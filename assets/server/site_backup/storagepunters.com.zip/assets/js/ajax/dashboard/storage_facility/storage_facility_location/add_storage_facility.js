function loadAllCompanyDataSequentially() {
    getAllCompanies()
        .then(function (typeResponse) {
            if (typeResponse.status === "success") {
                appendCompanies(typeResponse.data);
            }
        })
        .catch(function (error) {
            console.error("Error loading auction data:", error);
            showNotification("Failed to load auction data", "error");
        });
}


$(document).ready(function () {

    /*

    const timezones = moment.tz.names();
    const guessedZone = moment.tz.guess();

    $.each(timezones, function (index, timezone) {
        $('#storage_facility_timezone').append(
            $('<option>', {
                value: timezone,
                text: timezone
            })
        );
    });



    // Optionally preselect user's timezone
    $('#storage_facility_timezone').val(guessedZone);

    */

    loadAllCompanyDataSequentially();
});


$('#storage-facility-add-form').submit(function (event) {
    event.preventDefault(); // Prevent default form submission
    $('.error-message').remove();

    let isValid = true;
    let firstInvalid = null;

    function showError(inputId, message) {
        const $el = $(`#${inputId}`);
        $el.after(`<p class="error-message text-yellow text-error">${message}</p>`);
        if (!firstInvalid) firstInvalid = $el;
        isValid = false;
    }

    // Collect values
    const formData = {
        companyId: $("#companiesDropdown").val(),
        storage_facility_name: $("#storage_facility_name").val().trim(),
        storage_facility_abn: $("#storage_facility_abn").val().trim(),
        storage_facility_website: $("#storage_facility_website").val().trim(),
        storage_facility_description: $("#storage_facility_description").val().trim(),
        storage_facility_contact_email: $("#storage_facility_contact_email").val().trim(),
        storage_facility_additional_email: $("#storage_facility_additional_email").val().trim(),
        storage_facility_timezone: $("#storage_facility_timezone").val(),
        storage_facility_office_hours: $("#storage_facility_office_hours").val().trim(),
        storage_facility_payout_details: $("#storage_facility_payout_details").val().trim(),
        storage_facility_youtube_video_url: $("#storage_facility_youtube_video_url").val().trim(),
        storage_facility_branding_logo: $("#storage_facility_branding_logo").val().trim(),
        storage_facility_cell_phone: $("#cell_phone").val().trim(),
        storage_facility_street_address: $("#address").val().trim(),
        storage_facility_apt_suite: $("#apt_suite").val().trim(), // optional
        storage_facility_city: $("#city").val().trim(),
        storage_facility_zip: $("#zip").val().trim(),
        storage_facility_country: $("#country").val(),
        storage_facility_state: $("#state").val()
    };

    // Required field validation
    if (!formData.companyId) showError("companiesDropdown", "Please select a company.");
    if (!formData.storage_facility_name) showError("storage_facility_name", "Facility name is required.");
    if (!formData.storage_facility_abn) showError("storage_facility_abn", "ABN is required.");
    if (!formData.storage_facility_website || !/^https?:\/\/.+\..+/.test(formData.storage_facility_website)) {
        showError("storage_facility_website", "Enter a valid website URL.");
    }
    if (!formData.storage_facility_description) showError("storage_facility_description", "Description is required.");
    if (!formData.storage_facility_contact_email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.storage_facility_contact_email)) {
        showError("storage_facility_contact_email", "Enter a valid contact email.");
    }
    if (formData.storage_facility_additional_email &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.storage_facility_additional_email)) {
        showError("storage_facility_additional_email", "Enter a valid additional email.");
    }
    if (!formData.storage_facility_timezone) showError("storage_facility_timezone", "Select a timezone.");
    if (!formData.storage_facility_office_hours) showError("storage_facility_office_hours", "Office hours required.");
    if (!formData.storage_facility_payout_details) showError("storage_facility_payout_details", "Payout details required.");
    if (formData.storage_facility_youtube_video_url &&
        !/^https?:\/\/(www\.)?youtube\.com\/.+$/.test(formData.storage_facility_youtube_video_url)) {
        showError("storage_facility_youtube_video_url", "Enter a valid YouTube URL.");
    }
    if (!formData.storage_facility_cell_phone || !/^[\d\s()+-]{6,}$/.test(formData.storage_facility_cell_phone)) {
        showError("cell_phone", "Enter a valid phone number.");
    }
    if (!formData.storage_facility_street_address) showError("address", "Street address is required.");
    if (!formData.storage_facility_city) showError("city", "City is required.");
    if (!formData.storage_facility_zip || !/^\d{4,10}$/.test(formData.storage_facility_zip)) {
        showError("zip", "Enter a valid ZIP/postal code.");
    }
    if (!formData.storage_facility_country) showError("country", "Country is required.");
    if (!formData.storage_facility_state) showError("state", "State is required.");

    if (!isValid) {
        firstInvalid?.focus();
        return;
    }

    $("#save-storage-facility-add-btn").html('<span class="spinner-border spinner-border-sm"></span> Creating your storage facility...').attr("disabled", true);

    $.ajax({
        url: SITE_URL + 'api/storage/storage-facility/add', // Add with actual API endpoint
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(formData),
        dataType: 'json',
        beforeSend: function () {
            console.log('Adding storage facility details...');
        },
        success: function (response) {

            $("#save-storage-facility-add-btn").html("Add Facility").attr("disabled", false);

            if (response.status === "success") {
                showNotification(response.message, "success");


                // Delay briefly to let user see the message, then redirect
                setTimeout(function () {
                    window.location.href = SITE_URL + 'storage-facility/manage';
                }, 1000);

            } else {
                showNotification(response.message, "error");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {

            $("#save-storage-facility-add-btn").html("Add Facility").attr("disabled", false);
            let errorMessage = "Something went wrong. Try again.";

            if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                errorMessage = jqXHR.responseJSON.message;
            }

            showNotification(errorMessage, "error");
        }
    });
});

