$(document).ready(function () {


    $(".profile-btn").click(function (event) {
        event.stopPropagation(); // Prevent event bubbling

        // Toggle menu
        if ($(".profile_menu").length === 0) {
            $(".profile-btn").append(`
                <div class="mt-5 profile_menu d-flex flex-column justify-content-start gap-2 p-lg-2"
                    style="position: absolute; background: white; box-shadow: 0px 5px 10px rgba(0,0,0,0.2);
                    border-radius: 5px; padding: 10px; z-index: 1000;">
                    <li class="list-unstyled cursor-pointer active__dropdown btn__dashboard px-1 px-md-2">Dashboard</li>
                    <li class="list-unstyled cursor-pointer active__dropdown btn__account px-1 px-md-2">Edit Account</li>
                    <li class="list-unstyled cursor-pointer active__dropdown btn__logout px-1 px-md-2">Log Out</li>
                </div>
            `);

            // Change icon to UP when menu is opened
            $(".dropdown-icon").html(`
                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                    <path d="M256 217.9L383 345c9.4 9.4 24.6 9.4 33.9 0 9.4-9.4 9.3-24.6 0-34L273 167c-9.1-9.1-23.7-9.3-33.1-.7L95 310.9c-4.7 4.7-7 10.9-7 17s2.3 12.3 7 17c9.4 9.4 24.6 9.4 33.9 0l127.1-127z"></path>
                </svg>
            `);

            $(".btn__dashboard").click(function () {
                window.location.href = SITE_URL + "storage-facility/dashboard";
            });

            $(".btn__account").click(function () {
                window.location.href = SITE_URL + "storage-facility/edit-account";
            });

            $(".btn__setup__company").click(function () {
                window.location.href = SITE_URL + "company";
            });

            $(".btn__setup__bank__account").click(function () {
                window.location.href = SITE_URL + "bank";
            });

            $(".btn__manage__staff").click(function () {
                window.location.href = SITE_URL + "storage-facility/staff/manage";
            });

            $(".btn__manage__facility_storage").click(function () {
                window.location.href = SITE_URL + "storage-facility/manage";
            });

            $(".__btn__add__new__storage__facility").click(function () {
                window.location.href = SITE_URL + "storage-facility/add";
            });

            $(document).on("click", ".edit-storage-facility-btn", function () {
                let storageFacilityId = $(this).data("storage-facility-id");
                window.open(SITE_URL + "storage-facility/edit/" + storageFacilityId, "_blank"); // Open in a new tab
            });


            $('.btn__logout').on('click', function (e) {
                e.preventDefault(); // Prevent default form submission
                // Make AJAX request
                $.ajax({
                    url: SITE_URL + 'auth/logout', // Update the URL if necessary
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function (response) {

                        setTimeout(() => {
                            window.location.reload();
                        }, 300);
                    },
                    error: function (xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: xhr.responseJSON?.message || 'An unexpected error occurred. Please try again.',
                        });
                    },
                });
            });

        } else {
            $(".profile_menu").remove();

            // Change icon to DOWN when menu is closed
            $(".dropdown-icon").html(`
                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                    <path d="M256 294.1L383 167c9.4-9.4 24.6-9.4 33.9 0s9.3 24.6 0 34L273 345c-9.1 9.1-23.7 9.3-33.1.7L95 201.1c-4.7-4.7-7-10.9-7-17s2.3-12.3 7-17c9.4-9.4 24.6-9.4 33.9 0l127.1 127z"></path>
                </svg>
            `);
        }
    });

    $(".btn__dashboard").click(function () {
        window.location.href = SITE_URL + "storage-facility/dashboard";
    });

    $(".btn__edit__account").click(function () {
        window.location.href = SITE_URL + "storage-facility/edit-account";
    });

    $(".btn__setup__company").click(function () {
        window.location.href = SITE_URL + "company";
    });

    $(".btn__setup__bank__account").click(function () {
        window.location.href = SITE_URL + "bank";
    });

    $(".btn__manage__staff").click(function () {
        window.location.href = SITE_URL + "storage-facility/staff/manage";
    });

    $(".btn__manage__facility_storage").click(function () {
        window.location.href = SITE_URL + "storage-facility/manage";
    });

    $(".__btn__add__new__storage__facility").click(function () {
        window.location.href = SITE_URL + "storage-facility/add";
    });

    $(document).on("click", ".edit-storage-facility-btn", function () {
        let storageFacilityId = $(this).data("storage-facility-id");
        window.open(SITE_URL + "storage-facility/edit/" + storageFacilityId, "_blank"); // Open in a new tab
    });

});