let storageFacilityId = window.location.pathname.split("/").pop(); // Extract Auction ID from URL


function loadAllCompanyDataSequentially() {
    getAllCompanies()
        .then(function (typeResponse) {
            if (typeResponse.status === "success") {
                appendCompanies(typeResponse.data);
            }

            return fetchStorageFacilityDetails(storageFacilityId);
        })
        .catch(function (error) {
            console.error("Error loading auction data:", error);
            showNotification("Failed to load auction data", "error");
        });
}

$(document).ready(function () {

    /*
    const timezones = moment.tz.names();
    const guessedZone = moment.tz.guess();

    $.each(timezones, function (index, timezone) {
        $('#storage_facility_timezone').append(
            $('<option>', {
                value: timezone,
                text: timezone
            })
        );
    });

    // Optionally preselect user's timezone
    $('#storage_facility_timezone').val(guessedZone);
    */

    loadAllCompanyDataSequentially()


});


// Fetch auction details from API
function fetchStorageFacilityDetails(storageFacilityId) {


    $.ajax({
        url: SITE_URL + "api/storage/storage-facility/get_by_storage_id",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({ storageFacilityId: storageFacilityId }),
        success: function (response) {


            if (response.status === "success" && response.data) {
                let facility = response.data;


                // Basic fields
                $("#companiesDropdown").val(facility.storage_facility_company_id);
                $("#storage_facility_name").val(facility.storage_facility_name);
                $("#storage_facility_abn").val(facility.storage_facility_abn);
                $("#storage_facility_website").val(facility.storage_facility_website);
                $("#storage_facility_description").val(facility.storage_facility_description);
                $("#storage_facility_contact_email").val(facility.storage_facility_contact_email?.replace(/[\r\n]+/g, '').trim());
                $("#storage_facility_additional_email").val(facility.storage_facility_additional_email?.replace(/[\r\n]+/g, '').trim());
                $("#cell_phone").val(facility.storage_facility_cell_phone);
                $("#storage_facility_office_hours").val(facility.storage_facility_office_hours);
                $("#storage_facility_payout_details").val(facility.storage_facility_payout_details);
                $("#storage_facility_youtube_video_url").val(facility.storage_facility_youtube_video_url);
                $("#storage_facility_branding_logo").val(facility.storage_facility_branding_logo);

                // Address info
                $("#address").val(facility.storage_facility_street_address);
                $("#apt_suite").val(facility.storage_facility_apt_suite);
                $("#city").val(facility.storage_facility_city);
                $("#zip").val(facility.storage_facility_zip);
                $("#country").val(facility.storage_facility_country);
                $("#state").val(facility.storage_facility_state);

                // Set timezone if it's available after timezones are loaded
                const timezoneSelect = $("#storage_facility_timezone");
                const setTimezone = () => {
                    if (facility.storage_facility_timezone) {
                        timezoneSelect.val(facility.storage_facility_timezone);
                    }
                };

                // Wait for timezone options to be populated if using moment.tz.names()
                if (timezoneSelect.find("option").length > 1) {
                    setTimezone();
                } else {
                    setTimeout(setTimezone, 500); // fallback delay to ensure dropdown is ready
                }

                showNotification(response.message, "success");
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            let errorMessage = "Something went wrong. Try again.";

            if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                errorMessage = jqXHR.responseJSON.message;
            }

            showNotification(errorMessage, "error");
        }
    });
}



$('#storage-facility-update-form').submit(function (event) {
    event.preventDefault();
    $('.error-message').remove();

    let isValid = true;
    let firstInvalid = null;

    function showError(inputId, message) {
        const $el = $(`#${inputId}`);
        $el.after(`<p class="error-message text-yellow text-error">${message}</p>`);
        if (!firstInvalid) firstInvalid = $el;
        isValid = false;
    }


    let formData = {
        storageFacilityId: storageFacilityId, // Assuming you have this defined elsewhere
        companyId: $("#companiesDropdown").val(),
        storage_facility_name: $("#storage_facility_name").val().trim(),
        storage_facility_abn: $("#storage_facility_abn").val().trim(),
        storage_facility_website: $("#storage_facility_website").val().trim(),
        storage_facility_description: $("#storage_facility_description").val().trim(),
        storage_facility_contact_email: $("#storage_facility_contact_email").val().trim(),
        storage_facility_additional_email: $("#storage_facility_additional_email").val().trim(),
        storage_facility_timezone: $("#storage_facility_timezone").val(),
        storage_facility_office_hours: $("#storage_facility_office_hours").val().trim(),
        storage_facility_payout_details: $("#storage_facility_payout_details").val().trim(),
        storage_facility_youtube_video_url: $("#storage_facility_youtube_video_url").val().trim(),
        storage_facility_branding_logo: $("#storage_facility_branding_logo").val().trim(),

        storage_facility_cell_phone: $("#cell_phone").val().trim(),

        storage_facility_street_address: $("#address").val().trim(),
        storage_facility_apt_suite: $("#apt_suite").val().trim(),
        storage_facility_city: $("#city").val().trim(),
        storage_facility_zip: $("#zip").val().trim(),
        storage_facility_country: $("#country").val(),
        storage_facility_state: $("#state").val()
    };

    // Validations
    if (!formData.companyId) showError("companiesDropdown", "Please select a company.");
    if (!formData.storage_facility_name) showError("storage_facility_name", "Facility name is required.");
    if (!formData.storage_facility_abn) showError("storage_facility_abn", "ABN is required.");
    if (!formData.storage_facility_website || !/^https?:\/\/.+\..+/.test(formData.storage_facility_website)) {
        showError("storage_facility_website", "Enter a valid website URL.");
    }
    if (!formData.storage_facility_description) showError("storage_facility_description", "Description is required.");
    if (!formData.storage_facility_contact_email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.storage_facility_contact_email)) {
        showError("storage_facility_contact_email", "Enter a valid contact email.");
    }
    if (formData.storage_facility_additional_email &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.storage_facility_additional_email)) {
        showError("storage_facility_additional_email", "Enter a valid additional email.");
    }
    if (!formData.storage_facility_timezone) showError("storage_facility_timezone", "Select a timezone.");
    if (!formData.storage_facility_office_hours) showError("storage_facility_office_hours", "Office hours required.");
    if (!formData.storage_facility_payout_details) showError("storage_facility_payout_details", "Payout details required.");
    if (formData.storage_facility_youtube_video_url &&
        !/^https?:\/\/(www\.)?youtube\.com\/.+$/.test(formData.storage_facility_youtube_video_url)) {
        showError("storage_facility_youtube_video_url", "Enter a valid YouTube URL.");
    }
    if (!formData.storage_facility_cell_phone || !/^[\d\s()+-]{6,}$/.test(formData.storage_facility_cell_phone)) {
        showError("cell_phone", "Enter a valid phone number.");
    }
    if (!formData.storage_facility_street_address) showError("address", "Street address is required.");
    if (!formData.storage_facility_city) showError("city", "City is required.");
    if (!formData.storage_facility_zip || !/^\d{4,10}$/.test(formData.storage_facility_zip)) {
        showError("zip", "Enter a valid ZIP/postal code.");
    }
    if (!formData.storage_facility_country) showError("country", "Country is required.");
    if (!formData.storage_facility_state) showError("state", "State is required.");

    if (!isValid) {
        firstInvalid?.focus();
        return;
    }

    $("#save-storage-facility-updates-btn").html('<span class="spinner-border spinner-border-sm"></span> Saving changes...').attr("disabled", true);

    $.ajax({
        url: SITE_URL + 'api/storage/storage-facility/update', // Update with actual API endpoint
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(formData),
        dataType: 'json',
        beforeSend: function () {
            console.log('Updating storage facility details...');
        },
        success: function (response) {

            $("#save-storage-facility-updates-btn").html("Save Updates").attr("disabled", false);

            if (response.status === "success") {

                showNotification(response.message, "success");
            } else {
                showNotification(response.message, "error");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {

            $("#save-storage-facility-updates-btn").html("Save Updates").attr("disabled", false);

            let errorMessage = "Something went wrong. Try again.";

            if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                errorMessage = jqXHR.responseJSON.message;
            }

            showNotification(errorMessage, "error");
        }
    });
});

