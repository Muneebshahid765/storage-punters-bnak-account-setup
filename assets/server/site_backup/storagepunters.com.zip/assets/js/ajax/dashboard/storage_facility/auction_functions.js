function loadAllAuctionDataSequentially() {
    return getAllAuctionTypes()
        .then(function (typeResponse) {
            if (typeResponse.status === "success") {
                appendAuctionTypes(typeResponse.data);
            }
            return getAllAuctionStorageFacilities();
        })
        .then(function (facilitiesResponse) {
            if (facilitiesResponse.status === "success") {
                appendAuctionFacilities(facilitiesResponse.data);
            }

            if ($("#auctionCategoryDropdown").length) {
                return getAllAuctionCategory().then(function (categoryResponse) {
                    if (categoryResponse.status === "success") {
                        appendAuctionCategories(categoryResponse.data);
                    }
                });
            }

            // 🔁 Return a resolved promise if no category dropdown
            return Promise.resolve();
        })
        .catch(function (error) {
            console.error("Error loading auction data:", error);
            showNotification("Failed to load auction data", "error");
        });
}


// Recalculate on date or time change
$('#auction_start_date, #auction_start_time').on('change', calculateEndDateTime);


function calculateEndDateTime() {
    const startDate = $('#auction_start_date').val();      // format: YYYY-MM-DD
    const startTime = $('#auction_start_time').val();      // format: "hh:mm AM/PM"

    if (!startDate || !startTime) return;

    // Split into time and meridian (AM/PM)
    const [timePart, ampm] = startTime.split(' ');
    let [hours, minutes] = timePart.split(':').map(Number);

    // Convert to 24-hour format
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;

    // Parse start date
    const [year, month, day] = startDate.split('-').map(Number);

    // Construct date object in local time
    const startDateTime = new Date(year, month - 1, day, hours, minutes, 0); // month is 0-indexed
    if (isNaN(startDateTime.getTime())) return;

    // Add 72 hours
    const endDateTime = new Date(startDateTime.getTime() + 72 * 60 * 60 * 1000);

    // Format end date: YYYY-MM-DD
    const endYear = endDateTime.getFullYear();
    const endMonth = (endDateTime.getMonth() + 1).toString().padStart(2, '0');
    const endDay = endDateTime.getDate().toString().padStart(2, '0');
    const endDate = `${endYear}-${endMonth}-${endDay}`;

    // Format end time as hh:mm AM/PM
    let endHours = endDateTime.getHours();
    const endMinutes = endDateTime.getMinutes().toString().padStart(2, '0');
    const endAMPM = endHours >= 12 ? 'PM' : 'AM';
    endHours = endHours % 12 || 12;
    const formattedEndTime = `${endHours.toString().padStart(2, '0')}:${endMinutes} ${endAMPM}`;

    // Update the end date and time dropdown
    $('#auction_end_date').val(endDate);
    $('#auction_end_time').empty().append(
        $('<option>', {
            value: formattedEndTime,
            text: formattedEndTime,
            selected: true
        })
    );
}




// Set today's date as the minimum selectable date
$(document).ready(function () {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = (today.getMonth() + 1).toString().padStart(2, '0'); // month is 0-based
    const dd = today.getDate().toString().padStart(2, '0');
    const minDate = `${yyyy}-${mm}-${dd}`;

    $('#auction_start_date').attr('min', minDate);
});


function restrictToDecimal(inputSelector) {
    $(document).on('input', inputSelector, function () {
        let value = $(this).val();

        // Remove all characters except digits and dots
        value = value.replace(/[^0-9.]/g, '');

        // Keep only the first dot
        const parts = value.split('.');
        if (parts.length > 1) {
            value = parts[0] + '.' + parts.slice(1).join('');
        }

        $(this).val(value);
    });

    $(document).on('keydown', inputSelector, function (e) {
        const allowedKeys = [
            'Backspace', 'Tab', 'ArrowLeft', 'ArrowRight', 'Delete', 'Home', 'End'
        ];

        if (
            allowedKeys.includes(e.key) ||
            (e.ctrlKey && ['a', 'c', 'v', 'x'].includes(e.key.toLowerCase()))
        ) {
            return;
        }

        const currentValue = $(this).val();

        // Allow digits
        if (/^\d$/.test(e.key)) return;

        // Allow one dot
        if (e.key === '.' && !currentValue.includes('.')) return;

        // Block anything else
        e.preventDefault();
    });

    // Block paste, drop, right-click
    $(document).on('paste drop contextmenu', inputSelector, function (e) {
        e.preventDefault();
    });
}



