$(document).ready(function () {


    const $spinner = $('#spinner-overlay');

    function showSpinner() { $spinner.show(); }
    function hideSpinner() { $spinner.hide(); }

    function staffMemberListTable() {


        // Check if DataTable is already initialized
        if ($.fn.DataTable.isDataTable('#staff-member-table')) {
            // DataTable is already initialized, destroy the existing instance
            $('#staff-member-table').DataTable().destroy();
        }

        // Initialize DataTable
        $('#staff-member-table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": SITE_URL + "api/staff/storage-facility/get", // Change this to your backend URL
                "type": "POST",
                "beforeSend": function () {
                    showUniversalLoaderForTable('staff-member-table');
                },
                "dataSrc": function (json) {

                    hideUniversalLoader();

                    if (json.status === "success" && json.result) {
                        showNotification(json.message, "success");

                        json.draw = json.result.draw;
                        json.recordsTotal = json.result.recordsTotal;
                        json.recordsFiltered = json.result.recordsFiltered;
                        return json.result.data;
                    }

                    // Manually override DataTables draw & record counts
                    json.draw = json.result?.draw ?? 0;
                    json.recordsTotal = json.result?.recordsTotal ?? 0;
                    json.recordsFiltered = json.result?.recordsFiltered ?? 0;

                    showNotification(json.message, "error");
                    return [];
                },
                "error": function (xhr, status, error) {

                    hideUniversalLoader();

                    console.error("DataTables AJAX error:", status, error);
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.error) {
                            console.error("Server error:", response.message);
                        }
                    } catch (e) {
                        console.error("Error parsing JSON response:", e);
                    }
                },
            },
            "columns": [
                { "data": "staff_member_id" },
                { "data": "staff_member_first_name" },
                { "data": "staff_member_last_name" },
                { "data": "staff_member_email" },
                {
                    "data": "staff_member_status",
                    "orderable": false, // Disable sorting for this column
                    "render": function (data, type, row) {
                        // Check the status and generate the Bootstrap Switch button accordingly
                        var isChecked = (data.toLowerCase() === 'active');
                        var switchHtml = '<input type="checkbox" data-toggle="toggle" data-type="account" data-action="activation" data-on="Active" data-off="Inactive" ' +
                            'data-onstyle="success" data-offstyle="danger" ' +
                            'data-staff-member-system-id="' + row.staff_member_id + '" ' +
                            (isChecked ? 'checked' : '') + '>';

                        var resendButton = `
            <button type="button" class="btn btn-sm btn-yellow btn-contact text-uppercase text-white ms-2 __btn__resend__invitation"
                title="Resend Invitation"
                data-staff-member-id="${row.staff_member_id}"
                data-staff-member-email="${row.staff_member_email}">
                <i class="bi bi-arrow-clockwise"></i> Resend
            </button>
        `;

                        return switchHtml + resendButton;
                    }
                }/*,
                {
                    "data": null,
                    "orderable": false, // Disable sorting for this column
                    "render": function (data, type, row) {
                        return `<button type="button" style="border-radius: 12px; border: medium; font-weight: 500;"
                                    class="__btn__view__staff_member btn-yellow btn-contact px-md-4 d-flex align-items-center align-center gap-1  btn btn-primary btn-sm"
                                    data-staff-member-id="${row.staff_member_id}"
                                    data-staff-member-first-name="${row.staff_member_first_name}"
                                    data-staff-member-last-name="${row.staff_member_last_name}"
                                    data-staff-member-email="${row.staff_member_email}"
                                    <span>
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"></path>
                                        </svg>
                                    </span>
                                    <span class="__btn__update__staff__member__text">Edit Staff</span>

                                </button>`;
                    }
                }*/

            ],
            "order": [[1, 'desc']], // Set the combined name column as default sort
            "initComplete": function (settings, json) {

            },
            "drawCallback": function (settings) {
                // Initialize Bootstrap Switch for new elements
                $('[data-toggle="toggle"]').bootstrapSwitch();


                // Handle switch change event for elements with data-type='staff'
                $('[data-toggle="toggle"][data-action="activation"]').on('switchChange.bootstrapSwitch', function (event, state) {
                    var staffMemberId = $(this).data('staff-member-system-id');
                    var status = state ? 'Active' : 'Inactive';

                    let actionMessage = status.toLowerCase() === "active"
                        ? "You are about to <strong>active</strong> this staff. Do you want to proceed?"
                        : "You are about to <strong>deactive</strong> this staff. Do you want to continue?";

                    Swal.fire({
                        title: 'Are you sure?',
                        html: actionMessage, // ✅ Clear message for activation & deactivation
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, change it!'
                    }).then((result) => {
                        if (result.isConfirmed) {

                            $.ajax({
                                url: SITE_URL + 'api/staff/storage-facility/update-status',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify({
                                    staff_member_id: staffMemberId,
                                    staff_member_status_name: status
                                }),
                                beforeSend: function () {

                                },
                                success: function (response) {

                                    if (response.status === "success") {

                                        showNotification(response.message, "success");
                                        staffMemberListTable();

                                    } else {
                                        showNotification(response.message, "error");
                                    }
                                    // Additional success handling
                                },
                                error: function (jqXHR, textStatus, errorThrown) {
                                    let errorMessage = "Something went wrong. Try again.";

                                    if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                                        errorMessage = jqXHR.responseJSON.message;
                                    }
                                    $('[data-toggle="toggle"][data-action="activation"][data-staff-member-system-id="' + staffMemberId + '"]').bootstrapSwitch('toggleState', true);


                                    showNotification(errorMessage, "error");
                                }
                            });

                        } else {
                            // User clicked No or closed the dialog, revert the switch state

                            $('[data-toggle="toggle"][data-action="activation"][data-staff-member-system-id="' + staffMemberId + '"]').bootstrapSwitch('toggleState', true);

                        }
                    });
                });


            },
            "rowCallback": function (row, data, index) {
                // Add click event to the entire row except for the buttons
                $(row).on('click', function (event) {
                    // Check if the clicked element is not a button or a link
                    if (!$(event.target).is('button') && !$(event.target).is('a')) {


                    }
                });

                // Add hover effect
                $(row).hover(
                    function () {
                        $(this).addClass('table-hover');
                    },
                    function () {
                        $(this).removeClass('table-hover');
                    }
                ).css('cursor', 'pointer');
            },
        });

        /*$(document).on("click", ".__btn__view__staff_member", function () {

            let formContainer = $(".__table__staff__member");

            // Extract values from `data-` attributes
            let staffMemberId = $(this).data("staff-member-id");
            let firstName = $(this).data("staff-member-first-name");
            let lastName = $(this).data("staff-member-last-name");
            let email = $(this).data("staff-member-email");


            // Toggle form: If exists → Remove; Else → Append
            if ($(".__update__staff_member__form").length > 0 || $(".__new__staff_member__add__form").length > 0) {
                $(".__update__staff_member__form").slideUp(300, function () {
                    $(this).remove();
                    // Find the button where `data-staff-member-id` matches the selected ID
                    $(`.__btn__update__staff__member__text`).text("Edit Staff");
                    $(".__btn__add__new__staff__member__text").text("Add New");
                });
                $(".__new__staff_member__add__form").slideUp(300, function () {
                    $(this).remove();
                    $(".__btn__add__new__staff__member__text").text("Add New");
                    // Find the button where `data-staff-member-id` matches the selected ID
                    $(`.__btn__update__staff__member__text`).text("Edit Staff");
                });
            } else {
                let formHTML = `
                <div class="mt-5 mb-5 __update__staff_member__form">
                    <form id="staffMemberUpdateForm">

                     <input type="hidden" id="staff_member_id" value="${staffMemberId}" class="input-secondary text-300">

                    <div class="row">
                        <div class="mt-4 col-xl-6 col-lg-3 col-md-6">
                            <label for="firstname" class="input-label-secondary">First Name *</label>
                            <div class="input-field-container">
                                <input id="firstname" type="text" placeholder="First name" name="firstname"
                                    class="input-secondary text-300" value="${firstName}">
                            </div>
                        </div>

                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                            <label for="lastname" class="input-label-secondary">Last Name *</label>
                            <div class="input-field-container">
                                <input id="lastname" type="text" placeholder="Last name" name="lastname"
                                    class="input-secondary text-300" value="${lastName}">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="mt-4 col-lg-12 col-md-12">
                            <label for="email_address" class="input-label-secondary">Email *</label>
                            <div class="input-field-container">
                                <input id="email_address" type="email" placeholder="Email Address" name="email_address"
                                    class="input-secondary text-300" value="${email}" readonly>
                            </div>
                        </div>
                    </div>


                         <div style="width: max-content;" class="mt-4 mx-auto col">
                            <button type="submit" class="w-100 btn-yellow btn-update-staff-member btn-contact text-uppercase px-md-4 btn btn-primary btn-md">
                                Update Staff Information
                            </button>
                        </div>
                    </form>
                </div>`;

                formContainer.append(formHTML);


                $(".__update__staff_member__form").hide().slideDown(300);
                $(`.__btn__update__staff__member__text`).text("Edit Staff");
                $(`button[data-staff-member-id="${staffMemberId}"] .__btn__update__staff__member__text`).text("Hide");
            }

        });*/


    }

    staffMemberListTable();


    $(document).on("click", ".__btn__add__new__staff__member", function () {
        let formContainer = $(".__table__staff__member");


        // Toggle form: If exists → Remove; Else → Append
        if ($(".__update__staff__member__form").length > 0 || $(".__new__staff__member__add__form").length > 0) {
            $(".__update__staff__member__form").slideUp(300, function () {
                $(this).remove();
                $(".__btn__update__new__staff__member__text").text("Edit Staff");
                $(".__btn__add__new__staff__member__text").text("Add New");
            });
            $(".__new__staff__member__add__form").slideUp(300, function () {
                $(this).remove();
                $(".__btn__add__new__staff__member__text").text("Add New");
                $(".__btn__update__new__staff__member__text").text("Edit Staff");
            });
        } else {
            let formHTML = `
             <div class="mt-5 mb-5 __new__staff__member__add__form">
                 <form id="staffMemberAddForm">

                    <div class="row">
                        <div class="mt-4 col-xl-6 col-lg-3 col-md-6">
                            <label for="firstname" class="input-label-secondary">First Name *</label>
                            <div class="input-field-container">
                                <input id="firstname" type="text" placeholder="First name" name="firstname"
                                    class="input-secondary text-300" value="">
                            </div>
                        </div>

                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                            <label for="lastname" class="input-label-secondary">Last Name *</label>
                            <div class="input-field-container">
                                <input id="lastname" type="text" placeholder="Last name" name="lastname"
                                    class="input-secondary text-300" value="">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="mt-4 col-lg-12 col-md-12">
                            <label for="email_address" class="input-label-secondary">Email *</label>
                            <div class="input-field-container">
                                <input id="email_address2" type="email" placeholder="Email Address" name="email_address2"
                                    class="input-secondary text-300" value="">
                            </div>
                        </div>
                    </div>

                      <div style="width: max-content;" class="mt-4 mx-auto col">
                         <button type="submit" class="w-100 btn-yellow btn-contact btn-add-new-staff-member text-uppercase px-md-4 btn btn-primary btn-md">
                             Send Invite
                         </button>
                     </div>
                 </form>
             </div>`;



            formContainer.append(formHTML);

            $(".__new__staff__member__add__form").hide().slideDown(300);
            $(".__btn__add__new__staff__member__text").text("Hide");
        }
    });


    $(document).on("submit", "#staffMemberAddForm", async function (e) {
        e.preventDefault();

        $(".error-message").remove(); // Clear previous error messages

        let isValid = true;
        let firstInvalid = null;

        function showError(id, message) {
            const $el = $(`#${id}`);
            $el.after(`<p class="error-message text-yellow text-error">${message}</p>`);
            if (!firstInvalid) firstInvalid = $el;
            isValid = false;
        }

        // Collect input values
        let firstname = $("#firstname").val().trim();
        let lastname = $("#lastname").val().trim();
        let email_address = $("#email_address2").val().trim();

        // Validate first name
        if (!firstname) showError("firstname", "First name is required.");

        // Validate last name
        if (!lastname) showError("lastname", "Last name is required.");

        // Validate email
        if (!email_address) {
            showError("email_address2", "Email address is required.");
        } else {
            const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailPattern.test(email_address)) {
                showError("email_address2", "Please enter a valid email address.");
            }
        }

        if (!isValid) {
            firstInvalid?.focus();
            return;
        }

        let formData = {
            firstname: firstname,
            lastname: lastname,
            email: email_address
        };

        showSpinner(); // Show global spinner

        $.ajax({
            url: SITE_URL + "api/staff/storage-facility/add",
            type: 'POST',
            contentType: "application/json",
            dataType: 'json',
            data: JSON.stringify(formData),
            beforeSend: function () {
                // showUniversalLoaderForTable('staff-member-table');
            },
            success: function (response) {

                hideUniversalLoader();

                if (response.status === 'success') {


                    if (response.data && response.data.email && response.data.company_id) {
                        $.ajax({
                            url: SITE_URL + "email/process-staff-invitation",
                            type: "POST",
                            contentType: "application/json",
                            data: JSON.stringify({
                                email: response.data.email,
                                companyId: response.data.company_id,
                            }),
                            success: function (emailResponse) {

                                hideSpinner();

                                if (emailResponse.success) {
                                    showNotification(emailResponse.message, "success");
                                    staffMemberListTable();

                                    $(".__new__staff__member__add__form").slideUp(300, function () {
                                        $(this).remove();
                                        $(".__btn__add__new__staff__member__text").text("Add New");
                                        $(".__btn__update__new__staff__member__text").text("Edit Staff");
                                    });


                                } else {
                                    showNotification(emailResponse.message, "error");
                                }
                            },
                            error: function () {
                                console.error("Email sending failed.");

                            }
                        });
                    } else {
                        showNotification("We couldn't send the invitation email. Please try again later.", "error");
                        hideSpinner();
                    }
                } else {

                    showNotification(response.message, "error");
                    hideSpinner();
                }
            },
            error: function (xhr, status, error) {
                hideUniversalLoader();
                showNotification(xhr.responseJSON.message, "error");
                hideSpinner();
            }
        });
    });

    $(document).on("click", ".__btn__resend__invitation", function () {

        showSpinner(); // Show global spinner

        const email = $(this).data("staff-member-email");

        $.ajax({
            url: SITE_URL + "email/process-staff-invitation",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({
                email: email
            }),
            success: function (emailResponse) {

                hideSpinner();

                if (emailResponse.success) {
                    showNotification(emailResponse.message, "success");

                } else {
                    showNotification(emailResponse.message, "error");
                }
            },
            error: function () {
                console.error("Email sending failed.");

                hideSpinner();

            }
        });
    });


    /* $(document).on("submit", "#staffMemberUpdateForm", async function (e) {
         e.preventDefault();

         // Validate input fields
         let staff_member_id = $("#staff_member_id").val().trim();
         let firstname = $("#firstname").val().trim();
         let lastname = $("#lastname").val().trim();

         // Validate required fields
         if (!firstname || !lastname) {
             showNotification("All fields are required.", "error");
             return;
         }

         let formData = {
             staff_member_id: staff_member_id,
             firstname: firstname,
             lastname: lastname,
         };


         $.ajax({
             url: SITE_URL + "api/staff/storage-facility/update",
             type: 'POST',
             contentType: "application/json",
             dataType: 'json',
             data: JSON.stringify(formData),
             beforeSend: function () {
                 showUniversalLoaderForTable('staff-member-table');
             },
             success: function (response) {
                 $(".btn-update-staff-member").text("Update Staff Informations").prop("disabled", false);

                 if (response.status === "success") {

                     showNotification(response.message, "success");


                     $(".__update__staff_member__form").slideUp(300, function () {
                         $(this).remove();
                         $(".__btn__add__new__staff_member__text").text("Add New");
                         $(".__btn__update__staff__member__text").text("Edit Staff");
                     });

                     staffMemberListTable();
                 } else {

                     showNotification(response.message, "error");
                 }
             },
             error: function (jqXHR, textStatus, errorThrown) {

                 $(".btn-update-staff-member").text("Update Staff Information").prop("disabled", false);

                 let errorMessage = "Something went wrong. Try again.";

                 if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                     errorMessage = jqXHR.responseJSON.message;
                 }

                 showNotification(errorMessage, "error");
             }
         });
     });*/

});
