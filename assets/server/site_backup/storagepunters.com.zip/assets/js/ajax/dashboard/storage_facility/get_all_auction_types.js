function getAllAuctionTypes() {
    return $.ajax({
        url: SITE_URL + "api/auction/types",
        type: "POST",
        dataType: "json"
    });
}

function appendAuctionTypes(types) {
    const $dropdown = $("#auctionTypeDropdown");
    $dropdown.empty().append(`<option value="">Select Type</option>`);

    if (Array.isArray(types)) {
        types.forEach(type => {
            $dropdown.append(`<option value="${type.type_id}">${type.type_name}</option>`);
        });
    } else if (types && typeof types === "object") {
        // Handle single object fallback
        $dropdown.append(`<option value="${types.type_id}">${types.type_name}</option>`);
    }
}
