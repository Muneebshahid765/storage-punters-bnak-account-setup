const stripe = Stripe("pk_test_51R6fiK08JMAyNQJTF2EpTojLfkVPdSgt5touShfm70M2bR8NPh3TpF0sBN9VbipYTyREO0tTjXoNmstPvfEWYuJz00xbqLoHEU"); // test
//const stripe = Stripe("pk_live_51R6fi607pHCLCmTyXRaheK6FNnYKyaCdTNz4HN7iAvztRLBOLJt9Ttaka3LtddT64QBKXCEEwOxlKkzAgZ9bbmZV00qblODcVU"); // production

var elements = stripe.elements();
var card; // ✅ declare card globally
var style = '';

style = {
    base: {
        color: '#32325d',
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSmoothing: 'antialiased',
        fontSize: '16px',
        '::placeholder': {
            color: '#aab7c4'
        }
    },
    invalid: {
        color: '#fa755a',
        iconColor: '#fa755a'
    }
};

async function search_customer_by_email() {
    try {
        const response = await fetch(SITE_URL + "api/stripe/customer/search_by_email", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest" // ✅ This line fixes the issue
            },
            body: JSON.stringify({})
        });

        const data = await response.json();

        if (!response.ok || !data) {
            throw new Error(data.message || "Failed to check customer.");
        }

        if (data.success && data.customer) {
            return { exists: true, customer: data.customer };
        } else {
            return { exists: false, customer: null };
        }

    } catch (error) {

        return { exists: false, customer: null };
    }
}


async function create_stripe_customer() {
    try {
        const response = await fetch(SITE_URL + "api/stripe/customer/add", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest" // ✅ This line fixes the issue
            },
            body: JSON.stringify({})
        });

        const data = await response.json();

        if (!response.ok || !data.success || !data.customer) {
            throw new Error(data.message || "Customer creation failed.");
        }

        return {
            success: true,
            customer: data.customer
        };
    } catch (error) {

        return {
            success: false,
            message: error.message || "Unknown error occurred"
        };
    }
}

async function attach_bank_account(customer_id, token) {
    try {
        const response = await fetch(SITE_URL + "api/stripe/bank-account/attach", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            },
            body: JSON.stringify({
                customer_id: customer_id,
                token: token
            })
        });

        const data = await response.json();

        if (!response.ok || data.status !== "success") {
            throw new Error(data.message || "Failed to attach bank account.");
        }

        return {
            success: true,
            message: data.message,
            data: data.data || null
        };

    } catch (error) {
        return {
            success: false,
            message: error.message || "Unknown error occurred while attaching bank account"
        };
    }
}

