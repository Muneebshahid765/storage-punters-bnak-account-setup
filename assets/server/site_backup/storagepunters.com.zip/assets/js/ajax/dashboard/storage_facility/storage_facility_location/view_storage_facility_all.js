$(document).ready(function () {


    function storageFacilityListTable() {


        // Check if DataTable is already initialized
        if ($.fn.DataTable.isDataTable('#storage-facility-table')) {
            // DataTable is already initialized, destroy the existing instance
            $('#storage-facility-table').DataTable().destroy();
        }

        // Initialize DataTable
        $('#storage-facility-table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": SITE_URL + "api/storage/storage-facility/get", // Change this to your backend URL
                "type": "POST",
                "beforeSend": function () {

                },
                "dataSrc": function (json) {


                    if (json.status === "success" && json.result) {
                        showNotification(json.message, "success");

                        json.draw = json.result.draw;
                        json.recordsTotal = json.result.recordsTotal;
                        json.recordsFiltered = json.result.recordsFiltered;
                        return json.result.data;
                    }

                    showNotification(json.message, "error");
                    return [];
                },
                "error": function (xhr, status, error) {
                    console.error("DataTables AJAX error:", status, error);
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.error) {
                            console.error("Server error:", response.message);
                        }
                    } catch (e) {
                        console.error("Error parsing JSON response:", e);
                    }
                },
            },
            "columns": [
                { "data": "storage_facility_id" },
                { "data": "storage_facility_name" },
                { "data": "storage_facility_company_name" },
                { "data": "storage_facility_timezone" },
                { "data": "storage_facility_updated_at" },
                {
                    "data": "storage_facility_status",
                    "orderable": false, // Disable sorting for this column
                    "render": function (data, type, row) {
                        // Check the status and generate the Bootstrap Switch button accordingly
                        var isChecked = (data.toLowerCase() === 'active');
                        var switchHtml = '<input type="checkbox" data-toggle="toggle" data-type="account" data-action="verification" data-on="Active" data-off="Inactive" ' +
                            'data-onstyle="success" data-offstyle="danger" ' +
                            'data-storage-facility-system-id="' + row.storage_facility_id + '" ' +
                            (isChecked ? 'checked' : '') + '>';

                        return switchHtml;
                    }
                }, {
                    "data": null,
                    "orderable": false,
                    "render": function (data, type, row) {
                        return `
                        <div style="position: relative; display: inline-block;">

                            <!-- Three Dots (⋮) Dropdown Menu -->
                            <div class="dropdown d-inline-block">
                                <button style="background: #1C421D !important;" class=" border-0 btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    ⋮
                                </button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item edit-storage-facility-btn" href="#" data-storage-facility-id="${row.storage_facility_id}">
                                            <i class="bi bi-pencil-square me-2"></i> Edit
                                        </a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                        `;
                    }
                },
            ],
            "order": [[1, 'desc']], // Set the combined name column as default sort
            "initComplete": function (settings, json) {

            },
            "drawCallback": function (settings) {
                // Initialize Bootstrap Switch for new elements
                $('[data-toggle="toggle"]').bootstrapSwitch();

                // Handle switch change event for elements with data-type='card'
                $('[data-toggle="toggle"][data-action="verification"]').on('switchChange.bootstrapSwitch', function (event, state) {
                    var storageFacilityId = $(this).data('storage-facility-system-id');
                    var status = state ? 'Active' : 'Inactive';

                    let actionMessage = status.toLowerCase() === "active"
                        ? "You are about to <strong>activate</strong> this card. Do you want to proceed?"
                        : "You are about to <strong>deactivate</strong> this card. Do you want to continue?";

                    Swal.fire({
                        title: 'Are you sure?',
                        html: actionMessage, // ✅ Clear message for activation & deactivation
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, change it!'
                    }).then((result) => {
                        if (result.isConfirmed) {

                            $.ajax({
                                url: SITE_URL + 'api/storage/storage-facility/update-status',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify({
                                    storage_facility_id: storageFacilityId,
                                    storage_facility_status_name: status
                                }),
                                beforeSend: function () {

                                },
                                success: function (response) {

                                    if (response.status === "success") {

                                        showNotification(response.message, "success");
                                        storageFacilityListTable();

                                    } else {
                                        showNotification(response.message, "error");
                                    }
                                    // Additional success handling
                                },
                                error: function (jqXHR, textStatus, errorThrown) {
                                    let errorMessage = "Something went wrong. Try again.";

                                    if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                                        errorMessage = jqXHR.responseJSON.message;
                                    }
                                    $('[data-payment-method-system-id="' + storageFacilityId + '"]').bootstrapSwitch('toggleState', true);

                                    showNotification(errorMessage, "error");
                                }
                            });

                        } else {
                            // User clicked No or closed the dialog, revert the switch state

                            $('[data-storage-facility-system-id="' + storageFacilityId + '"]').bootstrapSwitch('toggleState', true);
                        }
                    });
                });


            },
            "rowCallback": function (row, data, index) {
                // Add click event to the entire row except for the buttons
                $(row).on('click', function (event) {
                    // Check if the clicked element is not a button or a link
                    if (!$(event.target).is('button') && !$(event.target).is('a')) {


                    }
                });

                // Add hover effect
                $(row).hover(
                    function () {
                        $(this).addClass('table-hover');
                    },
                    function () {
                        $(this).removeClass('table-hover');
                    }
                ).css('cursor', 'pointer');
            },
        });




    }

    storageFacilityListTable();

});
