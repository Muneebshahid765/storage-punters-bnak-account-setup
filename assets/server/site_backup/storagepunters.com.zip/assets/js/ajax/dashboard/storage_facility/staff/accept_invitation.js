$(document).ready(function () {

    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const companyId = $("#company_id").val();
    const userId = $("#user_id").val();

    const $spinner = $('#spinner-overlay');

    function showSpinner() { $spinner.show(); }
    function hideSpinner() { $spinner.hide(); }


    // Fetch auction details from API
    function fetchCompanyDetails(company_id, user_id) {

        showSpinner(); // Show global spinner

        $.ajax({
            url: SITE_URL + "companies/get_by_company_id",
            type: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({ companyId: company_id, userId: user_id }),
            success: function (response) {
                hideSpinner();


                if (response.status === "success" && response.data) {
                    $("#company_name").text(response.data.company_name);
                } else {
                    $("#company_name").text("Unknown Company");
                }

            },
            error: function (jqXHR, textStatus, errorThrown) {
                let errorMessage = "Something went wrong. Try again.";

                if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    errorMessage = jqXHR.responseJSON.message;
                }
                $("#company_name").text("Error loading company");
                showNotification(errorMessage, "error");
                hideSpinner();

            }
        });
    }

    // Call on page load
    fetchCompanyDetails(companyId, userId);

    // Accept button
    $("#btnAccept").on("click", function () {
        $.ajax({
            url: SITE_URL + "api/users/invitation/accept",
            type: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({ userId: userId, companyId: companyId, token: token }),
            success: function (response) {
                if (response.status === "success") {
                    showNotification("Invitation accepted!", "success");

                    setTimeout(function () {
                        window.location.href = SITE_URL;
                    }, 2000); //

                } else {
                    showNotification(response.message, "error");
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                let errorMessage = "Something went wrong while accepting invitation. Try again.";

                if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    errorMessage = jqXHR.responseJSON.message;
                }

                showNotification(errorMessage, "error");
            }
        });
    });

    // Accept button
    $("#btnCancel").on("click", function () {
        $.ajax({
            url: SITE_URL + "api/users/invitation/cancel",
            type: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({ userId: userId, companyId: companyId, token: token }),
            success: function (response) {
                if (response.status === "success") {

                    showNotification(response.message, "success");

                    setTimeout(function () {
                        window.location.href = SITE_URL;
                    }, 2000); //
                } else {
                    showNotification(response.message, "error");
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                let errorMessage = "Something went wrong while accepting invitation. Try again.";

                if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    errorMessage = jqXHR.responseJSON.message;
                }

                showNotification(errorMessage, "error");
            }
        });
    });


});