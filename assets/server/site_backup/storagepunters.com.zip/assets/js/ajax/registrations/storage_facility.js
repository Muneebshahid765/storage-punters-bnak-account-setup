$(document).ready(function () {
    const $form = $('#storage-punter-signup-form');
    const $spinner = $('#spinner-overlay');
    const $actionBtn = $('#action-button');
    const $otpContainer = $('#otp-dynamic-container');

    let otpVerified = false;
    let canResendOtp = false;
    let resendTimer = null;

    function showSpinner() { $spinner.show(); }
    function hideSpinner() { $spinner.hide(); }

    function getFormData() {
        return {
            first_name: $('#firstname').val().trim(),
            last_name: $('#lastname').val().trim(),
            dob: $('#dob').val(),
            email: $('#standard_email_address').val().trim(),
            cell_phone: $('#cell_phone').val().trim(),
            current_password: $('#current_password').val(),
            password_confirmation: $('#password_confirmation').val(),
            address: $('#address').val().trim(),
            apt_suite: $('#apt_suite').val().trim(),
            state: $('#state').val(),
            zip: $('#zip').val().trim(),
            city: $('#city').val().trim(),
            country: $('#country').val(),
            timezone: $('#timezone').val(),
            hear_us: $('#hear_us').val()
        };
    }

    function validateForm(data) {
        $('.error-message').remove();
        let valid = true;
        const required = ['first_name', 'last_name', 'dob', 'email', 'cell_phone', 'current_password', 'password_confirmation', 'address', 'state', 'zip', 'city', 'country', 'timezone'];
        required.forEach(field => {
            if (!data[field]) {
                $(`#${field}`).after(`<p class="error-message text-yellow text-error">This field is required.</p>`);
                valid = false;

            }
        });

        if (data.current_password.length < 6) {
            $('#current_password').after(`<p class="error-message text-yellow text-error">Password must be at least 6 characters.</p>`);
            valid = false;
        }
        if (data.current_password !== data.password_confirmation) {
            $('#password_confirmation').after(`<p class="error-message text-yellow text-error">Passwords do not match.</p>`);
            valid = false;
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            $('#email').after(`<p class="error-message text-yellow text-error">Invalid email format.</p>`);
            valid = false;
        }
        if (!/^\d{4,6}$/.test(data.zip)) {
            $('#zip').after(`<p class="error-message text-yellow text-error">Invalid ZIP/postal code.</p>`);
            valid = false;
        }
        return valid;
    }

    function startResendTimer() {
        let countdown = 30;
        canResendOtp = false;
        updateActionButton("Verify OTP", verifyOtpHandler);
        const $timer = $('<div id="otp-timer" class="mt-2 text-muted">Resend available in 30s</div>');
        $otpContainer.append($timer);

        resendTimer = setInterval(() => {
            countdown--;
            $timer.text(`Resend available in ${countdown}s`);
            if (countdown <= 0) {
                clearInterval(resendTimer);
                canResendOtp = true;
                updateActionButton("Resend OTP", resendOtpHandler);
                $timer.text('');
            }
        }, 1000);
    }

    function updateActionButton(text, clickHandler) {
        $actionBtn
            .text(text)
            .off('click')
            .removeClass('disabled')
            .on('click', clickHandler);
    }


    $form.on('submit', function (e) {
        e.preventDefault(); // 🔒 prevent default HTML form submitzz
    });

    async function sendOtp(email, toName) {
        showSpinner();
        try {
            const res = await $.ajax({
                url: SITE_URL + 'api/users/send-otp',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ email, toName }),
                dataType: 'json'
            });

            if (res.success) {
                showNotification("OTP sent to your email.", 'success');

                $otpContainer.html(`
                    <div class="form-group mt-3">
                        <input type="text"
                               id="otp_code"
                               class="input-secondary text-center"
                               placeholder="Enter OTP"
                               maxlength="6"
                               inputmode="numeric"
                               pattern="[0-9]*"
                               autocomplete="off"
                               onkeypress="if(event.key.length === 1 && !/\\d/.test(event.key)) return false;"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,6);"
                        />
                    </div>
                `);


                startResendTimer();
            } else {
                showNotification(res.message || "OTP send failed.", 'error');
                updateActionButton("Register", registerStepOneHandler); // Reset state
            }
        } catch {
            showNotification("Failed to send OTP.", 'error');
            updateActionButton("Register", registerStepOneHandler); // Reset state
        } finally {
            hideSpinner();
        }
    }

    async function verifyOtpHandler() {
        const data = getFormData();
        const otp = $('#otp_code').val().trim();
        if (!otp || otp.length !== 6) {
            return showNotification("Enter a valid 6-digit OTP.", "error");
        }

        showSpinner();
        try {
            const res = await $.ajax({
                url: SITE_URL + 'api/users/verify-otp',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ email: data.email, otp }),
                dataType: 'json'
            });

            if (res.success) {
                otpVerified = true;
                clearInterval(resendTimer);
                showNotification("OTP verified successfully!", 'success');
                $otpContainer.html('<div class="text-success mt-3 font-weight-bold">OTP Verified.</div>');
                updateActionButton("Register Now", registerHandler);
            } else {
                showNotification(res.message || "Incorrect OTP.", 'error');
            }
        } catch {
            showNotification("Verification failed.", "error");
        } finally {
            hideSpinner();
        }
    }

    async function resendOtpHandler() {
        const data = getFormData();
        await sendOtp(data.email, `${data.first_name} ${data.last_name}`);
    }

    async function registerHandler() {
        const data = getFormData();
        showSpinner();
        try {
            const res = await $.ajax({
                url: SITE_URL + 'api/users/standard-seller/registration',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data),
                dataType: 'json'
            });

            if (res.success || res.status === 'success') {

                $form[0].reset();
                $otpContainer.empty();
                otpVerified = false;
                canResendOtp = false;
                updateActionButton("Register", registerStepOneHandler);

                showNotification("Registration complete!", 'success');

                const res2 = await $.ajax({
                    url: SITE_URL + 'api/users/send-welcome-email',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({ email: data.email, toName: `${data.first_name} ${data.last_name}` }),
                    dataType: 'json'
                });

                if (res2.success || res2.status === 'success') {

                    showNotification(res2.message, 'success');

                    const encodedEmail = encodeURIComponent(data.email);
                    window.location.href = SITE_URL + 'registration-success?email=' + encodedEmail;
                }

            } else {
                showNotification(res.message || "Registration failed.", "error");
            }
        } catch {
            showNotification("Registration error.", "error");
        } finally {
            hideSpinner();
        }
    }

    async function registerStepOneHandler() {
        const data = getFormData();
        if (!validateForm(data)) return;
        await sendOtp(data.email, `${data.first_name} ${data.last_name}`);
        updateActionButton("Verify OTP", verifyOtpHandler);
    }

    // Initialize
    updateActionButton("Register", registerStepOneHandler);

    // Input: allow only digits, no messages
    $(document).on('input', '#otp_code', function () {
        const clean = $(this).val().replace(/\D/g, '').slice(0, 6);
        $(this).val(clean);
    });

    // Paste: full validation with messages
    $(document).on('paste', '#otp_code', function (e) {
        const clipboardData = e.originalEvent.clipboardData || window.clipboardData;
        const pasted = clipboardData.getData('text');

        // Check length first
        if (pasted.length !== 6) {
            e.preventDefault();
            showNotification("OTP must be exactly 6 digits.", "error");
            return;
        }

        // Check if it's all digits
        if (!/^\d{6}$/.test(pasted)) {
            e.preventDefault();
            showNotification("OTP must contain only numeric digits (0-9).", "error");
            return;
        }

        // Valid OTP
        $('#otp_code').val(pasted);
        showNotification("OTP accepted", "success");
    });




    setDobField(18); // Set DOB field for 18+ age

});
