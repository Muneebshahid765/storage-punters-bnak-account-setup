function addAuctionToBid(auctionId, bidAmount) {
    // Ensure auction_id exists before making the AJAX request
    if (!auctionId) {
        console.error("Auction ID is missing.");
        return;
    }

    $.ajax({
        url: SITE_URL + "api/auctions/add_bid_to_auction", // Change this to your backend URL
        type: "POST",
        data: JSON.stringify({ auctionId: auctionId, bidAmount: bidAmount }), // Sending data as JSON
        contentType: "application/json",
        dataType: "json",
        beforeSend: function () {
        },
        success: function (response) {
            if (response.status === "success") {
                showNotification(response.message, "success");

                initialBid = bidAmount;
                let bidInput = $("input[name='highBid']");
                bidInput.val(`$${bidAmount.toFixed(2)}`);
                let auctionCurrentPriceContainer = $(".auction__current_price__section");
                auctionCurrentPriceContainer.text(bidAmount.toFixed(2));

                // ✅ Trigger cron job after bid success using sendBeacon
                const cronUrl = SITE_URL + "email/process-auction-outbid-by-id/" + auctionId;
                navigator.sendBeacon(cronUrl);

            } else {
                showNotification(response.message, "error");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            let errorMessage = "Something went wrong. Try again.";

            if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                errorMessage = jqXHR.responseJSON.message;
            }

            showNotification(errorMessage, "error");
        }
    });
}