let auctionId = window.location.pathname.split("/").pop(); // Extract Auction ID from URL
// Get the input field
let bidInput = 0;

$(document).ready(function () {
    checkUserLogin(); // Check if user is logged in first
});

// Function to check if the user is logged in
function checkUserLogin() {
    $.ajax({
        url: SITE_URL + "api/user/checkUserLogin", // Adjust API endpoint
        type: "GET",
        dataType: "json",
        success: function (response) {
            if (response.status === true && response.user_data.isLoggedIn) {
                isUserLoggedIn = true; // User is logged in
                hasRoleId = response.user_data.roleId;
            } else {
                isUserLoggedIn = false; // User is not logged in
            }

            fetchAuctionDetails(auctionId); // Proceed to fetch auction details after login check
        },
        error: function () {
            isUserLoggedIn = false; // Assume not logged in on error
            fetchAuctionDetails(auctionId); // Proceed anyway
        }
    });
}



// Function to format auction date
function formatAuctionDate(date, time) {
    if (!date || !time) return "N/A";

    let parsedDate = new Date(`${date} ${time}`);

    // Format options
    let options = { month: "short", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true };

    return parsedDate.toLocaleString("en-US", options);
}

// Fetch auction details from API
function fetchAuctionDetails(auctionId) {
    let auctionTitleContainer = $(".auction__title__section");
    let auctionContainer = $(".auction__details__section");
    let auctionDescriptionsContainer = $(".auction__descriptions__section");
    let auctionStartDateContainer = $(".auction__start_date_time__section");
    let auctionEndDateContainer = $(".auction__end_date_time__section");
    let auctionCurrentPriceContainer = $(".auction__current_price__section");
    let auctionTagsContainer = $(".auction__tags__section");
    let auctionCountDownForSmallDevicesContainer = $(".auction__count_down__section_for_small_devices");
    let auctionCountDownForLargeDevicesContainer = $(".auction__count_down__section_for_large_devices");
    let auctionTotalViewsContainer = $(".auction__total_views__section");
    let userDynamicSectionContainer = $(".user-dynamic-section");
    let logginToBidContainer = $(".loggin-to-bid");

    // Show Skeleton Loader
    appendSkeletonLoader(auctionContainer);

    $.ajax({
        url: SITE_URL + "api/auctions/getAuctionById",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({ auctionId: auctionId, mode: "view" }),
        success: function (response) {
            $(".skeleton-loader").remove(); // Remove Skeleton Loader

            if (response.status === "success" && response.data) {
                let auction = response.data[0];
                let userData = response.user_data;
                // Get the initial bid amount directly from the auction variable
                initialBid = parseFloat(auction.auction_max_bid_amount.toString().replace(/[^0-9.]/g, "")) || 0;
                let isAuctionFavorite = userData.is_favorite;

                // Update Auction Details in UI
                let auctionHtml = `
                    <div class="h-100 w-100 ps-1 ps-md-5">
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Current Price:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">$${auction.auction_max_bid_amount}</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Unit Size:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">${auction.auction_unit_size}</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Facility:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">
                                    <div class="d-flex flex-wrap "><span>${auction.auction_storage_facility_name}</span><a class="ms-1 d-flex justify-content-start align-items-center" style="font-size: 13px; color: var(--border-active); cursor: pointer; text-decoration: none;" href="${SITE_URL + "auctions/" + auction.auction_id}"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M946.5 505L560.1 118.8l-25.9-25.9a31.5 31.5 0 0 0-44.4 0L77.5 505a63.9 63.9 0 0 0-18.8 46c.4 35.2 29.7 63.3 64.9 63.3h42.5V940h691.8V614.3h43.4c17.1 0 33.2-6.7 45.3-18.8a63.6 63.6 0 0 0 18.7-45.3c0-17-6.7-33.1-18.8-45.2zM568 868H456V664h112v204zm217.9-325.7V868H632V640c0-22.1-17.9-40-40-40H432c-22.1 0-40 17.9-40 40v228H238.1V542.3h-96l370-369.7 23.1 23.1L882 542.3h-96.1z"></path>
                                            </svg>View Facility Page</a></div>
                                    </p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Location:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">${auction.auction_storage_facility_city}, ${auction.auction_storage_facility_state}</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Starting Bid:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">$${auction.auction_start_bid_amount}</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Type:</p>
                                    <p class=" text-grey title__detail__auction d-flex" style="margin-top:0;margin-bottom:0.5rem">${auction.auction_category_name}</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <p class="mb-0 text-grey title__detail__auction" style="font-weight:bold">Seller Accepts:</p><span class="px-2 py-1" style="background-color:#41fff3;border-radius:32px;width:max-content">Credit/Debit Card</span>
                                </div>
                            </div>
                `;

                auctionContainer.html(auctionHtml); // Replace content with auction details


                let auctionCountDownForSmallDevicesHtml = `

                 <div class="d-flex px-0 justify-content-center flex-column align-items-center ps-md-0 ">
                            <div class="__timing__box__ __Days days-${auction.auction_id}"  style="visibility: visible;">--</div>
                            <p class="text-center mt-2 ">Days</p>
                        </div>
                        <div class="d-flex justify-content-center flex-column align-items-center">
                            <div class="__timing__box__ __Hours hours-${auction.auction_id}" style="visibility: visible;">--</div>
                            <p class="text-center mt-2 ">Hours</p>
                        </div>
                        <div class="d-flex justify-content-center flex-column align-items-center ">
                            <div class="__timing__box__ __Minutes minutes-${auction.auction_id}" style="visibility: visible;">--</div>
                            <p class="text-center mt-2 ">Mins</p>
                        </div>
                        <div class="d-flex justify-content-center flex-column align-items-center ">
                            <div class="__timing__box__ __Seconds seconds-${auction.auction_id}" style="visibility: visible;">--</div>
                            <p class="text-center mt-2 ">Secs</p>
                        </div>
                `;

                auctionCountDownForSmallDevicesContainer.html(auctionCountDownForSmallDevicesHtml); // Replace content with auction details


                let auctionCountDownForLargeDevicesHtml = `

                  <div class="ps-0  col-3">
                                <div class="__timing__box__ __Days days-${auction.auction_id}"  style="visibility: visible;">--</div>
                                <p class="text-center mt-2 ">Days</p>
                            </div>
                            <div class="col-3">
                                <div class="__timing__box__ __Hours hours-${auction.auction_id}" style="visibility: visible;">--</div>
                                <p class="text-center mt-2 ">Hours</p>
                            </div>
                            <div class="col-3">
                                <div class="__timing__box__ __Minutes minutes-${auction.auction_id}" style="visibility: visible;">--</div>
                                <p class="text-center mt-2 ">Minutes</p>
                            </div>
                            <div class="col-3">
                                <div class="__timing__box__ __Seconds seconds-${auction.auction_id}" style="visibility: visible;">--</div>
                                <p class="text-center mt-2 ">Seconds</p>
                            </div>
               `;

                auctionCountDownForLargeDevicesContainer.html(auctionCountDownForLargeDevicesHtml); // Replace content with auction details


                let userDynamicSectionHtml = "";


                if (isUserLoggedIn == false) {
                    userDynamicSectionHtml = `<p class="text-center w-100 p-3 border-warning-subtle mt-0 mt-md-3 bg-warning-subtle ">You must be logged in to bid</p>`;

                    logginToBidContainer.addClass("w-100");

                } else {

                    if (hasRoleId != 2) {

                        userDynamicSectionHtml = `
                        <div class="alert alert-warning text-center w-100 p-3 mt-0 mt-md-3">
                            <strong>Access Denied:</strong> You do not have permission to place bids on this auction due to your account role.
                        </div>
                    `;

                        logginToBidContainer.addClass("w-100");

                    } else {
                        if (isAuctionFavorite == false) {

                            userDynamicSectionHtml = `

                   <form>
                        <div class="d-flex justify-content-start align-items-center flex-column flex-md-row gap-2 flex-wrap">
                            <div class="d-flex align-items-center gap-3">
                                <span class="d-inline-block me-auto">
                                    <div class="me-auto d-flex justify-content-centent align-items-center bid__input__container">
                                        <div class="me-auto ">
                                        <input class="bid__input bid__amount me-auto ps-5 text-200 fs-5" type="text"
                                                name="highBid" inputclassnames="text-300" required="" value="$${auction.auction_max_bid_amount}"
                                                data-gtm-form-interact-field-id="0" error="add bid amount">
                                        </div>
                                        <div class="d-flex flex-column bid__btn_container">
                                                <button type="button" class="bid__input__btn btn__add_amount" style="background: var(--color-high-bid);">+10</button>

                                                <button type="button" class="bid__input__btn btn__subtract_amount" style="background-color: var(--color-high-bid); color: rgb(0, 0, 0);">-10</button>
                                        </div>
                                    </div>
                                </span>
                                <button type="button" style="border: medium; background: var(--color-high-bid);"
                                    class="me-auto responsive-btn p-3 p-md-2 d-block btn btn-primary btn-place-bid">Bid Now!
                                </button>
                            </div>
                            <div class="d-flex gap-3 flex-row-reverse align-items-center">
                                <button type="button"
                                    class="d-flex justify-content-left justify-content-md-center align-items-center gap-1 me-auto bg-transparent text-dark border-0 responsive-btn p-1 p-md-2 btn btn-primary">
                                    <span class="d-flex align-items-center"></span>
                                    <span style="border-bottom: 1px solid black;">
                                    </span>
                                </button>
                                <div>
                                    <div class="watchlist d-flex align-items-center" style="width: max-content;">
                                        <button type="button" style="border: 2px solid black;"
                                            class="btn-add-to-watch-list bg-transparent text-dark d-flex align-items-center gap-1 responsive-btn p-1 p-md-2 btn btn-primary"
                                            <span class="d-flex align-items-center">
                                                <span
                                                    style="box-sizing: border-box; display: inline-block; overflow: hidden; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px; position: relative; max-width: 100%;">
                                                    <span
                                                        style="box-sizing: border-box; display: block; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px; max-width: 100%;">
                                                        <img style="display: block; max-width: 100%; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px;"
                                                            alt="" aria-hidden="true"
                                                            src="data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%2720%27%20height=%2720%27/%3e">
                                                    </span>
                                                    <img alt="watch_list"
                                                        src="${SITE_URL + "assets/images/auction_details/watchlist.svg"}" decoding="async"
                                                        data-nimg="intrinsic"
                                                        style="position: absolute; inset: 0px; box-sizing: border-box; padding: 0px; border: medium; margin: auto; display: block; width: 0px; height: 0px; min-width: 100%; max-width: 100%; min-height: 100%; max-height: 100%;">
                                                </span>
                                            </span>
                                            <span class="d-flex align-items-center btn-text-watch-list">Add to Watch List
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                        `;

                        } else if (isAuctionFavorite == true) {

                            userDynamicSectionHtml = `

                     <form>
                        <div class="d-flex justify-content-start align-items-center flex-column flex-md-row gap-2 flex-wrap">
                            <div class="d-flex align-items-center gap-3">
                                <span class="d-inline-block me-auto">
                                    <div class="me-auto d-flex justify-content-centent align-items-center bid__input__container">
                                        <div class="me-auto ">
                                        <input class="bid__input bid__amount me-auto ps-5 text-200 fs-5" type="text"
                                                name="highBid" inputclassnames="text-300" required="" value="$${auction.auction_max_bid_amount}"
                                                data-gtm-form-interact-field-id="0" error="add bid amount">
                                        </div>
                                        <div class="d-flex flex-column bid__btn_container">
                                                <button type="button" class="bid__input__btn btn__add_amount" style="background: var(--color-high-bid);">+10</button>

                                                <button type="button" class="bid__input__btn btn__subtract_amount" style="background-color: var(--color-high-bid); color: rgb(0, 0, 0);">-10</button>
                                        </div>
                                    </div>
                                </span>
                                <button type="button" style="border: medium; background: var(--color-high-bid);"
                                    class="me-auto responsive-btn p-3 p-md-2 d-block btn btn-primary btn-place-bid">Bid Now!
                                </button>
                            </div>
                            <div class="d-flex gap-3 flex-row-reverse align-items-center">
                                <button type="button"
                                    class="d-flex justify-content-left justify-content-md-center align-items-center gap-1 me-auto bg-transparent text-dark border-0 responsive-btn p-1 p-md-2 btn btn-primary">
                                    <span class="d-flex align-items-center"></span>
                                    <span style="border-bottom: 1px solid black;">
                                    </span>
                                </button>
                                <div>
                                    <div class="watchlist d-flex align-items-center" style="width: max-content;">
                                        <button type="button" style="border: 2px solid black;"
                                            class="btn-remove-from-watch-list bg-transparent text-dark d-flex align-items-center gap-1 responsive-btn p-1 p-md-2 btn btn-primary"
                                            <span class="d-flex align-items-center">
                                                <span
                                                    style="box-sizing: border-box; display: inline-block; overflow: hidden; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px; position: relative; max-width: 100%;">
                                                    <span
                                                        style="box-sizing: border-box; display: block; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px; max-width: 100%;">
                                                        <img style="display: block; max-width: 100%; width: initial; height: initial; background: none; opacity: 1; border: 0px; margin: 0px; padding: 0px;"
                                                            alt="" aria-hidden="true"
                                                            src="data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%2720%27%20height=%2720%27/%3e">
                                                    </span>
                                                    <img alt="watch_list"
                                                        src="${SITE_URL + "assets/images/auction_details/watchlist.svg"}" decoding="async"
                                                        data-nimg="intrinsic"
                                                        style="position: absolute; inset: 0px; box-sizing: border-box; padding: 0px; border: medium; margin: auto; display: block; width: 0px; height: 0px; min-width: 100%; max-width: 100%; min-height: 100%; max-height: 100%;">
                                                </span>
                                            </span>
                                            <span class="d-flex align-items-center btn-text-watch-list">Remove From Watch List
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                        `;
                        }
                    }


                }

                if (isUserLoggedIn == false) {
                    logginToBidContainer.html(userDynamicSectionHtml); // Replace content with auction detail
                } else {
                    if (hasRoleId != 2) {

                        logginToBidContainer.html(userDynamicSectionHtml); // Replace content with auction detail
                    } else {
                        userDynamicSectionContainer.html(userDynamicSectionHtml); // Replace content with auction detail
                    }
                }

                let bidInput = $("input[name='highBid']");


                function getBidAmount() {
                    return parseFloat(bidInput.val().replace(/[^0-9.]/g, "")) || 0;
                }

                // Increase bid by 10 and format to 2 decimal places
                $(".btn__add_amount").click(function () {
                    let newBid = getBidAmount() + 10;
                    bidInput.val(`$${newBid.toFixed(2)}`); // Format to 2 decimal places
                });

                // Decrease bid by 10 but never below the initial bid amount
                $(".btn__subtract_amount").click(function () {
                    let newBid = getBidAmount() - 10;
                    if (newBid < initialBid) newBid = initialBid; // Prevent going below initial value
                    bidInput.val(`$${newBid.toFixed(2)}`); // Format to 2 decimal places
                });

                // Validate input field on change (Only allow whole numbers and check min value)
                bidInput.on("change", function () {
                    let value = getBidAmount();

                    // If input is not a valid number or below initial bid, reset to initial bid
                    if (isNaN(value) || value < initialBid) {
                        bidInput.val(`$${initialBid.toFixed(2)}`);
                    } else {
                        bidInput.val(`$${value.toFixed(2)}`);
                    }
                });

                // When input is clicked, clear the text
                bidInput.on("focus", function () {
                    $(this).val(""); // Remove existing text
                });

                $(document).on("click", ".btn-add-to-watch-list", function () {
                    $(this).removeClass("btn-add-to-watch-list").addClass("btn-remove-from-watch-list");
                    $(this).find(".btn-text-watch-list").text("Remove from Watch List");
                    addToWatchList(auctionId);
                });

                $(document).on("click", ".btn-remove-from-watch-list", function () {
                    $(this).removeClass("btn-remove-from-watch-list").addClass("btn-add-to-watch-list");
                    $(this).find(".btn-text-watch-list").text("Add to Watch List");
                    addToWatchList(auctionId);
                });


                $(".btn-place-bid").click(function () {
                    let bidAmount = parseFloat($("input[name='highBid']").val().replace(/[^0-9.]/g, "")) || 0;
                    addAuctionToBid(auctionId, bidAmount);

                });

                // When user leaves the input field, validate the entry
                bidInput.on("blur", function () {
                    let value = getBidAmount();

                    // If input is empty or invalid, reset to initial bid value
                    if (isNaN(value) || value < initialBid) {
                        $(this).val(`$${initialBid.toFixed(2)}`);
                    } else {
                        $(this).val(`$${value.toFixed(2)}`);
                    }
                });

                // Restrict input to only whole numbers (No decimals, No special characters)
                bidInput.on("keypress", function (e) {
                    let charCode = e.which ? e.which : e.keyCode;

                    // Allow only numbers and backspace
                    if (charCode < 48 || charCode > 57) { // ASCII codes for 0-9
                        e.preventDefault();
                    }
                });

                // Format Start Date & Time
                let formattedStartDate = formatAuctionDate(auction.auction_start_date, auction.auction_start_time);
                let formattedEndDate = formatAuctionDate(auction.auction_end_date, auction.auction_end_time);

                // Set Text in UI
                auctionStartDateContainer.text(formattedStartDate);
                auctionEndDateContainer.text(formattedEndDate);

                // Set Auction Description
                auctionTitleContainer.text(auction.auction_storage_facility_name + " Auction # " + auction.auction_id);
                auctionDescriptionsContainer.text(auction.auction_description || "No description available.");
                auctionCurrentPriceContainer.text(auction.auction_max_bid_amount);
                auctionTotalViewsContainer.text(auction.auction_total_views);

                // Process Tags from String to Array
                if (auction.auction_tags && auction.auction_tags.trim() !== "") {
                    let tagsArray = auction.auction_tags.split(",").map(tag => tag.trim()); // Split and trim spaces

                    let tagsHtml = tagsArray
                        .map(
                            (tag) => `
                                <a href="#" style="text-decoration: none;">
                                    <div style="font-weight: 200;" class="px-md-4 px-2 py-2 tags">${tag}</div>
                                </a>
                            `
                        )
                        .join(""); // Join all tags into a single string
                    auctionTagsContainer.html(tagsHtml);
                } else {
                    auctionTagsContainer.html('<p class="text-center text-muted">No tags available.</p>');
                }

                // Start the countdown timer
                startCountdown(auction.auction_id, auction.auction_end_date, auction.auction_end_time, auction.auction_storage_facility_timezone);

                showNotification(response.message, "success");
            } else {
                auctionContainer.html(`<p class="text-center text-danger">No auction details found.</p>`);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $(".skeleton-loader").remove();
            auctionContainer.html(`<p class="text-center text-danger">Failed to load auction details.</p>`);

            let errorMessage = "Something went wrong. Try again.";

            if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                errorMessage = jqXHR.responseJSON.message;
            }

            showNotification(errorMessage, "error");
        }
    });
}

// Append Skeleton Loader (Matching HTML Structure)
function appendSkeletonLoader(container) {
    let skeletonHtml = `
        <div class="skeleton-loader w-100">
            <h2 class="skeleton skeleton-heading mb-md-4"></h2>
            <div class="h-100 w-100 ps-1 ps-md-5">
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
                <div class="d-flex gap-2">
                    <p class="skeleton skeleton-text"></p>
                    <p class="skeleton skeleton-text"></p>
                </div>
            </div>
        </div>
    `;
    container.html(skeletonHtml);
}

// Countdown Timer for auction end time
function startCountdown2(auctionId, auctionEndDate, auctionEndTime, auctionTimezone) {
    try {
        new Intl.DateTimeFormat("en-US", { timeZone: auctionTimezone });
    } catch (error) {
        auctionTimezone = "UTC"; // Default to UTC if invalid timezone
    }

    function updateTimer() {
        const now = new Date(new Date().toLocaleString("en-US", { timeZone: auctionTimezone }));
        /*const endTime = new Date(`${auctionEndDate}T23:59:59`);
        const timeDiff = endTime - now;*/

        // Combine date and time, and parse in local timezone first
        const endDateTimeStr = `${auctionEndDate} ${auctionEndTime}`;
        const localEndTime = new Date(new Date(endDateTimeStr).toLocaleString("en-US", { timeZone: auctionTimezone }));

        const timeDiff = localEndTime - now;

        if (timeDiff <= 0) {
            $(`.days-${auctionId}`).text("0");
            $(`.hours-${auctionId}`).text("0");
            $(`.minutes-${auctionId}`).text("0");
            $(`.seconds-${auctionId}`).text("0");
            return;
        }

        let days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        let hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

        $(`.days-${auctionId}`).text(days);
        $(`.hours-${auctionId}`).text(hours);
        $(`.minutes-${auctionId}`).text(minutes);
        $(`.seconds-${auctionId}`).text(seconds);
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}

function startCountdown(auctionId, auctionEndDate, auctionEndTime, auctionTimezone) {
    const { DateTime } = luxon;

    // Combine date and time and interpret it in the given timezone
    const endDateTime = DateTime.fromFormat(
        `${auctionEndDate} ${auctionEndTime}`,
        "yyyy-MM-dd hh:mm a",
        { zone: auctionTimezone }
    );

    function updateTimer() {
        const now = DateTime.now().setZone(auctionTimezone);
        const diff = endDateTime.diff(now, ["days", "hours", "minutes", "seconds"]);

        if (diff.toMillis() <= 0) {
            $(`.days-${auctionId}`).text("0");
            $(`.hours-${auctionId}`).text("0");
            $(`.minutes-${auctionId}`).text("0");
            $(`.seconds-${auctionId}`).text("0");
            return;
        }

        $(`.days-${auctionId}`).text(Math.floor(diff.days));
        $(`.hours-${auctionId}`).text(Math.floor(diff.hours));
        $(`.minutes-${auctionId}`).text(Math.floor(diff.minutes));
        $(`.seconds-${auctionId}`).text(Math.floor(diff.seconds));
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}
