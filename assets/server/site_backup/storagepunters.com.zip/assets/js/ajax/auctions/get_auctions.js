// Global settings
// Global auction data storage
let allAuctions = [];
let currentPage = 1;
const pageSize = 16;

function fetchAuctions(limit) {
    $(".feature__live__section__container__grid").html(""); // Clear existing content
    let loaderHtml = `
    <div id="auction-loader" class="d-flex justify-content-center align-items-center w-100 my-4">
        <div class="spinner-border text-success" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
`;
    $(".feature__live__section__container__grid").append(loaderHtml);

    $.ajax({
        url: SITE_URL + "api/auctions/getTopThreeAuctions",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({ limit: limit }),
        success: function (response) {
            $("#auction-loader").remove();

            if (response.status === "success" && response.data.length > 0) {
                loadAuctionSequentially(response.data, 0); // Start loading one by one
            } else {
                $(".feature__live__section__container__grid").html(`
                    <div class=" bidding__cards__container  container">
                        <div style="border-radius: 15px;" class="bg-white mx-2 flex-wrap justify-content-center px-3 mt-3 row text-center py-4">
                            <div class="bid_card  border-0 px-1 col-lg-3 col-md-4 col-sm-6 col-10">
                                <div class="bid__card__wrapper">
                                    <div class="bid_card_img mb-3">
                                        <i class="bi bi-hourglass-split display-4 text-warning" style="z-index: 999 !important;"></i>
                                    </div>
                                    <h2 class="bid_card_title">No Auctions Live</h2>
                                    <p>There are currently no active auctions.<br>Check back soon or enable notifications to stay updated.</p>
                                </div>
                                <div class="bid_card_active"></div>
                            </div>
                        </div>
                    </div>
                `);


            }
        },
        error: function () {

            $("#auction-loader").remove();

            $(".feature__live__section__container__grid").html(`
                <div class=" bidding__cards__container  container">
                    <div style="border-radius: 15px;" class="bg-white mx-2 flex-wrap justify-content-center px-3 mt-3 row text-center py-4">
                        <div class="bid_card  border-0 px-1 col-lg-3 col-md-4 col-sm-6 col-10">
                            <div class="bid__card__wrapper">
                                <div class="bid_card_img mb-3">
                                    <i class="bi bi-hourglass-split display-4 text-warning" style="z-index: 999 !important;"></i>
                                </div>
                                <h2 class="bid_card_title">No Auctions Live</h2>
                                <p>There are currently no active auctions.<br>Check back soon or enable notifications to stay updated.</p>
                            </div>
                            <div class="bid_card_active"></div>
                        </div>
                    </div>
                </div>
            `);
        }
    });
}


function fetchAllAuctions(start = 0, end = 16, activePage = 1) {
    $(".auction__all__live__section__container__grid").html("");

    let loaderHtml = `
        <div id="auction-loader" class="d-flex justify-content-center align-items-center w-100 my-4">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;

    $(".auction__all__live__section__container__grid").append(loaderHtml);

    $.ajax({
        url: SITE_URL + "api/auctions/getAllAuctions",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({ start: start, end: end }),
        success: function (response) {
            $("#auction-loader").remove();

            if (response.status === "success" && response.data.length > 0) {
                loadAllAuctionSequentially(response.data, 0);
                const totalCount = response.totalCount || response.data.length; // Correct total
                renderPaginationFrontend(totalCount, activePage);
            } else {

                $(".auction__all__live__section__container__grid").html(`
                    <div class=" bidding__cards__container  container mb-3" style="max-width: 100% !important;">
                        <div style="border-radius: 15px;" class="bg-white mx-2 flex-wrap justify-content-center px-3 mt-3 row text-center py-4">
                            <div class="bid_card  border-0 px-1 col-lg-3 col-md-4 col-sm-6 col-10">
                                <div class="bid__card__wrapper">
                                    <div class="bid_card_img mb-3">
                                        <i class="bi bi-hourglass-split display-4 text-warning" style="z-index: 999 !important;"></i>
                                    </div>
                                    <h2 class="bid_card_title">No Auctions Live</h2>
                                    <p>There are currently no active auctions.<br>Check back soon or enable notifications to stay updated.</p>
                                </div>
                                <div class="bid_card_active"></div>
                            </div>
                        </div>
                    </div>
                `);


                $(".paginate-container").hide();
            }
        },
        error: function () {
            $("#auction-loader").remove();
            $(".auction__all__live__section__container__grid").html(`
                    <div class=" bidding__cards__container  container  mb-3" style="max-width: 100% !important;">
                        <div style="border-radius: 15px;" class="bg-white mx-2 flex-wrap justify-content-center px-3 mt-3 row text-center py-4">
                            <div class="bid_card  border-0 px-1 col-lg-3 col-md-4 col-sm-6 col-10">
                                <div class="bid__card__wrapper">
                                    <div class="bid_card_img mb-3">
                                        <i class="bi bi-hourglass-split display-4 text-warning" style="z-index: 999 !important;"></i>
                                    </div>
                                    <h2 class="bid_card_title">No Auctions Live</h2>
                                    <p>There are currently no active auctions.<br>Check back soon or enable notifications to stay updated.</p>
                                </div>
                                <div class="bid_card_active"></div>
                            </div>
                        </div>
                    </div>
                `);
        }
    });
}

function renderPaginationFrontend(totalCount, activePage) {
    const totalPages = Math.ceil(totalCount / pageSize);
    /*if (totalPages <= 1) {
        $(".paginate-container").hide();
        return;
    }*/

    let paginationHtml = `<ul class="container" role="navigation" aria-label="Pagination">`;

    // Previous Button
    paginationHtml += `<li class="previous ${activePage === 1 ? 'disabled' : ''}">
        <a class="page" data-page="${activePage - 1}" ${activePage === 1 ? 'aria-disabled="true"' : ''}>
            <svg stroke="currentColor" fill="currentColor" viewBox="0 0 24 24" height="1em" width="1em">
                <polygon fill="none" stroke="#000" stroke-width="2" points="6 2 18 12 6 22" transform="matrix(-1 0 0 1 24 0)"></polygon>
            </svg>
        </a>
    </li>`;

    // Page Numbers
    for (let i = 1; i <= totalPages; i++) {
        paginationHtml += `<li class="page ${i === activePage ? 'active1' : ''}">
            <a role="button" class="page-link" data-page="${i}">${i}</a>
        </li>`;
    }

    // Next Button
    paginationHtml += `<li class="next ${activePage === totalPages ? 'disabled' : ''}">
        <a class="page" data-page="${activePage + 1}" ${activePage === totalPages ? 'aria-disabled="true"' : ''}>
            <svg stroke="currentColor" fill="currentColor" viewBox="0 0 24 24" height="1em" width="1em">
                <polygon fill="none" stroke="#000" stroke-width="2" points="6 2 18 12 6 22"></polygon>
            </svg>
        </a>
    </li>`;

    paginationHtml += `</ul>`;
    $(".paginate-container").html(paginationHtml).show();
}


$(document).on("click", ".paginate-container .page a", function () {
    const page = parseInt($(this).data("page"));
    if (isNaN(page) || page < 1) return;

    const start = (page - 1) * pageSize;
    const end = start + pageSize;

    currentPage = page;
    fetchAllAuctions(start, end, page);
});


// Function to load auctions sequentially (one by one)
function loadAuctionSequentially(auctions, index) {
    if (index >= auctions.length) return; // Stop if all auctions are loaded

    appendSkeletonLoader(); // Show skeleton

    setTimeout(() => {
        $(".feature__live__section__container__grid").find(".skeleton-loader").first().remove(); // Remove skeleton
        appendAuctionCard(auctions[index]); // Append auction card
        loadAuctionSequentially(auctions, index + 1); // Load next auction
    }, 900); // Delay for smooth transition


}

// Function to load auctions sequentially (one by one)
function loadAllAuctionSequentially(auctions, index) {
    if (index >= auctions.length) return; // Stop if all auctions are loaded

    appendAllSkeletonLoader(); // Show skeleton

    setTimeout(() => {
        $(".auction__all__live__section__container__grid").find(".skeleton-loader").first().remove(); // Remove skeleton
        appendAllAuctionCard(auctions[index]); // Append auction card
        loadAllAuctionSequentially(auctions, index + 1); // Load next auction
    }, 450); // Delay for smooth transition


}


// Append skeleton loader (matching the auction card layout)
function appendSkeletonLoader() {
    let skeletonHtml = `
        <div class="mb-4 col-lg-3 col-md-4 skeleton-loader">
            <div class="bidding__card__grid">
                <!-- Skeleton for Image -->
                <div class="skeleton image"></div>

                <!-- Skeleton for Auction Number -->
                <div class="skeleton text auction-number"></div>

                <div class="d-flex card__info__container flex-column w-100">
                    <div class="card__info">
                        <table class="table table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3">
                            <thead>
                                <tr class="p-0">
                                    <th scope="col">
                                        <div class="text-center text-xs text-light-black font-semibold"></div>
                                    </th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-primary-dark">
                                        <div class="skeleton text high-bid"></div>
                                    </td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Skeleton for Storage Facility Name -->
                        <div class="skeleton text storage-name"></div>

                        <!-- Skeleton for Address -->
                        <div class="skeleton text address"></div>
                        <div class="skeleton text address"></div>
                    </div>

                    <div class="bidding__card__button__section">
                        <!-- Skeleton for Button -->
                        <div class="skeleton button"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    $(".feature__live__section__container__grid").append(skeletonHtml);
}

// Append skeleton loader (matching the auction card layout)
function appendAllSkeletonLoader() {
    let skeletonHtml = `
        <div class="mb-4 col-lg-3 col-md-4 skeleton-loader">
            <div class="bidding__card__grid">
                <!-- Skeleton for Image -->
                <div class="skeleton image"></div>

                <!-- Skeleton for Auction Number -->
                <div class="skeleton text auction-number"></div>

                <div class="d-flex card__info__container flex-column w-100">
                    <div class="card__info">
                        <table class="table table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3">
                            <thead>
                                <tr class="p-0">
                                    <th scope="col">
                                        <div class="text-center text-xs text-light-black font-semibold"></div>
                                    </th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                    <th scope="col"><div class="skeleton small-box"></div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-primary-dark">
                                        <div class="skeleton text high-bid"></div>
                                    </td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                    <td><div class="skeleton small-box"></div></td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Skeleton for Storage Facility Name -->
                        <div class="skeleton text storage-name"></div>

                        <!-- Skeleton for Address -->
                        <div class="skeleton text address"></div>
                        <div class="skeleton text address"></div>
                    </div>

                    <div class="bidding__card__button__section">
                        <!-- Skeleton for Button -->
                        <div class="skeleton button"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    $(".auction__all__live__section__container__grid").append(skeletonHtml);
}


// Append auction card with smooth fade-in
function appendAuctionCard(auction) {
    let auctionStartDate = auction.auction_start_date;
    let auctionEndDate = auction.auction_end_date;
    let auctionEndTime = auction.auction_end_time;
    let auctionTimezone = auction.auction_storage_facility_timezone || "UTC";

    let defaultImage = SITE_URL + "assets/images/logo1.jpeg";
    let images = auction.auction_cover_images && auction.auction_cover_images.length
        ? auction.auction_cover_images
        : [defaultImage];

    let swiperSlides = images.map((img, index) => {
        let imagePath = typeof img === 'string' ? img : img.path;
        return `
                <div class="swiper-slide">
                    <a data-fancybox="gallery-${auction.auction_id}" href="${imagePath}">
                        <img style="cursor: pointer;" src="${imagePath}" alt="Auction ${auction.auction_id} Image ${index}" height="246" width="200">
                    </a>
                </div>
            `;
    }).join("");



    let auctionHtml = `
        <div class="mb-4 col-lg-3 col-md-4 fade-in">
            <div class="bidding__card__grid">

            <div class="swiper-container swiper-auction-${auction.auction_id}">
                <div class="swiper-wrapper">
                    ${swiperSlides}
                </div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>

                <h2 class="__auction__number __auction__number__bg" style="font-weight: 500;">Auction #${auction.auction_id}</h2>
                <div class="d-flex card__info__container flex-column w-100">
                    <div class="card__info">
                        <table class="table table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3">
                            <thead>
                                <tr class="p-0">
                                    <th scope="col">
                                        <div class="text-center text-xs text-light-black font-semibold"> High Bid:</div>
                                    </th>
                                    <th scope="col"><div id="days-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="hours-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="minutes-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="seconds-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-primary-dark">
                                        <div class="text-center high-bid-font font-semibold">$${auction.auction_max_bid_amount}</div>
                                    </td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Day</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Hour</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Min</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Sec</div></td>
                                </tr>
                            </tbody>
                        </table>
                        <h3 class="false text-center" style="font-size: 20px; font-weight: bold;">${auction.auction_storage_facility_name}</h3>
                        <p class="text-light-black text-100 mb-1 d-flex align-items-center justify-content-center" style="font-size: 15px; font-weight: 500;">${auction.auction_storage_facility_street_address}</p>
                        <p class="text-light-black text-100 mb-md-3 mb-2 d-flex align-items-center justify-content-center" style="font-size: 15px; font-weight: 500;">${auction.auction_storage_facility_city}, ${auction.auction_storage_facility_state}</p>
                    </div>
                    <div class="bidding__card__button__section">
                                        <a href="${SITE_URL + "auctions/" + auction.auction_id}" target="_blank" rel="noopener noreferrer" style="text-decoration: none;">
                                            <button type="button" style="height: 44px; min-width: max-content; width: max-content;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  mx-auto mb-3 text-100 outline-light-btn btn btn-primary">View Auction
                                                <div class="ms-2 " style="color: inherit;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15.294" height="14.907" viewBox="0 0 15.294 14.907">
                                                        <path id="Icon_awesome-arrow-right" d="M6.5,3.646l.758-.758a.816.816,0,0,1,1.157,0L15.053,9.52a.816.816,0,0,1,0,1.157L8.418,17.313a.816.816,0,0,1-1.157,0L6.5,16.555a.82.82,0,0,1,.014-1.171l4.113-3.919H.819A.817.817,0,0,1,0,10.647V9.554a.817.817,0,0,1,.819-.819h9.81L6.516,4.817A.814.814,0,0,1,6.5,3.646Z" transform="translate(0 -2.647)" fill="inherit"></path>
                                                    </svg>
                                                </div>
                                            </button>
                                        </a>
                    </div>
                </div>
            </div>
        </div>
    `;

    $(".feature__live__section__container__grid").append(auctionHtml);


    new Swiper(`.swiper-auction-${auction.auction_id}`, {
        slidesPerView: 1,
        loop: true,
        pagination: {
            el: `.swiper-auction-${auction.auction_id} .swiper-pagination`,
            clickable: true
        },
        navigation: {
            nextEl: `.swiper-auction-${auction.auction_id} .swiper-button-next`,
            prevEl: `.swiper-auction-${auction.auction_id} .swiper-button-prev`
        }
    });

    // Start countdown for this auction
    startCountdown(auction.auction_id, auctionEndDate, auctionEndTime, auctionTimezone);
}

// Append auction card with smooth fade-in
function appendAllAuctionCard(auction) {
    let auctionStartDate = auction.auction_start_date;
    let auctionEndDate = auction.auction_end_date;
    let auctionEndTime = auction.auction_end_time;
    let auctionTimezone = auction.auction_storage_facility_timezone || "UTC";

    let defaultImage = SITE_URL + "assets/images/logo1.jpeg";
    let images = auction.auction_cover_images && auction.auction_cover_images.length
        ? auction.auction_cover_images
        : [defaultImage];

    let swiperSlides = images.map((img, index) => {
        let imagePath = typeof img === 'string' ? img : img.path;
        return `
                    <div class="swiper-slide">
                        <a data-fancybox="gallery-${auction.auction_id}" href="${imagePath}">
                            <img style="cursor: pointer;" src="${imagePath}" alt="Auction ${auction.auction_id} Image ${index}" height="246" width="200">
                        </a>
                    </div>
                `;
    }).join("");



    let auctionHtml = `
        <div class="mb-4 col-lg-3 col-md-4 fade-in">
            <div class="bidding__card__grid">

            <div class="swiper-container swiper-auction-${auction.auction_id}">
                <div class="swiper-wrapper">
                    ${swiperSlides}
                </div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>

                <div class="d-flex card__info__container flex-column w-100">
                    <div class="card__info">
                        <table class="table table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3">
                            <thead>
                                <tr class="p-0">
                                    <th scope="col">
                                        <div class="text-center text-xs text-light-black font-semibold"> High Bid:</div>
                                    </th>
                                    <th scope="col"><div id="days-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="hours-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="minutes-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                    <th scope="col"><div id="seconds-${auction.auction_id}" class="text-center text-300 font-semibold">--</div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-primary-dark">
                                        <div class="text-center high-bid-font font-semibold">$${auction.auction_max_bid_amount}</div>
                                    </td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Day</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Hour</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Min</div></td>
                                    <td><div class="text-center text-17 font-semibold text-muted-dark text-light-black">Sec</div></td>
                                </tr>
                            </tbody>
                        </table>
                        <h3 class="false text-center" style="font-size: 20px; font-weight: bold;">${auction.auction_storage_facility_name}</h3>
                        <p class="text-light-black text-100 mb-1 d-flex align-items-center justify-content-center" style="font-size: 15px; font-weight: 500;">${auction.auction_storage_facility_street_address}</p>
                        <p class="text-light-black text-100 mb-md-3 mb-2 d-flex align-items-center justify-content-center" style="font-size: 15px; font-weight: 500;">${auction.auction_storage_facility_city}, ${auction.auction_storage_facility_state}</p>
                    </div>
                    <div class="bidding__card__button__section">
                                        <a href="${SITE_URL + "auctions/" + auction.auction_id}" target="_blank" rel="noopener noreferrer" style="text-decoration: none;">
                                            <button type="button" style="height: 44px; min-width: max-content; width: max-content;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  mx-auto mb-3 text-100 outline-light-btn btn btn-primary">View Auction
                                                <div class="ms-2 " style="color: inherit;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15.294" height="14.907" viewBox="0 0 15.294 14.907">
                                                        <path id="Icon_awesome-arrow-right" d="M6.5,3.646l.758-.758a.816.816,0,0,1,1.157,0L15.053,9.52a.816.816,0,0,1,0,1.157L8.418,17.313a.816.816,0,0,1-1.157,0L6.5,16.555a.82.82,0,0,1,.014-1.171l4.113-3.919H.819A.817.817,0,0,1,0,10.647V9.554a.817.817,0,0,1,.819-.819h9.81L6.516,4.817A.814.814,0,0,1,6.5,3.646Z" transform="translate(0 -2.647)" fill="inherit"></path>
                                                    </svg>
                                                </div>
                                            </button>
                                        </a>
                    </div>
                </div>
            </div>
        </div>
    `;

    $(".auction__all__live__section__container__grid").append(auctionHtml);

    new Swiper(`.swiper-auction-${auction.auction_id}`, {
        slidesPerView: 1,
        loop: true,
        pagination: {
            el: `.swiper-auction-${auction.auction_id} .swiper-pagination`,
            clickable: true
        },
        navigation: {
            nextEl: `.swiper-auction-${auction.auction_id} .swiper-button-next`,
            prevEl: `.swiper-auction-${auction.auction_id} .swiper-button-prev`
        }
    });

    // Start countdown for this auction
    startCountdown(auction.auction_id, auctionEndDate, auctionEndTime, auctionTimezone);
}

function startCountdown2(auctionId, auctionEndDate, auctionEndTime, auctionTimezone) {

    // Validate timezone; fallback to Australia/Brisbane if invalid
    try {
        new Intl.DateTimeFormat("en-US", { timeZone: auctionTimezone });
    } catch (error) {
        auctionTimezone = "Australia/Brisbane";
    }

    function updateTimer() {
        const auctionTimeNow = new Date(new Date().toLocaleString("en-US", { timeZone: auctionTimezone }));
        const auctionEndTime = new Date(`${auctionEndDate}T23:59:59`);

        const timeDiff = auctionEndTime - auctionTimeNow;

        if (timeDiff <= 0) {
            $(`#days-${auctionId}`).text("0");
            $(`#hours-${auctionId}`).text("0");
            $(`#minutes-${auctionId}`).text("0");
            $(`#seconds-${auctionId}`).text("0");
            return;
        }

        let days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        let hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

        $(`#days-${auctionId}`).text(days);
        $(`#hours-${auctionId}`).text(hours);
        $(`#minutes-${auctionId}`).text(minutes);
        $(`#seconds-${auctionId}`).text(seconds);
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}


function startCountdown(auctionId, auctionEndDate, auctionEndTime, auctionTimezone) {
    const { DateTime } = luxon;

    // Validate timezone; fallback if invalid
    try {
        new Intl.DateTimeFormat("en-US", { timeZone: auctionTimezone });
    } catch (error) {
        auctionTimezone = "Australia/Brisbane";
    }

    // Create the end time using Luxon with timezone
    const endDateTime = DateTime.fromFormat(
        `${auctionEndDate} ${auctionEndTime}`,
        "yyyy-MM-dd hh:mm a",
        { zone: auctionTimezone }
    );

    function updateTimer() {
        const now = DateTime.now().setZone(auctionTimezone);
        const diff = endDateTime.diff(now, ["days", "hours", "minutes", "seconds"]);

        if (diff.toMillis() <= 0) {
            $(`#days-${auctionId}`).text("0");
            $(`#hours-${auctionId}`).text("0");
            $(`#minutes-${auctionId}`).text("0");
            $(`#seconds-${auctionId}`).text("0");
            return;
        }

        $(`#days-${auctionId}`).text(Math.floor(diff.days));
        $(`#hours-${auctionId}`).text(Math.floor(diff.hours));
        $(`#minutes-${auctionId}`).text(Math.floor(diff.minutes));
        $(`#seconds-${auctionId}`).text(Math.floor(diff.seconds));
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}

