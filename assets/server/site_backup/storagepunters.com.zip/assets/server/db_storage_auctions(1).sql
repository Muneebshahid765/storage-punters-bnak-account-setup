-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 01:32 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_storage_auctions`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auctions`
--

CREATE TABLE `tbl_auctions` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `unit_number` text NOT NULL,
  `disclose_unit_number_on_website` text NOT NULL,
  `outstanding_dept` decimal(15,2) NOT NULL,
  `starting_price` decimal(15,2) NOT NULL,
  `start_date` date NOT NULL,
  `start_time` text NOT NULL,
  `end_date` date NOT NULL,
  `end_time` text NOT NULL,
  `youtube_video_url` text NOT NULL,
  `unit_size` text NOT NULL,
  `tags` text NOT NULL,
  `additional_features` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auctions`
--

INSERT INTO `tbl_auctions` (`id`, `description`, `unit_number`, `disclose_unit_number_on_website`, `outstanding_dept`, `starting_price`, `start_date`, `start_time`, `end_date`, `end_time`, `youtube_video_url`, `unit_size`, `tags`, `additional_features`, `created_at`, `updated_at`) VALUES
(1, 'Hunting decoys, filing cabinets assorted other goods', 'A101', '1', '5000.00', '40.00', '2025-04-11', '08:00 AM', '2025-04-14', '08:00 AM', 'https://youtu.be/sample1', '2 x 4', 'cabinet, heavy equipment, clothing, tools, outdoor goods', 'balcony, pool view', '2025-02-13 18:23:48', '2025-04-05 05:53:44'),
(2, 'Nice unit', 'B202', '1', '2000.00', '60.00', '2025-04-01', '8:00 PM', '2025-04-30', '09:29 PM', 'https://youtu.be/sample2', '10 x 20', 'cabinet, heavy equipment, clothing, tools, outdoor...', 'Garden Access, Gym Facility', '2025-02-13 18:23:48', '2025-02-13 18:23:48'),
(3, 'hunting decoys', 'C303', '1', '0.00', '65.00', '2025-04-01', '9:00 AM', '2025-02-27', '10:00 PM', 'https://youtu.be/sample3', '20 x 40', 'outdoor goods', 'Penthouse, Private Terrace', '2025-02-13 18:23:48', '2025-02-13 18:23:48'),
(4, 'Household Items, Matress, Totes and boxes', 'D404', '1', '10000.00', '90.00', '2025-05-01', '02:00 PM', '2025-05-04', '02:00 PM', 'https://youtu.be/sample4', '1 x 5', 'heavy equipment, clothing', 'smart home features, sea view', '2025-02-13 18:23:48', '2025-04-28 12:10:01'),
(5, 'Totes and boxes', 'E505', '0', '500.00', '62.00', '2025-06-01', '8:00 AM', '2025-08-31', '6:00 AM', 'https://youtu.be/sample5', '3 x 9', '', 'Furnished, Near Metro Station', '2025-02-13 18:23:48', '2025-02-13 18:23:48'),
(6, '', '', '0', '0.00', '0.00', '0000-00-00', '', '0000-00-00', '', '', '', '', '', '2025-04-05 04:44:41', '2025-04-05 04:44:41'),
(7, 'this is a comment', '123456', '1', '500.00', '60.00', '2025-04-04', '08:55', '2025-04-07', '08:55', 'http://my-home-page.com', '2x3', 'january', 'new1', '2025-04-05 04:49:16', '2025-04-05 04:49:16'),
(8, 'this is a comment', '123456', '1', '500.00', '60.00', '2025-04-04', '08:55', '2025-04-07', '08:55', 'http://my-home-page.com', '2x3', 'january', 'new1', '2025-04-05 04:53:10', '2025-04-05 04:53:10'),
(9, 'this is a comment', '123456', '1', '500.00', '60.00', '2025-04-04', '12:55', '2025-04-07', '12:55', 'http://my-home-page.com', '2x3', 'january', 'new1', '2025-04-05 04:53:46', '2025-04-05 04:53:46'),
(10, 'this is a comment', '123456', '0', '500.00', '60.00', '2025-04-04', '12:55', '2025-05-10', '09:00 AM', 'http://my-home-page.com', '2x3', 'january', 'new1', '2025-04-05 04:57:15', '2025-04-05 04:57:15'),
(11, 'this is a comment', 'http://my-home-page.com', '0', '52.00', '40.00', '2025-04-05', '09:00', '2025-05-10', '06:00 PM', 'http://my-home-page.com', 'http://my-home-page.com', 'january', '01', '2025-04-05 05:18:53', '2025-04-05 05:18:53'),
(12, 'this is a comment', 'http://my-home-page.com', '0', '65.00', '45.00', '2025-04-04', '05:00 AM', '2025-05-05', '01:00 PM', 'http://my-home-page.com', 'http://my-home-page.com', 'january', '01', '2025-04-05 05:22:29', '2025-04-05 05:22:29'),
(13, 'this is a comment', 'http://my-home-page.com', '0', '500.00', '50.00', '2025-04-04', '12:00 AM', '2025-05-01', '05:00 PM', 'http://my-home-page.com', 'http://my-home-page.com', 'january', '01', '2025-04-05 05:55:30', '2025-04-05 05:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auctions_release_payment_schedule`
--

CREATE TABLE `tbl_auctions_release_payment_schedule` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `invoice_amount` decimal(15,2) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `schedule_at` datetime NOT NULL DEFAULT current_timestamp(),
  `schedule_status` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_categories`
--

CREATE TABLE `tbl_auction_categories` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_categories`
--

INSERT INTO `tbl_auction_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'General', '2025-02-25 06:35:21', '2025-02-25 06:35:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_category_relationship`
--

CREATE TABLE `tbl_auction_category_relationship` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `auction_category_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_category_relationship`
--

INSERT INTO `tbl_auction_category_relationship` (`id`, `auction_id`, `auction_category_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-02-25 04:35:30', '2025-04-05 05:53:44'),
(2, 2, 1, '2025-02-25 04:35:39', '2025-02-25 04:35:39'),
(3, 3, 1, '2025-02-25 04:35:39', '2025-02-25 04:35:39'),
(4, 4, 1, '2025-02-25 04:35:48', '2025-04-28 12:10:01'),
(5, 5, 1, '2025-02-25 04:35:48', '2025-02-25 04:35:48'),
(6, 8, 1, '2025-04-05 04:53:10', '2025-04-05 04:53:10'),
(7, 9, 1, '2025-04-05 04:53:46', '2025-04-05 04:53:46'),
(8, 10, 1, '2025-04-05 04:57:15', '2025-04-05 04:57:15'),
(9, 11, 1, '2025-04-05 05:18:53', '2025-04-05 05:18:53'),
(10, 12, 1, '2025-04-05 05:22:29', '2025-04-05 05:22:29'),
(11, 13, 1, '2025-04-05 05:55:30', '2025-04-05 05:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_confirmations`
--

CREATE TABLE `tbl_auction_confirmations` (
  `id` int(11) NOT NULL,
  `winner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `confirmation_type_id` int(11) NOT NULL,
  `confirmed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_confirmations`
--

INSERT INTO `tbl_auction_confirmations` (`id`, `winner_id`, `user_id`, `confirmation_type_id`, `confirmed_at`, `created_at`, `updated_at`) VALUES
(16, 1, 2, 1, '2025-04-29 13:42:31', '2025-04-29 13:42:31', '2025-04-29 13:42:31'),
(17, 1, 1, 1, '2025-04-29 13:42:39', '2025-04-29 13:42:39', '2025-04-29 13:42:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_confirmation_types`
--

CREATE TABLE `tbl_auction_confirmation_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_confirmation_types`
--

INSERT INTO `tbl_auction_confirmation_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Confirmed', '2025-04-17 06:08:02', '2025-04-17 06:08:02'),
(2, 'Declined', '2025-04-17 06:08:02', '2025-04-17 06:08:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_favorites`
--

CREATE TABLE `tbl_auction_favorites` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_favorites`
--

INSERT INTO `tbl_auction_favorites` (`id`, `auction_id`, `user_id`, `created_at`, `updated_at`) VALUES
(65, 2, 1, '2025-04-30 15:34:14', '2025-04-30 15:34:14'),
(66, 2, 7, '2025-04-30 12:56:42', '2025-04-30 12:56:42'),
(67, 2, 6, '2025-04-30 12:57:42', '2025-04-30 12:57:42'),
(68, 13, 6, '2025-05-01 14:36:53', '2025-05-01 14:36:53'),
(69, 13, 7, '2025-05-01 07:58:21', '2025-05-01 07:58:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_release_payment_schedule`
--

CREATE TABLE `tbl_auction_release_payment_schedule` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `auction_schedule_type_id` int(11) NOT NULL,
  `release_date` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_a` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_schedule_types`
--

CREATE TABLE `tbl_auction_schedule_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_schedule_types`
--

INSERT INTO `tbl_auction_schedule_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Scheduled', '2025-04-17 08:20:11', '2025-04-17 08:20:11'),
(2, 'Released', '2025-04-17 08:20:11', '2025-04-17 08:20:11'),
(3, 'Failed', '2025-04-17 08:20:24', '2025-04-17 08:20:24'),
(4, 'Cancelled', '2025-04-17 08:20:24', '2025-04-17 08:20:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_status_relationship`
--

CREATE TABLE `tbl_auction_status_relationship` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `auction_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_status_relationship`
--

INSERT INTO `tbl_auction_status_relationship` (`id`, `auction_id`, `auction_type_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-02-13 18:24:18', '2025-04-05 05:53:44'),
(2, 2, 9, '2025-02-13 18:24:18', '2025-05-01 12:39:52'),
(3, 3, 1, '2025-02-13 18:24:37', '2025-02-13 18:24:37'),
(4, 4, 9, '2025-02-13 18:24:37', '2025-04-28 12:10:01'),
(5, 5, 8, '2025-02-13 18:24:48', '2025-02-13 18:24:48'),
(6, 8, 1, '2025-04-05 04:53:10', '2025-04-05 04:53:10'),
(7, 9, 1, '2025-04-05 04:53:46', '2025-04-05 04:53:46'),
(8, 10, 1, '2025-04-05 04:57:15', '2025-04-05 04:57:15'),
(9, 11, 1, '2025-04-05 05:18:53', '2025-04-05 05:18:53'),
(10, 12, 1, '2025-04-05 05:22:29', '2025-05-01 15:55:00'),
(11, 13, 1, '2025-04-05 05:55:30', '2025-05-01 19:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_storage_facility_relationship`
--

CREATE TABLE `tbl_auction_storage_facility_relationship` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_storage_facility_relationship`
--

INSERT INTO `tbl_auction_storage_facility_relationship` (`id`, `auction_id`, `storage_facility_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-02-13 18:33:41', '2025-04-05 05:53:44'),
(2, 2, 1, '2025-02-13 18:33:41', '2025-02-13 18:33:41'),
(3, 3, 1, '2025-02-13 18:33:50', '2025-02-13 18:33:50'),
(4, 4, 1, '2025-02-13 18:33:50', '2025-04-28 12:10:01'),
(5, 5, 1, '2025-02-13 18:33:55', '2025-02-13 18:33:55'),
(6, 8, 1, '2025-04-05 04:53:10', '2025-04-05 04:53:10'),
(7, 9, 1, '2025-04-05 04:53:46', '2025-04-05 04:53:46'),
(8, 10, 1, '2025-04-05 04:57:15', '2025-04-05 04:57:15'),
(9, 11, 1, '2025-04-05 05:18:53', '2025-04-05 05:18:53'),
(10, 12, 1, '2025-04-05 05:22:29', '2025-04-05 05:22:29'),
(11, 13, 1, '2025-04-05 05:55:30', '2025-04-05 05:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_types`
--

CREATE TABLE `tbl_auction_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_types`
--

INSERT INTO `tbl_auction_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Live', '2025-02-09 22:25:43', '2025-02-09 22:25:43'),
(2, 'Paused', '2025-02-09 22:25:43', '2025-02-09 22:25:43'),
(3, 'Scheduled', '2025-02-09 22:25:52', '2025-02-09 22:25:52'),
(4, 'Closed', '2025-02-09 22:25:52', '2025-02-09 22:25:52'),
(5, 'Cancelled', '2025-02-09 22:25:58', '2025-02-09 22:25:58'),
(6, 'Draft', '2025-02-09 22:26:12', '2025-02-09 22:26:12'),
(7, 'Under Review', '2025-02-09 22:26:12', '2025-02-09 22:26:12'),
(8, 'Sold', '2025-02-09 22:26:17', '2025-02-09 22:26:17'),
(9, 'Won', '2025-04-28 06:49:58', '2025-04-28 06:49:58'),
(10, 'Expired', '2025-05-01 08:13:53', '2025-05-01 08:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_upload_relationship`
--

CREATE TABLE `tbl_auction_upload_relationship` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `upload_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_upload_relationship`
--

INSERT INTO `tbl_auction_upload_relationship` (`id`, `auction_id`, `upload_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2025-02-13 20:03:52', '2025-02-13 20:03:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_views`
--

CREATE TABLE `tbl_auction_views` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_views`
--

INSERT INTO `tbl_auction_views` (`id`, `auction_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, '2025-02-25 10:09:08', '2025-02-25 10:09:08'),
(2, 3, 1, '2025-02-25 10:09:16', '2025-02-25 10:09:16'),
(3, 3, 2, '2025-02-25 12:48:09', '2025-02-25 12:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auction_won`
--

CREATE TABLE `tbl_auction_won` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auction_won`
--

INSERT INTO `tbl_auction_won` (`id`, `auction_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, '2025-03-15 20:29:33', '2025-03-15 20:29:33'),
(2, 2, 1, '2025-04-30 21:16:04', '2025-04-30 21:16:04'),
(3, 2, 1, '2025-05-01 12:35:28', '2025-05-01 12:35:28'),
(4, 2, 1, '2025-05-01 12:39:52', '2025-05-01 12:39:52'),
(5, 13, 1, '2025-05-01 16:47:43', '2025-05-01 16:47:43'),
(6, 13, 1, '2025-05-01 16:58:15', '2025-05-01 16:58:15'),
(7, 13, 1, '2025-05-01 17:03:32', '2025-05-01 17:03:32'),
(8, 13, 1, '2025-05-01 17:08:11', '2025-05-01 17:08:11'),
(9, 13, 1, '2025-05-01 17:14:05', '2025-05-01 17:14:05'),
(10, 13, 1, '2025-05-01 19:43:45', '2025-05-01 19:43:45'),
(11, 13, 1, '2025-05-01 19:54:22', '2025-05-01 19:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank`
--

CREATE TABLE `tbl_bank` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stripe_customer_id` text NOT NULL,
  `stripe_bank_account_id` text NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `is_default` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bids`
--

CREATE TABLE `tbl_bids` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bid_amount` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_bids`
--

INSERT INTO `tbl_bids` (`id`, `auction_id`, `user_id`, `bid_amount`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '65.00', '2025-02-13 21:09:47', '2025-02-13 21:09:47'),
(2, 2, 6, '67.00', '2025-02-13 21:09:47', '2025-02-13 21:09:47'),
(3, 2, 7, '62.00', '2025-02-13 21:18:42', '2025-02-13 21:18:42'),
(5, 3, 1, '75.00', '2025-02-25 10:50:45', '2025-02-25 10:50:45'),
(6, 4, 1, '91.00', '2025-03-09 05:13:19', '2025-03-09 05:13:19'),
(7, 4, 1, '101.00', '2025-03-09 17:44:03', '2025-03-09 17:44:03'),
(8, 4, 1, '111.00', '2025-03-09 17:44:35', '2025-03-09 17:44:35'),
(9, 4, 1, '121.00', '2025-03-09 17:51:03', '2025-03-09 17:51:03'),
(10, 4, 1, '131.00', '2025-03-09 17:52:22', '2025-03-09 17:52:22'),
(11, 4, 1, '141.00', '2025-03-09 17:54:36', '2025-03-09 17:54:36'),
(12, 4, 1, '151.00', '2025-03-09 17:54:51', '2025-03-09 17:54:51'),
(13, 4, 1, '152.00', '2025-03-09 17:55:05', '2025-03-09 17:55:05'),
(14, 4, 1, '162.00', '2025-03-09 17:56:06', '2025-03-09 17:56:06'),
(15, 4, 1, '172.00', '2025-03-09 18:13:19', '2025-03-09 18:13:19'),
(16, 4, 1, '182.00', '2025-03-09 18:13:41', '2025-03-09 18:13:41'),
(17, 4, 1, '192.00', '2025-03-09 18:45:59', '2025-03-09 18:45:59'),
(18, 4, 1, '256.00', '2025-03-12 03:25:33', '2025-03-12 03:25:33'),
(19, 4, 1, '266.00', '2025-03-12 03:25:52', '2025-03-12 03:25:52'),
(20, 2, 6, '68.00', '2025-03-15 03:51:11', '2025-03-15 03:51:11'),
(21, 2, 1, '78.00', '2025-03-15 04:29:13', '2025-03-15 04:29:13'),
(22, 2, 1, '99.00', '2025-04-14 15:35:27', '2025-04-14 15:35:27'),
(23, 2, 1, '105.00', '2025-04-30 19:33:51', '2025-04-30 19:33:51'),
(24, 2, 1, '106.00', '2025-04-30 19:34:28', '2025-04-30 19:34:28'),
(25, 2, 1, '107.00', '2025-04-30 19:34:56', '2025-04-30 19:34:56'),
(26, 2, 1, '108.00', '2025-04-30 19:36:26', '2025-04-30 19:36:26'),
(27, 2, 1, '109.00', '2025-04-30 19:36:59', '2025-04-30 19:36:59'),
(28, 2, 1, '110.00', '2025-04-30 19:38:45', '2025-04-30 19:38:45'),
(29, 2, 1, '150.00', '2025-04-30 19:39:56', '2025-04-30 19:39:56'),
(30, 2, 1, '155.00', '2025-04-30 19:40:47', '2025-04-30 19:40:47'),
(31, 2, 1, '156.00', '2025-04-30 19:40:57', '2025-04-30 19:40:57'),
(32, 2, 1, '157.00', '2025-04-30 19:43:15', '2025-04-30 19:43:15'),
(33, 2, 1, '158.00', '2025-04-30 19:44:13', '2025-04-30 19:44:13'),
(34, 2, 1, '159.00', '2025-04-30 19:46:56', '2025-04-30 19:46:56'),
(35, 2, 1, '160.00', '2025-04-30 19:49:32', '2025-04-30 19:49:32'),
(36, 2, 1, '170.00', '2025-04-30 19:53:31', '2025-04-30 19:53:31'),
(37, 2, 1, '177.00', '2025-04-30 19:53:40', '2025-04-30 19:53:40'),
(38, 2, 1, '178.00', '2025-04-30 19:55:33', '2025-04-30 19:55:33'),
(39, 2, 1, '179.00', '2025-04-30 19:56:52', '2025-04-30 19:56:52'),
(40, 2, 1, '180.00', '2025-04-30 19:58:04', '2025-04-30 19:58:04'),
(41, 13, 6, '60.00', '2025-05-01 14:35:21', '2025-05-01 14:35:21'),
(42, 13, 1, '65.00', '2025-05-01 14:36:55', '2025-05-01 14:36:55'),
(43, 13, 1, '66.00', '2025-05-01 14:38:11', '2025-05-01 14:38:11'),
(44, 13, 1, '67.00', '2025-05-01 14:39:31', '2025-05-01 14:39:31'),
(45, 13, 1, '68.00', '2025-05-01 14:40:45', '2025-05-01 14:40:45'),
(46, 13, 1, '69.00', '2025-05-01 14:54:41', '2025-05-01 14:54:41'),
(47, 13, 1, '70.00', '2025-05-01 14:55:37', '2025-05-01 14:55:37'),
(48, 13, 7, '200.00', '2025-05-01 07:58:41', '2025-05-01 07:58:41'),
(49, 13, 1, '220.00', '2025-05-01 14:59:00', '2025-05-01 14:59:00'),
(50, 13, 1, '260.00', '2025-05-01 15:00:30', '2025-05-01 15:00:30'),
(51, 13, 1, '266.00', '2025-05-01 20:13:23', '2025-05-01 20:13:23'),
(52, 13, 1, '267.00', '2025-05-01 20:15:25', '2025-05-01 20:15:25'),
(53, 13, 1, '268.00', '2025-05-01 20:19:57', '2025-05-01 20:19:57'),
(54, 13, 1, '269.00', '2025-05-01 20:28:33', '2025-05-01 20:28:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_companies`
--

CREATE TABLE `tbl_companies` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `website` text NOT NULL,
  `email` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_companies`
--

INSERT INTO `tbl_companies` (`id`, `name`, `website`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Mammoth Storage', 'https://mammothselfstore.com.au/', 'hello@mammothstorage.com.au', '2025-02-13 18:27:28', '2025-04-06 09:40:38'),
(2, 'Aj Software', 'aj.com', 'aj@gmail.com', '2025-04-06 09:52:42', '2025-04-06 09:52:42'),
(3, 'Aj Software', 'aj.com', 'aj@gmail.com', '2025-04-06 09:53:30', '2025-04-06 09:58:28'),
(4, 'Aj Software', 'aj.com', 'aj@gmail.com', '2025-04-06 09:59:38', '2025-04-06 09:59:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_location_relationship`
--

CREATE TABLE `tbl_company_location_relationship` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company_location_relationship`
--

INSERT INTO `tbl_company_location_relationship` (`id`, `company_id`, `location_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2025-04-04 23:01:55', '2025-04-04 23:01:55'),
(2, 3, 3, '2025-04-06 09:53:30', '2025-04-06 09:53:30'),
(3, 4, 4, '2025-04-06 09:59:38', '2025-04-06 09:59:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_status_relationship`
--

CREATE TABLE `tbl_company_status_relationship` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company_status_relationship`
--

INSERT INTO `tbl_company_status_relationship` (`id`, `company_id`, `status_type_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-02-13 18:27:37', '2025-02-13 18:27:37'),
(2, 3, 1, '2025-04-06 09:53:30', '2025-04-06 09:53:30'),
(3, 4, 1, '2025-04-06 09:59:38', '2025-04-06 09:59:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_verfication_relationship`
--

CREATE TABLE `tbl_company_verfication_relationship` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `verfication_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company_verfication_relationship`
--

INSERT INTO `tbl_company_verfication_relationship` (`id`, `company_id`, `verfication_type_id`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2025-02-13 18:27:56', '2025-02-13 18:27:56'),
(2, 1, 2, 1, '2025-02-13 18:27:56', '2025-02-13 18:27:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_email_queue`
--

CREATE TABLE `tbl_email_queue` (
  `id` int(10) UNSIGNED NOT NULL,
  `to_email` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `template` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `auction_item` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `auction_amount` decimal(15,2) NOT NULL,
  `auction_total` decimal(15,2) NOT NULL,
  `auction_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_at` datetime NOT NULL,
  `status` enum('pending','processing','sent','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `error_message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_email_queue`
--

INSERT INTO `tbl_email_queue` (`id`, `to_email`, `subject`, `template`, `name`, `user_id`, `auction_id`, `auction_item`, `auction_amount`, `auction_total`, `auction_url`, `attachment`, `scheduled_at`, `status`, `error_message`, `created_at`, `updated_at`) VALUES
(12, 'specialemailid2050@gmail.com', 'Reminder: Auction ends in 1 hour', 'auction_reminder_1hr_email', 'Ali Jamil', 0, 2, 'Forest Glen Self Storage #2 - San Jose2 , California', '0.00', '0.00', 'http://localhost/storage_auctions/auctions/2', NULL, '2025-04-30 19:28:09', 'sent', NULL, '2025-04-30 11:28:09', '2025-04-30 13:52:43'),
(13, 'specialemailid2050@gmail.com', 'Reminder: Auction ends in 3 hours', 'auction_reminder_3hr_email', 'Ali Jamil', 0, 2, 'Forest Glen Self Storage #2 - San Jose2 , California', '0.00', '0.00', 'http://localhost/storage_auctions/auctions/2', NULL, '2025-04-30 21:29:10', 'sent', NULL, '2025-04-30 11:29:10', '2025-04-30 13:52:40'),
(16, 'specialemailid2050@gmail.com', 'You have Been Outbid!', 'auction_outbid_email', 'A1 J1', 0, 2, 'Forest Glen Self Storage #2 - San Jose2 , California', '0.00', '0.00', 'http://localhost/storage_auctions/auctions/2', NULL, '2025-04-30 19:58:05', 'sent', NULL, '2025-04-30 12:58:05', '2025-04-30 13:52:34'),
(17, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 2, 'Forest Glen Self Storage #2 - San Jose2 , California', '180.00', '180.00', 'http://localhost/storage_auctions/auctions/2', NULL, '2025-04-30 19:58:05', 'sent', NULL, '2025-04-30 12:58:05', '2025-05-01 12:34:56'),
(21, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 2, 'Forest Glen Self Storage #2 - San Jose2 , California', '180.00', '180.00', 'http://localhost/storage_auctions/auctions/2', NULL, '2025-05-01 12:35:04', 'sent', NULL, '2025-05-01 05:35:04', '2025-05-01 12:39:52'),
(29, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, '# -  ,', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 16:19:00', 'sent', NULL, '2025-05-01 09:19:00', '2025-05-01 09:23:48'),
(30, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 16:32:00', 'sent', NULL, '2025-05-01 09:32:00', '2025-05-01 16:47:38'),
(32, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 16:47:43', 'sent', NULL, '2025-05-01 09:47:43', '2025-05-01 16:47:43'),
(33, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 16:58:00', 'sent', NULL, '2025-05-01 09:58:00', '2025-05-01 16:58:00'),
(34, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 16:58:14', 'sent', NULL, '2025-05-01 09:58:14', '2025-05-01 16:58:15'),
(35, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:03:20', 'sent', NULL, '2025-05-01 10:03:20', '2025-05-01 17:03:21'),
(36, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:03:32', 'sent', NULL, '2025-05-01 10:03:32', '2025-05-01 17:03:32'),
(37, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:08:00', 'sent', NULL, '2025-05-01 10:08:00', '2025-05-01 17:08:00'),
(38, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:08:10', 'sent', NULL, '2025-05-01 10:08:10', '2025-05-01 17:08:11'),
(39, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:14:00', 'sent', NULL, '2025-05-01 10:14:00', '2025-05-01 17:14:00'),
(40, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 17:14:05', 'sent', NULL, '2025-05-01 10:14:05', '2025-05-01 17:14:05'),
(41, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:43:39', 'processing', NULL, '2025-05-01 12:43:39', '2025-05-01 19:43:39'),
(42, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:43:45', 'processing', NULL, '2025-05-01 12:43:45', '2025-05-01 19:43:45'),
(43, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:52:22', 'processing', NULL, '2025-05-01 12:52:22', '2025-05-01 19:54:12'),
(44, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:52:58', 'pending', NULL, '2025-05-01 12:52:58', '2025-05-01 12:52:58'),
(45, 'specialemailid2050@gmail.com', 'Congratulations, You Won the Auction!', 'auction_winner_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:54:11', 'pending', NULL, '2025-05-01 12:54:11', '2025-05-01 12:54:11'),
(46, 'specialemailid2050@gmail.com', 'Your Invoice from Storage Punters', 'auction_invoice_email', 'Ali Jamil', 0, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '260.00', '260.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 19:54:21', 'processing', NULL, '2025-05-01 12:54:21', '2025-05-01 19:54:22'),
(53, 'specialemailid2050@gmail.com', 'You have Been Outbid!', 'auction_outbid_email', 'A J', 6, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '269.00', '269.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 20:28:33', 'sent', NULL, '2025-05-01 13:28:33', '2025-05-01 20:28:33'),
(54, 'specialemailid2050@gmail.com', 'You have Been Outbid!', 'auction_outbid_email', 'A1 J1', 7, 13, 'Forest Glen Self Storage #13 - San Jose2 , Queensland', '269.00', '269.00', 'http://localhost/storage_auctions/auctions/13', NULL, '2025-05-01 20:28:33', 'sent', NULL, '2025-05-01 13:28:33', '2025-05-01 20:28:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoices`
--

CREATE TABLE `tbl_invoices` (
  `id` int(11) NOT NULL,
  `invoice_number` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `currency` text NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date NOT NULL,
  `paid_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoices`
--

INSERT INTO `tbl_invoices` (`id`, `invoice_number`, `amount`, `tax_amount`, `total_amount`, `currency`, `invoice_date`, `due_date`, `paid_date`, `created_at`, `updated_at`) VALUES
(1, 'AST123098', '100.00', '12.00', '115.00', 'USD', '2025-03-18', '2025-03-25', '2025-03-18', '2025-03-18 22:54:16', '2025-03-18 22:54:16'),
(3, 'INV-68120674abb6f', '180.00', '18.00', '180.00', 'AUD', '2025-04-30', '2025-05-03', '2025-05-03', '2025-04-30 21:16:04', '2025-04-30 21:16:04'),
(4, 'INV-6812ddf0da75b', '180.00', '18.00', '180.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 12:35:28', '2025-05-01 12:35:28'),
(5, 'INV-6812def81a407', '180.00', '18.00', '180.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 12:39:52', '2025-05-01 12:39:52'),
(6, 'INV-6813190fb8d3c', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 16:47:43', '2025-05-01 16:47:43'),
(7, 'INV-68131b873824a', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 16:58:15', '2025-05-01 16:58:15'),
(8, 'INV-68131cc4f14f5', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 17:03:32', '2025-05-01 17:03:32'),
(9, 'INV-68131ddb1766d', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 17:08:11', '2025-05-01 17:08:11'),
(10, 'INV-68131f3d40988', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 17:14:05', '2025-05-01 17:14:05'),
(11, 'INV-6813425174b1f', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 19:43:45', '2025-05-01 19:43:45'),
(12, 'INV-681344ce23a15', '260.00', '26.00', '260.00', 'AUD', '2025-05-01', '2025-05-04', '2025-05-04', '2025-05-01 19:54:22', '2025-05-01 19:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_auction_relationship`
--

CREATE TABLE `tbl_invoice_auction_relationship` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `invoice_type_id` int(11) NOT NULL,
  `invoice_payment_method_type_id` int(11) NOT NULL,
  `invoice_payment_status_type_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoice_auction_relationship`
--

INSERT INTO `tbl_invoice_auction_relationship` (`id`, `invoice_id`, `invoice_type_id`, `invoice_payment_method_type_id`, `invoice_payment_status_type_id`, `auction_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 2, 2, 4, 1, '2025-03-18 22:55:09', '2025-04-26 19:36:33'),
(3, 3, 2, 2, 1, 2, 1, '2025-04-30 21:16:04', '2025-04-30 21:16:04'),
(4, 4, 2, 2, 1, 2, 1, '2025-05-01 12:35:28', '2025-05-01 12:35:28'),
(5, 5, 2, 2, 1, 2, 1, '2025-05-01 12:39:52', '2025-05-01 12:39:52'),
(6, 6, 2, 2, 1, 13, 1, '2025-05-01 16:47:43', '2025-05-01 16:47:43'),
(7, 7, 2, 2, 1, 13, 1, '2025-05-01 16:58:15', '2025-05-01 16:58:15'),
(8, 8, 2, 2, 1, 13, 1, '2025-05-01 17:03:32', '2025-05-01 17:03:32'),
(9, 9, 2, 2, 1, 13, 1, '2025-05-01 17:08:11', '2025-05-01 17:08:11'),
(10, 10, 2, 2, 1, 13, 1, '2025-05-01 17:14:05', '2025-05-01 17:14:05'),
(11, 11, 2, 2, 1, 13, 1, '2025-05-01 19:43:45', '2025-05-01 19:43:45'),
(12, 12, 2, 2, 1, 13, 13, '2025-05-01 19:54:22', '2025-05-01 19:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_payment_method_types`
--

CREATE TABLE `tbl_invoice_payment_method_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `descriptions` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoice_payment_method_types`
--

INSERT INTO `tbl_invoice_payment_method_types` (`id`, `name`, `descriptions`, `created_at`, `updated_at`) VALUES
(1, 'Cash', 'Payment made using physical currency.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(2, 'Credit Card', 'Payment made using a credit card.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(3, 'Debit Card', 'Payment made using a debit card.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(4, 'Bank Transfer', 'Direct payment via bank transfer.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(5, 'PayPal', 'Online payment through PayPal.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(6, 'Cryptocurrency', 'Payment made using Bitcoin, Ethereum, or other cryptocurrencies.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(7, 'Google Pay', 'Digital payment via Google Pay.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(8, 'Apple Pay', 'Digital payment via Apple Pay.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(9, 'Cheque', 'Payment made using a bank cheque.', '2025-03-18 22:24:51', '2025-03-18 22:24:51'),
(10, 'Wire Transfer', 'Electronic funds transfer between banks.', '2025-03-18 22:24:51', '2025-03-18 22:24:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_stripe_logs_relationship`
--

CREATE TABLE `tbl_invoice_stripe_logs_relationship` (
  `id` int(11) NOT NULL,
  `stripe_event_id` text NOT NULL,
  `stripe_payment_intent_id` text NOT NULL,
  `stripe_customer_id` text NOT NULL,
  `stripe_charge_id` text NOT NULL,
  `amount_received` text NOT NULL,
  `currency` text NOT NULL,
  `payment_status` text NOT NULL,
  `event_type` text NOT NULL,
  `payment_at` datetime NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoice_stripe_logs_relationship`
--

INSERT INTO `tbl_invoice_stripe_logs_relationship` (`id`, `stripe_event_id`, `stripe_payment_intent_id`, `stripe_customer_id`, `stripe_charge_id`, `amount_received`, `currency`, `payment_status`, `event_type`, `payment_at`, `invoice_id`, `created_at`, `updated_at`) VALUES
(1, 'evt_3RI56e08JMAyNQJT1CkYuj8K', 'pi_3RI56e08JMAyNQJT1Q0Ps5o3', 'cus_SAxBxoznGWuf2e', 'ch_3RI56e08JMAyNQJT1DDWAlkj', '11500', 'usd', 'succeeded', 'payment_intent.succeeded', '0000-00-00 00:00:00', 1, '2025-04-26 19:34:12', '2025-04-26 19:34:12'),
(2, 'evt_3RI56e08JMAyNQJT1CkYuj8K', 'pi_3RI56e08JMAyNQJT1Q0Ps5o3', 'cus_SAxBxoznGWuf2e', 'ch_3RI56e08JMAyNQJT1DDWAlkj', '11500', 'usd', 'succeeded', 'payment_intent.succeeded', '2025-04-26 19:33:09', 1, '2025-04-26 19:36:33', '2025-04-26 19:36:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_stripe_relationship`
--

CREATE TABLE `tbl_invoice_stripe_relationship` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `stripe_invoice_id` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoice_stripe_relationship`
--

INSERT INTO `tbl_invoice_stripe_relationship` (`id`, `invoice_id`, `stripe_invoice_id`, `created_at`, `updated_at`) VALUES
(2, 1, '', '2025-04-24 20:19:27', '2025-04-24 20:19:27'),
(3, 1, '', '2025-04-24 20:20:47', '2025-04-24 20:20:47'),
(4, 1, 'pi_3RHNDI08JMAyNQJT1bH7VIiN', '2025-04-24 20:41:04', '2025-04-24 20:41:04'),
(5, 1, 'pi_3RHNMe08JMAyNQJT0s0YmDUG', '2025-04-24 20:50:44', '2025-04-24 20:50:44'),
(6, 1, 'pi_3RI3AG08JMAyNQJT1zckTP0s', '2025-04-26 17:28:45', '2025-04-26 17:28:45'),
(7, 1, 'pi_3RI3cs08JMAyNQJT13FKPx1d', '2025-04-26 17:58:19', '2025-04-26 17:58:19'),
(8, 1, 'pi_3RI56e08JMAyNQJT1Q0Ps5o3', '2025-04-26 19:33:09', '2025-04-26 19:33:09'),
(9, 1, 'pi_3RJ57I08JMAyNQJT1TRpuX4H', '2025-04-29 13:45:58', '2025-04-29 13:45:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_types`
--

CREATE TABLE `tbl_invoice_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `descriptions` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_invoice_types`
--

INSERT INTO `tbl_invoice_types` (`id`, `name`, `descriptions`, `created_at`, `updated_at`) VALUES
(1, 'Draft', 'Invoice is created but not yet submitted.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(2, 'Submitted', 'Invoice has been submitted for review.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(3, 'Approved', 'Invoice has been reviewed and approved.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(4, 'Pending', 'Invoice is awaiting payment.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(5, 'Cancelled', 'Invoice has been canceled.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(6, 'Voided', 'Invoice has been invalidated and holds no financial impact.', '2025-03-18 22:31:30', '2025-03-18 22:31:30'),
(7, 'Disputed', 'Invoice is under dispute and being reviewed.', '2025-03-18 22:31:30', '2025-03-18 22:31:30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_locations`
--

CREATE TABLE `tbl_locations` (
  `id` int(11) NOT NULL,
  `street_address` text NOT NULL,
  `apt_suite` text NOT NULL,
  `city` text NOT NULL,
  `postal_code` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `phone` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_locations`
--

INSERT INTO `tbl_locations` (`id`, `street_address`, `apt_suite`, `city`, `postal_code`, `state`, `country`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Shop 14 /380 Mons Road', '', 'Forest Glen', '4556', 'Queensland (QLD)', 'Australia', '1300 136 851', '2025-02-13 18:32:15', '2025-02-13 18:32:15'),
(2, '829 Di Fiore Drive', '123', 'San Jose2', '95128', 'Queensland', 'Australia', '408-591-4612', '2025-03-11 19:24:04', '2025-05-03 20:02:54'),
(3, 'full street address', '12312', 'city name', 'zip code or postal code', 'California', 'United States', '1212', '2025-04-06 09:53:30', '2025-04-06 09:58:28'),
(4, 'full street address', '1212', 'city name', 'zip code or postal code', 'California', 'United States', '(123) 456-7890', '2025-04-06 09:59:38', '2025-04-06 09:59:38'),
(5, 'full street address', '', 'city name', 'zip code or postal code', 'California', 'United States', '(123) 456-7890', '2025-04-07 13:35:25', '2025-04-07 13:35:25'),
(6, 'full street address', '', 'city name', 'zip code or postal code', 'California', 'United States', '(123) 456-7890', '2025-04-07 14:07:27', '2025-04-07 14:07:27'),
(7, 'full street address', '', 'city name', 'zip code or postal code', 'Queensland', 'Australia', '(123) 456-7890', '2025-04-07 14:19:41', '2025-05-01 05:24:32'),
(8, 'Full Street Address', '', 'Sydney', '123456', 'Queensland', 'Australia', '(123) 456-7890', '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(9, 'Full Street Address', '', 'Sydney', '123456', 'Queensland', 'Australia', '(123) 456-7890', '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(10, 'Full Street Address', '', 'City Name', '123456', 'Victoria', 'Australia', '(123) 456-7890', '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(11, 'Full Street Address', '', 'Sydney', '123456', 'Queensland', 'Australia', '(123) 456-7890', '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(12, 'Full Street Address', '', 'City Name', '123456', 'Queensland', 'Australia', '(123) 456-7890', '2025-05-04 12:52:13', '2025-05-04 12:52:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notification_types`
--

CREATE TABLE `tbl_notification_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `descriptions` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_notification_types`
--

INSERT INTO `tbl_notification_types` (`id`, `name`, `descriptions`, `created_at`, `updated_at`) VALUES
(1, 'New Auction', 'A new auction has been listed. Check out the details and place your bids before the auction ends.', '2025-02-09 22:47:22', '2025-02-09 22:47:22'),
(2, 'Favorite Auction', 'A reminder for an auction you favorited. Stay updated as it approaches the closing time!', '2025-02-09 22:47:22', '2025-02-09 22:47:22'),
(3, 'Outbid Auction', 'You have been outbid on an auction. Click the link to place a higher bid and stay in the race.', '2025-02-09 22:47:36', '2025-02-09 22:47:36'),
(4, 'Winning Auction', 'Congratulations! You have won the auction. Here’s how to contact the seller and proceed with payment and collection.', '2025-02-09 22:47:36', '2025-02-09 22:47:36'),
(5, 'Auction Closed', 'The auction you participated in has ended. View the final results and explore other ongoing auctions.', '2025-02-09 22:47:56', '2025-02-09 22:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_types`
--

CREATE TABLE `tbl_payment_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_payment_types`
--

INSERT INTO `tbl_payment_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Unpaid', '2025-02-09 22:31:00', '2025-02-09 22:31:00'),
(2, 'Paid', '2025-02-09 22:31:00', '2025-02-09 22:31:00'),
(3, 'Pending', '2025-02-09 22:31:10', '2025-02-09 22:31:10'),
(4, 'Failed', '2025-02-09 22:31:10', '2025-02-09 22:31:10'),
(5, 'Refunded', '2025-02-09 22:31:25', '2025-02-09 22:31:25'),
(6, 'Partially Paid', '2025-02-09 22:31:25', '2025-02-09 22:31:25'),
(7, 'Overpaid', '2025-02-09 22:31:35', '2025-02-09 22:31:35'),
(8, 'Cancelled', '2025-02-09 22:31:35', '2025-02-09 22:31:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_preference_types`
--

CREATE TABLE `tbl_preference_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_preference_types`
--

INSERT INTO `tbl_preference_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Email', '2025-03-18 20:14:23', '2025-03-18 20:14:23'),
(2, 'Text', '2025-03-18 20:14:23', '2025-03-18 20:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role_types`
--

CREATE TABLE `tbl_role_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `descriptions` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_role_types`
--

INSERT INTO `tbl_role_types` (`id`, `name`, `descriptions`, `created_at`, `updated_at`) VALUES
(1, 'Storage Facility', 'Manages and lists storage units for auctions.', '2025-02-08 15:26:26', '2025-02-08 15:26:26'),
(2, 'Punter', 'Participates in auctions by placing bids.', '2025-02-08 15:26:26', '2025-02-08 15:26:26'),
(3, 'Staff', 'Assists in managing storage facilities or platform operations.', '2025-02-09 22:54:22', '2025-02-09 22:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff_company_access_relationship`
--

CREATE TABLE `tbl_staff_company_access_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_staff_company_access_relationship`
--

INSERT INTO `tbl_staff_company_access_relationship` (`id`, `user_id`, `company_id`, `status_type_id`, `created_at`, `updated_at`) VALUES
(1, 15, 1, 1, '2025-05-05 14:58:09', '2025-05-05 15:03:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff_permissions`
--

CREATE TABLE `tbl_staff_permissions` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status_types`
--

CREATE TABLE `tbl_status_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `descriptions` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_status_types`
--

INSERT INTO `tbl_status_types` (`id`, `name`, `descriptions`, `created_at`, `updated_at`) VALUES
(1, 'Active', 'Currently enabled and operational.', '2025-02-09 21:15:23', '2025-02-09 21:15:23'),
(2, 'Inactive', 'Currently disabled and not operational.', '2025-02-09 21:15:23', '2025-02-09 21:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage_facilities`
--

CREATE TABLE `tbl_storage_facilities` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `abn` text NOT NULL,
  `website` text NOT NULL,
  `description` text NOT NULL,
  `timezone` text NOT NULL,
  `contact_email` text NOT NULL,
  `additional_email` text NOT NULL,
  `office_hours` text NOT NULL,
  `payout_details` text NOT NULL,
  `youtube_video_url` text NOT NULL,
  `branding_logo` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_storage_facilities`
--

INSERT INTO `tbl_storage_facilities` (`id`, `name`, `abn`, `website`, `description`, `timezone`, `contact_email`, `additional_email`, `office_hours`, `payout_details`, `youtube_video_url`, `branding_logo`, `created_at`, `updated_at`) VALUES
(1, 'Forest Glen Self Storage', '999', 'https://mammothselfstore.com.au/locations/storage-forest-glen/', 'Whether you’re getting ready to renovate, looking for a safe place to store your boat, or you’re heading off on that long-awaited trip of a lifetime, whatever your storage needs, Mammoth Storage Forest Glen can help you. As a locally owned, highly secure self storage facility located in Forest Glen, Sunshine Coast, we offer a range of long-term and short-term self storage options in a wide range of sizes to meet your storage needs. Our moving supplies shop makes storing with us even easier. Plus, you’ll be able to access your stored items at any time of the day or night with our secure 24/7 access system. *24 hours by request only*', 'Australia/Brisbane', 'hello@mammothstorage.com.au', 'abc@gmail.com', 'Access Hours: 5am – 9pm or 24 hours by request.\nReception Office Hours:\nMondays to Fridays: 8:30am to 5pm\nSaturdays: 8:30am to 1pm\nSunday: 9am to 12pm\nClosed on Public Holidays', 'p12', 'y12', 'b12', '2025-02-13 18:29:53', '2025-04-07 14:19:23'),
(2, 'my full name 2', '30', 'http://my-home-page.com', 'this is a comment', 'Australia/Brisbane', 'me@mydomain.com', 'me@mydomain.com', '30', '30', 'http://my-home-page.com', '30', '2025-04-07 13:35:25', '2025-04-07 13:35:25'),
(3, 'my full name 3', '30', 'http://my-home-page.com', 'this is a comment', 'Australia/Brisbane', 'me@mydomain.com', 'me@mydomain.com', '30', '30', 'http://my-home-page.com', '30', '2025-04-07 14:07:27', '2025-04-07 14:07:27'),
(4, 'my full name 4', '30', 'http://my-home-page.com', 'this is a comment', 'Australia/Brisbane', 'me@mydomain.com', 'me@mydomain.com', '30', '30', 'http://my-home-page.com', '30', '2025-04-07 14:19:41', '2025-05-01 05:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage_facility_company_relationship`
--

CREATE TABLE `tbl_storage_facility_company_relationship` (
  `id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_storage_facility_company_relationship`
--

INSERT INTO `tbl_storage_facility_company_relationship` (`id`, `storage_facility_id`, `company_id`, `created_at`, `updated_at`) VALUES
(2, 1, 1, '2025-04-04 23:02:44', '2025-04-04 23:02:44'),
(3, 3, 4, '2025-04-07 14:07:27', '2025-04-07 14:07:27'),
(4, 4, 1, '2025-04-07 14:19:41', '2025-04-07 14:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage_facility_location_relationship`
--

CREATE TABLE `tbl_storage_facility_location_relationship` (
  `id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_storage_facility_location_relationship`
--

INSERT INTO `tbl_storage_facility_location_relationship` (`id`, `storage_facility_id`, `location_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2025-02-13 18:32:30', '2025-02-13 18:32:30'),
(2, 2, 5, '2025-04-07 13:35:25', '2025-04-07 13:35:25'),
(3, 3, 6, '2025-04-07 14:07:27', '2025-04-07 14:07:27'),
(4, 4, 7, '2025-04-07 14:19:41', '2025-04-07 14:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage_facility_staff_relationship`
--

CREATE TABLE `tbl_storage_facility_staff_relationship` (
  `id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_storage_facility_status_relationship`
--

CREATE TABLE `tbl_storage_facility_status_relationship` (
  `id` int(11) NOT NULL,
  `storage_facility_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_storage_facility_status_relationship`
--

INSERT INTO `tbl_storage_facility_status_relationship` (`id`, `storage_facility_id`, `status_type_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-02-13 18:33:07', '2025-04-07 11:16:31'),
(2, 2, 1, '2025-04-07 13:35:25', '2025-04-07 13:35:25'),
(3, 3, 1, '2025-04-07 14:07:27', '2025-04-07 14:07:27'),
(4, 4, 1, '2025-04-07 14:19:41', '2025-04-07 14:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_token_activation_types`
--

CREATE TABLE `tbl_token_activation_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_token_activation_types`
--

INSERT INTO `tbl_token_activation_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Email Activation', '2025-05-04 07:34:22', '2025-05-04 07:34:22'),
(2, 'Forgot Password', '2025-05-04 07:34:22', '2025-05-04 07:34:22'),
(3, 'Invitation Staff', '2025-05-05 05:06:55', '2025-05-05 05:06:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE `tbl_uploads` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `path` text NOT NULL,
  `type` text NOT NULL,
  `size` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`id`, `name`, `path`, `type`, `size`, `created_at`, `updated_at`) VALUES
(1, 'Forest Glen', 'https://mammothselfstore.com.au/wp-content/uploads/2022/07/forestglen_1.jpg', 'jpg', '47.8 KB', '2025-02-13 20:02:11', '2025-02-13 20:02:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `last_name`, `created_at`, `updated_at`) VALUES
(1, 'Ali', 'Jamil', '2025-02-13 21:08:52', '2025-02-13 21:08:52'),
(2, 'Tobias', 'Constantinides', '2025-02-25 12:45:54', '2025-02-25 12:45:54'),
(3, 'A1', 'Ab', '2025-04-28 09:05:06', '2025-04-28 09:05:06'),
(4, 'A1', 'Ab', '2025-04-28 09:10:57', '2025-04-28 09:10:57'),
(5, 'Ali22', 'J123', '2025-04-28 10:00:03', '2025-04-28 10:56:10'),
(6, 'A', 'J', '2025-04-30 11:36:47', '2025-04-30 11:36:47'),
(7, 'A1', 'J1', '2025-04-30 11:36:53', '2025-04-30 11:36:53'),
(10, 'Ali', 'Jamil', '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(11, 'Ali', 'Jamil', '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(12, 'Ali', 'Jamil', '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(13, 'Ali', 'Jamil', '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(14, 'Ali', 'Jamil', '2025-05-04 12:52:13', '2025-05-04 12:52:13'),
(15, 'Ali', 'Jamil', '2025-05-05 14:31:03', '2025-05-05 14:31:03'),
(16, 'Ali', 'Jamil', '2025-05-06 05:52:40', '2025-05-06 05:52:40'),
(17, 'Ali', 'Jamil', '2025-05-06 05:55:50', '2025-05-06 05:55:50'),
(18, 'Ali', 'Jamil', '2025-05-06 05:57:52', '2025-05-06 05:57:52'),
(19, 'Ali', 'Jamil', '2025-05-06 05:58:52', '2025-05-06 05:58:52'),
(20, 'Ali', 'Jamil', '2025-05-06 05:59:57', '2025-05-06 05:59:57'),
(21, 'Ali', 'Jamil', '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(22, 'Ali', 'Jamil', '2025-05-06 06:09:35', '2025-05-06 06:09:35'),
(23, 'Ali', 'Jamil', '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(24, 'Ali', 'Jamil', '2025-05-06 06:14:28', '2025-05-06 06:14:28'),
(25, 'Ali', 'Jamil', '2025-05-06 07:14:21', '2025-05-06 07:14:21'),
(26, 'Ali', 'Jamil', '2025-05-06 07:15:29', '2025-05-06 07:15:29'),
(27, 'Ali', 'Jamil', '2025-05-06 07:33:11', '2025-05-06 07:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_activation_token`
--

CREATE TABLE `tbl_user_activation_token` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `token` text NOT NULL,
  `expires_at` datetime NOT NULL,
  `token_activation_type_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_activation_token`
--

INSERT INTO `tbl_user_activation_token` (`id`, `email`, `token`, `expires_at`, `token_activation_type_id`, `company_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'specialemailid2050@gmail.com', 'd05fbe2e57813a11ea9f93fb8a1ba8cf4b92ac0a44a0581d46d9c929dbefd777', '2025-05-04 20:39:17', 1, 0, 11, '2025-05-03 20:39:17', '2025-05-03 20:39:17'),
(2, 'specialemailid2050@gmail.com', 'eded9db9cdda4816d5d9225b89a1356ec7b94c1793cc06f34735137e58e19d97', '2025-05-04 20:42:57', 1, 0, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(5, 'specialemailid2050@gmail.com', 'fdb4048d1e2f149c024e8b9af7ecd675e8cf569d7384f8add3c0d812c31f7cd9', '2025-05-05 15:03:46', 2, 0, 13, '2025-05-04 15:03:46', '2025-05-04 15:03:46'),
(6, 'specialemailid2050@gmail.com', '90dff1c1b74f0713be4f49887261e3dd8f5c1696f45ecd0d758654bc5e588382', '2025-05-05 15:27:07', 2, 0, 13, '2025-05-04 15:27:07', '2025-05-04 15:27:07'),
(7, 'specialemailid2050@gmail.com', '9fefdbd6ab227c9c090e088dca1ebcc957522656658bac3185709d6f1cfa5050', '2025-05-05 15:28:58', 2, 0, 13, '2025-05-04 15:28:58', '2025-05-04 15:28:58'),
(8, 'specialemailid2050@gmail.com', '80bfd1576fcb29397bed2b9ecee265779c90a253440a8a734890fee0b1df2c46', '2025-05-05 15:29:40', 2, 0, 13, '2025-05-04 15:29:40', '2025-05-04 15:29:40'),
(13, 'test1288@gmail.com', 'ba05b2a5dd52e6919c7323ea51eed243f5e7848e2a7f20afa0cde35cf67370a6', '2025-05-08 05:59:58', 3, 1, 20, '2025-05-06 05:59:58', '2025-05-06 05:59:58'),
(14, 'test1277@gmail.com', '2a4a5b96f0926208d5d33f2317fe13ba91515feada2db1fce9ce6bc5a8282b75', '2025-05-08 06:00:43', 3, 1, 21, '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(15, 'test12336@gmail.com', 'b16965d43d26b36124c7596fd46af6f7c2c2e893c763d1e8075507ec173d126b', '2025-05-08 06:10:38', 3, 1, 23, '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(20, 'test12657567@gmail.com', 'a00bb147f1d6862160da8da50349bca0de9c072676af2a1a0817bc7f91f05636', '2025-05-08 07:35:18', 3, 1, 27, '2025-05-06 07:35:18', '2025-05-06 07:35:18'),
(21, 'test12657567@gmail.com', '2afbe0d56295fc13e5272796dbe9d5b28ff909d488f88e3d3deb992587929d4c', '2025-05-08 07:36:09', 3, 1, 27, '2025-05-06 07:36:09', '2025-05-06 07:36:09'),
(22, 'test12657567@gmail.com', 'b9883202640750e029719d1165a3c4dc54bc072c31fa287ac510cf9ae0079fec', '2025-05-08 07:46:47', 3, 1, 27, '2025-05-06 07:46:47', '2025-05-06 07:46:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_activity`
--

CREATE TABLE `tbl_user_activity` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_status` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_alert_settings`
--

CREATE TABLE `tbl_user_alert_settings` (
  `id` int(11) NOT NULL,
  `preference_type_id` int(11) NOT NULL,
  `notification_type_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_alert_settings`
--

INSERT INTO `tbl_user_alert_settings` (`id`, `preference_type_id`, `notification_type_id`, `status_type_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 4, 1, 1, '2025-03-18 20:19:03', '2025-03-19 04:58:50'),
(2, 2, 4, 1, 1, '2025-03-18 20:19:03', '2025-03-19 06:15:33'),
(3, 1, 5, 1, 1, '2025-03-18 20:21:29', '2025-03-19 06:15:21'),
(4, 2, 5, 2, 1, '2025-03-18 20:21:29', '2025-03-19 06:15:26'),
(5, 1, 3, 1, 1, '2025-03-18 20:21:55', '2025-03-19 04:20:29'),
(6, 1, 3, 2, 1, '2025-03-18 20:21:55', '2025-03-19 04:20:39'),
(13, 1, 4, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(14, 2, 4, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(15, 1, 5, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(16, 2, 5, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(17, 1, 3, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(18, 2, 3, 1, 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(19, 1, 4, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(20, 2, 4, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(21, 1, 5, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(22, 2, 5, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(23, 1, 3, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(24, 2, 3, 1, 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(25, 1, 4, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(26, 2, 4, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(27, 1, 5, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(28, 2, 5, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(29, 1, 3, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(30, 2, 3, 1, 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(31, 1, 4, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(32, 2, 4, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(33, 1, 5, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(34, 2, 5, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(35, 1, 3, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(36, 2, 3, 1, 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_bank_informations_relationship`
--

CREATE TABLE `tbl_user_bank_informations_relationship` (
  `id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_company_relationship`
--

CREATE TABLE `tbl_user_company_relationship` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_company_relationship`
--

INSERT INTO `tbl_user_company_relationship` (`id`, `company_id`, `user_id`, `status_type_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1, '2025-03-23 21:10:41', '2025-03-23 21:10:41'),
(2, 3, 1, 1, '2025-04-06 09:53:30', '2025-04-06 09:53:30'),
(3, 4, 1, 1, '2025-04-06 09:59:38', '2025-04-06 09:59:38'),
(10, 1, 15, 2, '2025-05-05 15:19:25', '2025-05-05 15:44:01'),
(11, 1, 16, 2, '2025-05-06 05:52:40', '2025-05-06 05:52:40'),
(12, 1, 17, 2, '2025-05-06 05:55:50', '2025-05-06 05:55:50'),
(13, 1, 18, 2, '2025-05-06 05:57:52', '2025-05-06 05:57:52'),
(14, 1, 19, 2, '2025-05-06 05:58:52', '2025-05-06 05:58:52'),
(15, 1, 20, 2, '2025-05-06 05:59:57', '2025-05-06 05:59:57'),
(16, 1, 21, 2, '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(17, 1, 22, 2, '2025-05-06 06:09:35', '2025-05-06 06:09:35'),
(18, 1, 23, 2, '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(19, 1, 24, 2, '2025-05-06 06:14:28', '2025-05-06 07:12:17'),
(20, 1, 25, 2, '2025-05-06 07:14:21', '2025-05-06 07:14:48'),
(21, 1, 26, 1, '2025-05-06 07:15:29', '2025-05-06 07:16:09'),
(22, 1, 27, 1, '2025-05-06 07:33:11', '2025-05-06 07:33:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `email`, `password`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'specialemailid2050123@gmail.com', '123456', 1, '2025-03-08 15:16:27', '2025-05-03 20:02:54'),
(2, 'storage@admin.com', '123456', 2, '2025-03-23 20:04:50', '2025-05-01 13:26:40'),
(3, 'specialemailid205012@gmail.com', '', 3, '2025-04-28 09:05:06', '2025-04-28 09:05:06'),
(4, 'abc@gmail.com', '', 4, '2025-04-28 09:10:57', '2025-04-28 09:10:57'),
(5, 'test1@gmail.com', '1', 5, '2025-04-28 10:00:03', '2025-04-28 10:00:03'),
(6, 'specialemailid2050121@gmail.com', '123456', 6, '2025-04-30 11:37:21', '2025-04-30 11:37:21'),
(7, 'specialemailid2050122@gmail.com', '123456', 7, '2025-04-30 11:37:21', '2025-04-30 11:37:21'),
(10, 'specialemailid205012263@gmail.com', '123456', 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(11, 'specialemailid20502213232@gmail.com', '123456', 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(12, 'specialemailid20501235345@gmail.com', '123456', 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(13, 'specialemailid2050@gmail.com', 'Aa123456@', 13, '2025-05-03 20:45:38', '2025-05-04 16:54:52'),
(14, 'andoroid.mobile2050@gmail.com', '123456', 14, '2025-05-04 12:52:13', '2025-05-04 12:52:13'),
(15, 'test12@gmail.com', '12345', 15, '2025-05-05 14:31:03', '2025-05-05 14:31:03'),
(16, 'test123@gmail.com', '12345', 16, '2025-05-06 05:52:40', '2025-05-06 05:52:40'),
(17, 'test1233@gmail.com', '12345', 17, '2025-05-06 05:55:50', '2025-05-06 05:55:50'),
(18, 'test12334@gmail.com', '12345', 18, '2025-05-06 05:57:52', '2025-05-06 05:57:52'),
(19, 'test129@gmail.com', '12345', 19, '2025-05-06 05:58:52', '2025-05-06 05:58:52'),
(20, 'test1288@gmail.com', '12345', 20, '2025-05-06 05:59:57', '2025-05-06 05:59:57'),
(21, 'test1277@gmail.com', '12345', 21, '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(22, 'test1255@gmail.com', '12345', 22, '2025-05-06 06:09:35', '2025-05-06 06:09:35'),
(23, 'test12336@gmail.com', '12345', 23, '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(24, 'test121111@gmail.com', '12345', 24, '2025-05-06 06:14:28', '2025-05-06 06:14:28'),
(25, 'test12123456@gmail.com', '12345', 25, '2025-05-06 07:14:21', '2025-05-06 07:14:21'),
(26, 'test12321654987@gmail.com', '12345', 26, '2025-05-06 07:15:29', '2025-05-06 07:15:29'),
(27, 'test12657567@gmail.com', '12345', 27, '2025-05-06 07:33:11', '2025-05-06 07:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_location_relationship`
--

CREATE TABLE `tbl_user_location_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_location_relationship`
--

INSERT INTO `tbl_user_location_relationship` (`id`, `user_id`, `location_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2025-03-11 19:24:23', '2025-03-11 19:24:23'),
(2, 2, 2, '2025-03-23 20:03:40', '2025-03-23 20:03:40'),
(3, 10, 8, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(4, 11, 9, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(5, 12, 10, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(6, 13, 11, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(7, 14, 12, '2025-05-04 12:52:13', '2025-05-04 12:52:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_payment_methods_relationship`
--

CREATE TABLE `tbl_user_payment_methods_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stripe_customer_id` text NOT NULL,
  `stripe_payment_method_id` text NOT NULL,
  `is_default` text NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `card_holder_first_name` text NOT NULL,
  `card_holder_last_name` text NOT NULL,
  `card_holder_email` text NOT NULL,
  `card_holder_phone` text NOT NULL,
  `card_billing_address` text NOT NULL,
  `card_billing_zip` text NOT NULL,
  `card_type` text NOT NULL,
  `card_holder_card_number` text NOT NULL,
  `card_expiration_month` text NOT NULL,
  `card_expiration_year` int(11) NOT NULL,
  `card_cvv` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_payment_methods_relationship`
--

INSERT INTO `tbl_user_payment_methods_relationship` (`id`, `user_id`, `stripe_customer_id`, `stripe_payment_method_id`, `is_default`, `status_type_id`, `created_at`, `updated_at`, `card_holder_first_name`, `card_holder_last_name`, `card_holder_email`, `card_holder_phone`, `card_billing_address`, `card_billing_zip`, `card_type`, `card_holder_card_number`, `card_expiration_month`, `card_expiration_year`, `card_cvv`) VALUES
(10, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RGbgc08JMAyNQJTRcujWxdE', 'false', 2, '2025-04-22 17:56:12', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, ''),
(11, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RHKDF08JMAyNQJTiPpcA3Jx', 'false', 2, '2025-04-24 17:28:51', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, ''),
(12, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RHKLD08JMAyNQJTiT9vZKmJ', 'false', 2, '2025-04-24 17:37:04', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, ''),
(13, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RHKP308JMAyNQJTxuHzanHq', 'false', 2, '2025-04-24 17:41:02', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, ''),
(14, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RHLMK08JMAyNQJTk5PwDLUI', 'false', 1, '2025-04-24 18:42:18', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, ''),
(15, 1, 'cus_SAxBxoznGWuf2e', 'pm_1RJ56Q08JMAyNQJTudaI5wzm', 'true', 1, '2025-04-29 13:45:07', '2025-04-29 13:45:31', '', '', '', '', '', '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_profile_relationship`
--

CREATE TABLE `tbl_user_profile_relationship` (
  `id` int(11) NOT NULL,
  `date_of_birth` date NOT NULL,
  `time_zone` text NOT NULL,
  `hear_us` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_profile_relationship`
--

INSERT INTO `tbl_user_profile_relationship` (`id`, `date_of_birth`, `time_zone`, `hear_us`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '1995-04-27', 'Australia/Sydney', 'company_website', 1, '2025-03-11 19:27:34', '2025-05-03 20:02:54'),
(2, '1995-04-27', 'Australia/Sydney', 'company_website', 2, '2025-03-11 19:27:34', '2025-05-01 13:26:40'),
(4, '2025-05-03', 'Australia/Brisbane', '', 10, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(5, '2025-05-03', 'Australia/Brisbane', '', 11, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(6, '2025-05-09', 'Australia/Brisbane', 'referral', 12, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(7, '2025-05-03', 'Australia/Brisbane', 'linkedin', 13, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(8, '2025-05-04', 'Australia/Brisbane', '', 14, '2025-05-04 12:52:13', '2025-05-04 12:52:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role_relationship`
--

CREATE TABLE `tbl_user_role_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_role_relationship`
--

INSERT INTO `tbl_user_role_relationship` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2025-03-08 15:17:48', '2025-03-08 15:17:48'),
(2, 2, 1, '2025-03-23 20:02:08', '2025-03-23 20:02:08'),
(3, 3, 3, '2025-04-28 09:05:06', '2025-04-28 09:05:06'),
(4, 4, 3, '2025-04-28 09:10:57', '2025-04-28 09:10:57'),
(5, 5, 3, '2025-04-28 10:00:03', '2025-04-28 10:00:03'),
(6, 6, 2, '2025-04-30 11:38:16', '2025-04-30 11:38:16'),
(7, 7, 2, '2025-04-30 11:38:16', '2025-04-30 11:38:16'),
(9, 10, 2, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(10, 11, 2, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(11, 12, 2, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(12, 13, 2, '2025-05-03 20:45:38', '2025-05-03 20:45:38'),
(13, 14, 1, '2025-05-04 12:52:13', '2025-05-04 12:52:13'),
(14, 15, 3, '2025-05-05 14:31:03', '2025-05-05 14:31:03'),
(15, 16, 3, '2025-05-06 05:52:40', '2025-05-06 05:52:40'),
(16, 17, 3, '2025-05-06 05:55:50', '2025-05-06 05:55:50'),
(17, 18, 3, '2025-05-06 05:57:52', '2025-05-06 05:57:52'),
(18, 19, 3, '2025-05-06 05:58:52', '2025-05-06 05:58:52'),
(19, 20, 3, '2025-05-06 05:59:57', '2025-05-06 05:59:57'),
(20, 21, 3, '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(21, 22, 3, '2025-05-06 06:09:35', '2025-05-06 06:09:35'),
(22, 23, 3, '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(23, 24, 3, '2025-05-06 06:14:28', '2025-05-06 06:14:28'),
(24, 25, 3, '2025-05-06 07:14:21', '2025-05-06 07:14:21'),
(25, 26, 3, '2025-05-06 07:15:29', '2025-05-06 07:15:29'),
(26, 27, 3, '2025-05-06 07:33:11', '2025-05-06 07:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_status_relationship`
--

CREATE TABLE `tbl_user_status_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_status_relationship`
--

INSERT INTO `tbl_user_status_relationship` (`id`, `user_id`, `status_type_id`, `created_at`, `updated_at`) VALUES
(2, 1, 1, '2025-03-09 05:15:10', '2025-03-09 05:15:10'),
(3, 2, 1, '2025-03-23 20:04:12', '2025-03-23 20:04:12'),
(4, 3, 2, '2025-04-28 09:05:06', '2025-04-28 09:05:06'),
(5, 4, 2, '2025-04-28 09:10:57', '2025-04-28 09:10:57'),
(6, 5, 1, '2025-04-28 10:00:03', '2025-04-28 10:13:42'),
(8, 10, 2, '2025-05-03 20:37:21', '2025-05-03 20:37:21'),
(9, 11, 2, '2025-05-03 20:39:16', '2025-05-03 20:39:16'),
(10, 12, 2, '2025-05-03 20:42:57', '2025-05-03 20:42:57'),
(11, 13, 1, '2025-05-03 20:45:38', '2025-05-03 21:38:54'),
(12, 14, 1, '2025-05-04 12:52:13', '2025-05-04 12:53:58'),
(13, 15, 1, '2025-05-05 14:31:03', '2025-05-05 14:31:03'),
(14, 16, 2, '2025-05-06 05:52:40', '2025-05-06 05:52:40'),
(15, 17, 2, '2025-05-06 05:55:50', '2025-05-06 05:55:50'),
(16, 18, 2, '2025-05-06 05:57:52', '2025-05-06 05:57:52'),
(17, 19, 2, '2025-05-06 05:58:52', '2025-05-06 05:58:52'),
(18, 20, 2, '2025-05-06 05:59:57', '2025-05-06 05:59:57'),
(19, 21, 2, '2025-05-06 06:00:43', '2025-05-06 06:00:43'),
(20, 22, 2, '2025-05-06 06:09:35', '2025-05-06 06:09:35'),
(21, 23, 2, '2025-05-06 06:10:38', '2025-05-06 06:10:38'),
(22, 24, 2, '2025-05-06 06:14:28', '2025-05-06 06:14:28'),
(23, 25, 2, '2025-05-06 07:14:21', '2025-05-06 07:14:21'),
(24, 26, 2, '2025-05-06 07:15:29', '2025-05-06 07:15:29'),
(25, 27, 2, '2025-05-06 07:33:11', '2025-05-06 07:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_stripe_relationship`
--

CREATE TABLE `tbl_user_stripe_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stripe_customer_id` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_stripe_relationship`
--

INSERT INTO `tbl_user_stripe_relationship` (`id`, `user_id`, `stripe_customer_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'cus_SAxBxoznGWuf2e', '2025-04-24 13:30:55', '2025-04-24 13:30:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_verfication_relationship`
--

CREATE TABLE `tbl_user_verfication_relationship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `verfication_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_verfication_relationship`
--

INSERT INTO `tbl_user_verfication_relationship` (`id`, `user_id`, `verfication_type_id`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2025-03-08 15:21:10', '2025-03-08 15:21:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_verfication_types`
--

CREATE TABLE `tbl_verfication_types` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_verfication_types`
--

INSERT INTO `tbl_verfication_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Email', '2025-02-09 22:20:16', '2025-02-09 22:20:16'),
(2, 'Phone', '2025-02-09 22:20:16', '2025-02-09 22:20:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_auctions`
--
ALTER TABLE `tbl_auctions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auctions_release_payment_schedule`
--
ALTER TABLE `tbl_auctions_release_payment_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auction_categories`
--
ALTER TABLE `tbl_auction_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auction_category_relationship`
--
ALTER TABLE `tbl_auction_category_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `auction_category_id` (`auction_category_id`);

--
-- Indexes for table `tbl_auction_confirmations`
--
ALTER TABLE `tbl_auction_confirmations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `winner_id` (`winner_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tbl_auction_confirmations_ibfk_3` (`confirmation_type_id`);

--
-- Indexes for table `tbl_auction_confirmation_types`
--
ALTER TABLE `tbl_auction_confirmation_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auction_favorites`
--
ALTER TABLE `tbl_auction_favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_auction_release_payment_schedule`
--
ALTER TABLE `tbl_auction_release_payment_schedule`
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `auction_schedule_type_id` (`auction_schedule_type_id`);

--
-- Indexes for table `tbl_auction_schedule_types`
--
ALTER TABLE `tbl_auction_schedule_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auction_status_relationship`
--
ALTER TABLE `tbl_auction_status_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `tbl_auction_status_relationship_ibfk_2` (`auction_type_id`);

--
-- Indexes for table `tbl_auction_storage_facility_relationship`
--
ALTER TABLE `tbl_auction_storage_facility_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`);

--
-- Indexes for table `tbl_auction_types`
--
ALTER TABLE `tbl_auction_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_auction_upload_relationship`
--
ALTER TABLE `tbl_auction_upload_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `upload_id` (`upload_id`);

--
-- Indexes for table `tbl_auction_views`
--
ALTER TABLE `tbl_auction_views`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_auction_won`
--
ALTER TABLE `tbl_auction_won`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bids`
--
ALTER TABLE `tbl_bids`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_companies`
--
ALTER TABLE `tbl_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company_location_relationship`
--
ALTER TABLE `tbl_company_location_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `tbl_company_status_relationship`
--
ALTER TABLE `tbl_company_status_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `status_id` (`status_type_id`);

--
-- Indexes for table `tbl_company_verfication_relationship`
--
ALTER TABLE `tbl_company_verfication_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `verfication_type_id` (`verfication_type_id`),
  ADD KEY `status_id` (`status_id`);

--
-- Indexes for table `tbl_email_queue`
--
ALTER TABLE `tbl_email_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status_scheduled_at` (`status`,`scheduled_at`);

--
-- Indexes for table `tbl_invoices`
--
ALTER TABLE `tbl_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_invoice_auction_relationship`
--
ALTER TABLE `tbl_invoice_auction_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `auction_id` (`auction_id`),
  ADD KEY `invoice_payment_method_type_id` (`invoice_payment_method_type_id`),
  ADD KEY `invoice_type_id` (`invoice_type_id`),
  ADD KEY `invoice_payment_status_type_id` (`invoice_payment_status_type_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_invoice_payment_method_types`
--
ALTER TABLE `tbl_invoice_payment_method_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_invoice_stripe_logs_relationship`
--
ALTER TABLE `tbl_invoice_stripe_logs_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `tbl_invoice_stripe_relationship`
--
ALTER TABLE `tbl_invoice_stripe_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `tbl_invoice_types`
--
ALTER TABLE `tbl_invoice_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_locations`
--
ALTER TABLE `tbl_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_notification_types`
--
ALTER TABLE `tbl_notification_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment_types`
--
ALTER TABLE `tbl_payment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_preference_types`
--
ALTER TABLE `tbl_preference_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_role_types`
--
ALTER TABLE `tbl_role_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staff_company_access_relationship`
--
ALTER TABLE `tbl_staff_company_access_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status_id` (`status_type_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `tbl_staff_permissions`
--
ALTER TABLE `tbl_staff_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_status_types`
--
ALTER TABLE `tbl_status_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_storage_facilities`
--
ALTER TABLE `tbl_storage_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_storage_facility_company_relationship`
--
ALTER TABLE `tbl_storage_facility_company_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `tbl_storage_facility_location_relationship`
--
ALTER TABLE `tbl_storage_facility_location_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `tbl_storage_facility_staff_relationship`
--
ALTER TABLE `tbl_storage_facility_staff_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_storage_facility_status_relationship`
--
ALTER TABLE `tbl_storage_facility_status_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storage_facility_id` (`storage_facility_id`),
  ADD KEY `status_type_id` (`status_type_id`);

--
-- Indexes for table `tbl_token_activation_types`
--
ALTER TABLE `tbl_token_activation_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_activation_token`
--
ALTER TABLE `tbl_user_activation_token`
  ADD PRIMARY KEY (`id`),
  ADD KEY `token_activation_type_id` (`token_activation_type_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_user_activity`
--
ALTER TABLE `tbl_user_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_alert_settings`
--
ALTER TABLE `tbl_user_alert_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_type_id` (`notification_type_id`),
  ADD KEY `preference_type_id` (`preference_type_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status_type_id` (`status_type_id`);

--
-- Indexes for table `tbl_user_bank_informations_relationship`
--
ALTER TABLE `tbl_user_bank_informations_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- Indexes for table `tbl_user_company_relationship`
--
ALTER TABLE `tbl_user_company_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status_type_id` (`status_type_id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_user_credentials_ibfk_1` (`user_id`);

--
-- Indexes for table `tbl_user_location_relationship`
--
ALTER TABLE `tbl_user_location_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `tbl_user_payment_methods_relationship`
--
ALTER TABLE `tbl_user_payment_methods_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status_type_id` (`status_type_id`);

--
-- Indexes for table `tbl_user_profile_relationship`
--
ALTER TABLE `tbl_user_profile_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_user_role_relationship`
--
ALTER TABLE `tbl_user_role_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `tbl_user_status_relationship`
--
ALTER TABLE `tbl_user_status_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status_id` (`status_type_id`);

--
-- Indexes for table `tbl_user_stripe_relationship`
--
ALTER TABLE `tbl_user_stripe_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_user_verfication_relationship`
--
ALTER TABLE `tbl_user_verfication_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `verfication_type_id` (`verfication_type_id`),
  ADD KEY `status_id` (`status_id`);

--
-- Indexes for table `tbl_verfication_types`
--
ALTER TABLE `tbl_verfication_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_auctions`
--
ALTER TABLE `tbl_auctions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_auctions_release_payment_schedule`
--
ALTER TABLE `tbl_auctions_release_payment_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_auction_categories`
--
ALTER TABLE `tbl_auction_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_auction_category_relationship`
--
ALTER TABLE `tbl_auction_category_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_auction_confirmations`
--
ALTER TABLE `tbl_auction_confirmations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_auction_confirmation_types`
--
ALTER TABLE `tbl_auction_confirmation_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_auction_favorites`
--
ALTER TABLE `tbl_auction_favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `tbl_auction_schedule_types`
--
ALTER TABLE `tbl_auction_schedule_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_auction_status_relationship`
--
ALTER TABLE `tbl_auction_status_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_auction_storage_facility_relationship`
--
ALTER TABLE `tbl_auction_storage_facility_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_auction_types`
--
ALTER TABLE `tbl_auction_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_auction_upload_relationship`
--
ALTER TABLE `tbl_auction_upload_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_auction_views`
--
ALTER TABLE `tbl_auction_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_auction_won`
--
ALTER TABLE `tbl_auction_won`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bids`
--
ALTER TABLE `tbl_bids`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `tbl_companies`
--
ALTER TABLE `tbl_companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_company_location_relationship`
--
ALTER TABLE `tbl_company_location_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_company_status_relationship`
--
ALTER TABLE `tbl_company_status_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_company_verfication_relationship`
--
ALTER TABLE `tbl_company_verfication_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_email_queue`
--
ALTER TABLE `tbl_email_queue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `tbl_invoices`
--
ALTER TABLE `tbl_invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_invoice_auction_relationship`
--
ALTER TABLE `tbl_invoice_auction_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_invoice_payment_method_types`
--
ALTER TABLE `tbl_invoice_payment_method_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_invoice_stripe_logs_relationship`
--
ALTER TABLE `tbl_invoice_stripe_logs_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_invoice_stripe_relationship`
--
ALTER TABLE `tbl_invoice_stripe_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_invoice_types`
--
ALTER TABLE `tbl_invoice_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_locations`
--
ALTER TABLE `tbl_locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_notification_types`
--
ALTER TABLE `tbl_notification_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_payment_types`
--
ALTER TABLE `tbl_payment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_preference_types`
--
ALTER TABLE `tbl_preference_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_role_types`
--
ALTER TABLE `tbl_role_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_staff_company_access_relationship`
--
ALTER TABLE `tbl_staff_company_access_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_staff_permissions`
--
ALTER TABLE `tbl_staff_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_status_types`
--
ALTER TABLE `tbl_status_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_storage_facilities`
--
ALTER TABLE `tbl_storage_facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_storage_facility_company_relationship`
--
ALTER TABLE `tbl_storage_facility_company_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_storage_facility_location_relationship`
--
ALTER TABLE `tbl_storage_facility_location_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_storage_facility_staff_relationship`
--
ALTER TABLE `tbl_storage_facility_staff_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_storage_facility_status_relationship`
--
ALTER TABLE `tbl_storage_facility_status_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_token_activation_types`
--
ALTER TABLE `tbl_token_activation_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_user_activation_token`
--
ALTER TABLE `tbl_user_activation_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_user_activity`
--
ALTER TABLE `tbl_user_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user_alert_settings`
--
ALTER TABLE `tbl_user_alert_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_user_bank_informations_relationship`
--
ALTER TABLE `tbl_user_bank_informations_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user_company_relationship`
--
ALTER TABLE `tbl_user_company_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_user_location_relationship`
--
ALTER TABLE `tbl_user_location_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_user_payment_methods_relationship`
--
ALTER TABLE `tbl_user_payment_methods_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_user_profile_relationship`
--
ALTER TABLE `tbl_user_profile_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user_role_relationship`
--
ALTER TABLE `tbl_user_role_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_user_status_relationship`
--
ALTER TABLE `tbl_user_status_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_user_stripe_relationship`
--
ALTER TABLE `tbl_user_stripe_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user_verfication_relationship`
--
ALTER TABLE `tbl_user_verfication_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_verfication_types`
--
ALTER TABLE `tbl_verfication_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_auction_category_relationship`
--
ALTER TABLE `tbl_auction_category_relationship`
  ADD CONSTRAINT `tbl_auction_category_relationship_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_category_relationship_ibfk_2` FOREIGN KEY (`auction_category_id`) REFERENCES `tbl_auction_categories` (`id`);

--
-- Constraints for table `tbl_auction_confirmations`
--
ALTER TABLE `tbl_auction_confirmations`
  ADD CONSTRAINT `tbl_auction_confirmations_ibfk_1` FOREIGN KEY (`winner_id`) REFERENCES `tbl_auction_won` (`id`),
  ADD CONSTRAINT `tbl_auction_confirmations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_auction_confirmations_ibfk_3` FOREIGN KEY (`confirmation_type_id`) REFERENCES `tbl_auction_confirmation_types` (`id`);

--
-- Constraints for table `tbl_auction_favorites`
--
ALTER TABLE `tbl_auction_favorites`
  ADD CONSTRAINT `tbl_auction_favorites_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_favorites_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_auction_release_payment_schedule`
--
ALTER TABLE `tbl_auction_release_payment_schedule`
  ADD CONSTRAINT `tbl_auction_release_payment_schedule_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_release_payment_schedule_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_auction_release_payment_schedule_ibfk_3` FOREIGN KEY (`auction_schedule_type_id`) REFERENCES `tbl_auction_schedule_types` (`id`);

--
-- Constraints for table `tbl_auction_status_relationship`
--
ALTER TABLE `tbl_auction_status_relationship`
  ADD CONSTRAINT `tbl_auction_status_relationship_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_status_relationship_ibfk_2` FOREIGN KEY (`auction_type_id`) REFERENCES `tbl_auction_types` (`id`);

--
-- Constraints for table `tbl_auction_storage_facility_relationship`
--
ALTER TABLE `tbl_auction_storage_facility_relationship`
  ADD CONSTRAINT `tbl_auction_storage_facility_relationship_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_storage_facility_relationship_ibfk_2` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`);

--
-- Constraints for table `tbl_auction_upload_relationship`
--
ALTER TABLE `tbl_auction_upload_relationship`
  ADD CONSTRAINT `tbl_auction_upload_relationship_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_upload_relationship_ibfk_2` FOREIGN KEY (`upload_id`) REFERENCES `tbl_uploads` (`id`);

--
-- Constraints for table `tbl_auction_views`
--
ALTER TABLE `tbl_auction_views`
  ADD CONSTRAINT `tbl_auction_views_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_views_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_auction_won`
--
ALTER TABLE `tbl_auction_won`
  ADD CONSTRAINT `tbl_auction_won_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_auction_won_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_bids`
--
ALTER TABLE `tbl_bids`
  ADD CONSTRAINT `tbl_bids_ibfk_1` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_company_location_relationship`
--
ALTER TABLE `tbl_company_location_relationship`
  ADD CONSTRAINT `tbl_company_location_relationship_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`),
  ADD CONSTRAINT `tbl_company_location_relationship_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `tbl_locations` (`id`);

--
-- Constraints for table `tbl_company_status_relationship`
--
ALTER TABLE `tbl_company_status_relationship`
  ADD CONSTRAINT `tbl_company_status_relationship_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`),
  ADD CONSTRAINT `tbl_company_status_relationship_ibfk_2` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_company_verfication_relationship`
--
ALTER TABLE `tbl_company_verfication_relationship`
  ADD CONSTRAINT `tbl_company_verfication_relationship_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`),
  ADD CONSTRAINT `tbl_company_verfication_relationship_ibfk_2` FOREIGN KEY (`verfication_type_id`) REFERENCES `tbl_verfication_types` (`id`),
  ADD CONSTRAINT `tbl_company_verfication_relationship_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_invoice_auction_relationship`
--
ALTER TABLE `tbl_invoice_auction_relationship`
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tbl_invoices` (`id`),
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_2` FOREIGN KEY (`auction_id`) REFERENCES `tbl_auctions` (`id`),
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_3` FOREIGN KEY (`invoice_payment_method_type_id`) REFERENCES `tbl_invoice_payment_method_types` (`id`),
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_4` FOREIGN KEY (`invoice_type_id`) REFERENCES `tbl_invoice_types` (`id`),
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_5` FOREIGN KEY (`invoice_payment_status_type_id`) REFERENCES `tbl_payment_types` (`id`),
  ADD CONSTRAINT `tbl_invoice_auction_relationship_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_invoice_stripe_logs_relationship`
--
ALTER TABLE `tbl_invoice_stripe_logs_relationship`
  ADD CONSTRAINT `tbl_invoice_stripe_logs_relationship_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tbl_invoices` (`id`);

--
-- Constraints for table `tbl_invoice_stripe_relationship`
--
ALTER TABLE `tbl_invoice_stripe_relationship`
  ADD CONSTRAINT `tbl_invoice_stripe_relationship_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tbl_invoices` (`id`);

--
-- Constraints for table `tbl_staff_company_access_relationship`
--
ALTER TABLE `tbl_staff_company_access_relationship`
  ADD CONSTRAINT `tbl_staff_company_access_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_staff_company_access_relationship_ibfk_2` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`),
  ADD CONSTRAINT `tbl_staff_company_access_relationship_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`);

--
-- Constraints for table `tbl_staff_permissions`
--
ALTER TABLE `tbl_staff_permissions`
  ADD CONSTRAINT `tbl_staff_permissions_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`),
  ADD CONSTRAINT `tbl_staff_permissions_ibfk_2` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`),
  ADD CONSTRAINT `tbl_staff_permissions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_storage_facility_company_relationship`
--
ALTER TABLE `tbl_storage_facility_company_relationship`
  ADD CONSTRAINT `tbl_storage_facility_company_relationship_ibfk_1` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`),
  ADD CONSTRAINT `tbl_storage_facility_company_relationship_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`);

--
-- Constraints for table `tbl_storage_facility_location_relationship`
--
ALTER TABLE `tbl_storage_facility_location_relationship`
  ADD CONSTRAINT `tbl_storage_facility_location_relationship_ibfk_1` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`),
  ADD CONSTRAINT `tbl_storage_facility_location_relationship_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `tbl_locations` (`id`);

--
-- Constraints for table `tbl_storage_facility_staff_relationship`
--
ALTER TABLE `tbl_storage_facility_staff_relationship`
  ADD CONSTRAINT `tbl_storage_facility_staff_relationship_ibfk_1` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`),
  ADD CONSTRAINT `tbl_storage_facility_staff_relationship_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_storage_facility_status_relationship`
--
ALTER TABLE `tbl_storage_facility_status_relationship`
  ADD CONSTRAINT `tbl_storage_facility_status_relationship_ibfk_1` FOREIGN KEY (`storage_facility_id`) REFERENCES `tbl_storage_facilities` (`id`),
  ADD CONSTRAINT `tbl_storage_facility_status_relationship_ibfk_2` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_user_activation_token`
--
ALTER TABLE `tbl_user_activation_token`
  ADD CONSTRAINT `tbl_user_activation_token_ibfk_1` FOREIGN KEY (`token_activation_type_id`) REFERENCES `tbl_token_activation_types` (`id`),
  ADD CONSTRAINT `tbl_user_activation_token_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_user_activity`
--
ALTER TABLE `tbl_user_activity`
  ADD CONSTRAINT `tbl_user_activity_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_user_alert_settings`
--
ALTER TABLE `tbl_user_alert_settings`
  ADD CONSTRAINT `tbl_user_alert_settings_ibfk_1` FOREIGN KEY (`notification_type_id`) REFERENCES `tbl_notification_types` (`id`),
  ADD CONSTRAINT `tbl_user_alert_settings_ibfk_2` FOREIGN KEY (`preference_type_id`) REFERENCES `tbl_preference_types` (`id`),
  ADD CONSTRAINT `tbl_user_alert_settings_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_alert_settings_ibfk_4` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_user_bank_informations_relationship`
--
ALTER TABLE `tbl_user_bank_informations_relationship`
  ADD CONSTRAINT `tbl_user_bank_informations_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_bank_informations_relationship_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `tbl_user_bank_informations_relationship` (`id`);

--
-- Constraints for table `tbl_user_company_relationship`
--
ALTER TABLE `tbl_user_company_relationship`
  ADD CONSTRAINT `tbl_user_company_relationship_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_companies` (`id`),
  ADD CONSTRAINT `tbl_user_company_relationship_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_company_relationship_ibfk_3` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD CONSTRAINT `tbl_user_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_user_location_relationship`
--
ALTER TABLE `tbl_user_location_relationship`
  ADD CONSTRAINT `tbl_user_location_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_location_relationship_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `tbl_locations` (`id`);

--
-- Constraints for table `tbl_user_payment_methods_relationship`
--
ALTER TABLE `tbl_user_payment_methods_relationship`
  ADD CONSTRAINT `tbl_user_payment_methods_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_payment_methods_relationship_ibfk_2` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_user_profile_relationship`
--
ALTER TABLE `tbl_user_profile_relationship`
  ADD CONSTRAINT `tbl_user_profile_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_user_role_relationship`
--
ALTER TABLE `tbl_user_role_relationship`
  ADD CONSTRAINT `tbl_user_role_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_role_relationship_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `tbl_role_types` (`id`);

--
-- Constraints for table `tbl_user_status_relationship`
--
ALTER TABLE `tbl_user_status_relationship`
  ADD CONSTRAINT `tbl_user_status_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_status_relationship_ibfk_2` FOREIGN KEY (`status_type_id`) REFERENCES `tbl_status_types` (`id`);

--
-- Constraints for table `tbl_user_stripe_relationship`
--
ALTER TABLE `tbl_user_stripe_relationship`
  ADD CONSTRAINT `tbl_user_stripe_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`);

--
-- Constraints for table `tbl_user_verfication_relationship`
--
ALTER TABLE `tbl_user_verfication_relationship`
  ADD CONSTRAINT `tbl_user_verfication_relationship_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  ADD CONSTRAINT `tbl_user_verfication_relationship_ibfk_2` FOREIGN KEY (`verfication_type_id`) REFERENCES `tbl_verfication_types` (`id`),
  ADD CONSTRAINT `tbl_user_verfication_relationship_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `tbl_status_types` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
