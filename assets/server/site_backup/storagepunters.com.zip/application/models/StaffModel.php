<?php
defined('BASEPATH') or exit('No direct script access allowed');

class StaffModel extends CI_Model
{
    protected $users_table = 'tbl_users';
    protected $user_passwords_table = 'tbl_user_credentials';
    protected $user_status_table = 'tbl_user_status_relationship';
    protected $user_roles_table = 'tbl_user_role_relationship';

    protected $roles_table = 'tbl_role_types';
    protected $status_table = 'tbl_status_types';

    protected $user_company_relationship_table = 'tbl_user_company_relationship';
    private function applySearchFilter($search)
    {
        $this->db->group_start();
        $this->db->or_like('sf.name', $search);
        $this->db->group_end();
    }

    public function countAllStaff()
    {
        return $this->db->count_all($this->users_table);
    }

    public function countFilteredStaff($search, $company_id)
    {

        $this->db->select('COUNT(*) as count');
        $this->db->from($this->users_table . ' u');
        $this->db->join($this->user_passwords_table . ' uc', 'uc.user_id = u.id', 'left');
        $this->db->join($this->user_status_table . ' us', 'us.user_id = u.id', 'left');
        $this->db->join($this->status_table . ' s', 's.id = us.status_type_id', 'left');
        $this->db->join($this->user_roles_table . ' ur', 'ur.user_id = u.id', 'left');
        $this->db->join($this->user_company_relationship_table . ' ucr', 'ucr.user_id = u.id', 'left');
        $this->db->where('ucr.company_id', $company_id);
        $this->db->where('ur.role_id', 3);
        if (!empty($search)) {
            $this->applySearchFilter($search);
        }

        return $this->db->get()->row()->count;
    }

    public function getFilteredStaffById($start, $length, $search, $orderColumnIndex, $orderDirIndex, $company_id)
    {


        $orderColumn = 'u.updated_at'; // Default column
        $orderDir = 'DESC'; // Default direction

        $this->db->select('u.id as staff_member_id,
        u.first_name as staff_member_first_name,
        u.last_name as staff_member_last_name,
        uc.email as staff_member_email,
        s.name as staff_member_status,
        u.created_at as staff_member_created_at,
        ');
        $this->db->from($this->users_table . ' u');
        $this->db->join($this->user_passwords_table . ' uc', 'uc.user_id = u.id', 'left');
        $this->db->join($this->user_roles_table . ' ur', 'ur.user_id = u.id', 'left');
        $this->db->join($this->user_company_relationship_table . ' ucr', 'ucr.user_id = u.id', 'left');
        $this->db->join($this->status_table . ' s', 's.id = ucr.status_type_id', 'left');
        $this->db->where('ucr.company_id', $company_id);
        $this->db->where('ur.role_id', 3);
        if (!empty($search)) {
            $this->applySearchFilter($search);
        }
        // Apply ordering
        $this->db->order_by($orderColumn, $orderDir);

        $this->db->limit($length, $start);

        return $this->db->get()->result_array();
    }


    public function insert_staff_data($staffMemberData)
    {
        $this->db->insert($this->users_table, $staffMemberData);
        return [
            'staff_member_id' => $this->db->insert_id()
        ];
    }

    public function insert_staff_credentials_data($staffMemberCredentialsData)
    {
        return $this->db->insert($this->user_passwords_table, $staffMemberCredentialsData);
    }

    public function insert_staff_role_data($staffMemberRoleData)
    {
        return $this->db->insert($this->user_roles_table, $staffMemberRoleData);
    }

    public function insert_staff_status_data($staffMemberStatusData)
    {
        return $this->db->insert($this->user_status_table, $staffMemberStatusData);
    }

    public function insert_staff_company_data($staffMemberCompanyData)
    {
        return $this->db->insert($this->user_company_relationship_table, $staffMemberCompanyData);
    }

    public function updateStaffMemberStatusData($staff_member_id,  $company_id, $staffMemberStatusData)
    {
        $this->db->where('user_id', $staff_member_id); // Match the user ID
        $this->db->where('company_id', $company_id); // Match the user ID
        $this->db->update($this->user_company_relationship_table, $staffMemberStatusData);

        return $this->db->affected_rows() > 0; // Return true if update was successful
    }

    public function updateStaffMemberData($staff_member_id, $staffMemberData)
    {
        $this->db->where('id', $staff_member_id); // Match the user ID
        $this->db->update($this->users_table, $staffMemberData);

        return $this->db->affected_rows() > 0; // Return true if update was successful
    }
}
