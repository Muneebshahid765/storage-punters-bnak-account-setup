<?php
defined('BASEPATH') or exit('No direct script access allowed');

class BankModel extends CI_Model
{

    protected $bank_table = 'tbl_bank';
    protected $bank_user_relationship_table = 'tbl_user_bank_informations_relationship';

    public function insertStorageFacilityBankData($bankAccountInfo)
    {
        $this->db->insert($this->bank_table, $bankAccountInfo);
        return [
            'bank_account_id' => $this->db->insert_id()
        ];
    }

    public function insertStorageFacilityBankUserRelationshipData($bankAccountUserRelationshipData)
    {
        return $this->db->insert($this->bank_user_relationship_table, $bankAccountUserRelationshipData);
    }

    public function getBankByUserId($user_id)
    {

        $this->db->where('user_id', $user_id);
        $query = $this->db->get($this->bank_user_relationship_table);

        if ($query->num_rows() > 0) {
            return $query->row_array(); // Return bank details as an array
        } else {
            return null; // bank not found
        }
    }

    public function getBankByIdWithUserId($bankId, $user_id)
    {
        $this->db->where('bank_id', $bankId);
        $this->db->where('user_id', $user_id);
        $query = $this->db->get($this->bank_user_relationship_table);

        if ($query->num_rows() > 0) {
            return $query->row_array(); // Return bank details as an array
        } else {
            return null; // bank not found
        }
    }


    public function getBankById($bankId)
    {
        $this->db->where('id', $bankId);
        $query = $this->db->get($this->bank_table);

        if ($query->num_rows() > 0) {
            return $query->row_array(); // Return company details as an array
        } else {
            return null; // company not found
        }
    }
}
