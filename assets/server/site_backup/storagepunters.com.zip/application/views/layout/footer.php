<footer>
    <div style="background-color: rgb(0, 117, 80);" class="footer px-2 py-md-0 py-md-3 container-fluid">
        <div class="footer__ d-flex customContainer justify-content-center align-items-center container-fluid">
            <div class="h-100 w-100 align-items-center justify-content-between row">
                <div class="px-0 col-md-auto">
                    <section class="d-flex justify-content-center flex-column align-items-center mt-3 d-md-block">
                        <button type="button" style="height: 44px; min-width: max-content; width: max-content;"
                            class="btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center align-items-center __header__btn __header__login__btn  d-sm-flex me-2 outline-dark-btn btn btn-primary"
                            data-bs-toggle="modal" data-bs-target="#registerModal">
                            <div class="me-2" style="color: inherit;">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1 d-flex d-md-none" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                                </svg>
                            </div>Register Now
                        </button>
                    </section>
                </div>
                <div class="ms-md-5 px-0 col">
                    <div class="footer__links__container mt-5 justify-content-between justify-content-md-end row">
                        <div class=" footer__links mt-2 pe-2 mt-md-3 col-md-6">
                            <h4 style="color: rgb(230, 206, 139);" class="mb-3">Online Auctions Contact</h4>
                            <ul>
                                <li class="d-flex w-100 "><span><svg style="flex-shrink: 0;" xmlns="http://www.w3.org/2000/svg" width="15px" height="15px" viewBox="0 0 17.903 21.437">
                                            <g id="Icon_feather-map-pin" dataName="Icon feather-map-pin" transform="translate(-3.5 -0.5)">
                                                <path id="Path_63827" dataName="Path 63827" d="M20.4,9.451c0,6.184-7.951,11.485-7.951,11.485S4.5,15.636,4.5,9.451a7.951,7.951,0,1,1,15.9,0Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                                <path id="Path_63828" data-name="Path 63828" d="M18.8,13.15a2.65,2.65,0,1,1-2.65-2.65A2.65,2.65,0,0,1,18.8,13.15Z" transform="translate(-3.699 -3.699)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                            </g>
                                        </svg></span>
                                    <p class="ms-3 mb-0">Shop 14 /380 Mons Road, Forest Glen QLD 4556</p>
                                </li>
                                <li class="d-flex align-items-start "> <span><svg xmlns="http://www.w3.org/2000/svg" width="15px" height="15px" viewBox="0 0 19.942 19.976">
                                            <path id="Icon_feather-phone-call" data-name="Icon feather-phone-call" d="M14.215,4.916a4.269,4.269,0,0,1,3.373,3.373M14.215,1.5A7.685,7.685,0,0,1,21,8.28m-.854,6.814v2.562a1.708,1.708,0,0,1-1.861,1.708,16.9,16.9,0,0,1-7.369-2.621A16.651,16.651,0,0,1,5.8,11.618a16.9,16.9,0,0,1-2.621-7.4,1.708,1.708,0,0,1,1.7-1.861H7.436A1.708,1.708,0,0,1,9.143,3.823a10.964,10.964,0,0,0,.6,2.4,1.708,1.708,0,0,1-.384,1.8L8.272,9.108A13.662,13.662,0,0,0,13.4,14.231l1.084-1.084a1.708,1.708,0,0,1,1.8-.384,10.964,10.964,0,0,0,2.4.6A1.708,1.708,0,0,1,20.15,15.094Z" transform="translate(-2.167 -0.396)" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                        </svg></span>
                                    <p class="ms-3 mb-0"><a class="text-white text-decoration-none" href="tel:1300 136 851<">1300 136 851</a></p>
                                </li>
                                <li class="d-flex align-items-start "> <span><svg xmlns="http://www.w3.org/2000/svg" width="15px" height="15px" viewBox="0 0 19.842 15.874">
                                            <path id="Icon_material-mail-outline" dataName="Icon material-mail-outline" d="M20.858,6H4.984A1.982,1.982,0,0,0,3.01,7.984L3,19.889a1.99,1.99,0,0,0,1.984,1.984H20.858a1.99,1.99,0,0,0,1.984-1.984V7.984A1.99,1.99,0,0,0,20.858,6Zm0,13.889H4.984V9.968l7.937,4.96,7.937-4.96Zm-7.937-6.945L4.984,7.984H20.858Z" transform="translate(-3 -6)" fill="#fff"></path>
                                        </svg></span>
                                    <p class="ms-3 mb-0"><a class="text-white text-decoration-none" href="mailto:hello@mammothstorage.com.au">hello@mammothstorage.com.au</a> </p>
                                </li>
                            </ul>
                            <h4 class="mb-3">Online Auctions Customer Services Hours</h4>
                            <ul>
                                <li class="d-flex align-items-start"><span><svg xmlns="http://www.w3.org/2000/svg" width="15px" height="15px" viewBox="0 0 23.273 23.273">
                                            <g id="Icon_feather-clock" dataName="Icon feather-clock" transform="translate(-1.5 -1.5)">
                                                <path id="Path_63829" dataName="Path 63829" d="M23.273,13.137A10.137,10.137,0,1,1,13.137,3,10.137,10.137,0,0,1,23.273,13.137Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"></path>
                                                <path id="Path_63830" dataName="Path 63830" d="M18,9v6.082l4.055,2.027" transform="translate(-4.863 -1.945)" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" fill="#fff"></path>
                                            </g>
                                        </svg></span>
                                    <div class="ms-3">
                                        <p class="mb-0">Monday - Friday: 8:30 AM - 05:00 PM</p>
                                        <p class="mb-0">Saturday: 08:30 AM - 01:00 PM</p>
                                        <p class="mb-0">Sunday: 09:00 AM - 12:00 PM</p>
                                        <p class="mb-0">Closed on Public Holidays (please contact us via chat or email)</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="footer__links mt-2 pe-2 mt-md-3 col-md-2">
                            <h4 style="color: rgb(230, 206, 139);" class="mb-3">Quick links</h4>
                            <ul>
                                <li><a style="color: white; text-decoration: none;" href='<?php echo site_url("auctions"); ?>'>Auctions Search</a></li>
                                <li id="footerLogin"><a style="color: white; text-decoration: none;" href='<?php echo site_url("login"); ?>'>Login</a></li>
                                <li><a style="color: white; text-decoration: none;" href='<?php echo site_url("about-us"); ?>'>About Us</a></li>
                                <li><a style="color: white; text-decoration: none;" href='<?php echo site_url("terms-and-conditions"); ?>'>Terms</a></li>
                                <li id="footerRegisterNow" style="color: white; text-decoration: none;"><a style="color: white; text-decoration: none;">Register Today!</a></li>
                            </ul>
                        </div>
                        <div class="footer__links mt-2 mt-md-3 col-md-4">
                            <h4 style="color: rgb(230, 206, 139);" class="mb-3">Live Auction, Legal Notices &amp; General Inquiries</h4>
                            <ul>
                                <li class="d-flex align-items-start ">
                                    <p class="ms-3 mb-0"><a class="text-white text-decoration-none">Tobias Constantinides</a></p>
                                </li>
                                <li class="d-flex align-items-start "> <span><svg xmlns="http://www.w3.org/2000/svg" width="15px" height="15px" viewBox="0 0 19.942 19.976">
                                            <path id="Icon_feather-phone-call" data-name="Icon feather-phone-call" d="M14.215,4.916a4.269,4.269,0,0,1,3.373,3.373M14.215,1.5A7.685,7.685,0,0,1,21,8.28m-.854,6.814v2.562a1.708,1.708,0,0,1-1.861,1.708,16.9,16.9,0,0,1-7.369-2.621A16.651,16.651,0,0,1,5.8,11.618a16.9,16.9,0,0,1-2.621-7.4,1.708,1.708,0,0,1,1.7-1.861H7.436A1.708,1.708,0,0,1,9.143,3.823a10.964,10.964,0,0,0,.6,2.4,1.708,1.708,0,0,1-.384,1.8L8.272,9.108A13.662,13.662,0,0,0,13.4,14.231l1.084-1.084a1.708,1.708,0,0,1,1.8-.384,10.964,10.964,0,0,0,2.4.6A1.708,1.708,0,0,1,20.15,15.094Z" transform="translate(-2.167 -0.396)" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                        </svg></span>
                                    <p class="ms-3 mb-0"><a class="text-white text-decoration-none" href="tel:1300 136 851">1300 136 851</a></p>
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="bottom__bar container-fluid">
    <div class="customContainer container-fluid">
        <div class="h-100 justify-content-lg-between align-items-center px-2 row">
            <div class="bottom__bar__partners font-lighter opacity-80 col-lg-auto col-md-6 col-sm-6 col-12">Website by Storage Punters</div>
            <div class="bottom__bar__socialLinks text-100 mt-2 mt-md-0 col-lg-auto col-md-3 col-sm-6 col-12">
                <div style="cursor:pointer"><a class="text-white" href="https://www.facebook.com/StoragePunters/" target="_blank"> <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
                        </svg></a></div>
                <div style="cursor:pointer"><a class="text-white" href="https://www.instagram.com/storagepunters/" target="_blank"> <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M512 306.9c-113.5 0-205.1 91.6-205.1 205.1S398.5 717.1 512 717.1 717.1 625.5 717.1 512 625.5 306.9 512 306.9zm0 338.4c-73.4 0-133.3-59.9-133.3-133.3S438.6 378.7 512 378.7 645.3 438.6 645.3 512 585.4 645.3 512 645.3zm213.5-394.6c-26.5 0-47.9 21.4-47.9 47.9s21.4 47.9 47.9 47.9 47.9-21.3 47.9-47.9a47.84 47.84 0 0 0-47.9-47.9zM911.8 512c0-55.2.5-109.9-2.6-165-3.1-64-17.7-120.8-64.5-167.6-46.9-46.9-103.6-61.4-167.6-64.5-55.2-3.1-109.9-2.6-165-2.6-55.2 0-109.9-.5-165 2.6-64 3.1-120.8 17.7-167.6 64.5C132.6 226.3 118.1 283 115 347c-3.1 55.2-2.6 109.9-2.6 165s-.5 109.9 2.6 165c3.1 64 17.7 120.8 64.5 167.6 46.9 46.9 103.6 61.4 167.6 64.5 55.2 3.1 109.9 2.6 165 2.6 55.2 0 109.9.5 165-2.6 64-3.1 120.8-17.7 167.6-64.5 46.9-46.9 61.4-103.6 64.5-167.6 3.2-55.1 2.6-109.8 2.6-165zm-88 235.8c-7.3 18.2-16.1 31.8-30.2 45.8-14.1 14.1-27.6 22.9-45.8 30.2C695.2 844.7 570.3 840 512 840c-58.3 0-183.3 4.7-235.9-16.1-18.2-7.3-31.8-16.1-45.8-30.2-14.1-14.1-22.9-27.6-30.2-45.8C179.3 695.2 184 570.3 184 512c0-58.3-4.7-183.3 16.1-235.9 7.3-18.2 16.1-31.8 30.2-45.8s27.6-22.9 45.8-30.2C328.7 179.3 453.7 184 512 184s183.3-4.7 235.9 16.1c18.2 7.3 31.8 16.1 45.8 30.2 14.1 14.1 22.9 27.6 30.2 45.8C844.7 328.7 840 453.7 840 512c0 58.3 4.7 183.2-16.2 235.8z"></path>
                        </svg></a></div>
                <div style="cursor:pointer"><a class="text-white" href="https://twitter.com/storage_punters" target="_blank"> <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                        </svg></a></div>
                <div style="cursor:pointer"><a class="text-white text-decoration-none" href="mailto:hello@mammothstorage.com.au"><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg></a></div>
            </div>
            <div class="bottom__bar__copyRight mt-2 mt-md-0 font-lighter opacity-80 col-lg-auto col-md-3 col-sm-12 col-12">Copyright © <!-- -->2025<!-- --> <!-- -->Storage Punters</div>
        </div>
    </div>
</div>


<!-- Modal -->
<div id="registerModal" class="modal fade" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="pb-4 container-fluid">
                    <div class="register__options__container mx-auto mt-4 mb-4">
                        <h1 class="text-grey text-center pt-4 pb-0" style="font-weight: bold;">Register as a</h1>
                        <div class="justify-content-between gap-4 mt-4 align-items-center px-sm-3 px-md-0 mx-3 mx-sm-0 row">
                            <div class="register__options mt-4 col">
                                <div class="register__option register__option__active">
                                    <h2>Bidder</h2>
                                    <div class="register__option__icon">
                                        <img src="<?= base_url('assets/images/home/bidder-icon.png') ?>" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="register__options mt-4 col">
                                <div class="register__option register__option__active">
                                    <h2>Storage Facility</h2>
                                    <div class="register__option__icon">
                                        <img src="<?= base_url('assets/images/home/storage_facility-icon.png') ?>" alt="icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="auctionAgreementModal" tabindex="-1" aria-labelledby="auctionAgreementModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Auction Agreement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>
                    By confirming, both buyer and seller agree to the terms of the auction and commit to fulfill their obligations.
                </p>
                <!-- Add more legal content if needed -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" id="confirmAuctionAgreementBtn">I Agree</button>
            </div>
        </div>
    </div>
</div>


<!-- Spinner overlay -->
<div id="spinner-overlay" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); z-index:9999;">
    <div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);">
        <div class="spinner-border text-light" role="status"></div>
    </div>
</div>