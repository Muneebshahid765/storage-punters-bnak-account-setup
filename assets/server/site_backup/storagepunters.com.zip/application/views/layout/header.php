<header class="nav-scroll">
    <div class="header px-0 px-md-2 bg-transparent container-fluid">
        <div class="d-flex align-items-center h-100 customContainer mx-auto container-fluid">
            <section class="false"><a href="<?php echo site_url(); ?>"><img style="mix-blend-mode:darken" src="<?= base_url('assets/images/logo2.jpeg') ?>" alt="Self Storage Auction" class="header__logo"></a></section>

            <section class="header__links d-none d-lg-block h-100">
                <ul class="d-flex list-unstyled w-100 align-items-center justify-content-end justify-content-xl-center h-100">
                    <li class=" text-white false"><a class="text-200" href="<?php echo site_url(); ?>">Home</a></li>
                    <li class=" text-grey false"><a class="text-200" href='<?php echo site_url("auctions"); ?>'>Auctions</a></li>
                    <li class=" text-grey false"><a class="text-200" href='<?php echo site_url("faqs"); ?>'>FAQs</a></li>
                    <li class=" text-grey false"><a class="text-200" href='<?php echo site_url("contact-us"); ?>'>Contact</a></li>
                </ul>
            </section>
            <section class="position-relative  d-flex h-100  d-md-flex align-items-center ms-auto  ">


                <?php if (!isset($_SESSION['auction_user_session_data'])) { ?>

                    <div class="me-2 __header__login__btn bg-white d-none d-sm-flex align-items-center justify-content-center" style="width: 44px; height: 44px; flex-shrink: 0; border-radius: 50%; border: 2px solid var(--border-active); cursor: pointer;">
                        <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" color="black" class=" " style="color: black;" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                    </div>

                    <button type="button" style="height: 44px; min-width: max-content; width: 100%;"
                        class="btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center align-items-center __header__btn __header__login__btn d-none d-sm-flex me-2 outline-dark-btn btn btn-primary"
                        data-bs-toggle="modal" data-bs-target="#registerModal">
                        <div class="me-2" style="color: inherit;">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1 d-flex d-md-none" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                            </svg>
                        </div>Register Now
                    </button>

                    <button type="button" style="height: 44px; min-width: max-content; width: 100%;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center align-items-center  __header__btn __system__user__login__btn __header__login__btn d-flex outline-dark-btn btn btn-primary">
                        <div class="me-2 " style="color: inherit;">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1 d-flex d-md-none" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                            </svg>
                        </div>Log in
                    </button>

                <?php } else { ?>

                    <div class="profile-btn d-lg-none d-flex ms-auto ">
                        <button type="button" class="bg-transparent text-dark border-0 btn btn-primary">
                            <span class="d-flex align-items-center gap-1">
                                <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path>
                                </svg>
                                <span class="dropdown-icon">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M256 294.1L383 167c9.4-9.4 24.6-9.4 33.9 0s9.3 24.6 0 34L273 345c-9.1 9.1-23.7 9.3-33.1.7L95 201.1c-4.7-4.7-7-10.9-7-17s2.3-12.3 7-17c9.4-9.4 24.6-9.4 33.9 0l127.1 127z"></path>
                                    </svg>
                                </span>
                            </span>
                        </button>
                    </div>

                    <div class="profile-btn">
                        <button type="button" class="bg-transparent text-dark border-0 btn btn-primary">
                            <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path>
                            </svg> <span>Profile</span>
                            <span class="dropdown-icon">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M256 294.1L383 167c9.4-9.4 24.6-9.4 33.9 0s9.3 24.6 0 34L273 345c-9.1 9.1-23.7 9.3-33.1.7L95 201.1c-4.7-4.7-7-10.9-7-17s2.3-12.3 7-17c9.4-9.4 24.6-9.4 33.9 0l127.1 127z"></path>
                                </svg>
                            </span>
                        </button>

                    </div>

                <?php } ?>

            </section>

            <div style="background-color: white; z-index:9999;" class="d-none position-absolute login-popup col-md-4">
                <div class="mx-auto py-2 py-md-4 col-md-10">


                    <!-- Description -->
                    <div class="text-center mb-3">
                        <h3 class="fw-bold text-dark">Welcome Back!</h3>
                        <p class="text-muted">Log in to your account to access exclusive features, track your bids, and manage your dashboard efficiently.</p>
                    </div>

                    <form id="login_form" class="px-4 mt-3 px-md-0">
                        <div class="row">
                            <div class="col-12">
                                <label class="input-label-secondary">Username
                                    <svg xmlns="http://www.w3.org/2000/svg" width="19.006px" height="19.006px" viewBox="0 0 19.006 20.734" class="ms-2">
                                        <path id="Icon_awesome-asterisk" data-name="Icon awesome-asterisk" d="M20,13.53l-5.759-3.163L20,7.2a.972.972,0,0,0,.374-1.338L19.587,4.5a.972.972,0,0,0-1.346-.345L12.623,7.561,12.764.993A.972.972,0,0,0,11.792,0H10.215a.972.972,0,0,0-.972.993l.141,6.569L3.765,4.155A.972.972,0,0,0,2.42,4.5L1.631,5.867A.972.972,0,0,0,2,7.2l5.759,3.162L2,13.53a.972.972,0,0,0-.374,1.338l.789,1.366a.972.972,0,0,0,1.346.345l5.618-3.406-.141,6.569a.972.972,0,0,0,.972.993h1.578a.972.972,0,0,0,.972-.993l-.141-6.569,5.618,3.406a.972.972,0,0,0,1.346-.345l.789-1.366A.972.972,0,0,0,20,13.53Z" transform="translate(-1.5)" fill="var(--btn-bg-yellow)"></path>
                                    </svg>
                                </label>
                                <div class="input-field-container"><input type="text" name="email" id="email" placeholder="Username" class="input-secondary" value=""></div>
                            </div>
                            <div class="mt-2 mt-md-4 col-12">
                                <label class="input-label-secondary">Password
                                    <svg xmlns="http://www.w3.org/2000/svg" width="19.006px" height="19.006px" viewBox="0 0 19.006 20.734" class="ms-2">
                                        <path id="Icon_awesome-asterisk" data-name="Icon awesome-asterisk" d="M20,13.53l-5.759-3.163L20,7.2a.972.972,0,0,0,.374-1.338L19.587,4.5a.972.972,0,0,0-1.346-.345L12.623,7.561,12.764.993A.972.972,0,0,0,11.792,0H10.215a.972.972,0,0,0-.972.993l.141,6.569L3.765,4.155A.972.972,0,0,0,2.42,4.5L1.631,5.867A.972.972,0,0,0,2,7.2l5.759,3.162L2,13.53a.972.972,0,0,0-.374,1.338l.789,1.366a.972.972,0,0,0,1.346.345l5.618-3.406-.141,6.569a.972.972,0,0,0,.972.993h1.578a.972.972,0,0,0,.972-.993l-.141-6.569,5.618,3.406a.972.972,0,0,0,1.346-.345l.789-1.366A.972.972,0,0,0,20,13.53Z" transform="translate(-1.5)" fill="var(--btn-bg-yellow)"></path>
                                    </svg>
                                </label>
                                <div class="input-field-container"><input name="password" id="password" placeholder="Password" type="password" class=" input-secondary" value="">
                                    <div class="input-svg toggle-password">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="23.401" height="auto" viewBox="0 0 23.401 15.601" class="">
                                            <path id="Icon_awesome-eye" data-name="Icon awesome-eye" d="M23.26,11.707A13.03,13.03,0,0,0,11.7,4.5,13.032,13.032,0,0,0,.141,11.708a1.314,1.314,0,0,0,0,1.186A13.03,13.03,0,0,0,11.7,20.1,13.032,13.032,0,0,0,23.26,12.893,1.314,1.314,0,0,0,23.26,11.707ZM11.7,18.151a5.85,5.85,0,1,1,5.85-5.85A5.85,5.85,0,0,1,11.7,18.151Zm0-9.75a3.872,3.872,0,0,0-1.028.154,1.944,1.944,0,0,1-2.718,2.718A3.891,3.891,0,1,0,11.7,8.4Z" transform="translate(0 -4.5)" fill="var(--btn-bg-yellow)"></path>
                                        </svg>
                                    </div>
                                </div>
                                <p class="text-end mt-2 text-yellow __system__user__forgot__password__btn" style="cursor: pointer;">Forgot Password?</p>
                            </div>
                            <div class="mx-auto col-10"><button type="submit" style="background: var(--icon-yellow); font-weight: bold; border: 0px;" class="w-100 btn-login btn btn-primary" data-dashlane-label="true" data-dashlane-rid="311d23e999c375a2" data-dashlane-classification="action,login" data-kwimpalastatus="dead">Sign In</button></div>
                            <div class="text-center mt-2 mt-md-3 col-12">
                                <p>Don't have an Account? <span class="text-yellow" data-bs-toggle="modal" data-bs-target="#registerModal" style="cursor: pointer;">Sign Up Now</span></p>
                            </div>
                            <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                        </div>
                    </form>
                </div>
            </div>


            <div style="background-color: white; z-index:9999;" class="d-none position-absolute forgot-password-popup col-md-4">
                <div class="mx-auto py-2 py-md-4 col-md-10">
                    <form id="forgot_password_form" class="px-4 px-md-0">
                        <div class="row">
                            <div class="mt-2 mt-md-4 col-12">
                                <h2 class="text-center font-bold" style="color: var(--icon-yellow);">Forgot Password</h2>
                            </div>
                            <div class="mt-2 mt-md-4 col-12"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" font-size="32" class="mb-4 d-flex cursor-pointer __system__user__forgot__password__back__btn" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path fill="none" d="M0 0h24v24H0V0z"></path>
                                    <path d="M21 11H6.83l3.58-3.59L9 6l-6 6 6 6 1.41-1.41L6.83 13H21v-2z"></path>
                                </svg>
                                <h5 class="text-center font-semibold text-grey">Email Password Reset Link</h5>
                            </div>
                            <div class="mt-4 col-12">
                                <p class="text-center text-grey">Enter the email address of the associated account you would like to recover and a link to reset your password will be sent </p>
                            </div>
                            <div class="mt-2 mt-md-4 col-12">
                                <div class="input-field-container"><input name="email_address" id="email_address" placeholder="Email address associated with your account" type="email" class=" input-secondary " ></div>
                            </div>
                            <div class="mt-4 pt-md-4 col-12"><button type="submit" style="background: var(--icon-yellow); font-weight: 600; border: 0px;" class="w-100 btn-forgot-password text-400 btn btn-primary">Reset Password and Send Link</button> </div>
                        </div>
                        <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                    </form>
                </div>
            </div>

            <section class="d-flex align-items-center">
                <div class="d-none d-lg-none d-flex ms-auto ">
                    <button type="button" class="bg-transparent text-dark border-0 btn btn-primary">
                        <span class="d-flex align-items-center gap-1">
                            <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path>
                            </svg>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256 294.1L383 167c9.4-9.4 24.6-9.4 33.9 0s9.3 24.6 0 34L273 345c-9.1 9.1-23.7 9.3-33.1.7L95 201.1c-4.7-4.7-7-10.9-7-17s2.3-12.3 7-17c9.4-9.4 24.6-9.4 33.9 0l127.1 127z"></path>
                            </svg>
                        </span>
                    </button>
                </div>
                <div class="d-lg-none d-flex ms-auto" style="cursor: pointer;">
                    <svg class="header__nav__open_button__dropdown" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="30" width="30" xmlns="http://www.w3.org/2000/svg">
                        <path d="M912 192H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 284H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 284H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zM104 228a56 56 0 1 0 112 0 56 56 0 1 0-112 0zm0 284a56 56 0 1 0 112 0 56 56 0 1 0-112 0zm0 284a56 56 0 1 0 112 0 56 56 0 1 0-112 0z"></path>
                    </svg>
                </div>
            </section>
        </div>
        <nav class="">
            <div class="header__nav__dropdown  false">
                <div class="topBar px-0 mx-0 h-maxC container-fluid">
                    <div class="d-flex align-items-center customContainer container-fluid">
                        <section class=" ps-2"></section>

                        <?php if (!isset($_SESSION['auction_user_session_data'])) { ?>
                            <section>
                                <button type="button" style="height:44px;min-width:max-content;width:100%"
                                    class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  __header__btn d-lg-none d-lg-flex me-2 outline-dark-btn btn btn-primary"
                                    data-bs-toggle="modal" data-bs-target="#registerModal">
                                    <div class="me-2 " style="color:inherit">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                                        </svg>
                                    </div>Register Now
                                </button>
                            </section>
                            <section class=" ps-2 ">
                                <button type="button" style="height:44px;min-width:max-content;width:100%" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  __header__btn __system__user__login__btn d-lg-none d-lg-flex outline-dark-btn btn btn-primary">
                                    <div class="me-2 " style="color:inherit"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                                        </svg></div>Log in
                                </button>
                            </section>

                        <?php } ?>

                        <section class=" ps-2 d-flex flex-column ms-auto">
                            <div class="mt-auto">
                                <svg class="header__nav__close_button__dropdown" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" color="#fff" style="color:#fff" height="30" width="30" xmlns="http://www.w3.org/2000/svg">
                                    <path fill="none" d="M0 0h24v24H0z"></path>
                                    <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
                                </svg>
                            </div>
                        </section>
                    </div>
                </div>
                <div class="d-flex justify-content-between padding-y-13 px-4 align-items-center">
                    <div class="position-relative gradientInput me-3 mt-0 flex-grow">
                        <div class="outline_search_input_preElem f-flex align-items-center justify-content-center"><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" color="white" class=" " style="color:white" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg></div><input type="text" placeholder="Search Auctions" class="text-start outline_search_input  outline-dark px-md-5 ps-5" style="max-width:100%;color:inherit">
                    </div>
                </div>

                <ul class="d-flex list-unstyled mb-0 w-100 align-items-start padding-y-13 justify-content-start px-4 pt-2 ">
                    <li class=" header__nav__dropdown_li text-white  mt-0 "><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li class="text-grey false "><a href='<?php echo site_url("auctions"); ?>'>Auctions</a></li>
                    <li class="text-grey false "><a href='<?php echo site_url("faqs"); ?>'>FAQs</a></li>
                    <li class="text-grey false "><a href='<?php echo site_url("contact-us"); ?>'>Contact</a></li>
                </ul>

                <div class="social-links-nav-dropdown">
                    <section class=" d-flex align-items-end justify-content-center px-3 py-4">
                        <div class="d-flex justify-content-between w-100 justify-content-sm-center" style="padding: 0px 8px;"><a href="#test" class=" topBar__socialLink"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M960 509.2c0-2.2 0-4.7-.1-7.6-.1-8.1-.3-17.2-.5-26.9-.8-27.9-2.2-55.7-4.4-81.9-3-36.1-7.4-66.2-13.4-88.8a139.52 139.52 0 0 0-98.3-98.5c-28.3-7.6-83.7-12.3-161.7-15.2-37.1-1.4-76.8-2.3-116.5-2.8-13.9-.2-26.8-.3-38.4-.4h-29.4c-11.6.1-24.5.2-38.4.4-39.7.5-79.4 1.4-116.5 2.8-78 3-133.5 7.7-161.7 15.2A139.35 139.35 0 0 0 82.4 304C76.3 326.6 72 356.7 69 392.8c-2.2 26.2-3.6 54-4.4 81.9-.3 9.7-.4 18.8-.5 26.9 0 2.9-.1 5.4-.1 7.6v5.6c0 2.2 0 4.7.1 7.6.1 8.1.3 17.2.5 26.9.8 27.9 2.2 55.7 4.4 81.9 3 36.1 7.4 66.2 13.4 88.8 12.8 47.9 50.4 85.7 98.3 98.5 28.2 7.6 83.7 12.3 161.7 15.2 37.1 1.4 76.8 2.3 116.5 2.8 13.9.2 26.8.3 38.4.4h29.4c11.6-.1 24.5-.2 38.4-.4 39.7-.5 79.4-1.4 116.5-2.8 78-3 133.5-7.7 161.7-15.2 47.9-12.8 85.5-50.5 98.3-98.5 6.1-22.6 10.4-52.7 13.4-88.8 2.2-26.2 3.6-54 4.4-81.9.3-9.7.4-18.8.5-26.9 0-2.9.1-5.4.1-7.6v-5.6zm-72 5.2c0 2.1 0 4.4-.1 7.1-.1 7.8-.3 16.4-.5 25.7-.7 26.6-2.1 53.2-4.2 77.9-2.7 32.2-6.5 58.6-11.2 76.3-6.2 23.1-24.4 41.4-47.4 47.5-21 5.6-73.9 10.1-145.8 12.8-36.4 1.4-75.6 2.3-114.7 2.8-13.7.2-26.4.3-37.8.3h-28.6l-37.8-.3c-39.1-.5-78.2-1.4-114.7-2.8-71.9-2.8-124.9-7.2-145.8-12.8-23-6.2-41.2-24.4-47.4-47.5-4.7-17.7-8.5-44.1-11.2-76.3-2.1-24.7-3.4-51.3-4.2-77.9-.3-9.3-.4-18-.5-25.7 0-2.7-.1-5.1-.1-7.1v-4.8c0-2.1 0-4.4.1-7.1.1-7.8.3-16.4.5-25.7.7-26.6 2.1-53.2 4.2-77.9 2.7-32.2 6.5-58.6 11.2-76.3 6.2-23.1 24.4-41.4 47.4-47.5 21-5.6 73.9-10.1 145.8-12.8 36.4-1.4 75.6-2.3 114.7-2.8 13.7-.2 26.4-.3 37.8-.3h28.6l37.8.3c39.1.5 78.2 1.4 114.7 2.8 71.9 2.8 124.9 7.2 145.8 12.8 23 6.2 41.2 24.4 47.4 47.5 4.7 17.7 8.5 44.1 11.2 76.3 2.1 24.7 3.4 51.3 4.2 77.9.3 9.3.4 18 .5 25.7 0 2.7.1 5.1.1 7.1v4.8zM423 646l232-135-232-133z"></path>
                                </svg></a><a href="#test" class="ms-3 topBar__socialLink "><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"></path>
                                </svg></a><a href="#TEST" class="ms-3 topBar__socialLink"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
                                </svg></a><a href="#test" class="ms-3 topBar__socialLink"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.3499 5.5498C13.7681 5.5498 12.4786 6.81785 12.4504 8.39633L12.4223 9.97138C12.4164 10.3027 12.143 10.5665 11.8117 10.5606C11.7881 10.5602 11.7646 10.5584 11.7413 10.5552L10.1805 10.3423C8.12699 10.0623 6.15883 9.11711 4.27072 7.54387C3.67275 10.8535 4.84 13.147 7.65342 14.9157L9.40041 16.014C9.68095 16.1904 9.7654 16.5608 9.58903 16.8413C9.54861 16.9056 9.49636 16.9616 9.43504 17.0064L7.84338 18.1693C8.78973 18.2288 9.68938 18.1873 10.435 18.0385C15.1526 17.097 18.2897 13.5468 18.2897 7.69084C18.2897 7.21275 17.2774 5.5498 15.3499 5.5498ZM10.4507 8.36066C10.4983 5.69559 12.6735 3.5498 15.3499 3.5498C16.7132 3.5498 17.9465 4.10658 18.8348 5.00515C19.5462 4.9998 20.1514 5.17966 21.5035 4.35943C21.1693 5.9998 21.0034 6.71177 20.2897 7.69084C20.2897 15.3324 15.5926 19.0487 10.8264 19.9998C7.5587 20.6519 2.80646 19.5812 1.44531 18.1584C2.13874 18.1051 4.95928 17.8018 6.58895 16.6089C5.20994 15.6984 -0.278631 12.4679 3.32772 3.78617C5.02119 5.76283 6.73797 7.10831 8.47807 7.82262C9.63548 8.29774 9.91978 8.28825 10.4507 8.36066Z"></path>
                                </svg></a><a href="#test" class="ms-3 topBar__socialLink"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" height="15" width="15" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                                </svg></a></div>
                    </section>
                </div>
            </div>
        </nav>
    </div>
</header>