<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>
                                    <button class="false btn__edit__account">Edit Account</button>
                                    <button class="false btn__payment__method">Payment Method</button>
                                    <button class="tab_btn btn__notificaitons">Notifications</button>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Notifications</h1>
                                    </div>
                                    <div class="d-md-none">
                                        <div style="background: white; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; top: 0px; left: 0px; width: 100%; z-index: 5000; max-height: 400px; overflow: auto;" class="mx-auto">
                                            <div class="mt-4 mb-2 text-center col">
                                                <h4 class="text-l text-grey " style="font-weight: bold;">Manage Notifications and Alerts</h4>
                                            </div>


                                            <div class="mx-auto dashboard" style="width: 80%;">
                                                <div class="table-responsive">
                                                    <table class="mt-sm-1 notifications-table">
                                                        <thead class="p-2 text-nowrap">
                                                            <th class="text-center py-1 px-1 border">Auction Activity</th>
                                                            <th class="text-center py-1 px-1 border">Preference Type</th>
                                                            <th class="text-center py-1 px-1 border">Yes</th>
                                                            <th class="text-center py-1 px-1 border">No</th>
                                                        </thead>
                                                        <tbody class="p-2 text-nowrap">

                                                        </tbody>
                                                    </table>
                                                </div>

                                                <!--<div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="p-2 text-nowrap">
                                                            <th class="text-start py-3 px-5 border">Daily Notifications</th>
                                                            <th class="text-start border py-3 ps-3 ">Yes</th>
                                                            <th class="text-start border py-3 ps-3 ">No</th>
                                                            <th class="text-start border py-3 ps-3 ">Notifications From Region (select up to 2)</th>
                                                        </thead>
                                                        <tbody class="p-2 text-nowrap">
                                                            <tr>
                                                                <td class="text-start" style="vertical-align: middle;">
                                                                    <p class=""> New Auctions Near Me</p>
                                                                </td>
                                                                <td class="text-start" style="vertical-align: middle;"><input type="radio" name="Yes-0" checked=""></td>
                                                                <td class="text-start" style="vertical-align: middle;"><input type="radio" name="Yes-0"></td>
                                                                <td width="30%">
                                                                    <div class=" css-b62m3t-container"><span id="react-select-36-live-region" class="css-7pg0cj-a11yText"></span><span aria-live="polite" aria-atomic="false" aria-relevant="additions text" class="css-7pg0cj-a11yText"></span>
                                                                        <div class="ssa____control css-13cymwt-control">
                                                                            <div class="ssa____value-container ssa____value-container--is-multi ssa____value-container--has-value css-1dyz3mf">
                                                                                <div class="ssa____multi-value css-1p3m7a8-multiValue">
                                                                                    <div class="ssa____multi-value__label css-9jq23d">California</div>
                                                                                    <div role="button" class="ssa____multi-value__remove css-v7duua" aria-label="Remove California"><svg height="14" width="14" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                            <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                        </svg></div>
                                                                                </div>
                                                                                <div class="ssa____input-container css-19bb58m" data-value=""><input class="ssa____input" style="color: inherit; background: 0px center; opacity: 1; width: 100%; grid-area: 1 / 2; font: inherit; min-width: 2px; border: 0px; margin: 0px; outline: 0px; padding: 0px;" autocapitalize="none" autocomplete="off" autocorrect="off" id="react-select-36-input" spellcheck="false" tabindex="0" type="text" aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" role="combobox" value=""></div>
                                                                            </div>
                                                                            <div class="ssa____indicators css-1wy0on6">
                                                                                <div class="ssa____indicator ssa____clear-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                        <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                    </svg></div>
                                                                                <div class="ssa____indicator ssa____dropdown-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                        <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
                                                                                    </svg></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="text-start" style="vertical-align: middle;">
                                                                    <p class=""> Closing Auctions Near Me</p>
                                                                </td>
                                                                <td class="text-start" style="vertical-align: middle;"><input type="radio" name="Yes-1" checked=""></td>
                                                                <td class="text-start" style="vertical-align: middle;"><input type="radio" name="Yes-1"></td>
                                                                <td width="30%">
                                                                    <div class=" css-b62m3t-container"><span id="react-select-37-live-region" class="css-7pg0cj-a11yText"></span><span aria-live="polite" aria-atomic="false" aria-relevant="additions text" class="css-7pg0cj-a11yText"></span>
                                                                        <div class="ssa____control css-13cymwt-control">
                                                                            <div class="ssa____value-container ssa____value-container--is-multi ssa____value-container--has-value css-1dyz3mf">
                                                                                <div class="ssa____multi-value css-1p3m7a8-multiValue">
                                                                                    <div class="ssa____multi-value__label css-9jq23d">California</div>
                                                                                    <div role="button" class="ssa____multi-value__remove css-v7duua" aria-label="Remove California"><svg height="14" width="14" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                            <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                        </svg></div>
                                                                                </div>
                                                                                <div class="ssa____input-container css-19bb58m" data-value=""><input class="ssa____input" style="color: inherit; background: 0px center; opacity: 1; width: 100%; grid-area: 1 / 2; font: inherit; min-width: 2px; border: 0px; margin: 0px; outline: 0px; padding: 0px;" autocapitalize="none" autocomplete="off" autocorrect="off" id="react-select-37-input" spellcheck="false" tabindex="0" type="text" aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" role="combobox" value=""></div>
                                                                            </div>
                                                                            <div class="ssa____indicators css-1wy0on6">
                                                                                <div class="ssa____indicator ssa____clear-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                        <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                    </svg></div>
                                                                                <div class="ssa____indicator ssa____dropdown-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                        <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
                                                                                    </svg></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>-->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-none d-md-block">
                                        <div class="mt-2 notification__menu p-3" style="z-index: 5000;">
                                            <div class="mt-4 mb-2 col">
                                                <h4 class="text-l text-grey " style="font-weight: bold;">Manage Notifications and Alerts</h4>
                                            </div>
                                            <div class="col">
                                                <h6>Audio Settings</h6>
                                            </div>
                                            <div class="col">
                                                <p>Have sound enabled by default on auctions</p>
                                            </div>
                                            <div class="col">
                                                <div class="mb-3"><select name="audio_settings" id="filter">
                                                        <option value="Enabled - Auctioneer Dan">Enabled - Auctioneer Dan</option>
                                                        <option value="Disabled">Disabled</option>
                                                    </select></div>
                                            </div>
                                            <div class="table-responsive">
                                                <table class="mt-sm-1 table notifications-table">
                                                    <thead class="p-2 text-nowrap">
                                                        <th class="text-center ps-3 py-3 border">Auction Activity</th>
                                                        <th class="text-center ps-3 py-3 border">Preference Type</th>
                                                        <th class="text-center border py-3 ps-3 ">Yes</th>
                                                        <th class="text-center border py-3 ps-3 ">No</th>
                                                    </thead>
                                                    <tbody class="p-2 text-nowrap">

                                                    </tbody>
                                                </table>
                                            </div>
                                            <!-- <table class="table">
                                                <thead class="p-2 text-nowrap">
                                                    <th class="text-start py-3 px-5 border">Daily Notifications</th>
                                                    <th class="text-start border py-3 ps-3 ">Yes</th>
                                                    <th class="text-start border py-3 ps-3 ">No</th>
                                                    <th class="text-start border py-3 ps-3 ">Notifications From Region (select up to 2)</th>
                                                </thead>
                                                <tbody class="p-2 text-nowrap">
                                                    <tr>
                                                        <td class="text-start" style="vertical-align: middle;">
                                                            <p class=""> New Auctions Near Me</p>
                                                        </td>
                                                        <td class="text-start" style="vertical-align: middle;"><input type="radio" checked=""></td>
                                                        <td class="text-start" style="vertical-align: middle;"><input type="radio"></td>
                                                        <td width="30%">
                                                            <div class=" css-b62m3t-container"><span id="react-select-38-live-region" class="css-7pg0cj-a11yText"></span><span aria-live="polite" aria-atomic="false" aria-relevant="additions text" class="css-7pg0cj-a11yText"></span>
                                                                <div class="ssa____control css-13cymwt-control">
                                                                    <div class="ssa____value-container ssa____value-container--is-multi ssa____value-container--has-value css-1dyz3mf">
                                                                        <div class="ssa____multi-value css-1p3m7a8-multiValue">
                                                                            <div class="ssa____multi-value__label css-9jq23d">California</div>
                                                                            <div role="button" class="ssa____multi-value__remove css-v7duua" aria-label="Remove California"><svg height="14" width="14" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                    <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                </svg></div>
                                                                        </div>
                                                                        <div class="ssa____input-container css-19bb58m" data-value=""><input class="ssa____input" style="color: inherit; background: 0px center; opacity: 1; width: 100%; grid-area: 1 / 2; font: inherit; min-width: 2px; border: 0px; margin: 0px; outline: 0px; padding: 0px;" autocapitalize="none" autocomplete="off" autocorrect="off" id="react-select-38-input" spellcheck="false" tabindex="0" type="text" aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" role="combobox" value=""></div>
                                                                    </div>
                                                                    <div class="ssa____indicators css-1wy0on6">
                                                                        <div class="ssa____indicator ssa____clear-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                            </svg></div>
                                                                        <div class="ssa____indicator ssa____dropdown-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
                                                                            </svg></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-start" style="vertical-align: middle;">
                                                            <p class=""> Closing Auctions Near Me</p>
                                                        </td>
                                                        <td class="text-start" style="vertical-align: middle;"><input type="radio" checked=""></td>
                                                        <td class="text-start" style="vertical-align: middle;"><input type="radio"></td>
                                                        <td width="30%">
                                                            <div class=" css-b62m3t-container"><span id="react-select-39-live-region" class="css-7pg0cj-a11yText"></span><span aria-live="polite" aria-atomic="false" aria-relevant="additions text" class="css-7pg0cj-a11yText"></span>
                                                                <div class="ssa____control css-13cymwt-control">
                                                                    <div class="ssa____value-container ssa____value-container--is-multi ssa____value-container--has-value css-1dyz3mf">
                                                                        <div class="ssa____multi-value css-1p3m7a8-multiValue">
                                                                            <div class="ssa____multi-value__label css-9jq23d">California</div>
                                                                            <div role="button" class="ssa____multi-value__remove css-v7duua" aria-label="Remove California"><svg height="14" width="14" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                    <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                                </svg></div>
                                                                        </div>
                                                                        <div class="ssa____input-container css-19bb58m" data-value=""><input class="ssa____input" style="color: inherit; background: 0px center; opacity: 1; width: 100%; grid-area: 1 / 2; font: inherit; min-width: 2px; border: 0px; margin: 0px; outline: 0px; padding: 0px;" autocapitalize="none" autocomplete="off" autocorrect="off" id="react-select-39-input" spellcheck="false" tabindex="0" type="text" aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" role="combobox" value=""></div>
                                                                    </div>
                                                                    <div class="ssa____indicators css-1wy0on6">
                                                                        <div class="ssa____indicator ssa____clear-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                                                            </svg></div>
                                                                        <div class="ssa____indicator ssa____dropdown-indicator css-1xc3v61-indicatorContainer" aria-hidden="true"><svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-8mmkcg">
                                                                                <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
                                                                            </svg></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>