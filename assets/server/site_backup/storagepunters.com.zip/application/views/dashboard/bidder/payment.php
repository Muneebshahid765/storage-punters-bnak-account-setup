<div class="p-0 d-flex flex-column h-100 container-fluid">


    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>
                                    <button class="false btn__edit__account">Edit Account</button>
                                    <button class="tab_btn btn__payment__method">Payment Method</button>
                                    <button class="false btn__notificaitons">Notifications</button>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Payment Methods</h1>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="ms-0 ms-md-auto" style="width: max-content;">
                                            <button type="button" style="border-radius: 12px; border: medium; font-weight: 500;" class="__btn__add__new__payment__method w-100 btn-yellow btn-contact px-md-4 d-flex align-items-center gap-1  btn btn-primary btn-sm">
                                                <span>
                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1H2zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7z"></path>
                                                        <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1z"></path>
                                                    </svg>
                                                </span><span class="__btn__add__new__payment__method__text">Add New</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="rounded dashboard row __table__payment__method">
                                    <div class="mt-4 col-12">
                                        <div class="text-center payment-table">
                                            <div class="table-responsive">
                                                <table id="payment-method-table" class="mt-sm-1 p-0 table table-striped table-bordered table-hover">
                                                    <thead class="text-nowrap">
                                                        <th style="text-align: left;" class="p-2 border">Card # </th>
                                                        <th style="text-align: left;" class="p-2 border">Name</th>
                                                        <th style="text-align: left;" class="p-2 border">Card Ending In </th>
                                                        <th style="text-align: left;" class="p-2 border">Card Type </th>
                                                        <th style="text-align: left;" class="p-2 border">Exp </th>
                                                        <th style="text-align: left;" class="p-2 border">Default </th>
                                                        <th style="text-align: left;" class="p-2 border">Attach/Detach </th>
                                                        <!-- <th style="text-align: left;" class="p-2 border">Activity </th>-->
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</div>