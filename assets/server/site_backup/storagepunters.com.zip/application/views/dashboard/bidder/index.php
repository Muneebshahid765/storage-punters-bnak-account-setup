<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="tab_btn btn__dashboard">Dashboard</button>
                                    <button class="false btn__edit__account">Edit Account</button>
                                    <button class="false btn__payment__method">Payment Method</button>
                                    <button class="false btn__notificaitons">Notifications</button>
                                </div>
                            </div>

                            <div class="">
                                <div class="mb-4 row">
                                    <div role="alert" class="fade d-none mx-auto w-75 text-center alert alert-success show">Your membership is downgraded to Standard Bidder</div>
                                    <div role="alert" class="fade d-none mx-auto w-75 text-left alert alert-danger show">You currently have bids placed on active auctions. You cannot have active bids placed. Please wait until these auctions end before canceling.</div>
                                    <div class="d-flex justify-content-center flex-column align-items-center align-items-md-start dashboard col-md-6 col-12">
                                        <h1 class="dashboard__headings mt-2 mt-md-0" style="font-weight: 600;">Welcome back, <?php echo $this->session->userdata('auction_user_session_data')['first_name']?></h1>
                                        <div class="d-flex gap-3 align-items-center mt-sm-4"></div>
                                    </div>
                                    <div class="d-none mt-4 mt-sm-0 d-flex justify-content-center flex-column align-items-center align-items-md-end col-md-6 col-12">
                                        <h1 class="text-sm-center dashboard__headings text-md-end me-md-5 me-lg-4 mb-4">Active Subscription</h1>
                                        <div class="p-3 mt-1 rounded dashboard position-relative " style="border: 1px solid rgb(197, 197, 197); background: rgb(238, 238, 238); width: max-content;">
                                            <p class="mt-4 text-center"><span class="me-1">Standard Bidder</span>(15% Premium)</p><button type="button" style="color: var(--border-active);" class="color__orange text-center bg-transparent border-0 btn btn-primary">Upgrade to Executive Bidder</button>
                                        </div>
                                    </div>
                                </div>
                                <div class=" d-md-block">
                                    <div class="tab_list">
                                        <div class="__tab__auction__dashboard">
                                            <button class="tab_btn btn__current__active_auctions">Current/Active</button>
                                            <button class="false btn__all_auctions">All Auctions Bid On</button>
                                            <button class="false btn__watched_auctions">Watched Auctions</button>
                                            <button class="false btn__won_auctions">Auctions Won</button>
                                            <button class="false btn__invoices_auctions">Invoices</button>
                                        </div>
                                    </div>


                                    <div class="__tab__table_auction__dashboard">
                                        <!-- <div class="border rounded dashboard ps-2 pe-2">
                                            <div class="my-2 row">
                                                <div class=" d-flex justify-content-between col-sm-12 col-12">
                                                    <div class="px-2 w-100 d-flex justify-content-center justify-content-md-between flex-column flex-md-row" style="background: rgba(0, 0, 0, 0.05); padding: 15px;">
                                                        <div>
                                                            <p class="mb-1 my-auto">Active Auctions Bid On </p>
                                                        </div>
                                                        <div>
                                                            <p class="my-auto">Current Time Zone - America/Los_Angeles</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="text-center dashboard ">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered table-hover">
                                                            <thead class="p-2 text-nowrap">
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">Auction #</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">Status</th>
                                                                <th style="width: 15%; text-align: left;" class="border ps-3">Seller</th>
                                                                <th style="width: 15%; text-align: left;" class="border ps-3">Ends</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">High Bid</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">My Max Bid</th>
                                                                <th style="width: 3%; text-align: left;" class="border ps-3">Actions</th>
                                                            </thead>
                                                            <tbody class="p-2 text-nowrap" data-dashlane-rid="03fd3258ebd8e6b8" data-dashlane-classification="other">
                                                                <th> <input type="text" placeholder="enter auction id" class="filter-box" name="sampleId" data-dashlane-rid="a08648a9f4ca483e" data-dashlane-classification="other"></th>
                                                                <th class="border"></th>
                                                                <th class="border"><input type="text" class="filter-box" placeholder="enter facility name" name="FacilityName" data-dashlane-rid="1914b6c1ea5dbfb3" data-dashlane-classification="name" data-kwimpalastatus="alive" data-kwimpalaid="1741451383701-2"></th>
                                                                <th class="border"><input type="date" class="filter-box" name="EndDate" data-dashlane-rid="f8c201f5f57256a9" data-dashlane-classification="date"></th>
                                                                <th class="border"><input type="text" class="filter-box" placeholder="enter high bid" name="CurrentHighBid" data-dashlane-rid="bec499ba083b3da5" data-dashlane-classification="other"> </th>
                                                                <th class="border"></th>
                                                                <th class="border"></th>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>-->
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>