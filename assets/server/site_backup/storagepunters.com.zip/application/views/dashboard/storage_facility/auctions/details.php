<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>


                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>

                                    <?php

                                    }

                                    ?>

                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Edit your Auction Details</h1>
                                    </div>
                                </div>

                                Time zone in Brisbane QLD, Australia

                                <form id="auction-update-form" class="mt-2 mt-md-4">
                                    <div class="row">

                                        <div id="auction-upload-section"></div>

                                        <!-- Auction ID (disabled) -->
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-12 mt-4">
                                            <label for="auction_id" class="input-label-secondary">Auction ID</label>
                                            <input id="auction_id" name="auction_id" type="text" class="input-secondary text-300" placeholder="Auto-generated" disabled>
                                        </div>

                                        <!-- Auction Type -->
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-12 mt-4">
                                            <label for="auctionTypeDropdown" class="input-label-secondary">Auction Type</label>
                                            <div class="input-field-container">
                                                <select id="auctionTypeDropdown" name="auction_type" class="input-secondary">
                                                    <option value="">Loading types...</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Storage Facility -->
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-12 mt-4">
                                            <label for="storageFacilityDropdown" class="input-label-secondary">Storage Facility</label>
                                            <div class="input-field-container">
                                                <select id="storageFacilityDropdown" name="storage_facility" class="input-secondary">
                                                    <option value="">Loading facilities...</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Unit Number -->
                                        <div class="col-xl-3 col-lg-3 col-md-4 col-12 mt-4">
                                            <label for="auction_unit_number" class="input-label-secondary">Unit Number</label>
                                            <input id="auction_unit_number" type="text" class="input-secondary text-300" placeholder="Enter unit number (e.g. B202)">
                                        </div>

                                        <!-- Description -->
                                        <div class="col-xl-9 col-lg-9 col-md-8 col-12 mt-4">
                                            <label for="auction_description" class="input-label-secondary">Description</label>
                                            <input id="auction_description" type="text" class="input-secondary text-300" placeholder="Enter auction description">
                                        </div>

                                        <!-- Tags -->
                                        <div class="mt-4 col-12">
                                            <label for="auction_tags" class="input-label-secondary">Tags</label>
                                            <input id="auction_tags" type="text" class="input-secondary text-300" placeholder="Enter tags (comma-separated)">
                                        </div>


                                        <!--Auction Category -->
                                        <div class="col-xl-3 col-md-4  col-lg-3 col-12 mt-4">
                                            <label for="auctionCategoryDropdown" class="input-label-secondary">Category</label>
                                            <div class="input-field-container">
                                                <select id="auctionCategoryDropdown" name="auction_category" class="input-secondary">
                                                    <option value="">Loading categories...</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Disclose Unit -->
                                        <div class="mt-4 col-xl-3  col-lg-3 col-md-8">
                                            <label for="auction_disclose_unit_number_on_website" class="input-label-secondary">Disclose Unit?</label>
                                            <select id="auction_disclose_unit_number_on_website" class="input-secondary text-300">
                                                <option value="0">No</option>
                                                <option value="1">Yes</option>
                                            </select>
                                        </div>

                                        <!-- Outstanding Debt -->
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_outstanding_dept" class="input-label-secondary">Outstanding Debt ($)</label>
                                            <input id="auction_outstanding_dept" type="text" class="input-secondary text-300" placeholder="Amount in dollars">
                                        </div>

                                        <!-- Start Bid -->
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_start_bid_amount" class="input-label-secondary">Start Bid Amount ($)</label>
                                            <input id="auction_start_bid_amount" type="text" class="input-secondary text-300" placeholder="Minimum bid amount">
                                        </div>

                                        <!-- Start Date & Time -->
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_start_date" class="input-label-secondary">Start Date</label>
                                            <input id="auction_start_date" type="date" class="input-secondary text-300" placeholder="Start date">
                                        </div>
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_start_time" class="input-label-secondary">Start Time</label>
                                            <select id="auction_start_time" class="input-secondary text-300">
                                                <option value="">Select time</option>
                                                <option value="12:00 AM">12:00 AM</option>
                                                <option value="01:00 AM">01:00 AM</option>
                                                <option value="02:00 AM">02:00 AM</option>
                                                <option value="03:00 AM">03:00 AM</option>
                                                <option value="04:00 AM">04:00 AM</option>
                                                <option value="05:00 AM">05:00 AM</option>
                                                <option value="06:00 AM">06:00 AM</option>
                                                <option value="07:00 AM">07:00 AM</option>
                                                <option value="08:00 AM">08:00 AM</option>
                                                <option value="09:00 AM">09:00 AM</option>
                                                <option value="10:00 AM">10:00 AM</option>
                                                <option value="11:00 AM">11:00 AM</option>
                                                <option value="12:00 PM">12:00 PM</option>
                                                <option value="01:00 PM">01:00 PM</option>
                                                <option value="02:00 PM">02:00 PM</option>
                                                <option value="03:00 PM">03:00 PM</option>
                                                <option value="04:00 PM">04:00 PM</option>
                                                <option value="05:00 PM">05:00 PM</option>
                                                <option value="06:00 PM">06:00 PM</option>
                                                <option value="07:00 PM">07:00 PM</option>
                                                <option value="08:00 PM">08:00 PM</option>
                                                <option value="09:00 PM">09:00 PM</option>
                                                <option value="10:00 PM">10:00 PM</option>
                                                <option value="11:00 PM">11:00 PM</option>
                                            </select>
                                        </div>

                                        <!-- End Date & Time -->
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_end_date" class="input-label-secondary">End Date</label>
                                            <input id="auction_end_date" type="date" class="input-secondary text-300" placeholder="End date" readonly>
                                        </div>
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="auction_end_time" class="input-label-secondary">End Time</label>
                                            <select id="auction_end_time" class="input-secondary text-300" readonly>

                                            </select>
                                        </div>

                                        <!-- YouTube URL -->
                                        <div class="mt-4 col-12">
                                            <label for="auction_youtube_video_url" class="input-label-secondary">YouTube Video URL</label>
                                            <input id="auction_youtube_video_url" type="url" class="input-secondary text-300" placeholder="Paste YouTube link (optional)">
                                        </div>

                                        <!-- Unit Size -->
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-4">
                                            <label for="auction_unit_size" class="input-label-secondary">Unit Size</label>
                                            <input id="auction_unit_size" type="text" class="input-secondary text-300" placeholder="e.g. 10 x 20">
                                        </div>

                                        <!-- Additional Features -->
                                        <div class="mt-4 col-xl-9 col-lg-9 col-md-8">
                                            <label for="auction_additional_features" class="input-label-secondary">Additional Features</label>
                                            <input id="auction_additional_features" type="text" class="input-secondary text-300" placeholder="Comma-separated features">
                                        </div>

                                        <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                            <button type="submit" id="save-auction-updates-btn" style="border-radius:12px;border:none;font-weight:500" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Save Updates

                                            </button>
                                        </div>


                                    </div>


                                </form>


                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>