<div class="p-0 d-flex flex-column h-100 container-fluid">


    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>
                                    <button class="false btn__edit__account">Edit Account</button>
                                    <button class="false btn__setup__company">Company Setup</button>
                                    <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                    <button class="tab_btn btn__manage__staff">Manage Staff</button>
                                    <button class="false btn__manage__facility_storage">Manage Facility Storage</button>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Staff Members</h1>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="ms-0 ms-md-auto" style="width: max-content;">
                                            <button type="button" style="border-radius: 12px; border: medium; font-weight: 500;" class="__btn__add__new__staff__member w-100 btn-yellow btn-contact px-md-4 d-flex align-items-center gap-1  btn btn-primary btn-sm">
                                                <span>
                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"></path>
                                                    </svg>
                                                </span><span class="__btn__add__new__staff__member__text">Add New</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="rounded dashboard row __table__staff__member">
                                    <div class="mt-4 col-12">
                                        <div class="text-center staff-table">
                                            <div class="table-responsive">
                                                <table id="staff-member-table" class="mt-sm-1 p-0 table table-striped table-bordered table-hover">
                                                    <thead class="text-nowrap">
                                                        <th style="text-align: left;" class="p-2 border">Staff # </th>
                                                        <th style="text-align: left;" class="p-2 border">First Name</th>
                                                        <th style="text-align: left;" class="p-2 border">Last Name</th>
                                                        <th style="text-align: left;" class="p-2 border">Email</th>
                                                        <th style="text-align: left;" class="p-2 border">Access </th>
                                                        <!--<th style="text-align: left;" class="p-2 border">Action</th>-->
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</div>