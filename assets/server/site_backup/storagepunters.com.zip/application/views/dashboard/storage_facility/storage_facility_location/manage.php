<div class="p-0 d-flex flex-column h-100 container-fluid">


    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>
                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>


                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="tab_btn btn__manage__facility_storage">Manage Facility Storage</button>


                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Storgae Facility Locations</h1>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="ms-0 ms-md-auto" style="width: max-content;">
                                            <button type="button" style="border-radius: 12px; border: medium; font-weight: 500;" class="__btn__add__new__storage__facility w-100 btn-yellow btn-contact px-md-4 d-flex align-items-center gap-1  btn btn-primary btn-sm">
                                                <span>
                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1H2zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7z"></path>
                                                        <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1z"></path>
                                                    </svg>
                                                </span><span class="__btn__add__new__storage__facility_location__text">Add New</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="rounded dashboard row __table__storage__facility">
                                    <div class="mt-4 col-12">
                                        <div class="text-center storage-facility-table">
                                            <div class="table-responsive">
                                                <table id="storage-facility-table" class="mt-sm-1 p-0 table table-striped table-bordered table-hover">
                                                    <thead class="text-nowrap">
                                                        <th style="text-align: left;" class="p-2 border">Facility # </th>
                                                        <th style="text-align: left;" class="p-2 border">Facility Name </th>
                                                        <th style="text-align: left;" class="p-2 border">Company Name </th>
                                                        <th style="text-align: left;" class="p-2 border">Facility Timezone </th>
                                                        <th style="text-align: left;" class="p-2 border">Last Modified </th>
                                                        <th style="text-align: left;" class="p-2 border">Status </th>
                                                        <th style="text-align: left;" class="p-2 border">Actions </th>
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</div>