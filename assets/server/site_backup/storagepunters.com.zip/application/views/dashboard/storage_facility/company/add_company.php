<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>


                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="tab_btn btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>

                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Setup your Company details</h1>
                                    </div>
                                </div>
                                <form id="company-setup-add-form" class="mt-2 mt-md-4">
                                    <div class="row">
                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="company_name" class="input-label-secondary">Company Name *</label>
                                            <div class="input-field-container">
                                                <input id="company_name" type="text" placeholder="Enter company name" name="company_name" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="company_email" class="input-label-secondary">Company Email *</label>
                                            <div class="input-field-container">
                                                <input id="company_email" type="email" placeholder="Enter company email" name="company_email" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="company_website" class="input-label-secondary">Company Website *</label>
                                            <div class="input-field-container">
                                                <input id="company_website" type="text" placeholder="Enter company website" name="company_website" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="cell_phone" class="input-label-secondary">Cell Phone *</label>
                                            <div class="input-field-container">
                                                <input id="cell_phone" type="tel" placeholder="Enter cell number" name="cell_phone" class="input-secondary text-300" value="">
                                            </div>
                                        </div>


                                        <div class="mt-4 col-xl-9 col-md-4 col-12">
                                            <label for="address" class="input-label-secondary">Address *</label>
                                            <div class="input-field-container">
                                                <input id="address" type="text" placeholder="Enter street address" name="address" class="input-secondary" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="apt_suite" class="input-label-secondary">Apt/Suite</label>
                                            <div class="input-field-container">
                                                <input id="apt_suite" type="text" placeholder="Enter apartment" name="apt_suite" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="country" class="input-label-secondary">Country *</label>
                                            <div class="input-field-container">
                                                <select id="country" name="country" class="input-secondary">
                                                    <option value="Australia" selected>Australia</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="state" class="input-label-secondary">State *</label>
                                            <div class="input-field-container">
                                                <select id="state" name="state" class="input-secondary">
                                                    <option value="" style="display:none">Select a state</option>
                                                    <option value="New South Wales">New South Wales</option>
                                                    <option value="Victoria">Victoria</option>
                                                    <option value="Queensland">Queensland</option>
                                                    <option value="Western Australia">Western Australia</option>
                                                    <option value="South Australia">South Australia</option>
                                                    <option value="Tasmania">Tasmania</option>
                                                    <option value="Australian Capital Territory">Australian Capital Territory</option>
                                                    <option value="Northern Territory">Northern Territory</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="zip" class="input-label-secondary">ZIP *</label>
                                            <div class="input-field-container">
                                                <input id="zip" type="text" placeholder="Enter ZIP" name="zip" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="city" class="input-label-secondary">City *</label>
                                            <div class="input-field-container">
                                                <input id="city" type="text" placeholder="Enter City" name="city" class="input-secondary text-300" value="">
                                            </div>
                                        </div>


                                        <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                            <button type="submit" id="save-company-add-btn" style="border-radius:12px;border:none;font-weight:500" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Add Company

                                            </button>
                                        </div>
                                    </div>
                                </form>

                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>