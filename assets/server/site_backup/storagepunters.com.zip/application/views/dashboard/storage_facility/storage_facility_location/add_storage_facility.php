<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>


                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="tab_btn btn__manage__facility_storage">Manage Facility Storage</button>


                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Add your Storage Facility details</h1>
                                    </div>
                                </div>

                                <div class="border rounded dashboard ps-3 pe-3 mt-3">
                                    <div class="row my-2">

                                        <!-- Company Name -->
                                        <div class="col-12 mb-3">
                                            <label for="companiesDropdown" class="input-label-secondary">Company Name</label>
                                            <div class="input-field-container">
                                                <select id="companiesDropdown" name="company_name" class="input-secondary">
                                                    <option value="">Loading company...</option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <form id="storage-facility-add-form" class="mt-2 mt-md-4">
                                    <div class="row">
                                        <div class="mt-4 col-12">
                                            <label for="storage_facility_name" class="input-label-secondary">Facility Name *</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_name" type="text" name="storage_facility_name" class="input-secondary text-300" placeholder="e.g. Northside Storage Center" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_abn" class="input-label-secondary">ABN *</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_abn" type="text" name="storage_facility_abn" class="input-secondary text-300" placeholder="e.g. 51 824 753 556" value="">
                                            </div>
                                        </div>


                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_website" class="input-label-secondary">Facility Website *</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_website" type="text" placeholder="e.g. www.northsidestorage.com" name="storage_facility_website" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-12">
                                            <label for="storage_facility_description" class="input-label-secondary">Facility Description *</label>
                                            <div class="input-field-container">
                                                <textarea id="storage_facility_description" name="storage_facility_description" class="input-secondary2 text-300" placeholder="e.g. Northside Storage offers secure, 24/7 access self-storage units in various sizes." rows="6"></textarea>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_timezone" class="input-label-secondary">Timezone *</label>
                                            <div class="input-field-container">
                                                <select id="storage_facility_timezone" name="storage_facility_timezone" class="input-secondary text-300">
                                                    <option value="" style="display:none">Select a time zone</option>
                                                    <option value="Australia/Adelaide">Australia/Adelaide</option>
                                                    <option value="Australia/Brisbane" selected>Australia/Brisbane</option>
                                                    <option value="Australia/Broken_Hill">Australia/Broken_Hill</option>
                                                    <option value="Australia/Canberra">Australia/Canberra</option>
                                                    <option value="Australia/Currie">Australia/Currie</option>
                                                    <option value="Australia/Darwin">Australia/Darwin</option>
                                                    <option value="Australia/Eucla">Australia/Eucla</option>
                                                    <option value="Australia/Hobart">Australia/Hobart</option>
                                                    <option value="Australia/LHI">Australia/LHI</option>
                                                    <option value="Australia/Lindeman">Australia/Lindeman</option>
                                                    <option value="Australia/Lord_Howe">Australia/Lord_Howe</option>
                                                    <option value="Australia/Melbourne">Australia/Melbourne</option>
                                                    <option value="Australia/NSW">Australia/NSW</option>
                                                    <option value="Australia/North">Australia/North</option>
                                                    <option value="Australia/Perth">Australia/Perth</option>
                                                    <option value="Australia/Queensland">Australia/Queensland</option>
                                                    <option value="Australia/South">Australia/South</option>
                                                    <option value="Australia/Sydney">Australia/Sydney</option>
                                                    <option value="Australia/Tasmania">Australia/Tasmania</option>
                                                    <option value="Australia/Victoria">Australia/Victoria</option>
                                                    <option value="Australia/West">Australia/West</option>
                                                    <option value="Australia/Yancowinna">Australia/Yancowinna</option>
                                                </select>
                                            </div>
                                        </div>



                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_email" class="input-label-secondary">Facility Contact Email *</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_contact_email" type="email" name="storage_facility_contact_email" class="input-secondary text-300" placeholder="e.g. contact@example.com" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_email" class="input-label-secondary">Facility Additional Email *</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_additional_email" type="email" name="storage_facility_additional_email" class="input-secondary text-300" placeholder="e.g. support@example.com" value="">
                                            </div>
                                        </div>




                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="cell_phone" class="input-label-secondary">Cell Phone *</label>
                                            <div class="input-field-container">
                                                <input id="cell_phone" type="text" placeholder="e.g. (123) 456-7890" name="cell_phone" class="input-secondary text-300" value="">
                                            </div>
                                        </div>


                                        <div class="mt-4 col-12">
                                            <label for="storage_facility_office_hours" class="input-label-secondary">Office Hours *</label>
                                            <div class="input-field-container">
                                                <textarea id="storage_facility_office_hours" name="storage_facility_office_hours" class="input-secondary2 text-300" placeholder="e.g. Mon–Fri: 9am–5pm, Sat: 10am–2pm, Sun: Closed" rows="6"></textarea>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-12">
                                            <label for="storage_facility_payout_details" class="input-label-secondary">Payout Details *</label>
                                            <div class="input-field-container">
                                                <textarea id="storage_facility_payout_details" name="storage_facility_payout_details" class="input-secondary2 text-300" placeholder="e.g. Bank: Westpac, BSB: 123-456, Account: 987654321" rows="6"></textarea>
                                            </div>
                                        </div>


                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_youtube_video_url" class="input-label-secondary">YouTube Video URL</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_youtube_video_url" type="text" name="storage_facility_youtube_video_url" class="input-secondary text-300" placeholder="e.g. https://www.youtube.com/watch?v=example" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-lg-6 col-md-6">
                                            <label for="storage_facility_branding_logo" class="input-label-secondary">Brand Logo URL</label>
                                            <div class="input-field-container">
                                                <input id="storage_facility_branding_logo" type="text" name="storage_facility_branding_logo" class="input-secondary text-300" placeholder="e.g. https://yourdomain.com/logo.png" value="">
                                            </div>
                                        </div>



                                        <div class="mt-4 col-xl-9 col-md-4 col-12">
                                            <label for="address" class="input-label-secondary">Address *</label>
                                            <div class="input-field-container">
                                                <input id="address" type="text" placeholder="Enter street address" name="address" class="input-secondary" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="apt_suite" class="input-label-secondary">Apt/Suite</label>
                                            <div class="input-field-container">
                                                <input id="apt_suite" type="text" placeholder="Enter apartment" name="apt_suite" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="country" class="input-label-secondary">Country *</label>
                                            <div class="input-field-container">
                                                <select id="country" name="country" class="input-secondary">
                                                    <option value="Australia" selected>Australia</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="state" class="input-label-secondary">State *</label>
                                            <div class="input-field-container">
                                                <select id="state" name="state" class="input-secondary">
                                                    <option value="" style="display:none">Select a state</option>
                                                    <option value="New South Wales">New South Wales</option>
                                                    <option value="Victoria">Victoria</option>
                                                    <option value="Queensland" selected>Queensland</option>
                                                    <option value="Western Australia">Western Australia</option>
                                                    <option value="South Australia">South Australia</option>
                                                    <option value="Tasmania">Tasmania</option>
                                                    <option value="Australian Capital Territory">Australian Capital Territory</option>
                                                    <option value="Northern Territory">Northern Territory</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="zip" class="input-label-secondary">ZIP *</label>
                                            <div class="input-field-container">
                                                <input id="zip" type="text" placeholder="Enter ZIP" name="zip" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="city" class="input-label-secondary">City *</label>
                                            <div class="input-field-container">
                                                <input id="city" type="text" placeholder="Enter City" name="city" class="input-secondary text-300" value="">
                                            </div>
                                        </div>


                                        <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                            <button type="submit" id="save-storage-facility-add-btn" style="border-radius:12px;border:none;font-weight:500" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Add Facility
                                            </button>
                                        </div>
                                    </div>
                                </form>

                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>