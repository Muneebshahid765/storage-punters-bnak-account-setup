<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="tab_btn btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>

                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>
                                    <?php

                                    }

                                    ?>

                                </div>
                            </div>

                            <div class="">


                                <div class=" d-md-block">
                                    <div class="tab_list">
                                        <div class="__tab__auction__dashboard">
                                            <button class="tab_btn btn__all_auctions">All Auctions</button>
                                            <button class="false btn__won_auctions">Auctions Won</button>
                                            <button class="false btn__invoices_auctions">Invoices</button>
                                        </div>
                                    </div>

                                    <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                        <button type="button" style="border-radius:12px; borderborder:none; font-weight:500" class="add-auction-btn w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Add Auction

                                        </button>
                                    </div>



                                    <div class="border rounded dashboard ps-3 pe-3 mt-3">
                                        <div class="row my-2">

                                            <!-- Auction Type -->
                                            <div class="col-xl-4 col-md-4 col-12 mb-3">
                                                <label for="auctionTypeDropdown" class="input-label-secondary">Auction Type</label>
                                                <div class="input-field-container">
                                                    <select id="auctionTypeDropdown" name="auction_type" class="input-secondary">
                                                        <option value="">Loading types...</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Storage Facility -->
                                            <div class="col-xl-4 col-md-4 col-12 mb-3">
                                                <label for="storageFacilityDropdown" class="input-label-secondary">Storage Facility</label>
                                                <div class="input-field-container">
                                                    <select id="storageFacilityDropdown" name="storage_facility" class="input-secondary">
                                                        <option value="">Loading facilities...</option>
                                                    </select>
                                                </div>
                                            </div>

                                        </div>

                                    </div>



                                    <div class="__tab__table_auction__dashboard">
                                        <!-- <div class="border rounded dashboard ps-2 pe-2">
                                            <div class="my-2 row">
                                                <div class=" d-flex justify-content-between col-sm-12 col-12">
                                                    <div class="px-2 w-100 d-flex justify-content-center justify-content-md-between flex-column flex-md-row" style="background: rgba(0, 0, 0, 0.05); padding: 15px;">
                                                        <div>
                                                            <p class="mb-1 my-auto">Active Auctions Bid On </p>
                                                        </div>
                                                        <div>
                                                            <p class="my-auto">Current Time Zone - America/Los_Angeles</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="text-center dashboard ">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered table-hover">
                                                            <thead class="p-2 text-nowrap">
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">Auction #</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">Status</th>
                                                                <th style="width: 15%; text-align: left;" class="border ps-3">Seller</th>
                                                                <th style="width: 15%; text-align: left;" class="border ps-3">Ends</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">High Bid</th>
                                                                <th style="width: 8%; text-align: left;" class="border ps-3">My Max Bid</th>
                                                                <th style="width: 3%; text-align: left;" class="border ps-3">Actions</th>
                                                            </thead>
                                                            <tbody class="p-2 text-nowrap" data-dashlane-rid="03fd3258ebd8e6b8" data-dashlane-classification="other">
                                                                <th> <input type="text" placeholder="enter auction id" class="filter-box" name="sampleId" data-dashlane-rid="a08648a9f4ca483e" data-dashlane-classification="other"></th>
                                                                <th class="border"></th>
                                                                <th class="border"><input type="text" class="filter-box" placeholder="enter facility name" name="FacilityName" data-dashlane-rid="1914b6c1ea5dbfb3" data-dashlane-classification="name" data-kwimpalastatus="alive" data-kwimpalaid="1741451383701-2"></th>
                                                                <th class="border"><input type="date" class="filter-box" name="EndDate" data-dashlane-rid="f8c201f5f57256a9" data-dashlane-classification="date"></th>
                                                                <th class="border"><input type="text" class="filter-box" placeholder="enter high bid" name="CurrentHighBid" data-dashlane-rid="bec499ba083b3da5" data-dashlane-classification="other"> </th>
                                                                <th class="border"></th>
                                                                <th class="border"></th>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>-->
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>