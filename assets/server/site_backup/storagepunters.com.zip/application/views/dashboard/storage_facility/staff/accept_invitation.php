<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-header bg-success text-white text-center">
                    <h4 class="mb-0">You're Invited to Join</h4>
                </div>
                <div class="card-body">
                    <!-- Hidden Fields -->
                    <input type="hidden" id="user_id" value="<?= $user_id ?>">
                    <input type="hidden" id="company_id" value="<?= $company_id ?>">

                    <!-- Company Info -->
                    <div class="mb-4 text-center">
                        <h5 class="fw-bold mb-2">Company</h5>
                        <p id="company_name" class="fs-5 text-muted">Loading...</p>
                    </div>

                    <!-- Instructions -->
                    <p class="text-center mb-4">
                        To accept the invitation and become part of this organization, click below.
                    </p>

                    <!-- Buttons -->
                    <div class="d-flex justify-content-between">
                        <button type="button" id="btnCancel" class="btn btn-outline-secondary px-4">Reject</button>
                        <button type="button" id="btnAccept" class="btn btn-success px-4">Accept Invitation</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
