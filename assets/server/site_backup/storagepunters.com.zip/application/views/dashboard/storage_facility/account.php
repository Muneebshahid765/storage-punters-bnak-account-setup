<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>

                                        <button class="tab_btn btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="false btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>

                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Edit your Profile</h1>
                                    </div>
                                </div>
                                <form id="user-profile-form" class="mt-2 mt-md-4">
                                    <div class="row">
                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="firstname" class="input-label-secondary">First Name *</label>
                                            <div class="input-field-container">
                                                <input id="firstname" type="text" placeholder="Enter your first name" name="firstname" class="input-secondary text-300" value="" disabled>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-lg-3 col-md-6">
                                            <label for="lastname" class="input-label-secondary">Last Name *</label>
                                            <div class="input-field-container">
                                                <input id="lastname" type="text" placeholder="Enter last name" name="lastname" class="input-secondary text-300" value="" disabled>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-2 col-lg-3 col-md-6">
                                            <label for="dob" class="input-label-secondary">Date of Birth *</label>
                                            <div class="input-field-container">
                                                <input id="dob" type="date" name="dob" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-lg-4 col-md-6">
                                            <label for="standard_email_address" class="input-label-secondary">Email *</label>
                                            <div class="input-field-container">
                                                <input id="standard_email_address" type="email" placeholder="Enter Email Address" name="standard_email_address" class="input-secondary text-300" value="" disabled>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-lg-4 col-md-6">
                                            <label for="cell_phone" class="input-label-secondary">Cell Phone *</label>
                                            <div class="input-field-container">
                                                <input id="cell_phone" type="tel" placeholder="Enter cell number" name="cell_phone" class="input-secondary text-300" value="" disabled>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-lg-4 col-md-6">
                                            <label for="password" class="input-label-secondary">Password *</label>
                                            <div class="input-field-container">
                                                <input id="current_password" type="password" placeholder="Enter password" name="current_password" class="input-secondary text-300" value="">
                                                <div class="input-svg toggle-password">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="23.401" height="auto" viewBox="0 0 23.401 15.601" class="">
                                                        <path id="Icon_awesome-eye" data-name="Icon awesome-eye" d="M23.26,11.707A13.03,13.03,0,0,0,11.7,4.5,13.032,13.032,0,0,0,.141,11.708a1.314,1.314,0,0,0,0,1.186A13.03,13.03,0,0,0,11.7,20.1,13.032,13.032,0,0,0,23.26,12.893,1.314,1.314,0,0,0,23.26,11.707ZM11.7,18.151a5.85,5.85,0,1,1,5.85-5.85A5.85,5.85,0,0,1,11.7,18.151Zm0-9.75a3.872,3.872,0,0,0-1.028.154,1.944,1.944,0,0,1-2.718,2.718A3.891,3.891,0,1,0,11.7,8.4Z" transform="translate(0 -4.5)" fill="var(--btn-bg-yellow)"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-lg-4 col-md-6">
                                            <label for="password_confirmation" class="input-label-secondary">Repeat Password *</label>
                                            <div class="input-field-container">
                                                <input id="password_confirmation" type="password" placeholder="Enter password again" name="password_confirmation" class="input-secondary text-300" value="">
                                                <div class="input-svg toggle-password">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="23.401" height="auto" viewBox="0 0 23.401 15.601" class="">
                                                        <path id="Icon_awesome-eye" data-name="Icon awesome-eye" d="M23.26,11.707A13.03,13.03,0,0,0,11.7,4.5,13.032,13.032,0,0,0,.141,11.708a1.314,1.314,0,0,0,0,1.186A13.03,13.03,0,0,0,11.7,20.1,13.032,13.032,0,0,0,23.26,12.893,1.314,1.314,0,0,0,23.26,11.707ZM11.7,18.151a5.85,5.85,0,1,1,5.85-5.85A5.85,5.85,0,0,1,11.7,18.151Zm0-9.75a3.872,3.872,0,0,0-1.028.154,1.944,1.944,0,0,1-2.718,2.718A3.891,3.891,0,1,0,11.7,8.4Z" transform="translate(0 -4.5)" fill="var(--btn-bg-yellow)"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-9 col-md-4 col-12">
                                            <label for="address" class="input-label-secondary">Address *</label>
                                            <div class="input-field-container">
                                                <input id="address" type="text" placeholder="Enter street address" name="address" class="input-secondary" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="apt_suite" class="input-label-secondary">Apt/Suite</label>
                                            <div class="input-field-container">
                                                <input id="apt_suite" type="text" placeholder="Enter apartment" name="apt_suite" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="country" class="input-label-secondary">Country *</label>
                                            <div class="input-field-container">
                                                <select id="country" name="country" class="input-secondary">
                                                <option value="Australia" selected>Australia</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="state" class="input-label-secondary">State *</label>
                                            <div class="input-field-container">
                                                <select id="state" name="state" class="input-secondary">
                                                    <option value="" style="display:none">Select a state</option>
                                                    <option value="New South Wales">New South Wales</option>
                                                    <option value="Victoria">Victoria</option>
                                                    <option value="Queensland">Queensland</option>
                                                    <option value="Western Australia">Western Australia</option>
                                                    <option value="South Australia">South Australia</option>
                                                    <option value="Tasmania">Tasmania</option>
                                                    <option value="Australian Capital Territory">Australian Capital Territory</option>
                                                    <option value="Northern Territory">Northern Territory</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="zip" class="input-label-secondary">ZIP *</label>
                                            <div class="input-field-container">
                                                <input id="zip" type="text" placeholder="Enter ZIP" name="zip" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="city" class="input-label-secondary">City *</label>
                                            <div class="input-field-container">
                                                <input id="city" type="text" placeholder="Enter City" name="city" class="input-secondary text-300" value="">
                                            </div>
                                        </div>


                                        <div class="mt-4 col-xl-3 col-md-4 col-12">
                                            <label for="timezone" class="input-label-secondary">Time Zone *</label>
                                            <div class="input-field-container">
                                                <select id="timezone" name="timezone" class="input-secondary">
                                                    <option value="" style="display:none">Select a time zone</option>
                                                    <option value="Australia/Adelaide">Australia/Adelaide</option>
                                                    <option value="Australia/Brisbane" selected>Australia/Brisbane</option>
                                                    <option value="Australia/Broken_Hill">Australia/Broken_Hill</option>
                                                    <option value="Australia/Canberra">Australia/Canberra</option>
                                                    <option value="Australia/Currie">Australia/Currie</option>
                                                    <option value="Australia/Darwin">Australia/Darwin</option>
                                                    <option value="Australia/Eucla">Australia/Eucla</option>
                                                    <option value="Australia/Hobart">Australia/Hobart</option>
                                                    <option value="Australia/LHI">Australia/LHI</option>
                                                    <option value="Australia/Lindeman">Australia/Lindeman</option>
                                                    <option value="Australia/Lord_Howe">Australia/Lord_Howe</option>
                                                    <option value="Australia/Melbourne">Australia/Melbourne</option>
                                                    <option value="Australia/NSW">Australia/NSW</option>
                                                    <option value="Australia/North">Australia/North</option>
                                                    <option value="Australia/Perth">Australia/Perth</option>
                                                    <option value="Australia/Queensland">Australia/Queensland</option>
                                                    <option value="Australia/South">Australia/South</option>
                                                    <option value="Australia/Sydney">Australia/Sydney</option>
                                                    <option value="Australia/Tasmania">Australia/Tasmania</option>
                                                    <option value="Australia/Victoria">Australia/Victoria</option>
                                                    <option value="Australia/West">Australia/West</option>
                                                    <option value="Australia/Yancowinna">Australia/Yancowinna</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-9">
                                            <label for="hear_us" class="input-label-secondary">How did you hear about us?</label>
                                            <div class="input-field-container">
                                                <select id="hear_us" name="hear_us" class="input-secondary">
                                                    <option value="" selected>Select...</option>
                                                    <option value="google">Google Search</option>
                                                    <option value="social_media">Social Media (Facebook, Instagram, Twitter, etc.)</option>
                                                    <option value="word_of_mouth">Word of Mouth</option>
                                                    <option value="referral">Referral from a Friend</option>
                                                    <option value="email_campaign">Email Campaign</option>
                                                    <option value="tv_advertisement">TV Advertisement</option>
                                                    <option value="radio_advertisement">Radio Advertisement</option>
                                                    <option value="newspaper">Newspaper / Magazine</option>
                                                    <option value="online_advertisement">Online Advertisement</option>
                                                    <option value="youtube">YouTube</option>
                                                    <option value="blog">Blog / Article</option>
                                                    <option value="linkedin">LinkedIn</option>
                                                    <option value="company_website">Company Website</option>
                                                    <option value="event_or_webinar">Event or Webinar</option>
                                                    <option value="other">Other</option>
                                                </select>

                                            </div>
                                        </div>

                                        <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                            <button type="submit" id="save-updates-btn" style="border-radius:12px;border:none;font-weight:500" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Save Updates

                                            </button>
                                        </div>
                                    </div>
                                </form>

                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>