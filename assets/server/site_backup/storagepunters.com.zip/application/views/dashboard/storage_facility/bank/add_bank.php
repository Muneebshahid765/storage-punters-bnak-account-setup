<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>

                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>

                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="tab_btn btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>

                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Setup your Bank account details</h1>
                                    </div>
                                </div>
                                <form id="bank-setup-add-form" class="mt-2 mt-md-4">
                                    <div class="row">

                                        <div class="mt-4 col-xl-6 col-md-6">
                                            <label for="account_holder_name" class="input-label-secondary">Account Holder Name *</label>
                                            <div class="input-field-container">
                                                <input id="account_holder_name" type="text" placeholder="Enter account holder name" name="account_holder_name" class="input-secondary text-300">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-md-6">
                                            <label for="account_holder_type" class="input-label-secondary">Account Holder Type *</label>
                                            <select id="account_holder_type" name="account_holder_type" class="input-secondary text-300">
                                                <option value="" style="display:none">Select</option>
                                                <option value="individual">Individual</option>
                                                <option value="company" selected>Company</option>
                                            </select>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-md-6">
                                            <label for="routing_number" class="input-label-secondary">Routing Number *</label>
                                            <div class="input-field-container">
                                                <input id="routing_number" type="text" placeholder="Enter routing number" name="routing_number" class="input-secondary text-300">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-md-6">
                                            <label for="account_number" class="input-label-secondary">Account Number *</label>
                                            <div class="input-field-container">
                                                <input id="account_number" type="text" placeholder="Enter account number" name="account_number" class="input-secondary text-300">
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-6 col-md-6">
                                            <label for="account_type" class="input-label-secondary">Account Type (optional)</label>
                                            <select id="account_type" name="account_type" class="input-secondary text-300">
                                                <option value="" style="display:none">Select</option>
                                                <option value="checking" selected>Checking</option>
                                                <option value="savings">Savings</option>
                                            </select>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-6">
                                            <label for="country" class="input-label-secondary">Country *</label>
                                            <div class="input-field-container">
                                                <select id="country" name="country" class="input-secondary text-300">
                                                    <option value="" style="display:none">Select Country</option>
                                                    <option value="AU" selected>Australia</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mt-4 col-xl-3 col-md-6">
                                            <label for="currency" class="input-label-secondary">Currency *</label>
                                            <div class="input-field-container">
                                                <select id="currency" name="currency" class="input-secondary text-300" >
                                                    <option value="" style="display:none">Select Currency</option>
                                                    <option value="aud" selected>AUD - Australian Dollar</option>
                                                    <!-- Add more currencies as needed -->
                                                </select>
                                            </div>
                                        </div>


                                        <div style="width: max-content;" class="mt-4 mx-auto col-md-12">
                                            <button type="submit" id="save-bank-add-btn" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md" style="border-radius: 12px; border: none; font-weight: 500;">
                                                Add Bank
                                            </button>
                                        </div>
                                    </div>
                                </form>


                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>