<div class="p-0 d-flex flex-column h-100 container-fluid">

    <main style="flex-grow:1">
        <div class="customContainer mt-4 mb-4 decline-link  container-fluid">
            <h1 class="text-xl text-grey mb-0 mb-md-4" style="font-weight: bold;">My Account</h1>
            <div class="row">
                <div class="container-fluid">
                    <div class="">
                        <div class="">
                            <div class="tab_list mb-4">
                                <div class="__tab__dashboard">
                                    <button class="false btn__dashboard">Dashboard</button>
                                    <?php

                                    $userSessionData = $this->session->userdata('auction_user_session_data');
                                    $userRoleId = $userSessionData['role_id'];

                                    // Check if user is logged in
                                    if (in_array($userRoleId, [1])) {

                                    ?>

                                        <button class="false btn__edit__account">Edit Account</button>
                                        <button class="false btn__setup__company">Company Setup</button>
                                        <button class="tab_btn btn__setup__bank__account">Bank Account Setup</button>
                                        <button class="false btn__manage__staff">Manage Staff</button>
                                        <button class="false btn__manage__facility_storage">Manage Facility Storage</button>

                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col">
                                        <h1 class="text-500 mt-2 mt-md-0 text-grey mx-auto mx-md-0" style="font-weight: bold;">Edit your Bank account details</h1>
                                    </div>
                                </div>
                                <form id="bank-update-form" class="mt-2 mt-md-4">
                                    <div class="row">
                                        <div class="mt-4 col-xl-12 col-lg-12 col-md-12">
                                            <label for="account_holder_name" class="input-label-secondary">Account Holder Name *</label>
                                            <div class="input-field-container">
                                                <input id="account_holder_name" type="text" placeholder="Enter account holder name" name="account_holder_name" class="input-secondary text-300" value="">
                                            </div>
                                        </div>

                                        <div style="width:max-content" class="mt-4 mx-auto  col-md-12 col">
                                            <button type="submit" id="save-bank-updates-btn" style="border-radius:12px;border:none;font-weight:500" class="w-100 btn-yellow btn-contact text-uppercase px-md-4 btn btn-primary btn-md">Save Updates

                                            </button>
                                        </div>
                                    </div>
                                </form>

                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                                <div style="position: fixed; z-index: 9999; inset: 16px; pointer-events: none;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>