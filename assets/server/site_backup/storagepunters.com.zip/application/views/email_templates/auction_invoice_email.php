<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Your Invoice from Storage Punters</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body style="font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 0; padding: 20px;">
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; margin: auto; background-color: #ffffff; border: 1px solid #e3e3e3; border-radius: 8px;">
        <!-- Header -->
        <tr>
            <td style="padding: 20px 30px; text-align: center; background-color: #007550; border-top-left-radius: 8px; border-top-right-radius: 8px;">
                <h2 style="color: #ffffff; margin: 0;">Your Invoice from Storage Punters</h2>
            </td>
        </tr>

        <!-- Body -->
        <!-- Body -->
        <tr>
            <td style="padding: 30px;">
                <p style="font-size: 16px; color: #333;">Hello <strong><?= $name ?></strong>,</p>

                <p style="font-size: 16px; color: #333;">
                    This is an automated generated invoice from <strong>Storage Punters</strong>.
                </p>

                <p style="font-size: 16px; color: #333;">
                    Attached is the invoice for your winning auction item: <strong><?= $auction_item ?></strong>.
                </p>

                <p style="font-size: 16px; color: #333;">
                    To complete your payment, please follow these steps:
                </p>

                <ol style="font-size: 16px; color: #333; padding-left: 20px;">
                    <li>Log in to your account on the Storage Punters platform.</li>
                    <li>Navigate to <strong>Dashboard</strong> &rarr; <strong>Invoice</strong>.</li>
                    <li>Click the three dots <strong>(⋯)</strong> next to your invoice and select <strong>Pay Now</strong>.</li>
                    <li>Confirm the payment by clicking <strong>Pay Now</strong> again.</li>
                </ol>

                <p style="font-size: 16px; color: #333;">
                    If you have any questions regarding the invoice or your purchase, feel free to <strong><a href="<?= base_url('contact') ?>" style="color: #333; text-decoration: none;">contact our support team</a></strong>.
                </p>

                <p style="font-size: 16px; color: #333;">
                    Thank you for choosing Storage Punters!
                </p>

                <p style="font-size: 16px; color: #333;">
                    Sincerely,<br>
                    <strong>The Storage Punters Team</strong>
                </p>
            </td>
        </tr>


        <!-- Footer -->
        <tr>
            <td style="background-color: #f1f1f1; text-align: center; padding: 15px; font-size: 14px; color: #888; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;">
                &copy; <?= date('Y') ?> Storage Punters. All rights reserved.
            </td>
        </tr>
    </table>
</body>

</html>