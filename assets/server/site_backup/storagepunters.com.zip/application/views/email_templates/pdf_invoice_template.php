<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Storage Punters Invoice</title>
</head>
<body style="font-family: Arial, sans-serif; font-size: 14px; padding: 0; margin: 0; color: #333;">
    <div style="width: 100%; max-width: 700px; margin: 0 auto; padding: 20px;">

        <!-- Header -->
        <table width="100%" style="border-bottom: 2px solid #007550; padding-bottom: 10px; margin-bottom: 20px;">
            <tr>
                <td style="width: 50%;">
                    <img src="<?= base_url('assets/images/logo2.jpeg') ?>" alt="Storage Punters Logo" style="height: 60px;">
                </td>
                <td style="width: 50%; text-align: right;">
                    <h2 style="margin: 0; color: #007550;">Invoice #<?= $invoice_number ?></h2>
                    <p style="margin: 0;"><strong>Date:</strong> <?= date('F j, Y') ?></p>
                </td>
            </tr>
        </table>

        <!-- Billed To -->
        <h4 style="margin-top: 0; color: #007550;">Billed To:</h4>
        <p style="margin: 5px 0 20px 0;"><?= $name ?></p>

        <!-- Auction Info -->
        <h4 style="margin-bottom: 10px; color: #007550;">Auction Information</h4>
        <p style="margin: 5px 0 20px 0;"><strong>Auction:</strong> <?= $auction_item ?></p>

        <!-- Summary Table -->
        <h4 style="margin-bottom: 10px; color: #007550;">Summary</h4>
        <table width="100%" cellpadding="8" cellspacing="0" style="border-collapse: collapse; border: 1px solid #ccc;">
            <thead>
                <tr style="background-color: #f0f0f0;">
                    <th align="left" style="border: 1px solid #ccc;">Description</th>
                    <th align="right" style="border: 1px solid #ccc;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="border: 1px solid #ccc;"><?= $auction_item ?></td>
                    <td align="right" style="border: 1px solid #ccc;">$<?= number_format($auction_amount, 2) // replace with dynamic value ?></td>
                </tr>
            </tbody>
            <tfoot>
                <tr style="background-color: #f9f9f9;">
                    <td align="right" style="border: 1px solid #ccc;"><strong>Total:</strong></td>
                    <td align="right" style="border: 1px solid #ccc;"><strong>$<?= number_format($auction_total, 2) ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <!-- Footer -->
        <p style="text-align: center; margin-top: 40px; font-size: 13px; color: #666;">
            Thank you for your business with <strong>Storage Punters</strong>!
        </p>
    </div>
</body>
</html>
