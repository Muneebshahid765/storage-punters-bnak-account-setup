<div class="p-0 d-flex flex-column h-100 container-fluid">
    <main style="flex-grow:1">
        <div class="p-0 banner container-fluid">
            <section class="banner__info">
                <h1 class="text-xxl font-weight-bold px-2">Bid Online on Storage Auctions</h1>
                <div class="px-md-5 input-banner">
                    <div class="position-relative gradientInput mt-md-5 mt-3 mb-4 w-100" data-dashlane-rid="db01494838fb1d27">
                        <div class="outline_search_input_preElem f-flex align-items-center justify-content-center"><svg xmlns="http://www.w3.org/2000/svg" width="24.118" height="24.118" viewBox="0 0 24.118 24.118">
                                <path id="Icon_metro-target" dataName="Icon metro-target" d="M26.689,12.48H24.312a9.822,9.822,0,0,0-8.175-8.175V1.928H13.122V4.305A9.822,9.822,0,0,0,4.948,12.48H2.571v3.015H4.948a9.822,9.822,0,0,0,8.175,8.175v2.377h3.015V23.669a9.822,9.822,0,0,0,8.175-8.175h2.377V12.48Zm-5.445,0h-2.35a4.534,4.534,0,0,0-2.757-2.757V7.373a6.806,6.806,0,0,1,5.107,5.107ZM14.63,15.495a1.507,1.507,0,1,1,1.507-1.507A1.507,1.507,0,0,1,14.63,15.495ZM13.122,7.373v2.35a4.534,4.534,0,0,0-2.757,2.757H8.016A6.806,6.806,0,0,1,13.122,7.373ZM8.016,15.495h2.35a4.534,4.534,0,0,0,2.757,2.757V20.6A6.806,6.806,0,0,1,8.016,15.495ZM16.137,20.6v-2.35a4.534,4.534,0,0,0,2.757-2.757h2.35A6.806,6.806,0,0,1,16.137,20.6Z" transform="translate(-2.571 -1.928)" fill="var(--border-active)"></path>
                            </svg></div><input type="text" placeholder="Search Auctions" class="text-start outline_search_input  outline-dark px-md-5 ps-5" style="max-width: 100%; color: inherit;" data-dashlane-rid="16318bea6f07a5bc">
                        <div class="outline_search_input_postElem ">
                            <button type="button" style="min-width: max-content; width: 100%;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  text-200 outline-dark-btn btn btn-primary" data-dashlane-label="true" data-dashlane-rid="39a171eb66798573">
                                <div class="me-2 " style="color: inherit;">
                                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                    </svg>
                                </div><span>Search Now</span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class=" bidding__cards__container  container">
            <div class="d-none d-md-flex flex-wrap justify-content-center px-3 mt-3 mt-md-0 row">
                <div class="bid_card px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper border-right-xxl border-right-md border-right-sm ">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/register-to-bid.png') ?>" alt="registration to bid icon"> </div>
                        <h2 class="bid_card_title">1. Register to BID</h2>
                        <p>Start bidding online today by creating a <strong>FREE</strong> account</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card mt-sm-0 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper border-right-xxl border-right-md ">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/find-auction.png') ?>" alt="Map pin with lock icon"> </div>
                        <h2 class="bid_card_title">2. Find Auction</h2>
                        <p>Search and get notified of auctions located near you</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card mt-4 mt-md-0 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper border-right-xxl border-right-sm">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/start-bidding.png') ?>" alt="Auction hammer icon"> </div>
                        <h2 class="bid_card_title">3. Start Bidding</h2>
                        <p>Have your eyes set on some treasure? Start Bidding!</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card mt-md-4 mt-lg-0 mt-4 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/claim-your-treasure.png') ?>" alt="Golden star badge icon"> </div>
                        <h2 class="bid_card_title">4. Claim Your Treasure</h2>
                        <p>Won an auction? You'll receive an invoice with details to claim your treasure!</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
            </div>

            <div style="border-top:4px solid var(--icon-yellow);border-bottom:4px solid var(--icon-yellow);border-radius:15px" class="d-md-none bg-white mx-2 flex-wrap justify-content-center px-0 mt-3 mt-md-0 row">
                <div class="bid_card shadow-none border-0 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/register-to-bid.png') ?>" alt="registration to bid icon"> </div>
                        <h2 class="bid_card_title">1. Register to BID</h2>
                        <p>Start bidding online today by creating a <strong>FREE</strong> <!-- -->account</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card shadow-none border-0 mt-sm-0 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper ">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/find-auction.png') ?>" alt="Map pin with lock icon"> </div>
                        <h2 class="bid_card_title">2. Find Auction</h2>
                        <p>Search and get notified of auctions located near you</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card border-0 mt-0 px-1 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper ">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/start-bidding.png') ?>" alt="Auction hammer icon"> </div>
                        <h2 class="bid_card_title">3. Start Bidding</h2>
                        <p>Have your eyes set on some treasure? Start Bidding!</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
                <div class="bid_card border-0 px-1 mt-0 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="bid__card__wrapper">
                        <div class="bid_card_img"><img src="<?= base_url('assets/images/home/claim-your-treasure.png') ?>" alt="Golden star badge icon"> </div>
                        <h2 class="bid_card_title">4. Claim Your Treasure</h2>
                        <p>Won an auction? You'll receive an invoice with details to claim your treasure!</p>
                    </div>
                    <div class="bid_card_active"> </div>
                </div>
            </div>
        </div>
        <div class="feature_live_storage_auction customContainer container-fluid">
            <div class="p-1 p-md-3 text-center text-xl" style="font-size: 48px; font-weight: bold; color: var(--text-color-grey);">Featured Live Online Storage Auctions</div>
            <div class="d-md-block">
                <div class="relative">

                    <div class="feature__live__section__container__grid   mx-0 px-0 mt-5 pt-3 pb-4 m-0 row">
                        <!-- <div class="mb-4 col-lg-3 col-md-4">
                            <div class="bidding__card__grid"><img style="cursor: pointer;" src="https://mammothselfstore.com.au/wp-content/uploads/2022/07/forestglen_1.jpg" alt="Auction in Largo, Florida - Menards Self Storage - Largo - #474931" height="246" width="200">
                                <h2 class="__auction__number  __auction__number__bg  " style="font-weight: 500;">Auction #474931</h2>
                                <div class="d-flex card__info__container  flex-column w-100 false">
                                    <div class="card__info">
                                        <table class="table  table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3 ">
                                            <thead>
                                                <tr class="p-0">
                                                    <th scope="col">
                                                        <div class="text-center text-xs text-light-black font-semibold"> High Bid:</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">14</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">6</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">32</div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-primary-dark">
                                                        <div class="text-center high-bid-font font-semibold">$5,510</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Day</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Hour</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Min</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <h3 class="false text-center" style="font-size: 20px; font-weight: bold;">Menards Self Storage - Largo</h3>
                                        <p class=" text-light-black text-100 mb-1  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 20 20" aria-hidden="true" class="me-2" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path>
                                            </svg> 2200 Lake Ave,</p>
                                        <p class=" text-light-black text-100 mb-md-3 mb-2  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;">Largo, FL</p>
                                    </div>
                                    <div class="bidding__card__button__section">
                                        <table class="d-none  table table-bordered w-100 mt-3">
                                            <thead>
                                                <tr>
                                                    <th scope="col text-100">Days</th>
                                                    <th scope="col text-100">Hours</th>
                                                    <th scope="col text-100">Min</th>
                                                    <th class="false" scope="col text-100">Sec</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>14</td>
                                                    <td>6</td>
                                                    <td>32</td>
                                                    <td class="false">25</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <a href="<?php echo site_url("auctions/1"); ?>" target="_blank" rel="noopener noreferrer" style="text-decoration: none;">
                                            <button type="button" style="height: 44px; min-width: max-content; width: max-content;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  mx-auto mb-3 text-100 outline-light-btn btn btn-primary">View Auction
                                                <div class="ms-2 " style="color: inherit;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15.294" height="14.907" viewBox="0 0 15.294 14.907">
                                                        <path id="Icon_awesome-arrow-right" d="M6.5,3.646l.758-.758a.816.816,0,0,1,1.157,0L15.053,9.52a.816.816,0,0,1,0,1.157L8.418,17.313a.816.816,0,0,1-1.157,0L6.5,16.555a.82.82,0,0,1,.014-1.171l4.113-3.919H.819A.817.817,0,0,1,0,10.647V9.554a.817.817,0,0,1,.819-.819h9.81L6.516,4.817A.814.814,0,0,1,6.5,3.646Z" transform="translate(0 -2.647)" fill="inherit"></path>
                                                    </svg>
                                                </div>
                                            </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4 col-lg-3 col-md-4">
                            <div class="bidding__card__grid"><img style="cursor: pointer;" src="https://mammothselfstore.com.au/wp-content/uploads/2022/07/forestglen_1.jpg" alt="Auction in Largo, Florida - Menards Self Storage - Largo - #474931" height="246" width="200">
                                <h2 class="__auction__number  __auction__number__bg  " style="font-weight: 500;">Auction #464931</h2>
                                <div class="d-flex card__info__container  flex-column w-100 false">
                                    <div class="card__info">
                                        <table class="table  table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3 ">
                                            <thead>
                                                <tr class="p-0">
                                                    <th scope="col">
                                                        <div class="text-center text-xs text-light-black font-semibold"> High Bid:</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">14</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">6</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">32</div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-primary-dark">
                                                        <div class="text-center high-bid-font font-semibold">$6,610</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Day</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Hour</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Min</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <h3 class="false text-center" style="font-size: 20px; font-weight: bold;">Menards Self Storage - Largo</h3>
                                        <p class=" text-light-black text-100 mb-1  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 20 20" aria-hidden="true" class="me-2" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path>
                                            </svg> 2200 Lake Ave,</p>
                                        <p class=" text-light-black text-100 mb-md-3 mb-2  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;">Largo, FL</p>
                                    </div>
                                    <div class="bidding__card__button__section">
                                        <table class="d-none  table table-bordered w-100 mt-3">
                                            <thead>
                                                <tr>
                                                    <th scope="col text-100">Days</th>
                                                    <th scope="col text-100">Hours</th>
                                                    <th scope="col text-100">Min</th>
                                                    <th class="false" scope="col text-100">Sec</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>14</td>
                                                    <td>6</td>
                                                    <td>32</td>
                                                    <td class="false">25</td>
                                                </tr>
                                            </tbody>
                                        </table><a href="<?php echo site_url("auctions/2"); ?>" target="_blank" rel="noopener noreferrer" style="text-decoration: none;"><button type="button" style="height: 44px; min-width: max-content; width: max-content;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  mx-auto mb-3 text-100 outline-light-btn btn btn-primary">View Auction <div class="ms-2 " style="color: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="15.294" height="14.907" viewBox="0 0 15.294 14.907">
                                                        <path id="Icon_awesome-arrow-right" d="M6.5,3.646l.758-.758a.816.816,0,0,1,1.157,0L15.053,9.52a.816.816,0,0,1,0,1.157L8.418,17.313a.816.816,0,0,1-1.157,0L6.5,16.555a.82.82,0,0,1,.014-1.171l4.113-3.919H.819A.817.817,0,0,1,0,10.647V9.554a.817.817,0,0,1,.819-.819h9.81L6.516,4.817A.814.814,0,0,1,6.5,3.646Z" transform="translate(0 -2.647)" fill="inherit"></path>
                                                    </svg></div></button></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-4 col-lg-3 col-md-4">
                            <div class="bidding__card__grid"><img style="cursor: pointer;" src="https://mammothselfstore.com.au/wp-content/uploads/2022/07/forestglen_1.jpg" alt="Auction in Largo, Florida - Menards Self Storage - Largo - #474931" height="246" width="200">
                                <h2 class="__auction__number  __auction__number__bg  " style="font-weight: 500;">Auction #494921</h2>
                                <div class="d-flex card__info__container  flex-column w-100 false">
                                    <div class="card__info">
                                        <table class="table  table-bordered w-100 mt-md-3 mt-2 mb-2 mb-md-3 ">
                                            <thead>
                                                <tr class="p-0">
                                                    <th scope="col">
                                                        <div class="text-center text-xs text-light-black font-semibold"> High Bid:</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">14</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">6</div>
                                                    </th>
                                                    <th scope="col">
                                                        <div class="text-center text-300 font-semibold">32</div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-primary-dark">
                                                        <div class="text-center high-bid-font font-semibold">$6,610</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Day</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Hour</div>
                                                    </td>
                                                    <td>
                                                        <div class="text-center text-17 font-semibold text-muted-dark text-light-black">Min</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <h3 class="false text-center" style="font-size: 20px; font-weight: bold;">Menards Self Storage - Largo</h3>
                                        <p class=" text-light-black text-100 mb-1  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 20 20" aria-hidden="true" class="me-2" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path>
                                            </svg> 2200 Lake Ave,</p>
                                        <p class=" text-light-black text-100 mb-md-3 mb-2  d-flex align-items-center  justify-content-center " style="font-size: 15px; font-weight: 500;">Largo, FL</p>
                                    </div>
                                    <div class="bidding__card__button__section">
                                        <table class="d-none  table table-bordered w-100 mt-3">
                                            <thead>
                                                <tr>
                                                    <th scope="col text-100">Days</th>
                                                    <th scope="col text-100">Hours</th>
                                                    <th scope="col text-100">Min</th>
                                                    <th class="false" scope="col text-100">Sec</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>14</td>
                                                    <td>6</td>
                                                    <td>32</td>
                                                    <td class="false">25</td>
                                                </tr>
                                            </tbody>
                                        </table><a href="<?php echo site_url("auctions/3"); ?>" target="_blank" rel="noopener noreferrer" style="text-decoration: none;"><button type="button" style="height: 44px; min-width: max-content; width: max-content;" class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center  mx-auto mb-3 text-100 outline-light-btn btn btn-primary">View Auction <div class="ms-2 " style="color: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="15.294" height="14.907" viewBox="0 0 15.294 14.907">
                                                        <path id="Icon_awesome-arrow-right" d="M6.5,3.646l.758-.758a.816.816,0,0,1,1.157,0L15.053,9.52a.816.816,0,0,1,0,1.157L8.418,17.313a.816.816,0,0,1-1.157,0L6.5,16.555a.82.82,0,0,1,.014-1.171l4.113-3.919H.819A.817.817,0,0,1,0,10.647V9.554a.817.817,0,0,1,.819-.819h9.81L6.516,4.817A.814.814,0,0,1,6.5,3.646Z" transform="translate(0 -2.647)" fill="inherit"></path>
                                                    </svg></div></button></a>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <div class="right-arrow hide-md">&gt;</div>
                </div>
            </div>
        </div>
        <div class="registerNow_banner my-4 py-3 p-lg-0 undefined container-fluid">
            <div class="d-flex w-100 customContainer align-items-center h-100 container-fluid">
                <div class="d-flex align-items-center justify-content-center justify-content-md-none w-100"><img src="<?= base_url('assets/images/home/gavel-icon.png') ?>" alt="hammer" width="100%" style="max-width: 97px; mix-blend-mode: multiply;" class="me-sm-5 me-3">
                    <div class=" d-md-flex flex-md-row align-items-center justify-content-between" style="flex-grow: 1;">
                        <h3 class="text-md pb-2 text-white" style="max-width: 33ch;">Create Your <b>Free</b> Account And Start <b>Bidding On Storage Auctions!</b></h3>
                        <div class="mt-2 mt-md-0">


                            <button type="button" style="height: 66px; min-width: max-content; width: max-content;"
                                class=" btn_primary_gradient position-relative px-3 font-semibold d-flex justify-content-center  align-items-center   text-uppercase  font-semibold text-500     outline-dark-btn btn btn-primary"
                                data-bs-toggle="modal" data-bs-target="#registerModal">
                                <div class="me-2" style="color: inherit;">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="me-1 d-flex d-md-none" height="18" width="18" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"></path>
                                    </svg>
                                </div>Register Now
                            </button>


                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
</div>