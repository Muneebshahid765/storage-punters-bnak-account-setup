<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-08 02:06:07 --> Config Class Initialized
INFO - 2025-05-08 02:06:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 02:06:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 02:06:07 --> Utf8 Class Initialized
INFO - 2025-05-08 02:06:07 --> URI Class Initialized
DEBUG - 2025-05-08 02:06:07 --> No URI present. Default controller set.
INFO - 2025-05-08 02:06:07 --> Router Class Initialized
INFO - 2025-05-08 02:06:07 --> Output Class Initialized
INFO - 2025-05-08 02:06:07 --> Security Class Initialized
DEBUG - 2025-05-08 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 02:06:07 --> Input Class Initialized
INFO - 2025-05-08 02:06:07 --> Language Class Initialized
INFO - 2025-05-08 02:06:07 --> Loader Class Initialized
INFO - 2025-05-08 02:06:07 --> Helper loaded: url_helper
INFO - 2025-05-08 02:06:07 --> Helper loaded: string_helper
INFO - 2025-05-08 02:06:07 --> Helper loaded: form_helper
INFO - 2025-05-08 02:06:07 --> Helper loaded: file_helper
INFO - 2025-05-08 02:06:07 --> Helper loaded: html_helper
INFO - 2025-05-08 02:06:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 02:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 02:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 02:06:07 --> Controller Class Initialized
INFO - 2025-05-08 02:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 02:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 02:06:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 02:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 02:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 02:06:07 --> Final output sent to browser
DEBUG - 2025-05-08 02:06:07 --> Total execution time: 0.0512
INFO - 2025-05-08 02:06:09 --> Config Class Initialized
INFO - 2025-05-08 02:06:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 02:06:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 02:06:09 --> Utf8 Class Initialized
INFO - 2025-05-08 02:06:09 --> URI Class Initialized
INFO - 2025-05-08 02:06:09 --> Router Class Initialized
INFO - 2025-05-08 02:06:09 --> Output Class Initialized
INFO - 2025-05-08 02:06:09 --> Security Class Initialized
DEBUG - 2025-05-08 02:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 02:06:09 --> Input Class Initialized
INFO - 2025-05-08 02:06:09 --> Language Class Initialized
INFO - 2025-05-08 02:06:09 --> Loader Class Initialized
INFO - 2025-05-08 02:06:09 --> Helper loaded: url_helper
INFO - 2025-05-08 02:06:09 --> Helper loaded: string_helper
INFO - 2025-05-08 02:06:09 --> Helper loaded: form_helper
INFO - 2025-05-08 02:06:09 --> Helper loaded: file_helper
INFO - 2025-05-08 02:06:09 --> Helper loaded: html_helper
INFO - 2025-05-08 02:06:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 02:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 02:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 02:06:09 --> Controller Class Initialized
INFO - 2025-05-08 02:06:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 02:06:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 02:06:09 --> File loaded: /home/storagep/public_html/application/views/pages/contact_us.php
INFO - 2025-05-08 02:06:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 02:06:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 02:06:09 --> Final output sent to browser
DEBUG - 2025-05-08 02:06:09 --> Total execution time: 0.0055
INFO - 2025-05-08 02:15:46 --> Config Class Initialized
INFO - 2025-05-08 02:15:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 02:15:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 02:15:46 --> Utf8 Class Initialized
INFO - 2025-05-08 02:15:46 --> URI Class Initialized
DEBUG - 2025-05-08 02:15:46 --> No URI present. Default controller set.
INFO - 2025-05-08 02:15:46 --> Router Class Initialized
INFO - 2025-05-08 02:15:46 --> Output Class Initialized
INFO - 2025-05-08 02:15:46 --> Security Class Initialized
DEBUG - 2025-05-08 02:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 02:15:46 --> Input Class Initialized
INFO - 2025-05-08 02:15:46 --> Language Class Initialized
INFO - 2025-05-08 02:15:46 --> Loader Class Initialized
INFO - 2025-05-08 02:15:46 --> Helper loaded: url_helper
INFO - 2025-05-08 02:15:46 --> Helper loaded: string_helper
INFO - 2025-05-08 02:15:46 --> Helper loaded: form_helper
INFO - 2025-05-08 02:15:46 --> Helper loaded: file_helper
INFO - 2025-05-08 02:15:46 --> Helper loaded: html_helper
INFO - 2025-05-08 02:15:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 02:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 02:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 02:15:46 --> Controller Class Initialized
INFO - 2025-05-08 02:15:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 02:15:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 02:15:46 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 02:15:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 02:15:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 02:15:46 --> Final output sent to browser
DEBUG - 2025-05-08 02:15:46 --> Total execution time: 0.0362
INFO - 2025-05-08 03:17:42 --> Config Class Initialized
INFO - 2025-05-08 03:17:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 03:17:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 03:17:42 --> Utf8 Class Initialized
INFO - 2025-05-08 03:17:42 --> URI Class Initialized
DEBUG - 2025-05-08 03:17:42 --> No URI present. Default controller set.
INFO - 2025-05-08 03:17:42 --> Router Class Initialized
INFO - 2025-05-08 03:17:42 --> Output Class Initialized
INFO - 2025-05-08 03:17:42 --> Security Class Initialized
DEBUG - 2025-05-08 03:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 03:17:42 --> Input Class Initialized
INFO - 2025-05-08 03:17:42 --> Language Class Initialized
INFO - 2025-05-08 03:17:42 --> Loader Class Initialized
INFO - 2025-05-08 03:17:42 --> Helper loaded: url_helper
INFO - 2025-05-08 03:17:42 --> Helper loaded: string_helper
INFO - 2025-05-08 03:17:42 --> Helper loaded: form_helper
INFO - 2025-05-08 03:17:42 --> Helper loaded: file_helper
INFO - 2025-05-08 03:17:42 --> Helper loaded: html_helper
INFO - 2025-05-08 03:17:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 03:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 03:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 03:17:42 --> Controller Class Initialized
INFO - 2025-05-08 03:17:42 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 03:17:42 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 03:17:42 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 03:17:42 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 03:17:42 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 03:17:42 --> Final output sent to browser
DEBUG - 2025-05-08 03:17:42 --> Total execution time: 0.0541
INFO - 2025-05-08 04:05:14 --> Config Class Initialized
INFO - 2025-05-08 04:05:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:05:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:05:14 --> Utf8 Class Initialized
INFO - 2025-05-08 04:05:14 --> URI Class Initialized
DEBUG - 2025-05-08 04:05:14 --> No URI present. Default controller set.
INFO - 2025-05-08 04:05:14 --> Router Class Initialized
INFO - 2025-05-08 04:05:14 --> Output Class Initialized
INFO - 2025-05-08 04:05:14 --> Security Class Initialized
DEBUG - 2025-05-08 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:05:14 --> Input Class Initialized
INFO - 2025-05-08 04:05:14 --> Language Class Initialized
INFO - 2025-05-08 04:05:14 --> Loader Class Initialized
INFO - 2025-05-08 04:05:14 --> Helper loaded: url_helper
INFO - 2025-05-08 04:05:14 --> Helper loaded: string_helper
INFO - 2025-05-08 04:05:14 --> Helper loaded: form_helper
INFO - 2025-05-08 04:05:14 --> Helper loaded: file_helper
INFO - 2025-05-08 04:05:14 --> Helper loaded: html_helper
INFO - 2025-05-08 04:05:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:05:14 --> Controller Class Initialized
INFO - 2025-05-08 04:05:14 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:05:14 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:05:14 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:05:14 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:05:14 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:05:14 --> Final output sent to browser
DEBUG - 2025-05-08 04:05:14 --> Total execution time: 0.0882
INFO - 2025-05-08 04:06:06 --> Config Class Initialized
INFO - 2025-05-08 04:06:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:06:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:06:06 --> Utf8 Class Initialized
INFO - 2025-05-08 04:06:06 --> URI Class Initialized
INFO - 2025-05-08 04:06:06 --> Router Class Initialized
INFO - 2025-05-08 04:06:06 --> Output Class Initialized
INFO - 2025-05-08 04:06:06 --> Security Class Initialized
DEBUG - 2025-05-08 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:06:06 --> Input Class Initialized
INFO - 2025-05-08 04:06:06 --> Language Class Initialized
INFO - 2025-05-08 04:06:06 --> Loader Class Initialized
INFO - 2025-05-08 04:06:06 --> Helper loaded: url_helper
INFO - 2025-05-08 04:06:06 --> Helper loaded: string_helper
INFO - 2025-05-08 04:06:06 --> Helper loaded: form_helper
INFO - 2025-05-08 04:06:06 --> Helper loaded: file_helper
INFO - 2025-05-08 04:06:06 --> Helper loaded: html_helper
INFO - 2025-05-08 04:06:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:06:06 --> Controller Class Initialized
INFO - 2025-05-08 04:06:07 --> Config Class Initialized
INFO - 2025-05-08 04:06:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:06:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:06:07 --> Utf8 Class Initialized
INFO - 2025-05-08 04:06:07 --> URI Class Initialized
DEBUG - 2025-05-08 04:06:07 --> No URI present. Default controller set.
INFO - 2025-05-08 04:06:07 --> Router Class Initialized
INFO - 2025-05-08 04:06:07 --> Output Class Initialized
INFO - 2025-05-08 04:06:07 --> Security Class Initialized
DEBUG - 2025-05-08 04:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:06:07 --> Input Class Initialized
INFO - 2025-05-08 04:06:07 --> Language Class Initialized
INFO - 2025-05-08 04:06:07 --> Loader Class Initialized
INFO - 2025-05-08 04:06:07 --> Helper loaded: url_helper
INFO - 2025-05-08 04:06:07 --> Helper loaded: string_helper
INFO - 2025-05-08 04:06:07 --> Helper loaded: form_helper
INFO - 2025-05-08 04:06:07 --> Helper loaded: file_helper
INFO - 2025-05-08 04:06:07 --> Helper loaded: html_helper
INFO - 2025-05-08 04:06:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:06:07 --> Controller Class Initialized
INFO - 2025-05-08 04:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:06:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:06:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:06:07 --> Final output sent to browser
DEBUG - 2025-05-08 04:06:07 --> Total execution time: 0.0032
INFO - 2025-05-08 04:06:09 --> Config Class Initialized
INFO - 2025-05-08 04:06:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:06:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:06:09 --> Utf8 Class Initialized
INFO - 2025-05-08 04:06:09 --> URI Class Initialized
INFO - 2025-05-08 04:06:09 --> Router Class Initialized
INFO - 2025-05-08 04:06:09 --> Output Class Initialized
INFO - 2025-05-08 04:06:09 --> Security Class Initialized
DEBUG - 2025-05-08 04:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:06:09 --> Input Class Initialized
INFO - 2025-05-08 04:06:09 --> Language Class Initialized
INFO - 2025-05-08 04:06:09 --> Loader Class Initialized
INFO - 2025-05-08 04:06:09 --> Helper loaded: url_helper
INFO - 2025-05-08 04:06:09 --> Helper loaded: string_helper
INFO - 2025-05-08 04:06:09 --> Helper loaded: form_helper
INFO - 2025-05-08 04:06:09 --> Helper loaded: file_helper
INFO - 2025-05-08 04:06:09 --> Helper loaded: html_helper
INFO - 2025-05-08 04:06:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:06:09 --> Controller Class Initialized
INFO - 2025-05-08 04:06:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:07:46 --> Config Class Initialized
INFO - 2025-05-08 04:07:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:07:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:07:46 --> Utf8 Class Initialized
INFO - 2025-05-08 04:07:46 --> URI Class Initialized
DEBUG - 2025-05-08 04:07:46 --> No URI present. Default controller set.
INFO - 2025-05-08 04:07:46 --> Router Class Initialized
INFO - 2025-05-08 04:07:46 --> Output Class Initialized
INFO - 2025-05-08 04:07:46 --> Security Class Initialized
DEBUG - 2025-05-08 04:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:07:46 --> Input Class Initialized
INFO - 2025-05-08 04:07:46 --> Language Class Initialized
INFO - 2025-05-08 04:07:46 --> Loader Class Initialized
INFO - 2025-05-08 04:07:46 --> Helper loaded: url_helper
INFO - 2025-05-08 04:07:46 --> Helper loaded: string_helper
INFO - 2025-05-08 04:07:46 --> Helper loaded: form_helper
INFO - 2025-05-08 04:07:46 --> Helper loaded: file_helper
INFO - 2025-05-08 04:07:46 --> Helper loaded: html_helper
INFO - 2025-05-08 04:07:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:07:46 --> Controller Class Initialized
INFO - 2025-05-08 04:07:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:07:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:07:46 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:07:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:07:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:07:46 --> Final output sent to browser
DEBUG - 2025-05-08 04:07:46 --> Total execution time: 0.0306
INFO - 2025-05-08 04:07:49 --> Config Class Initialized
INFO - 2025-05-08 04:07:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:07:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:07:49 --> Utf8 Class Initialized
INFO - 2025-05-08 04:07:49 --> URI Class Initialized
INFO - 2025-05-08 04:07:49 --> Router Class Initialized
INFO - 2025-05-08 04:07:49 --> Output Class Initialized
INFO - 2025-05-08 04:07:49 --> Security Class Initialized
DEBUG - 2025-05-08 04:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:07:49 --> Input Class Initialized
INFO - 2025-05-08 04:07:49 --> Language Class Initialized
INFO - 2025-05-08 04:07:49 --> Loader Class Initialized
INFO - 2025-05-08 04:07:49 --> Helper loaded: url_helper
INFO - 2025-05-08 04:07:49 --> Helper loaded: string_helper
INFO - 2025-05-08 04:07:49 --> Helper loaded: form_helper
INFO - 2025-05-08 04:07:49 --> Helper loaded: file_helper
INFO - 2025-05-08 04:07:49 --> Helper loaded: html_helper
INFO - 2025-05-08 04:07:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:07:49 --> Controller Class Initialized
INFO - 2025-05-08 04:07:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:07:59 --> Config Class Initialized
INFO - 2025-05-08 04:07:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:07:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:07:59 --> Utf8 Class Initialized
INFO - 2025-05-08 04:07:59 --> URI Class Initialized
INFO - 2025-05-08 04:07:59 --> Router Class Initialized
INFO - 2025-05-08 04:07:59 --> Output Class Initialized
INFO - 2025-05-08 04:07:59 --> Security Class Initialized
DEBUG - 2025-05-08 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:07:59 --> Input Class Initialized
INFO - 2025-05-08 04:07:59 --> Language Class Initialized
INFO - 2025-05-08 04:07:59 --> Loader Class Initialized
INFO - 2025-05-08 04:07:59 --> Helper loaded: url_helper
INFO - 2025-05-08 04:07:59 --> Helper loaded: string_helper
INFO - 2025-05-08 04:07:59 --> Helper loaded: form_helper
INFO - 2025-05-08 04:07:59 --> Helper loaded: file_helper
INFO - 2025-05-08 04:07:59 --> Helper loaded: html_helper
INFO - 2025-05-08 04:07:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:07:59 --> Controller Class Initialized
INFO - 2025-05-08 04:07:59 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:07:59 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:07:59 --> File loaded: /home/storagep/public_html/application/views/auth/sign_in.php
INFO - 2025-05-08 04:07:59 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:07:59 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:07:59 --> Final output sent to browser
DEBUG - 2025-05-08 04:07:59 --> Total execution time: 0.0060
INFO - 2025-05-08 04:08:48 --> Config Class Initialized
INFO - 2025-05-08 04:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:08:48 --> Utf8 Class Initialized
INFO - 2025-05-08 04:08:48 --> URI Class Initialized
INFO - 2025-05-08 04:08:48 --> Router Class Initialized
INFO - 2025-05-08 04:08:48 --> Output Class Initialized
INFO - 2025-05-08 04:08:48 --> Security Class Initialized
DEBUG - 2025-05-08 04:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:08:48 --> Input Class Initialized
INFO - 2025-05-08 04:08:48 --> Language Class Initialized
INFO - 2025-05-08 04:08:48 --> Loader Class Initialized
INFO - 2025-05-08 04:08:48 --> Helper loaded: url_helper
INFO - 2025-05-08 04:08:48 --> Helper loaded: string_helper
INFO - 2025-05-08 04:08:48 --> Helper loaded: form_helper
INFO - 2025-05-08 04:08:48 --> Helper loaded: file_helper
INFO - 2025-05-08 04:08:48 --> Helper loaded: html_helper
INFO - 2025-05-08 04:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:08:48 --> Controller Class Initialized
INFO - 2025-05-08 04:08:48 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:08:48 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:08:48 --> File loaded: /home/storagep/public_html/application/views/auth/sign_in.php
INFO - 2025-05-08 04:08:48 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:08:48 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:08:48 --> Final output sent to browser
DEBUG - 2025-05-08 04:08:48 --> Total execution time: 0.0419
INFO - 2025-05-08 04:09:07 --> Config Class Initialized
INFO - 2025-05-08 04:09:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:07 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:07 --> URI Class Initialized
INFO - 2025-05-08 04:09:07 --> Router Class Initialized
INFO - 2025-05-08 04:09:07 --> Output Class Initialized
INFO - 2025-05-08 04:09:07 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:07 --> Input Class Initialized
INFO - 2025-05-08 04:09:07 --> Language Class Initialized
INFO - 2025-05-08 04:09:07 --> Loader Class Initialized
INFO - 2025-05-08 04:09:07 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:07 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:07 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:07 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:07 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:07 --> Controller Class Initialized
INFO - 2025-05-08 04:09:07 --> Model "UserModel" initialized
INFO - 2025-05-08 04:09:08 --> Config Class Initialized
INFO - 2025-05-08 04:09:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:08 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:08 --> URI Class Initialized
INFO - 2025-05-08 04:09:08 --> Router Class Initialized
INFO - 2025-05-08 04:09:08 --> Output Class Initialized
INFO - 2025-05-08 04:09:08 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:08 --> Input Class Initialized
INFO - 2025-05-08 04:09:08 --> Language Class Initialized
INFO - 2025-05-08 04:09:08 --> Loader Class Initialized
INFO - 2025-05-08 04:09:08 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:08 --> Controller Class Initialized
INFO - 2025-05-08 04:09:08 --> Config Class Initialized
INFO - 2025-05-08 04:09:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:08 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:08 --> URI Class Initialized
DEBUG - 2025-05-08 04:09:08 --> No URI present. Default controller set.
INFO - 2025-05-08 04:09:08 --> Router Class Initialized
INFO - 2025-05-08 04:09:08 --> Output Class Initialized
INFO - 2025-05-08 04:09:08 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:08 --> Input Class Initialized
INFO - 2025-05-08 04:09:08 --> Language Class Initialized
INFO - 2025-05-08 04:09:08 --> Loader Class Initialized
INFO - 2025-05-08 04:09:08 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:08 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:08 --> Controller Class Initialized
INFO - 2025-05-08 04:09:08 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:09:08 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:09:08 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:09:08 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:09:08 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:09:08 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:08 --> Total execution time: 0.0039
INFO - 2025-05-08 04:09:10 --> Config Class Initialized
INFO - 2025-05-08 04:09:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:10 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:10 --> URI Class Initialized
INFO - 2025-05-08 04:09:10 --> Router Class Initialized
INFO - 2025-05-08 04:09:10 --> Output Class Initialized
INFO - 2025-05-08 04:09:10 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:10 --> Input Class Initialized
INFO - 2025-05-08 04:09:10 --> Language Class Initialized
INFO - 2025-05-08 04:09:10 --> Loader Class Initialized
INFO - 2025-05-08 04:09:10 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:10 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:10 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:10 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:10 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:10 --> Controller Class Initialized
INFO - 2025-05-08 04:09:10 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:13 --> Config Class Initialized
INFO - 2025-05-08 04:09:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:13 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:13 --> URI Class Initialized
INFO - 2025-05-08 04:09:13 --> Router Class Initialized
INFO - 2025-05-08 04:09:13 --> Output Class Initialized
INFO - 2025-05-08 04:09:13 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:13 --> Input Class Initialized
INFO - 2025-05-08 04:09:13 --> Language Class Initialized
INFO - 2025-05-08 04:09:13 --> Loader Class Initialized
INFO - 2025-05-08 04:09:13 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:13 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:13 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:13 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:13 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:13 --> Controller Class Initialized
INFO - 2025-05-08 04:09:14 --> Config Class Initialized
INFO - 2025-05-08 04:09:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:14 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:14 --> URI Class Initialized
DEBUG - 2025-05-08 04:09:14 --> No URI present. Default controller set.
INFO - 2025-05-08 04:09:14 --> Router Class Initialized
INFO - 2025-05-08 04:09:14 --> Output Class Initialized
INFO - 2025-05-08 04:09:14 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:14 --> Input Class Initialized
INFO - 2025-05-08 04:09:14 --> Language Class Initialized
INFO - 2025-05-08 04:09:14 --> Loader Class Initialized
INFO - 2025-05-08 04:09:14 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:14 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:14 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:14 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:14 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:14 --> Controller Class Initialized
INFO - 2025-05-08 04:09:14 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:09:14 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:09:14 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:09:14 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:09:14 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:09:14 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:14 --> Total execution time: 0.0076
INFO - 2025-05-08 04:09:16 --> Config Class Initialized
INFO - 2025-05-08 04:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:16 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:16 --> URI Class Initialized
INFO - 2025-05-08 04:09:16 --> Router Class Initialized
INFO - 2025-05-08 04:09:16 --> Output Class Initialized
INFO - 2025-05-08 04:09:16 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:16 --> Input Class Initialized
INFO - 2025-05-08 04:09:16 --> Language Class Initialized
INFO - 2025-05-08 04:09:16 --> Loader Class Initialized
INFO - 2025-05-08 04:09:16 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:16 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:16 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:16 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:16 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:16 --> Controller Class Initialized
INFO - 2025-05-08 04:09:16 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:17 --> Config Class Initialized
INFO - 2025-05-08 04:09:17 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:17 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:17 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:17 --> URI Class Initialized
INFO - 2025-05-08 04:09:17 --> Router Class Initialized
INFO - 2025-05-08 04:09:17 --> Output Class Initialized
INFO - 2025-05-08 04:09:17 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:17 --> Input Class Initialized
INFO - 2025-05-08 04:09:17 --> Language Class Initialized
INFO - 2025-05-08 04:09:17 --> Loader Class Initialized
INFO - 2025-05-08 04:09:17 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:17 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:17 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:17 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:17 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:17 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:17 --> Controller Class Initialized
INFO - 2025-05-08 04:09:17 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:09:17 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:09:17 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 04:09:17 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:09:17 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:09:17 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:17 --> Total execution time: 0.0048
INFO - 2025-05-08 04:09:18 --> Config Class Initialized
INFO - 2025-05-08 04:09:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:18 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:18 --> URI Class Initialized
INFO - 2025-05-08 04:09:18 --> Router Class Initialized
INFO - 2025-05-08 04:09:18 --> Output Class Initialized
INFO - 2025-05-08 04:09:18 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:18 --> Input Class Initialized
INFO - 2025-05-08 04:09:18 --> Language Class Initialized
INFO - 2025-05-08 04:09:18 --> Loader Class Initialized
INFO - 2025-05-08 04:09:18 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:18 --> Controller Class Initialized
INFO - 2025-05-08 04:09:18 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:18 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:18 --> Total execution time: 0.0028
INFO - 2025-05-08 04:09:18 --> Config Class Initialized
INFO - 2025-05-08 04:09:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:18 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:18 --> URI Class Initialized
INFO - 2025-05-08 04:09:18 --> Router Class Initialized
INFO - 2025-05-08 04:09:18 --> Output Class Initialized
INFO - 2025-05-08 04:09:18 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:18 --> Input Class Initialized
INFO - 2025-05-08 04:09:18 --> Language Class Initialized
INFO - 2025-05-08 04:09:18 --> Loader Class Initialized
INFO - 2025-05-08 04:09:18 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:18 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:18 --> Controller Class Initialized
INFO - 2025-05-08 04:09:18 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:09:18 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 04:09:18 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:19 --> Config Class Initialized
INFO - 2025-05-08 04:09:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:19 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:19 --> URI Class Initialized
INFO - 2025-05-08 04:09:19 --> Router Class Initialized
INFO - 2025-05-08 04:09:19 --> Output Class Initialized
INFO - 2025-05-08 04:09:19 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:19 --> Input Class Initialized
INFO - 2025-05-08 04:09:19 --> Language Class Initialized
INFO - 2025-05-08 04:09:19 --> Loader Class Initialized
INFO - 2025-05-08 04:09:19 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:19 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:19 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:19 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:19 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:19 --> Controller Class Initialized
INFO - 2025-05-08 04:09:19 --> Model "UserModel" initialized
INFO - 2025-05-08 04:09:19 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:19 --> Total execution time: 0.0060
INFO - 2025-05-08 04:09:45 --> Config Class Initialized
INFO - 2025-05-08 04:09:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:45 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:45 --> URI Class Initialized
INFO - 2025-05-08 04:09:45 --> Router Class Initialized
INFO - 2025-05-08 04:09:45 --> Output Class Initialized
INFO - 2025-05-08 04:09:45 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:45 --> Input Class Initialized
INFO - 2025-05-08 04:09:45 --> Language Class Initialized
INFO - 2025-05-08 04:09:45 --> Loader Class Initialized
INFO - 2025-05-08 04:09:45 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:45 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:45 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:45 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:45 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:45 --> Controller Class Initialized
INFO - 2025-05-08 04:09:45 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:09:45 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:09:45 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:45 --> Total execution time: 0.0060
INFO - 2025-05-08 04:09:47 --> Config Class Initialized
INFO - 2025-05-08 04:09:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:47 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:47 --> URI Class Initialized
INFO - 2025-05-08 04:09:47 --> Router Class Initialized
INFO - 2025-05-08 04:09:47 --> Output Class Initialized
INFO - 2025-05-08 04:09:47 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:47 --> Input Class Initialized
INFO - 2025-05-08 04:09:47 --> Language Class Initialized
INFO - 2025-05-08 04:09:47 --> Loader Class Initialized
INFO - 2025-05-08 04:09:47 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:47 --> Controller Class Initialized
INFO - 2025-05-08 04:09:47 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:47 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:47 --> Total execution time: 0.0024
INFO - 2025-05-08 04:09:47 --> Config Class Initialized
INFO - 2025-05-08 04:09:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:47 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:47 --> URI Class Initialized
INFO - 2025-05-08 04:09:47 --> Router Class Initialized
INFO - 2025-05-08 04:09:47 --> Output Class Initialized
INFO - 2025-05-08 04:09:47 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:47 --> Input Class Initialized
INFO - 2025-05-08 04:09:47 --> Language Class Initialized
INFO - 2025-05-08 04:09:47 --> Loader Class Initialized
INFO - 2025-05-08 04:09:47 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:47 --> Controller Class Initialized
INFO - 2025-05-08 04:09:47 --> Model "UserModel" initialized
INFO - 2025-05-08 04:09:47 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:47 --> Total execution time: 0.0027
INFO - 2025-05-08 04:09:47 --> Config Class Initialized
INFO - 2025-05-08 04:09:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:09:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:09:47 --> Utf8 Class Initialized
INFO - 2025-05-08 04:09:47 --> URI Class Initialized
INFO - 2025-05-08 04:09:47 --> Router Class Initialized
INFO - 2025-05-08 04:09:47 --> Output Class Initialized
INFO - 2025-05-08 04:09:47 --> Security Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:09:47 --> Input Class Initialized
INFO - 2025-05-08 04:09:47 --> Language Class Initialized
INFO - 2025-05-08 04:09:47 --> Loader Class Initialized
INFO - 2025-05-08 04:09:47 --> Helper loaded: url_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: string_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: form_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: file_helper
INFO - 2025-05-08 04:09:47 --> Helper loaded: html_helper
INFO - 2025-05-08 04:09:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:09:47 --> Controller Class Initialized
INFO - 2025-05-08 04:09:47 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:09:47 --> Final output sent to browser
DEBUG - 2025-05-08 04:09:47 --> Total execution time: 0.0027
INFO - 2025-05-08 04:18:12 --> Config Class Initialized
INFO - 2025-05-08 04:18:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:12 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:12 --> URI Class Initialized
INFO - 2025-05-08 04:18:12 --> Router Class Initialized
INFO - 2025-05-08 04:18:12 --> Output Class Initialized
INFO - 2025-05-08 04:18:12 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:12 --> Input Class Initialized
INFO - 2025-05-08 04:18:12 --> Language Class Initialized
INFO - 2025-05-08 04:18:12 --> Loader Class Initialized
INFO - 2025-05-08 04:18:12 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:12 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:12 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:12 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:12 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:12 --> Controller Class Initialized
INFO - 2025-05-08 04:18:12 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:18:12 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:18:12 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:18:12 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:18:12 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:18:12 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:18:12 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:12 --> Total execution time: 0.0460
INFO - 2025-05-08 04:18:13 --> Config Class Initialized
INFO - 2025-05-08 04:18:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:13 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:13 --> URI Class Initialized
INFO - 2025-05-08 04:18:13 --> Router Class Initialized
INFO - 2025-05-08 04:18:13 --> Output Class Initialized
INFO - 2025-05-08 04:18:13 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:13 --> Input Class Initialized
INFO - 2025-05-08 04:18:13 --> Language Class Initialized
INFO - 2025-05-08 04:18:13 --> Loader Class Initialized
INFO - 2025-05-08 04:18:13 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:13 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:13 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:13 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:13 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:13 --> Controller Class Initialized
INFO - 2025-05-08 04:18:13 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:18:13 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:13 --> Total execution time: 0.0044
INFO - 2025-05-08 04:18:14 --> Config Class Initialized
INFO - 2025-05-08 04:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:14 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:14 --> URI Class Initialized
INFO - 2025-05-08 04:18:14 --> Router Class Initialized
INFO - 2025-05-08 04:18:14 --> Output Class Initialized
INFO - 2025-05-08 04:18:14 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:14 --> Input Class Initialized
INFO - 2025-05-08 04:18:14 --> Language Class Initialized
INFO - 2025-05-08 04:18:14 --> Loader Class Initialized
INFO - 2025-05-08 04:18:14 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:14 --> Controller Class Initialized
INFO - 2025-05-08 04:18:14 --> Model "UserModel" initialized
INFO - 2025-05-08 04:18:14 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:14 --> Total execution time: 0.0056
INFO - 2025-05-08 04:18:14 --> Config Class Initialized
INFO - 2025-05-08 04:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:14 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:14 --> URI Class Initialized
INFO - 2025-05-08 04:18:14 --> Router Class Initialized
INFO - 2025-05-08 04:18:14 --> Output Class Initialized
INFO - 2025-05-08 04:18:14 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:14 --> Input Class Initialized
INFO - 2025-05-08 04:18:14 --> Language Class Initialized
INFO - 2025-05-08 04:18:14 --> Loader Class Initialized
INFO - 2025-05-08 04:18:14 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:14 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:14 --> Controller Class Initialized
INFO - 2025-05-08 04:18:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:18:14 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:14 --> Total execution time: 0.0043
INFO - 2025-05-08 04:18:51 --> Config Class Initialized
INFO - 2025-05-08 04:18:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:51 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:51 --> URI Class Initialized
INFO - 2025-05-08 04:18:51 --> Router Class Initialized
INFO - 2025-05-08 04:18:51 --> Output Class Initialized
INFO - 2025-05-08 04:18:51 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:51 --> Input Class Initialized
INFO - 2025-05-08 04:18:51 --> Language Class Initialized
INFO - 2025-05-08 04:18:51 --> Loader Class Initialized
INFO - 2025-05-08 04:18:51 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:51 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:51 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:51 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:51 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:51 --> Controller Class Initialized
INFO - 2025-05-08 04:18:51 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:18:51 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:18:51 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:18:51 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:18:51 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:18:51 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:18:51 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:51 --> Total execution time: 0.0044
INFO - 2025-05-08 04:18:53 --> Config Class Initialized
INFO - 2025-05-08 04:18:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:53 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:53 --> URI Class Initialized
INFO - 2025-05-08 04:18:53 --> Router Class Initialized
INFO - 2025-05-08 04:18:53 --> Output Class Initialized
INFO - 2025-05-08 04:18:53 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:53 --> Input Class Initialized
INFO - 2025-05-08 04:18:53 --> Language Class Initialized
INFO - 2025-05-08 04:18:53 --> Loader Class Initialized
INFO - 2025-05-08 04:18:53 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:53 --> Controller Class Initialized
INFO - 2025-05-08 04:18:53 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:18:53 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:53 --> Total execution time: 0.0032
INFO - 2025-05-08 04:18:53 --> Config Class Initialized
INFO - 2025-05-08 04:18:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:53 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:53 --> URI Class Initialized
INFO - 2025-05-08 04:18:53 --> Router Class Initialized
INFO - 2025-05-08 04:18:53 --> Output Class Initialized
INFO - 2025-05-08 04:18:53 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:53 --> Input Class Initialized
INFO - 2025-05-08 04:18:53 --> Language Class Initialized
INFO - 2025-05-08 04:18:53 --> Loader Class Initialized
INFO - 2025-05-08 04:18:53 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:53 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:53 --> Controller Class Initialized
INFO - 2025-05-08 04:18:53 --> Model "UserModel" initialized
INFO - 2025-05-08 04:18:53 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:53 --> Total execution time: 0.0034
INFO - 2025-05-08 04:18:54 --> Config Class Initialized
INFO - 2025-05-08 04:18:54 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:18:54 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:18:54 --> Utf8 Class Initialized
INFO - 2025-05-08 04:18:54 --> URI Class Initialized
INFO - 2025-05-08 04:18:54 --> Router Class Initialized
INFO - 2025-05-08 04:18:54 --> Output Class Initialized
INFO - 2025-05-08 04:18:54 --> Security Class Initialized
DEBUG - 2025-05-08 04:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:18:54 --> Input Class Initialized
INFO - 2025-05-08 04:18:54 --> Language Class Initialized
INFO - 2025-05-08 04:18:54 --> Loader Class Initialized
INFO - 2025-05-08 04:18:54 --> Helper loaded: url_helper
INFO - 2025-05-08 04:18:54 --> Helper loaded: string_helper
INFO - 2025-05-08 04:18:54 --> Helper loaded: form_helper
INFO - 2025-05-08 04:18:54 --> Helper loaded: file_helper
INFO - 2025-05-08 04:18:54 --> Helper loaded: html_helper
INFO - 2025-05-08 04:18:54 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:18:54 --> Controller Class Initialized
INFO - 2025-05-08 04:18:54 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:18:54 --> Final output sent to browser
DEBUG - 2025-05-08 04:18:54 --> Total execution time: 0.0026
INFO - 2025-05-08 04:27:11 --> Config Class Initialized
INFO - 2025-05-08 04:27:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:27:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:27:11 --> Utf8 Class Initialized
INFO - 2025-05-08 04:27:11 --> URI Class Initialized
INFO - 2025-05-08 04:27:11 --> Router Class Initialized
INFO - 2025-05-08 04:27:11 --> Output Class Initialized
INFO - 2025-05-08 04:27:11 --> Security Class Initialized
DEBUG - 2025-05-08 04:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:27:11 --> Input Class Initialized
INFO - 2025-05-08 04:27:11 --> Language Class Initialized
INFO - 2025-05-08 04:27:11 --> Loader Class Initialized
INFO - 2025-05-08 04:27:11 --> Helper loaded: url_helper
INFO - 2025-05-08 04:27:11 --> Helper loaded: string_helper
INFO - 2025-05-08 04:27:11 --> Helper loaded: form_helper
INFO - 2025-05-08 04:27:11 --> Helper loaded: file_helper
INFO - 2025-05-08 04:27:11 --> Helper loaded: html_helper
INFO - 2025-05-08 04:27:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:27:11 --> Controller Class Initialized
INFO - 2025-05-08 04:27:11 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:27:11 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:27:11 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:27:11 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:27:11 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:27:11 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:27:11 --> Final output sent to browser
DEBUG - 2025-05-08 04:27:11 --> Total execution time: 0.0346
INFO - 2025-05-08 04:29:22 --> Config Class Initialized
INFO - 2025-05-08 04:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:29:22 --> Utf8 Class Initialized
INFO - 2025-05-08 04:29:22 --> URI Class Initialized
INFO - 2025-05-08 04:29:22 --> Router Class Initialized
INFO - 2025-05-08 04:29:22 --> Output Class Initialized
INFO - 2025-05-08 04:29:22 --> Security Class Initialized
DEBUG - 2025-05-08 04:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:29:22 --> Input Class Initialized
INFO - 2025-05-08 04:29:22 --> Language Class Initialized
INFO - 2025-05-08 04:29:22 --> Loader Class Initialized
INFO - 2025-05-08 04:29:22 --> Helper loaded: url_helper
INFO - 2025-05-08 04:29:22 --> Helper loaded: string_helper
INFO - 2025-05-08 04:29:22 --> Helper loaded: form_helper
INFO - 2025-05-08 04:29:22 --> Helper loaded: file_helper
INFO - 2025-05-08 04:29:22 --> Helper loaded: html_helper
INFO - 2025-05-08 04:29:22 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:29:22 --> Controller Class Initialized
INFO - 2025-05-08 04:29:22 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:29:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:29:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:29:22 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:29:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:29:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:29:22 --> Final output sent to browser
DEBUG - 2025-05-08 04:29:22 --> Total execution time: 0.0336
INFO - 2025-05-08 04:29:26 --> Config Class Initialized
INFO - 2025-05-08 04:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:29:26 --> Utf8 Class Initialized
INFO - 2025-05-08 04:29:26 --> URI Class Initialized
INFO - 2025-05-08 04:29:26 --> Router Class Initialized
INFO - 2025-05-08 04:29:26 --> Output Class Initialized
INFO - 2025-05-08 04:29:26 --> Security Class Initialized
DEBUG - 2025-05-08 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:29:26 --> Input Class Initialized
INFO - 2025-05-08 04:29:26 --> Language Class Initialized
INFO - 2025-05-08 04:29:26 --> Loader Class Initialized
INFO - 2025-05-08 04:29:26 --> Helper loaded: url_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: string_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: form_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: file_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: html_helper
INFO - 2025-05-08 04:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:29:26 --> Controller Class Initialized
INFO - 2025-05-08 04:29:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:29:26 --> Final output sent to browser
DEBUG - 2025-05-08 04:29:26 --> Total execution time: 0.0059
INFO - 2025-05-08 04:29:26 --> Config Class Initialized
INFO - 2025-05-08 04:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:29:26 --> Utf8 Class Initialized
INFO - 2025-05-08 04:29:26 --> URI Class Initialized
INFO - 2025-05-08 04:29:26 --> Router Class Initialized
INFO - 2025-05-08 04:29:26 --> Output Class Initialized
INFO - 2025-05-08 04:29:26 --> Security Class Initialized
DEBUG - 2025-05-08 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:29:26 --> Input Class Initialized
INFO - 2025-05-08 04:29:26 --> Language Class Initialized
INFO - 2025-05-08 04:29:26 --> Loader Class Initialized
INFO - 2025-05-08 04:29:26 --> Helper loaded: url_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: string_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: form_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: file_helper
INFO - 2025-05-08 04:29:26 --> Helper loaded: html_helper
INFO - 2025-05-08 04:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:29:26 --> Controller Class Initialized
INFO - 2025-05-08 04:29:26 --> Model "UserModel" initialized
INFO - 2025-05-08 04:29:26 --> Final output sent to browser
DEBUG - 2025-05-08 04:29:26 --> Total execution time: 0.0062
INFO - 2025-05-08 04:29:27 --> Config Class Initialized
INFO - 2025-05-08 04:29:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:29:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:29:27 --> Utf8 Class Initialized
INFO - 2025-05-08 04:29:27 --> URI Class Initialized
INFO - 2025-05-08 04:29:27 --> Router Class Initialized
INFO - 2025-05-08 04:29:27 --> Output Class Initialized
INFO - 2025-05-08 04:29:27 --> Security Class Initialized
DEBUG - 2025-05-08 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:29:27 --> Input Class Initialized
INFO - 2025-05-08 04:29:27 --> Language Class Initialized
INFO - 2025-05-08 04:29:27 --> Loader Class Initialized
INFO - 2025-05-08 04:29:27 --> Helper loaded: url_helper
INFO - 2025-05-08 04:29:27 --> Helper loaded: string_helper
INFO - 2025-05-08 04:29:27 --> Helper loaded: form_helper
INFO - 2025-05-08 04:29:27 --> Helper loaded: file_helper
INFO - 2025-05-08 04:29:27 --> Helper loaded: html_helper
INFO - 2025-05-08 04:29:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:29:27 --> Controller Class Initialized
INFO - 2025-05-08 04:29:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:29:27 --> Final output sent to browser
DEBUG - 2025-05-08 04:29:27 --> Total execution time: 0.0028
INFO - 2025-05-08 04:30:23 --> Config Class Initialized
INFO - 2025-05-08 04:30:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:30:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:30:23 --> Utf8 Class Initialized
INFO - 2025-05-08 04:30:23 --> URI Class Initialized
INFO - 2025-05-08 04:30:23 --> Router Class Initialized
INFO - 2025-05-08 04:30:23 --> Output Class Initialized
INFO - 2025-05-08 04:30:23 --> Security Class Initialized
DEBUG - 2025-05-08 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:30:23 --> Input Class Initialized
INFO - 2025-05-08 04:30:23 --> Language Class Initialized
INFO - 2025-05-08 04:30:23 --> Loader Class Initialized
INFO - 2025-05-08 04:30:23 --> Helper loaded: url_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: string_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: form_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: file_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: html_helper
INFO - 2025-05-08 04:30:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:30:23 --> Controller Class Initialized
INFO - 2025-05-08 04:30:23 --> Config Class Initialized
INFO - 2025-05-08 04:30:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:30:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:30:23 --> Utf8 Class Initialized
INFO - 2025-05-08 04:30:23 --> URI Class Initialized
DEBUG - 2025-05-08 04:30:23 --> No URI present. Default controller set.
INFO - 2025-05-08 04:30:23 --> Router Class Initialized
INFO - 2025-05-08 04:30:23 --> Output Class Initialized
INFO - 2025-05-08 04:30:23 --> Security Class Initialized
DEBUG - 2025-05-08 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:30:23 --> Input Class Initialized
INFO - 2025-05-08 04:30:23 --> Language Class Initialized
INFO - 2025-05-08 04:30:23 --> Loader Class Initialized
INFO - 2025-05-08 04:30:23 --> Helper loaded: url_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: string_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: form_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: file_helper
INFO - 2025-05-08 04:30:23 --> Helper loaded: html_helper
INFO - 2025-05-08 04:30:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:30:23 --> Controller Class Initialized
INFO - 2025-05-08 04:30:23 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:30:23 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:30:23 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 04:30:23 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:30:23 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:30:23 --> Final output sent to browser
DEBUG - 2025-05-08 04:30:23 --> Total execution time: 0.0045
INFO - 2025-05-08 04:32:41 --> Config Class Initialized
INFO - 2025-05-08 04:32:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:32:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:32:41 --> Utf8 Class Initialized
INFO - 2025-05-08 04:32:41 --> URI Class Initialized
INFO - 2025-05-08 04:32:41 --> Router Class Initialized
INFO - 2025-05-08 04:32:41 --> Output Class Initialized
INFO - 2025-05-08 04:32:41 --> Security Class Initialized
DEBUG - 2025-05-08 04:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:32:41 --> Input Class Initialized
INFO - 2025-05-08 04:32:41 --> Language Class Initialized
INFO - 2025-05-08 04:32:41 --> Loader Class Initialized
INFO - 2025-05-08 04:32:41 --> Helper loaded: url_helper
INFO - 2025-05-08 04:32:41 --> Helper loaded: string_helper
INFO - 2025-05-08 04:32:41 --> Helper loaded: form_helper
INFO - 2025-05-08 04:32:41 --> Helper loaded: file_helper
INFO - 2025-05-08 04:32:41 --> Helper loaded: html_helper
INFO - 2025-05-08 04:32:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:32:41 --> Controller Class Initialized
INFO - 2025-05-08 04:32:41 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:32:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:32:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:32:41 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:32:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:32:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:32:41 --> Final output sent to browser
DEBUG - 2025-05-08 04:32:41 --> Total execution time: 0.0341
INFO - 2025-05-08 04:32:45 --> Config Class Initialized
INFO - 2025-05-08 04:32:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:32:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:32:45 --> Utf8 Class Initialized
INFO - 2025-05-08 04:32:45 --> URI Class Initialized
INFO - 2025-05-08 04:32:45 --> Router Class Initialized
INFO - 2025-05-08 04:32:45 --> Output Class Initialized
INFO - 2025-05-08 04:32:45 --> Security Class Initialized
DEBUG - 2025-05-08 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:32:45 --> Input Class Initialized
INFO - 2025-05-08 04:32:45 --> Language Class Initialized
INFO - 2025-05-08 04:32:45 --> Loader Class Initialized
INFO - 2025-05-08 04:32:45 --> Helper loaded: url_helper
INFO - 2025-05-08 04:32:45 --> Helper loaded: string_helper
INFO - 2025-05-08 04:32:45 --> Helper loaded: form_helper
INFO - 2025-05-08 04:32:45 --> Helper loaded: file_helper
INFO - 2025-05-08 04:32:45 --> Helper loaded: html_helper
INFO - 2025-05-08 04:32:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:32:45 --> Controller Class Initialized
INFO - 2025-05-08 04:32:45 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:32:45 --> Final output sent to browser
DEBUG - 2025-05-08 04:32:45 --> Total execution time: 0.0042
INFO - 2025-05-08 04:32:46 --> Config Class Initialized
INFO - 2025-05-08 04:32:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:32:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:32:46 --> Utf8 Class Initialized
INFO - 2025-05-08 04:32:46 --> URI Class Initialized
INFO - 2025-05-08 04:32:46 --> Router Class Initialized
INFO - 2025-05-08 04:32:46 --> Output Class Initialized
INFO - 2025-05-08 04:32:46 --> Security Class Initialized
DEBUG - 2025-05-08 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:32:46 --> Input Class Initialized
INFO - 2025-05-08 04:32:46 --> Language Class Initialized
INFO - 2025-05-08 04:32:46 --> Loader Class Initialized
INFO - 2025-05-08 04:32:46 --> Helper loaded: url_helper
INFO - 2025-05-08 04:32:46 --> Helper loaded: string_helper
INFO - 2025-05-08 04:32:46 --> Helper loaded: form_helper
INFO - 2025-05-08 04:32:46 --> Helper loaded: file_helper
INFO - 2025-05-08 04:32:46 --> Helper loaded: html_helper
INFO - 2025-05-08 04:32:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:32:46 --> Controller Class Initialized
INFO - 2025-05-08 04:32:46 --> Model "UserModel" initialized
INFO - 2025-05-08 04:32:46 --> Final output sent to browser
DEBUG - 2025-05-08 04:32:46 --> Total execution time: 0.0062
INFO - 2025-05-08 04:32:47 --> Config Class Initialized
INFO - 2025-05-08 04:32:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:32:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:32:47 --> Utf8 Class Initialized
INFO - 2025-05-08 04:32:47 --> URI Class Initialized
INFO - 2025-05-08 04:32:47 --> Router Class Initialized
INFO - 2025-05-08 04:32:47 --> Output Class Initialized
INFO - 2025-05-08 04:32:47 --> Security Class Initialized
DEBUG - 2025-05-08 04:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:32:47 --> Input Class Initialized
INFO - 2025-05-08 04:32:47 --> Language Class Initialized
INFO - 2025-05-08 04:32:47 --> Loader Class Initialized
INFO - 2025-05-08 04:32:47 --> Helper loaded: url_helper
INFO - 2025-05-08 04:32:47 --> Helper loaded: string_helper
INFO - 2025-05-08 04:32:47 --> Helper loaded: form_helper
INFO - 2025-05-08 04:32:47 --> Helper loaded: file_helper
INFO - 2025-05-08 04:32:47 --> Helper loaded: html_helper
INFO - 2025-05-08 04:32:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:32:47 --> Controller Class Initialized
INFO - 2025-05-08 04:32:47 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:32:47 --> Final output sent to browser
DEBUG - 2025-05-08 04:32:47 --> Total execution time: 0.0024
INFO - 2025-05-08 04:35:44 --> Config Class Initialized
INFO - 2025-05-08 04:35:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:35:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:35:44 --> Utf8 Class Initialized
INFO - 2025-05-08 04:35:44 --> URI Class Initialized
INFO - 2025-05-08 04:35:44 --> Router Class Initialized
INFO - 2025-05-08 04:35:44 --> Output Class Initialized
INFO - 2025-05-08 04:35:44 --> Security Class Initialized
DEBUG - 2025-05-08 04:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:35:44 --> Input Class Initialized
INFO - 2025-05-08 04:35:44 --> Language Class Initialized
INFO - 2025-05-08 04:35:44 --> Loader Class Initialized
INFO - 2025-05-08 04:35:44 --> Helper loaded: url_helper
INFO - 2025-05-08 04:35:44 --> Helper loaded: string_helper
INFO - 2025-05-08 04:35:44 --> Helper loaded: form_helper
INFO - 2025-05-08 04:35:44 --> Helper loaded: file_helper
INFO - 2025-05-08 04:35:44 --> Helper loaded: html_helper
INFO - 2025-05-08 04:35:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:35:44 --> Controller Class Initialized
INFO - 2025-05-08 04:35:44 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:35:44 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:35:44 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:35:44 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:35:44 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:35:44 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:35:44 --> Final output sent to browser
DEBUG - 2025-05-08 04:35:44 --> Total execution time: 0.0466
INFO - 2025-05-08 04:35:50 --> Config Class Initialized
INFO - 2025-05-08 04:35:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:35:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:35:50 --> Utf8 Class Initialized
INFO - 2025-05-08 04:35:50 --> URI Class Initialized
INFO - 2025-05-08 04:35:50 --> Router Class Initialized
INFO - 2025-05-08 04:35:50 --> Output Class Initialized
INFO - 2025-05-08 04:35:50 --> Security Class Initialized
DEBUG - 2025-05-08 04:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:35:50 --> Input Class Initialized
INFO - 2025-05-08 04:35:50 --> Language Class Initialized
INFO - 2025-05-08 04:35:50 --> Loader Class Initialized
INFO - 2025-05-08 04:35:50 --> Helper loaded: url_helper
INFO - 2025-05-08 04:35:50 --> Helper loaded: string_helper
INFO - 2025-05-08 04:35:50 --> Helper loaded: form_helper
INFO - 2025-05-08 04:35:50 --> Helper loaded: file_helper
INFO - 2025-05-08 04:35:50 --> Helper loaded: html_helper
INFO - 2025-05-08 04:35:50 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:35:50 --> Controller Class Initialized
INFO - 2025-05-08 04:35:50 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:35:50 --> Final output sent to browser
DEBUG - 2025-05-08 04:35:50 --> Total execution time: 0.0060
INFO - 2025-05-08 04:35:52 --> Config Class Initialized
INFO - 2025-05-08 04:35:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:35:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:35:52 --> Utf8 Class Initialized
INFO - 2025-05-08 04:35:52 --> URI Class Initialized
INFO - 2025-05-08 04:35:52 --> Router Class Initialized
INFO - 2025-05-08 04:35:52 --> Output Class Initialized
INFO - 2025-05-08 04:35:52 --> Security Class Initialized
DEBUG - 2025-05-08 04:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:35:52 --> Input Class Initialized
INFO - 2025-05-08 04:35:52 --> Language Class Initialized
INFO - 2025-05-08 04:35:52 --> Loader Class Initialized
INFO - 2025-05-08 04:35:52 --> Helper loaded: url_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: string_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: form_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: file_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: html_helper
INFO - 2025-05-08 04:35:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:35:52 --> Controller Class Initialized
INFO - 2025-05-08 04:35:52 --> Model "UserModel" initialized
INFO - 2025-05-08 04:35:52 --> Final output sent to browser
DEBUG - 2025-05-08 04:35:52 --> Total execution time: 0.0053
INFO - 2025-05-08 04:35:52 --> Config Class Initialized
INFO - 2025-05-08 04:35:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:35:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:35:52 --> Utf8 Class Initialized
INFO - 2025-05-08 04:35:52 --> URI Class Initialized
INFO - 2025-05-08 04:35:52 --> Router Class Initialized
INFO - 2025-05-08 04:35:52 --> Output Class Initialized
INFO - 2025-05-08 04:35:52 --> Security Class Initialized
DEBUG - 2025-05-08 04:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:35:52 --> Input Class Initialized
INFO - 2025-05-08 04:35:52 --> Language Class Initialized
INFO - 2025-05-08 04:35:52 --> Loader Class Initialized
INFO - 2025-05-08 04:35:52 --> Helper loaded: url_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: string_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: form_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: file_helper
INFO - 2025-05-08 04:35:52 --> Helper loaded: html_helper
INFO - 2025-05-08 04:35:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:35:52 --> Controller Class Initialized
INFO - 2025-05-08 04:35:52 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:35:52 --> Final output sent to browser
DEBUG - 2025-05-08 04:35:52 --> Total execution time: 0.0024
INFO - 2025-05-08 04:39:09 --> Config Class Initialized
INFO - 2025-05-08 04:39:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:39:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:39:09 --> Utf8 Class Initialized
INFO - 2025-05-08 04:39:09 --> URI Class Initialized
INFO - 2025-05-08 04:39:09 --> Router Class Initialized
INFO - 2025-05-08 04:39:09 --> Output Class Initialized
INFO - 2025-05-08 04:39:09 --> Security Class Initialized
DEBUG - 2025-05-08 04:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:39:09 --> Input Class Initialized
INFO - 2025-05-08 04:39:09 --> Language Class Initialized
INFO - 2025-05-08 04:39:09 --> Loader Class Initialized
INFO - 2025-05-08 04:39:09 --> Helper loaded: url_helper
INFO - 2025-05-08 04:39:09 --> Helper loaded: string_helper
INFO - 2025-05-08 04:39:09 --> Helper loaded: form_helper
INFO - 2025-05-08 04:39:09 --> Helper loaded: file_helper
INFO - 2025-05-08 04:39:09 --> Helper loaded: html_helper
INFO - 2025-05-08 04:39:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:39:09 --> Controller Class Initialized
INFO - 2025-05-08 04:39:09 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:39:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:39:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:39:09 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:39:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:39:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:39:09 --> Final output sent to browser
DEBUG - 2025-05-08 04:39:09 --> Total execution time: 0.0467
INFO - 2025-05-08 04:39:13 --> Config Class Initialized
INFO - 2025-05-08 04:39:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:39:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:39:13 --> Utf8 Class Initialized
INFO - 2025-05-08 04:39:13 --> URI Class Initialized
INFO - 2025-05-08 04:39:13 --> Router Class Initialized
INFO - 2025-05-08 04:39:13 --> Output Class Initialized
INFO - 2025-05-08 04:39:13 --> Security Class Initialized
DEBUG - 2025-05-08 04:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:39:13 --> Input Class Initialized
INFO - 2025-05-08 04:39:13 --> Language Class Initialized
INFO - 2025-05-08 04:39:13 --> Loader Class Initialized
INFO - 2025-05-08 04:39:13 --> Helper loaded: url_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: string_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: form_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: file_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: html_helper
INFO - 2025-05-08 04:39:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:39:13 --> Controller Class Initialized
INFO - 2025-05-08 04:39:13 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:39:13 --> Final output sent to browser
DEBUG - 2025-05-08 04:39:13 --> Total execution time: 0.0068
INFO - 2025-05-08 04:39:13 --> Config Class Initialized
INFO - 2025-05-08 04:39:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:39:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:39:13 --> Utf8 Class Initialized
INFO - 2025-05-08 04:39:13 --> URI Class Initialized
INFO - 2025-05-08 04:39:13 --> Router Class Initialized
INFO - 2025-05-08 04:39:13 --> Output Class Initialized
INFO - 2025-05-08 04:39:13 --> Security Class Initialized
DEBUG - 2025-05-08 04:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:39:13 --> Input Class Initialized
INFO - 2025-05-08 04:39:13 --> Language Class Initialized
INFO - 2025-05-08 04:39:13 --> Loader Class Initialized
INFO - 2025-05-08 04:39:13 --> Helper loaded: url_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: string_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: form_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: file_helper
INFO - 2025-05-08 04:39:13 --> Helper loaded: html_helper
INFO - 2025-05-08 04:39:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:39:13 --> Controller Class Initialized
INFO - 2025-05-08 04:39:13 --> Model "UserModel" initialized
INFO - 2025-05-08 04:39:13 --> Final output sent to browser
DEBUG - 2025-05-08 04:39:13 --> Total execution time: 0.0060
INFO - 2025-05-08 04:39:14 --> Config Class Initialized
INFO - 2025-05-08 04:39:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:39:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:39:14 --> Utf8 Class Initialized
INFO - 2025-05-08 04:39:14 --> URI Class Initialized
INFO - 2025-05-08 04:39:14 --> Router Class Initialized
INFO - 2025-05-08 04:39:14 --> Output Class Initialized
INFO - 2025-05-08 04:39:14 --> Security Class Initialized
DEBUG - 2025-05-08 04:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:39:14 --> Input Class Initialized
INFO - 2025-05-08 04:39:14 --> Language Class Initialized
INFO - 2025-05-08 04:39:14 --> Loader Class Initialized
INFO - 2025-05-08 04:39:14 --> Helper loaded: url_helper
INFO - 2025-05-08 04:39:14 --> Helper loaded: string_helper
INFO - 2025-05-08 04:39:14 --> Helper loaded: form_helper
INFO - 2025-05-08 04:39:14 --> Helper loaded: file_helper
INFO - 2025-05-08 04:39:14 --> Helper loaded: html_helper
INFO - 2025-05-08 04:39:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:39:14 --> Controller Class Initialized
INFO - 2025-05-08 04:39:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:39:14 --> Final output sent to browser
DEBUG - 2025-05-08 04:39:14 --> Total execution time: 0.0032
INFO - 2025-05-08 04:41:26 --> Config Class Initialized
INFO - 2025-05-08 04:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:41:26 --> Utf8 Class Initialized
INFO - 2025-05-08 04:41:26 --> URI Class Initialized
INFO - 2025-05-08 04:41:26 --> Router Class Initialized
INFO - 2025-05-08 04:41:26 --> Output Class Initialized
INFO - 2025-05-08 04:41:26 --> Security Class Initialized
DEBUG - 2025-05-08 04:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:41:26 --> Input Class Initialized
INFO - 2025-05-08 04:41:26 --> Language Class Initialized
INFO - 2025-05-08 04:41:26 --> Loader Class Initialized
INFO - 2025-05-08 04:41:26 --> Helper loaded: url_helper
INFO - 2025-05-08 04:41:26 --> Helper loaded: string_helper
INFO - 2025-05-08 04:41:26 --> Helper loaded: form_helper
INFO - 2025-05-08 04:41:26 --> Helper loaded: file_helper
INFO - 2025-05-08 04:41:26 --> Helper loaded: html_helper
INFO - 2025-05-08 04:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:41:26 --> Controller Class Initialized
INFO - 2025-05-08 04:41:26 --> Model "CompanyModel" initialized
INFO - 2025-05-08 04:41:26 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 04:41:26 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 04:41:26 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 04:41:26 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 04:41:26 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 04:41:26 --> Final output sent to browser
DEBUG - 2025-05-08 04:41:26 --> Total execution time: 0.0368
INFO - 2025-05-08 04:41:31 --> Config Class Initialized
INFO - 2025-05-08 04:41:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:41:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:41:31 --> Utf8 Class Initialized
INFO - 2025-05-08 04:41:31 --> URI Class Initialized
INFO - 2025-05-08 04:41:31 --> Router Class Initialized
INFO - 2025-05-08 04:41:31 --> Output Class Initialized
INFO - 2025-05-08 04:41:31 --> Security Class Initialized
DEBUG - 2025-05-08 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:41:31 --> Input Class Initialized
INFO - 2025-05-08 04:41:31 --> Language Class Initialized
INFO - 2025-05-08 04:41:31 --> Loader Class Initialized
INFO - 2025-05-08 04:41:31 --> Helper loaded: url_helper
INFO - 2025-05-08 04:41:31 --> Helper loaded: string_helper
INFO - 2025-05-08 04:41:31 --> Helper loaded: form_helper
INFO - 2025-05-08 04:41:31 --> Helper loaded: file_helper
INFO - 2025-05-08 04:41:31 --> Helper loaded: html_helper
INFO - 2025-05-08 04:41:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:41:31 --> Controller Class Initialized
INFO - 2025-05-08 04:41:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:41:31 --> Final output sent to browser
DEBUG - 2025-05-08 04:41:31 --> Total execution time: 0.0062
INFO - 2025-05-08 04:41:33 --> Config Class Initialized
INFO - 2025-05-08 04:41:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:41:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:41:33 --> Utf8 Class Initialized
INFO - 2025-05-08 04:41:33 --> URI Class Initialized
INFO - 2025-05-08 04:41:33 --> Router Class Initialized
INFO - 2025-05-08 04:41:33 --> Output Class Initialized
INFO - 2025-05-08 04:41:33 --> Security Class Initialized
DEBUG - 2025-05-08 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:41:33 --> Input Class Initialized
INFO - 2025-05-08 04:41:33 --> Language Class Initialized
INFO - 2025-05-08 04:41:33 --> Loader Class Initialized
INFO - 2025-05-08 04:41:33 --> Helper loaded: url_helper
INFO - 2025-05-08 04:41:33 --> Helper loaded: string_helper
INFO - 2025-05-08 04:41:33 --> Helper loaded: form_helper
INFO - 2025-05-08 04:41:33 --> Helper loaded: file_helper
INFO - 2025-05-08 04:41:33 --> Helper loaded: html_helper
INFO - 2025-05-08 04:41:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:41:33 --> Controller Class Initialized
INFO - 2025-05-08 04:41:33 --> Model "UserModel" initialized
INFO - 2025-05-08 04:41:33 --> Final output sent to browser
DEBUG - 2025-05-08 04:41:33 --> Total execution time: 0.0100
INFO - 2025-05-08 04:41:34 --> Config Class Initialized
INFO - 2025-05-08 04:41:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 04:41:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 04:41:34 --> Utf8 Class Initialized
INFO - 2025-05-08 04:41:34 --> URI Class Initialized
INFO - 2025-05-08 04:41:34 --> Router Class Initialized
INFO - 2025-05-08 04:41:34 --> Output Class Initialized
INFO - 2025-05-08 04:41:34 --> Security Class Initialized
DEBUG - 2025-05-08 04:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 04:41:34 --> Input Class Initialized
INFO - 2025-05-08 04:41:34 --> Language Class Initialized
INFO - 2025-05-08 04:41:34 --> Loader Class Initialized
INFO - 2025-05-08 04:41:34 --> Helper loaded: url_helper
INFO - 2025-05-08 04:41:34 --> Helper loaded: string_helper
INFO - 2025-05-08 04:41:34 --> Helper loaded: form_helper
INFO - 2025-05-08 04:41:34 --> Helper loaded: file_helper
INFO - 2025-05-08 04:41:34 --> Helper loaded: html_helper
INFO - 2025-05-08 04:41:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 04:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 04:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 04:41:34 --> Controller Class Initialized
INFO - 2025-05-08 04:41:34 --> Model "AuctionModel" initialized
INFO - 2025-05-08 04:41:34 --> Final output sent to browser
DEBUG - 2025-05-08 04:41:34 --> Total execution time: 0.2438
INFO - 2025-05-08 05:15:41 --> Config Class Initialized
INFO - 2025-05-08 05:15:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:15:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:15:41 --> Utf8 Class Initialized
INFO - 2025-05-08 05:15:41 --> URI Class Initialized
INFO - 2025-05-08 05:15:41 --> Router Class Initialized
INFO - 2025-05-08 05:15:41 --> Output Class Initialized
INFO - 2025-05-08 05:15:41 --> Security Class Initialized
DEBUG - 2025-05-08 05:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:15:41 --> Input Class Initialized
INFO - 2025-05-08 05:15:41 --> Language Class Initialized
INFO - 2025-05-08 05:15:41 --> Loader Class Initialized
INFO - 2025-05-08 05:15:41 --> Helper loaded: url_helper
INFO - 2025-05-08 05:15:41 --> Helper loaded: string_helper
INFO - 2025-05-08 05:15:41 --> Helper loaded: form_helper
INFO - 2025-05-08 05:15:41 --> Helper loaded: file_helper
INFO - 2025-05-08 05:15:41 --> Helper loaded: html_helper
INFO - 2025-05-08 05:15:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:15:41 --> Controller Class Initialized
INFO - 2025-05-08 05:15:41 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:15:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:15:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:15:41 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:15:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:15:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:15:41 --> Final output sent to browser
DEBUG - 2025-05-08 05:15:41 --> Total execution time: 0.0523
INFO - 2025-05-08 05:15:46 --> Config Class Initialized
INFO - 2025-05-08 05:15:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:15:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:15:46 --> Utf8 Class Initialized
INFO - 2025-05-08 05:15:46 --> URI Class Initialized
INFO - 2025-05-08 05:15:46 --> Router Class Initialized
INFO - 2025-05-08 05:15:46 --> Output Class Initialized
INFO - 2025-05-08 05:15:46 --> Security Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:15:46 --> Input Class Initialized
INFO - 2025-05-08 05:15:46 --> Language Class Initialized
INFO - 2025-05-08 05:15:46 --> Loader Class Initialized
INFO - 2025-05-08 05:15:46 --> Helper loaded: url_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: string_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: form_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: file_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: html_helper
INFO - 2025-05-08 05:15:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:15:46 --> Controller Class Initialized
INFO - 2025-05-08 05:15:46 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:15:46 --> Final output sent to browser
DEBUG - 2025-05-08 05:15:46 --> Total execution time: 0.0047
INFO - 2025-05-08 05:15:46 --> Config Class Initialized
INFO - 2025-05-08 05:15:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:15:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:15:46 --> Utf8 Class Initialized
INFO - 2025-05-08 05:15:46 --> URI Class Initialized
INFO - 2025-05-08 05:15:46 --> Router Class Initialized
INFO - 2025-05-08 05:15:46 --> Output Class Initialized
INFO - 2025-05-08 05:15:46 --> Security Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:15:46 --> Input Class Initialized
INFO - 2025-05-08 05:15:46 --> Language Class Initialized
INFO - 2025-05-08 05:15:46 --> Loader Class Initialized
INFO - 2025-05-08 05:15:46 --> Helper loaded: url_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: string_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: form_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: file_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: html_helper
INFO - 2025-05-08 05:15:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:15:46 --> Controller Class Initialized
INFO - 2025-05-08 05:15:46 --> Model "UserModel" initialized
INFO - 2025-05-08 05:15:46 --> Final output sent to browser
DEBUG - 2025-05-08 05:15:46 --> Total execution time: 0.0059
INFO - 2025-05-08 05:15:46 --> Config Class Initialized
INFO - 2025-05-08 05:15:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:15:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:15:46 --> Utf8 Class Initialized
INFO - 2025-05-08 05:15:46 --> URI Class Initialized
INFO - 2025-05-08 05:15:46 --> Router Class Initialized
INFO - 2025-05-08 05:15:46 --> Output Class Initialized
INFO - 2025-05-08 05:15:46 --> Security Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:15:46 --> Input Class Initialized
INFO - 2025-05-08 05:15:46 --> Language Class Initialized
INFO - 2025-05-08 05:15:46 --> Loader Class Initialized
INFO - 2025-05-08 05:15:46 --> Helper loaded: url_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: string_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: form_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: file_helper
INFO - 2025-05-08 05:15:46 --> Helper loaded: html_helper
INFO - 2025-05-08 05:15:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:15:46 --> Controller Class Initialized
INFO - 2025-05-08 05:15:46 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:15:46 --> Final output sent to browser
DEBUG - 2025-05-08 05:15:46 --> Total execution time: 0.0033
INFO - 2025-05-08 05:19:16 --> Config Class Initialized
INFO - 2025-05-08 05:19:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:19:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:19:16 --> Utf8 Class Initialized
INFO - 2025-05-08 05:19:16 --> URI Class Initialized
INFO - 2025-05-08 05:19:16 --> Router Class Initialized
INFO - 2025-05-08 05:19:16 --> Output Class Initialized
INFO - 2025-05-08 05:19:16 --> Security Class Initialized
DEBUG - 2025-05-08 05:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:19:16 --> Input Class Initialized
INFO - 2025-05-08 05:19:16 --> Language Class Initialized
INFO - 2025-05-08 05:19:16 --> Loader Class Initialized
INFO - 2025-05-08 05:19:16 --> Helper loaded: url_helper
INFO - 2025-05-08 05:19:16 --> Helper loaded: string_helper
INFO - 2025-05-08 05:19:16 --> Helper loaded: form_helper
INFO - 2025-05-08 05:19:16 --> Helper loaded: file_helper
INFO - 2025-05-08 05:19:16 --> Helper loaded: html_helper
INFO - 2025-05-08 05:19:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:19:16 --> Controller Class Initialized
INFO - 2025-05-08 05:19:16 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:19:16 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:19:16 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:19:16 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:19:16 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:19:16 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:19:16 --> Final output sent to browser
DEBUG - 2025-05-08 05:19:16 --> Total execution time: 0.0438
INFO - 2025-05-08 05:19:19 --> Config Class Initialized
INFO - 2025-05-08 05:19:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:19:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:19:19 --> Utf8 Class Initialized
INFO - 2025-05-08 05:19:19 --> URI Class Initialized
INFO - 2025-05-08 05:19:19 --> Router Class Initialized
INFO - 2025-05-08 05:19:19 --> Output Class Initialized
INFO - 2025-05-08 05:19:19 --> Security Class Initialized
DEBUG - 2025-05-08 05:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:19:19 --> Input Class Initialized
INFO - 2025-05-08 05:19:19 --> Language Class Initialized
INFO - 2025-05-08 05:19:19 --> Loader Class Initialized
INFO - 2025-05-08 05:19:19 --> Helper loaded: url_helper
INFO - 2025-05-08 05:19:19 --> Helper loaded: string_helper
INFO - 2025-05-08 05:19:19 --> Helper loaded: form_helper
INFO - 2025-05-08 05:19:19 --> Helper loaded: file_helper
INFO - 2025-05-08 05:19:19 --> Helper loaded: html_helper
INFO - 2025-05-08 05:19:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:19:19 --> Controller Class Initialized
INFO - 2025-05-08 05:19:19 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:19:19 --> Final output sent to browser
DEBUG - 2025-05-08 05:19:19 --> Total execution time: 0.0044
INFO - 2025-05-08 05:19:20 --> Config Class Initialized
INFO - 2025-05-08 05:19:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:19:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:19:20 --> Utf8 Class Initialized
INFO - 2025-05-08 05:19:20 --> URI Class Initialized
INFO - 2025-05-08 05:19:20 --> Router Class Initialized
INFO - 2025-05-08 05:19:20 --> Output Class Initialized
INFO - 2025-05-08 05:19:20 --> Security Class Initialized
DEBUG - 2025-05-08 05:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:19:20 --> Input Class Initialized
INFO - 2025-05-08 05:19:20 --> Language Class Initialized
INFO - 2025-05-08 05:19:20 --> Loader Class Initialized
INFO - 2025-05-08 05:19:20 --> Helper loaded: url_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: string_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: form_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: file_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: html_helper
INFO - 2025-05-08 05:19:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:19:20 --> Controller Class Initialized
INFO - 2025-05-08 05:19:20 --> Model "UserModel" initialized
INFO - 2025-05-08 05:19:20 --> Final output sent to browser
DEBUG - 2025-05-08 05:19:20 --> Total execution time: 0.0055
INFO - 2025-05-08 05:19:20 --> Config Class Initialized
INFO - 2025-05-08 05:19:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:19:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:19:20 --> Utf8 Class Initialized
INFO - 2025-05-08 05:19:20 --> URI Class Initialized
INFO - 2025-05-08 05:19:20 --> Router Class Initialized
INFO - 2025-05-08 05:19:20 --> Output Class Initialized
INFO - 2025-05-08 05:19:20 --> Security Class Initialized
DEBUG - 2025-05-08 05:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:19:20 --> Input Class Initialized
INFO - 2025-05-08 05:19:20 --> Language Class Initialized
INFO - 2025-05-08 05:19:20 --> Loader Class Initialized
INFO - 2025-05-08 05:19:20 --> Helper loaded: url_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: string_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: form_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: file_helper
INFO - 2025-05-08 05:19:20 --> Helper loaded: html_helper
INFO - 2025-05-08 05:19:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:19:20 --> Controller Class Initialized
INFO - 2025-05-08 05:19:20 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:19:20 --> Final output sent to browser
DEBUG - 2025-05-08 05:19:20 --> Total execution time: 0.0023
INFO - 2025-05-08 05:20:48 --> Config Class Initialized
INFO - 2025-05-08 05:20:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:20:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:20:48 --> Utf8 Class Initialized
INFO - 2025-05-08 05:20:48 --> URI Class Initialized
INFO - 2025-05-08 05:20:48 --> Router Class Initialized
INFO - 2025-05-08 05:20:48 --> Output Class Initialized
INFO - 2025-05-08 05:20:48 --> Security Class Initialized
DEBUG - 2025-05-08 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:20:48 --> Input Class Initialized
INFO - 2025-05-08 05:20:48 --> Language Class Initialized
INFO - 2025-05-08 05:20:48 --> Loader Class Initialized
INFO - 2025-05-08 05:20:48 --> Helper loaded: url_helper
INFO - 2025-05-08 05:20:48 --> Helper loaded: string_helper
INFO - 2025-05-08 05:20:48 --> Helper loaded: form_helper
INFO - 2025-05-08 05:20:48 --> Helper loaded: file_helper
INFO - 2025-05-08 05:20:48 --> Helper loaded: html_helper
INFO - 2025-05-08 05:20:48 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:20:48 --> Controller Class Initialized
INFO - 2025-05-08 05:20:48 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:20:48 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:20:48 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:20:48 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:20:48 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:20:48 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:20:48 --> Final output sent to browser
DEBUG - 2025-05-08 05:20:48 --> Total execution time: 0.0338
INFO - 2025-05-08 05:20:52 --> Config Class Initialized
INFO - 2025-05-08 05:20:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:20:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:20:52 --> Utf8 Class Initialized
INFO - 2025-05-08 05:20:52 --> URI Class Initialized
INFO - 2025-05-08 05:20:52 --> Router Class Initialized
INFO - 2025-05-08 05:20:52 --> Output Class Initialized
INFO - 2025-05-08 05:20:52 --> Security Class Initialized
DEBUG - 2025-05-08 05:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:20:52 --> Input Class Initialized
INFO - 2025-05-08 05:20:52 --> Language Class Initialized
INFO - 2025-05-08 05:20:52 --> Loader Class Initialized
INFO - 2025-05-08 05:20:52 --> Helper loaded: url_helper
INFO - 2025-05-08 05:20:52 --> Helper loaded: string_helper
INFO - 2025-05-08 05:20:52 --> Helper loaded: form_helper
INFO - 2025-05-08 05:20:52 --> Helper loaded: file_helper
INFO - 2025-05-08 05:20:52 --> Helper loaded: html_helper
INFO - 2025-05-08 05:20:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:20:52 --> Controller Class Initialized
INFO - 2025-05-08 05:20:52 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:20:52 --> Final output sent to browser
DEBUG - 2025-05-08 05:20:52 --> Total execution time: 0.0042
INFO - 2025-05-08 05:20:53 --> Config Class Initialized
INFO - 2025-05-08 05:20:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:20:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:20:53 --> Utf8 Class Initialized
INFO - 2025-05-08 05:20:53 --> URI Class Initialized
INFO - 2025-05-08 05:20:53 --> Router Class Initialized
INFO - 2025-05-08 05:20:53 --> Output Class Initialized
INFO - 2025-05-08 05:20:53 --> Security Class Initialized
DEBUG - 2025-05-08 05:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:20:53 --> Input Class Initialized
INFO - 2025-05-08 05:20:53 --> Language Class Initialized
INFO - 2025-05-08 05:20:53 --> Loader Class Initialized
INFO - 2025-05-08 05:20:53 --> Helper loaded: url_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: string_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: form_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: file_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: html_helper
INFO - 2025-05-08 05:20:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:20:53 --> Controller Class Initialized
INFO - 2025-05-08 05:20:53 --> Model "UserModel" initialized
INFO - 2025-05-08 05:20:53 --> Final output sent to browser
DEBUG - 2025-05-08 05:20:53 --> Total execution time: 0.0055
INFO - 2025-05-08 05:20:53 --> Config Class Initialized
INFO - 2025-05-08 05:20:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:20:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:20:53 --> Utf8 Class Initialized
INFO - 2025-05-08 05:20:53 --> URI Class Initialized
INFO - 2025-05-08 05:20:53 --> Router Class Initialized
INFO - 2025-05-08 05:20:53 --> Output Class Initialized
INFO - 2025-05-08 05:20:53 --> Security Class Initialized
DEBUG - 2025-05-08 05:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:20:53 --> Input Class Initialized
INFO - 2025-05-08 05:20:53 --> Language Class Initialized
INFO - 2025-05-08 05:20:53 --> Loader Class Initialized
INFO - 2025-05-08 05:20:53 --> Helper loaded: url_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: string_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: form_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: file_helper
INFO - 2025-05-08 05:20:53 --> Helper loaded: html_helper
INFO - 2025-05-08 05:20:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:20:53 --> Controller Class Initialized
INFO - 2025-05-08 05:20:53 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:20:53 --> Final output sent to browser
DEBUG - 2025-05-08 05:20:53 --> Total execution time: 0.0023
INFO - 2025-05-08 05:40:29 --> Config Class Initialized
INFO - 2025-05-08 05:40:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:40:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:40:29 --> Utf8 Class Initialized
INFO - 2025-05-08 05:40:29 --> URI Class Initialized
INFO - 2025-05-08 05:40:29 --> Router Class Initialized
INFO - 2025-05-08 05:40:29 --> Output Class Initialized
INFO - 2025-05-08 05:40:29 --> Security Class Initialized
DEBUG - 2025-05-08 05:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:40:29 --> Input Class Initialized
INFO - 2025-05-08 05:40:29 --> Language Class Initialized
INFO - 2025-05-08 05:40:29 --> Loader Class Initialized
INFO - 2025-05-08 05:40:29 --> Helper loaded: url_helper
INFO - 2025-05-08 05:40:29 --> Helper loaded: string_helper
INFO - 2025-05-08 05:40:29 --> Helper loaded: form_helper
INFO - 2025-05-08 05:40:29 --> Helper loaded: file_helper
INFO - 2025-05-08 05:40:29 --> Helper loaded: html_helper
INFO - 2025-05-08 05:40:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:40:29 --> Controller Class Initialized
INFO - 2025-05-08 05:40:29 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:40:29 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:40:29 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:40:29 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:40:29 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:40:29 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:40:29 --> Final output sent to browser
DEBUG - 2025-05-08 05:40:29 --> Total execution time: 0.0385
INFO - 2025-05-08 05:40:33 --> Config Class Initialized
INFO - 2025-05-08 05:40:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:40:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:40:33 --> Utf8 Class Initialized
INFO - 2025-05-08 05:40:33 --> URI Class Initialized
INFO - 2025-05-08 05:40:33 --> Router Class Initialized
INFO - 2025-05-08 05:40:33 --> Output Class Initialized
INFO - 2025-05-08 05:40:33 --> Security Class Initialized
DEBUG - 2025-05-08 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:40:33 --> Input Class Initialized
INFO - 2025-05-08 05:40:33 --> Language Class Initialized
INFO - 2025-05-08 05:40:33 --> Loader Class Initialized
INFO - 2025-05-08 05:40:33 --> Helper loaded: url_helper
INFO - 2025-05-08 05:40:33 --> Helper loaded: string_helper
INFO - 2025-05-08 05:40:33 --> Helper loaded: form_helper
INFO - 2025-05-08 05:40:33 --> Helper loaded: file_helper
INFO - 2025-05-08 05:40:33 --> Helper loaded: html_helper
INFO - 2025-05-08 05:40:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:40:33 --> Controller Class Initialized
INFO - 2025-05-08 05:40:33 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:40:33 --> Final output sent to browser
DEBUG - 2025-05-08 05:40:33 --> Total execution time: 0.0054
INFO - 2025-05-08 05:40:35 --> Config Class Initialized
INFO - 2025-05-08 05:40:35 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:40:35 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:40:35 --> Utf8 Class Initialized
INFO - 2025-05-08 05:40:35 --> URI Class Initialized
INFO - 2025-05-08 05:40:35 --> Router Class Initialized
INFO - 2025-05-08 05:40:35 --> Output Class Initialized
INFO - 2025-05-08 05:40:35 --> Security Class Initialized
DEBUG - 2025-05-08 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:40:35 --> Input Class Initialized
INFO - 2025-05-08 05:40:35 --> Language Class Initialized
INFO - 2025-05-08 05:40:35 --> Loader Class Initialized
INFO - 2025-05-08 05:40:35 --> Helper loaded: url_helper
INFO - 2025-05-08 05:40:35 --> Helper loaded: string_helper
INFO - 2025-05-08 05:40:35 --> Helper loaded: form_helper
INFO - 2025-05-08 05:40:35 --> Helper loaded: file_helper
INFO - 2025-05-08 05:40:35 --> Helper loaded: html_helper
INFO - 2025-05-08 05:40:35 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:40:35 --> Controller Class Initialized
INFO - 2025-05-08 05:40:35 --> Model "UserModel" initialized
INFO - 2025-05-08 05:40:35 --> Final output sent to browser
DEBUG - 2025-05-08 05:40:35 --> Total execution time: 0.0070
INFO - 2025-05-08 05:40:40 --> Config Class Initialized
INFO - 2025-05-08 05:40:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:40:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:40:40 --> Utf8 Class Initialized
INFO - 2025-05-08 05:40:40 --> URI Class Initialized
INFO - 2025-05-08 05:40:40 --> Router Class Initialized
INFO - 2025-05-08 05:40:40 --> Output Class Initialized
INFO - 2025-05-08 05:40:40 --> Security Class Initialized
DEBUG - 2025-05-08 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:40:40 --> Input Class Initialized
INFO - 2025-05-08 05:40:40 --> Language Class Initialized
INFO - 2025-05-08 05:40:40 --> Loader Class Initialized
INFO - 2025-05-08 05:40:40 --> Helper loaded: url_helper
INFO - 2025-05-08 05:40:40 --> Helper loaded: string_helper
INFO - 2025-05-08 05:40:40 --> Helper loaded: form_helper
INFO - 2025-05-08 05:40:40 --> Helper loaded: file_helper
INFO - 2025-05-08 05:40:40 --> Helper loaded: html_helper
INFO - 2025-05-08 05:40:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:40:40 --> Controller Class Initialized
INFO - 2025-05-08 05:40:40 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:40:40 --> Final output sent to browser
DEBUG - 2025-05-08 05:40:40 --> Total execution time: 0.0034
INFO - 2025-05-08 05:44:01 --> Config Class Initialized
INFO - 2025-05-08 05:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:01 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:01 --> URI Class Initialized
DEBUG - 2025-05-08 05:44:01 --> No URI present. Default controller set.
INFO - 2025-05-08 05:44:01 --> Router Class Initialized
INFO - 2025-05-08 05:44:01 --> Output Class Initialized
INFO - 2025-05-08 05:44:01 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:01 --> Input Class Initialized
INFO - 2025-05-08 05:44:01 --> Language Class Initialized
INFO - 2025-05-08 05:44:01 --> Loader Class Initialized
INFO - 2025-05-08 05:44:01 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:01 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:01 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:01 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:01 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:01 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:01 --> Controller Class Initialized
INFO - 2025-05-08 05:44:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:44:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:44:01 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 05:44:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:44:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:44:01 --> Final output sent to browser
DEBUG - 2025-05-08 05:44:01 --> Total execution time: 0.0316
INFO - 2025-05-08 05:44:05 --> Config Class Initialized
INFO - 2025-05-08 05:44:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:05 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:05 --> URI Class Initialized
INFO - 2025-05-08 05:44:05 --> Router Class Initialized
INFO - 2025-05-08 05:44:05 --> Output Class Initialized
INFO - 2025-05-08 05:44:05 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:05 --> Input Class Initialized
INFO - 2025-05-08 05:44:05 --> Language Class Initialized
INFO - 2025-05-08 05:44:05 --> Loader Class Initialized
INFO - 2025-05-08 05:44:05 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:05 --> Controller Class Initialized
INFO - 2025-05-08 05:44:05 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:44:05 --> Config Class Initialized
INFO - 2025-05-08 05:44:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:05 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:05 --> URI Class Initialized
DEBUG - 2025-05-08 05:44:05 --> No URI present. Default controller set.
INFO - 2025-05-08 05:44:05 --> Router Class Initialized
INFO - 2025-05-08 05:44:05 --> Output Class Initialized
INFO - 2025-05-08 05:44:05 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:05 --> Input Class Initialized
INFO - 2025-05-08 05:44:05 --> Language Class Initialized
INFO - 2025-05-08 05:44:05 --> Loader Class Initialized
INFO - 2025-05-08 05:44:05 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:05 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:05 --> Controller Class Initialized
INFO - 2025-05-08 05:44:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:44:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:44:05 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 05:44:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:44:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:44:05 --> Final output sent to browser
DEBUG - 2025-05-08 05:44:05 --> Total execution time: 0.0045
INFO - 2025-05-08 05:44:06 --> Config Class Initialized
INFO - 2025-05-08 05:44:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:06 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:06 --> URI Class Initialized
DEBUG - 2025-05-08 05:44:06 --> No URI present. Default controller set.
INFO - 2025-05-08 05:44:06 --> Router Class Initialized
INFO - 2025-05-08 05:44:06 --> Output Class Initialized
INFO - 2025-05-08 05:44:06 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:06 --> Input Class Initialized
INFO - 2025-05-08 05:44:06 --> Language Class Initialized
INFO - 2025-05-08 05:44:06 --> Loader Class Initialized
INFO - 2025-05-08 05:44:06 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:06 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:06 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:06 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:06 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:06 --> Controller Class Initialized
INFO - 2025-05-08 05:44:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:44:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:44:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 05:44:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:44:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:44:06 --> Final output sent to browser
DEBUG - 2025-05-08 05:44:06 --> Total execution time: 0.0025
INFO - 2025-05-08 05:44:07 --> Config Class Initialized
INFO - 2025-05-08 05:44:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:07 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:07 --> URI Class Initialized
INFO - 2025-05-08 05:44:07 --> Router Class Initialized
INFO - 2025-05-08 05:44:07 --> Output Class Initialized
INFO - 2025-05-08 05:44:07 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:07 --> Input Class Initialized
INFO - 2025-05-08 05:44:07 --> Language Class Initialized
ERROR - 2025-05-08 05:44:07 --> 404 Page Not Found: Banner1png/index
INFO - 2025-05-08 05:44:19 --> Config Class Initialized
INFO - 2025-05-08 05:44:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:19 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:19 --> URI Class Initialized
DEBUG - 2025-05-08 05:44:19 --> No URI present. Default controller set.
INFO - 2025-05-08 05:44:19 --> Router Class Initialized
INFO - 2025-05-08 05:44:19 --> Output Class Initialized
INFO - 2025-05-08 05:44:19 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:19 --> Input Class Initialized
INFO - 2025-05-08 05:44:19 --> Language Class Initialized
INFO - 2025-05-08 05:44:19 --> Loader Class Initialized
INFO - 2025-05-08 05:44:19 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:19 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:19 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:19 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:19 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:19 --> Controller Class Initialized
INFO - 2025-05-08 05:44:19 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:44:19 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:44:19 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 05:44:19 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:44:19 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:44:19 --> Final output sent to browser
DEBUG - 2025-05-08 05:44:19 --> Total execution time: 0.0041
INFO - 2025-05-08 05:44:23 --> Config Class Initialized
INFO - 2025-05-08 05:44:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:44:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:44:23 --> Utf8 Class Initialized
INFO - 2025-05-08 05:44:23 --> URI Class Initialized
INFO - 2025-05-08 05:44:23 --> Router Class Initialized
INFO - 2025-05-08 05:44:23 --> Output Class Initialized
INFO - 2025-05-08 05:44:23 --> Security Class Initialized
DEBUG - 2025-05-08 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:44:23 --> Input Class Initialized
INFO - 2025-05-08 05:44:23 --> Language Class Initialized
INFO - 2025-05-08 05:44:23 --> Loader Class Initialized
INFO - 2025-05-08 05:44:23 --> Helper loaded: url_helper
INFO - 2025-05-08 05:44:23 --> Helper loaded: string_helper
INFO - 2025-05-08 05:44:23 --> Helper loaded: form_helper
INFO - 2025-05-08 05:44:23 --> Helper loaded: file_helper
INFO - 2025-05-08 05:44:23 --> Helper loaded: html_helper
INFO - 2025-05-08 05:44:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:44:23 --> Controller Class Initialized
INFO - 2025-05-08 05:44:23 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:46:01 --> Config Class Initialized
INFO - 2025-05-08 05:46:01 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:46:01 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:46:01 --> Utf8 Class Initialized
INFO - 2025-05-08 05:46:01 --> URI Class Initialized
INFO - 2025-05-08 05:46:01 --> Router Class Initialized
INFO - 2025-05-08 05:46:01 --> Output Class Initialized
INFO - 2025-05-08 05:46:01 --> Security Class Initialized
DEBUG - 2025-05-08 05:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:46:01 --> Input Class Initialized
INFO - 2025-05-08 05:46:01 --> Language Class Initialized
INFO - 2025-05-08 05:46:01 --> Loader Class Initialized
INFO - 2025-05-08 05:46:01 --> Helper loaded: url_helper
INFO - 2025-05-08 05:46:01 --> Helper loaded: string_helper
INFO - 2025-05-08 05:46:01 --> Helper loaded: form_helper
INFO - 2025-05-08 05:46:01 --> Helper loaded: file_helper
INFO - 2025-05-08 05:46:01 --> Helper loaded: html_helper
INFO - 2025-05-08 05:46:01 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:46:01 --> Controller Class Initialized
INFO - 2025-05-08 05:46:01 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:46:01 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:46:01 --> Final output sent to browser
DEBUG - 2025-05-08 05:46:01 --> Total execution time: 0.0347
INFO - 2025-05-08 05:46:04 --> Config Class Initialized
INFO - 2025-05-08 05:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:46:04 --> Utf8 Class Initialized
INFO - 2025-05-08 05:46:04 --> URI Class Initialized
INFO - 2025-05-08 05:46:04 --> Router Class Initialized
INFO - 2025-05-08 05:46:04 --> Output Class Initialized
INFO - 2025-05-08 05:46:04 --> Security Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:46:04 --> Input Class Initialized
INFO - 2025-05-08 05:46:04 --> Language Class Initialized
INFO - 2025-05-08 05:46:04 --> Loader Class Initialized
INFO - 2025-05-08 05:46:04 --> Helper loaded: url_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: string_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: form_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: file_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: html_helper
INFO - 2025-05-08 05:46:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:46:04 --> Controller Class Initialized
INFO - 2025-05-08 05:46:04 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:46:04 --> Final output sent to browser
DEBUG - 2025-05-08 05:46:04 --> Total execution time: 0.0044
INFO - 2025-05-08 05:46:04 --> Config Class Initialized
INFO - 2025-05-08 05:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:46:04 --> Utf8 Class Initialized
INFO - 2025-05-08 05:46:04 --> URI Class Initialized
INFO - 2025-05-08 05:46:04 --> Router Class Initialized
INFO - 2025-05-08 05:46:04 --> Output Class Initialized
INFO - 2025-05-08 05:46:04 --> Security Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:46:04 --> Input Class Initialized
INFO - 2025-05-08 05:46:04 --> Language Class Initialized
INFO - 2025-05-08 05:46:04 --> Loader Class Initialized
INFO - 2025-05-08 05:46:04 --> Helper loaded: url_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: string_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: form_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: file_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: html_helper
INFO - 2025-05-08 05:46:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:46:04 --> Controller Class Initialized
INFO - 2025-05-08 05:46:04 --> Model "UserModel" initialized
INFO - 2025-05-08 05:46:04 --> Final output sent to browser
DEBUG - 2025-05-08 05:46:04 --> Total execution time: 0.0052
INFO - 2025-05-08 05:46:04 --> Config Class Initialized
INFO - 2025-05-08 05:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:46:04 --> Utf8 Class Initialized
INFO - 2025-05-08 05:46:04 --> URI Class Initialized
INFO - 2025-05-08 05:46:04 --> Router Class Initialized
INFO - 2025-05-08 05:46:04 --> Output Class Initialized
INFO - 2025-05-08 05:46:04 --> Security Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:46:04 --> Input Class Initialized
INFO - 2025-05-08 05:46:04 --> Language Class Initialized
INFO - 2025-05-08 05:46:04 --> Loader Class Initialized
INFO - 2025-05-08 05:46:04 --> Helper loaded: url_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: string_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: form_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: file_helper
INFO - 2025-05-08 05:46:04 --> Helper loaded: html_helper
INFO - 2025-05-08 05:46:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:46:04 --> Controller Class Initialized
INFO - 2025-05-08 05:46:04 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:46:04 --> Final output sent to browser
DEBUG - 2025-05-08 05:46:04 --> Total execution time: 0.0034
INFO - 2025-05-08 05:46:34 --> Config Class Initialized
INFO - 2025-05-08 05:46:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:46:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:46:34 --> Utf8 Class Initialized
INFO - 2025-05-08 05:46:34 --> URI Class Initialized
DEBUG - 2025-05-08 05:46:34 --> No URI present. Default controller set.
INFO - 2025-05-08 05:46:34 --> Router Class Initialized
INFO - 2025-05-08 05:46:34 --> Output Class Initialized
INFO - 2025-05-08 05:46:34 --> Security Class Initialized
DEBUG - 2025-05-08 05:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:46:34 --> Input Class Initialized
INFO - 2025-05-08 05:46:34 --> Language Class Initialized
INFO - 2025-05-08 05:46:34 --> Loader Class Initialized
INFO - 2025-05-08 05:46:34 --> Helper loaded: url_helper
INFO - 2025-05-08 05:46:34 --> Helper loaded: string_helper
INFO - 2025-05-08 05:46:34 --> Helper loaded: form_helper
INFO - 2025-05-08 05:46:34 --> Helper loaded: file_helper
INFO - 2025-05-08 05:46:34 --> Helper loaded: html_helper
INFO - 2025-05-08 05:46:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:46:34 --> Controller Class Initialized
INFO - 2025-05-08 05:46:34 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:46:34 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:46:34 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 05:46:34 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:46:34 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:46:34 --> Final output sent to browser
DEBUG - 2025-05-08 05:46:34 --> Total execution time: 0.0048
INFO - 2025-05-08 05:53:03 --> Config Class Initialized
INFO - 2025-05-08 05:53:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:03 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:03 --> URI Class Initialized
INFO - 2025-05-08 05:53:03 --> Router Class Initialized
INFO - 2025-05-08 05:53:03 --> Output Class Initialized
INFO - 2025-05-08 05:53:03 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:03 --> Input Class Initialized
INFO - 2025-05-08 05:53:03 --> Language Class Initialized
INFO - 2025-05-08 05:53:03 --> Loader Class Initialized
INFO - 2025-05-08 05:53:03 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:03 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:03 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:03 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:03 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:03 --> Controller Class Initialized
INFO - 2025-05-08 05:53:03 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:53:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:53:03 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:53:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:53:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:53:03 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:03 --> Total execution time: 0.0418
INFO - 2025-05-08 05:53:05 --> Config Class Initialized
INFO - 2025-05-08 05:53:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:05 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:05 --> URI Class Initialized
INFO - 2025-05-08 05:53:05 --> Router Class Initialized
INFO - 2025-05-08 05:53:05 --> Output Class Initialized
INFO - 2025-05-08 05:53:05 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:05 --> Input Class Initialized
INFO - 2025-05-08 05:53:05 --> Language Class Initialized
INFO - 2025-05-08 05:53:05 --> Loader Class Initialized
INFO - 2025-05-08 05:53:05 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:05 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:05 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:05 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:05 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:05 --> Controller Class Initialized
INFO - 2025-05-08 05:53:05 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:53:05 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:05 --> Total execution time: 0.0046
INFO - 2025-05-08 05:53:07 --> Config Class Initialized
INFO - 2025-05-08 05:53:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:07 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:07 --> URI Class Initialized
INFO - 2025-05-08 05:53:07 --> Router Class Initialized
INFO - 2025-05-08 05:53:07 --> Output Class Initialized
INFO - 2025-05-08 05:53:07 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:07 --> Input Class Initialized
INFO - 2025-05-08 05:53:07 --> Language Class Initialized
INFO - 2025-05-08 05:53:07 --> Loader Class Initialized
INFO - 2025-05-08 05:53:07 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:07 --> Controller Class Initialized
INFO - 2025-05-08 05:53:07 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:07 --> Config Class Initialized
INFO - 2025-05-08 05:53:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:07 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:07 --> URI Class Initialized
INFO - 2025-05-08 05:53:07 --> Router Class Initialized
INFO - 2025-05-08 05:53:07 --> Output Class Initialized
INFO - 2025-05-08 05:53:07 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:07 --> Input Class Initialized
INFO - 2025-05-08 05:53:07 --> Language Class Initialized
INFO - 2025-05-08 05:53:07 --> Loader Class Initialized
INFO - 2025-05-08 05:53:07 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:07 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:07 --> Controller Class Initialized
INFO - 2025-05-08 05:53:07 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:53:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:53:07 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/company/details.php
INFO - 2025-05-08 05:53:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:53:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:53:07 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:07 --> Total execution time: 0.0092
INFO - 2025-05-08 05:53:08 --> Config Class Initialized
INFO - 2025-05-08 05:53:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:08 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:08 --> URI Class Initialized
INFO - 2025-05-08 05:53:08 --> Router Class Initialized
INFO - 2025-05-08 05:53:08 --> Output Class Initialized
INFO - 2025-05-08 05:53:08 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:08 --> Input Class Initialized
INFO - 2025-05-08 05:53:08 --> Language Class Initialized
INFO - 2025-05-08 05:53:08 --> Loader Class Initialized
INFO - 2025-05-08 05:53:08 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:08 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:08 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:08 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:08 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:08 --> Controller Class Initialized
INFO - 2025-05-08 05:53:09 --> Config Class Initialized
INFO - 2025-05-08 05:53:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:09 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:09 --> URI Class Initialized
INFO - 2025-05-08 05:53:09 --> Router Class Initialized
INFO - 2025-05-08 05:53:09 --> Output Class Initialized
INFO - 2025-05-08 05:53:09 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:09 --> Input Class Initialized
INFO - 2025-05-08 05:53:09 --> Language Class Initialized
INFO - 2025-05-08 05:53:09 --> Loader Class Initialized
INFO - 2025-05-08 05:53:09 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:09 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:09 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:09 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:09 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:09 --> Controller Class Initialized
INFO - 2025-05-08 05:53:09 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:09 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:09 --> Total execution time: 0.0040
INFO - 2025-05-08 05:53:11 --> Config Class Initialized
INFO - 2025-05-08 05:53:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:11 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:11 --> URI Class Initialized
INFO - 2025-05-08 05:53:11 --> Router Class Initialized
INFO - 2025-05-08 05:53:11 --> Output Class Initialized
INFO - 2025-05-08 05:53:11 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:11 --> Input Class Initialized
INFO - 2025-05-08 05:53:11 --> Language Class Initialized
INFO - 2025-05-08 05:53:11 --> Loader Class Initialized
INFO - 2025-05-08 05:53:11 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:11 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:11 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:11 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:11 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:11 --> Controller Class Initialized
INFO - 2025-05-08 05:53:11 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:15 --> Config Class Initialized
INFO - 2025-05-08 05:53:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:15 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:15 --> URI Class Initialized
INFO - 2025-05-08 05:53:15 --> Router Class Initialized
INFO - 2025-05-08 05:53:15 --> Output Class Initialized
INFO - 2025-05-08 05:53:15 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:15 --> Input Class Initialized
INFO - 2025-05-08 05:53:15 --> Language Class Initialized
INFO - 2025-05-08 05:53:15 --> Loader Class Initialized
INFO - 2025-05-08 05:53:15 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:15 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:15 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:15 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:15 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:15 --> Controller Class Initialized
INFO - 2025-05-08 05:53:15 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:15 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:53:15 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:53:15 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/staff/manage.php
INFO - 2025-05-08 05:53:15 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:53:15 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:53:15 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:15 --> Total execution time: 0.0106
INFO - 2025-05-08 05:53:16 --> Config Class Initialized
INFO - 2025-05-08 05:53:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:53:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:53:16 --> Utf8 Class Initialized
INFO - 2025-05-08 05:53:16 --> URI Class Initialized
INFO - 2025-05-08 05:53:16 --> Router Class Initialized
INFO - 2025-05-08 05:53:16 --> Output Class Initialized
INFO - 2025-05-08 05:53:16 --> Security Class Initialized
DEBUG - 2025-05-08 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:53:16 --> Input Class Initialized
INFO - 2025-05-08 05:53:16 --> Language Class Initialized
INFO - 2025-05-08 05:53:16 --> Loader Class Initialized
INFO - 2025-05-08 05:53:16 --> Helper loaded: url_helper
INFO - 2025-05-08 05:53:16 --> Helper loaded: string_helper
INFO - 2025-05-08 05:53:16 --> Helper loaded: form_helper
INFO - 2025-05-08 05:53:16 --> Helper loaded: file_helper
INFO - 2025-05-08 05:53:16 --> Helper loaded: html_helper
INFO - 2025-05-08 05:53:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:53:16 --> Controller Class Initialized
INFO - 2025-05-08 05:53:16 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:53:16 --> Model "StaffModel" initialized
INFO - 2025-05-08 05:53:16 --> Final output sent to browser
DEBUG - 2025-05-08 05:53:16 --> Total execution time: 0.0079
INFO - 2025-05-08 05:55:57 --> Config Class Initialized
INFO - 2025-05-08 05:55:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:55:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:55:57 --> Utf8 Class Initialized
INFO - 2025-05-08 05:55:57 --> URI Class Initialized
INFO - 2025-05-08 05:55:57 --> Router Class Initialized
INFO - 2025-05-08 05:55:57 --> Output Class Initialized
INFO - 2025-05-08 05:55:57 --> Security Class Initialized
DEBUG - 2025-05-08 05:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:55:57 --> Input Class Initialized
INFO - 2025-05-08 05:55:57 --> Language Class Initialized
INFO - 2025-05-08 05:55:57 --> Loader Class Initialized
INFO - 2025-05-08 05:55:57 --> Helper loaded: url_helper
INFO - 2025-05-08 05:55:57 --> Helper loaded: string_helper
INFO - 2025-05-08 05:55:57 --> Helper loaded: form_helper
INFO - 2025-05-08 05:55:57 --> Helper loaded: file_helper
INFO - 2025-05-08 05:55:57 --> Helper loaded: html_helper
INFO - 2025-05-08 05:55:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:55:57 --> Controller Class Initialized
INFO - 2025-05-08 05:55:57 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:55:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:55:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:55:57 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/staff/manage.php
INFO - 2025-05-08 05:55:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:55:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:55:57 --> Final output sent to browser
DEBUG - 2025-05-08 05:55:57 --> Total execution time: 0.0337
INFO - 2025-05-08 05:55:58 --> Config Class Initialized
INFO - 2025-05-08 05:55:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:55:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:55:58 --> Utf8 Class Initialized
INFO - 2025-05-08 05:55:58 --> URI Class Initialized
INFO - 2025-05-08 05:55:58 --> Router Class Initialized
INFO - 2025-05-08 05:55:58 --> Output Class Initialized
INFO - 2025-05-08 05:55:58 --> Security Class Initialized
DEBUG - 2025-05-08 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:55:58 --> Input Class Initialized
INFO - 2025-05-08 05:55:58 --> Language Class Initialized
INFO - 2025-05-08 05:55:58 --> Loader Class Initialized
INFO - 2025-05-08 05:55:58 --> Helper loaded: url_helper
INFO - 2025-05-08 05:55:58 --> Helper loaded: string_helper
INFO - 2025-05-08 05:55:58 --> Helper loaded: form_helper
INFO - 2025-05-08 05:55:58 --> Helper loaded: file_helper
INFO - 2025-05-08 05:55:58 --> Helper loaded: html_helper
INFO - 2025-05-08 05:55:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:55:58 --> Controller Class Initialized
INFO - 2025-05-08 05:55:58 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:55:58 --> Model "StaffModel" initialized
INFO - 2025-05-08 05:55:58 --> Final output sent to browser
DEBUG - 2025-05-08 05:55:58 --> Total execution time: 0.0047
INFO - 2025-05-08 05:56:05 --> Config Class Initialized
INFO - 2025-05-08 05:56:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:56:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:56:05 --> Utf8 Class Initialized
INFO - 2025-05-08 05:56:05 --> URI Class Initialized
INFO - 2025-05-08 05:56:05 --> Router Class Initialized
INFO - 2025-05-08 05:56:05 --> Output Class Initialized
INFO - 2025-05-08 05:56:05 --> Security Class Initialized
DEBUG - 2025-05-08 05:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:56:05 --> Input Class Initialized
INFO - 2025-05-08 05:56:05 --> Language Class Initialized
INFO - 2025-05-08 05:56:05 --> Loader Class Initialized
INFO - 2025-05-08 05:56:05 --> Helper loaded: url_helper
INFO - 2025-05-08 05:56:05 --> Helper loaded: string_helper
INFO - 2025-05-08 05:56:05 --> Helper loaded: form_helper
INFO - 2025-05-08 05:56:05 --> Helper loaded: file_helper
INFO - 2025-05-08 05:56:05 --> Helper loaded: html_helper
INFO - 2025-05-08 05:56:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:56:05 --> Controller Class Initialized
INFO - 2025-05-08 05:56:05 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:56:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:56:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:56:05 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/staff/manage.php
INFO - 2025-05-08 05:56:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:56:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:56:05 --> Final output sent to browser
DEBUG - 2025-05-08 05:56:05 --> Total execution time: 0.0032
INFO - 2025-05-08 05:56:08 --> Config Class Initialized
INFO - 2025-05-08 05:56:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:56:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:56:08 --> Utf8 Class Initialized
INFO - 2025-05-08 05:56:08 --> URI Class Initialized
INFO - 2025-05-08 05:56:08 --> Router Class Initialized
INFO - 2025-05-08 05:56:08 --> Output Class Initialized
INFO - 2025-05-08 05:56:08 --> Security Class Initialized
DEBUG - 2025-05-08 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:56:08 --> Input Class Initialized
INFO - 2025-05-08 05:56:08 --> Language Class Initialized
INFO - 2025-05-08 05:56:08 --> Loader Class Initialized
INFO - 2025-05-08 05:56:08 --> Helper loaded: url_helper
INFO - 2025-05-08 05:56:08 --> Helper loaded: string_helper
INFO - 2025-05-08 05:56:08 --> Helper loaded: form_helper
INFO - 2025-05-08 05:56:08 --> Helper loaded: file_helper
INFO - 2025-05-08 05:56:08 --> Helper loaded: html_helper
INFO - 2025-05-08 05:56:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:56:08 --> Controller Class Initialized
INFO - 2025-05-08 05:56:08 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:56:08 --> Model "StaffModel" initialized
INFO - 2025-05-08 05:56:08 --> Final output sent to browser
DEBUG - 2025-05-08 05:56:08 --> Total execution time: 0.0057
INFO - 2025-05-08 05:56:42 --> Config Class Initialized
INFO - 2025-05-08 05:56:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:56:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:56:42 --> Utf8 Class Initialized
INFO - 2025-05-08 05:56:42 --> URI Class Initialized
INFO - 2025-05-08 05:56:42 --> Router Class Initialized
INFO - 2025-05-08 05:56:42 --> Output Class Initialized
INFO - 2025-05-08 05:56:42 --> Security Class Initialized
DEBUG - 2025-05-08 05:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:56:42 --> Input Class Initialized
INFO - 2025-05-08 05:56:42 --> Language Class Initialized
INFO - 2025-05-08 05:56:42 --> Loader Class Initialized
INFO - 2025-05-08 05:56:42 --> Helper loaded: url_helper
INFO - 2025-05-08 05:56:42 --> Helper loaded: string_helper
INFO - 2025-05-08 05:56:42 --> Helper loaded: form_helper
INFO - 2025-05-08 05:56:42 --> Helper loaded: file_helper
INFO - 2025-05-08 05:56:42 --> Helper loaded: html_helper
INFO - 2025-05-08 05:56:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:56:42 --> Controller Class Initialized
INFO - 2025-05-08 05:56:42 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:56:42 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:56:42 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 05:56:42 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:56:42 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:56:42 --> Final output sent to browser
DEBUG - 2025-05-08 05:56:42 --> Total execution time: 0.0066
INFO - 2025-05-08 05:57:13 --> Config Class Initialized
INFO - 2025-05-08 05:57:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:57:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:57:13 --> Utf8 Class Initialized
INFO - 2025-05-08 05:57:13 --> URI Class Initialized
INFO - 2025-05-08 05:57:13 --> Router Class Initialized
INFO - 2025-05-08 05:57:13 --> Output Class Initialized
INFO - 2025-05-08 05:57:13 --> Security Class Initialized
DEBUG - 2025-05-08 05:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:57:13 --> Input Class Initialized
INFO - 2025-05-08 05:57:13 --> Language Class Initialized
INFO - 2025-05-08 05:57:13 --> Loader Class Initialized
INFO - 2025-05-08 05:57:13 --> Helper loaded: url_helper
INFO - 2025-05-08 05:57:13 --> Helper loaded: string_helper
INFO - 2025-05-08 05:57:13 --> Helper loaded: form_helper
INFO - 2025-05-08 05:57:13 --> Helper loaded: file_helper
INFO - 2025-05-08 05:57:13 --> Helper loaded: html_helper
INFO - 2025-05-08 05:57:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:57:13 --> Controller Class Initialized
INFO - 2025-05-08 05:57:13 --> Model "CompanyModel" initialized
INFO - 2025-05-08 05:57:13 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 05:57:13 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 05:57:13 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 05:57:13 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 05:57:13 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 05:57:13 --> Final output sent to browser
DEBUG - 2025-05-08 05:57:13 --> Total execution time: 0.0091
INFO - 2025-05-08 05:57:14 --> Config Class Initialized
INFO - 2025-05-08 05:57:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:57:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:57:14 --> Utf8 Class Initialized
INFO - 2025-05-08 05:57:14 --> URI Class Initialized
INFO - 2025-05-08 05:57:14 --> Router Class Initialized
INFO - 2025-05-08 05:57:14 --> Output Class Initialized
INFO - 2025-05-08 05:57:14 --> Security Class Initialized
DEBUG - 2025-05-08 05:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:57:14 --> Input Class Initialized
INFO - 2025-05-08 05:57:14 --> Language Class Initialized
INFO - 2025-05-08 05:57:14 --> Loader Class Initialized
INFO - 2025-05-08 05:57:14 --> Helper loaded: url_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: string_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: form_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: file_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: html_helper
INFO - 2025-05-08 05:57:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:57:14 --> Controller Class Initialized
INFO - 2025-05-08 05:57:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:57:14 --> Final output sent to browser
DEBUG - 2025-05-08 05:57:14 --> Total execution time: 0.0046
INFO - 2025-05-08 05:57:14 --> Config Class Initialized
INFO - 2025-05-08 05:57:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:57:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:57:14 --> Utf8 Class Initialized
INFO - 2025-05-08 05:57:14 --> URI Class Initialized
INFO - 2025-05-08 05:57:14 --> Router Class Initialized
INFO - 2025-05-08 05:57:14 --> Output Class Initialized
INFO - 2025-05-08 05:57:14 --> Security Class Initialized
DEBUG - 2025-05-08 05:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:57:14 --> Input Class Initialized
INFO - 2025-05-08 05:57:14 --> Language Class Initialized
INFO - 2025-05-08 05:57:14 --> Loader Class Initialized
INFO - 2025-05-08 05:57:14 --> Helper loaded: url_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: string_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: form_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: file_helper
INFO - 2025-05-08 05:57:14 --> Helper loaded: html_helper
INFO - 2025-05-08 05:57:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:57:14 --> Controller Class Initialized
INFO - 2025-05-08 05:57:14 --> Model "UserModel" initialized
INFO - 2025-05-08 05:57:14 --> Final output sent to browser
DEBUG - 2025-05-08 05:57:14 --> Total execution time: 0.0089
INFO - 2025-05-08 05:57:15 --> Config Class Initialized
INFO - 2025-05-08 05:57:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 05:57:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 05:57:15 --> Utf8 Class Initialized
INFO - 2025-05-08 05:57:15 --> URI Class Initialized
INFO - 2025-05-08 05:57:15 --> Router Class Initialized
INFO - 2025-05-08 05:57:15 --> Output Class Initialized
INFO - 2025-05-08 05:57:15 --> Security Class Initialized
DEBUG - 2025-05-08 05:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 05:57:15 --> Input Class Initialized
INFO - 2025-05-08 05:57:15 --> Language Class Initialized
INFO - 2025-05-08 05:57:15 --> Loader Class Initialized
INFO - 2025-05-08 05:57:15 --> Helper loaded: url_helper
INFO - 2025-05-08 05:57:15 --> Helper loaded: string_helper
INFO - 2025-05-08 05:57:15 --> Helper loaded: form_helper
INFO - 2025-05-08 05:57:15 --> Helper loaded: file_helper
INFO - 2025-05-08 05:57:15 --> Helper loaded: html_helper
INFO - 2025-05-08 05:57:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 05:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 05:57:15 --> Controller Class Initialized
INFO - 2025-05-08 05:57:15 --> Model "AuctionModel" initialized
INFO - 2025-05-08 05:57:15 --> Final output sent to browser
DEBUG - 2025-05-08 05:57:15 --> Total execution time: 0.0034
INFO - 2025-05-08 06:08:07 --> Config Class Initialized
INFO - 2025-05-08 06:08:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 06:08:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 06:08:07 --> Utf8 Class Initialized
INFO - 2025-05-08 06:08:07 --> URI Class Initialized
INFO - 2025-05-08 06:08:07 --> Router Class Initialized
INFO - 2025-05-08 06:08:07 --> Output Class Initialized
INFO - 2025-05-08 06:08:07 --> Security Class Initialized
DEBUG - 2025-05-08 06:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 06:08:07 --> Input Class Initialized
INFO - 2025-05-08 06:08:07 --> Language Class Initialized
INFO - 2025-05-08 06:08:07 --> Loader Class Initialized
INFO - 2025-05-08 06:08:07 --> Helper loaded: url_helper
INFO - 2025-05-08 06:08:07 --> Helper loaded: string_helper
INFO - 2025-05-08 06:08:07 --> Helper loaded: form_helper
INFO - 2025-05-08 06:08:07 --> Helper loaded: file_helper
INFO - 2025-05-08 06:08:07 --> Helper loaded: html_helper
INFO - 2025-05-08 06:08:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 06:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 06:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 06:08:07 --> Controller Class Initialized
INFO - 2025-05-08 06:08:08 --> Config Class Initialized
INFO - 2025-05-08 06:08:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 06:08:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 06:08:08 --> Utf8 Class Initialized
INFO - 2025-05-08 06:08:08 --> URI Class Initialized
INFO - 2025-05-08 06:08:08 --> Router Class Initialized
INFO - 2025-05-08 06:08:08 --> Output Class Initialized
INFO - 2025-05-08 06:08:08 --> Security Class Initialized
DEBUG - 2025-05-08 06:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 06:08:08 --> Input Class Initialized
INFO - 2025-05-08 06:08:08 --> Language Class Initialized
INFO - 2025-05-08 06:08:08 --> Loader Class Initialized
INFO - 2025-05-08 06:08:08 --> Helper loaded: url_helper
INFO - 2025-05-08 06:08:08 --> Helper loaded: string_helper
INFO - 2025-05-08 06:08:08 --> Helper loaded: form_helper
INFO - 2025-05-08 06:08:08 --> Helper loaded: file_helper
INFO - 2025-05-08 06:08:08 --> Helper loaded: html_helper
INFO - 2025-05-08 06:08:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 06:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 06:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 06:08:08 --> Controller Class Initialized
INFO - 2025-05-08 06:08:09 --> Config Class Initialized
INFO - 2025-05-08 06:08:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 06:08:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 06:08:09 --> Utf8 Class Initialized
INFO - 2025-05-08 06:08:09 --> URI Class Initialized
DEBUG - 2025-05-08 06:08:09 --> No URI present. Default controller set.
INFO - 2025-05-08 06:08:09 --> Router Class Initialized
INFO - 2025-05-08 06:08:09 --> Output Class Initialized
INFO - 2025-05-08 06:08:09 --> Security Class Initialized
DEBUG - 2025-05-08 06:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 06:08:09 --> Input Class Initialized
INFO - 2025-05-08 06:08:09 --> Language Class Initialized
INFO - 2025-05-08 06:08:09 --> Loader Class Initialized
INFO - 2025-05-08 06:08:09 --> Helper loaded: url_helper
INFO - 2025-05-08 06:08:09 --> Helper loaded: string_helper
INFO - 2025-05-08 06:08:09 --> Helper loaded: form_helper
INFO - 2025-05-08 06:08:09 --> Helper loaded: file_helper
INFO - 2025-05-08 06:08:09 --> Helper loaded: html_helper
INFO - 2025-05-08 06:08:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 06:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 06:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 06:08:09 --> Controller Class Initialized
INFO - 2025-05-08 06:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 06:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 06:08:09 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 06:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 06:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 06:08:09 --> Final output sent to browser
DEBUG - 2025-05-08 06:08:09 --> Total execution time: 0.0035
INFO - 2025-05-08 06:08:12 --> Config Class Initialized
INFO - 2025-05-08 06:08:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 06:08:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 06:08:12 --> Utf8 Class Initialized
INFO - 2025-05-08 06:08:12 --> URI Class Initialized
INFO - 2025-05-08 06:08:12 --> Router Class Initialized
INFO - 2025-05-08 06:08:12 --> Output Class Initialized
INFO - 2025-05-08 06:08:12 --> Security Class Initialized
DEBUG - 2025-05-08 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 06:08:12 --> Input Class Initialized
INFO - 2025-05-08 06:08:12 --> Language Class Initialized
INFO - 2025-05-08 06:08:12 --> Loader Class Initialized
INFO - 2025-05-08 06:08:12 --> Helper loaded: url_helper
INFO - 2025-05-08 06:08:12 --> Helper loaded: string_helper
INFO - 2025-05-08 06:08:12 --> Helper loaded: form_helper
INFO - 2025-05-08 06:08:12 --> Helper loaded: file_helper
INFO - 2025-05-08 06:08:12 --> Helper loaded: html_helper
INFO - 2025-05-08 06:08:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 06:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 06:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 06:08:12 --> Controller Class Initialized
INFO - 2025-05-08 06:08:12 --> Model "AuctionModel" initialized
INFO - 2025-05-08 06:14:27 --> Config Class Initialized
INFO - 2025-05-08 06:14:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 06:14:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 06:14:27 --> Utf8 Class Initialized
INFO - 2025-05-08 06:14:27 --> URI Class Initialized
DEBUG - 2025-05-08 06:14:27 --> No URI present. Default controller set.
INFO - 2025-05-08 06:14:27 --> Router Class Initialized
INFO - 2025-05-08 06:14:27 --> Output Class Initialized
INFO - 2025-05-08 06:14:27 --> Security Class Initialized
DEBUG - 2025-05-08 06:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 06:14:27 --> Input Class Initialized
INFO - 2025-05-08 06:14:27 --> Language Class Initialized
INFO - 2025-05-08 06:14:27 --> Loader Class Initialized
INFO - 2025-05-08 06:14:27 --> Helper loaded: url_helper
INFO - 2025-05-08 06:14:27 --> Helper loaded: string_helper
INFO - 2025-05-08 06:14:27 --> Helper loaded: form_helper
INFO - 2025-05-08 06:14:27 --> Helper loaded: file_helper
INFO - 2025-05-08 06:14:27 --> Helper loaded: html_helper
INFO - 2025-05-08 06:14:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 06:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 06:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 06:14:27 --> Controller Class Initialized
INFO - 2025-05-08 06:14:27 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 06:14:27 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 06:14:27 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 06:14:27 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 06:14:27 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 06:14:27 --> Final output sent to browser
DEBUG - 2025-05-08 06:14:27 --> Total execution time: 0.0287
INFO - 2025-05-08 07:12:31 --> Config Class Initialized
INFO - 2025-05-08 07:12:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 07:12:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 07:12:31 --> Utf8 Class Initialized
INFO - 2025-05-08 07:12:31 --> URI Class Initialized
DEBUG - 2025-05-08 07:12:31 --> No URI present. Default controller set.
INFO - 2025-05-08 07:12:31 --> Router Class Initialized
INFO - 2025-05-08 07:12:31 --> Output Class Initialized
INFO - 2025-05-08 07:12:31 --> Security Class Initialized
DEBUG - 2025-05-08 07:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 07:12:31 --> Input Class Initialized
INFO - 2025-05-08 07:12:31 --> Language Class Initialized
INFO - 2025-05-08 07:12:31 --> Loader Class Initialized
INFO - 2025-05-08 07:12:31 --> Helper loaded: url_helper
INFO - 2025-05-08 07:12:31 --> Helper loaded: string_helper
INFO - 2025-05-08 07:12:31 --> Helper loaded: form_helper
INFO - 2025-05-08 07:12:31 --> Helper loaded: file_helper
INFO - 2025-05-08 07:12:31 --> Helper loaded: html_helper
INFO - 2025-05-08 07:12:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 07:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 07:12:31 --> Controller Class Initialized
INFO - 2025-05-08 07:12:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 07:12:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 07:12:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 07:12:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 07:12:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 07:12:31 --> Final output sent to browser
DEBUG - 2025-05-08 07:12:31 --> Total execution time: 0.0598
INFO - 2025-05-08 07:12:34 --> Config Class Initialized
INFO - 2025-05-08 07:12:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 07:12:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 07:12:34 --> Utf8 Class Initialized
INFO - 2025-05-08 07:12:34 --> URI Class Initialized
INFO - 2025-05-08 07:12:34 --> Router Class Initialized
INFO - 2025-05-08 07:12:34 --> Output Class Initialized
INFO - 2025-05-08 07:12:34 --> Security Class Initialized
DEBUG - 2025-05-08 07:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 07:12:34 --> Input Class Initialized
INFO - 2025-05-08 07:12:34 --> Language Class Initialized
INFO - 2025-05-08 07:12:34 --> Loader Class Initialized
INFO - 2025-05-08 07:12:34 --> Helper loaded: url_helper
INFO - 2025-05-08 07:12:34 --> Helper loaded: string_helper
INFO - 2025-05-08 07:12:34 --> Helper loaded: form_helper
INFO - 2025-05-08 07:12:34 --> Helper loaded: file_helper
INFO - 2025-05-08 07:12:34 --> Helper loaded: html_helper
INFO - 2025-05-08 07:12:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 07:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 07:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 07:12:34 --> Controller Class Initialized
INFO - 2025-05-08 07:12:34 --> Model "AuctionModel" initialized
INFO - 2025-05-08 07:15:51 --> Config Class Initialized
INFO - 2025-05-08 07:15:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 07:15:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 07:15:51 --> Utf8 Class Initialized
INFO - 2025-05-08 07:15:51 --> URI Class Initialized
INFO - 2025-05-08 07:15:51 --> Router Class Initialized
INFO - 2025-05-08 07:15:51 --> Output Class Initialized
INFO - 2025-05-08 07:15:51 --> Security Class Initialized
DEBUG - 2025-05-08 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 07:15:51 --> Input Class Initialized
INFO - 2025-05-08 07:15:51 --> Language Class Initialized
ERROR - 2025-05-08 07:15:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-08 07:41:59 --> Config Class Initialized
INFO - 2025-05-08 07:41:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 07:41:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 07:41:59 --> Utf8 Class Initialized
INFO - 2025-05-08 07:41:59 --> URI Class Initialized
DEBUG - 2025-05-08 07:41:59 --> No URI present. Default controller set.
INFO - 2025-05-08 07:41:59 --> Router Class Initialized
INFO - 2025-05-08 07:41:59 --> Output Class Initialized
INFO - 2025-05-08 07:41:59 --> Security Class Initialized
DEBUG - 2025-05-08 07:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 07:41:59 --> Input Class Initialized
INFO - 2025-05-08 07:41:59 --> Language Class Initialized
INFO - 2025-05-08 07:41:59 --> Loader Class Initialized
INFO - 2025-05-08 07:41:59 --> Helper loaded: url_helper
INFO - 2025-05-08 07:41:59 --> Helper loaded: string_helper
INFO - 2025-05-08 07:41:59 --> Helper loaded: form_helper
INFO - 2025-05-08 07:41:59 --> Helper loaded: file_helper
INFO - 2025-05-08 07:41:59 --> Helper loaded: html_helper
INFO - 2025-05-08 07:41:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 07:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 07:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 07:41:59 --> Controller Class Initialized
INFO - 2025-05-08 07:41:59 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 07:41:59 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 07:41:59 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 07:41:59 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 07:41:59 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 07:41:59 --> Final output sent to browser
DEBUG - 2025-05-08 07:41:59 --> Total execution time: 0.0552
INFO - 2025-05-08 07:42:05 --> Config Class Initialized
INFO - 2025-05-08 07:42:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 07:42:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 07:42:05 --> Utf8 Class Initialized
INFO - 2025-05-08 07:42:05 --> URI Class Initialized
DEBUG - 2025-05-08 07:42:05 --> No URI present. Default controller set.
INFO - 2025-05-08 07:42:05 --> Router Class Initialized
INFO - 2025-05-08 07:42:05 --> Output Class Initialized
INFO - 2025-05-08 07:42:05 --> Security Class Initialized
DEBUG - 2025-05-08 07:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 07:42:05 --> Input Class Initialized
INFO - 2025-05-08 07:42:05 --> Language Class Initialized
INFO - 2025-05-08 07:42:05 --> Loader Class Initialized
INFO - 2025-05-08 07:42:05 --> Helper loaded: url_helper
INFO - 2025-05-08 07:42:05 --> Helper loaded: string_helper
INFO - 2025-05-08 07:42:05 --> Helper loaded: form_helper
INFO - 2025-05-08 07:42:05 --> Helper loaded: file_helper
INFO - 2025-05-08 07:42:05 --> Helper loaded: html_helper
INFO - 2025-05-08 07:42:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 07:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 07:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 07:42:05 --> Controller Class Initialized
INFO - 2025-05-08 07:42:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 07:42:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 07:42:05 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 07:42:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 07:42:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 07:42:05 --> Final output sent to browser
DEBUG - 2025-05-08 07:42:05 --> Total execution time: 0.0035
INFO - 2025-05-08 08:40:31 --> Config Class Initialized
INFO - 2025-05-08 08:40:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 08:40:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 08:40:31 --> Utf8 Class Initialized
INFO - 2025-05-08 08:40:31 --> URI Class Initialized
DEBUG - 2025-05-08 08:40:31 --> No URI present. Default controller set.
INFO - 2025-05-08 08:40:31 --> Router Class Initialized
INFO - 2025-05-08 08:40:31 --> Output Class Initialized
INFO - 2025-05-08 08:40:31 --> Security Class Initialized
DEBUG - 2025-05-08 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 08:40:31 --> Input Class Initialized
INFO - 2025-05-08 08:40:31 --> Language Class Initialized
INFO - 2025-05-08 08:40:31 --> Loader Class Initialized
INFO - 2025-05-08 08:40:31 --> Helper loaded: url_helper
INFO - 2025-05-08 08:40:31 --> Helper loaded: string_helper
INFO - 2025-05-08 08:40:31 --> Helper loaded: form_helper
INFO - 2025-05-08 08:40:31 --> Helper loaded: file_helper
INFO - 2025-05-08 08:40:31 --> Helper loaded: html_helper
INFO - 2025-05-08 08:40:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 08:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 08:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 08:40:31 --> Controller Class Initialized
INFO - 2025-05-08 08:40:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 08:40:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 08:40:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 08:40:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 08:40:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 08:40:31 --> Final output sent to browser
DEBUG - 2025-05-08 08:40:31 --> Total execution time: 0.0563
INFO - 2025-05-08 10:18:27 --> Config Class Initialized
INFO - 2025-05-08 10:18:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:18:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:18:27 --> Utf8 Class Initialized
INFO - 2025-05-08 10:18:27 --> URI Class Initialized
DEBUG - 2025-05-08 10:18:27 --> No URI present. Default controller set.
INFO - 2025-05-08 10:18:27 --> Router Class Initialized
INFO - 2025-05-08 10:18:27 --> Output Class Initialized
INFO - 2025-05-08 10:18:27 --> Security Class Initialized
DEBUG - 2025-05-08 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:18:27 --> Input Class Initialized
INFO - 2025-05-08 10:18:27 --> Language Class Initialized
INFO - 2025-05-08 10:18:27 --> Loader Class Initialized
INFO - 2025-05-08 10:18:27 --> Helper loaded: url_helper
INFO - 2025-05-08 10:18:27 --> Helper loaded: string_helper
INFO - 2025-05-08 10:18:27 --> Helper loaded: form_helper
INFO - 2025-05-08 10:18:27 --> Helper loaded: file_helper
INFO - 2025-05-08 10:18:27 --> Helper loaded: html_helper
INFO - 2025-05-08 10:18:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 10:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 10:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 10:18:27 --> Controller Class Initialized
INFO - 2025-05-08 10:18:27 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 10:18:27 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 10:18:27 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 10:18:27 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 10:18:27 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 10:18:27 --> Final output sent to browser
DEBUG - 2025-05-08 10:18:27 --> Total execution time: 0.0557
INFO - 2025-05-08 10:18:27 --> Config Class Initialized
INFO - 2025-05-08 10:18:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:18:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:18:27 --> Utf8 Class Initialized
INFO - 2025-05-08 10:18:27 --> URI Class Initialized
INFO - 2025-05-08 10:18:27 --> Router Class Initialized
INFO - 2025-05-08 10:18:27 --> Output Class Initialized
INFO - 2025-05-08 10:18:27 --> Security Class Initialized
DEBUG - 2025-05-08 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:18:27 --> Input Class Initialized
INFO - 2025-05-08 10:18:27 --> Language Class Initialized
ERROR - 2025-05-08 10:18:27 --> 404 Page Not Found: Faviconpng/index
INFO - 2025-05-08 10:28:46 --> Config Class Initialized
INFO - 2025-05-08 10:28:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:28:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:28:46 --> Utf8 Class Initialized
INFO - 2025-05-08 10:28:46 --> URI Class Initialized
DEBUG - 2025-05-08 10:28:46 --> No URI present. Default controller set.
INFO - 2025-05-08 10:28:46 --> Router Class Initialized
INFO - 2025-05-08 10:28:46 --> Output Class Initialized
INFO - 2025-05-08 10:28:46 --> Security Class Initialized
DEBUG - 2025-05-08 10:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:28:46 --> Input Class Initialized
INFO - 2025-05-08 10:28:46 --> Language Class Initialized
INFO - 2025-05-08 10:28:46 --> Loader Class Initialized
INFO - 2025-05-08 10:28:46 --> Helper loaded: url_helper
INFO - 2025-05-08 10:28:46 --> Helper loaded: string_helper
INFO - 2025-05-08 10:28:46 --> Helper loaded: form_helper
INFO - 2025-05-08 10:28:46 --> Helper loaded: file_helper
INFO - 2025-05-08 10:28:46 --> Helper loaded: html_helper
INFO - 2025-05-08 10:28:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 10:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 10:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 10:28:46 --> Controller Class Initialized
INFO - 2025-05-08 10:28:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 10:28:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 10:28:46 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 10:28:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 10:28:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 10:28:46 --> Final output sent to browser
DEBUG - 2025-05-08 10:28:46 --> Total execution time: 0.0394
INFO - 2025-05-08 10:28:46 --> Config Class Initialized
INFO - 2025-05-08 10:28:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:28:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:28:46 --> Utf8 Class Initialized
INFO - 2025-05-08 10:28:46 --> URI Class Initialized
INFO - 2025-05-08 10:28:46 --> Router Class Initialized
INFO - 2025-05-08 10:28:46 --> Output Class Initialized
INFO - 2025-05-08 10:28:46 --> Security Class Initialized
DEBUG - 2025-05-08 10:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:28:46 --> Input Class Initialized
INFO - 2025-05-08 10:28:46 --> Language Class Initialized
ERROR - 2025-05-08 10:28:46 --> 404 Page Not Found: Faviconpng/index
INFO - 2025-05-08 10:30:31 --> Config Class Initialized
INFO - 2025-05-08 10:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:30:31 --> Utf8 Class Initialized
INFO - 2025-05-08 10:30:31 --> URI Class Initialized
DEBUG - 2025-05-08 10:30:31 --> No URI present. Default controller set.
INFO - 2025-05-08 10:30:31 --> Router Class Initialized
INFO - 2025-05-08 10:30:31 --> Output Class Initialized
INFO - 2025-05-08 10:30:31 --> Security Class Initialized
DEBUG - 2025-05-08 10:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:30:31 --> Input Class Initialized
INFO - 2025-05-08 10:30:31 --> Language Class Initialized
INFO - 2025-05-08 10:30:31 --> Loader Class Initialized
INFO - 2025-05-08 10:30:31 --> Helper loaded: url_helper
INFO - 2025-05-08 10:30:31 --> Helper loaded: string_helper
INFO - 2025-05-08 10:30:31 --> Helper loaded: form_helper
INFO - 2025-05-08 10:30:31 --> Helper loaded: file_helper
INFO - 2025-05-08 10:30:31 --> Helper loaded: html_helper
INFO - 2025-05-08 10:30:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 10:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 10:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 10:30:31 --> Controller Class Initialized
INFO - 2025-05-08 10:30:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 10:30:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 10:30:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 10:30:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 10:30:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 10:30:31 --> Final output sent to browser
DEBUG - 2025-05-08 10:30:31 --> Total execution time: 0.0299
INFO - 2025-05-08 10:30:31 --> Config Class Initialized
INFO - 2025-05-08 10:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 10:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 10:30:31 --> Utf8 Class Initialized
INFO - 2025-05-08 10:30:31 --> URI Class Initialized
INFO - 2025-05-08 10:30:31 --> Router Class Initialized
INFO - 2025-05-08 10:30:31 --> Output Class Initialized
INFO - 2025-05-08 10:30:31 --> Security Class Initialized
DEBUG - 2025-05-08 10:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 10:30:31 --> Input Class Initialized
INFO - 2025-05-08 10:30:31 --> Language Class Initialized
ERROR - 2025-05-08 10:30:31 --> 404 Page Not Found: Faviconpng/index
INFO - 2025-05-08 11:42:28 --> Config Class Initialized
INFO - 2025-05-08 11:42:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 11:42:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 11:42:28 --> Utf8 Class Initialized
INFO - 2025-05-08 11:42:28 --> URI Class Initialized
DEBUG - 2025-05-08 11:42:28 --> No URI present. Default controller set.
INFO - 2025-05-08 11:42:28 --> Router Class Initialized
INFO - 2025-05-08 11:42:28 --> Output Class Initialized
INFO - 2025-05-08 11:42:28 --> Security Class Initialized
DEBUG - 2025-05-08 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 11:42:28 --> Input Class Initialized
INFO - 2025-05-08 11:42:28 --> Language Class Initialized
INFO - 2025-05-08 11:42:28 --> Loader Class Initialized
INFO - 2025-05-08 11:42:28 --> Helper loaded: url_helper
INFO - 2025-05-08 11:42:28 --> Helper loaded: string_helper
INFO - 2025-05-08 11:42:28 --> Helper loaded: form_helper
INFO - 2025-05-08 11:42:28 --> Helper loaded: file_helper
INFO - 2025-05-08 11:42:28 --> Helper loaded: html_helper
INFO - 2025-05-08 11:42:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 11:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 11:42:28 --> Controller Class Initialized
INFO - 2025-05-08 11:42:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 11:42:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 11:42:28 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 11:42:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 11:42:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 11:42:28 --> Final output sent to browser
DEBUG - 2025-05-08 11:42:28 --> Total execution time: 0.0631
INFO - 2025-05-08 11:42:32 --> Config Class Initialized
INFO - 2025-05-08 11:42:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 11:42:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 11:42:32 --> Utf8 Class Initialized
INFO - 2025-05-08 11:42:32 --> URI Class Initialized
DEBUG - 2025-05-08 11:42:32 --> No URI present. Default controller set.
INFO - 2025-05-08 11:42:32 --> Router Class Initialized
INFO - 2025-05-08 11:42:32 --> Output Class Initialized
INFO - 2025-05-08 11:42:32 --> Security Class Initialized
DEBUG - 2025-05-08 11:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 11:42:32 --> Input Class Initialized
INFO - 2025-05-08 11:42:32 --> Language Class Initialized
INFO - 2025-05-08 11:42:32 --> Loader Class Initialized
INFO - 2025-05-08 11:42:32 --> Helper loaded: url_helper
INFO - 2025-05-08 11:42:32 --> Helper loaded: string_helper
INFO - 2025-05-08 11:42:32 --> Helper loaded: form_helper
INFO - 2025-05-08 11:42:32 --> Helper loaded: file_helper
INFO - 2025-05-08 11:42:32 --> Helper loaded: html_helper
INFO - 2025-05-08 11:42:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 11:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 11:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 11:42:32 --> Controller Class Initialized
INFO - 2025-05-08 11:42:32 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 11:42:32 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 11:42:32 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 11:42:32 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 11:42:32 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 11:42:32 --> Final output sent to browser
DEBUG - 2025-05-08 11:42:32 --> Total execution time: 0.0028
INFO - 2025-05-08 12:11:00 --> Config Class Initialized
INFO - 2025-05-08 12:11:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:00 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:00 --> URI Class Initialized
DEBUG - 2025-05-08 12:11:00 --> No URI present. Default controller set.
INFO - 2025-05-08 12:11:00 --> Router Class Initialized
INFO - 2025-05-08 12:11:00 --> Output Class Initialized
INFO - 2025-05-08 12:11:00 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:00 --> Input Class Initialized
INFO - 2025-05-08 12:11:00 --> Language Class Initialized
INFO - 2025-05-08 12:11:00 --> Loader Class Initialized
INFO - 2025-05-08 12:11:00 --> Helper loaded: url_helper
INFO - 2025-05-08 12:11:00 --> Helper loaded: string_helper
INFO - 2025-05-08 12:11:00 --> Helper loaded: form_helper
INFO - 2025-05-08 12:11:00 --> Helper loaded: file_helper
INFO - 2025-05-08 12:11:00 --> Helper loaded: html_helper
INFO - 2025-05-08 12:11:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:11:00 --> Controller Class Initialized
INFO - 2025-05-08 12:11:00 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:11:00 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:11:00 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:11:00 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:11:00 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:11:00 --> Final output sent to browser
DEBUG - 2025-05-08 12:11:00 --> Total execution time: 0.0305
INFO - 2025-05-08 12:11:07 --> Config Class Initialized
INFO - 2025-05-08 12:11:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:07 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:07 --> URI Class Initialized
DEBUG - 2025-05-08 12:11:07 --> No URI present. Default controller set.
INFO - 2025-05-08 12:11:07 --> Router Class Initialized
INFO - 2025-05-08 12:11:07 --> Output Class Initialized
INFO - 2025-05-08 12:11:07 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:07 --> Input Class Initialized
INFO - 2025-05-08 12:11:07 --> Language Class Initialized
INFO - 2025-05-08 12:11:07 --> Loader Class Initialized
INFO - 2025-05-08 12:11:07 --> Helper loaded: url_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: string_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: form_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: file_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: html_helper
INFO - 2025-05-08 12:11:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:11:07 --> Controller Class Initialized
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:11:07 --> Final output sent to browser
DEBUG - 2025-05-08 12:11:07 --> Total execution time: 0.0042
INFO - 2025-05-08 12:11:07 --> Config Class Initialized
INFO - 2025-05-08 12:11:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:07 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:07 --> URI Class Initialized
DEBUG - 2025-05-08 12:11:07 --> No URI present. Default controller set.
INFO - 2025-05-08 12:11:07 --> Router Class Initialized
INFO - 2025-05-08 12:11:07 --> Output Class Initialized
INFO - 2025-05-08 12:11:07 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:07 --> Input Class Initialized
INFO - 2025-05-08 12:11:07 --> Language Class Initialized
INFO - 2025-05-08 12:11:07 --> Loader Class Initialized
INFO - 2025-05-08 12:11:07 --> Helper loaded: url_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: string_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: form_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: file_helper
INFO - 2025-05-08 12:11:07 --> Helper loaded: html_helper
INFO - 2025-05-08 12:11:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:11:07 --> Controller Class Initialized
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:11:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:11:07 --> Final output sent to browser
DEBUG - 2025-05-08 12:11:07 --> Total execution time: 0.0046
INFO - 2025-05-08 12:11:13 --> Config Class Initialized
INFO - 2025-05-08 12:11:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:13 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:13 --> URI Class Initialized
INFO - 2025-05-08 12:11:13 --> Router Class Initialized
INFO - 2025-05-08 12:11:13 --> Output Class Initialized
INFO - 2025-05-08 12:11:13 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:13 --> Input Class Initialized
INFO - 2025-05-08 12:11:13 --> Language Class Initialized
INFO - 2025-05-08 12:11:13 --> Loader Class Initialized
INFO - 2025-05-08 12:11:13 --> Helper loaded: url_helper
INFO - 2025-05-08 12:11:13 --> Helper loaded: string_helper
INFO - 2025-05-08 12:11:13 --> Helper loaded: form_helper
INFO - 2025-05-08 12:11:13 --> Helper loaded: file_helper
INFO - 2025-05-08 12:11:13 --> Helper loaded: html_helper
INFO - 2025-05-08 12:11:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:11:13 --> Controller Class Initialized
INFO - 2025-05-08 12:11:13 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:11:15 --> Config Class Initialized
INFO - 2025-05-08 12:11:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:15 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:15 --> URI Class Initialized
INFO - 2025-05-08 12:11:15 --> Router Class Initialized
INFO - 2025-05-08 12:11:15 --> Output Class Initialized
INFO - 2025-05-08 12:11:15 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:15 --> Input Class Initialized
INFO - 2025-05-08 12:11:15 --> Language Class Initialized
INFO - 2025-05-08 12:11:15 --> Loader Class Initialized
INFO - 2025-05-08 12:11:15 --> Helper loaded: url_helper
INFO - 2025-05-08 12:11:15 --> Helper loaded: string_helper
INFO - 2025-05-08 12:11:15 --> Helper loaded: form_helper
INFO - 2025-05-08 12:11:15 --> Helper loaded: file_helper
INFO - 2025-05-08 12:11:15 --> Helper loaded: html_helper
INFO - 2025-05-08 12:11:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:11:15 --> Controller Class Initialized
INFO - 2025-05-08 12:11:37 --> Config Class Initialized
INFO - 2025-05-08 12:11:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:37 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:37 --> URI Class Initialized
INFO - 2025-05-08 12:11:37 --> Router Class Initialized
INFO - 2025-05-08 12:11:37 --> Output Class Initialized
INFO - 2025-05-08 12:11:37 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:37 --> Input Class Initialized
INFO - 2025-05-08 12:11:37 --> Language Class Initialized
ERROR - 2025-05-08 12:11:37 --> 404 Page Not Found: Adstxt/index
INFO - 2025-05-08 12:11:37 --> Config Class Initialized
INFO - 2025-05-08 12:11:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:37 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:37 --> URI Class Initialized
INFO - 2025-05-08 12:11:37 --> Router Class Initialized
INFO - 2025-05-08 12:11:37 --> Output Class Initialized
INFO - 2025-05-08 12:11:37 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:37 --> Input Class Initialized
INFO - 2025-05-08 12:11:37 --> Language Class Initialized
ERROR - 2025-05-08 12:11:37 --> 404 Page Not Found: App-adstxt/index
INFO - 2025-05-08 12:11:38 --> Config Class Initialized
INFO - 2025-05-08 12:11:38 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:38 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:38 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:38 --> URI Class Initialized
INFO - 2025-05-08 12:11:38 --> Router Class Initialized
INFO - 2025-05-08 12:11:38 --> Output Class Initialized
INFO - 2025-05-08 12:11:38 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:38 --> Input Class Initialized
INFO - 2025-05-08 12:11:38 --> Language Class Initialized
ERROR - 2025-05-08 12:11:38 --> 404 Page Not Found: Sellersjson/index
INFO - 2025-05-08 12:11:41 --> Config Class Initialized
INFO - 2025-05-08 12:11:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:41 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:41 --> URI Class Initialized
INFO - 2025-05-08 12:11:41 --> Router Class Initialized
INFO - 2025-05-08 12:11:41 --> Output Class Initialized
INFO - 2025-05-08 12:11:41 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:41 --> Input Class Initialized
INFO - 2025-05-08 12:11:41 --> Language Class Initialized
ERROR - 2025-05-08 12:11:41 --> 404 Page Not Found: Adstxt/index
INFO - 2025-05-08 12:11:41 --> Config Class Initialized
INFO - 2025-05-08 12:11:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:41 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:41 --> URI Class Initialized
INFO - 2025-05-08 12:11:41 --> Router Class Initialized
INFO - 2025-05-08 12:11:41 --> Output Class Initialized
INFO - 2025-05-08 12:11:41 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:41 --> Input Class Initialized
INFO - 2025-05-08 12:11:41 --> Language Class Initialized
ERROR - 2025-05-08 12:11:41 --> 404 Page Not Found: App-adstxt/index
INFO - 2025-05-08 12:11:42 --> Config Class Initialized
INFO - 2025-05-08 12:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:11:42 --> Utf8 Class Initialized
INFO - 2025-05-08 12:11:42 --> URI Class Initialized
INFO - 2025-05-08 12:11:42 --> Router Class Initialized
INFO - 2025-05-08 12:11:42 --> Output Class Initialized
INFO - 2025-05-08 12:11:42 --> Security Class Initialized
DEBUG - 2025-05-08 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:11:42 --> Input Class Initialized
INFO - 2025-05-08 12:11:42 --> Language Class Initialized
ERROR - 2025-05-08 12:11:42 --> 404 Page Not Found: Sellersjson/index
INFO - 2025-05-08 12:31:45 --> Config Class Initialized
INFO - 2025-05-08 12:31:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:31:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:31:45 --> Utf8 Class Initialized
INFO - 2025-05-08 12:31:45 --> URI Class Initialized
DEBUG - 2025-05-08 12:31:45 --> No URI present. Default controller set.
INFO - 2025-05-08 12:31:45 --> Router Class Initialized
INFO - 2025-05-08 12:31:45 --> Output Class Initialized
INFO - 2025-05-08 12:31:45 --> Security Class Initialized
DEBUG - 2025-05-08 12:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:31:45 --> Input Class Initialized
INFO - 2025-05-08 12:31:45 --> Language Class Initialized
INFO - 2025-05-08 12:31:45 --> Loader Class Initialized
INFO - 2025-05-08 12:31:45 --> Helper loaded: url_helper
INFO - 2025-05-08 12:31:45 --> Helper loaded: string_helper
INFO - 2025-05-08 12:31:45 --> Helper loaded: form_helper
INFO - 2025-05-08 12:31:45 --> Helper loaded: file_helper
INFO - 2025-05-08 12:31:45 --> Helper loaded: html_helper
INFO - 2025-05-08 12:31:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:31:45 --> Controller Class Initialized
INFO - 2025-05-08 12:31:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:31:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:31:45 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:31:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:31:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:31:45 --> Final output sent to browser
DEBUG - 2025-05-08 12:31:45 --> Total execution time: 0.0292
INFO - 2025-05-08 12:32:33 --> Config Class Initialized
INFO - 2025-05-08 12:32:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:32:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:32:33 --> Utf8 Class Initialized
INFO - 2025-05-08 12:32:33 --> URI Class Initialized
DEBUG - 2025-05-08 12:32:33 --> No URI present. Default controller set.
INFO - 2025-05-08 12:32:33 --> Router Class Initialized
INFO - 2025-05-08 12:32:33 --> Output Class Initialized
INFO - 2025-05-08 12:32:33 --> Security Class Initialized
DEBUG - 2025-05-08 12:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:32:33 --> Input Class Initialized
INFO - 2025-05-08 12:32:33 --> Language Class Initialized
INFO - 2025-05-08 12:32:33 --> Loader Class Initialized
INFO - 2025-05-08 12:32:33 --> Helper loaded: url_helper
INFO - 2025-05-08 12:32:33 --> Helper loaded: string_helper
INFO - 2025-05-08 12:32:33 --> Helper loaded: form_helper
INFO - 2025-05-08 12:32:33 --> Helper loaded: file_helper
INFO - 2025-05-08 12:32:33 --> Helper loaded: html_helper
INFO - 2025-05-08 12:32:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:32:33 --> Controller Class Initialized
INFO - 2025-05-08 12:32:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:32:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:32:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:32:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:32:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:32:33 --> Final output sent to browser
DEBUG - 2025-05-08 12:32:33 --> Total execution time: 0.0283
INFO - 2025-05-08 12:50:03 --> Config Class Initialized
INFO - 2025-05-08 12:50:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:50:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:50:03 --> Utf8 Class Initialized
INFO - 2025-05-08 12:50:03 --> URI Class Initialized
DEBUG - 2025-05-08 12:50:03 --> No URI present. Default controller set.
INFO - 2025-05-08 12:50:03 --> Router Class Initialized
INFO - 2025-05-08 12:50:03 --> Output Class Initialized
INFO - 2025-05-08 12:50:03 --> Security Class Initialized
DEBUG - 2025-05-08 12:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:50:03 --> Input Class Initialized
INFO - 2025-05-08 12:50:03 --> Language Class Initialized
INFO - 2025-05-08 12:50:03 --> Loader Class Initialized
INFO - 2025-05-08 12:50:03 --> Helper loaded: url_helper
INFO - 2025-05-08 12:50:03 --> Helper loaded: string_helper
INFO - 2025-05-08 12:50:03 --> Helper loaded: form_helper
INFO - 2025-05-08 12:50:03 --> Helper loaded: file_helper
INFO - 2025-05-08 12:50:03 --> Helper loaded: html_helper
INFO - 2025-05-08 12:50:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:50:03 --> Controller Class Initialized
INFO - 2025-05-08 12:50:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:50:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:50:03 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:50:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:50:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:50:03 --> Final output sent to browser
DEBUG - 2025-05-08 12:50:03 --> Total execution time: 0.0295
INFO - 2025-05-08 12:50:07 --> Config Class Initialized
INFO - 2025-05-08 12:50:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:50:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:50:07 --> Utf8 Class Initialized
INFO - 2025-05-08 12:50:07 --> URI Class Initialized
INFO - 2025-05-08 12:50:07 --> Router Class Initialized
INFO - 2025-05-08 12:50:07 --> Output Class Initialized
INFO - 2025-05-08 12:50:07 --> Security Class Initialized
DEBUG - 2025-05-08 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:50:07 --> Input Class Initialized
INFO - 2025-05-08 12:50:07 --> Language Class Initialized
INFO - 2025-05-08 12:50:07 --> Loader Class Initialized
INFO - 2025-05-08 12:50:07 --> Helper loaded: url_helper
INFO - 2025-05-08 12:50:07 --> Helper loaded: string_helper
INFO - 2025-05-08 12:50:07 --> Helper loaded: form_helper
INFO - 2025-05-08 12:50:07 --> Helper loaded: file_helper
INFO - 2025-05-08 12:50:07 --> Helper loaded: html_helper
INFO - 2025-05-08 12:50:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:50:07 --> Controller Class Initialized
INFO - 2025-05-08 12:50:07 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:11 --> Config Class Initialized
INFO - 2025-05-08 12:55:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:11 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:11 --> URI Class Initialized
INFO - 2025-05-08 12:55:11 --> Router Class Initialized
INFO - 2025-05-08 12:55:11 --> Output Class Initialized
INFO - 2025-05-08 12:55:11 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:11 --> Input Class Initialized
INFO - 2025-05-08 12:55:11 --> Language Class Initialized
INFO - 2025-05-08 12:55:11 --> Loader Class Initialized
INFO - 2025-05-08 12:55:11 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:11 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:11 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:11 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:11 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:11 --> Controller Class Initialized
INFO - 2025-05-08 12:55:11 --> Model "UserModel" initialized
INFO - 2025-05-08 12:55:12 --> Config Class Initialized
INFO - 2025-05-08 12:55:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:12 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:12 --> URI Class Initialized
DEBUG - 2025-05-08 12:55:12 --> No URI present. Default controller set.
INFO - 2025-05-08 12:55:12 --> Router Class Initialized
INFO - 2025-05-08 12:55:12 --> Output Class Initialized
INFO - 2025-05-08 12:55:12 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:12 --> Input Class Initialized
INFO - 2025-05-08 12:55:12 --> Language Class Initialized
INFO - 2025-05-08 12:55:12 --> Loader Class Initialized
INFO - 2025-05-08 12:55:12 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:12 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:12 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:12 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:12 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:12 --> Controller Class Initialized
INFO - 2025-05-08 12:55:12 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:55:12 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:55:12 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 12:55:12 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:55:12 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:55:12 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:12 --> Total execution time: 0.0048
INFO - 2025-05-08 12:55:14 --> Config Class Initialized
INFO - 2025-05-08 12:55:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:14 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:14 --> URI Class Initialized
INFO - 2025-05-08 12:55:14 --> Router Class Initialized
INFO - 2025-05-08 12:55:14 --> Output Class Initialized
INFO - 2025-05-08 12:55:14 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:14 --> Input Class Initialized
INFO - 2025-05-08 12:55:14 --> Language Class Initialized
INFO - 2025-05-08 12:55:14 --> Loader Class Initialized
INFO - 2025-05-08 12:55:14 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:14 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:14 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:14 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:14 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:14 --> Controller Class Initialized
INFO - 2025-05-08 12:55:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:15 --> Config Class Initialized
INFO - 2025-05-08 12:55:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:15 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:15 --> URI Class Initialized
INFO - 2025-05-08 12:55:15 --> Router Class Initialized
INFO - 2025-05-08 12:55:15 --> Output Class Initialized
INFO - 2025-05-08 12:55:15 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:15 --> Input Class Initialized
INFO - 2025-05-08 12:55:15 --> Language Class Initialized
INFO - 2025-05-08 12:55:15 --> Loader Class Initialized
INFO - 2025-05-08 12:55:15 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:15 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:15 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:15 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:15 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:15 --> Controller Class Initialized
INFO - 2025-05-08 12:55:15 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:55:15 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:55:15 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 12:55:15 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:55:15 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:55:15 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:15 --> Total execution time: 0.0052
INFO - 2025-05-08 12:55:17 --> Config Class Initialized
INFO - 2025-05-08 12:55:17 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:17 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:17 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:17 --> URI Class Initialized
INFO - 2025-05-08 12:55:17 --> Router Class Initialized
INFO - 2025-05-08 12:55:17 --> Output Class Initialized
INFO - 2025-05-08 12:55:17 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:17 --> Input Class Initialized
INFO - 2025-05-08 12:55:17 --> Language Class Initialized
INFO - 2025-05-08 12:55:17 --> Loader Class Initialized
INFO - 2025-05-08 12:55:17 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:17 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:17 --> Controller Class Initialized
INFO - 2025-05-08 12:55:17 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:17 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:17 --> Total execution time: 0.0048
INFO - 2025-05-08 12:55:17 --> Config Class Initialized
INFO - 2025-05-08 12:55:17 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:17 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:17 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:17 --> URI Class Initialized
INFO - 2025-05-08 12:55:17 --> Router Class Initialized
INFO - 2025-05-08 12:55:17 --> Output Class Initialized
INFO - 2025-05-08 12:55:17 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:17 --> Input Class Initialized
INFO - 2025-05-08 12:55:17 --> Language Class Initialized
INFO - 2025-05-08 12:55:17 --> Loader Class Initialized
INFO - 2025-05-08 12:55:17 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:17 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:17 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:17 --> Controller Class Initialized
INFO - 2025-05-08 12:55:17 --> Model "CompanyModel" initialized
INFO - 2025-05-08 12:55:17 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 12:55:17 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:18 --> Config Class Initialized
INFO - 2025-05-08 12:55:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:18 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:18 --> URI Class Initialized
INFO - 2025-05-08 12:55:18 --> Router Class Initialized
INFO - 2025-05-08 12:55:18 --> Output Class Initialized
INFO - 2025-05-08 12:55:18 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:18 --> Input Class Initialized
INFO - 2025-05-08 12:55:18 --> Language Class Initialized
INFO - 2025-05-08 12:55:18 --> Loader Class Initialized
INFO - 2025-05-08 12:55:18 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:18 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:18 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:18 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:18 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:18 --> Controller Class Initialized
INFO - 2025-05-08 12:55:18 --> Model "UserModel" initialized
INFO - 2025-05-08 12:55:18 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:18 --> Total execution time: 0.0054
INFO - 2025-05-08 12:55:19 --> Config Class Initialized
INFO - 2025-05-08 12:55:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:19 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:19 --> URI Class Initialized
INFO - 2025-05-08 12:55:19 --> Router Class Initialized
INFO - 2025-05-08 12:55:19 --> Output Class Initialized
INFO - 2025-05-08 12:55:19 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:19 --> Input Class Initialized
INFO - 2025-05-08 12:55:19 --> Language Class Initialized
INFO - 2025-05-08 12:55:19 --> Loader Class Initialized
INFO - 2025-05-08 12:55:19 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:19 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:19 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:19 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:19 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:19 --> Controller Class Initialized
INFO - 2025-05-08 12:55:19 --> Model "CompanyModel" initialized
INFO - 2025-05-08 12:55:19 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:55:19 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:55:19 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 12:55:19 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:55:19 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:55:19 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:19 --> Total execution time: 0.0042
INFO - 2025-05-08 12:55:20 --> Config Class Initialized
INFO - 2025-05-08 12:55:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:20 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:20 --> URI Class Initialized
INFO - 2025-05-08 12:55:20 --> Router Class Initialized
INFO - 2025-05-08 12:55:20 --> Output Class Initialized
INFO - 2025-05-08 12:55:20 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:20 --> Input Class Initialized
INFO - 2025-05-08 12:55:20 --> Language Class Initialized
INFO - 2025-05-08 12:55:20 --> Loader Class Initialized
INFO - 2025-05-08 12:55:20 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:20 --> Controller Class Initialized
INFO - 2025-05-08 12:55:20 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:20 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:20 --> Total execution time: 0.0035
INFO - 2025-05-08 12:55:20 --> Config Class Initialized
INFO - 2025-05-08 12:55:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:20 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:20 --> URI Class Initialized
INFO - 2025-05-08 12:55:20 --> Router Class Initialized
INFO - 2025-05-08 12:55:20 --> Output Class Initialized
INFO - 2025-05-08 12:55:20 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:20 --> Input Class Initialized
INFO - 2025-05-08 12:55:20 --> Language Class Initialized
INFO - 2025-05-08 12:55:20 --> Loader Class Initialized
INFO - 2025-05-08 12:55:20 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:20 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:20 --> Controller Class Initialized
INFO - 2025-05-08 12:55:20 --> Model "UserModel" initialized
INFO - 2025-05-08 12:55:20 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:20 --> Total execution time: 0.0029
INFO - 2025-05-08 12:55:21 --> Config Class Initialized
INFO - 2025-05-08 12:55:21 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:21 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:21 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:21 --> URI Class Initialized
INFO - 2025-05-08 12:55:21 --> Router Class Initialized
INFO - 2025-05-08 12:55:21 --> Output Class Initialized
INFO - 2025-05-08 12:55:21 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:21 --> Input Class Initialized
INFO - 2025-05-08 12:55:21 --> Language Class Initialized
INFO - 2025-05-08 12:55:21 --> Loader Class Initialized
INFO - 2025-05-08 12:55:21 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:21 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:21 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:21 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:21 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:21 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:21 --> Controller Class Initialized
INFO - 2025-05-08 12:55:21 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:21 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:21 --> Total execution time: 0.0027
INFO - 2025-05-08 12:55:23 --> Config Class Initialized
INFO - 2025-05-08 12:55:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:23 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:23 --> URI Class Initialized
INFO - 2025-05-08 12:55:23 --> Router Class Initialized
INFO - 2025-05-08 12:55:23 --> Output Class Initialized
INFO - 2025-05-08 12:55:23 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:23 --> Input Class Initialized
INFO - 2025-05-08 12:55:23 --> Language Class Initialized
INFO - 2025-05-08 12:55:23 --> Loader Class Initialized
INFO - 2025-05-08 12:55:23 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:23 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:23 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:23 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:23 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:23 --> Controller Class Initialized
INFO - 2025-05-08 12:55:23 --> Model "CompanyModel" initialized
INFO - 2025-05-08 12:55:23 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:55:23 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:55:23 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 12:55:23 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:55:23 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:55:23 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:23 --> Total execution time: 0.0032
INFO - 2025-05-08 12:55:26 --> Config Class Initialized
INFO - 2025-05-08 12:55:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:26 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:26 --> URI Class Initialized
INFO - 2025-05-08 12:55:26 --> Router Class Initialized
INFO - 2025-05-08 12:55:26 --> Output Class Initialized
INFO - 2025-05-08 12:55:26 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:26 --> Input Class Initialized
INFO - 2025-05-08 12:55:26 --> Language Class Initialized
INFO - 2025-05-08 12:55:26 --> Loader Class Initialized
INFO - 2025-05-08 12:55:26 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:26 --> Controller Class Initialized
INFO - 2025-05-08 12:55:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:26 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:26 --> Total execution time: 0.0028
INFO - 2025-05-08 12:55:26 --> Config Class Initialized
INFO - 2025-05-08 12:55:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:26 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:26 --> URI Class Initialized
INFO - 2025-05-08 12:55:26 --> Router Class Initialized
INFO - 2025-05-08 12:55:26 --> Output Class Initialized
INFO - 2025-05-08 12:55:26 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:26 --> Input Class Initialized
INFO - 2025-05-08 12:55:26 --> Language Class Initialized
INFO - 2025-05-08 12:55:26 --> Loader Class Initialized
INFO - 2025-05-08 12:55:26 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:26 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:26 --> Controller Class Initialized
INFO - 2025-05-08 12:55:26 --> Model "UserModel" initialized
INFO - 2025-05-08 12:55:26 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:26 --> Total execution time: 0.0035
INFO - 2025-05-08 12:55:27 --> Config Class Initialized
INFO - 2025-05-08 12:55:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:55:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:55:27 --> Utf8 Class Initialized
INFO - 2025-05-08 12:55:27 --> URI Class Initialized
INFO - 2025-05-08 12:55:27 --> Router Class Initialized
INFO - 2025-05-08 12:55:27 --> Output Class Initialized
INFO - 2025-05-08 12:55:27 --> Security Class Initialized
DEBUG - 2025-05-08 12:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:55:27 --> Input Class Initialized
INFO - 2025-05-08 12:55:27 --> Language Class Initialized
INFO - 2025-05-08 12:55:27 --> Loader Class Initialized
INFO - 2025-05-08 12:55:27 --> Helper loaded: url_helper
INFO - 2025-05-08 12:55:27 --> Helper loaded: string_helper
INFO - 2025-05-08 12:55:27 --> Helper loaded: form_helper
INFO - 2025-05-08 12:55:27 --> Helper loaded: file_helper
INFO - 2025-05-08 12:55:27 --> Helper loaded: html_helper
INFO - 2025-05-08 12:55:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:55:27 --> Controller Class Initialized
INFO - 2025-05-08 12:55:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:55:27 --> Final output sent to browser
DEBUG - 2025-05-08 12:55:27 --> Total execution time: 0.0024
INFO - 2025-05-08 12:57:01 --> Config Class Initialized
INFO - 2025-05-08 12:57:01 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:01 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:01 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:01 --> URI Class Initialized
INFO - 2025-05-08 12:57:01 --> Router Class Initialized
INFO - 2025-05-08 12:57:01 --> Output Class Initialized
INFO - 2025-05-08 12:57:01 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:01 --> Input Class Initialized
INFO - 2025-05-08 12:57:01 --> Language Class Initialized
INFO - 2025-05-08 12:57:01 --> Loader Class Initialized
INFO - 2025-05-08 12:57:01 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:01 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:01 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:01 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:01 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:01 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:01 --> Controller Class Initialized
INFO - 2025-05-08 12:57:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:57:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:57:01 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 12:57:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:57:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:57:01 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:01 --> Total execution time: 0.0310
INFO - 2025-05-08 12:57:03 --> Config Class Initialized
INFO - 2025-05-08 12:57:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:03 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:03 --> URI Class Initialized
INFO - 2025-05-08 12:57:03 --> Router Class Initialized
INFO - 2025-05-08 12:57:03 --> Output Class Initialized
INFO - 2025-05-08 12:57:03 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:03 --> Input Class Initialized
INFO - 2025-05-08 12:57:03 --> Language Class Initialized
INFO - 2025-05-08 12:57:03 --> Loader Class Initialized
INFO - 2025-05-08 12:57:03 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:03 --> Controller Class Initialized
INFO - 2025-05-08 12:57:03 --> Model "CompanyModel" initialized
INFO - 2025-05-08 12:57:03 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 12:57:03 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:57:03 --> Config Class Initialized
INFO - 2025-05-08 12:57:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:03 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:03 --> URI Class Initialized
INFO - 2025-05-08 12:57:03 --> Router Class Initialized
INFO - 2025-05-08 12:57:03 --> Output Class Initialized
INFO - 2025-05-08 12:57:03 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:03 --> Input Class Initialized
INFO - 2025-05-08 12:57:03 --> Language Class Initialized
INFO - 2025-05-08 12:57:03 --> Loader Class Initialized
INFO - 2025-05-08 12:57:03 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:03 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:03 --> Controller Class Initialized
INFO - 2025-05-08 12:57:03 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:57:03 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:03 --> Total execution time: 0.0040
INFO - 2025-05-08 12:57:04 --> Config Class Initialized
INFO - 2025-05-08 12:57:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:04 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:04 --> URI Class Initialized
INFO - 2025-05-08 12:57:04 --> Router Class Initialized
INFO - 2025-05-08 12:57:04 --> Output Class Initialized
INFO - 2025-05-08 12:57:04 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:04 --> Input Class Initialized
INFO - 2025-05-08 12:57:04 --> Language Class Initialized
INFO - 2025-05-08 12:57:04 --> Loader Class Initialized
INFO - 2025-05-08 12:57:04 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:04 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:04 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:04 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:04 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:04 --> Controller Class Initialized
INFO - 2025-05-08 12:57:04 --> Model "UserModel" initialized
INFO - 2025-05-08 12:57:04 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:04 --> Total execution time: 0.0101
INFO - 2025-05-08 12:57:05 --> Config Class Initialized
INFO - 2025-05-08 12:57:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:05 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:05 --> URI Class Initialized
INFO - 2025-05-08 12:57:05 --> Router Class Initialized
INFO - 2025-05-08 12:57:05 --> Output Class Initialized
INFO - 2025-05-08 12:57:05 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:05 --> Input Class Initialized
INFO - 2025-05-08 12:57:05 --> Language Class Initialized
INFO - 2025-05-08 12:57:05 --> Loader Class Initialized
INFO - 2025-05-08 12:57:05 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:05 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:05 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:05 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:05 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:05 --> Controller Class Initialized
INFO - 2025-05-08 12:57:05 --> Model "CompanyModel" initialized
INFO - 2025-05-08 12:57:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:57:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:57:05 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 12:57:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:57:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:57:05 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:05 --> Total execution time: 0.0030
INFO - 2025-05-08 12:57:06 --> Config Class Initialized
INFO - 2025-05-08 12:57:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:06 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:06 --> URI Class Initialized
INFO - 2025-05-08 12:57:06 --> Router Class Initialized
INFO - 2025-05-08 12:57:06 --> Output Class Initialized
INFO - 2025-05-08 12:57:06 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:06 --> Input Class Initialized
INFO - 2025-05-08 12:57:06 --> Language Class Initialized
INFO - 2025-05-08 12:57:06 --> Loader Class Initialized
INFO - 2025-05-08 12:57:06 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:06 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:06 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:06 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:06 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:06 --> Controller Class Initialized
INFO - 2025-05-08 12:57:06 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:57:06 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:06 --> Total execution time: 0.0032
INFO - 2025-05-08 12:57:09 --> Config Class Initialized
INFO - 2025-05-08 12:57:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:09 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:09 --> URI Class Initialized
INFO - 2025-05-08 12:57:09 --> Router Class Initialized
INFO - 2025-05-08 12:57:09 --> Output Class Initialized
INFO - 2025-05-08 12:57:09 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:09 --> Input Class Initialized
INFO - 2025-05-08 12:57:09 --> Language Class Initialized
INFO - 2025-05-08 12:57:09 --> Loader Class Initialized
INFO - 2025-05-08 12:57:09 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:09 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:09 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:09 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:09 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:09 --> Controller Class Initialized
INFO - 2025-05-08 12:57:09 --> Model "UserModel" initialized
INFO - 2025-05-08 12:57:09 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:09 --> Total execution time: 0.0026
INFO - 2025-05-08 12:57:10 --> Config Class Initialized
INFO - 2025-05-08 12:57:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:57:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:57:10 --> Utf8 Class Initialized
INFO - 2025-05-08 12:57:10 --> URI Class Initialized
INFO - 2025-05-08 12:57:10 --> Router Class Initialized
INFO - 2025-05-08 12:57:10 --> Output Class Initialized
INFO - 2025-05-08 12:57:10 --> Security Class Initialized
DEBUG - 2025-05-08 12:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:57:10 --> Input Class Initialized
INFO - 2025-05-08 12:57:10 --> Language Class Initialized
INFO - 2025-05-08 12:57:10 --> Loader Class Initialized
INFO - 2025-05-08 12:57:10 --> Helper loaded: url_helper
INFO - 2025-05-08 12:57:10 --> Helper loaded: string_helper
INFO - 2025-05-08 12:57:10 --> Helper loaded: form_helper
INFO - 2025-05-08 12:57:10 --> Helper loaded: file_helper
INFO - 2025-05-08 12:57:10 --> Helper loaded: html_helper
INFO - 2025-05-08 12:57:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:57:10 --> Controller Class Initialized
INFO - 2025-05-08 12:57:10 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:57:10 --> Final output sent to browser
DEBUG - 2025-05-08 12:57:10 --> Total execution time: 0.0023
INFO - 2025-05-08 12:58:16 --> Config Class Initialized
INFO - 2025-05-08 12:58:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:16 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:16 --> URI Class Initialized
INFO - 2025-05-08 12:58:16 --> Router Class Initialized
INFO - 2025-05-08 12:58:16 --> Output Class Initialized
INFO - 2025-05-08 12:58:16 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:16 --> Input Class Initialized
INFO - 2025-05-08 12:58:16 --> Language Class Initialized
INFO - 2025-05-08 12:58:16 --> Loader Class Initialized
INFO - 2025-05-08 12:58:16 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:16 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:16 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:16 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:16 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:16 --> Controller Class Initialized
INFO - 2025-05-08 12:58:16 --> Model "UploadModel" initialized
INFO - 2025-05-08 12:58:16 --> Final output sent to browser
DEBUG - 2025-05-08 12:58:16 --> Total execution time: 0.0473
INFO - 2025-05-08 12:58:17 --> Config Class Initialized
INFO - 2025-05-08 12:58:17 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:17 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:17 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:17 --> URI Class Initialized
INFO - 2025-05-08 12:58:17 --> Router Class Initialized
INFO - 2025-05-08 12:58:17 --> Output Class Initialized
INFO - 2025-05-08 12:58:17 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:17 --> Input Class Initialized
INFO - 2025-05-08 12:58:17 --> Language Class Initialized
INFO - 2025-05-08 12:58:17 --> Loader Class Initialized
INFO - 2025-05-08 12:58:17 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:17 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:17 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:17 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:17 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:17 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:17 --> Controller Class Initialized
INFO - 2025-05-08 12:58:17 --> Model "AuctionModel" initialized
ERROR - 2025-05-08 12:58:17 --> Severity: error --> Exception: Call to undefined function exec() /home/storagep/public_html/application/controllers/Auctions.php 2493
INFO - 2025-05-08 12:58:28 --> Config Class Initialized
INFO - 2025-05-08 12:58:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:28 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:28 --> URI Class Initialized
INFO - 2025-05-08 12:58:28 --> Router Class Initialized
INFO - 2025-05-08 12:58:28 --> Output Class Initialized
INFO - 2025-05-08 12:58:28 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:28 --> Input Class Initialized
INFO - 2025-05-08 12:58:28 --> Language Class Initialized
INFO - 2025-05-08 12:58:28 --> Loader Class Initialized
INFO - 2025-05-08 12:58:28 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:28 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:28 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:28 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:28 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:28 --> Controller Class Initialized
INFO - 2025-05-08 12:58:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:58:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:58:28 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 12:58:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:58:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:58:28 --> Final output sent to browser
DEBUG - 2025-05-08 12:58:28 --> Total execution time: 0.0032
INFO - 2025-05-08 12:58:30 --> Config Class Initialized
INFO - 2025-05-08 12:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:30 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:30 --> URI Class Initialized
INFO - 2025-05-08 12:58:30 --> Router Class Initialized
INFO - 2025-05-08 12:58:30 --> Output Class Initialized
INFO - 2025-05-08 12:58:30 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:30 --> Input Class Initialized
INFO - 2025-05-08 12:58:30 --> Language Class Initialized
INFO - 2025-05-08 12:58:30 --> Loader Class Initialized
INFO - 2025-05-08 12:58:30 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:30 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:30 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:30 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:30 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:30 --> Controller Class Initialized
INFO - 2025-05-08 12:58:30 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
INFO - 2025-05-08 12:58:31 --> Config Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 12:58:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> URI Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Router Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:31 --> Output Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:31 --> Input Class Initialized
INFO - 2025-05-08 12:58:31 --> Language Class Initialized
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:31 --> Loader Class Initialized
INFO - 2025-05-08 12:58:31 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:31 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
DEBUG - 2025-05-08 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:31 --> Controller Class Initialized
INFO - 2025-05-08 12:58:35 --> Config Class Initialized
INFO - 2025-05-08 12:58:35 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:35 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:35 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:35 --> URI Class Initialized
INFO - 2025-05-08 12:58:35 --> Router Class Initialized
INFO - 2025-05-08 12:58:35 --> Output Class Initialized
INFO - 2025-05-08 12:58:35 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:35 --> Input Class Initialized
INFO - 2025-05-08 12:58:35 --> Language Class Initialized
INFO - 2025-05-08 12:58:35 --> Loader Class Initialized
INFO - 2025-05-08 12:58:35 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:35 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:35 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:35 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:35 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:35 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:35 --> Controller Class Initialized
INFO - 2025-05-08 12:58:35 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 12:58:35 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 12:58:35 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 12:58:35 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 12:58:35 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 12:58:35 --> Final output sent to browser
DEBUG - 2025-05-08 12:58:35 --> Total execution time: 0.0031
INFO - 2025-05-08 12:58:38 --> Config Class Initialized
INFO - 2025-05-08 12:58:38 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:38 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:38 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:38 --> URI Class Initialized
INFO - 2025-05-08 12:58:38 --> Router Class Initialized
INFO - 2025-05-08 12:58:38 --> Output Class Initialized
INFO - 2025-05-08 12:58:38 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:38 --> Input Class Initialized
INFO - 2025-05-08 12:58:38 --> Language Class Initialized
INFO - 2025-05-08 12:58:38 --> Loader Class Initialized
INFO - 2025-05-08 12:58:38 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:38 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:38 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:38 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:38 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:38 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:38 --> Controller Class Initialized
INFO - 2025-05-08 12:58:38 --> Model "AuctionModel" initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Config Class Initialized
INFO - 2025-05-08 12:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 12:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> URI Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Router Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Output Class Initialized
INFO - 2025-05-08 12:58:40 --> Security Class Initialized
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 12:58:40 --> Input Class Initialized
INFO - 2025-05-08 12:58:40 --> Language Class Initialized
INFO - 2025-05-08 12:58:40 --> Loader Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 12:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 12:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 12:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 12:58:40 --> Controller Class Initialized
INFO - 2025-05-08 13:00:05 --> Config Class Initialized
INFO - 2025-05-08 13:00:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:05 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:05 --> URI Class Initialized
INFO - 2025-05-08 13:00:05 --> Router Class Initialized
INFO - 2025-05-08 13:00:05 --> Output Class Initialized
INFO - 2025-05-08 13:00:05 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:05 --> Input Class Initialized
INFO - 2025-05-08 13:00:05 --> Language Class Initialized
INFO - 2025-05-08 13:00:05 --> Loader Class Initialized
INFO - 2025-05-08 13:00:05 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:05 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:05 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:05 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:05 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:05 --> Controller Class Initialized
INFO - 2025-05-08 13:00:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:00:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:00:05 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 13:00:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:00:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:00:05 --> Final output sent to browser
DEBUG - 2025-05-08 13:00:05 --> Total execution time: 0.0339
INFO - 2025-05-08 13:00:09 --> Config Class Initialized
INFO - 2025-05-08 13:00:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:09 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:09 --> URI Class Initialized
INFO - 2025-05-08 13:00:09 --> Router Class Initialized
INFO - 2025-05-08 13:00:09 --> Output Class Initialized
INFO - 2025-05-08 13:00:09 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:09 --> Input Class Initialized
INFO - 2025-05-08 13:00:09 --> Language Class Initialized
INFO - 2025-05-08 13:00:09 --> Loader Class Initialized
INFO - 2025-05-08 13:00:09 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:09 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:09 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:09 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:09 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:09 --> Controller Class Initialized
INFO - 2025-05-08 13:00:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:00:10 --> Config Class Initialized
INFO - 2025-05-08 13:00:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:10 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:10 --> URI Class Initialized
INFO - 2025-05-08 13:00:10 --> Router Class Initialized
INFO - 2025-05-08 13:00:10 --> Output Class Initialized
INFO - 2025-05-08 13:00:10 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:10 --> Input Class Initialized
INFO - 2025-05-08 13:00:10 --> Language Class Initialized
INFO - 2025-05-08 13:00:10 --> Loader Class Initialized
INFO - 2025-05-08 13:00:10 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:10 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:10 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:10 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:10 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:10 --> Controller Class Initialized
INFO - 2025-05-08 13:00:23 --> Config Class Initialized
INFO - 2025-05-08 13:00:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:23 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:23 --> URI Class Initialized
INFO - 2025-05-08 13:00:23 --> Router Class Initialized
INFO - 2025-05-08 13:00:23 --> Output Class Initialized
INFO - 2025-05-08 13:00:23 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:23 --> Input Class Initialized
INFO - 2025-05-08 13:00:23 --> Language Class Initialized
INFO - 2025-05-08 13:00:23 --> Loader Class Initialized
INFO - 2025-05-08 13:00:23 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:23 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:23 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:23 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:23 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:23 --> Controller Class Initialized
INFO - 2025-05-08 13:00:23 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:00:23 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:00:23 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 13:00:23 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:00:23 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:00:23 --> Final output sent to browser
DEBUG - 2025-05-08 13:00:23 --> Total execution time: 0.0061
INFO - 2025-05-08 13:00:24 --> Config Class Initialized
INFO - 2025-05-08 13:00:24 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:24 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:24 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:24 --> URI Class Initialized
INFO - 2025-05-08 13:00:24 --> Router Class Initialized
INFO - 2025-05-08 13:00:24 --> Output Class Initialized
INFO - 2025-05-08 13:00:24 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:24 --> Input Class Initialized
INFO - 2025-05-08 13:00:24 --> Language Class Initialized
INFO - 2025-05-08 13:00:24 --> Loader Class Initialized
INFO - 2025-05-08 13:00:24 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:24 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:24 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:24 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:24 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:24 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:24 --> Controller Class Initialized
INFO - 2025-05-08 13:00:24 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:00:25 --> Config Class Initialized
INFO - 2025-05-08 13:00:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:25 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:25 --> URI Class Initialized
INFO - 2025-05-08 13:00:25 --> Router Class Initialized
INFO - 2025-05-08 13:00:25 --> Output Class Initialized
INFO - 2025-05-08 13:00:25 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:25 --> Input Class Initialized
INFO - 2025-05-08 13:00:25 --> Language Class Initialized
INFO - 2025-05-08 13:00:25 --> Loader Class Initialized
INFO - 2025-05-08 13:00:25 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:25 --> Database Driver Class Initialized
INFO - 2025-05-08 13:00:25 --> Config Class Initialized
INFO - 2025-05-08 13:00:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:25 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:25 --> URI Class Initialized
DEBUG - 2025-05-08 13:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:25 --> Router Class Initialized
INFO - 2025-05-08 13:00:25 --> Output Class Initialized
INFO - 2025-05-08 13:00:25 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:25 --> Input Class Initialized
INFO - 2025-05-08 13:00:25 --> Controller Class Initialized
INFO - 2025-05-08 13:00:25 --> Language Class Initialized
INFO - 2025-05-08 13:00:25 --> Loader Class Initialized
INFO - 2025-05-08 13:00:25 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:25 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:25 --> Controller Class Initialized
INFO - 2025-05-08 13:00:28 --> Config Class Initialized
INFO - 2025-05-08 13:00:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:28 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:28 --> URI Class Initialized
INFO - 2025-05-08 13:00:28 --> Router Class Initialized
INFO - 2025-05-08 13:00:28 --> Output Class Initialized
INFO - 2025-05-08 13:00:28 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:28 --> Input Class Initialized
INFO - 2025-05-08 13:00:28 --> Language Class Initialized
INFO - 2025-05-08 13:00:28 --> Loader Class Initialized
INFO - 2025-05-08 13:00:28 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:28 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:28 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:28 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:28 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:28 --> Controller Class Initialized
INFO - 2025-05-08 13:00:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:00:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:00:28 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 13:00:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:00:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:00:28 --> Final output sent to browser
DEBUG - 2025-05-08 13:00:28 --> Total execution time: 0.0030
INFO - 2025-05-08 13:00:31 --> Config Class Initialized
INFO - 2025-05-08 13:00:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:31 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:31 --> URI Class Initialized
INFO - 2025-05-08 13:00:31 --> Router Class Initialized
INFO - 2025-05-08 13:00:31 --> Output Class Initialized
INFO - 2025-05-08 13:00:31 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:31 --> Input Class Initialized
INFO - 2025-05-08 13:00:31 --> Language Class Initialized
INFO - 2025-05-08 13:00:31 --> Loader Class Initialized
INFO - 2025-05-08 13:00:31 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:31 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:31 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:31 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:31 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:31 --> Controller Class Initialized
INFO - 2025-05-08 13:00:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:00:32 --> Config Class Initialized
INFO - 2025-05-08 13:00:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:32 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:32 --> URI Class Initialized
INFO - 2025-05-08 13:00:32 --> Config Class Initialized
INFO - 2025-05-08 13:00:32 --> Hooks Class Initialized
INFO - 2025-05-08 13:00:32 --> Router Class Initialized
DEBUG - 2025-05-08 13:00:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:32 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:32 --> Output Class Initialized
INFO - 2025-05-08 13:00:32 --> URI Class Initialized
INFO - 2025-05-08 13:00:32 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:32 --> Input Class Initialized
INFO - 2025-05-08 13:00:32 --> Router Class Initialized
INFO - 2025-05-08 13:00:32 --> Language Class Initialized
INFO - 2025-05-08 13:00:32 --> Output Class Initialized
INFO - 2025-05-08 13:00:32 --> Loader Class Initialized
INFO - 2025-05-08 13:00:32 --> Security Class Initialized
INFO - 2025-05-08 13:00:32 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: string_helper
DEBUG - 2025-05-08 13:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:32 --> Input Class Initialized
INFO - 2025-05-08 13:00:32 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:32 --> Language Class Initialized
INFO - 2025-05-08 13:00:32 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:32 --> Loader Class Initialized
INFO - 2025-05-08 13:00:32 --> Database Driver Class Initialized
INFO - 2025-05-08 13:00:32 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:32 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:32 --> Controller Class Initialized
DEBUG - 2025-05-08 13:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:32 --> Controller Class Initialized
INFO - 2025-05-08 13:00:40 --> Config Class Initialized
INFO - 2025-05-08 13:00:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:40 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:40 --> URI Class Initialized
DEBUG - 2025-05-08 13:00:40 --> No URI present. Default controller set.
INFO - 2025-05-08 13:00:40 --> Router Class Initialized
INFO - 2025-05-08 13:00:40 --> Output Class Initialized
INFO - 2025-05-08 13:00:40 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:40 --> Input Class Initialized
INFO - 2025-05-08 13:00:40 --> Language Class Initialized
INFO - 2025-05-08 13:00:40 --> Loader Class Initialized
INFO - 2025-05-08 13:00:40 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:40 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:40 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:40 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:40 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:40 --> Controller Class Initialized
INFO - 2025-05-08 13:00:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:00:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:00:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 13:00:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:00:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:00:40 --> Final output sent to browser
DEBUG - 2025-05-08 13:00:40 --> Total execution time: 0.0046
INFO - 2025-05-08 13:00:42 --> Config Class Initialized
INFO - 2025-05-08 13:00:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:42 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:42 --> URI Class Initialized
INFO - 2025-05-08 13:00:42 --> Router Class Initialized
INFO - 2025-05-08 13:00:42 --> Output Class Initialized
INFO - 2025-05-08 13:00:42 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:42 --> Input Class Initialized
INFO - 2025-05-08 13:00:42 --> Language Class Initialized
INFO - 2025-05-08 13:00:42 --> Loader Class Initialized
INFO - 2025-05-08 13:00:42 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:42 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:42 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:42 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:42 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:42 --> Controller Class Initialized
INFO - 2025-05-08 13:00:42 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:00:43 --> Config Class Initialized
INFO - 2025-05-08 13:00:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:43 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:43 --> URI Class Initialized
INFO - 2025-05-08 13:00:43 --> Router Class Initialized
INFO - 2025-05-08 13:00:43 --> Output Class Initialized
INFO - 2025-05-08 13:00:43 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:43 --> Input Class Initialized
INFO - 2025-05-08 13:00:43 --> Language Class Initialized
INFO - 2025-05-08 13:00:43 --> Loader Class Initialized
INFO - 2025-05-08 13:00:43 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: string_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:43 --> Database Driver Class Initialized
INFO - 2025-05-08 13:00:43 --> Config Class Initialized
INFO - 2025-05-08 13:00:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:00:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:00:43 --> Utf8 Class Initialized
INFO - 2025-05-08 13:00:43 --> URI Class Initialized
INFO - 2025-05-08 13:00:43 --> Router Class Initialized
INFO - 2025-05-08 13:00:43 --> Output Class Initialized
INFO - 2025-05-08 13:00:43 --> Security Class Initialized
DEBUG - 2025-05-08 13:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:00:43 --> Input Class Initialized
INFO - 2025-05-08 13:00:43 --> Language Class Initialized
INFO - 2025-05-08 13:00:43 --> Loader Class Initialized
INFO - 2025-05-08 13:00:43 --> Helper loaded: url_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: string_helper
DEBUG - 2025-05-08 13:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:43 --> Helper loaded: form_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: file_helper
INFO - 2025-05-08 13:00:43 --> Helper loaded: html_helper
INFO - 2025-05-08 13:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:43 --> Controller Class Initialized
INFO - 2025-05-08 13:00:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:00:43 --> Controller Class Initialized
INFO - 2025-05-08 13:02:33 --> Config Class Initialized
INFO - 2025-05-08 13:02:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:33 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:33 --> URI Class Initialized
DEBUG - 2025-05-08 13:02:33 --> No URI present. Default controller set.
INFO - 2025-05-08 13:02:33 --> Router Class Initialized
INFO - 2025-05-08 13:02:33 --> Output Class Initialized
INFO - 2025-05-08 13:02:33 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:33 --> Input Class Initialized
INFO - 2025-05-08 13:02:33 --> Language Class Initialized
INFO - 2025-05-08 13:02:33 --> Loader Class Initialized
INFO - 2025-05-08 13:02:33 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:33 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:33 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:33 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:33 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:33 --> Controller Class Initialized
INFO - 2025-05-08 13:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:02:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 13:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:02:33 --> Final output sent to browser
DEBUG - 2025-05-08 13:02:33 --> Total execution time: 0.0297
INFO - 2025-05-08 13:02:36 --> Config Class Initialized
INFO - 2025-05-08 13:02:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:36 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:36 --> URI Class Initialized
INFO - 2025-05-08 13:02:36 --> Router Class Initialized
INFO - 2025-05-08 13:02:36 --> Output Class Initialized
INFO - 2025-05-08 13:02:36 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:36 --> Input Class Initialized
INFO - 2025-05-08 13:02:36 --> Language Class Initialized
INFO - 2025-05-08 13:02:36 --> Loader Class Initialized
INFO - 2025-05-08 13:02:36 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:36 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:36 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:36 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:36 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:36 --> Controller Class Initialized
INFO - 2025-05-08 13:02:36 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:02:44 --> Config Class Initialized
INFO - 2025-05-08 13:02:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:44 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:44 --> URI Class Initialized
INFO - 2025-05-08 13:02:44 --> Router Class Initialized
INFO - 2025-05-08 13:02:44 --> Output Class Initialized
INFO - 2025-05-08 13:02:44 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:44 --> Input Class Initialized
INFO - 2025-05-08 13:02:44 --> Language Class Initialized
INFO - 2025-05-08 13:02:44 --> Loader Class Initialized
INFO - 2025-05-08 13:02:44 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:44 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:44 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:44 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:44 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:44 --> Controller Class Initialized
INFO - 2025-05-08 13:02:44 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:02:44 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:02:44 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 13:02:44 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:02:44 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:02:44 --> Final output sent to browser
DEBUG - 2025-05-08 13:02:44 --> Total execution time: 0.0027
INFO - 2025-05-08 13:02:45 --> Config Class Initialized
INFO - 2025-05-08 13:02:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:45 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:45 --> URI Class Initialized
INFO - 2025-05-08 13:02:45 --> Router Class Initialized
INFO - 2025-05-08 13:02:45 --> Output Class Initialized
INFO - 2025-05-08 13:02:45 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:45 --> Input Class Initialized
INFO - 2025-05-08 13:02:45 --> Language Class Initialized
INFO - 2025-05-08 13:02:45 --> Loader Class Initialized
INFO - 2025-05-08 13:02:45 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:45 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:45 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:45 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:45 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:45 --> Controller Class Initialized
INFO - 2025-05-08 13:02:45 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:02:55 --> Config Class Initialized
INFO - 2025-05-08 13:02:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:55 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:55 --> URI Class Initialized
DEBUG - 2025-05-08 13:02:55 --> No URI present. Default controller set.
INFO - 2025-05-08 13:02:55 --> Router Class Initialized
INFO - 2025-05-08 13:02:55 --> Output Class Initialized
INFO - 2025-05-08 13:02:55 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:55 --> Input Class Initialized
INFO - 2025-05-08 13:02:55 --> Language Class Initialized
INFO - 2025-05-08 13:02:55 --> Loader Class Initialized
INFO - 2025-05-08 13:02:55 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:55 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:55 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:55 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:55 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:55 --> Controller Class Initialized
INFO - 2025-05-08 13:02:55 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:02:55 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:02:55 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 13:02:55 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:02:55 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:02:55 --> Final output sent to browser
DEBUG - 2025-05-08 13:02:55 --> Total execution time: 0.0029
INFO - 2025-05-08 13:02:56 --> Config Class Initialized
INFO - 2025-05-08 13:02:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:02:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:02:56 --> Utf8 Class Initialized
INFO - 2025-05-08 13:02:56 --> URI Class Initialized
INFO - 2025-05-08 13:02:56 --> Router Class Initialized
INFO - 2025-05-08 13:02:56 --> Output Class Initialized
INFO - 2025-05-08 13:02:56 --> Security Class Initialized
DEBUG - 2025-05-08 13:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:02:56 --> Input Class Initialized
INFO - 2025-05-08 13:02:56 --> Language Class Initialized
INFO - 2025-05-08 13:02:56 --> Loader Class Initialized
INFO - 2025-05-08 13:02:56 --> Helper loaded: url_helper
INFO - 2025-05-08 13:02:56 --> Helper loaded: string_helper
INFO - 2025-05-08 13:02:56 --> Helper loaded: form_helper
INFO - 2025-05-08 13:02:56 --> Helper loaded: file_helper
INFO - 2025-05-08 13:02:56 --> Helper loaded: html_helper
INFO - 2025-05-08 13:02:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:02:56 --> Controller Class Initialized
INFO - 2025-05-08 13:02:56 --> Model "AuctionModel" initialized
INFO - 2025-05-08 13:04:40 --> Config Class Initialized
INFO - 2025-05-08 13:04:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:04:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:04:40 --> Utf8 Class Initialized
INFO - 2025-05-08 13:04:40 --> URI Class Initialized
DEBUG - 2025-05-08 13:04:40 --> No URI present. Default controller set.
INFO - 2025-05-08 13:04:40 --> Router Class Initialized
INFO - 2025-05-08 13:04:40 --> Output Class Initialized
INFO - 2025-05-08 13:04:40 --> Security Class Initialized
DEBUG - 2025-05-08 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:04:40 --> Input Class Initialized
INFO - 2025-05-08 13:04:40 --> Language Class Initialized
INFO - 2025-05-08 13:04:40 --> Loader Class Initialized
INFO - 2025-05-08 13:04:40 --> Helper loaded: url_helper
INFO - 2025-05-08 13:04:40 --> Helper loaded: string_helper
INFO - 2025-05-08 13:04:40 --> Helper loaded: form_helper
INFO - 2025-05-08 13:04:40 --> Helper loaded: file_helper
INFO - 2025-05-08 13:04:40 --> Helper loaded: html_helper
INFO - 2025-05-08 13:04:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:04:40 --> Controller Class Initialized
INFO - 2025-05-08 13:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:04:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 13:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:04:40 --> Final output sent to browser
DEBUG - 2025-05-08 13:04:40 --> Total execution time: 0.0284
INFO - 2025-05-08 13:40:26 --> Config Class Initialized
INFO - 2025-05-08 13:40:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 13:40:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 13:40:26 --> Utf8 Class Initialized
INFO - 2025-05-08 13:40:26 --> URI Class Initialized
DEBUG - 2025-05-08 13:40:26 --> No URI present. Default controller set.
INFO - 2025-05-08 13:40:26 --> Router Class Initialized
INFO - 2025-05-08 13:40:26 --> Output Class Initialized
INFO - 2025-05-08 13:40:26 --> Security Class Initialized
DEBUG - 2025-05-08 13:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 13:40:26 --> Input Class Initialized
INFO - 2025-05-08 13:40:26 --> Language Class Initialized
INFO - 2025-05-08 13:40:26 --> Loader Class Initialized
INFO - 2025-05-08 13:40:26 --> Helper loaded: url_helper
INFO - 2025-05-08 13:40:26 --> Helper loaded: string_helper
INFO - 2025-05-08 13:40:26 --> Helper loaded: form_helper
INFO - 2025-05-08 13:40:26 --> Helper loaded: file_helper
INFO - 2025-05-08 13:40:26 --> Helper loaded: html_helper
INFO - 2025-05-08 13:40:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 13:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 13:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 13:40:26 --> Controller Class Initialized
INFO - 2025-05-08 13:40:26 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 13:40:26 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 13:40:26 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 13:40:26 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 13:40:26 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 13:40:26 --> Final output sent to browser
DEBUG - 2025-05-08 13:40:26 --> Total execution time: 0.0446
INFO - 2025-05-08 14:50:06 --> Config Class Initialized
INFO - 2025-05-08 14:50:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 14:50:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 14:50:06 --> Utf8 Class Initialized
INFO - 2025-05-08 14:50:06 --> URI Class Initialized
DEBUG - 2025-05-08 14:50:06 --> No URI present. Default controller set.
INFO - 2025-05-08 14:50:06 --> Router Class Initialized
INFO - 2025-05-08 14:50:06 --> Output Class Initialized
INFO - 2025-05-08 14:50:06 --> Security Class Initialized
DEBUG - 2025-05-08 14:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 14:50:06 --> Input Class Initialized
INFO - 2025-05-08 14:50:06 --> Language Class Initialized
INFO - 2025-05-08 14:50:06 --> Loader Class Initialized
INFO - 2025-05-08 14:50:06 --> Helper loaded: url_helper
INFO - 2025-05-08 14:50:06 --> Helper loaded: string_helper
INFO - 2025-05-08 14:50:06 --> Helper loaded: form_helper
INFO - 2025-05-08 14:50:06 --> Helper loaded: file_helper
INFO - 2025-05-08 14:50:06 --> Helper loaded: html_helper
INFO - 2025-05-08 14:50:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 14:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 14:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 14:50:06 --> Controller Class Initialized
INFO - 2025-05-08 14:50:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 14:50:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 14:50:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 14:50:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 14:50:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 14:50:06 --> Final output sent to browser
DEBUG - 2025-05-08 14:50:06 --> Total execution time: 0.0468
INFO - 2025-05-08 15:02:33 --> Config Class Initialized
INFO - 2025-05-08 15:02:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:02:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:02:33 --> Utf8 Class Initialized
INFO - 2025-05-08 15:02:33 --> URI Class Initialized
DEBUG - 2025-05-08 15:02:33 --> No URI present. Default controller set.
INFO - 2025-05-08 15:02:33 --> Router Class Initialized
INFO - 2025-05-08 15:02:33 --> Output Class Initialized
INFO - 2025-05-08 15:02:33 --> Security Class Initialized
DEBUG - 2025-05-08 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:02:33 --> Input Class Initialized
INFO - 2025-05-08 15:02:33 --> Language Class Initialized
INFO - 2025-05-08 15:02:33 --> Loader Class Initialized
INFO - 2025-05-08 15:02:33 --> Helper loaded: url_helper
INFO - 2025-05-08 15:02:33 --> Helper loaded: string_helper
INFO - 2025-05-08 15:02:33 --> Helper loaded: form_helper
INFO - 2025-05-08 15:02:33 --> Helper loaded: file_helper
INFO - 2025-05-08 15:02:33 --> Helper loaded: html_helper
INFO - 2025-05-08 15:02:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:02:33 --> Controller Class Initialized
INFO - 2025-05-08 15:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:02:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 15:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:02:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:02:33 --> Final output sent to browser
DEBUG - 2025-05-08 15:02:33 --> Total execution time: 0.0309
INFO - 2025-05-08 15:02:47 --> Config Class Initialized
INFO - 2025-05-08 15:02:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:02:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:02:47 --> Utf8 Class Initialized
INFO - 2025-05-08 15:02:47 --> URI Class Initialized
DEBUG - 2025-05-08 15:02:47 --> No URI present. Default controller set.
INFO - 2025-05-08 15:02:47 --> Router Class Initialized
INFO - 2025-05-08 15:02:47 --> Output Class Initialized
INFO - 2025-05-08 15:02:47 --> Security Class Initialized
DEBUG - 2025-05-08 15:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:02:47 --> Input Class Initialized
INFO - 2025-05-08 15:02:47 --> Language Class Initialized
INFO - 2025-05-08 15:02:47 --> Loader Class Initialized
INFO - 2025-05-08 15:02:47 --> Helper loaded: url_helper
INFO - 2025-05-08 15:02:47 --> Helper loaded: string_helper
INFO - 2025-05-08 15:02:47 --> Helper loaded: form_helper
INFO - 2025-05-08 15:02:47 --> Helper loaded: file_helper
INFO - 2025-05-08 15:02:47 --> Helper loaded: html_helper
INFO - 2025-05-08 15:02:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:02:47 --> Controller Class Initialized
INFO - 2025-05-08 15:02:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:02:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:02:47 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 15:02:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:02:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:02:47 --> Final output sent to browser
DEBUG - 2025-05-08 15:02:47 --> Total execution time: 0.0054
INFO - 2025-05-08 15:25:36 --> Config Class Initialized
INFO - 2025-05-08 15:25:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:36 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:36 --> URI Class Initialized
DEBUG - 2025-05-08 15:25:36 --> No URI present. Default controller set.
INFO - 2025-05-08 15:25:36 --> Router Class Initialized
INFO - 2025-05-08 15:25:36 --> Output Class Initialized
INFO - 2025-05-08 15:25:36 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:36 --> Input Class Initialized
INFO - 2025-05-08 15:25:36 --> Language Class Initialized
INFO - 2025-05-08 15:25:36 --> Loader Class Initialized
INFO - 2025-05-08 15:25:36 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:36 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:36 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:36 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:36 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:36 --> Controller Class Initialized
INFO - 2025-05-08 15:25:36 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:36 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:36 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 15:25:36 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:36 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:36 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:36 --> Total execution time: 0.0298
INFO - 2025-05-08 15:25:37 --> Config Class Initialized
INFO - 2025-05-08 15:25:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:37 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:37 --> URI Class Initialized
DEBUG - 2025-05-08 15:25:37 --> No URI present. Default controller set.
INFO - 2025-05-08 15:25:37 --> Router Class Initialized
INFO - 2025-05-08 15:25:37 --> Output Class Initialized
INFO - 2025-05-08 15:25:37 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:37 --> Input Class Initialized
INFO - 2025-05-08 15:25:37 --> Language Class Initialized
INFO - 2025-05-08 15:25:37 --> Loader Class Initialized
INFO - 2025-05-08 15:25:37 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:37 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:37 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:37 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:37 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:37 --> Controller Class Initialized
INFO - 2025-05-08 15:25:37 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:37 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:37 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 15:25:37 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:37 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:37 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:37 --> Total execution time: 0.0034
INFO - 2025-05-08 15:25:40 --> Config Class Initialized
INFO - 2025-05-08 15:25:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:40 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:40 --> URI Class Initialized
INFO - 2025-05-08 15:25:40 --> Router Class Initialized
INFO - 2025-05-08 15:25:40 --> Output Class Initialized
INFO - 2025-05-08 15:25:40 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:40 --> Input Class Initialized
INFO - 2025-05-08 15:25:40 --> Language Class Initialized
INFO - 2025-05-08 15:25:40 --> Loader Class Initialized
INFO - 2025-05-08 15:25:40 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:40 --> Controller Class Initialized
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/pages/contact_us.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:40 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:40 --> Total execution time: 0.0042
INFO - 2025-05-08 15:25:40 --> Config Class Initialized
INFO - 2025-05-08 15:25:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:40 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:40 --> URI Class Initialized
INFO - 2025-05-08 15:25:40 --> Router Class Initialized
INFO - 2025-05-08 15:25:40 --> Output Class Initialized
INFO - 2025-05-08 15:25:40 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:40 --> Input Class Initialized
INFO - 2025-05-08 15:25:40 --> Language Class Initialized
INFO - 2025-05-08 15:25:40 --> Loader Class Initialized
INFO - 2025-05-08 15:25:40 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:40 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:40 --> Controller Class Initialized
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/pages/contact_us.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:40 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:40 --> Total execution time: 0.0025
INFO - 2025-05-08 15:25:45 --> Config Class Initialized
INFO - 2025-05-08 15:25:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:45 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:45 --> URI Class Initialized
INFO - 2025-05-08 15:25:45 --> Router Class Initialized
INFO - 2025-05-08 15:25:45 --> Output Class Initialized
INFO - 2025-05-08 15:25:45 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:45 --> Input Class Initialized
INFO - 2025-05-08 15:25:45 --> Language Class Initialized
INFO - 2025-05-08 15:25:45 --> Loader Class Initialized
INFO - 2025-05-08 15:25:45 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:45 --> Controller Class Initialized
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:45 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:45 --> Total execution time: 0.0081
INFO - 2025-05-08 15:25:45 --> Config Class Initialized
INFO - 2025-05-08 15:25:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:45 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:45 --> URI Class Initialized
INFO - 2025-05-08 15:25:45 --> Router Class Initialized
INFO - 2025-05-08 15:25:45 --> Output Class Initialized
INFO - 2025-05-08 15:25:45 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:45 --> Input Class Initialized
INFO - 2025-05-08 15:25:45 --> Language Class Initialized
INFO - 2025-05-08 15:25:45 --> Loader Class Initialized
INFO - 2025-05-08 15:25:45 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:45 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:45 --> Controller Class Initialized
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:45 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:45 --> Total execution time: 0.0026
INFO - 2025-05-08 15:25:49 --> Config Class Initialized
INFO - 2025-05-08 15:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:49 --> URI Class Initialized
INFO - 2025-05-08 15:25:49 --> Router Class Initialized
INFO - 2025-05-08 15:25:49 --> Output Class Initialized
INFO - 2025-05-08 15:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:49 --> Input Class Initialized
INFO - 2025-05-08 15:25:49 --> Language Class Initialized
INFO - 2025-05-08 15:25:49 --> Loader Class Initialized
INFO - 2025-05-08 15:25:49 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:49 --> Controller Class Initialized
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/pages/faqs.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:49 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:49 --> Total execution time: 0.0034
INFO - 2025-05-08 15:25:49 --> Config Class Initialized
INFO - 2025-05-08 15:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:49 --> URI Class Initialized
INFO - 2025-05-08 15:25:49 --> Router Class Initialized
INFO - 2025-05-08 15:25:49 --> Output Class Initialized
INFO - 2025-05-08 15:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:49 --> Input Class Initialized
INFO - 2025-05-08 15:25:49 --> Language Class Initialized
INFO - 2025-05-08 15:25:49 --> Loader Class Initialized
INFO - 2025-05-08 15:25:49 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:49 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:49 --> Controller Class Initialized
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/pages/faqs.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:49 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:49 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:49 --> Total execution time: 0.0033
INFO - 2025-05-08 15:25:58 --> Config Class Initialized
INFO - 2025-05-08 15:25:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:58 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:58 --> URI Class Initialized
INFO - 2025-05-08 15:25:58 --> Router Class Initialized
INFO - 2025-05-08 15:25:58 --> Output Class Initialized
INFO - 2025-05-08 15:25:58 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:58 --> Input Class Initialized
INFO - 2025-05-08 15:25:58 --> Language Class Initialized
INFO - 2025-05-08 15:25:58 --> Loader Class Initialized
INFO - 2025-05-08 15:25:58 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:58 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:58 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:58 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:58 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:58 --> Controller Class Initialized
INFO - 2025-05-08 15:25:58 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:58 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:58 --> File loaded: /home/storagep/public_html/application/views/auth/sign_in.php
INFO - 2025-05-08 15:25:58 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:58 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:58 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:58 --> Total execution time: 0.0051
INFO - 2025-05-08 15:25:59 --> Config Class Initialized
INFO - 2025-05-08 15:25:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:25:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:25:59 --> Utf8 Class Initialized
INFO - 2025-05-08 15:25:59 --> URI Class Initialized
INFO - 2025-05-08 15:25:59 --> Router Class Initialized
INFO - 2025-05-08 15:25:59 --> Output Class Initialized
INFO - 2025-05-08 15:25:59 --> Security Class Initialized
DEBUG - 2025-05-08 15:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:25:59 --> Input Class Initialized
INFO - 2025-05-08 15:25:59 --> Language Class Initialized
INFO - 2025-05-08 15:25:59 --> Loader Class Initialized
INFO - 2025-05-08 15:25:59 --> Helper loaded: url_helper
INFO - 2025-05-08 15:25:59 --> Helper loaded: string_helper
INFO - 2025-05-08 15:25:59 --> Helper loaded: form_helper
INFO - 2025-05-08 15:25:59 --> Helper loaded: file_helper
INFO - 2025-05-08 15:25:59 --> Helper loaded: html_helper
INFO - 2025-05-08 15:25:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:25:59 --> Controller Class Initialized
INFO - 2025-05-08 15:25:59 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:25:59 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:25:59 --> File loaded: /home/storagep/public_html/application/views/auth/sign_in.php
INFO - 2025-05-08 15:25:59 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:25:59 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:25:59 --> Final output sent to browser
DEBUG - 2025-05-08 15:25:59 --> Total execution time: 0.0032
INFO - 2025-05-08 15:26:03 --> Config Class Initialized
INFO - 2025-05-08 15:26:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:26:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:26:03 --> Utf8 Class Initialized
INFO - 2025-05-08 15:26:03 --> URI Class Initialized
INFO - 2025-05-08 15:26:03 --> Router Class Initialized
INFO - 2025-05-08 15:26:03 --> Output Class Initialized
INFO - 2025-05-08 15:26:03 --> Security Class Initialized
DEBUG - 2025-05-08 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:26:03 --> Input Class Initialized
INFO - 2025-05-08 15:26:03 --> Language Class Initialized
INFO - 2025-05-08 15:26:03 --> Loader Class Initialized
INFO - 2025-05-08 15:26:03 --> Helper loaded: url_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: string_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: form_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: file_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: html_helper
INFO - 2025-05-08 15:26:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:26:03 --> Controller Class Initialized
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/pages/about_us.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:26:03 --> Final output sent to browser
DEBUG - 2025-05-08 15:26:03 --> Total execution time: 0.0036
INFO - 2025-05-08 15:26:03 --> Config Class Initialized
INFO - 2025-05-08 15:26:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:26:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:26:03 --> Utf8 Class Initialized
INFO - 2025-05-08 15:26:03 --> URI Class Initialized
INFO - 2025-05-08 15:26:03 --> Router Class Initialized
INFO - 2025-05-08 15:26:03 --> Output Class Initialized
INFO - 2025-05-08 15:26:03 --> Security Class Initialized
DEBUG - 2025-05-08 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:26:03 --> Input Class Initialized
INFO - 2025-05-08 15:26:03 --> Language Class Initialized
INFO - 2025-05-08 15:26:03 --> Loader Class Initialized
INFO - 2025-05-08 15:26:03 --> Helper loaded: url_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: string_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: form_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: file_helper
INFO - 2025-05-08 15:26:03 --> Helper loaded: html_helper
INFO - 2025-05-08 15:26:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:26:03 --> Controller Class Initialized
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/pages/about_us.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:26:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:26:03 --> Final output sent to browser
DEBUG - 2025-05-08 15:26:03 --> Total execution time: 0.0024
INFO - 2025-05-08 15:26:07 --> Config Class Initialized
INFO - 2025-05-08 15:26:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:26:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:26:07 --> Utf8 Class Initialized
INFO - 2025-05-08 15:26:07 --> URI Class Initialized
INFO - 2025-05-08 15:26:07 --> Router Class Initialized
INFO - 2025-05-08 15:26:07 --> Output Class Initialized
INFO - 2025-05-08 15:26:07 --> Security Class Initialized
DEBUG - 2025-05-08 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:26:07 --> Input Class Initialized
INFO - 2025-05-08 15:26:07 --> Language Class Initialized
INFO - 2025-05-08 15:26:07 --> Loader Class Initialized
INFO - 2025-05-08 15:26:07 --> Helper loaded: url_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: string_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: form_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: file_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: html_helper
INFO - 2025-05-08 15:26:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:26:07 --> Controller Class Initialized
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/pages/terms_and_conditions.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:26:07 --> Final output sent to browser
DEBUG - 2025-05-08 15:26:07 --> Total execution time: 0.0030
INFO - 2025-05-08 15:26:07 --> Config Class Initialized
INFO - 2025-05-08 15:26:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 15:26:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 15:26:07 --> Utf8 Class Initialized
INFO - 2025-05-08 15:26:07 --> URI Class Initialized
INFO - 2025-05-08 15:26:07 --> Router Class Initialized
INFO - 2025-05-08 15:26:07 --> Output Class Initialized
INFO - 2025-05-08 15:26:07 --> Security Class Initialized
DEBUG - 2025-05-08 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 15:26:07 --> Input Class Initialized
INFO - 2025-05-08 15:26:07 --> Language Class Initialized
INFO - 2025-05-08 15:26:07 --> Loader Class Initialized
INFO - 2025-05-08 15:26:07 --> Helper loaded: url_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: string_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: form_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: file_helper
INFO - 2025-05-08 15:26:07 --> Helper loaded: html_helper
INFO - 2025-05-08 15:26:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 15:26:07 --> Controller Class Initialized
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/pages/terms_and_conditions.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 15:26:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 15:26:07 --> Final output sent to browser
DEBUG - 2025-05-08 15:26:07 --> Total execution time: 0.0026
INFO - 2025-05-08 16:01:06 --> Config Class Initialized
INFO - 2025-05-08 16:01:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:01:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:01:06 --> Utf8 Class Initialized
INFO - 2025-05-08 16:01:06 --> URI Class Initialized
DEBUG - 2025-05-08 16:01:06 --> No URI present. Default controller set.
INFO - 2025-05-08 16:01:06 --> Router Class Initialized
INFO - 2025-05-08 16:01:06 --> Output Class Initialized
INFO - 2025-05-08 16:01:06 --> Security Class Initialized
DEBUG - 2025-05-08 16:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:01:06 --> Input Class Initialized
INFO - 2025-05-08 16:01:06 --> Language Class Initialized
INFO - 2025-05-08 16:01:06 --> Loader Class Initialized
INFO - 2025-05-08 16:01:06 --> Helper loaded: url_helper
INFO - 2025-05-08 16:01:06 --> Helper loaded: string_helper
INFO - 2025-05-08 16:01:06 --> Helper loaded: form_helper
INFO - 2025-05-08 16:01:06 --> Helper loaded: file_helper
INFO - 2025-05-08 16:01:06 --> Helper loaded: html_helper
INFO - 2025-05-08 16:01:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:01:06 --> Controller Class Initialized
INFO - 2025-05-08 16:01:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:01:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:01:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:01:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:01:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:01:06 --> Final output sent to browser
DEBUG - 2025-05-08 16:01:06 --> Total execution time: 0.0318
INFO - 2025-05-08 16:12:07 --> Config Class Initialized
INFO - 2025-05-08 16:12:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:07 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:07 --> URI Class Initialized
INFO - 2025-05-08 16:12:07 --> Router Class Initialized
INFO - 2025-05-08 16:12:07 --> Output Class Initialized
INFO - 2025-05-08 16:12:07 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:07 --> Input Class Initialized
INFO - 2025-05-08 16:12:07 --> Language Class Initialized
INFO - 2025-05-08 16:12:07 --> Loader Class Initialized
INFO - 2025-05-08 16:12:07 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:07 --> Controller Class Initialized
INFO - 2025-05-08 16:12:07 --> Config Class Initialized
INFO - 2025-05-08 16:12:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:07 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:07 --> URI Class Initialized
DEBUG - 2025-05-08 16:12:07 --> No URI present. Default controller set.
INFO - 2025-05-08 16:12:07 --> Router Class Initialized
INFO - 2025-05-08 16:12:07 --> Output Class Initialized
INFO - 2025-05-08 16:12:07 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:07 --> Input Class Initialized
INFO - 2025-05-08 16:12:07 --> Language Class Initialized
INFO - 2025-05-08 16:12:07 --> Loader Class Initialized
INFO - 2025-05-08 16:12:07 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:07 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:07 --> Controller Class Initialized
INFO - 2025-05-08 16:12:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:12:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:07 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:07 --> Total execution time: 0.0039
INFO - 2025-05-08 16:12:09 --> Config Class Initialized
INFO - 2025-05-08 16:12:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:09 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:09 --> URI Class Initialized
INFO - 2025-05-08 16:12:09 --> Router Class Initialized
INFO - 2025-05-08 16:12:09 --> Output Class Initialized
INFO - 2025-05-08 16:12:09 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:09 --> Input Class Initialized
INFO - 2025-05-08 16:12:09 --> Language Class Initialized
INFO - 2025-05-08 16:12:09 --> Loader Class Initialized
INFO - 2025-05-08 16:12:09 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:09 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:09 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:09 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:09 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:09 --> Controller Class Initialized
INFO - 2025-05-08 16:12:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:16 --> Config Class Initialized
INFO - 2025-05-08 16:12:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:16 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:16 --> URI Class Initialized
INFO - 2025-05-08 16:12:16 --> Router Class Initialized
INFO - 2025-05-08 16:12:16 --> Output Class Initialized
INFO - 2025-05-08 16:12:16 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:16 --> Input Class Initialized
INFO - 2025-05-08 16:12:16 --> Language Class Initialized
INFO - 2025-05-08 16:12:16 --> Loader Class Initialized
INFO - 2025-05-08 16:12:16 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:16 --> Controller Class Initialized
INFO - 2025-05-08 16:12:16 --> Model "UserModel" initialized
INFO - 2025-05-08 16:12:16 --> Config Class Initialized
INFO - 2025-05-08 16:12:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:16 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:16 --> URI Class Initialized
DEBUG - 2025-05-08 16:12:16 --> No URI present. Default controller set.
INFO - 2025-05-08 16:12:16 --> Router Class Initialized
INFO - 2025-05-08 16:12:16 --> Output Class Initialized
INFO - 2025-05-08 16:12:16 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:16 --> Input Class Initialized
INFO - 2025-05-08 16:12:16 --> Language Class Initialized
INFO - 2025-05-08 16:12:16 --> Loader Class Initialized
INFO - 2025-05-08 16:12:16 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:16 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:16 --> Controller Class Initialized
INFO - 2025-05-08 16:12:16 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:16 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:16 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:12:16 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:16 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:16 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:16 --> Total execution time: 0.0026
INFO - 2025-05-08 16:12:18 --> Config Class Initialized
INFO - 2025-05-08 16:12:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:18 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:18 --> URI Class Initialized
INFO - 2025-05-08 16:12:18 --> Router Class Initialized
INFO - 2025-05-08 16:12:18 --> Output Class Initialized
INFO - 2025-05-08 16:12:18 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:18 --> Input Class Initialized
INFO - 2025-05-08 16:12:18 --> Language Class Initialized
INFO - 2025-05-08 16:12:18 --> Loader Class Initialized
INFO - 2025-05-08 16:12:18 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:18 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:18 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:18 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:18 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:18 --> Controller Class Initialized
INFO - 2025-05-08 16:12:18 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:22 --> Config Class Initialized
INFO - 2025-05-08 16:12:22 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:22 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:22 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:22 --> URI Class Initialized
INFO - 2025-05-08 16:12:22 --> Router Class Initialized
INFO - 2025-05-08 16:12:22 --> Output Class Initialized
INFO - 2025-05-08 16:12:22 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:22 --> Input Class Initialized
INFO - 2025-05-08 16:12:22 --> Language Class Initialized
INFO - 2025-05-08 16:12:22 --> Loader Class Initialized
INFO - 2025-05-08 16:12:22 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:22 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:22 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:22 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:22 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:22 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:22 --> Controller Class Initialized
INFO - 2025-05-08 16:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:22 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 16:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:22 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:22 --> Total execution time: 0.0048
INFO - 2025-05-08 16:12:23 --> Config Class Initialized
INFO - 2025-05-08 16:12:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:23 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:23 --> URI Class Initialized
INFO - 2025-05-08 16:12:23 --> Router Class Initialized
INFO - 2025-05-08 16:12:23 --> Output Class Initialized
INFO - 2025-05-08 16:12:23 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:23 --> Input Class Initialized
INFO - 2025-05-08 16:12:23 --> Language Class Initialized
INFO - 2025-05-08 16:12:23 --> Loader Class Initialized
INFO - 2025-05-08 16:12:23 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:23 --> Controller Class Initialized
INFO - 2025-05-08 16:12:23 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:23 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:23 --> Total execution time: 0.0045
INFO - 2025-05-08 16:12:23 --> Config Class Initialized
INFO - 2025-05-08 16:12:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:23 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:23 --> URI Class Initialized
INFO - 2025-05-08 16:12:23 --> Router Class Initialized
INFO - 2025-05-08 16:12:23 --> Output Class Initialized
INFO - 2025-05-08 16:12:23 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:23 --> Input Class Initialized
INFO - 2025-05-08 16:12:23 --> Language Class Initialized
INFO - 2025-05-08 16:12:23 --> Loader Class Initialized
INFO - 2025-05-08 16:12:23 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:23 --> Controller Class Initialized
INFO - 2025-05-08 16:12:23 --> Model "CompanyModel" initialized
INFO - 2025-05-08 16:12:23 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 16:12:23 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:23 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:23 --> Total execution time: 0.0108
INFO - 2025-05-08 16:12:23 --> Config Class Initialized
INFO - 2025-05-08 16:12:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:23 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:23 --> URI Class Initialized
INFO - 2025-05-08 16:12:23 --> Router Class Initialized
INFO - 2025-05-08 16:12:23 --> Output Class Initialized
INFO - 2025-05-08 16:12:23 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:23 --> Input Class Initialized
INFO - 2025-05-08 16:12:23 --> Language Class Initialized
INFO - 2025-05-08 16:12:23 --> Loader Class Initialized
INFO - 2025-05-08 16:12:23 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:23 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:23 --> Controller Class Initialized
INFO - 2025-05-08 16:12:23 --> Model "UserModel" initialized
INFO - 2025-05-08 16:12:23 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:23 --> Total execution time: 0.0052
INFO - 2025-05-08 16:12:26 --> Config Class Initialized
INFO - 2025-05-08 16:12:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:26 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:26 --> URI Class Initialized
INFO - 2025-05-08 16:12:26 --> Router Class Initialized
INFO - 2025-05-08 16:12:26 --> Output Class Initialized
INFO - 2025-05-08 16:12:26 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:26 --> Input Class Initialized
INFO - 2025-05-08 16:12:26 --> Language Class Initialized
INFO - 2025-05-08 16:12:26 --> Loader Class Initialized
INFO - 2025-05-08 16:12:26 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:26 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:26 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:26 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:26 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:26 --> Controller Class Initialized
INFO - 2025-05-08 16:12:26 --> Model "CompanyModel" initialized
INFO - 2025-05-08 16:12:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:26 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:26 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:26 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 16:12:26 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:26 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:26 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:26 --> Total execution time: 0.0073
INFO - 2025-05-08 16:12:27 --> Config Class Initialized
INFO - 2025-05-08 16:12:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:27 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:27 --> URI Class Initialized
INFO - 2025-05-08 16:12:27 --> Router Class Initialized
INFO - 2025-05-08 16:12:27 --> Output Class Initialized
INFO - 2025-05-08 16:12:27 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:27 --> Input Class Initialized
INFO - 2025-05-08 16:12:27 --> Language Class Initialized
INFO - 2025-05-08 16:12:27 --> Loader Class Initialized
INFO - 2025-05-08 16:12:27 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:27 --> Controller Class Initialized
INFO - 2025-05-08 16:12:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:27 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:27 --> Total execution time: 0.0533
INFO - 2025-05-08 16:12:27 --> Config Class Initialized
INFO - 2025-05-08 16:12:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:27 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:27 --> URI Class Initialized
INFO - 2025-05-08 16:12:27 --> Router Class Initialized
INFO - 2025-05-08 16:12:27 --> Output Class Initialized
INFO - 2025-05-08 16:12:27 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:27 --> Input Class Initialized
INFO - 2025-05-08 16:12:27 --> Language Class Initialized
INFO - 2025-05-08 16:12:27 --> Loader Class Initialized
INFO - 2025-05-08 16:12:27 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:27 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:27 --> Controller Class Initialized
INFO - 2025-05-08 16:12:27 --> Model "UserModel" initialized
INFO - 2025-05-08 16:12:27 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:27 --> Total execution time: 0.0535
INFO - 2025-05-08 16:12:28 --> Config Class Initialized
INFO - 2025-05-08 16:12:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:28 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:28 --> URI Class Initialized
INFO - 2025-05-08 16:12:28 --> Router Class Initialized
INFO - 2025-05-08 16:12:28 --> Output Class Initialized
INFO - 2025-05-08 16:12:28 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:28 --> Input Class Initialized
INFO - 2025-05-08 16:12:28 --> Language Class Initialized
INFO - 2025-05-08 16:12:28 --> Loader Class Initialized
INFO - 2025-05-08 16:12:28 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:28 --> Controller Class Initialized
INFO - 2025-05-08 16:12:28 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:28 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:28 --> Total execution time: 0.0528
INFO - 2025-05-08 16:12:28 --> Config Class Initialized
INFO - 2025-05-08 16:12:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:28 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:28 --> URI Class Initialized
INFO - 2025-05-08 16:12:28 --> Router Class Initialized
INFO - 2025-05-08 16:12:28 --> Output Class Initialized
INFO - 2025-05-08 16:12:28 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:28 --> Input Class Initialized
INFO - 2025-05-08 16:12:28 --> Language Class Initialized
INFO - 2025-05-08 16:12:28 --> Loader Class Initialized
INFO - 2025-05-08 16:12:28 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:28 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:28 --> Controller Class Initialized
INFO - 2025-05-08 16:12:29 --> Config Class Initialized
INFO - 2025-05-08 16:12:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:29 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:29 --> URI Class Initialized
INFO - 2025-05-08 16:12:29 --> Router Class Initialized
INFO - 2025-05-08 16:12:29 --> Output Class Initialized
INFO - 2025-05-08 16:12:29 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:29 --> Input Class Initialized
INFO - 2025-05-08 16:12:29 --> Language Class Initialized
INFO - 2025-05-08 16:12:29 --> Loader Class Initialized
INFO - 2025-05-08 16:12:29 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:29 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:29 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:29 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:29 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:29 --> Controller Class Initialized
INFO - 2025-05-08 16:12:29 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:33 --> Config Class Initialized
INFO - 2025-05-08 16:12:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:33 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:33 --> URI Class Initialized
INFO - 2025-05-08 16:12:33 --> Router Class Initialized
INFO - 2025-05-08 16:12:33 --> Output Class Initialized
INFO - 2025-05-08 16:12:33 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:33 --> Input Class Initialized
INFO - 2025-05-08 16:12:33 --> Language Class Initialized
INFO - 2025-05-08 16:12:33 --> Loader Class Initialized
INFO - 2025-05-08 16:12:33 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:33 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:33 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:33 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:33 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:33 --> Controller Class Initialized
INFO - 2025-05-08 16:12:33 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:36 --> Config Class Initialized
INFO - 2025-05-08 16:12:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:36 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:36 --> URI Class Initialized
INFO - 2025-05-08 16:12:36 --> Router Class Initialized
INFO - 2025-05-08 16:12:36 --> Output Class Initialized
INFO - 2025-05-08 16:12:36 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:36 --> Input Class Initialized
INFO - 2025-05-08 16:12:36 --> Language Class Initialized
INFO - 2025-05-08 16:12:36 --> Loader Class Initialized
INFO - 2025-05-08 16:12:36 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:36 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:36 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:36 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:36 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:36 --> Controller Class Initialized
INFO - 2025-05-08 16:12:36 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:36 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:36 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 16:12:36 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:36 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:36 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:36 --> Total execution time: 0.0053
INFO - 2025-05-08 16:12:37 --> Config Class Initialized
INFO - 2025-05-08 16:12:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:37 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:37 --> URI Class Initialized
INFO - 2025-05-08 16:12:37 --> Router Class Initialized
INFO - 2025-05-08 16:12:37 --> Output Class Initialized
INFO - 2025-05-08 16:12:37 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:37 --> Input Class Initialized
INFO - 2025-05-08 16:12:37 --> Language Class Initialized
INFO - 2025-05-08 16:12:37 --> Loader Class Initialized
INFO - 2025-05-08 16:12:37 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:37 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:37 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:37 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:37 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:37 --> Controller Class Initialized
INFO - 2025-05-08 16:12:37 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:40 --> Config Class Initialized
INFO - 2025-05-08 16:12:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:40 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:40 --> URI Class Initialized
DEBUG - 2025-05-08 16:12:40 --> No URI present. Default controller set.
INFO - 2025-05-08 16:12:40 --> Router Class Initialized
INFO - 2025-05-08 16:12:40 --> Output Class Initialized
INFO - 2025-05-08 16:12:40 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:40 --> Input Class Initialized
INFO - 2025-05-08 16:12:40 --> Language Class Initialized
INFO - 2025-05-08 16:12:40 --> Loader Class Initialized
INFO - 2025-05-08 16:12:40 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:40 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:40 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:40 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:40 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:40 --> Controller Class Initialized
INFO - 2025-05-08 16:12:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:12:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:40 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:40 --> Total execution time: 0.0027
INFO - 2025-05-08 16:12:42 --> Config Class Initialized
INFO - 2025-05-08 16:12:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:42 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:42 --> URI Class Initialized
INFO - 2025-05-08 16:12:42 --> Router Class Initialized
INFO - 2025-05-08 16:12:42 --> Output Class Initialized
INFO - 2025-05-08 16:12:42 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:42 --> Input Class Initialized
INFO - 2025-05-08 16:12:42 --> Language Class Initialized
INFO - 2025-05-08 16:12:42 --> Loader Class Initialized
INFO - 2025-05-08 16:12:42 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:42 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:42 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:42 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:42 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:42 --> Controller Class Initialized
INFO - 2025-05-08 16:12:42 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:12:45 --> Config Class Initialized
INFO - 2025-05-08 16:12:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:45 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:45 --> URI Class Initialized
INFO - 2025-05-08 16:12:45 --> Router Class Initialized
INFO - 2025-05-08 16:12:45 --> Output Class Initialized
INFO - 2025-05-08 16:12:45 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:45 --> Input Class Initialized
INFO - 2025-05-08 16:12:45 --> Language Class Initialized
INFO - 2025-05-08 16:12:45 --> Loader Class Initialized
INFO - 2025-05-08 16:12:45 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:45 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:45 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:45 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:45 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:45 --> Controller Class Initialized
INFO - 2025-05-08 16:12:46 --> Config Class Initialized
INFO - 2025-05-08 16:12:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:46 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:46 --> URI Class Initialized
DEBUG - 2025-05-08 16:12:46 --> No URI present. Default controller set.
INFO - 2025-05-08 16:12:46 --> Router Class Initialized
INFO - 2025-05-08 16:12:46 --> Output Class Initialized
INFO - 2025-05-08 16:12:46 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:46 --> Input Class Initialized
INFO - 2025-05-08 16:12:46 --> Language Class Initialized
INFO - 2025-05-08 16:12:46 --> Loader Class Initialized
INFO - 2025-05-08 16:12:46 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:46 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:46 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:46 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:46 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:46 --> Controller Class Initialized
INFO - 2025-05-08 16:12:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:12:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:12:46 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:12:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:12:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:12:46 --> Final output sent to browser
DEBUG - 2025-05-08 16:12:46 --> Total execution time: 0.0035
INFO - 2025-05-08 16:12:52 --> Config Class Initialized
INFO - 2025-05-08 16:12:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:12:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:12:52 --> Utf8 Class Initialized
INFO - 2025-05-08 16:12:52 --> URI Class Initialized
INFO - 2025-05-08 16:12:52 --> Router Class Initialized
INFO - 2025-05-08 16:12:52 --> Output Class Initialized
INFO - 2025-05-08 16:12:52 --> Security Class Initialized
DEBUG - 2025-05-08 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:12:52 --> Input Class Initialized
INFO - 2025-05-08 16:12:52 --> Language Class Initialized
INFO - 2025-05-08 16:12:52 --> Loader Class Initialized
INFO - 2025-05-08 16:12:52 --> Helper loaded: url_helper
INFO - 2025-05-08 16:12:52 --> Helper loaded: string_helper
INFO - 2025-05-08 16:12:52 --> Helper loaded: form_helper
INFO - 2025-05-08 16:12:52 --> Helper loaded: file_helper
INFO - 2025-05-08 16:12:52 --> Helper loaded: html_helper
INFO - 2025-05-08 16:12:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:12:52 --> Controller Class Initialized
INFO - 2025-05-08 16:12:52 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:14:07 --> Config Class Initialized
INFO - 2025-05-08 16:14:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:14:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:14:07 --> Utf8 Class Initialized
INFO - 2025-05-08 16:14:07 --> URI Class Initialized
DEBUG - 2025-05-08 16:14:07 --> No URI present. Default controller set.
INFO - 2025-05-08 16:14:07 --> Router Class Initialized
INFO - 2025-05-08 16:14:07 --> Output Class Initialized
INFO - 2025-05-08 16:14:07 --> Security Class Initialized
DEBUG - 2025-05-08 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:14:07 --> Input Class Initialized
INFO - 2025-05-08 16:14:07 --> Language Class Initialized
INFO - 2025-05-08 16:14:07 --> Loader Class Initialized
INFO - 2025-05-08 16:14:07 --> Helper loaded: url_helper
INFO - 2025-05-08 16:14:07 --> Helper loaded: string_helper
INFO - 2025-05-08 16:14:07 --> Helper loaded: form_helper
INFO - 2025-05-08 16:14:07 --> Helper loaded: file_helper
INFO - 2025-05-08 16:14:07 --> Helper loaded: html_helper
INFO - 2025-05-08 16:14:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:14:07 --> Controller Class Initialized
INFO - 2025-05-08 16:14:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:14:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:14:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:14:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:14:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:14:07 --> Final output sent to browser
DEBUG - 2025-05-08 16:14:07 --> Total execution time: 0.0289
INFO - 2025-05-08 16:20:11 --> Config Class Initialized
INFO - 2025-05-08 16:20:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:20:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:20:11 --> Utf8 Class Initialized
INFO - 2025-05-08 16:20:11 --> URI Class Initialized
DEBUG - 2025-05-08 16:20:11 --> No URI present. Default controller set.
INFO - 2025-05-08 16:20:11 --> Router Class Initialized
INFO - 2025-05-08 16:20:11 --> Output Class Initialized
INFO - 2025-05-08 16:20:11 --> Security Class Initialized
DEBUG - 2025-05-08 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:20:11 --> Input Class Initialized
INFO - 2025-05-08 16:20:11 --> Language Class Initialized
INFO - 2025-05-08 16:20:11 --> Loader Class Initialized
INFO - 2025-05-08 16:20:11 --> Helper loaded: url_helper
INFO - 2025-05-08 16:20:11 --> Helper loaded: string_helper
INFO - 2025-05-08 16:20:11 --> Helper loaded: form_helper
INFO - 2025-05-08 16:20:11 --> Helper loaded: file_helper
INFO - 2025-05-08 16:20:11 --> Helper loaded: html_helper
INFO - 2025-05-08 16:20:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:20:11 --> Controller Class Initialized
INFO - 2025-05-08 16:20:11 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:20:11 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:20:11 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:20:11 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:20:11 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:20:11 --> Final output sent to browser
DEBUG - 2025-05-08 16:20:11 --> Total execution time: 0.0310
INFO - 2025-05-08 16:23:57 --> Config Class Initialized
INFO - 2025-05-08 16:23:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:23:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:23:57 --> Utf8 Class Initialized
INFO - 2025-05-08 16:23:57 --> URI Class Initialized
INFO - 2025-05-08 16:23:57 --> Router Class Initialized
INFO - 2025-05-08 16:23:57 --> Output Class Initialized
INFO - 2025-05-08 16:23:57 --> Security Class Initialized
DEBUG - 2025-05-08 16:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:23:57 --> Input Class Initialized
INFO - 2025-05-08 16:23:57 --> Language Class Initialized
INFO - 2025-05-08 16:23:57 --> Loader Class Initialized
INFO - 2025-05-08 16:23:57 --> Helper loaded: url_helper
INFO - 2025-05-08 16:23:57 --> Helper loaded: string_helper
INFO - 2025-05-08 16:23:57 --> Helper loaded: form_helper
INFO - 2025-05-08 16:23:57 --> Helper loaded: file_helper
INFO - 2025-05-08 16:23:57 --> Helper loaded: html_helper
INFO - 2025-05-08 16:23:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:23:57 --> Controller Class Initialized
INFO - 2025-05-08 16:24:03 --> Config Class Initialized
INFO - 2025-05-08 16:24:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:24:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:24:03 --> Utf8 Class Initialized
INFO - 2025-05-08 16:24:03 --> URI Class Initialized
INFO - 2025-05-08 16:24:03 --> Router Class Initialized
INFO - 2025-05-08 16:24:03 --> Output Class Initialized
INFO - 2025-05-08 16:24:03 --> Security Class Initialized
DEBUG - 2025-05-08 16:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:24:03 --> Input Class Initialized
INFO - 2025-05-08 16:24:03 --> Language Class Initialized
INFO - 2025-05-08 16:24:03 --> Loader Class Initialized
INFO - 2025-05-08 16:24:03 --> Helper loaded: url_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: string_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: form_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: file_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: html_helper
INFO - 2025-05-08 16:24:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:24:03 --> Controller Class Initialized
INFO - 2025-05-08 16:24:03 --> Config Class Initialized
INFO - 2025-05-08 16:24:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:24:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:24:03 --> Utf8 Class Initialized
INFO - 2025-05-08 16:24:03 --> URI Class Initialized
DEBUG - 2025-05-08 16:24:03 --> No URI present. Default controller set.
INFO - 2025-05-08 16:24:03 --> Router Class Initialized
INFO - 2025-05-08 16:24:03 --> Output Class Initialized
INFO - 2025-05-08 16:24:03 --> Security Class Initialized
DEBUG - 2025-05-08 16:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:24:03 --> Input Class Initialized
INFO - 2025-05-08 16:24:03 --> Language Class Initialized
INFO - 2025-05-08 16:24:03 --> Loader Class Initialized
INFO - 2025-05-08 16:24:03 --> Helper loaded: url_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: string_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: form_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: file_helper
INFO - 2025-05-08 16:24:03 --> Helper loaded: html_helper
INFO - 2025-05-08 16:24:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:24:03 --> Controller Class Initialized
INFO - 2025-05-08 16:24:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:24:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:24:03 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:24:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:24:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:24:03 --> Final output sent to browser
DEBUG - 2025-05-08 16:24:03 --> Total execution time: 0.0041
INFO - 2025-05-08 16:24:06 --> Config Class Initialized
INFO - 2025-05-08 16:24:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:24:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:24:06 --> Utf8 Class Initialized
INFO - 2025-05-08 16:24:06 --> URI Class Initialized
INFO - 2025-05-08 16:24:06 --> Router Class Initialized
INFO - 2025-05-08 16:24:06 --> Output Class Initialized
INFO - 2025-05-08 16:24:06 --> Security Class Initialized
DEBUG - 2025-05-08 16:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:24:06 --> Input Class Initialized
INFO - 2025-05-08 16:24:06 --> Language Class Initialized
INFO - 2025-05-08 16:24:06 --> Loader Class Initialized
INFO - 2025-05-08 16:24:06 --> Helper loaded: url_helper
INFO - 2025-05-08 16:24:06 --> Helper loaded: string_helper
INFO - 2025-05-08 16:24:06 --> Helper loaded: form_helper
INFO - 2025-05-08 16:24:06 --> Helper loaded: file_helper
INFO - 2025-05-08 16:24:06 --> Helper loaded: html_helper
INFO - 2025-05-08 16:24:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:24:06 --> Controller Class Initialized
INFO - 2025-05-08 16:24:06 --> Model "AuctionModel" initialized
INFO - 2025-05-08 16:25:46 --> Config Class Initialized
INFO - 2025-05-08 16:25:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:46 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:46 --> URI Class Initialized
DEBUG - 2025-05-08 16:25:46 --> No URI present. Default controller set.
INFO - 2025-05-08 16:25:46 --> Router Class Initialized
INFO - 2025-05-08 16:25:46 --> Output Class Initialized
INFO - 2025-05-08 16:25:46 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:46 --> Input Class Initialized
INFO - 2025-05-08 16:25:46 --> Language Class Initialized
INFO - 2025-05-08 16:25:46 --> Loader Class Initialized
INFO - 2025-05-08 16:25:46 --> Helper loaded: url_helper
INFO - 2025-05-08 16:25:46 --> Helper loaded: string_helper
INFO - 2025-05-08 16:25:46 --> Helper loaded: form_helper
INFO - 2025-05-08 16:25:46 --> Helper loaded: file_helper
INFO - 2025-05-08 16:25:46 --> Helper loaded: html_helper
INFO - 2025-05-08 16:25:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:25:46 --> Controller Class Initialized
INFO - 2025-05-08 16:25:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:25:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:25:46 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:25:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:25:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:25:46 --> Final output sent to browser
DEBUG - 2025-05-08 16:25:46 --> Total execution time: 0.0293
INFO - 2025-05-08 16:25:47 --> Config Class Initialized
INFO - 2025-05-08 16:25:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:47 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:47 --> URI Class Initialized
INFO - 2025-05-08 16:25:47 --> Router Class Initialized
INFO - 2025-05-08 16:25:47 --> Output Class Initialized
INFO - 2025-05-08 16:25:47 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:47 --> Input Class Initialized
INFO - 2025-05-08 16:25:47 --> Language Class Initialized
ERROR - 2025-05-08 16:25:47 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2025-05-08 16:25:47 --> Config Class Initialized
INFO - 2025-05-08 16:25:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:47 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:47 --> URI Class Initialized
INFO - 2025-05-08 16:25:47 --> Router Class Initialized
INFO - 2025-05-08 16:25:47 --> Output Class Initialized
INFO - 2025-05-08 16:25:47 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:47 --> Input Class Initialized
INFO - 2025-05-08 16:25:47 --> Language Class Initialized
ERROR - 2025-05-08 16:25:47 --> 404 Page Not Found: Wp-admin/install.php
INFO - 2025-05-08 16:25:47 --> Config Class Initialized
INFO - 2025-05-08 16:25:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:47 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:47 --> URI Class Initialized
INFO - 2025-05-08 16:25:47 --> Router Class Initialized
INFO - 2025-05-08 16:25:47 --> Output Class Initialized
INFO - 2025-05-08 16:25:47 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:47 --> Input Class Initialized
INFO - 2025-05-08 16:25:47 --> Language Class Initialized
ERROR - 2025-05-08 16:25:47 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2025-05-08 16:25:48 --> Config Class Initialized
INFO - 2025-05-08 16:25:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:48 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:48 --> URI Class Initialized
INFO - 2025-05-08 16:25:48 --> Router Class Initialized
INFO - 2025-05-08 16:25:48 --> Output Class Initialized
INFO - 2025-05-08 16:25:48 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:48 --> Input Class Initialized
INFO - 2025-05-08 16:25:48 --> Language Class Initialized
ERROR - 2025-05-08 16:25:48 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2025-05-08 16:25:48 --> Config Class Initialized
INFO - 2025-05-08 16:25:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:48 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:48 --> URI Class Initialized
INFO - 2025-05-08 16:25:48 --> Router Class Initialized
INFO - 2025-05-08 16:25:48 --> Output Class Initialized
INFO - 2025-05-08 16:25:48 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:48 --> Input Class Initialized
INFO - 2025-05-08 16:25:48 --> Language Class Initialized
ERROR - 2025-05-08 16:25:48 --> 404 Page Not Found: Wp/wp-admin
INFO - 2025-05-08 16:25:48 --> Config Class Initialized
INFO - 2025-05-08 16:25:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:48 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:48 --> URI Class Initialized
INFO - 2025-05-08 16:25:48 --> Router Class Initialized
INFO - 2025-05-08 16:25:48 --> Output Class Initialized
INFO - 2025-05-08 16:25:48 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:48 --> Input Class Initialized
INFO - 2025-05-08 16:25:48 --> Language Class Initialized
ERROR - 2025-05-08 16:25:48 --> 404 Page Not Found: Wp/wp-admin
INFO - 2025-05-08 16:25:49 --> Config Class Initialized
INFO - 2025-05-08 16:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:49 --> URI Class Initialized
INFO - 2025-05-08 16:25:49 --> Router Class Initialized
INFO - 2025-05-08 16:25:49 --> Output Class Initialized
INFO - 2025-05-08 16:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:49 --> Input Class Initialized
INFO - 2025-05-08 16:25:49 --> Language Class Initialized
ERROR - 2025-05-08 16:25:49 --> 404 Page Not Found: New/wp-admin
INFO - 2025-05-08 16:25:49 --> Config Class Initialized
INFO - 2025-05-08 16:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:49 --> URI Class Initialized
INFO - 2025-05-08 16:25:49 --> Router Class Initialized
INFO - 2025-05-08 16:25:49 --> Output Class Initialized
INFO - 2025-05-08 16:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:49 --> Input Class Initialized
INFO - 2025-05-08 16:25:49 --> Language Class Initialized
ERROR - 2025-05-08 16:25:49 --> 404 Page Not Found: New/wp-admin
INFO - 2025-05-08 16:25:49 --> Config Class Initialized
INFO - 2025-05-08 16:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:49 --> URI Class Initialized
INFO - 2025-05-08 16:25:49 --> Router Class Initialized
INFO - 2025-05-08 16:25:49 --> Output Class Initialized
INFO - 2025-05-08 16:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:49 --> Input Class Initialized
INFO - 2025-05-08 16:25:49 --> Language Class Initialized
ERROR - 2025-05-08 16:25:49 --> 404 Page Not Found: Old/wp-admin
INFO - 2025-05-08 16:25:49 --> Config Class Initialized
INFO - 2025-05-08 16:25:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:49 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:49 --> URI Class Initialized
INFO - 2025-05-08 16:25:49 --> Router Class Initialized
INFO - 2025-05-08 16:25:49 --> Output Class Initialized
INFO - 2025-05-08 16:25:49 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:49 --> Input Class Initialized
INFO - 2025-05-08 16:25:49 --> Language Class Initialized
ERROR - 2025-05-08 16:25:49 --> 404 Page Not Found: Old/wp-admin
INFO - 2025-05-08 16:25:50 --> Config Class Initialized
INFO - 2025-05-08 16:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:50 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:50 --> URI Class Initialized
INFO - 2025-05-08 16:25:50 --> Router Class Initialized
INFO - 2025-05-08 16:25:50 --> Output Class Initialized
INFO - 2025-05-08 16:25:50 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:50 --> Input Class Initialized
INFO - 2025-05-08 16:25:50 --> Language Class Initialized
ERROR - 2025-05-08 16:25:50 --> 404 Page Not Found: Blog/wp-admin
INFO - 2025-05-08 16:25:50 --> Config Class Initialized
INFO - 2025-05-08 16:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:50 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:50 --> URI Class Initialized
INFO - 2025-05-08 16:25:50 --> Router Class Initialized
INFO - 2025-05-08 16:25:50 --> Output Class Initialized
INFO - 2025-05-08 16:25:50 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:50 --> Input Class Initialized
INFO - 2025-05-08 16:25:50 --> Language Class Initialized
ERROR - 2025-05-08 16:25:50 --> 404 Page Not Found: Blog/wp-admin
INFO - 2025-05-08 16:25:50 --> Config Class Initialized
INFO - 2025-05-08 16:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:50 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:50 --> URI Class Initialized
INFO - 2025-05-08 16:25:50 --> Router Class Initialized
INFO - 2025-05-08 16:25:50 --> Output Class Initialized
INFO - 2025-05-08 16:25:50 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:50 --> Input Class Initialized
INFO - 2025-05-08 16:25:50 --> Language Class Initialized
ERROR - 2025-05-08 16:25:50 --> 404 Page Not Found: Test/wp-admin
INFO - 2025-05-08 16:25:51 --> Config Class Initialized
INFO - 2025-05-08 16:25:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:51 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:51 --> URI Class Initialized
INFO - 2025-05-08 16:25:51 --> Router Class Initialized
INFO - 2025-05-08 16:25:51 --> Output Class Initialized
INFO - 2025-05-08 16:25:51 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:51 --> Input Class Initialized
INFO - 2025-05-08 16:25:51 --> Language Class Initialized
ERROR - 2025-05-08 16:25:51 --> 404 Page Not Found: Test/wp-admin
INFO - 2025-05-08 16:25:51 --> Config Class Initialized
INFO - 2025-05-08 16:25:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:51 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:51 --> URI Class Initialized
INFO - 2025-05-08 16:25:51 --> Router Class Initialized
INFO - 2025-05-08 16:25:51 --> Output Class Initialized
INFO - 2025-05-08 16:25:51 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:51 --> Input Class Initialized
INFO - 2025-05-08 16:25:51 --> Language Class Initialized
ERROR - 2025-05-08 16:25:51 --> 404 Page Not Found: Shop/wp-admin
INFO - 2025-05-08 16:25:51 --> Config Class Initialized
INFO - 2025-05-08 16:25:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:25:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:25:51 --> Utf8 Class Initialized
INFO - 2025-05-08 16:25:51 --> URI Class Initialized
INFO - 2025-05-08 16:25:51 --> Router Class Initialized
INFO - 2025-05-08 16:25:51 --> Output Class Initialized
INFO - 2025-05-08 16:25:51 --> Security Class Initialized
DEBUG - 2025-05-08 16:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:25:51 --> Input Class Initialized
INFO - 2025-05-08 16:25:51 --> Language Class Initialized
ERROR - 2025-05-08 16:25:51 --> 404 Page Not Found: Shop/wp-admin
INFO - 2025-05-08 16:30:40 --> Config Class Initialized
INFO - 2025-05-08 16:30:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:30:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:30:40 --> Utf8 Class Initialized
INFO - 2025-05-08 16:30:40 --> URI Class Initialized
DEBUG - 2025-05-08 16:30:40 --> No URI present. Default controller set.
INFO - 2025-05-08 16:30:40 --> Router Class Initialized
INFO - 2025-05-08 16:30:40 --> Output Class Initialized
INFO - 2025-05-08 16:30:40 --> Security Class Initialized
DEBUG - 2025-05-08 16:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:30:40 --> Input Class Initialized
INFO - 2025-05-08 16:30:40 --> Language Class Initialized
INFO - 2025-05-08 16:30:40 --> Loader Class Initialized
INFO - 2025-05-08 16:30:40 --> Helper loaded: url_helper
INFO - 2025-05-08 16:30:40 --> Helper loaded: string_helper
INFO - 2025-05-08 16:30:40 --> Helper loaded: form_helper
INFO - 2025-05-08 16:30:40 --> Helper loaded: file_helper
INFO - 2025-05-08 16:30:40 --> Helper loaded: html_helper
INFO - 2025-05-08 16:30:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:30:40 --> Controller Class Initialized
INFO - 2025-05-08 16:30:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:30:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:30:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:30:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:30:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:30:40 --> Final output sent to browser
DEBUG - 2025-05-08 16:30:40 --> Total execution time: 0.0288
INFO - 2025-05-08 16:39:28 --> Config Class Initialized
INFO - 2025-05-08 16:39:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:39:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:39:28 --> Utf8 Class Initialized
INFO - 2025-05-08 16:39:28 --> URI Class Initialized
DEBUG - 2025-05-08 16:39:28 --> No URI present. Default controller set.
INFO - 2025-05-08 16:39:28 --> Router Class Initialized
INFO - 2025-05-08 16:39:28 --> Output Class Initialized
INFO - 2025-05-08 16:39:28 --> Security Class Initialized
DEBUG - 2025-05-08 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:39:28 --> Input Class Initialized
INFO - 2025-05-08 16:39:28 --> Language Class Initialized
INFO - 2025-05-08 16:39:28 --> Loader Class Initialized
INFO - 2025-05-08 16:39:28 --> Helper loaded: url_helper
INFO - 2025-05-08 16:39:28 --> Helper loaded: string_helper
INFO - 2025-05-08 16:39:28 --> Helper loaded: form_helper
INFO - 2025-05-08 16:39:28 --> Helper loaded: file_helper
INFO - 2025-05-08 16:39:28 --> Helper loaded: html_helper
INFO - 2025-05-08 16:39:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:39:28 --> Controller Class Initialized
INFO - 2025-05-08 16:39:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:39:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:39:28 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:39:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:39:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:39:28 --> Final output sent to browser
DEBUG - 2025-05-08 16:39:28 --> Total execution time: 0.0296
INFO - 2025-05-08 16:55:00 --> Config Class Initialized
INFO - 2025-05-08 16:55:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 16:55:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 16:55:00 --> Utf8 Class Initialized
INFO - 2025-05-08 16:55:00 --> URI Class Initialized
DEBUG - 2025-05-08 16:55:00 --> No URI present. Default controller set.
INFO - 2025-05-08 16:55:00 --> Router Class Initialized
INFO - 2025-05-08 16:55:00 --> Output Class Initialized
INFO - 2025-05-08 16:55:00 --> Security Class Initialized
DEBUG - 2025-05-08 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 16:55:00 --> Input Class Initialized
INFO - 2025-05-08 16:55:00 --> Language Class Initialized
INFO - 2025-05-08 16:55:00 --> Loader Class Initialized
INFO - 2025-05-08 16:55:00 --> Helper loaded: url_helper
INFO - 2025-05-08 16:55:00 --> Helper loaded: string_helper
INFO - 2025-05-08 16:55:00 --> Helper loaded: form_helper
INFO - 2025-05-08 16:55:00 --> Helper loaded: file_helper
INFO - 2025-05-08 16:55:00 --> Helper loaded: html_helper
INFO - 2025-05-08 16:55:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 16:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 16:55:00 --> Controller Class Initialized
INFO - 2025-05-08 16:55:00 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 16:55:00 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 16:55:00 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 16:55:00 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 16:55:00 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 16:55:00 --> Final output sent to browser
DEBUG - 2025-05-08 16:55:00 --> Total execution time: 0.0315
INFO - 2025-05-08 17:36:40 --> Config Class Initialized
INFO - 2025-05-08 17:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:36:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:36:40 --> Utf8 Class Initialized
INFO - 2025-05-08 17:36:40 --> URI Class Initialized
INFO - 2025-05-08 17:36:40 --> Router Class Initialized
INFO - 2025-05-08 17:36:40 --> Output Class Initialized
INFO - 2025-05-08 17:36:40 --> Security Class Initialized
DEBUG - 2025-05-08 17:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:36:40 --> Input Class Initialized
INFO - 2025-05-08 17:36:40 --> Language Class Initialized
ERROR - 2025-05-08 17:36:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-08 17:39:51 --> Config Class Initialized
INFO - 2025-05-08 17:39:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:51 --> URI Class Initialized
INFO - 2025-05-08 17:39:51 --> Router Class Initialized
INFO - 2025-05-08 17:39:51 --> Output Class Initialized
INFO - 2025-05-08 17:39:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:51 --> Input Class Initialized
INFO - 2025-05-08 17:39:51 --> Language Class Initialized
INFO - 2025-05-08 17:39:51 --> Loader Class Initialized
INFO - 2025-05-08 17:39:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:51 --> Controller Class Initialized
INFO - 2025-05-08 17:39:51 --> Model "UserModel" initialized
INFO - 2025-05-08 17:39:52 --> Config Class Initialized
INFO - 2025-05-08 17:39:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:52 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:52 --> URI Class Initialized
DEBUG - 2025-05-08 17:39:52 --> No URI present. Default controller set.
INFO - 2025-05-08 17:39:52 --> Router Class Initialized
INFO - 2025-05-08 17:39:52 --> Output Class Initialized
INFO - 2025-05-08 17:39:52 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:52 --> Input Class Initialized
INFO - 2025-05-08 17:39:52 --> Language Class Initialized
INFO - 2025-05-08 17:39:52 --> Loader Class Initialized
INFO - 2025-05-08 17:39:52 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:52 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:52 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:52 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:52 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:52 --> Controller Class Initialized
INFO - 2025-05-08 17:39:52 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:39:52 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:39:52 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:39:52 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:39:52 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:39:52 --> Final output sent to browser
DEBUG - 2025-05-08 17:39:52 --> Total execution time: 0.0079
INFO - 2025-05-08 17:39:56 --> Config Class Initialized
INFO - 2025-05-08 17:39:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:56 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:56 --> URI Class Initialized
INFO - 2025-05-08 17:39:56 --> Router Class Initialized
INFO - 2025-05-08 17:39:56 --> Output Class Initialized
INFO - 2025-05-08 17:39:56 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:56 --> Input Class Initialized
INFO - 2025-05-08 17:39:56 --> Language Class Initialized
INFO - 2025-05-08 17:39:56 --> Loader Class Initialized
INFO - 2025-05-08 17:39:56 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:56 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:56 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:56 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:56 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:56 --> Controller Class Initialized
INFO - 2025-05-08 17:39:56 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:39:57 --> Config Class Initialized
INFO - 2025-05-08 17:39:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:57 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:57 --> URI Class Initialized
INFO - 2025-05-08 17:39:57 --> Router Class Initialized
INFO - 2025-05-08 17:39:57 --> Output Class Initialized
INFO - 2025-05-08 17:39:57 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:57 --> Input Class Initialized
INFO - 2025-05-08 17:39:57 --> Language Class Initialized
INFO - 2025-05-08 17:39:57 --> Loader Class Initialized
INFO - 2025-05-08 17:39:57 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:57 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:57 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:57 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:57 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:57 --> Controller Class Initialized
INFO - 2025-05-08 17:39:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:39:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:39:57 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 17:39:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:39:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:39:57 --> Final output sent to browser
DEBUG - 2025-05-08 17:39:57 --> Total execution time: 0.0051
INFO - 2025-05-08 17:39:59 --> Config Class Initialized
INFO - 2025-05-08 17:39:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:59 --> URI Class Initialized
INFO - 2025-05-08 17:39:59 --> Router Class Initialized
INFO - 2025-05-08 17:39:59 --> Output Class Initialized
INFO - 2025-05-08 17:39:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:59 --> Input Class Initialized
INFO - 2025-05-08 17:39:59 --> Language Class Initialized
INFO - 2025-05-08 17:39:59 --> Loader Class Initialized
INFO - 2025-05-08 17:39:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:59 --> Controller Class Initialized
INFO - 2025-05-08 17:39:59 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:39:59 --> Final output sent to browser
DEBUG - 2025-05-08 17:39:59 --> Total execution time: 0.0044
INFO - 2025-05-08 17:39:59 --> Config Class Initialized
INFO - 2025-05-08 17:39:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:39:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:39:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:39:59 --> URI Class Initialized
INFO - 2025-05-08 17:39:59 --> Router Class Initialized
INFO - 2025-05-08 17:39:59 --> Output Class Initialized
INFO - 2025-05-08 17:39:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:39:59 --> Input Class Initialized
INFO - 2025-05-08 17:39:59 --> Language Class Initialized
INFO - 2025-05-08 17:39:59 --> Loader Class Initialized
INFO - 2025-05-08 17:39:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:39:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:39:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:39:59 --> Controller Class Initialized
INFO - 2025-05-08 17:39:59 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:39:59 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:39:59 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:39:59 --> Final output sent to browser
DEBUG - 2025-05-08 17:39:59 --> Total execution time: 0.0118
INFO - 2025-05-08 17:40:00 --> Config Class Initialized
INFO - 2025-05-08 17:40:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:00 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:00 --> URI Class Initialized
INFO - 2025-05-08 17:40:00 --> Router Class Initialized
INFO - 2025-05-08 17:40:00 --> Output Class Initialized
INFO - 2025-05-08 17:40:00 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:00 --> Input Class Initialized
INFO - 2025-05-08 17:40:00 --> Language Class Initialized
INFO - 2025-05-08 17:40:00 --> Loader Class Initialized
INFO - 2025-05-08 17:40:00 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:00 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:00 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:00 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:00 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:00 --> Controller Class Initialized
INFO - 2025-05-08 17:40:00 --> Model "UserModel" initialized
INFO - 2025-05-08 17:40:00 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:00 --> Total execution time: 0.0067
INFO - 2025-05-08 17:40:03 --> Config Class Initialized
INFO - 2025-05-08 17:40:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:03 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:03 --> URI Class Initialized
INFO - 2025-05-08 17:40:03 --> Router Class Initialized
INFO - 2025-05-08 17:40:03 --> Output Class Initialized
INFO - 2025-05-08 17:40:03 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:03 --> Input Class Initialized
INFO - 2025-05-08 17:40:03 --> Language Class Initialized
INFO - 2025-05-08 17:40:03 --> Loader Class Initialized
INFO - 2025-05-08 17:40:03 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:03 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:03 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:03 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:03 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:03 --> Controller Class Initialized
INFO - 2025-05-08 17:40:03 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:40:03 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:40:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:40:03 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:40:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:40:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:40:03 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:03 --> Total execution time: 0.0088
INFO - 2025-05-08 17:40:04 --> Config Class Initialized
INFO - 2025-05-08 17:40:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:04 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:04 --> URI Class Initialized
INFO - 2025-05-08 17:40:04 --> Router Class Initialized
INFO - 2025-05-08 17:40:04 --> Output Class Initialized
INFO - 2025-05-08 17:40:04 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:04 --> Input Class Initialized
INFO - 2025-05-08 17:40:04 --> Language Class Initialized
INFO - 2025-05-08 17:40:04 --> Loader Class Initialized
INFO - 2025-05-08 17:40:04 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:04 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:04 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:04 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:04 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:04 --> Controller Class Initialized
INFO - 2025-05-08 17:40:04 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:04 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:04 --> Total execution time: 0.0049
INFO - 2025-05-08 17:40:05 --> Config Class Initialized
INFO - 2025-05-08 17:40:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:05 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:05 --> URI Class Initialized
INFO - 2025-05-08 17:40:05 --> Router Class Initialized
INFO - 2025-05-08 17:40:05 --> Output Class Initialized
INFO - 2025-05-08 17:40:05 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:05 --> Input Class Initialized
INFO - 2025-05-08 17:40:05 --> Language Class Initialized
INFO - 2025-05-08 17:40:05 --> Loader Class Initialized
INFO - 2025-05-08 17:40:05 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:05 --> Controller Class Initialized
INFO - 2025-05-08 17:40:05 --> Model "UserModel" initialized
INFO - 2025-05-08 17:40:05 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:05 --> Total execution time: 0.0027
INFO - 2025-05-08 17:40:05 --> Config Class Initialized
INFO - 2025-05-08 17:40:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:05 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:05 --> URI Class Initialized
INFO - 2025-05-08 17:40:05 --> Router Class Initialized
INFO - 2025-05-08 17:40:05 --> Output Class Initialized
INFO - 2025-05-08 17:40:05 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:05 --> Input Class Initialized
INFO - 2025-05-08 17:40:05 --> Language Class Initialized
INFO - 2025-05-08 17:40:05 --> Loader Class Initialized
INFO - 2025-05-08 17:40:05 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:05 --> Controller Class Initialized
INFO - 2025-05-08 17:40:05 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:05 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:05 --> Total execution time: 0.0027
INFO - 2025-05-08 17:40:05 --> Config Class Initialized
INFO - 2025-05-08 17:40:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:05 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:05 --> URI Class Initialized
INFO - 2025-05-08 17:40:05 --> Router Class Initialized
INFO - 2025-05-08 17:40:05 --> Output Class Initialized
INFO - 2025-05-08 17:40:05 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:05 --> Input Class Initialized
INFO - 2025-05-08 17:40:05 --> Language Class Initialized
INFO - 2025-05-08 17:40:05 --> Loader Class Initialized
INFO - 2025-05-08 17:40:05 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:05 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:05 --> Controller Class Initialized
INFO - 2025-05-08 17:40:06 --> Config Class Initialized
INFO - 2025-05-08 17:40:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:06 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:06 --> URI Class Initialized
INFO - 2025-05-08 17:40:06 --> Router Class Initialized
INFO - 2025-05-08 17:40:06 --> Output Class Initialized
INFO - 2025-05-08 17:40:06 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:06 --> Input Class Initialized
INFO - 2025-05-08 17:40:06 --> Language Class Initialized
INFO - 2025-05-08 17:40:06 --> Loader Class Initialized
INFO - 2025-05-08 17:40:06 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:06 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:06 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:06 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:06 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:06 --> Controller Class Initialized
INFO - 2025-05-08 17:40:06 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:23 --> Config Class Initialized
INFO - 2025-05-08 17:40:23 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:23 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:23 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:23 --> URI Class Initialized
INFO - 2025-05-08 17:40:23 --> Router Class Initialized
INFO - 2025-05-08 17:40:23 --> Output Class Initialized
INFO - 2025-05-08 17:40:23 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:23 --> Input Class Initialized
INFO - 2025-05-08 17:40:23 --> Language Class Initialized
INFO - 2025-05-08 17:40:23 --> Loader Class Initialized
INFO - 2025-05-08 17:40:23 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:23 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:23 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:23 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:23 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:23 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:23 --> Controller Class Initialized
INFO - 2025-05-08 17:40:23 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:40:23 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:23 --> Total execution time: 0.0072
INFO - 2025-05-08 17:40:25 --> Config Class Initialized
INFO - 2025-05-08 17:40:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:25 --> URI Class Initialized
INFO - 2025-05-08 17:40:25 --> Router Class Initialized
INFO - 2025-05-08 17:40:25 --> Output Class Initialized
INFO - 2025-05-08 17:40:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:25 --> Input Class Initialized
INFO - 2025-05-08 17:40:25 --> Language Class Initialized
INFO - 2025-05-08 17:40:25 --> Loader Class Initialized
INFO - 2025-05-08 17:40:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:25 --> Controller Class Initialized
INFO - 2025-05-08 17:40:25 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:41 --> Config Class Initialized
INFO - 2025-05-08 17:40:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:41 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:41 --> URI Class Initialized
DEBUG - 2025-05-08 17:40:41 --> No URI present. Default controller set.
INFO - 2025-05-08 17:40:41 --> Router Class Initialized
INFO - 2025-05-08 17:40:41 --> Output Class Initialized
INFO - 2025-05-08 17:40:41 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:41 --> Input Class Initialized
INFO - 2025-05-08 17:40:41 --> Language Class Initialized
INFO - 2025-05-08 17:40:41 --> Loader Class Initialized
INFO - 2025-05-08 17:40:41 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:41 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:41 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:41 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:41 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:41 --> Controller Class Initialized
INFO - 2025-05-08 17:40:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:40:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:40:41 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:40:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:40:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:40:41 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:41 --> Total execution time: 0.0041
INFO - 2025-05-08 17:40:42 --> Config Class Initialized
INFO - 2025-05-08 17:40:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:42 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:42 --> URI Class Initialized
INFO - 2025-05-08 17:40:42 --> Router Class Initialized
INFO - 2025-05-08 17:40:42 --> Output Class Initialized
INFO - 2025-05-08 17:40:42 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:42 --> Input Class Initialized
INFO - 2025-05-08 17:40:42 --> Language Class Initialized
INFO - 2025-05-08 17:40:42 --> Loader Class Initialized
INFO - 2025-05-08 17:40:42 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:42 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:42 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:42 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:42 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:42 --> Controller Class Initialized
INFO - 2025-05-08 17:40:42 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:45 --> Config Class Initialized
INFO - 2025-05-08 17:40:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:45 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:45 --> URI Class Initialized
DEBUG - 2025-05-08 17:40:45 --> No URI present. Default controller set.
INFO - 2025-05-08 17:40:45 --> Router Class Initialized
INFO - 2025-05-08 17:40:45 --> Output Class Initialized
INFO - 2025-05-08 17:40:45 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:45 --> Input Class Initialized
INFO - 2025-05-08 17:40:45 --> Language Class Initialized
INFO - 2025-05-08 17:40:45 --> Loader Class Initialized
INFO - 2025-05-08 17:40:45 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:45 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:45 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:45 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:45 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:45 --> Controller Class Initialized
INFO - 2025-05-08 17:40:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:40:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:40:45 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:40:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:40:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:40:45 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:45 --> Total execution time: 0.0035
INFO - 2025-05-08 17:40:48 --> Config Class Initialized
INFO - 2025-05-08 17:40:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:48 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:48 --> URI Class Initialized
INFO - 2025-05-08 17:40:48 --> Router Class Initialized
INFO - 2025-05-08 17:40:48 --> Output Class Initialized
INFO - 2025-05-08 17:40:48 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:48 --> Input Class Initialized
INFO - 2025-05-08 17:40:48 --> Language Class Initialized
INFO - 2025-05-08 17:40:48 --> Loader Class Initialized
INFO - 2025-05-08 17:40:48 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:48 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:48 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:48 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:48 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:48 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:48 --> Controller Class Initialized
INFO - 2025-05-08 17:40:48 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:51 --> Config Class Initialized
INFO - 2025-05-08 17:40:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:51 --> URI Class Initialized
INFO - 2025-05-08 17:40:51 --> Router Class Initialized
INFO - 2025-05-08 17:40:51 --> Output Class Initialized
INFO - 2025-05-08 17:40:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:51 --> Input Class Initialized
INFO - 2025-05-08 17:40:51 --> Language Class Initialized
INFO - 2025-05-08 17:40:51 --> Loader Class Initialized
INFO - 2025-05-08 17:40:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:51 --> Controller Class Initialized
INFO - 2025-05-08 17:40:51 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:40:51 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:51 --> Total execution time: 0.0064
INFO - 2025-05-08 17:40:52 --> Config Class Initialized
INFO - 2025-05-08 17:40:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:52 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:52 --> URI Class Initialized
INFO - 2025-05-08 17:40:52 --> Router Class Initialized
INFO - 2025-05-08 17:40:52 --> Output Class Initialized
INFO - 2025-05-08 17:40:52 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:52 --> Input Class Initialized
INFO - 2025-05-08 17:40:52 --> Language Class Initialized
INFO - 2025-05-08 17:40:52 --> Loader Class Initialized
INFO - 2025-05-08 17:40:52 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:52 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:52 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:52 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:52 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:52 --> Controller Class Initialized
INFO - 2025-05-08 17:40:52 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:54 --> Config Class Initialized
INFO - 2025-05-08 17:40:54 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:54 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:54 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:54 --> URI Class Initialized
DEBUG - 2025-05-08 17:40:54 --> No URI present. Default controller set.
INFO - 2025-05-08 17:40:54 --> Router Class Initialized
INFO - 2025-05-08 17:40:54 --> Output Class Initialized
INFO - 2025-05-08 17:40:54 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:54 --> Input Class Initialized
INFO - 2025-05-08 17:40:54 --> Language Class Initialized
INFO - 2025-05-08 17:40:54 --> Loader Class Initialized
INFO - 2025-05-08 17:40:54 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:54 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:54 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:54 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:54 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:54 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:54 --> Controller Class Initialized
INFO - 2025-05-08 17:40:54 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:40:54 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:40:54 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:40:54 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:40:54 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:40:54 --> Final output sent to browser
DEBUG - 2025-05-08 17:40:54 --> Total execution time: 0.0028
INFO - 2025-05-08 17:40:57 --> Config Class Initialized
INFO - 2025-05-08 17:40:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:57 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:57 --> URI Class Initialized
INFO - 2025-05-08 17:40:57 --> Router Class Initialized
INFO - 2025-05-08 17:40:57 --> Output Class Initialized
INFO - 2025-05-08 17:40:57 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:57 --> Input Class Initialized
INFO - 2025-05-08 17:40:57 --> Language Class Initialized
INFO - 2025-05-08 17:40:57 --> Loader Class Initialized
INFO - 2025-05-08 17:40:57 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:57 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:57 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:57 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:57 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:57 --> Controller Class Initialized
INFO - 2025-05-08 17:40:57 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Config Class Initialized
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
INFO - 2025-05-08 17:40:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> URI Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
INFO - 2025-05-08 17:40:59 --> Router Class Initialized
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:59 --> Output Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Security Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Input Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:59 --> Language Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> Loader Class Initialized
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
INFO - 2025-05-08 17:40:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:40:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:40:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
DEBUG - 2025-05-08 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
INFO - 2025-05-08 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:40:59 --> Controller Class Initialized
INFO - 2025-05-08 17:41:10 --> Config Class Initialized
INFO - 2025-05-08 17:41:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:10 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:10 --> URI Class Initialized
DEBUG - 2025-05-08 17:41:10 --> No URI present. Default controller set.
INFO - 2025-05-08 17:41:10 --> Router Class Initialized
INFO - 2025-05-08 17:41:10 --> Output Class Initialized
INFO - 2025-05-08 17:41:10 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:10 --> Input Class Initialized
INFO - 2025-05-08 17:41:10 --> Language Class Initialized
INFO - 2025-05-08 17:41:10 --> Loader Class Initialized
INFO - 2025-05-08 17:41:10 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:10 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:10 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:10 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:10 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:10 --> Controller Class Initialized
INFO - 2025-05-08 17:41:10 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:41:10 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:41:10 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:41:10 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:41:10 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:41:10 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:10 --> Total execution time: 0.0028
INFO - 2025-05-08 17:41:15 --> Config Class Initialized
INFO - 2025-05-08 17:41:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:15 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:15 --> URI Class Initialized
INFO - 2025-05-08 17:41:15 --> Router Class Initialized
INFO - 2025-05-08 17:41:15 --> Output Class Initialized
INFO - 2025-05-08 17:41:15 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:15 --> Input Class Initialized
INFO - 2025-05-08 17:41:15 --> Language Class Initialized
INFO - 2025-05-08 17:41:15 --> Loader Class Initialized
INFO - 2025-05-08 17:41:15 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:15 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:15 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:15 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:15 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:15 --> Controller Class Initialized
INFO - 2025-05-08 17:41:15 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
INFO - 2025-05-08 17:41:16 --> Config Class Initialized
INFO - 2025-05-08 17:41:16 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
DEBUG - 2025-05-08 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
INFO - 2025-05-08 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> URI Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:16 --> Router Class Initialized
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Output Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Security Class Initialized
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:16 --> Input Class Initialized
INFO - 2025-05-08 17:41:16 --> Language Class Initialized
INFO - 2025-05-08 17:41:16 --> Loader Class Initialized
INFO - 2025-05-08 17:41:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:16 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
INFO - 2025-05-08 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:16 --> Controller Class Initialized
INFO - 2025-05-08 17:41:22 --> Config Class Initialized
INFO - 2025-05-08 17:41:22 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:22 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:22 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:22 --> URI Class Initialized
INFO - 2025-05-08 17:41:22 --> Router Class Initialized
INFO - 2025-05-08 17:41:22 --> Output Class Initialized
INFO - 2025-05-08 17:41:22 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:22 --> Input Class Initialized
INFO - 2025-05-08 17:41:22 --> Language Class Initialized
INFO - 2025-05-08 17:41:22 --> Loader Class Initialized
INFO - 2025-05-08 17:41:22 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:22 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:22 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:22 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:22 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:22 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:22 --> Controller Class Initialized
INFO - 2025-05-08 17:41:22 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:41:22 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:41:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:41:22 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:41:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:41:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:41:22 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:22 --> Total execution time: 0.0036
INFO - 2025-05-08 17:41:25 --> Config Class Initialized
INFO - 2025-05-08 17:41:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:25 --> URI Class Initialized
INFO - 2025-05-08 17:41:25 --> Router Class Initialized
INFO - 2025-05-08 17:41:25 --> Output Class Initialized
INFO - 2025-05-08 17:41:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:25 --> Input Class Initialized
INFO - 2025-05-08 17:41:25 --> Language Class Initialized
INFO - 2025-05-08 17:41:25 --> Loader Class Initialized
INFO - 2025-05-08 17:41:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:25 --> Controller Class Initialized
INFO - 2025-05-08 17:41:25 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:25 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:25 --> Total execution time: 0.0030
INFO - 2025-05-08 17:41:26 --> Config Class Initialized
INFO - 2025-05-08 17:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:26 --> URI Class Initialized
INFO - 2025-05-08 17:41:26 --> Router Class Initialized
INFO - 2025-05-08 17:41:26 --> Output Class Initialized
INFO - 2025-05-08 17:41:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:26 --> Input Class Initialized
INFO - 2025-05-08 17:41:26 --> Language Class Initialized
INFO - 2025-05-08 17:41:26 --> Loader Class Initialized
INFO - 2025-05-08 17:41:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:26 --> Controller Class Initialized
INFO - 2025-05-08 17:41:26 --> Model "UserModel" initialized
INFO - 2025-05-08 17:41:26 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:26 --> Total execution time: 0.0025
INFO - 2025-05-08 17:41:26 --> Config Class Initialized
INFO - 2025-05-08 17:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:26 --> URI Class Initialized
INFO - 2025-05-08 17:41:26 --> Router Class Initialized
INFO - 2025-05-08 17:41:26 --> Output Class Initialized
INFO - 2025-05-08 17:41:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:26 --> Input Class Initialized
INFO - 2025-05-08 17:41:26 --> Language Class Initialized
INFO - 2025-05-08 17:41:26 --> Loader Class Initialized
INFO - 2025-05-08 17:41:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:26 --> Controller Class Initialized
INFO - 2025-05-08 17:41:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:26 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:26 --> Total execution time: 0.0029
INFO - 2025-05-08 17:41:27 --> Config Class Initialized
INFO - 2025-05-08 17:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:27 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:27 --> URI Class Initialized
INFO - 2025-05-08 17:41:27 --> Router Class Initialized
INFO - 2025-05-08 17:41:27 --> Output Class Initialized
INFO - 2025-05-08 17:41:27 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:27 --> Input Class Initialized
INFO - 2025-05-08 17:41:27 --> Language Class Initialized
INFO - 2025-05-08 17:41:27 --> Loader Class Initialized
INFO - 2025-05-08 17:41:27 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:27 --> Controller Class Initialized
INFO - 2025-05-08 17:41:27 --> Config Class Initialized
INFO - 2025-05-08 17:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:27 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:27 --> URI Class Initialized
INFO - 2025-05-08 17:41:27 --> Router Class Initialized
INFO - 2025-05-08 17:41:27 --> Output Class Initialized
INFO - 2025-05-08 17:41:27 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:27 --> Input Class Initialized
INFO - 2025-05-08 17:41:27 --> Language Class Initialized
INFO - 2025-05-08 17:41:27 --> Loader Class Initialized
INFO - 2025-05-08 17:41:27 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:27 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:27 --> Controller Class Initialized
INFO - 2025-05-08 17:41:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:28 --> Config Class Initialized
INFO - 2025-05-08 17:41:28 --> Hooks Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
DEBUG - 2025-05-08 17:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> URI Class Initialized
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Router Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Output Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Security Class Initialized
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Input Class Initialized
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:28 --> Language Class Initialized
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
INFO - 2025-05-08 17:41:28 --> Loader Class Initialized
INFO - 2025-05-08 17:41:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-08 17:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:28 --> Controller Class Initialized
INFO - 2025-05-08 17:41:32 --> Config Class Initialized
INFO - 2025-05-08 17:41:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:32 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:32 --> URI Class Initialized
INFO - 2025-05-08 17:41:32 --> Router Class Initialized
INFO - 2025-05-08 17:41:32 --> Output Class Initialized
INFO - 2025-05-08 17:41:32 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:32 --> Input Class Initialized
INFO - 2025-05-08 17:41:32 --> Language Class Initialized
INFO - 2025-05-08 17:41:32 --> Loader Class Initialized
INFO - 2025-05-08 17:41:32 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:32 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:32 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:32 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:32 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:32 --> Controller Class Initialized
INFO - 2025-05-08 17:41:32 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:43 --> Config Class Initialized
INFO - 2025-05-08 17:41:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:43 --> URI Class Initialized
INFO - 2025-05-08 17:41:43 --> Router Class Initialized
INFO - 2025-05-08 17:41:43 --> Output Class Initialized
INFO - 2025-05-08 17:41:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:43 --> Input Class Initialized
INFO - 2025-05-08 17:41:43 --> Language Class Initialized
INFO - 2025-05-08 17:41:43 --> Loader Class Initialized
INFO - 2025-05-08 17:41:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:43 --> Controller Class Initialized
INFO - 2025-05-08 17:41:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:47 --> Config Class Initialized
INFO - 2025-05-08 17:41:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:47 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:47 --> URI Class Initialized
DEBUG - 2025-05-08 17:41:47 --> No URI present. Default controller set.
INFO - 2025-05-08 17:41:47 --> Router Class Initialized
INFO - 2025-05-08 17:41:47 --> Output Class Initialized
INFO - 2025-05-08 17:41:47 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:47 --> Input Class Initialized
INFO - 2025-05-08 17:41:47 --> Language Class Initialized
INFO - 2025-05-08 17:41:47 --> Loader Class Initialized
INFO - 2025-05-08 17:41:47 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:47 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:47 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:47 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:47 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:47 --> Controller Class Initialized
INFO - 2025-05-08 17:41:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:41:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:41:47 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:41:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:41:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:41:47 --> Final output sent to browser
DEBUG - 2025-05-08 17:41:47 --> Total execution time: 0.0028
INFO - 2025-05-08 17:41:49 --> Config Class Initialized
INFO - 2025-05-08 17:41:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:49 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:49 --> URI Class Initialized
INFO - 2025-05-08 17:41:49 --> Router Class Initialized
INFO - 2025-05-08 17:41:49 --> Output Class Initialized
INFO - 2025-05-08 17:41:49 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:49 --> Input Class Initialized
INFO - 2025-05-08 17:41:49 --> Language Class Initialized
INFO - 2025-05-08 17:41:49 --> Loader Class Initialized
INFO - 2025-05-08 17:41:49 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:49 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:49 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:49 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:49 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:49 --> Controller Class Initialized
INFO - 2025-05-08 17:41:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:41:51 --> Config Class Initialized
INFO - 2025-05-08 17:41:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:51 --> URI Class Initialized
INFO - 2025-05-08 17:41:51 --> Router Class Initialized
INFO - 2025-05-08 17:41:51 --> Output Class Initialized
INFO - 2025-05-08 17:41:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:51 --> Input Class Initialized
INFO - 2025-05-08 17:41:51 --> Language Class Initialized
INFO - 2025-05-08 17:41:51 --> Loader Class Initialized
INFO - 2025-05-08 17:41:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:51 --> Config Class Initialized
INFO - 2025-05-08 17:41:51 --> Controller Class Initialized
INFO - 2025-05-08 17:41:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:41:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:41:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:41:51 --> URI Class Initialized
INFO - 2025-05-08 17:41:51 --> Router Class Initialized
INFO - 2025-05-08 17:41:51 --> Output Class Initialized
INFO - 2025-05-08 17:41:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:41:51 --> Input Class Initialized
INFO - 2025-05-08 17:41:51 --> Language Class Initialized
INFO - 2025-05-08 17:41:51 --> Loader Class Initialized
INFO - 2025-05-08 17:41:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:41:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:41:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:41:51 --> Controller Class Initialized
INFO - 2025-05-08 17:42:15 --> Config Class Initialized
INFO - 2025-05-08 17:42:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:15 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:15 --> URI Class Initialized
INFO - 2025-05-08 17:42:15 --> Router Class Initialized
INFO - 2025-05-08 17:42:15 --> Output Class Initialized
INFO - 2025-05-08 17:42:15 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:15 --> Input Class Initialized
INFO - 2025-05-08 17:42:15 --> Language Class Initialized
INFO - 2025-05-08 17:42:15 --> Loader Class Initialized
INFO - 2025-05-08 17:42:15 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:15 --> Controller Class Initialized
INFO - 2025-05-08 17:42:15 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:42:15 --> Final output sent to browser
DEBUG - 2025-05-08 17:42:15 --> Total execution time: 0.0103
INFO - 2025-05-08 17:42:15 --> Config Class Initialized
INFO - 2025-05-08 17:42:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:15 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:15 --> URI Class Initialized
INFO - 2025-05-08 17:42:15 --> Router Class Initialized
INFO - 2025-05-08 17:42:15 --> Output Class Initialized
INFO - 2025-05-08 17:42:15 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:15 --> Input Class Initialized
INFO - 2025-05-08 17:42:15 --> Language Class Initialized
INFO - 2025-05-08 17:42:15 --> Loader Class Initialized
INFO - 2025-05-08 17:42:15 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:15 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:15 --> Controller Class Initialized
INFO - 2025-05-08 17:42:15 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:42:19 --> Config Class Initialized
INFO - 2025-05-08 17:42:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:19 --> URI Class Initialized
DEBUG - 2025-05-08 17:42:19 --> No URI present. Default controller set.
INFO - 2025-05-08 17:42:19 --> Router Class Initialized
INFO - 2025-05-08 17:42:19 --> Output Class Initialized
INFO - 2025-05-08 17:42:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:19 --> Input Class Initialized
INFO - 2025-05-08 17:42:19 --> Language Class Initialized
INFO - 2025-05-08 17:42:19 --> Loader Class Initialized
INFO - 2025-05-08 17:42:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:19 --> Controller Class Initialized
INFO - 2025-05-08 17:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:42:19 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:42:19 --> Final output sent to browser
DEBUG - 2025-05-08 17:42:19 --> Total execution time: 0.0030
INFO - 2025-05-08 17:42:22 --> Config Class Initialized
INFO - 2025-05-08 17:42:22 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:22 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:22 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:22 --> URI Class Initialized
INFO - 2025-05-08 17:42:22 --> Router Class Initialized
INFO - 2025-05-08 17:42:22 --> Output Class Initialized
INFO - 2025-05-08 17:42:22 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:22 --> Input Class Initialized
INFO - 2025-05-08 17:42:22 --> Language Class Initialized
INFO - 2025-05-08 17:42:22 --> Loader Class Initialized
INFO - 2025-05-08 17:42:22 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:22 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:22 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:22 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:22 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:22 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:22 --> Controller Class Initialized
INFO - 2025-05-08 17:42:22 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:42:25 --> Config Class Initialized
INFO - 2025-05-08 17:42:25 --> Config Class Initialized
INFO - 2025-05-08 17:42:25 --> Hooks Class Initialized
INFO - 2025-05-08 17:42:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:42:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:25 --> URI Class Initialized
INFO - 2025-05-08 17:42:25 --> URI Class Initialized
INFO - 2025-05-08 17:42:25 --> Config Class Initialized
INFO - 2025-05-08 17:42:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:25 --> URI Class Initialized
INFO - 2025-05-08 17:42:25 --> Router Class Initialized
INFO - 2025-05-08 17:42:25 --> Output Class Initialized
INFO - 2025-05-08 17:42:25 --> Router Class Initialized
INFO - 2025-05-08 17:42:25 --> Security Class Initialized
INFO - 2025-05-08 17:42:25 --> Config Class Initialized
INFO - 2025-05-08 17:42:25 --> Output Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:25 --> Input Class Initialized
INFO - 2025-05-08 17:42:25 --> Router Class Initialized
INFO - 2025-05-08 17:42:25 --> Security Class Initialized
INFO - 2025-05-08 17:42:25 --> Language Class Initialized
INFO - 2025-05-08 17:42:25 --> Hooks Class Initialized
INFO - 2025-05-08 17:42:25 --> Output Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:25 --> Config Class Initialized
INFO - 2025-05-08 17:42:25 --> Input Class Initialized
INFO - 2025-05-08 17:42:25 --> Security Class Initialized
INFO - 2025-05-08 17:42:25 --> Loader Class Initialized
INFO - 2025-05-08 17:42:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:25 --> Language Class Initialized
INFO - 2025-05-08 17:42:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:25 --> Input Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: url_helper
DEBUG - 2025-05-08 17:42:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:25 --> Language Class Initialized
INFO - 2025-05-08 17:42:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:25 --> Loader Class Initialized
INFO - 2025-05-08 17:42:25 --> URI Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:25 --> Loader Class Initialized
INFO - 2025-05-08 17:42:25 --> URI Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:25 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:25 --> Router Class Initialized
INFO - 2025-05-08 17:42:25 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:25 --> Output Class Initialized
INFO - 2025-05-08 17:42:25 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:25 --> Security Class Initialized
INFO - 2025-05-08 17:42:25 --> Router Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:25 --> Input Class Initialized
INFO - 2025-05-08 17:42:25 --> Output Class Initialized
INFO - 2025-05-08 17:42:25 --> Language Class Initialized
INFO - 2025-05-08 17:42:25 --> Security Class Initialized
INFO - 2025-05-08 17:42:25 --> Loader Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: url_helper
DEBUG - 2025-05-08 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:25 --> Input Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:25 --> Language Class Initialized
INFO - 2025-05-08 17:42:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:25 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:25 --> Loader Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:25 --> Helper loaded: url_helper
DEBUG - 2025-05-08 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:25 --> Controller Class Initialized
INFO - 2025-05-08 17:42:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:25 --> Controller Class Initialized
DEBUG - 2025-05-08 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:25 --> Controller Class Initialized
INFO - 2025-05-08 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:25 --> Controller Class Initialized
INFO - 2025-05-08 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:25 --> Controller Class Initialized
INFO - 2025-05-08 17:42:39 --> Config Class Initialized
INFO - 2025-05-08 17:42:39 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:39 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:39 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:39 --> URI Class Initialized
INFO - 2025-05-08 17:42:39 --> Router Class Initialized
INFO - 2025-05-08 17:42:39 --> Output Class Initialized
INFO - 2025-05-08 17:42:39 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:39 --> Input Class Initialized
INFO - 2025-05-08 17:42:39 --> Language Class Initialized
INFO - 2025-05-08 17:42:39 --> Loader Class Initialized
INFO - 2025-05-08 17:42:39 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:39 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:39 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:39 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:39 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:39 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:39 --> Controller Class Initialized
INFO - 2025-05-08 17:42:39 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:42:44 --> Config Class Initialized
INFO - 2025-05-08 17:42:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:44 --> URI Class Initialized
DEBUG - 2025-05-08 17:42:44 --> No URI present. Default controller set.
INFO - 2025-05-08 17:42:44 --> Router Class Initialized
INFO - 2025-05-08 17:42:44 --> Output Class Initialized
INFO - 2025-05-08 17:42:44 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:44 --> Input Class Initialized
INFO - 2025-05-08 17:42:44 --> Language Class Initialized
INFO - 2025-05-08 17:42:44 --> Loader Class Initialized
INFO - 2025-05-08 17:42:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:44 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:44 --> Controller Class Initialized
INFO - 2025-05-08 17:42:44 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:42:44 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:42:44 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:42:44 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:42:44 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:42:44 --> Final output sent to browser
DEBUG - 2025-05-08 17:42:44 --> Total execution time: 0.0035
INFO - 2025-05-08 17:42:47 --> Config Class Initialized
INFO - 2025-05-08 17:42:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:47 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:47 --> URI Class Initialized
INFO - 2025-05-08 17:42:47 --> Router Class Initialized
INFO - 2025-05-08 17:42:47 --> Output Class Initialized
INFO - 2025-05-08 17:42:47 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:47 --> Input Class Initialized
INFO - 2025-05-08 17:42:47 --> Language Class Initialized
INFO - 2025-05-08 17:42:47 --> Loader Class Initialized
INFO - 2025-05-08 17:42:47 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:47 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:47 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:47 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:47 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:47 --> Controller Class Initialized
INFO - 2025-05-08 17:42:47 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:42:48 --> Config Class Initialized
INFO - 2025-05-08 17:42:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:48 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:48 --> URI Class Initialized
INFO - 2025-05-08 17:42:48 --> Router Class Initialized
INFO - 2025-05-08 17:42:48 --> Output Class Initialized
INFO - 2025-05-08 17:42:48 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:48 --> Input Class Initialized
INFO - 2025-05-08 17:42:48 --> Language Class Initialized
INFO - 2025-05-08 17:42:48 --> Loader Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:48 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:48 --> Controller Class Initialized
INFO - 2025-05-08 17:42:48 --> Config Class Initialized
INFO - 2025-05-08 17:42:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:48 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:48 --> URI Class Initialized
INFO - 2025-05-08 17:42:48 --> Config Class Initialized
INFO - 2025-05-08 17:42:48 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:48 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:48 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:48 --> URI Class Initialized
INFO - 2025-05-08 17:42:48 --> Router Class Initialized
INFO - 2025-05-08 17:42:48 --> Config Class Initialized
INFO - 2025-05-08 17:42:48 --> Hooks Class Initialized
INFO - 2025-05-08 17:42:48 --> Output Class Initialized
INFO - 2025-05-08 17:42:48 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:48 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:48 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:48 --> Input Class Initialized
INFO - 2025-05-08 17:42:48 --> Language Class Initialized
INFO - 2025-05-08 17:42:48 --> Router Class Initialized
INFO - 2025-05-08 17:42:48 --> URI Class Initialized
INFO - 2025-05-08 17:42:48 --> Loader Class Initialized
INFO - 2025-05-08 17:42:48 --> Output Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:48 --> Security Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: string_helper
DEBUG - 2025-05-08 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:48 --> Input Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:48 --> Language Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:48 --> Router Class Initialized
INFO - 2025-05-08 17:42:48 --> Loader Class Initialized
INFO - 2025-05-08 17:42:48 --> Output Class Initialized
INFO - 2025-05-08 17:42:48 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:48 --> Security Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: string_helper
DEBUG - 2025-05-08 17:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:48 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:48 --> Input Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:48 --> Language Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:48 --> Loader Class Initialized
INFO - 2025-05-08 17:42:48 --> Database Driver Class Initialized
INFO - 2025-05-08 17:42:48 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:48 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:48 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:48 --> Controller Class Initialized
DEBUG - 2025-05-08 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:48 --> Controller Class Initialized
INFO - 2025-05-08 17:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:48 --> Controller Class Initialized
INFO - 2025-05-08 17:42:53 --> Config Class Initialized
INFO - 2025-05-08 17:42:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:53 --> URI Class Initialized
DEBUG - 2025-05-08 17:42:53 --> No URI present. Default controller set.
INFO - 2025-05-08 17:42:53 --> Router Class Initialized
INFO - 2025-05-08 17:42:53 --> Output Class Initialized
INFO - 2025-05-08 17:42:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:53 --> Input Class Initialized
INFO - 2025-05-08 17:42:53 --> Language Class Initialized
INFO - 2025-05-08 17:42:53 --> Loader Class Initialized
INFO - 2025-05-08 17:42:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:53 --> Controller Class Initialized
INFO - 2025-05-08 17:42:53 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:42:53 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:42:53 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:42:53 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:42:53 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:42:53 --> Final output sent to browser
DEBUG - 2025-05-08 17:42:53 --> Total execution time: 0.0038
INFO - 2025-05-08 17:42:54 --> Config Class Initialized
INFO - 2025-05-08 17:42:54 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:54 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:54 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:54 --> URI Class Initialized
INFO - 2025-05-08 17:42:54 --> Router Class Initialized
INFO - 2025-05-08 17:42:54 --> Output Class Initialized
INFO - 2025-05-08 17:42:54 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:54 --> Input Class Initialized
INFO - 2025-05-08 17:42:54 --> Language Class Initialized
INFO - 2025-05-08 17:42:54 --> Loader Class Initialized
INFO - 2025-05-08 17:42:54 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:54 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:54 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:54 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:54 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:54 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:54 --> Controller Class Initialized
INFO - 2025-05-08 17:42:54 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:42:56 --> Config Class Initialized
INFO - 2025-05-08 17:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:56 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:56 --> URI Class Initialized
INFO - 2025-05-08 17:42:56 --> Router Class Initialized
INFO - 2025-05-08 17:42:56 --> Output Class Initialized
INFO - 2025-05-08 17:42:56 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:56 --> Input Class Initialized
INFO - 2025-05-08 17:42:56 --> Language Class Initialized
INFO - 2025-05-08 17:42:56 --> Loader Class Initialized
INFO - 2025-05-08 17:42:56 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:56 --> Controller Class Initialized
INFO - 2025-05-08 17:42:56 --> Config Class Initialized
INFO - 2025-05-08 17:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:56 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:56 --> URI Class Initialized
INFO - 2025-05-08 17:42:56 --> Router Class Initialized
INFO - 2025-05-08 17:42:56 --> Output Class Initialized
INFO - 2025-05-08 17:42:56 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:56 --> Input Class Initialized
INFO - 2025-05-08 17:42:56 --> Language Class Initialized
INFO - 2025-05-08 17:42:56 --> Loader Class Initialized
INFO - 2025-05-08 17:42:56 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:56 --> Controller Class Initialized
INFO - 2025-05-08 17:42:56 --> Config Class Initialized
INFO - 2025-05-08 17:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:56 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:56 --> URI Class Initialized
INFO - 2025-05-08 17:42:56 --> Router Class Initialized
INFO - 2025-05-08 17:42:56 --> Output Class Initialized
INFO - 2025-05-08 17:42:56 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:56 --> Input Class Initialized
INFO - 2025-05-08 17:42:56 --> Language Class Initialized
INFO - 2025-05-08 17:42:56 --> Loader Class Initialized
INFO - 2025-05-08 17:42:56 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:56 --> Controller Class Initialized
INFO - 2025-05-08 17:42:56 --> Config Class Initialized
INFO - 2025-05-08 17:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:42:56 --> Utf8 Class Initialized
INFO - 2025-05-08 17:42:56 --> URI Class Initialized
INFO - 2025-05-08 17:42:56 --> Router Class Initialized
INFO - 2025-05-08 17:42:56 --> Output Class Initialized
INFO - 2025-05-08 17:42:56 --> Security Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:42:56 --> Input Class Initialized
INFO - 2025-05-08 17:42:56 --> Language Class Initialized
INFO - 2025-05-08 17:42:56 --> Loader Class Initialized
INFO - 2025-05-08 17:42:56 --> Helper loaded: url_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: string_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: form_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: file_helper
INFO - 2025-05-08 17:42:56 --> Helper loaded: html_helper
INFO - 2025-05-08 17:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:42:56 --> Controller Class Initialized
INFO - 2025-05-08 17:43:00 --> Config Class Initialized
INFO - 2025-05-08 17:43:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:00 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:00 --> URI Class Initialized
INFO - 2025-05-08 17:43:00 --> Router Class Initialized
INFO - 2025-05-08 17:43:00 --> Output Class Initialized
INFO - 2025-05-08 17:43:00 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:00 --> Input Class Initialized
INFO - 2025-05-08 17:43:00 --> Language Class Initialized
INFO - 2025-05-08 17:43:00 --> Loader Class Initialized
INFO - 2025-05-08 17:43:00 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:00 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:00 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:00 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:00 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:00 --> Controller Class Initialized
INFO - 2025-05-08 17:43:00 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:04 --> Config Class Initialized
INFO - 2025-05-08 17:43:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:04 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:04 --> URI Class Initialized
DEBUG - 2025-05-08 17:43:04 --> No URI present. Default controller set.
INFO - 2025-05-08 17:43:04 --> Router Class Initialized
INFO - 2025-05-08 17:43:04 --> Output Class Initialized
INFO - 2025-05-08 17:43:04 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:04 --> Input Class Initialized
INFO - 2025-05-08 17:43:04 --> Language Class Initialized
INFO - 2025-05-08 17:43:04 --> Loader Class Initialized
INFO - 2025-05-08 17:43:04 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:04 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:04 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:04 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:04 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:04 --> Controller Class Initialized
INFO - 2025-05-08 17:43:04 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:43:04 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:43:04 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:43:04 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:43:04 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:43:04 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:04 --> Total execution time: 0.0030
INFO - 2025-05-08 17:43:08 --> Config Class Initialized
INFO - 2025-05-08 17:43:08 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:08 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:08 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:08 --> URI Class Initialized
INFO - 2025-05-08 17:43:08 --> Router Class Initialized
INFO - 2025-05-08 17:43:08 --> Output Class Initialized
INFO - 2025-05-08 17:43:08 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:08 --> Input Class Initialized
INFO - 2025-05-08 17:43:08 --> Language Class Initialized
INFO - 2025-05-08 17:43:08 --> Loader Class Initialized
INFO - 2025-05-08 17:43:08 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:08 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:08 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:08 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:08 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:08 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:08 --> Controller Class Initialized
INFO - 2025-05-08 17:43:08 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:10 --> Config Class Initialized
INFO - 2025-05-08 17:43:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:10 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:10 --> URI Class Initialized
INFO - 2025-05-08 17:43:10 --> Router Class Initialized
INFO - 2025-05-08 17:43:10 --> Output Class Initialized
INFO - 2025-05-08 17:43:10 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:10 --> Input Class Initialized
INFO - 2025-05-08 17:43:10 --> Language Class Initialized
INFO - 2025-05-08 17:43:10 --> Loader Class Initialized
INFO - 2025-05-08 17:43:10 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:10 --> Controller Class Initialized
INFO - 2025-05-08 17:43:10 --> Config Class Initialized
INFO - 2025-05-08 17:43:10 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:10 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:10 --> URI Class Initialized
INFO - 2025-05-08 17:43:10 --> Router Class Initialized
INFO - 2025-05-08 17:43:10 --> Output Class Initialized
INFO - 2025-05-08 17:43:10 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:10 --> Input Class Initialized
INFO - 2025-05-08 17:43:10 --> Language Class Initialized
INFO - 2025-05-08 17:43:10 --> Loader Class Initialized
INFO - 2025-05-08 17:43:10 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:10 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:10 --> Config Class Initialized
INFO - 2025-05-08 17:43:10 --> Hooks Class Initialized
INFO - 2025-05-08 17:43:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-08 17:43:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:10 --> Controller Class Initialized
INFO - 2025-05-08 17:43:10 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:10 --> URI Class Initialized
INFO - 2025-05-08 17:43:10 --> Config Class Initialized
INFO - 2025-05-08 17:43:10 --> Hooks Class Initialized
INFO - 2025-05-08 17:43:10 --> Router Class Initialized
INFO - 2025-05-08 17:43:10 --> Output Class Initialized
DEBUG - 2025-05-08 17:43:10 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:10 --> Security Class Initialized
INFO - 2025-05-08 17:43:10 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:10 --> Input Class Initialized
INFO - 2025-05-08 17:43:10 --> URI Class Initialized
INFO - 2025-05-08 17:43:10 --> Language Class Initialized
INFO - 2025-05-08 17:43:10 --> Loader Class Initialized
INFO - 2025-05-08 17:43:10 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:10 --> Database Driver Class Initialized
INFO - 2025-05-08 17:43:10 --> Router Class Initialized
INFO - 2025-05-08 17:43:10 --> Output Class Initialized
INFO - 2025-05-08 17:43:10 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:10 --> Input Class Initialized
INFO - 2025-05-08 17:43:10 --> Language Class Initialized
INFO - 2025-05-08 17:43:10 --> Loader Class Initialized
INFO - 2025-05-08 17:43:10 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:10 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:10 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:10 --> Database Driver Class Initialized
INFO - 2025-05-08 17:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:10 --> Controller Class Initialized
DEBUG - 2025-05-08 17:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:10 --> Controller Class Initialized
INFO - 2025-05-08 17:43:11 --> Config Class Initialized
INFO - 2025-05-08 17:43:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:11 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:11 --> URI Class Initialized
DEBUG - 2025-05-08 17:43:11 --> No URI present. Default controller set.
INFO - 2025-05-08 17:43:11 --> Router Class Initialized
INFO - 2025-05-08 17:43:11 --> Output Class Initialized
INFO - 2025-05-08 17:43:11 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:11 --> Input Class Initialized
INFO - 2025-05-08 17:43:11 --> Language Class Initialized
INFO - 2025-05-08 17:43:11 --> Loader Class Initialized
INFO - 2025-05-08 17:43:11 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:11 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:11 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:11 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:11 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:11 --> Controller Class Initialized
INFO - 2025-05-08 17:43:11 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:43:11 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:43:11 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:43:11 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:43:11 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:43:11 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:11 --> Total execution time: 0.0028
INFO - 2025-05-08 17:43:16 --> Config Class Initialized
INFO - 2025-05-08 17:43:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:16 --> URI Class Initialized
INFO - 2025-05-08 17:43:16 --> Router Class Initialized
INFO - 2025-05-08 17:43:16 --> Output Class Initialized
INFO - 2025-05-08 17:43:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:16 --> Input Class Initialized
INFO - 2025-05-08 17:43:16 --> Language Class Initialized
INFO - 2025-05-08 17:43:16 --> Loader Class Initialized
INFO - 2025-05-08 17:43:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:16 --> Controller Class Initialized
INFO - 2025-05-08 17:43:16 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:18 --> Config Class Initialized
INFO - 2025-05-08 17:43:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:18 --> URI Class Initialized
INFO - 2025-05-08 17:43:18 --> Router Class Initialized
INFO - 2025-05-08 17:43:18 --> Output Class Initialized
INFO - 2025-05-08 17:43:18 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:18 --> Input Class Initialized
INFO - 2025-05-08 17:43:18 --> Language Class Initialized
INFO - 2025-05-08 17:43:18 --> Loader Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:18 --> Controller Class Initialized
INFO - 2025-05-08 17:43:18 --> Config Class Initialized
INFO - 2025-05-08 17:43:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:18 --> Config Class Initialized
INFO - 2025-05-08 17:43:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:18 --> Hooks Class Initialized
INFO - 2025-05-08 17:43:18 --> URI Class Initialized
DEBUG - 2025-05-08 17:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:18 --> URI Class Initialized
INFO - 2025-05-08 17:43:18 --> Router Class Initialized
INFO - 2025-05-08 17:43:18 --> Output Class Initialized
INFO - 2025-05-08 17:43:18 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:18 --> Input Class Initialized
INFO - 2025-05-08 17:43:18 --> Language Class Initialized
INFO - 2025-05-08 17:43:18 --> Loader Class Initialized
INFO - 2025-05-08 17:43:18 --> Router Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:18 --> Output Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:18 --> Security Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:18 --> Input Class Initialized
INFO - 2025-05-08 17:43:18 --> Database Driver Class Initialized
INFO - 2025-05-08 17:43:18 --> Language Class Initialized
INFO - 2025-05-08 17:43:18 --> Loader Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:18 --> Config Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:18 --> Hooks Class Initialized
INFO - 2025-05-08 17:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:18 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:18 --> URI Class Initialized
INFO - 2025-05-08 17:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:18 --> Controller Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:18 --> Router Class Initialized
INFO - 2025-05-08 17:43:18 --> Output Class Initialized
INFO - 2025-05-08 17:43:18 --> Security Class Initialized
INFO - 2025-05-08 17:43:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-08 17:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:18 --> Controller Class Initialized
INFO - 2025-05-08 17:43:18 --> Input Class Initialized
INFO - 2025-05-08 17:43:18 --> Language Class Initialized
INFO - 2025-05-08 17:43:18 --> Loader Class Initialized
INFO - 2025-05-08 17:43:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:18 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:18 --> Controller Class Initialized
INFO - 2025-05-08 17:43:22 --> Config Class Initialized
INFO - 2025-05-08 17:43:22 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:22 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:22 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:22 --> URI Class Initialized
INFO - 2025-05-08 17:43:22 --> Router Class Initialized
INFO - 2025-05-08 17:43:22 --> Output Class Initialized
INFO - 2025-05-08 17:43:22 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:22 --> Input Class Initialized
INFO - 2025-05-08 17:43:22 --> Language Class Initialized
INFO - 2025-05-08 17:43:22 --> Loader Class Initialized
INFO - 2025-05-08 17:43:22 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:22 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:22 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:22 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:22 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:22 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:22 --> Controller Class Initialized
INFO - 2025-05-08 17:43:22 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:43:22 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:43:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:43:22 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:43:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:43:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:43:22 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:22 --> Total execution time: 0.0050
INFO - 2025-05-08 17:43:25 --> Config Class Initialized
INFO - 2025-05-08 17:43:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:25 --> URI Class Initialized
INFO - 2025-05-08 17:43:25 --> Router Class Initialized
INFO - 2025-05-08 17:43:25 --> Output Class Initialized
INFO - 2025-05-08 17:43:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:25 --> Input Class Initialized
INFO - 2025-05-08 17:43:25 --> Language Class Initialized
INFO - 2025-05-08 17:43:25 --> Loader Class Initialized
INFO - 2025-05-08 17:43:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:25 --> Controller Class Initialized
INFO - 2025-05-08 17:43:25 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:25 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:25 --> Total execution time: 0.0029
INFO - 2025-05-08 17:43:25 --> Config Class Initialized
INFO - 2025-05-08 17:43:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:25 --> URI Class Initialized
INFO - 2025-05-08 17:43:25 --> Router Class Initialized
INFO - 2025-05-08 17:43:25 --> Output Class Initialized
INFO - 2025-05-08 17:43:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:25 --> Input Class Initialized
INFO - 2025-05-08 17:43:25 --> Language Class Initialized
INFO - 2025-05-08 17:43:25 --> Loader Class Initialized
INFO - 2025-05-08 17:43:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:25 --> Controller Class Initialized
INFO - 2025-05-08 17:43:25 --> Model "UserModel" initialized
INFO - 2025-05-08 17:43:25 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:25 --> Total execution time: 0.0026
INFO - 2025-05-08 17:43:25 --> Config Class Initialized
INFO - 2025-05-08 17:43:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:25 --> URI Class Initialized
INFO - 2025-05-08 17:43:25 --> Router Class Initialized
INFO - 2025-05-08 17:43:25 --> Output Class Initialized
INFO - 2025-05-08 17:43:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:25 --> Input Class Initialized
INFO - 2025-05-08 17:43:25 --> Language Class Initialized
INFO - 2025-05-08 17:43:25 --> Loader Class Initialized
INFO - 2025-05-08 17:43:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:25 --> Controller Class Initialized
INFO - 2025-05-08 17:43:25 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:25 --> Final output sent to browser
DEBUG - 2025-05-08 17:43:25 --> Total execution time: 0.0028
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
INFO - 2025-05-08 17:43:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
INFO - 2025-05-08 17:43:26 --> Config Class Initialized
INFO - 2025-05-08 17:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:26 --> URI Class Initialized
INFO - 2025-05-08 17:43:26 --> Router Class Initialized
INFO - 2025-05-08 17:43:26 --> Output Class Initialized
INFO - 2025-05-08 17:43:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:26 --> Input Class Initialized
INFO - 2025-05-08 17:43:26 --> Language Class Initialized
INFO - 2025-05-08 17:43:26 --> Loader Class Initialized
INFO - 2025-05-08 17:43:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:26 --> Controller Class Initialized
INFO - 2025-05-08 17:43:31 --> Config Class Initialized
INFO - 2025-05-08 17:43:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:31 --> URI Class Initialized
INFO - 2025-05-08 17:43:31 --> Router Class Initialized
INFO - 2025-05-08 17:43:31 --> Output Class Initialized
INFO - 2025-05-08 17:43:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:31 --> Input Class Initialized
INFO - 2025-05-08 17:43:31 --> Language Class Initialized
INFO - 2025-05-08 17:43:31 --> Loader Class Initialized
INFO - 2025-05-08 17:43:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:31 --> Controller Class Initialized
INFO - 2025-05-08 17:43:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:43:36 --> Config Class Initialized
INFO - 2025-05-08 17:43:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:43:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:43:36 --> Utf8 Class Initialized
INFO - 2025-05-08 17:43:36 --> URI Class Initialized
INFO - 2025-05-08 17:43:36 --> Router Class Initialized
INFO - 2025-05-08 17:43:36 --> Output Class Initialized
INFO - 2025-05-08 17:43:36 --> Security Class Initialized
DEBUG - 2025-05-08 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:43:36 --> Input Class Initialized
INFO - 2025-05-08 17:43:36 --> Language Class Initialized
INFO - 2025-05-08 17:43:36 --> Loader Class Initialized
INFO - 2025-05-08 17:43:36 --> Helper loaded: url_helper
INFO - 2025-05-08 17:43:36 --> Helper loaded: string_helper
INFO - 2025-05-08 17:43:36 --> Helper loaded: form_helper
INFO - 2025-05-08 17:43:36 --> Helper loaded: file_helper
INFO - 2025-05-08 17:43:36 --> Helper loaded: html_helper
INFO - 2025-05-08 17:43:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:43:36 --> Controller Class Initialized
INFO - 2025-05-08 17:43:36 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:24 --> Config Class Initialized
INFO - 2025-05-08 17:44:24 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:24 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:24 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:24 --> URI Class Initialized
INFO - 2025-05-08 17:44:24 --> Router Class Initialized
INFO - 2025-05-08 17:44:24 --> Output Class Initialized
INFO - 2025-05-08 17:44:24 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:24 --> Input Class Initialized
INFO - 2025-05-08 17:44:24 --> Language Class Initialized
INFO - 2025-05-08 17:44:24 --> Loader Class Initialized
INFO - 2025-05-08 17:44:24 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:24 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:24 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:24 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:24 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:24 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:24 --> Controller Class Initialized
INFO - 2025-05-08 17:44:24 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:44:24 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:24 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:44:24 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:44:24 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:44:24 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:44:24 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:44:24 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:24 --> Total execution time: 0.0358
INFO - 2025-05-08 17:44:27 --> Config Class Initialized
INFO - 2025-05-08 17:44:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:27 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:27 --> URI Class Initialized
INFO - 2025-05-08 17:44:27 --> Router Class Initialized
INFO - 2025-05-08 17:44:27 --> Output Class Initialized
INFO - 2025-05-08 17:44:27 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:27 --> Input Class Initialized
INFO - 2025-05-08 17:44:27 --> Language Class Initialized
INFO - 2025-05-08 17:44:27 --> Loader Class Initialized
INFO - 2025-05-08 17:44:27 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:27 --> Controller Class Initialized
INFO - 2025-05-08 17:44:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:27 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:27 --> Total execution time: 0.0045
INFO - 2025-05-08 17:44:27 --> Config Class Initialized
INFO - 2025-05-08 17:44:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:27 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:27 --> URI Class Initialized
INFO - 2025-05-08 17:44:27 --> Router Class Initialized
INFO - 2025-05-08 17:44:27 --> Output Class Initialized
INFO - 2025-05-08 17:44:27 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:27 --> Input Class Initialized
INFO - 2025-05-08 17:44:27 --> Language Class Initialized
INFO - 2025-05-08 17:44:27 --> Loader Class Initialized
INFO - 2025-05-08 17:44:27 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:27 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:27 --> Controller Class Initialized
INFO - 2025-05-08 17:44:27 --> Model "UserModel" initialized
INFO - 2025-05-08 17:44:27 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:27 --> Total execution time: 0.0067
INFO - 2025-05-08 17:44:28 --> Config Class Initialized
INFO - 2025-05-08 17:44:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:28 --> URI Class Initialized
INFO - 2025-05-08 17:44:28 --> Router Class Initialized
INFO - 2025-05-08 17:44:28 --> Output Class Initialized
INFO - 2025-05-08 17:44:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:28 --> Input Class Initialized
INFO - 2025-05-08 17:44:28 --> Language Class Initialized
INFO - 2025-05-08 17:44:28 --> Loader Class Initialized
INFO - 2025-05-08 17:44:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:28 --> Controller Class Initialized
INFO - 2025-05-08 17:44:28 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:28 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:28 --> Total execution time: 0.0025
INFO - 2025-05-08 17:44:28 --> Config Class Initialized
INFO - 2025-05-08 17:44:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:28 --> URI Class Initialized
INFO - 2025-05-08 17:44:28 --> Router Class Initialized
INFO - 2025-05-08 17:44:28 --> Output Class Initialized
INFO - 2025-05-08 17:44:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:28 --> Input Class Initialized
INFO - 2025-05-08 17:44:28 --> Language Class Initialized
INFO - 2025-05-08 17:44:28 --> Loader Class Initialized
INFO - 2025-05-08 17:44:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:28 --> Controller Class Initialized
INFO - 2025-05-08 17:44:28 --> Config Class Initialized
INFO - 2025-05-08 17:44:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:28 --> URI Class Initialized
INFO - 2025-05-08 17:44:28 --> Router Class Initialized
INFO - 2025-05-08 17:44:28 --> Output Class Initialized
INFO - 2025-05-08 17:44:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:28 --> Input Class Initialized
INFO - 2025-05-08 17:44:28 --> Language Class Initialized
INFO - 2025-05-08 17:44:28 --> Loader Class Initialized
INFO - 2025-05-08 17:44:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:28 --> Controller Class Initialized
INFO - 2025-05-08 17:44:28 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:29 --> Config Class Initialized
INFO - 2025-05-08 17:44:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:29 --> URI Class Initialized
INFO - 2025-05-08 17:44:29 --> Router Class Initialized
INFO - 2025-05-08 17:44:29 --> Output Class Initialized
INFO - 2025-05-08 17:44:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:29 --> Input Class Initialized
INFO - 2025-05-08 17:44:29 --> Language Class Initialized
INFO - 2025-05-08 17:44:29 --> Loader Class Initialized
INFO - 2025-05-08 17:44:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:29 --> Controller Class Initialized
INFO - 2025-05-08 17:44:33 --> Config Class Initialized
INFO - 2025-05-08 17:44:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:33 --> URI Class Initialized
DEBUG - 2025-05-08 17:44:33 --> No URI present. Default controller set.
INFO - 2025-05-08 17:44:33 --> Router Class Initialized
INFO - 2025-05-08 17:44:33 --> Output Class Initialized
INFO - 2025-05-08 17:44:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:33 --> Input Class Initialized
INFO - 2025-05-08 17:44:33 --> Language Class Initialized
INFO - 2025-05-08 17:44:33 --> Loader Class Initialized
INFO - 2025-05-08 17:44:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:33 --> Controller Class Initialized
INFO - 2025-05-08 17:44:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:44:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:44:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:44:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:44:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:44:33 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:33 --> Total execution time: 0.0043
INFO - 2025-05-08 17:44:35 --> Config Class Initialized
INFO - 2025-05-08 17:44:35 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:35 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:35 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:35 --> URI Class Initialized
INFO - 2025-05-08 17:44:35 --> Router Class Initialized
INFO - 2025-05-08 17:44:35 --> Output Class Initialized
INFO - 2025-05-08 17:44:35 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:35 --> Input Class Initialized
INFO - 2025-05-08 17:44:35 --> Language Class Initialized
INFO - 2025-05-08 17:44:35 --> Loader Class Initialized
INFO - 2025-05-08 17:44:35 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:35 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:35 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:35 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:35 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:35 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:35 --> Controller Class Initialized
INFO - 2025-05-08 17:44:35 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:37 --> Config Class Initialized
INFO - 2025-05-08 17:44:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:37 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:37 --> URI Class Initialized
INFO - 2025-05-08 17:44:37 --> Router Class Initialized
INFO - 2025-05-08 17:44:37 --> Output Class Initialized
INFO - 2025-05-08 17:44:37 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:37 --> Input Class Initialized
INFO - 2025-05-08 17:44:37 --> Language Class Initialized
INFO - 2025-05-08 17:44:37 --> Loader Class Initialized
INFO - 2025-05-08 17:44:37 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:37 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:37 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:37 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:37 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:37 --> Controller Class Initialized
INFO - 2025-05-08 17:44:51 --> Config Class Initialized
INFO - 2025-05-08 17:44:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:51 --> URI Class Initialized
INFO - 2025-05-08 17:44:51 --> Router Class Initialized
INFO - 2025-05-08 17:44:51 --> Output Class Initialized
INFO - 2025-05-08 17:44:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:51 --> Input Class Initialized
INFO - 2025-05-08 17:44:51 --> Language Class Initialized
INFO - 2025-05-08 17:44:51 --> Loader Class Initialized
INFO - 2025-05-08 17:44:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:51 --> Controller Class Initialized
INFO - 2025-05-08 17:44:51 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:44:51 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:51 --> Total execution time: 0.0074
INFO - 2025-05-08 17:44:51 --> Config Class Initialized
INFO - 2025-05-08 17:44:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:51 --> URI Class Initialized
INFO - 2025-05-08 17:44:51 --> Router Class Initialized
INFO - 2025-05-08 17:44:51 --> Output Class Initialized
INFO - 2025-05-08 17:44:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:51 --> Input Class Initialized
INFO - 2025-05-08 17:44:51 --> Language Class Initialized
INFO - 2025-05-08 17:44:51 --> Loader Class Initialized
INFO - 2025-05-08 17:44:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:51 --> Controller Class Initialized
INFO - 2025-05-08 17:44:51 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:44:59 --> Config Class Initialized
INFO - 2025-05-08 17:44:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:44:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:44:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:44:59 --> URI Class Initialized
DEBUG - 2025-05-08 17:44:59 --> No URI present. Default controller set.
INFO - 2025-05-08 17:44:59 --> Router Class Initialized
INFO - 2025-05-08 17:44:59 --> Output Class Initialized
INFO - 2025-05-08 17:44:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:44:59 --> Input Class Initialized
INFO - 2025-05-08 17:44:59 --> Language Class Initialized
INFO - 2025-05-08 17:44:59 --> Loader Class Initialized
INFO - 2025-05-08 17:44:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:44:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:44:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:44:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:44:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:44:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:44:59 --> Controller Class Initialized
INFO - 2025-05-08 17:44:59 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:44:59 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:44:59 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:44:59 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:44:59 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:44:59 --> Final output sent to browser
DEBUG - 2025-05-08 17:44:59 --> Total execution time: 0.0034
INFO - 2025-05-08 17:45:00 --> Config Class Initialized
INFO - 2025-05-08 17:45:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:00 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:00 --> URI Class Initialized
INFO - 2025-05-08 17:45:00 --> Router Class Initialized
INFO - 2025-05-08 17:45:00 --> Output Class Initialized
INFO - 2025-05-08 17:45:00 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:00 --> Input Class Initialized
INFO - 2025-05-08 17:45:00 --> Language Class Initialized
INFO - 2025-05-08 17:45:00 --> Loader Class Initialized
INFO - 2025-05-08 17:45:00 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:00 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:00 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:00 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:00 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:00 --> Controller Class Initialized
INFO - 2025-05-08 17:45:00 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:02 --> Config Class Initialized
INFO - 2025-05-08 17:45:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:02 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:02 --> URI Class Initialized
INFO - 2025-05-08 17:45:02 --> Router Class Initialized
INFO - 2025-05-08 17:45:02 --> Output Class Initialized
INFO - 2025-05-08 17:45:02 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:02 --> Input Class Initialized
INFO - 2025-05-08 17:45:02 --> Language Class Initialized
INFO - 2025-05-08 17:45:02 --> Loader Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:02 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:02 --> Config Class Initialized
INFO - 2025-05-08 17:45:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:02 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:02 --> Config Class Initialized
INFO - 2025-05-08 17:45:02 --> Config Class Initialized
INFO - 2025-05-08 17:45:02 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:02 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:02 --> URI Class Initialized
INFO - 2025-05-08 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:02 --> Controller Class Initialized
DEBUG - 2025-05-08 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:45:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:02 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:02 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:02 --> URI Class Initialized
INFO - 2025-05-08 17:45:02 --> URI Class Initialized
INFO - 2025-05-08 17:45:02 --> Router Class Initialized
INFO - 2025-05-08 17:45:02 --> Output Class Initialized
INFO - 2025-05-08 17:45:02 --> Router Class Initialized
INFO - 2025-05-08 17:45:02 --> Output Class Initialized
INFO - 2025-05-08 17:45:02 --> Security Class Initialized
INFO - 2025-05-08 17:45:02 --> Security Class Initialized
INFO - 2025-05-08 17:45:02 --> Router Class Initialized
DEBUG - 2025-05-08 17:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:02 --> Input Class Initialized
INFO - 2025-05-08 17:45:02 --> Input Class Initialized
INFO - 2025-05-08 17:45:02 --> Output Class Initialized
INFO - 2025-05-08 17:45:02 --> Language Class Initialized
INFO - 2025-05-08 17:45:02 --> Language Class Initialized
INFO - 2025-05-08 17:45:02 --> Security Class Initialized
INFO - 2025-05-08 17:45:02 --> Loader Class Initialized
INFO - 2025-05-08 17:45:02 --> Loader Class Initialized
DEBUG - 2025-05-08 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:02 --> Input Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:02 --> Language Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:02 --> Loader Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:02 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:02 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:02 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:02 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:02 --> Controller Class Initialized
INFO - 2025-05-08 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:02 --> Controller Class Initialized
INFO - 2025-05-08 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:02 --> Controller Class Initialized
INFO - 2025-05-08 17:45:19 --> Config Class Initialized
INFO - 2025-05-08 17:45:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:19 --> URI Class Initialized
INFO - 2025-05-08 17:45:19 --> Router Class Initialized
INFO - 2025-05-08 17:45:19 --> Output Class Initialized
INFO - 2025-05-08 17:45:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:19 --> Input Class Initialized
INFO - 2025-05-08 17:45:19 --> Language Class Initialized
INFO - 2025-05-08 17:45:19 --> Loader Class Initialized
INFO - 2025-05-08 17:45:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:19 --> Controller Class Initialized
INFO - 2025-05-08 17:45:19 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:45:19 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:19 --> Total execution time: 0.0052
INFO - 2025-05-08 17:45:19 --> Config Class Initialized
INFO - 2025-05-08 17:45:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:19 --> URI Class Initialized
INFO - 2025-05-08 17:45:19 --> Router Class Initialized
INFO - 2025-05-08 17:45:19 --> Output Class Initialized
INFO - 2025-05-08 17:45:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:19 --> Input Class Initialized
INFO - 2025-05-08 17:45:19 --> Language Class Initialized
INFO - 2025-05-08 17:45:19 --> Loader Class Initialized
INFO - 2025-05-08 17:45:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:19 --> Controller Class Initialized
INFO - 2025-05-08 17:45:19 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:29 --> Config Class Initialized
INFO - 2025-05-08 17:45:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:29 --> URI Class Initialized
DEBUG - 2025-05-08 17:45:29 --> No URI present. Default controller set.
INFO - 2025-05-08 17:45:29 --> Router Class Initialized
INFO - 2025-05-08 17:45:29 --> Output Class Initialized
INFO - 2025-05-08 17:45:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:29 --> Input Class Initialized
INFO - 2025-05-08 17:45:29 --> Language Class Initialized
INFO - 2025-05-08 17:45:29 --> Loader Class Initialized
INFO - 2025-05-08 17:45:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:29 --> Controller Class Initialized
INFO - 2025-05-08 17:45:29 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:45:29 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:45:29 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:45:29 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:45:29 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:45:29 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:29 --> Total execution time: 0.0036
INFO - 2025-05-08 17:45:31 --> Config Class Initialized
INFO - 2025-05-08 17:45:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:31 --> URI Class Initialized
INFO - 2025-05-08 17:45:31 --> Router Class Initialized
INFO - 2025-05-08 17:45:31 --> Output Class Initialized
INFO - 2025-05-08 17:45:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:31 --> Input Class Initialized
INFO - 2025-05-08 17:45:31 --> Language Class Initialized
INFO - 2025-05-08 17:45:31 --> Loader Class Initialized
INFO - 2025-05-08 17:45:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:31 --> Controller Class Initialized
INFO - 2025-05-08 17:45:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Config Class Initialized
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:33 --> URI Class Initialized
INFO - 2025-05-08 17:45:33 --> Router Class Initialized
INFO - 2025-05-08 17:45:33 --> Output Class Initialized
INFO - 2025-05-08 17:45:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:33 --> Input Class Initialized
INFO - 2025-05-08 17:45:33 --> Language Class Initialized
INFO - 2025-05-08 17:45:33 --> Loader Class Initialized
INFO - 2025-05-08 17:45:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:33 --> Controller Class Initialized
INFO - 2025-05-08 17:45:36 --> Config Class Initialized
INFO - 2025-05-08 17:45:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:36 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:36 --> URI Class Initialized
INFO - 2025-05-08 17:45:36 --> Router Class Initialized
INFO - 2025-05-08 17:45:36 --> Output Class Initialized
INFO - 2025-05-08 17:45:36 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:36 --> Input Class Initialized
INFO - 2025-05-08 17:45:36 --> Language Class Initialized
INFO - 2025-05-08 17:45:36 --> Loader Class Initialized
INFO - 2025-05-08 17:45:36 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:36 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:36 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:36 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:36 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:36 --> Controller Class Initialized
INFO - 2025-05-08 17:45:36 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:45:36 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:36 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:45:36 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:45:36 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:45:36 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:45:36 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:45:36 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:36 --> Total execution time: 0.0037
INFO - 2025-05-08 17:45:39 --> Config Class Initialized
INFO - 2025-05-08 17:45:39 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:39 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:39 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:39 --> URI Class Initialized
INFO - 2025-05-08 17:45:39 --> Router Class Initialized
INFO - 2025-05-08 17:45:39 --> Output Class Initialized
INFO - 2025-05-08 17:45:39 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:39 --> Input Class Initialized
INFO - 2025-05-08 17:45:39 --> Language Class Initialized
INFO - 2025-05-08 17:45:39 --> Loader Class Initialized
INFO - 2025-05-08 17:45:39 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:39 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:39 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:39 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:39 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:39 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:39 --> Controller Class Initialized
INFO - 2025-05-08 17:45:39 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:39 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:39 --> Total execution time: 0.0038
INFO - 2025-05-08 17:45:41 --> Config Class Initialized
INFO - 2025-05-08 17:45:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:41 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:41 --> URI Class Initialized
INFO - 2025-05-08 17:45:41 --> Router Class Initialized
INFO - 2025-05-08 17:45:41 --> Output Class Initialized
INFO - 2025-05-08 17:45:41 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:41 --> Input Class Initialized
INFO - 2025-05-08 17:45:41 --> Language Class Initialized
INFO - 2025-05-08 17:45:41 --> Loader Class Initialized
INFO - 2025-05-08 17:45:41 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:41 --> Controller Class Initialized
INFO - 2025-05-08 17:45:41 --> Model "UserModel" initialized
INFO - 2025-05-08 17:45:41 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:41 --> Total execution time: 0.0027
INFO - 2025-05-08 17:45:41 --> Config Class Initialized
INFO - 2025-05-08 17:45:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:41 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:41 --> URI Class Initialized
INFO - 2025-05-08 17:45:41 --> Router Class Initialized
INFO - 2025-05-08 17:45:41 --> Output Class Initialized
INFO - 2025-05-08 17:45:41 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:41 --> Input Class Initialized
INFO - 2025-05-08 17:45:41 --> Language Class Initialized
INFO - 2025-05-08 17:45:41 --> Loader Class Initialized
INFO - 2025-05-08 17:45:41 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:41 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:41 --> Controller Class Initialized
INFO - 2025-05-08 17:45:41 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:41 --> Final output sent to browser
DEBUG - 2025-05-08 17:45:41 --> Total execution time: 0.0034
INFO - 2025-05-08 17:45:42 --> Config Class Initialized
INFO - 2025-05-08 17:45:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:42 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:42 --> URI Class Initialized
INFO - 2025-05-08 17:45:42 --> Router Class Initialized
INFO - 2025-05-08 17:45:42 --> Output Class Initialized
INFO - 2025-05-08 17:45:42 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:42 --> Input Class Initialized
INFO - 2025-05-08 17:45:42 --> Language Class Initialized
INFO - 2025-05-08 17:45:42 --> Loader Class Initialized
INFO - 2025-05-08 17:45:42 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:42 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:42 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:42 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:42 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:42 --> Controller Class Initialized
INFO - 2025-05-08 17:45:43 --> Config Class Initialized
INFO - 2025-05-08 17:45:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:43 --> URI Class Initialized
INFO - 2025-05-08 17:45:43 --> Router Class Initialized
INFO - 2025-05-08 17:45:43 --> Output Class Initialized
INFO - 2025-05-08 17:45:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:43 --> Input Class Initialized
INFO - 2025-05-08 17:45:43 --> Language Class Initialized
INFO - 2025-05-08 17:45:43 --> Loader Class Initialized
INFO - 2025-05-08 17:45:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:43 --> Controller Class Initialized
INFO - 2025-05-08 17:45:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
INFO - 2025-05-08 17:45:44 --> Config Class Initialized
INFO - 2025-05-08 17:45:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
DEBUG - 2025-05-08 17:45:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:45:44 --> Utf8 Class Initialized
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> URI Class Initialized
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> Router Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Output Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Security Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
INFO - 2025-05-08 17:45:44 --> Input Class Initialized
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:44 --> Language Class Initialized
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:44 --> Loader Class Initialized
INFO - 2025-05-08 17:45:44 --> Helper loaded: url_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: string_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: form_helper
INFO - 2025-05-08 17:45:44 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:44 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:44 --> Database Driver Class Initialized
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
DEBUG - 2025-05-08 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
INFO - 2025-05-08 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:45:44 --> Controller Class Initialized
INFO - 2025-05-08 17:46:27 --> Config Class Initialized
INFO - 2025-05-08 17:46:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:27 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:27 --> URI Class Initialized
INFO - 2025-05-08 17:46:27 --> Router Class Initialized
INFO - 2025-05-08 17:46:27 --> Output Class Initialized
INFO - 2025-05-08 17:46:27 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:27 --> Input Class Initialized
INFO - 2025-05-08 17:46:27 --> Language Class Initialized
INFO - 2025-05-08 17:46:27 --> Loader Class Initialized
INFO - 2025-05-08 17:46:27 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:27 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:27 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:27 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:27 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:27 --> Controller Class Initialized
INFO - 2025-05-08 17:46:27 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:46:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:27 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:46:27 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:46:27 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:46:27 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:46:27 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:46:27 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:27 --> Total execution time: 0.0391
INFO - 2025-05-08 17:46:29 --> Config Class Initialized
INFO - 2025-05-08 17:46:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:29 --> URI Class Initialized
INFO - 2025-05-08 17:46:29 --> Router Class Initialized
INFO - 2025-05-08 17:46:29 --> Output Class Initialized
INFO - 2025-05-08 17:46:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:29 --> Input Class Initialized
INFO - 2025-05-08 17:46:29 --> Language Class Initialized
INFO - 2025-05-08 17:46:29 --> Loader Class Initialized
INFO - 2025-05-08 17:46:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:29 --> Controller Class Initialized
INFO - 2025-05-08 17:46:29 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:29 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:29 --> Total execution time: 0.0035
INFO - 2025-05-08 17:46:30 --> Config Class Initialized
INFO - 2025-05-08 17:46:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:30 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:30 --> URI Class Initialized
INFO - 2025-05-08 17:46:30 --> Router Class Initialized
INFO - 2025-05-08 17:46:30 --> Output Class Initialized
INFO - 2025-05-08 17:46:30 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:30 --> Input Class Initialized
INFO - 2025-05-08 17:46:30 --> Language Class Initialized
INFO - 2025-05-08 17:46:30 --> Loader Class Initialized
INFO - 2025-05-08 17:46:30 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:30 --> Controller Class Initialized
INFO - 2025-05-08 17:46:30 --> Model "UserModel" initialized
INFO - 2025-05-08 17:46:30 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:30 --> Total execution time: 0.0073
INFO - 2025-05-08 17:46:30 --> Config Class Initialized
INFO - 2025-05-08 17:46:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:30 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:30 --> URI Class Initialized
INFO - 2025-05-08 17:46:30 --> Router Class Initialized
INFO - 2025-05-08 17:46:30 --> Output Class Initialized
INFO - 2025-05-08 17:46:30 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:30 --> Input Class Initialized
INFO - 2025-05-08 17:46:30 --> Language Class Initialized
INFO - 2025-05-08 17:46:30 --> Loader Class Initialized
INFO - 2025-05-08 17:46:30 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:30 --> Controller Class Initialized
INFO - 2025-05-08 17:46:30 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:30 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:30 --> Total execution time: 0.0025
INFO - 2025-05-08 17:46:30 --> Config Class Initialized
INFO - 2025-05-08 17:46:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:30 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:30 --> URI Class Initialized
INFO - 2025-05-08 17:46:30 --> Router Class Initialized
INFO - 2025-05-08 17:46:30 --> Output Class Initialized
INFO - 2025-05-08 17:46:30 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:30 --> Input Class Initialized
INFO - 2025-05-08 17:46:30 --> Language Class Initialized
INFO - 2025-05-08 17:46:30 --> Loader Class Initialized
INFO - 2025-05-08 17:46:30 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:30 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:30 --> Controller Class Initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
INFO - 2025-05-08 17:46:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Config Class Initialized
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Hooks Class Initialized
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:46:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:31 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> URI Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Router Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:31 --> Output Class Initialized
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:31 --> Input Class Initialized
INFO - 2025-05-08 17:46:31 --> Language Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Loader Class Initialized
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
INFO - 2025-05-08 17:46:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:31 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
DEBUG - 2025-05-08 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:31 --> Controller Class Initialized
INFO - 2025-05-08 17:46:36 --> Config Class Initialized
INFO - 2025-05-08 17:46:36 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:36 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:36 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:36 --> URI Class Initialized
INFO - 2025-05-08 17:46:36 --> Router Class Initialized
INFO - 2025-05-08 17:46:36 --> Output Class Initialized
INFO - 2025-05-08 17:46:36 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:36 --> Input Class Initialized
INFO - 2025-05-08 17:46:36 --> Language Class Initialized
INFO - 2025-05-08 17:46:36 --> Loader Class Initialized
INFO - 2025-05-08 17:46:36 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:36 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:36 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:36 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:36 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:36 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:36 --> Controller Class Initialized
INFO - 2025-05-08 17:46:36 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:42 --> Config Class Initialized
INFO - 2025-05-08 17:46:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:42 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:42 --> URI Class Initialized
DEBUG - 2025-05-08 17:46:42 --> No URI present. Default controller set.
INFO - 2025-05-08 17:46:42 --> Router Class Initialized
INFO - 2025-05-08 17:46:42 --> Output Class Initialized
INFO - 2025-05-08 17:46:42 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:42 --> Input Class Initialized
INFO - 2025-05-08 17:46:42 --> Language Class Initialized
INFO - 2025-05-08 17:46:42 --> Loader Class Initialized
INFO - 2025-05-08 17:46:42 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:42 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:42 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:42 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:42 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:42 --> Controller Class Initialized
INFO - 2025-05-08 17:46:42 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:46:42 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:46:42 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:46:42 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:46:42 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:46:42 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:42 --> Total execution time: 0.0035
INFO - 2025-05-08 17:46:45 --> Config Class Initialized
INFO - 2025-05-08 17:46:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:45 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:45 --> URI Class Initialized
INFO - 2025-05-08 17:46:45 --> Router Class Initialized
INFO - 2025-05-08 17:46:45 --> Output Class Initialized
INFO - 2025-05-08 17:46:45 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:45 --> Input Class Initialized
INFO - 2025-05-08 17:46:45 --> Language Class Initialized
INFO - 2025-05-08 17:46:45 --> Loader Class Initialized
INFO - 2025-05-08 17:46:45 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:45 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:45 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:45 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:45 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:45 --> Controller Class Initialized
INFO - 2025-05-08 17:46:45 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:46:46 --> Config Class Initialized
INFO - 2025-05-08 17:46:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:46 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:46 --> URI Class Initialized
INFO - 2025-05-08 17:46:46 --> Router Class Initialized
INFO - 2025-05-08 17:46:46 --> Output Class Initialized
INFO - 2025-05-08 17:46:46 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:46 --> Input Class Initialized
INFO - 2025-05-08 17:46:46 --> Language Class Initialized
INFO - 2025-05-08 17:46:46 --> Loader Class Initialized
INFO - 2025-05-08 17:46:46 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:46 --> Controller Class Initialized
INFO - 2025-05-08 17:46:46 --> Config Class Initialized
INFO - 2025-05-08 17:46:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:46 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:46 --> URI Class Initialized
INFO - 2025-05-08 17:46:46 --> Router Class Initialized
INFO - 2025-05-08 17:46:46 --> Output Class Initialized
INFO - 2025-05-08 17:46:46 --> Security Class Initialized
INFO - 2025-05-08 17:46:46 --> Config Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:46 --> Hooks Class Initialized
INFO - 2025-05-08 17:46:46 --> Input Class Initialized
INFO - 2025-05-08 17:46:46 --> Language Class Initialized
DEBUG - 2025-05-08 17:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:46 --> Loader Class Initialized
INFO - 2025-05-08 17:46:46 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:46 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:46 --> URI Class Initialized
INFO - 2025-05-08 17:46:46 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:46 --> Database Driver Class Initialized
INFO - 2025-05-08 17:46:46 --> Router Class Initialized
INFO - 2025-05-08 17:46:46 --> Output Class Initialized
INFO - 2025-05-08 17:46:46 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:46 --> Input Class Initialized
INFO - 2025-05-08 17:46:46 --> Language Class Initialized
INFO - 2025-05-08 17:46:46 --> Loader Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:46 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:46 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:46 --> Controller Class Initialized
INFO - 2025-05-08 17:46:46 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:46 --> Controller Class Initialized
INFO - 2025-05-08 17:46:58 --> Config Class Initialized
INFO - 2025-05-08 17:46:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:58 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:58 --> URI Class Initialized
INFO - 2025-05-08 17:46:58 --> Router Class Initialized
INFO - 2025-05-08 17:46:58 --> Output Class Initialized
INFO - 2025-05-08 17:46:58 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:58 --> Input Class Initialized
INFO - 2025-05-08 17:46:58 --> Language Class Initialized
INFO - 2025-05-08 17:46:58 --> Loader Class Initialized
INFO - 2025-05-08 17:46:58 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:58 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:58 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:58 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:58 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:58 --> Controller Class Initialized
INFO - 2025-05-08 17:46:58 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:46:58 --> Final output sent to browser
DEBUG - 2025-05-08 17:46:58 --> Total execution time: 0.0057
INFO - 2025-05-08 17:46:59 --> Config Class Initialized
INFO - 2025-05-08 17:46:59 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:46:59 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:46:59 --> Utf8 Class Initialized
INFO - 2025-05-08 17:46:59 --> URI Class Initialized
INFO - 2025-05-08 17:46:59 --> Router Class Initialized
INFO - 2025-05-08 17:46:59 --> Output Class Initialized
INFO - 2025-05-08 17:46:59 --> Security Class Initialized
DEBUG - 2025-05-08 17:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:46:59 --> Input Class Initialized
INFO - 2025-05-08 17:46:59 --> Language Class Initialized
INFO - 2025-05-08 17:46:59 --> Loader Class Initialized
INFO - 2025-05-08 17:46:59 --> Helper loaded: url_helper
INFO - 2025-05-08 17:46:59 --> Helper loaded: string_helper
INFO - 2025-05-08 17:46:59 --> Helper loaded: form_helper
INFO - 2025-05-08 17:46:59 --> Helper loaded: file_helper
INFO - 2025-05-08 17:46:59 --> Helper loaded: html_helper
INFO - 2025-05-08 17:46:59 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:46:59 --> Controller Class Initialized
INFO - 2025-05-08 17:46:59 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:47:15 --> Config Class Initialized
INFO - 2025-05-08 17:47:15 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:15 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:15 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:15 --> URI Class Initialized
DEBUG - 2025-05-08 17:47:15 --> No URI present. Default controller set.
INFO - 2025-05-08 17:47:15 --> Router Class Initialized
INFO - 2025-05-08 17:47:15 --> Output Class Initialized
INFO - 2025-05-08 17:47:15 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:15 --> Input Class Initialized
INFO - 2025-05-08 17:47:15 --> Language Class Initialized
INFO - 2025-05-08 17:47:15 --> Loader Class Initialized
INFO - 2025-05-08 17:47:15 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:15 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:15 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:15 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:15 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:15 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:15 --> Controller Class Initialized
INFO - 2025-05-08 17:47:15 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:47:15 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:47:15 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:47:15 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:47:15 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:47:15 --> Final output sent to browser
DEBUG - 2025-05-08 17:47:15 --> Total execution time: 0.0037
INFO - 2025-05-08 17:47:16 --> Config Class Initialized
INFO - 2025-05-08 17:47:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:16 --> URI Class Initialized
INFO - 2025-05-08 17:47:16 --> Router Class Initialized
INFO - 2025-05-08 17:47:16 --> Output Class Initialized
INFO - 2025-05-08 17:47:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:16 --> Input Class Initialized
INFO - 2025-05-08 17:47:16 --> Language Class Initialized
INFO - 2025-05-08 17:47:16 --> Loader Class Initialized
INFO - 2025-05-08 17:47:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:16 --> Controller Class Initialized
INFO - 2025-05-08 17:47:16 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:47:18 --> Config Class Initialized
INFO - 2025-05-08 17:47:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:18 --> URI Class Initialized
INFO - 2025-05-08 17:47:18 --> Router Class Initialized
INFO - 2025-05-08 17:47:18 --> Output Class Initialized
INFO - 2025-05-08 17:47:18 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:18 --> Input Class Initialized
INFO - 2025-05-08 17:47:18 --> Language Class Initialized
INFO - 2025-05-08 17:47:18 --> Loader Class Initialized
INFO - 2025-05-08 17:47:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:18 --> Database Driver Class Initialized
INFO - 2025-05-08 17:47:18 --> Config Class Initialized
INFO - 2025-05-08 17:47:18 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:18 --> URI Class Initialized
DEBUG - 2025-05-08 17:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:18 --> Router Class Initialized
INFO - 2025-05-08 17:47:18 --> Controller Class Initialized
INFO - 2025-05-08 17:47:18 --> Output Class Initialized
INFO - 2025-05-08 17:47:18 --> Config Class Initialized
INFO - 2025-05-08 17:47:18 --> Hooks Class Initialized
INFO - 2025-05-08 17:47:18 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:18 --> Input Class Initialized
DEBUG - 2025-05-08 17:47:18 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:18 --> Language Class Initialized
INFO - 2025-05-08 17:47:18 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:18 --> Loader Class Initialized
INFO - 2025-05-08 17:47:18 --> URI Class Initialized
INFO - 2025-05-08 17:47:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:18 --> Database Driver Class Initialized
INFO - 2025-05-08 17:47:18 --> Router Class Initialized
INFO - 2025-05-08 17:47:18 --> Output Class Initialized
INFO - 2025-05-08 17:47:18 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:18 --> Input Class Initialized
INFO - 2025-05-08 17:47:18 --> Language Class Initialized
INFO - 2025-05-08 17:47:18 --> Loader Class Initialized
INFO - 2025-05-08 17:47:18 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:18 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:18 --> Database Driver Class Initialized
INFO - 2025-05-08 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:18 --> Controller Class Initialized
DEBUG - 2025-05-08 17:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:18 --> Controller Class Initialized
INFO - 2025-05-08 17:47:26 --> Config Class Initialized
INFO - 2025-05-08 17:47:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:26 --> URI Class Initialized
INFO - 2025-05-08 17:47:26 --> Router Class Initialized
INFO - 2025-05-08 17:47:26 --> Output Class Initialized
INFO - 2025-05-08 17:47:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:26 --> Input Class Initialized
INFO - 2025-05-08 17:47:26 --> Language Class Initialized
INFO - 2025-05-08 17:47:26 --> Loader Class Initialized
INFO - 2025-05-08 17:47:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:26 --> Controller Class Initialized
INFO - 2025-05-08 17:47:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:47:31 --> Config Class Initialized
INFO - 2025-05-08 17:47:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:31 --> URI Class Initialized
DEBUG - 2025-05-08 17:47:31 --> No URI present. Default controller set.
INFO - 2025-05-08 17:47:31 --> Router Class Initialized
INFO - 2025-05-08 17:47:31 --> Output Class Initialized
INFO - 2025-05-08 17:47:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:31 --> Input Class Initialized
INFO - 2025-05-08 17:47:31 --> Language Class Initialized
INFO - 2025-05-08 17:47:31 --> Loader Class Initialized
INFO - 2025-05-08 17:47:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:31 --> Controller Class Initialized
INFO - 2025-05-08 17:47:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:47:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:47:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:47:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:47:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:47:31 --> Final output sent to browser
DEBUG - 2025-05-08 17:47:31 --> Total execution time: 0.0037
INFO - 2025-05-08 17:47:32 --> Config Class Initialized
INFO - 2025-05-08 17:47:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:32 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:32 --> URI Class Initialized
INFO - 2025-05-08 17:47:32 --> Router Class Initialized
INFO - 2025-05-08 17:47:32 --> Output Class Initialized
INFO - 2025-05-08 17:47:32 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:32 --> Input Class Initialized
INFO - 2025-05-08 17:47:32 --> Language Class Initialized
INFO - 2025-05-08 17:47:32 --> Loader Class Initialized
INFO - 2025-05-08 17:47:32 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:32 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:32 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:32 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:32 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:32 --> Controller Class Initialized
INFO - 2025-05-08 17:47:32 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:47:34 --> Config Class Initialized
INFO - 2025-05-08 17:47:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:47:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:47:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:47:34 --> URI Class Initialized
INFO - 2025-05-08 17:47:34 --> Router Class Initialized
INFO - 2025-05-08 17:47:34 --> Output Class Initialized
INFO - 2025-05-08 17:47:34 --> Security Class Initialized
DEBUG - 2025-05-08 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:47:34 --> Input Class Initialized
INFO - 2025-05-08 17:47:34 --> Language Class Initialized
INFO - 2025-05-08 17:47:34 --> Loader Class Initialized
INFO - 2025-05-08 17:47:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:47:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:47:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:47:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:47:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:47:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:47:34 --> Controller Class Initialized
INFO - 2025-05-08 17:50:49 --> Config Class Initialized
INFO - 2025-05-08 17:50:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:50:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:50:49 --> Utf8 Class Initialized
INFO - 2025-05-08 17:50:49 --> URI Class Initialized
DEBUG - 2025-05-08 17:50:49 --> No URI present. Default controller set.
INFO - 2025-05-08 17:50:49 --> Router Class Initialized
INFO - 2025-05-08 17:50:49 --> Output Class Initialized
INFO - 2025-05-08 17:50:49 --> Security Class Initialized
DEBUG - 2025-05-08 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:50:49 --> Input Class Initialized
INFO - 2025-05-08 17:50:49 --> Language Class Initialized
INFO - 2025-05-08 17:50:49 --> Loader Class Initialized
INFO - 2025-05-08 17:50:49 --> Helper loaded: url_helper
INFO - 2025-05-08 17:50:49 --> Helper loaded: string_helper
INFO - 2025-05-08 17:50:49 --> Helper loaded: form_helper
INFO - 2025-05-08 17:50:49 --> Helper loaded: file_helper
INFO - 2025-05-08 17:50:49 --> Helper loaded: html_helper
INFO - 2025-05-08 17:50:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:50:49 --> Controller Class Initialized
INFO - 2025-05-08 17:50:49 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:50:49 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:50:49 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:50:49 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:50:49 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:50:49 --> Final output sent to browser
DEBUG - 2025-05-08 17:50:49 --> Total execution time: 0.0309
INFO - 2025-05-08 17:50:52 --> Config Class Initialized
INFO - 2025-05-08 17:50:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:50:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:50:52 --> Utf8 Class Initialized
INFO - 2025-05-08 17:50:52 --> URI Class Initialized
INFO - 2025-05-08 17:50:52 --> Router Class Initialized
INFO - 2025-05-08 17:50:52 --> Output Class Initialized
INFO - 2025-05-08 17:50:52 --> Security Class Initialized
DEBUG - 2025-05-08 17:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:50:52 --> Input Class Initialized
INFO - 2025-05-08 17:50:52 --> Language Class Initialized
INFO - 2025-05-08 17:50:52 --> Loader Class Initialized
INFO - 2025-05-08 17:50:52 --> Helper loaded: url_helper
INFO - 2025-05-08 17:50:52 --> Helper loaded: string_helper
INFO - 2025-05-08 17:50:52 --> Helper loaded: form_helper
INFO - 2025-05-08 17:50:52 --> Helper loaded: file_helper
INFO - 2025-05-08 17:50:52 --> Helper loaded: html_helper
INFO - 2025-05-08 17:50:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:50:52 --> Controller Class Initialized
INFO - 2025-05-08 17:50:52 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:50:53 --> Config Class Initialized
INFO - 2025-05-08 17:50:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:50:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:50:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:50:53 --> URI Class Initialized
INFO - 2025-05-08 17:50:53 --> Router Class Initialized
INFO - 2025-05-08 17:50:53 --> Output Class Initialized
INFO - 2025-05-08 17:50:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:50:53 --> Input Class Initialized
INFO - 2025-05-08 17:50:53 --> Language Class Initialized
INFO - 2025-05-08 17:50:53 --> Loader Class Initialized
INFO - 2025-05-08 17:50:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:50:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:50:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:50:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:50:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:50:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:50:53 --> Controller Class Initialized
INFO - 2025-05-08 17:50:57 --> Config Class Initialized
INFO - 2025-05-08 17:50:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:50:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:50:57 --> Utf8 Class Initialized
INFO - 2025-05-08 17:50:57 --> URI Class Initialized
INFO - 2025-05-08 17:50:57 --> Router Class Initialized
INFO - 2025-05-08 17:50:57 --> Output Class Initialized
INFO - 2025-05-08 17:50:57 --> Security Class Initialized
DEBUG - 2025-05-08 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:50:57 --> Input Class Initialized
INFO - 2025-05-08 17:50:57 --> Language Class Initialized
INFO - 2025-05-08 17:50:57 --> Loader Class Initialized
INFO - 2025-05-08 17:50:57 --> Helper loaded: url_helper
INFO - 2025-05-08 17:50:57 --> Helper loaded: string_helper
INFO - 2025-05-08 17:50:57 --> Helper loaded: form_helper
INFO - 2025-05-08 17:50:57 --> Helper loaded: file_helper
INFO - 2025-05-08 17:50:57 --> Helper loaded: html_helper
INFO - 2025-05-08 17:50:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:50:57 --> Controller Class Initialized
INFO - 2025-05-08 17:50:57 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:50:57 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:50:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:50:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:50:57 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/details.php
INFO - 2025-05-08 17:50:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:50:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:50:57 --> Final output sent to browser
DEBUG - 2025-05-08 17:50:57 --> Total execution time: 0.0041
INFO - 2025-05-08 17:51:00 --> Config Class Initialized
INFO - 2025-05-08 17:51:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:00 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:00 --> URI Class Initialized
INFO - 2025-05-08 17:51:00 --> Router Class Initialized
INFO - 2025-05-08 17:51:00 --> Output Class Initialized
INFO - 2025-05-08 17:51:00 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:00 --> Input Class Initialized
INFO - 2025-05-08 17:51:00 --> Language Class Initialized
INFO - 2025-05-08 17:51:00 --> Loader Class Initialized
INFO - 2025-05-08 17:51:00 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:00 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:00 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:00 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:00 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:00 --> Controller Class Initialized
INFO - 2025-05-08 17:51:00 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:00 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:00 --> Total execution time: 0.0029
INFO - 2025-05-08 17:51:02 --> Config Class Initialized
INFO - 2025-05-08 17:51:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:02 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:02 --> URI Class Initialized
INFO - 2025-05-08 17:51:02 --> Router Class Initialized
INFO - 2025-05-08 17:51:02 --> Output Class Initialized
INFO - 2025-05-08 17:51:02 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:02 --> Input Class Initialized
INFO - 2025-05-08 17:51:02 --> Language Class Initialized
INFO - 2025-05-08 17:51:02 --> Loader Class Initialized
INFO - 2025-05-08 17:51:02 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:02 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:02 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:02 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:02 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:02 --> Controller Class Initialized
INFO - 2025-05-08 17:51:02 --> Model "UserModel" initialized
INFO - 2025-05-08 17:51:02 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:02 --> Total execution time: 0.0054
INFO - 2025-05-08 17:51:03 --> Config Class Initialized
INFO - 2025-05-08 17:51:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:03 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:03 --> URI Class Initialized
INFO - 2025-05-08 17:51:03 --> Router Class Initialized
INFO - 2025-05-08 17:51:03 --> Output Class Initialized
INFO - 2025-05-08 17:51:03 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:03 --> Input Class Initialized
INFO - 2025-05-08 17:51:03 --> Language Class Initialized
INFO - 2025-05-08 17:51:03 --> Loader Class Initialized
INFO - 2025-05-08 17:51:03 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:03 --> Controller Class Initialized
INFO - 2025-05-08 17:51:03 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:03 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:03 --> Total execution time: 0.0025
INFO - 2025-05-08 17:51:03 --> Config Class Initialized
INFO - 2025-05-08 17:51:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:03 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:03 --> URI Class Initialized
INFO - 2025-05-08 17:51:03 --> Router Class Initialized
INFO - 2025-05-08 17:51:03 --> Output Class Initialized
INFO - 2025-05-08 17:51:03 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:03 --> Input Class Initialized
INFO - 2025-05-08 17:51:03 --> Language Class Initialized
INFO - 2025-05-08 17:51:03 --> Loader Class Initialized
INFO - 2025-05-08 17:51:03 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:03 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:03 --> Controller Class Initialized
INFO - 2025-05-08 17:51:04 --> Config Class Initialized
INFO - 2025-05-08 17:51:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:04 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:04 --> URI Class Initialized
INFO - 2025-05-08 17:51:04 --> Router Class Initialized
INFO - 2025-05-08 17:51:04 --> Output Class Initialized
INFO - 2025-05-08 17:51:04 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:04 --> Input Class Initialized
INFO - 2025-05-08 17:51:04 --> Language Class Initialized
INFO - 2025-05-08 17:51:04 --> Loader Class Initialized
INFO - 2025-05-08 17:51:04 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:04 --> Controller Class Initialized
INFO - 2025-05-08 17:51:04 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:04 --> Config Class Initialized
INFO - 2025-05-08 17:51:04 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:04 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:04 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:04 --> URI Class Initialized
INFO - 2025-05-08 17:51:04 --> Router Class Initialized
INFO - 2025-05-08 17:51:04 --> Output Class Initialized
INFO - 2025-05-08 17:51:04 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:04 --> Input Class Initialized
INFO - 2025-05-08 17:51:04 --> Language Class Initialized
INFO - 2025-05-08 17:51:04 --> Loader Class Initialized
INFO - 2025-05-08 17:51:04 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:04 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:04 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:04 --> Controller Class Initialized
INFO - 2025-05-08 17:51:09 --> Config Class Initialized
INFO - 2025-05-08 17:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:09 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:09 --> URI Class Initialized
INFO - 2025-05-08 17:51:09 --> Router Class Initialized
INFO - 2025-05-08 17:51:09 --> Output Class Initialized
INFO - 2025-05-08 17:51:09 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:09 --> Input Class Initialized
INFO - 2025-05-08 17:51:09 --> Language Class Initialized
INFO - 2025-05-08 17:51:09 --> Loader Class Initialized
INFO - 2025-05-08 17:51:09 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:09 --> Controller Class Initialized
INFO - 2025-05-08 17:51:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:09 --> Config Class Initialized
INFO - 2025-05-08 17:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:09 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:09 --> URI Class Initialized
INFO - 2025-05-08 17:51:09 --> Router Class Initialized
INFO - 2025-05-08 17:51:09 --> Output Class Initialized
INFO - 2025-05-08 17:51:09 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:09 --> Input Class Initialized
INFO - 2025-05-08 17:51:09 --> Language Class Initialized
INFO - 2025-05-08 17:51:09 --> Loader Class Initialized
INFO - 2025-05-08 17:51:09 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:09 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:09 --> Controller Class Initialized
INFO - 2025-05-08 17:51:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:14 --> Config Class Initialized
INFO - 2025-05-08 17:51:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:14 --> URI Class Initialized
DEBUG - 2025-05-08 17:51:14 --> No URI present. Default controller set.
INFO - 2025-05-08 17:51:14 --> Router Class Initialized
INFO - 2025-05-08 17:51:14 --> Output Class Initialized
INFO - 2025-05-08 17:51:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:14 --> Input Class Initialized
INFO - 2025-05-08 17:51:14 --> Language Class Initialized
INFO - 2025-05-08 17:51:14 --> Loader Class Initialized
INFO - 2025-05-08 17:51:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:14 --> Controller Class Initialized
INFO - 2025-05-08 17:51:14 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:51:14 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:51:14 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:51:14 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:51:14 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:51:14 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:14 --> Total execution time: 0.0027
INFO - 2025-05-08 17:51:16 --> Config Class Initialized
INFO - 2025-05-08 17:51:16 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:16 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:16 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:16 --> URI Class Initialized
INFO - 2025-05-08 17:51:16 --> Router Class Initialized
INFO - 2025-05-08 17:51:16 --> Output Class Initialized
INFO - 2025-05-08 17:51:16 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:16 --> Input Class Initialized
INFO - 2025-05-08 17:51:16 --> Language Class Initialized
INFO - 2025-05-08 17:51:16 --> Loader Class Initialized
INFO - 2025-05-08 17:51:16 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:16 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:16 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:16 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:16 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:16 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:16 --> Controller Class Initialized
INFO - 2025-05-08 17:51:16 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:32 --> Config Class Initialized
INFO - 2025-05-08 17:51:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:32 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:32 --> URI Class Initialized
INFO - 2025-05-08 17:51:32 --> Router Class Initialized
INFO - 2025-05-08 17:51:32 --> Output Class Initialized
INFO - 2025-05-08 17:51:32 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:32 --> Input Class Initialized
INFO - 2025-05-08 17:51:32 --> Language Class Initialized
INFO - 2025-05-08 17:51:32 --> Loader Class Initialized
INFO - 2025-05-08 17:51:32 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:32 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:32 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:32 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:32 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:32 --> Controller Class Initialized
INFO - 2025-05-08 17:51:32 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:51:33 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:33 --> Total execution time: 1.0036
INFO - 2025-05-08 17:51:33 --> Config Class Initialized
INFO - 2025-05-08 17:51:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:33 --> URI Class Initialized
INFO - 2025-05-08 17:51:33 --> Router Class Initialized
INFO - 2025-05-08 17:51:33 --> Output Class Initialized
INFO - 2025-05-08 17:51:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:33 --> Input Class Initialized
INFO - 2025-05-08 17:51:33 --> Language Class Initialized
INFO - 2025-05-08 17:51:33 --> Loader Class Initialized
INFO - 2025-05-08 17:51:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:33 --> Controller Class Initialized
INFO - 2025-05-08 17:51:33 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
INFO - 2025-05-08 17:51:34 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Config Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
DEBUG - 2025-05-08 17:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> URI Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Router Class Initialized
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
INFO - 2025-05-08 17:51:34 --> Output Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Security Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
DEBUG - 2025-05-08 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Input Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Language Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Loader Class Initialized
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:34 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:34 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
DEBUG - 2025-05-08 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
INFO - 2025-05-08 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:34 --> Controller Class Initialized
INFO - 2025-05-08 17:51:43 --> Config Class Initialized
INFO - 2025-05-08 17:51:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:43 --> URI Class Initialized
DEBUG - 2025-05-08 17:51:43 --> No URI present. Default controller set.
INFO - 2025-05-08 17:51:43 --> Router Class Initialized
INFO - 2025-05-08 17:51:43 --> Output Class Initialized
INFO - 2025-05-08 17:51:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:43 --> Input Class Initialized
INFO - 2025-05-08 17:51:43 --> Language Class Initialized
INFO - 2025-05-08 17:51:43 --> Loader Class Initialized
INFO - 2025-05-08 17:51:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:43 --> Controller Class Initialized
INFO - 2025-05-08 17:51:43 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:51:43 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:51:43 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:51:43 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:51:43 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:51:43 --> Final output sent to browser
DEBUG - 2025-05-08 17:51:43 --> Total execution time: 0.0080
INFO - 2025-05-08 17:51:51 --> Config Class Initialized
INFO - 2025-05-08 17:51:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:51 --> URI Class Initialized
INFO - 2025-05-08 17:51:51 --> Router Class Initialized
INFO - 2025-05-08 17:51:51 --> Output Class Initialized
INFO - 2025-05-08 17:51:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:51 --> Input Class Initialized
INFO - 2025-05-08 17:51:51 --> Language Class Initialized
INFO - 2025-05-08 17:51:51 --> Loader Class Initialized
INFO - 2025-05-08 17:51:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:51 --> Controller Class Initialized
INFO - 2025-05-08 17:51:51 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Config Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Hooks Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:51:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> URI Class Initialized
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
INFO - 2025-05-08 17:51:53 --> Router Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> Output Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Security Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
INFO - 2025-05-08 17:51:53 --> Input Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Language Class Initialized
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
INFO - 2025-05-08 17:51:53 --> Loader Class Initialized
INFO - 2025-05-08 17:51:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:51:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
INFO - 2025-05-08 17:51:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
DEBUG - 2025-05-08 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:51:53 --> Controller Class Initialized
INFO - 2025-05-08 17:52:19 --> Config Class Initialized
INFO - 2025-05-08 17:52:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:19 --> URI Class Initialized
INFO - 2025-05-08 17:52:19 --> Router Class Initialized
INFO - 2025-05-08 17:52:19 --> Output Class Initialized
INFO - 2025-05-08 17:52:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:19 --> Input Class Initialized
INFO - 2025-05-08 17:52:19 --> Language Class Initialized
INFO - 2025-05-08 17:52:19 --> Loader Class Initialized
INFO - 2025-05-08 17:52:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:19 --> Controller Class Initialized
INFO - 2025-05-08 17:52:19 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:52:19 --> Final output sent to browser
DEBUG - 2025-05-08 17:52:19 --> Total execution time: 0.0045
INFO - 2025-05-08 17:52:19 --> Config Class Initialized
INFO - 2025-05-08 17:52:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:19 --> URI Class Initialized
INFO - 2025-05-08 17:52:19 --> Router Class Initialized
INFO - 2025-05-08 17:52:19 --> Output Class Initialized
INFO - 2025-05-08 17:52:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:19 --> Input Class Initialized
INFO - 2025-05-08 17:52:19 --> Language Class Initialized
INFO - 2025-05-08 17:52:19 --> Loader Class Initialized
INFO - 2025-05-08 17:52:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:19 --> Controller Class Initialized
INFO - 2025-05-08 17:52:19 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:52:20 --> Config Class Initialized
INFO - 2025-05-08 17:52:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:20 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:20 --> URI Class Initialized
INFO - 2025-05-08 17:52:20 --> Router Class Initialized
INFO - 2025-05-08 17:52:20 --> Output Class Initialized
INFO - 2025-05-08 17:52:20 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:20 --> Input Class Initialized
INFO - 2025-05-08 17:52:20 --> Language Class Initialized
INFO - 2025-05-08 17:52:20 --> Loader Class Initialized
INFO - 2025-05-08 17:52:20 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:20 --> Controller Class Initialized
INFO - 2025-05-08 17:52:20 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:52:20 --> Config Class Initialized
INFO - 2025-05-08 17:52:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:20 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:20 --> URI Class Initialized
INFO - 2025-05-08 17:52:20 --> Router Class Initialized
INFO - 2025-05-08 17:52:20 --> Output Class Initialized
INFO - 2025-05-08 17:52:20 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:20 --> Input Class Initialized
INFO - 2025-05-08 17:52:20 --> Language Class Initialized
INFO - 2025-05-08 17:52:20 --> Loader Class Initialized
INFO - 2025-05-08 17:52:20 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:20 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:20 --> Controller Class Initialized
INFO - 2025-05-08 17:52:24 --> Config Class Initialized
INFO - 2025-05-08 17:52:24 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:24 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:24 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:24 --> URI Class Initialized
DEBUG - 2025-05-08 17:52:24 --> No URI present. Default controller set.
INFO - 2025-05-08 17:52:24 --> Router Class Initialized
INFO - 2025-05-08 17:52:24 --> Output Class Initialized
INFO - 2025-05-08 17:52:24 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:24 --> Input Class Initialized
INFO - 2025-05-08 17:52:24 --> Language Class Initialized
INFO - 2025-05-08 17:52:24 --> Loader Class Initialized
INFO - 2025-05-08 17:52:24 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:24 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:24 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:24 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:24 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:24 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:24 --> Controller Class Initialized
INFO - 2025-05-08 17:52:24 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:52:24 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:52:24 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:52:24 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:52:24 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:52:24 --> Final output sent to browser
DEBUG - 2025-05-08 17:52:24 --> Total execution time: 0.0027
INFO - 2025-05-08 17:52:31 --> Config Class Initialized
INFO - 2025-05-08 17:52:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:31 --> URI Class Initialized
INFO - 2025-05-08 17:52:31 --> Router Class Initialized
INFO - 2025-05-08 17:52:31 --> Output Class Initialized
INFO - 2025-05-08 17:52:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:31 --> Input Class Initialized
INFO - 2025-05-08 17:52:31 --> Language Class Initialized
INFO - 2025-05-08 17:52:31 --> Loader Class Initialized
INFO - 2025-05-08 17:52:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:31 --> Controller Class Initialized
INFO - 2025-05-08 17:52:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:52:33 --> Config Class Initialized
INFO - 2025-05-08 17:52:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:33 --> URI Class Initialized
INFO - 2025-05-08 17:52:33 --> Router Class Initialized
INFO - 2025-05-08 17:52:33 --> Output Class Initialized
INFO - 2025-05-08 17:52:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:33 --> Input Class Initialized
INFO - 2025-05-08 17:52:33 --> Language Class Initialized
INFO - 2025-05-08 17:52:33 --> Loader Class Initialized
INFO - 2025-05-08 17:52:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:33 --> Controller Class Initialized
INFO - 2025-05-08 17:52:33 --> Config Class Initialized
INFO - 2025-05-08 17:52:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:33 --> URI Class Initialized
INFO - 2025-05-08 17:52:33 --> Router Class Initialized
INFO - 2025-05-08 17:52:33 --> Output Class Initialized
INFO - 2025-05-08 17:52:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:33 --> Input Class Initialized
INFO - 2025-05-08 17:52:33 --> Language Class Initialized
INFO - 2025-05-08 17:52:33 --> Loader Class Initialized
INFO - 2025-05-08 17:52:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:33 --> Controller Class Initialized
INFO - 2025-05-08 17:52:33 --> Config Class Initialized
INFO - 2025-05-08 17:52:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:33 --> URI Class Initialized
INFO - 2025-05-08 17:52:33 --> Router Class Initialized
INFO - 2025-05-08 17:52:33 --> Output Class Initialized
INFO - 2025-05-08 17:52:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:33 --> Input Class Initialized
INFO - 2025-05-08 17:52:33 --> Language Class Initialized
INFO - 2025-05-08 17:52:33 --> Loader Class Initialized
INFO - 2025-05-08 17:52:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:33 --> Controller Class Initialized
INFO - 2025-05-08 17:52:43 --> Config Class Initialized
INFO - 2025-05-08 17:52:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:43 --> URI Class Initialized
INFO - 2025-05-08 17:52:43 --> Router Class Initialized
INFO - 2025-05-08 17:52:43 --> Output Class Initialized
INFO - 2025-05-08 17:52:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:43 --> Input Class Initialized
INFO - 2025-05-08 17:52:43 --> Language Class Initialized
INFO - 2025-05-08 17:52:43 --> Loader Class Initialized
INFO - 2025-05-08 17:52:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:43 --> Controller Class Initialized
INFO - 2025-05-08 17:52:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:52:43 --> Config Class Initialized
INFO - 2025-05-08 17:52:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:43 --> URI Class Initialized
INFO - 2025-05-08 17:52:43 --> Router Class Initialized
INFO - 2025-05-08 17:52:43 --> Output Class Initialized
INFO - 2025-05-08 17:52:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:43 --> Input Class Initialized
INFO - 2025-05-08 17:52:43 --> Language Class Initialized
INFO - 2025-05-08 17:52:43 --> Loader Class Initialized
INFO - 2025-05-08 17:52:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:43 --> Controller Class Initialized
INFO - 2025-05-08 17:52:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:52:51 --> Config Class Initialized
INFO - 2025-05-08 17:52:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:51 --> URI Class Initialized
DEBUG - 2025-05-08 17:52:51 --> No URI present. Default controller set.
INFO - 2025-05-08 17:52:51 --> Router Class Initialized
INFO - 2025-05-08 17:52:51 --> Output Class Initialized
INFO - 2025-05-08 17:52:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:51 --> Input Class Initialized
INFO - 2025-05-08 17:52:51 --> Language Class Initialized
INFO - 2025-05-08 17:52:51 --> Loader Class Initialized
INFO - 2025-05-08 17:52:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:51 --> Controller Class Initialized
INFO - 2025-05-08 17:52:51 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:52:51 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:52:51 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:52:51 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:52:51 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:52:51 --> Final output sent to browser
DEBUG - 2025-05-08 17:52:51 --> Total execution time: 0.0028
INFO - 2025-05-08 17:52:55 --> Config Class Initialized
INFO - 2025-05-08 17:52:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:52:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:52:55 --> Utf8 Class Initialized
INFO - 2025-05-08 17:52:55 --> URI Class Initialized
INFO - 2025-05-08 17:52:55 --> Router Class Initialized
INFO - 2025-05-08 17:52:55 --> Output Class Initialized
INFO - 2025-05-08 17:52:55 --> Security Class Initialized
DEBUG - 2025-05-08 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:52:55 --> Input Class Initialized
INFO - 2025-05-08 17:52:55 --> Language Class Initialized
INFO - 2025-05-08 17:52:55 --> Loader Class Initialized
INFO - 2025-05-08 17:52:55 --> Helper loaded: url_helper
INFO - 2025-05-08 17:52:55 --> Helper loaded: string_helper
INFO - 2025-05-08 17:52:55 --> Helper loaded: form_helper
INFO - 2025-05-08 17:52:55 --> Helper loaded: file_helper
INFO - 2025-05-08 17:52:55 --> Helper loaded: html_helper
INFO - 2025-05-08 17:52:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:52:55 --> Controller Class Initialized
INFO - 2025-05-08 17:52:55 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:12 --> Config Class Initialized
INFO - 2025-05-08 17:53:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:12 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:12 --> URI Class Initialized
INFO - 2025-05-08 17:53:12 --> Router Class Initialized
INFO - 2025-05-08 17:53:12 --> Output Class Initialized
INFO - 2025-05-08 17:53:12 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:12 --> Input Class Initialized
INFO - 2025-05-08 17:53:12 --> Language Class Initialized
INFO - 2025-05-08 17:53:12 --> Loader Class Initialized
INFO - 2025-05-08 17:53:12 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:12 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:12 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:12 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:12 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:12 --> Controller Class Initialized
INFO - 2025-05-08 17:53:12 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:53:12 --> Final output sent to browser
DEBUG - 2025-05-08 17:53:12 --> Total execution time: 0.0110
INFO - 2025-05-08 17:53:13 --> Config Class Initialized
INFO - 2025-05-08 17:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:13 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:13 --> URI Class Initialized
INFO - 2025-05-08 17:53:13 --> Router Class Initialized
INFO - 2025-05-08 17:53:13 --> Output Class Initialized
INFO - 2025-05-08 17:53:13 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:13 --> Input Class Initialized
INFO - 2025-05-08 17:53:13 --> Language Class Initialized
INFO - 2025-05-08 17:53:13 --> Loader Class Initialized
INFO - 2025-05-08 17:53:13 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:13 --> Controller Class Initialized
INFO - 2025-05-08 17:53:13 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:13 --> Config Class Initialized
INFO - 2025-05-08 17:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:13 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:13 --> URI Class Initialized
INFO - 2025-05-08 17:53:13 --> Router Class Initialized
INFO - 2025-05-08 17:53:13 --> Output Class Initialized
INFO - 2025-05-08 17:53:13 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:13 --> Input Class Initialized
INFO - 2025-05-08 17:53:13 --> Language Class Initialized
INFO - 2025-05-08 17:53:13 --> Loader Class Initialized
INFO - 2025-05-08 17:53:13 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:13 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:13 --> Controller Class Initialized
INFO - 2025-05-08 17:53:13 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:14 --> Config Class Initialized
INFO - 2025-05-08 17:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:14 --> URI Class Initialized
INFO - 2025-05-08 17:53:14 --> Router Class Initialized
INFO - 2025-05-08 17:53:14 --> Output Class Initialized
INFO - 2025-05-08 17:53:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:14 --> Input Class Initialized
INFO - 2025-05-08 17:53:14 --> Language Class Initialized
INFO - 2025-05-08 17:53:14 --> Loader Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:14 --> Controller Class Initialized
INFO - 2025-05-08 17:53:14 --> Config Class Initialized
INFO - 2025-05-08 17:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:14 --> URI Class Initialized
INFO - 2025-05-08 17:53:14 --> Config Class Initialized
INFO - 2025-05-08 17:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:14 --> Router Class Initialized
INFO - 2025-05-08 17:53:14 --> URI Class Initialized
INFO - 2025-05-08 17:53:14 --> Output Class Initialized
INFO - 2025-05-08 17:53:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:14 --> Config Class Initialized
INFO - 2025-05-08 17:53:14 --> Input Class Initialized
INFO - 2025-05-08 17:53:14 --> Hooks Class Initialized
INFO - 2025-05-08 17:53:14 --> Language Class Initialized
INFO - 2025-05-08 17:53:14 --> Router Class Initialized
INFO - 2025-05-08 17:53:14 --> Loader Class Initialized
DEBUG - 2025-05-08 17:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:14 --> Output Class Initialized
INFO - 2025-05-08 17:53:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:14 --> Security Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:14 --> URI Class Initialized
INFO - 2025-05-08 17:53:14 --> Input Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:14 --> Language Class Initialized
INFO - 2025-05-08 17:53:14 --> Config Class Initialized
INFO - 2025-05-08 17:53:14 --> Hooks Class Initialized
INFO - 2025-05-08 17:53:14 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:14 --> Loader Class Initialized
DEBUG - 2025-05-08 17:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:14 --> URI Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:14 --> Router Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:14 --> Output Class Initialized
INFO - 2025-05-08 17:53:14 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:14 --> Input Class Initialized
INFO - 2025-05-08 17:53:14 --> Language Class Initialized
INFO - 2025-05-08 17:53:14 --> Router Class Initialized
INFO - 2025-05-08 17:53:14 --> Loader Class Initialized
INFO - 2025-05-08 17:53:14 --> Output Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:14 --> Security Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: string_helper
DEBUG - 2025-05-08 17:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:14 --> Input Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: form_helper
DEBUG - 2025-05-08 17:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:14 --> Language Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:14 --> Loader Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:14 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:14 --> Controller Class Initialized
INFO - 2025-05-08 17:53:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:14 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:14 --> Controller Class Initialized
DEBUG - 2025-05-08 17:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:14 --> Controller Class Initialized
INFO - 2025-05-08 17:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:14 --> Controller Class Initialized
INFO - 2025-05-08 17:53:25 --> Config Class Initialized
INFO - 2025-05-08 17:53:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:25 --> URI Class Initialized
DEBUG - 2025-05-08 17:53:25 --> No URI present. Default controller set.
INFO - 2025-05-08 17:53:25 --> Router Class Initialized
INFO - 2025-05-08 17:53:25 --> Output Class Initialized
INFO - 2025-05-08 17:53:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:25 --> Input Class Initialized
INFO - 2025-05-08 17:53:25 --> Language Class Initialized
INFO - 2025-05-08 17:53:25 --> Loader Class Initialized
INFO - 2025-05-08 17:53:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:25 --> Controller Class Initialized
INFO - 2025-05-08 17:53:25 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:53:25 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:53:25 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:53:25 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:53:25 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:53:25 --> Final output sent to browser
DEBUG - 2025-05-08 17:53:25 --> Total execution time: 0.0031
INFO - 2025-05-08 17:53:32 --> Config Class Initialized
INFO - 2025-05-08 17:53:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:32 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:32 --> URI Class Initialized
INFO - 2025-05-08 17:53:32 --> Router Class Initialized
INFO - 2025-05-08 17:53:32 --> Output Class Initialized
INFO - 2025-05-08 17:53:32 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:32 --> Input Class Initialized
INFO - 2025-05-08 17:53:32 --> Language Class Initialized
INFO - 2025-05-08 17:53:32 --> Loader Class Initialized
INFO - 2025-05-08 17:53:32 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:32 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:32 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:32 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:32 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:32 --> Controller Class Initialized
INFO - 2025-05-08 17:53:32 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:33 --> Config Class Initialized
INFO - 2025-05-08 17:53:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:33 --> URI Class Initialized
INFO - 2025-05-08 17:53:33 --> Router Class Initialized
INFO - 2025-05-08 17:53:33 --> Output Class Initialized
INFO - 2025-05-08 17:53:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:33 --> Input Class Initialized
INFO - 2025-05-08 17:53:33 --> Language Class Initialized
INFO - 2025-05-08 17:53:33 --> Loader Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:33 --> Config Class Initialized
INFO - 2025-05-08 17:53:33 --> Controller Class Initialized
INFO - 2025-05-08 17:53:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:33 --> URI Class Initialized
INFO - 2025-05-08 17:53:33 --> Config Class Initialized
INFO - 2025-05-08 17:53:33 --> Hooks Class Initialized
INFO - 2025-05-08 17:53:33 --> Config Class Initialized
DEBUG - 2025-05-08 17:53:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:33 --> Router Class Initialized
INFO - 2025-05-08 17:53:33 --> Hooks Class Initialized
INFO - 2025-05-08 17:53:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:33 --> Output Class Initialized
DEBUG - 2025-05-08 17:53:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:33 --> URI Class Initialized
INFO - 2025-05-08 17:53:33 --> Security Class Initialized
INFO - 2025-05-08 17:53:33 --> URI Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:33 --> Input Class Initialized
INFO - 2025-05-08 17:53:33 --> Language Class Initialized
INFO - 2025-05-08 17:53:33 --> Loader Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:33 --> Router Class Initialized
INFO - 2025-05-08 17:53:33 --> Router Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:33 --> Output Class Initialized
INFO - 2025-05-08 17:53:33 --> Output Class Initialized
INFO - 2025-05-08 17:53:33 --> Security Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:33 --> Security Class Initialized
INFO - 2025-05-08 17:53:33 --> Config Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:33 --> Hooks Class Initialized
INFO - 2025-05-08 17:53:33 --> Input Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: file_helper
DEBUG - 2025-05-08 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:33 --> Language Class Initialized
INFO - 2025-05-08 17:53:33 --> Input Class Initialized
DEBUG - 2025-05-08 17:53:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:33 --> Loader Class Initialized
INFO - 2025-05-08 17:53:33 --> Language Class Initialized
INFO - 2025-05-08 17:53:33 --> URI Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:33 --> Loader Class Initialized
INFO - 2025-05-08 17:53:33 --> Router Class Initialized
INFO - 2025-05-08 17:53:33 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:33 --> Output Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:33 --> Security Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: html_helper
DEBUG - 2025-05-08 17:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:33 --> Input Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:33 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:33 --> Language Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:33 --> Loader Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:33 --> Database Driver Class Initialized
INFO - 2025-05-08 17:53:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-08 17:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:33 --> Controller Class Initialized
DEBUG - 2025-05-08 17:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:33 --> Controller Class Initialized
INFO - 2025-05-08 17:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:33 --> Controller Class Initialized
INFO - 2025-05-08 17:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:33 --> Controller Class Initialized
INFO - 2025-05-08 17:53:41 --> Config Class Initialized
INFO - 2025-05-08 17:53:41 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:41 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:41 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:41 --> URI Class Initialized
INFO - 2025-05-08 17:53:41 --> Router Class Initialized
INFO - 2025-05-08 17:53:41 --> Output Class Initialized
INFO - 2025-05-08 17:53:41 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:41 --> Input Class Initialized
INFO - 2025-05-08 17:53:41 --> Language Class Initialized
INFO - 2025-05-08 17:53:41 --> Loader Class Initialized
INFO - 2025-05-08 17:53:41 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:41 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:41 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:41 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:41 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:41 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:41 --> Controller Class Initialized
INFO - 2025-05-08 17:53:41 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:42 --> Config Class Initialized
INFO - 2025-05-08 17:53:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:42 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:42 --> URI Class Initialized
INFO - 2025-05-08 17:53:42 --> Router Class Initialized
INFO - 2025-05-08 17:53:42 --> Output Class Initialized
INFO - 2025-05-08 17:53:42 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:42 --> Input Class Initialized
INFO - 2025-05-08 17:53:42 --> Language Class Initialized
INFO - 2025-05-08 17:53:42 --> Loader Class Initialized
INFO - 2025-05-08 17:53:42 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:42 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:42 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:42 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:42 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:42 --> Controller Class Initialized
INFO - 2025-05-08 17:53:42 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:50 --> Config Class Initialized
INFO - 2025-05-08 17:53:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:50 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:50 --> URI Class Initialized
DEBUG - 2025-05-08 17:53:50 --> No URI present. Default controller set.
INFO - 2025-05-08 17:53:50 --> Router Class Initialized
INFO - 2025-05-08 17:53:50 --> Output Class Initialized
INFO - 2025-05-08 17:53:50 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:50 --> Input Class Initialized
INFO - 2025-05-08 17:53:50 --> Language Class Initialized
INFO - 2025-05-08 17:53:50 --> Loader Class Initialized
INFO - 2025-05-08 17:53:50 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:50 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:50 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:50 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:50 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:50 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:50 --> Controller Class Initialized
INFO - 2025-05-08 17:53:50 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:53:50 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:53:50 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:53:50 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:53:50 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:53:50 --> Final output sent to browser
DEBUG - 2025-05-08 17:53:50 --> Total execution time: 0.0029
INFO - 2025-05-08 17:53:53 --> Config Class Initialized
INFO - 2025-05-08 17:53:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:53 --> URI Class Initialized
INFO - 2025-05-08 17:53:53 --> Router Class Initialized
INFO - 2025-05-08 17:53:53 --> Output Class Initialized
INFO - 2025-05-08 17:53:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:53 --> Input Class Initialized
INFO - 2025-05-08 17:53:53 --> Language Class Initialized
INFO - 2025-05-08 17:53:53 --> Loader Class Initialized
INFO - 2025-05-08 17:53:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:53 --> Controller Class Initialized
INFO - 2025-05-08 17:53:53 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:53:55 --> Config Class Initialized
INFO - 2025-05-08 17:53:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:55 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:55 --> URI Class Initialized
INFO - 2025-05-08 17:53:55 --> Router Class Initialized
INFO - 2025-05-08 17:53:55 --> Output Class Initialized
INFO - 2025-05-08 17:53:55 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:55 --> Input Class Initialized
INFO - 2025-05-08 17:53:55 --> Language Class Initialized
INFO - 2025-05-08 17:53:55 --> Loader Class Initialized
INFO - 2025-05-08 17:53:55 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:55 --> Controller Class Initialized
INFO - 2025-05-08 17:53:55 --> Config Class Initialized
INFO - 2025-05-08 17:53:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:55 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:55 --> URI Class Initialized
INFO - 2025-05-08 17:53:55 --> Router Class Initialized
INFO - 2025-05-08 17:53:55 --> Output Class Initialized
INFO - 2025-05-08 17:53:55 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:55 --> Input Class Initialized
INFO - 2025-05-08 17:53:55 --> Language Class Initialized
INFO - 2025-05-08 17:53:55 --> Loader Class Initialized
INFO - 2025-05-08 17:53:55 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:55 --> Controller Class Initialized
INFO - 2025-05-08 17:53:55 --> Config Class Initialized
INFO - 2025-05-08 17:53:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:53:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:53:55 --> Utf8 Class Initialized
INFO - 2025-05-08 17:53:55 --> URI Class Initialized
INFO - 2025-05-08 17:53:55 --> Router Class Initialized
INFO - 2025-05-08 17:53:55 --> Output Class Initialized
INFO - 2025-05-08 17:53:55 --> Security Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:53:55 --> Input Class Initialized
INFO - 2025-05-08 17:53:55 --> Language Class Initialized
INFO - 2025-05-08 17:53:55 --> Loader Class Initialized
INFO - 2025-05-08 17:53:55 --> Helper loaded: url_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: string_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: form_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: file_helper
INFO - 2025-05-08 17:53:55 --> Helper loaded: html_helper
INFO - 2025-05-08 17:53:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:53:55 --> Controller Class Initialized
INFO - 2025-05-08 17:54:11 --> Config Class Initialized
INFO - 2025-05-08 17:54:11 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:11 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:11 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:11 --> URI Class Initialized
INFO - 2025-05-08 17:54:11 --> Router Class Initialized
INFO - 2025-05-08 17:54:11 --> Output Class Initialized
INFO - 2025-05-08 17:54:11 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:11 --> Input Class Initialized
INFO - 2025-05-08 17:54:11 --> Language Class Initialized
INFO - 2025-05-08 17:54:11 --> Loader Class Initialized
INFO - 2025-05-08 17:54:11 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:11 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:11 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:11 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:11 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:11 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:11 --> Controller Class Initialized
INFO - 2025-05-08 17:54:11 --> Model "UploadModel" initialized
INFO - 2025-05-08 17:54:11 --> Final output sent to browser
DEBUG - 2025-05-08 17:54:11 --> Total execution time: 0.0063
INFO - 2025-05-08 17:54:12 --> Config Class Initialized
INFO - 2025-05-08 17:54:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:12 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:12 --> URI Class Initialized
INFO - 2025-05-08 17:54:12 --> Router Class Initialized
INFO - 2025-05-08 17:54:12 --> Output Class Initialized
INFO - 2025-05-08 17:54:12 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:12 --> Input Class Initialized
INFO - 2025-05-08 17:54:12 --> Language Class Initialized
INFO - 2025-05-08 17:54:12 --> Loader Class Initialized
INFO - 2025-05-08 17:54:12 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:12 --> Controller Class Initialized
INFO - 2025-05-08 17:54:12 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:12 --> Config Class Initialized
INFO - 2025-05-08 17:54:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:12 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:12 --> URI Class Initialized
INFO - 2025-05-08 17:54:12 --> Router Class Initialized
INFO - 2025-05-08 17:54:12 --> Output Class Initialized
INFO - 2025-05-08 17:54:12 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:12 --> Input Class Initialized
INFO - 2025-05-08 17:54:12 --> Language Class Initialized
INFO - 2025-05-08 17:54:12 --> Loader Class Initialized
INFO - 2025-05-08 17:54:12 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:12 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:12 --> Controller Class Initialized
INFO - 2025-05-08 17:54:12 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:13 --> Config Class Initialized
INFO - 2025-05-08 17:54:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:13 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:13 --> URI Class Initialized
INFO - 2025-05-08 17:54:13 --> Router Class Initialized
INFO - 2025-05-08 17:54:13 --> Output Class Initialized
INFO - 2025-05-08 17:54:13 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:13 --> Input Class Initialized
INFO - 2025-05-08 17:54:13 --> Language Class Initialized
INFO - 2025-05-08 17:54:13 --> Loader Class Initialized
INFO - 2025-05-08 17:54:13 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:13 --> Controller Class Initialized
INFO - 2025-05-08 17:54:13 --> Config Class Initialized
INFO - 2025-05-08 17:54:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:13 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:13 --> URI Class Initialized
INFO - 2025-05-08 17:54:13 --> Router Class Initialized
INFO - 2025-05-08 17:54:13 --> Output Class Initialized
INFO - 2025-05-08 17:54:13 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:13 --> Input Class Initialized
INFO - 2025-05-08 17:54:13 --> Language Class Initialized
INFO - 2025-05-08 17:54:13 --> Loader Class Initialized
INFO - 2025-05-08 17:54:13 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:13 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:13 --> Controller Class Initialized
INFO - 2025-05-08 17:54:24 --> Config Class Initialized
INFO - 2025-05-08 17:54:24 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:24 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:24 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:24 --> URI Class Initialized
DEBUG - 2025-05-08 17:54:24 --> No URI present. Default controller set.
INFO - 2025-05-08 17:54:24 --> Router Class Initialized
INFO - 2025-05-08 17:54:24 --> Output Class Initialized
INFO - 2025-05-08 17:54:24 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:24 --> Input Class Initialized
INFO - 2025-05-08 17:54:24 --> Language Class Initialized
INFO - 2025-05-08 17:54:24 --> Loader Class Initialized
INFO - 2025-05-08 17:54:24 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:24 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:24 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:24 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:24 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:24 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:24 --> Controller Class Initialized
INFO - 2025-05-08 17:54:24 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:54:24 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:54:24 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:54:24 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:54:24 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:54:24 --> Final output sent to browser
DEBUG - 2025-05-08 17:54:24 --> Total execution time: 0.0032
INFO - 2025-05-08 17:54:28 --> Config Class Initialized
INFO - 2025-05-08 17:54:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:28 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:28 --> URI Class Initialized
INFO - 2025-05-08 17:54:28 --> Router Class Initialized
INFO - 2025-05-08 17:54:28 --> Output Class Initialized
INFO - 2025-05-08 17:54:28 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:28 --> Input Class Initialized
INFO - 2025-05-08 17:54:28 --> Language Class Initialized
INFO - 2025-05-08 17:54:28 --> Loader Class Initialized
INFO - 2025-05-08 17:54:28 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:28 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:28 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:28 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:28 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:28 --> Controller Class Initialized
INFO - 2025-05-08 17:54:28 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:29 --> Config Class Initialized
INFO - 2025-05-08 17:54:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:29 --> URI Class Initialized
INFO - 2025-05-08 17:54:29 --> Router Class Initialized
INFO - 2025-05-08 17:54:29 --> Output Class Initialized
INFO - 2025-05-08 17:54:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:29 --> Input Class Initialized
INFO - 2025-05-08 17:54:29 --> Language Class Initialized
INFO - 2025-05-08 17:54:29 --> Loader Class Initialized
INFO - 2025-05-08 17:54:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:29 --> Controller Class Initialized
INFO - 2025-05-08 17:54:29 --> Config Class Initialized
INFO - 2025-05-08 17:54:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:29 --> URI Class Initialized
INFO - 2025-05-08 17:54:29 --> Router Class Initialized
INFO - 2025-05-08 17:54:29 --> Output Class Initialized
INFO - 2025-05-08 17:54:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:29 --> Input Class Initialized
INFO - 2025-05-08 17:54:29 --> Language Class Initialized
INFO - 2025-05-08 17:54:29 --> Loader Class Initialized
INFO - 2025-05-08 17:54:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:29 --> Controller Class Initialized
INFO - 2025-05-08 17:54:29 --> Config Class Initialized
INFO - 2025-05-08 17:54:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:29 --> URI Class Initialized
INFO - 2025-05-08 17:54:29 --> Router Class Initialized
INFO - 2025-05-08 17:54:29 --> Output Class Initialized
INFO - 2025-05-08 17:54:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:29 --> Input Class Initialized
INFO - 2025-05-08 17:54:29 --> Language Class Initialized
INFO - 2025-05-08 17:54:29 --> Loader Class Initialized
INFO - 2025-05-08 17:54:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:29 --> Config Class Initialized
INFO - 2025-05-08 17:54:29 --> Database Driver Class Initialized
INFO - 2025-05-08 17:54:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:29 --> URI Class Initialized
INFO - 2025-05-08 17:54:29 --> Router Class Initialized
INFO - 2025-05-08 17:54:29 --> Output Class Initialized
INFO - 2025-05-08 17:54:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:29 --> Input Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:29 --> Language Class Initialized
INFO - 2025-05-08 17:54:29 --> Loader Class Initialized
INFO - 2025-05-08 17:54:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:29 --> Controller Class Initialized
INFO - 2025-05-08 17:54:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:29 --> Controller Class Initialized
INFO - 2025-05-08 17:54:39 --> Config Class Initialized
INFO - 2025-05-08 17:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:39 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:39 --> URI Class Initialized
INFO - 2025-05-08 17:54:39 --> Router Class Initialized
INFO - 2025-05-08 17:54:39 --> Output Class Initialized
INFO - 2025-05-08 17:54:39 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:39 --> Input Class Initialized
INFO - 2025-05-08 17:54:39 --> Language Class Initialized
INFO - 2025-05-08 17:54:39 --> Loader Class Initialized
INFO - 2025-05-08 17:54:39 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:39 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:39 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:39 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:39 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:39 --> Controller Class Initialized
INFO - 2025-05-08 17:54:39 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:40 --> Config Class Initialized
INFO - 2025-05-08 17:54:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:40 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:40 --> URI Class Initialized
INFO - 2025-05-08 17:54:40 --> Router Class Initialized
INFO - 2025-05-08 17:54:40 --> Output Class Initialized
INFO - 2025-05-08 17:54:40 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:40 --> Input Class Initialized
INFO - 2025-05-08 17:54:40 --> Language Class Initialized
INFO - 2025-05-08 17:54:40 --> Loader Class Initialized
INFO - 2025-05-08 17:54:40 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:40 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:40 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:40 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:40 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:40 --> Controller Class Initialized
INFO - 2025-05-08 17:54:40 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:42 --> Config Class Initialized
INFO - 2025-05-08 17:54:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:42 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:42 --> URI Class Initialized
INFO - 2025-05-08 17:54:42 --> Router Class Initialized
INFO - 2025-05-08 17:54:42 --> Output Class Initialized
INFO - 2025-05-08 17:54:42 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:42 --> Input Class Initialized
INFO - 2025-05-08 17:54:42 --> Language Class Initialized
INFO - 2025-05-08 17:54:42 --> Loader Class Initialized
INFO - 2025-05-08 17:54:42 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:42 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:42 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:42 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:42 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:42 --> Controller Class Initialized
INFO - 2025-05-08 17:54:42 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:43 --> Config Class Initialized
INFO - 2025-05-08 17:54:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:43 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:43 --> URI Class Initialized
INFO - 2025-05-08 17:54:43 --> Router Class Initialized
INFO - 2025-05-08 17:54:43 --> Output Class Initialized
INFO - 2025-05-08 17:54:43 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:43 --> Input Class Initialized
INFO - 2025-05-08 17:54:43 --> Language Class Initialized
INFO - 2025-05-08 17:54:43 --> Loader Class Initialized
INFO - 2025-05-08 17:54:43 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:43 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:43 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:43 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:43 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:43 --> Controller Class Initialized
INFO - 2025-05-08 17:54:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:54:47 --> Config Class Initialized
INFO - 2025-05-08 17:54:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:47 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:47 --> URI Class Initialized
DEBUG - 2025-05-08 17:54:47 --> No URI present. Default controller set.
INFO - 2025-05-08 17:54:47 --> Router Class Initialized
INFO - 2025-05-08 17:54:47 --> Output Class Initialized
INFO - 2025-05-08 17:54:47 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:47 --> Input Class Initialized
INFO - 2025-05-08 17:54:47 --> Language Class Initialized
INFO - 2025-05-08 17:54:47 --> Loader Class Initialized
INFO - 2025-05-08 17:54:47 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:47 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:47 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:47 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:47 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:47 --> Controller Class Initialized
INFO - 2025-05-08 17:54:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:54:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:54:47 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:54:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:54:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:54:47 --> Final output sent to browser
DEBUG - 2025-05-08 17:54:47 --> Total execution time: 0.0028
INFO - 2025-05-08 17:54:58 --> Config Class Initialized
INFO - 2025-05-08 17:54:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:54:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:54:58 --> Utf8 Class Initialized
INFO - 2025-05-08 17:54:58 --> URI Class Initialized
INFO - 2025-05-08 17:54:58 --> Router Class Initialized
INFO - 2025-05-08 17:54:58 --> Output Class Initialized
INFO - 2025-05-08 17:54:58 --> Security Class Initialized
DEBUG - 2025-05-08 17:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:54:58 --> Input Class Initialized
INFO - 2025-05-08 17:54:58 --> Language Class Initialized
INFO - 2025-05-08 17:54:58 --> Loader Class Initialized
INFO - 2025-05-08 17:54:58 --> Helper loaded: url_helper
INFO - 2025-05-08 17:54:58 --> Helper loaded: string_helper
INFO - 2025-05-08 17:54:58 --> Helper loaded: form_helper
INFO - 2025-05-08 17:54:58 --> Helper loaded: file_helper
INFO - 2025-05-08 17:54:58 --> Helper loaded: html_helper
INFO - 2025-05-08 17:54:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:54:58 --> Controller Class Initialized
INFO - 2025-05-08 17:54:58 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:09 --> Config Class Initialized
INFO - 2025-05-08 17:58:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:09 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:09 --> URI Class Initialized
DEBUG - 2025-05-08 17:58:09 --> No URI present. Default controller set.
INFO - 2025-05-08 17:58:09 --> Router Class Initialized
INFO - 2025-05-08 17:58:09 --> Output Class Initialized
INFO - 2025-05-08 17:58:09 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:09 --> Input Class Initialized
INFO - 2025-05-08 17:58:09 --> Language Class Initialized
INFO - 2025-05-08 17:58:09 --> Loader Class Initialized
INFO - 2025-05-08 17:58:09 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:09 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:09 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:09 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:09 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:09 --> Controller Class Initialized
INFO - 2025-05-08 17:58:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:58:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:58:09 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 17:58:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:58:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:58:09 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:09 --> Total execution time: 0.0361
INFO - 2025-05-08 17:58:12 --> Config Class Initialized
INFO - 2025-05-08 17:58:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:12 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:12 --> URI Class Initialized
INFO - 2025-05-08 17:58:12 --> Router Class Initialized
INFO - 2025-05-08 17:58:12 --> Output Class Initialized
INFO - 2025-05-08 17:58:12 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:12 --> Input Class Initialized
INFO - 2025-05-08 17:58:12 --> Language Class Initialized
INFO - 2025-05-08 17:58:12 --> Loader Class Initialized
INFO - 2025-05-08 17:58:12 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:12 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:12 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:12 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:12 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:12 --> Controller Class Initialized
INFO - 2025-05-08 17:58:12 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:33 --> Config Class Initialized
INFO - 2025-05-08 17:58:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:33 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:33 --> URI Class Initialized
INFO - 2025-05-08 17:58:33 --> Router Class Initialized
INFO - 2025-05-08 17:58:33 --> Output Class Initialized
INFO - 2025-05-08 17:58:33 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:33 --> Input Class Initialized
INFO - 2025-05-08 17:58:33 --> Language Class Initialized
INFO - 2025-05-08 17:58:33 --> Loader Class Initialized
INFO - 2025-05-08 17:58:33 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:33 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:33 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:33 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:33 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:33 --> Controller Class Initialized
INFO - 2025-05-08 17:58:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:58:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:58:33 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 17:58:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:58:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:58:33 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:33 --> Total execution time: 0.0050
INFO - 2025-05-08 17:58:37 --> Config Class Initialized
INFO - 2025-05-08 17:58:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:37 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:37 --> URI Class Initialized
INFO - 2025-05-08 17:58:37 --> Router Class Initialized
INFO - 2025-05-08 17:58:37 --> Output Class Initialized
INFO - 2025-05-08 17:58:37 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:37 --> Input Class Initialized
INFO - 2025-05-08 17:58:37 --> Language Class Initialized
INFO - 2025-05-08 17:58:37 --> Loader Class Initialized
INFO - 2025-05-08 17:58:37 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:37 --> Controller Class Initialized
INFO - 2025-05-08 17:58:37 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:37 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:37 --> Total execution time: 0.0034
INFO - 2025-05-08 17:58:37 --> Config Class Initialized
INFO - 2025-05-08 17:58:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:37 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:37 --> URI Class Initialized
INFO - 2025-05-08 17:58:37 --> Router Class Initialized
INFO - 2025-05-08 17:58:37 --> Output Class Initialized
INFO - 2025-05-08 17:58:37 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:37 --> Input Class Initialized
INFO - 2025-05-08 17:58:37 --> Language Class Initialized
INFO - 2025-05-08 17:58:37 --> Loader Class Initialized
INFO - 2025-05-08 17:58:37 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:37 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:37 --> Controller Class Initialized
INFO - 2025-05-08 17:58:37 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:58:37 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:58:37 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:40 --> Config Class Initialized
INFO - 2025-05-08 17:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:40 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:40 --> URI Class Initialized
INFO - 2025-05-08 17:58:40 --> Router Class Initialized
INFO - 2025-05-08 17:58:40 --> Output Class Initialized
INFO - 2025-05-08 17:58:40 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:40 --> Input Class Initialized
INFO - 2025-05-08 17:58:40 --> Language Class Initialized
INFO - 2025-05-08 17:58:40 --> Loader Class Initialized
INFO - 2025-05-08 17:58:40 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:40 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:40 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:40 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:40 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:40 --> Controller Class Initialized
INFO - 2025-05-08 17:58:40 --> Model "UserModel" initialized
INFO - 2025-05-08 17:58:40 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:40 --> Total execution time: 0.0075
INFO - 2025-05-08 17:58:46 --> Config Class Initialized
INFO - 2025-05-08 17:58:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:46 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:46 --> URI Class Initialized
INFO - 2025-05-08 17:58:46 --> Router Class Initialized
INFO - 2025-05-08 17:58:46 --> Output Class Initialized
INFO - 2025-05-08 17:58:46 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:46 --> Input Class Initialized
INFO - 2025-05-08 17:58:46 --> Language Class Initialized
INFO - 2025-05-08 17:58:46 --> Loader Class Initialized
INFO - 2025-05-08 17:58:46 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:46 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:46 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:46 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:46 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:46 --> Controller Class Initialized
INFO - 2025-05-08 17:58:46 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:58:46 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:58:46 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 17:58:46 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:58:46 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:58:46 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:46 --> Total execution time: 0.0047
INFO - 2025-05-08 17:58:49 --> Config Class Initialized
INFO - 2025-05-08 17:58:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:49 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:49 --> URI Class Initialized
INFO - 2025-05-08 17:58:49 --> Router Class Initialized
INFO - 2025-05-08 17:58:49 --> Output Class Initialized
INFO - 2025-05-08 17:58:49 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:49 --> Input Class Initialized
INFO - 2025-05-08 17:58:49 --> Language Class Initialized
INFO - 2025-05-08 17:58:49 --> Loader Class Initialized
INFO - 2025-05-08 17:58:49 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:49 --> Controller Class Initialized
INFO - 2025-05-08 17:58:49 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:58:49 --> Config Class Initialized
INFO - 2025-05-08 17:58:49 --> Hooks Class Initialized
INFO - 2025-05-08 17:58:49 --> Model "StorageFacilityModel" initialized
DEBUG - 2025-05-08 17:58:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:49 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:49 --> URI Class Initialized
INFO - 2025-05-08 17:58:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:49 --> Router Class Initialized
INFO - 2025-05-08 17:58:49 --> Output Class Initialized
INFO - 2025-05-08 17:58:49 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:49 --> Input Class Initialized
INFO - 2025-05-08 17:58:49 --> Language Class Initialized
INFO - 2025-05-08 17:58:49 --> Loader Class Initialized
INFO - 2025-05-08 17:58:49 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:49 --> Controller Class Initialized
INFO - 2025-05-08 17:58:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:49 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:49 --> Total execution time: 0.0046
INFO - 2025-05-08 17:58:49 --> Config Class Initialized
INFO - 2025-05-08 17:58:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:49 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:49 --> URI Class Initialized
INFO - 2025-05-08 17:58:49 --> Router Class Initialized
INFO - 2025-05-08 17:58:49 --> Output Class Initialized
INFO - 2025-05-08 17:58:49 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:49 --> Input Class Initialized
INFO - 2025-05-08 17:58:49 --> Language Class Initialized
INFO - 2025-05-08 17:58:49 --> Loader Class Initialized
INFO - 2025-05-08 17:58:49 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:49 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:49 --> Controller Class Initialized
INFO - 2025-05-08 17:58:49 --> Model "UserModel" initialized
INFO - 2025-05-08 17:58:49 --> Final output sent to browser
DEBUG - 2025-05-08 17:58:49 --> Total execution time: 0.0029
INFO - 2025-05-08 17:58:51 --> Config Class Initialized
INFO - 2025-05-08 17:58:51 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:51 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:51 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:51 --> URI Class Initialized
INFO - 2025-05-08 17:58:51 --> Router Class Initialized
INFO - 2025-05-08 17:58:51 --> Output Class Initialized
INFO - 2025-05-08 17:58:51 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:51 --> Input Class Initialized
INFO - 2025-05-08 17:58:51 --> Language Class Initialized
INFO - 2025-05-08 17:58:51 --> Loader Class Initialized
INFO - 2025-05-08 17:58:51 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:51 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:51 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:51 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:51 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:51 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:51 --> Controller Class Initialized
INFO - 2025-05-08 17:58:51 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:58:51 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:58:51 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:53 --> Config Class Initialized
INFO - 2025-05-08 17:58:53 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:53 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:53 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:53 --> URI Class Initialized
INFO - 2025-05-08 17:58:53 --> Router Class Initialized
INFO - 2025-05-08 17:58:53 --> Output Class Initialized
INFO - 2025-05-08 17:58:53 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:53 --> Input Class Initialized
INFO - 2025-05-08 17:58:53 --> Language Class Initialized
INFO - 2025-05-08 17:58:53 --> Loader Class Initialized
INFO - 2025-05-08 17:58:53 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:53 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:53 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:53 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:53 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:53 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:53 --> Controller Class Initialized
INFO - 2025-05-08 17:58:53 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:58:53 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:58:53 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:58:55 --> Config Class Initialized
INFO - 2025-05-08 17:58:55 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:58:55 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:58:55 --> Utf8 Class Initialized
INFO - 2025-05-08 17:58:55 --> URI Class Initialized
INFO - 2025-05-08 17:58:55 --> Router Class Initialized
INFO - 2025-05-08 17:58:55 --> Output Class Initialized
INFO - 2025-05-08 17:58:55 --> Security Class Initialized
DEBUG - 2025-05-08 17:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:58:55 --> Input Class Initialized
INFO - 2025-05-08 17:58:55 --> Language Class Initialized
INFO - 2025-05-08 17:58:55 --> Loader Class Initialized
INFO - 2025-05-08 17:58:55 --> Helper loaded: url_helper
INFO - 2025-05-08 17:58:55 --> Helper loaded: string_helper
INFO - 2025-05-08 17:58:55 --> Helper loaded: form_helper
INFO - 2025-05-08 17:58:55 --> Helper loaded: file_helper
INFO - 2025-05-08 17:58:55 --> Helper loaded: html_helper
INFO - 2025-05-08 17:58:55 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:58:55 --> Controller Class Initialized
INFO - 2025-05-08 17:58:55 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:58:55 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:58:55 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:07 --> Config Class Initialized
INFO - 2025-05-08 17:59:07 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:07 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:07 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:07 --> URI Class Initialized
INFO - 2025-05-08 17:59:07 --> Router Class Initialized
INFO - 2025-05-08 17:59:07 --> Output Class Initialized
INFO - 2025-05-08 17:59:07 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:07 --> Input Class Initialized
INFO - 2025-05-08 17:59:07 --> Language Class Initialized
INFO - 2025-05-08 17:59:07 --> Loader Class Initialized
INFO - 2025-05-08 17:59:07 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:07 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:07 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:07 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:07 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:07 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:07 --> Controller Class Initialized
INFO - 2025-05-08 17:59:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 17:59:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 17:59:07 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 17:59:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 17:59:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 17:59:07 --> Final output sent to browser
DEBUG - 2025-05-08 17:59:07 --> Total execution time: 0.0052
INFO - 2025-05-08 17:59:14 --> Config Class Initialized
INFO - 2025-05-08 17:59:14 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:14 --> URI Class Initialized
INFO - 2025-05-08 17:59:14 --> Router Class Initialized
INFO - 2025-05-08 17:59:14 --> Output Class Initialized
INFO - 2025-05-08 17:59:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:14 --> Input Class Initialized
INFO - 2025-05-08 17:59:14 --> Language Class Initialized
INFO - 2025-05-08 17:59:14 --> Config Class Initialized
INFO - 2025-05-08 17:59:14 --> Hooks Class Initialized
INFO - 2025-05-08 17:59:14 --> Loader Class Initialized
DEBUG - 2025-05-08 17:59:14 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:14 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:14 --> URI Class Initialized
INFO - 2025-05-08 17:59:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:14 --> Router Class Initialized
INFO - 2025-05-08 17:59:14 --> Output Class Initialized
INFO - 2025-05-08 17:59:14 --> Database Driver Class Initialized
INFO - 2025-05-08 17:59:14 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:14 --> Input Class Initialized
INFO - 2025-05-08 17:59:14 --> Language Class Initialized
INFO - 2025-05-08 17:59:14 --> Loader Class Initialized
INFO - 2025-05-08 17:59:14 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:14 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:14 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:14 --> Controller Class Initialized
DEBUG - 2025-05-08 17:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:14 --> Final output sent to browser
DEBUG - 2025-05-08 17:59:14 --> Total execution time: 0.0047
INFO - 2025-05-08 17:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:14 --> Controller Class Initialized
INFO - 2025-05-08 17:59:14 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:59:14 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:59:14 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:19 --> Config Class Initialized
INFO - 2025-05-08 17:59:19 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:19 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:19 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:19 --> URI Class Initialized
INFO - 2025-05-08 17:59:19 --> Router Class Initialized
INFO - 2025-05-08 17:59:19 --> Output Class Initialized
INFO - 2025-05-08 17:59:19 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:19 --> Input Class Initialized
INFO - 2025-05-08 17:59:19 --> Language Class Initialized
INFO - 2025-05-08 17:59:19 --> Loader Class Initialized
INFO - 2025-05-08 17:59:19 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:19 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:19 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:19 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:19 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:19 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:19 --> Controller Class Initialized
INFO - 2025-05-08 17:59:19 --> Model "UserModel" initialized
INFO - 2025-05-08 17:59:19 --> Final output sent to browser
DEBUG - 2025-05-08 17:59:19 --> Total execution time: 0.0044
INFO - 2025-05-08 17:59:25 --> Config Class Initialized
INFO - 2025-05-08 17:59:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:25 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:25 --> URI Class Initialized
INFO - 2025-05-08 17:59:25 --> Router Class Initialized
INFO - 2025-05-08 17:59:25 --> Output Class Initialized
INFO - 2025-05-08 17:59:25 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:25 --> Input Class Initialized
INFO - 2025-05-08 17:59:25 --> Language Class Initialized
INFO - 2025-05-08 17:59:25 --> Loader Class Initialized
INFO - 2025-05-08 17:59:25 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:25 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:25 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:25 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:25 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:25 --> Controller Class Initialized
INFO - 2025-05-08 17:59:25 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:59:25 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:59:25 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:26 --> Config Class Initialized
INFO - 2025-05-08 17:59:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:26 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:26 --> URI Class Initialized
INFO - 2025-05-08 17:59:26 --> Router Class Initialized
INFO - 2025-05-08 17:59:26 --> Output Class Initialized
INFO - 2025-05-08 17:59:26 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:26 --> Input Class Initialized
INFO - 2025-05-08 17:59:26 --> Language Class Initialized
INFO - 2025-05-08 17:59:26 --> Loader Class Initialized
INFO - 2025-05-08 17:59:26 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:26 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:26 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:26 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:26 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:26 --> Controller Class Initialized
INFO - 2025-05-08 17:59:26 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:59:26 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:59:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:29 --> Config Class Initialized
INFO - 2025-05-08 17:59:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:29 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:29 --> URI Class Initialized
INFO - 2025-05-08 17:59:29 --> Router Class Initialized
INFO - 2025-05-08 17:59:29 --> Output Class Initialized
INFO - 2025-05-08 17:59:29 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:29 --> Input Class Initialized
INFO - 2025-05-08 17:59:29 --> Language Class Initialized
INFO - 2025-05-08 17:59:29 --> Loader Class Initialized
INFO - 2025-05-08 17:59:29 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:29 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:29 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:29 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:29 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:29 --> Controller Class Initialized
INFO - 2025-05-08 17:59:29 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:59:29 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:59:29 --> Model "AuctionModel" initialized
INFO - 2025-05-08 17:59:31 --> Config Class Initialized
INFO - 2025-05-08 17:59:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 17:59:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 17:59:31 --> Utf8 Class Initialized
INFO - 2025-05-08 17:59:31 --> URI Class Initialized
INFO - 2025-05-08 17:59:31 --> Router Class Initialized
INFO - 2025-05-08 17:59:31 --> Output Class Initialized
INFO - 2025-05-08 17:59:31 --> Security Class Initialized
DEBUG - 2025-05-08 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 17:59:31 --> Input Class Initialized
INFO - 2025-05-08 17:59:31 --> Language Class Initialized
INFO - 2025-05-08 17:59:31 --> Loader Class Initialized
INFO - 2025-05-08 17:59:31 --> Helper loaded: url_helper
INFO - 2025-05-08 17:59:31 --> Helper loaded: string_helper
INFO - 2025-05-08 17:59:31 --> Helper loaded: form_helper
INFO - 2025-05-08 17:59:31 --> Helper loaded: file_helper
INFO - 2025-05-08 17:59:31 --> Helper loaded: html_helper
INFO - 2025-05-08 17:59:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 17:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 17:59:31 --> Controller Class Initialized
INFO - 2025-05-08 17:59:31 --> Model "CompanyModel" initialized
INFO - 2025-05-08 17:59:31 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 17:59:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:00:25 --> Config Class Initialized
INFO - 2025-05-08 18:00:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:25 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:25 --> URI Class Initialized
INFO - 2025-05-08 18:00:25 --> Router Class Initialized
INFO - 2025-05-08 18:00:25 --> Output Class Initialized
INFO - 2025-05-08 18:00:25 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:25 --> Input Class Initialized
INFO - 2025-05-08 18:00:25 --> Language Class Initialized
INFO - 2025-05-08 18:00:25 --> Loader Class Initialized
INFO - 2025-05-08 18:00:25 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:25 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:25 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:25 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:25 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:25 --> Controller Class Initialized
INFO - 2025-05-08 18:00:25 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:00:25 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:00:25 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 18:00:25 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:00:25 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:00:25 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:25 --> Total execution time: 0.0286
INFO - 2025-05-08 18:00:30 --> Config Class Initialized
INFO - 2025-05-08 18:00:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:30 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:30 --> URI Class Initialized
INFO - 2025-05-08 18:00:30 --> Router Class Initialized
INFO - 2025-05-08 18:00:30 --> Output Class Initialized
INFO - 2025-05-08 18:00:30 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:30 --> Input Class Initialized
INFO - 2025-05-08 18:00:30 --> Language Class Initialized
INFO - 2025-05-08 18:00:30 --> Loader Class Initialized
INFO - 2025-05-08 18:00:30 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:30 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:30 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:30 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:30 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:30 --> Controller Class Initialized
INFO - 2025-05-08 18:00:30 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:00:30 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:00:30 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:00:31 --> Config Class Initialized
INFO - 2025-05-08 18:00:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:31 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:31 --> URI Class Initialized
INFO - 2025-05-08 18:00:31 --> Router Class Initialized
INFO - 2025-05-08 18:00:31 --> Output Class Initialized
INFO - 2025-05-08 18:00:31 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:31 --> Input Class Initialized
INFO - 2025-05-08 18:00:31 --> Language Class Initialized
INFO - 2025-05-08 18:00:31 --> Loader Class Initialized
INFO - 2025-05-08 18:00:31 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:31 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:31 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:31 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:31 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:31 --> Controller Class Initialized
INFO - 2025-05-08 18:00:31 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:00:31 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:31 --> Total execution time: 0.0039
INFO - 2025-05-08 18:00:33 --> Config Class Initialized
INFO - 2025-05-08 18:00:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:33 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:33 --> URI Class Initialized
INFO - 2025-05-08 18:00:33 --> Router Class Initialized
INFO - 2025-05-08 18:00:33 --> Output Class Initialized
INFO - 2025-05-08 18:00:33 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:33 --> Input Class Initialized
INFO - 2025-05-08 18:00:33 --> Language Class Initialized
INFO - 2025-05-08 18:00:33 --> Loader Class Initialized
INFO - 2025-05-08 18:00:33 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:33 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:33 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:33 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:33 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:33 --> Controller Class Initialized
INFO - 2025-05-08 18:00:33 --> Model "UserModel" initialized
INFO - 2025-05-08 18:00:33 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:33 --> Total execution time: 0.0060
INFO - 2025-05-08 18:00:47 --> Config Class Initialized
INFO - 2025-05-08 18:00:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:47 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:47 --> URI Class Initialized
INFO - 2025-05-08 18:00:47 --> Router Class Initialized
INFO - 2025-05-08 18:00:47 --> Output Class Initialized
INFO - 2025-05-08 18:00:47 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:47 --> Input Class Initialized
INFO - 2025-05-08 18:00:47 --> Language Class Initialized
INFO - 2025-05-08 18:00:47 --> Loader Class Initialized
INFO - 2025-05-08 18:00:47 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:47 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:47 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:47 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:47 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:47 --> Controller Class Initialized
INFO - 2025-05-08 18:00:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:00:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:00:47 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 18:00:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:00:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:00:47 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:47 --> Total execution time: 0.0037
INFO - 2025-05-08 18:00:49 --> Config Class Initialized
INFO - 2025-05-08 18:00:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:49 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:49 --> URI Class Initialized
INFO - 2025-05-08 18:00:49 --> Router Class Initialized
INFO - 2025-05-08 18:00:49 --> Output Class Initialized
INFO - 2025-05-08 18:00:49 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:49 --> Input Class Initialized
INFO - 2025-05-08 18:00:49 --> Language Class Initialized
INFO - 2025-05-08 18:00:49 --> Loader Class Initialized
INFO - 2025-05-08 18:00:49 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:49 --> Controller Class Initialized
INFO - 2025-05-08 18:00:49 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:00:49 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:00:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:00:49 --> Config Class Initialized
INFO - 2025-05-08 18:00:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:49 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:49 --> URI Class Initialized
INFO - 2025-05-08 18:00:49 --> Router Class Initialized
INFO - 2025-05-08 18:00:49 --> Output Class Initialized
INFO - 2025-05-08 18:00:49 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:49 --> Input Class Initialized
INFO - 2025-05-08 18:00:49 --> Language Class Initialized
INFO - 2025-05-08 18:00:49 --> Loader Class Initialized
INFO - 2025-05-08 18:00:49 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:49 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:49 --> Controller Class Initialized
INFO - 2025-05-08 18:00:49 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:00:49 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:49 --> Total execution time: 0.0038
INFO - 2025-05-08 18:00:50 --> Config Class Initialized
INFO - 2025-05-08 18:00:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:00:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:00:50 --> Utf8 Class Initialized
INFO - 2025-05-08 18:00:50 --> URI Class Initialized
INFO - 2025-05-08 18:00:50 --> Router Class Initialized
INFO - 2025-05-08 18:00:50 --> Output Class Initialized
INFO - 2025-05-08 18:00:50 --> Security Class Initialized
DEBUG - 2025-05-08 18:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:00:50 --> Input Class Initialized
INFO - 2025-05-08 18:00:50 --> Language Class Initialized
INFO - 2025-05-08 18:00:50 --> Loader Class Initialized
INFO - 2025-05-08 18:00:50 --> Helper loaded: url_helper
INFO - 2025-05-08 18:00:50 --> Helper loaded: string_helper
INFO - 2025-05-08 18:00:50 --> Helper loaded: form_helper
INFO - 2025-05-08 18:00:50 --> Helper loaded: file_helper
INFO - 2025-05-08 18:00:50 --> Helper loaded: html_helper
INFO - 2025-05-08 18:00:50 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:00:50 --> Controller Class Initialized
INFO - 2025-05-08 18:00:50 --> Model "UserModel" initialized
INFO - 2025-05-08 18:00:50 --> Final output sent to browser
DEBUG - 2025-05-08 18:00:50 --> Total execution time: 0.0038
INFO - 2025-05-08 18:01:58 --> Config Class Initialized
INFO - 2025-05-08 18:01:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:01:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:01:58 --> Utf8 Class Initialized
INFO - 2025-05-08 18:01:58 --> URI Class Initialized
DEBUG - 2025-05-08 18:01:58 --> No URI present. Default controller set.
INFO - 2025-05-08 18:01:58 --> Router Class Initialized
INFO - 2025-05-08 18:01:58 --> Output Class Initialized
INFO - 2025-05-08 18:01:58 --> Security Class Initialized
DEBUG - 2025-05-08 18:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:01:58 --> Input Class Initialized
INFO - 2025-05-08 18:01:58 --> Language Class Initialized
INFO - 2025-05-08 18:01:58 --> Loader Class Initialized
INFO - 2025-05-08 18:01:58 --> Helper loaded: url_helper
INFO - 2025-05-08 18:01:58 --> Helper loaded: string_helper
INFO - 2025-05-08 18:01:58 --> Helper loaded: form_helper
INFO - 2025-05-08 18:01:58 --> Helper loaded: file_helper
INFO - 2025-05-08 18:01:58 --> Helper loaded: html_helper
INFO - 2025-05-08 18:01:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:01:58 --> Controller Class Initialized
INFO - 2025-05-08 18:01:58 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:01:58 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:01:58 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:01:58 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:01:58 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:01:58 --> Final output sent to browser
DEBUG - 2025-05-08 18:01:58 --> Total execution time: 0.0386
INFO - 2025-05-08 18:02:00 --> Config Class Initialized
INFO - 2025-05-08 18:02:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:02:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:02:00 --> Utf8 Class Initialized
INFO - 2025-05-08 18:02:00 --> URI Class Initialized
INFO - 2025-05-08 18:02:00 --> Router Class Initialized
INFO - 2025-05-08 18:02:00 --> Output Class Initialized
INFO - 2025-05-08 18:02:00 --> Security Class Initialized
DEBUG - 2025-05-08 18:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:02:00 --> Input Class Initialized
INFO - 2025-05-08 18:02:00 --> Language Class Initialized
INFO - 2025-05-08 18:02:00 --> Loader Class Initialized
INFO - 2025-05-08 18:02:00 --> Helper loaded: url_helper
INFO - 2025-05-08 18:02:00 --> Helper loaded: string_helper
INFO - 2025-05-08 18:02:00 --> Helper loaded: form_helper
INFO - 2025-05-08 18:02:00 --> Helper loaded: file_helper
INFO - 2025-05-08 18:02:00 --> Helper loaded: html_helper
INFO - 2025-05-08 18:02:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:02:00 --> Controller Class Initialized
INFO - 2025-05-08 18:02:00 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:02:01 --> Config Class Initialized
INFO - 2025-05-08 18:02:01 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:02:01 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:02:01 --> Utf8 Class Initialized
INFO - 2025-05-08 18:02:01 --> URI Class Initialized
INFO - 2025-05-08 18:02:01 --> Router Class Initialized
INFO - 2025-05-08 18:02:01 --> Output Class Initialized
INFO - 2025-05-08 18:02:01 --> Security Class Initialized
DEBUG - 2025-05-08 18:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:02:01 --> Input Class Initialized
INFO - 2025-05-08 18:02:01 --> Language Class Initialized
INFO - 2025-05-08 18:02:01 --> Loader Class Initialized
INFO - 2025-05-08 18:02:01 --> Helper loaded: url_helper
INFO - 2025-05-08 18:02:01 --> Helper loaded: string_helper
INFO - 2025-05-08 18:02:01 --> Helper loaded: form_helper
INFO - 2025-05-08 18:02:01 --> Helper loaded: file_helper
INFO - 2025-05-08 18:02:01 --> Helper loaded: html_helper
INFO - 2025-05-08 18:02:01 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:02:01 --> Controller Class Initialized
INFO - 2025-05-08 18:02:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:02:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:02:01 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 18:02:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:02:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:02:01 --> Final output sent to browser
DEBUG - 2025-05-08 18:02:01 --> Total execution time: 0.0041
INFO - 2025-05-08 18:02:02 --> Config Class Initialized
INFO - 2025-05-08 18:02:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:02:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:02:02 --> Utf8 Class Initialized
INFO - 2025-05-08 18:02:02 --> URI Class Initialized
INFO - 2025-05-08 18:02:02 --> Router Class Initialized
INFO - 2025-05-08 18:02:02 --> Output Class Initialized
INFO - 2025-05-08 18:02:02 --> Security Class Initialized
DEBUG - 2025-05-08 18:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:02:02 --> Input Class Initialized
INFO - 2025-05-08 18:02:02 --> Language Class Initialized
INFO - 2025-05-08 18:02:02 --> Loader Class Initialized
INFO - 2025-05-08 18:02:02 --> Helper loaded: url_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: string_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: form_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: file_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: html_helper
INFO - 2025-05-08 18:02:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:02:02 --> Controller Class Initialized
INFO - 2025-05-08 18:02:02 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:02:02 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:02:02 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:02:02 --> Config Class Initialized
INFO - 2025-05-08 18:02:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:02:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:02:02 --> Utf8 Class Initialized
INFO - 2025-05-08 18:02:02 --> URI Class Initialized
INFO - 2025-05-08 18:02:02 --> Router Class Initialized
INFO - 2025-05-08 18:02:02 --> Output Class Initialized
INFO - 2025-05-08 18:02:02 --> Security Class Initialized
DEBUG - 2025-05-08 18:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:02:02 --> Input Class Initialized
INFO - 2025-05-08 18:02:02 --> Language Class Initialized
INFO - 2025-05-08 18:02:02 --> Loader Class Initialized
INFO - 2025-05-08 18:02:02 --> Helper loaded: url_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: string_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: form_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: file_helper
INFO - 2025-05-08 18:02:02 --> Helper loaded: html_helper
INFO - 2025-05-08 18:02:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:02:02 --> Controller Class Initialized
INFO - 2025-05-08 18:02:02 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:02:02 --> Final output sent to browser
DEBUG - 2025-05-08 18:02:02 --> Total execution time: 0.0025
INFO - 2025-05-08 18:02:03 --> Config Class Initialized
INFO - 2025-05-08 18:02:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:02:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:02:03 --> Utf8 Class Initialized
INFO - 2025-05-08 18:02:03 --> URI Class Initialized
INFO - 2025-05-08 18:02:03 --> Router Class Initialized
INFO - 2025-05-08 18:02:03 --> Output Class Initialized
INFO - 2025-05-08 18:02:03 --> Security Class Initialized
DEBUG - 2025-05-08 18:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:02:03 --> Input Class Initialized
INFO - 2025-05-08 18:02:03 --> Language Class Initialized
INFO - 2025-05-08 18:02:03 --> Loader Class Initialized
INFO - 2025-05-08 18:02:03 --> Helper loaded: url_helper
INFO - 2025-05-08 18:02:03 --> Helper loaded: string_helper
INFO - 2025-05-08 18:02:03 --> Helper loaded: form_helper
INFO - 2025-05-08 18:02:03 --> Helper loaded: file_helper
INFO - 2025-05-08 18:02:03 --> Helper loaded: html_helper
INFO - 2025-05-08 18:02:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:02:03 --> Controller Class Initialized
INFO - 2025-05-08 18:02:03 --> Model "UserModel" initialized
INFO - 2025-05-08 18:02:03 --> Final output sent to browser
DEBUG - 2025-05-08 18:02:03 --> Total execution time: 0.0066
INFO - 2025-05-08 18:04:27 --> Config Class Initialized
INFO - 2025-05-08 18:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:04:27 --> Utf8 Class Initialized
INFO - 2025-05-08 18:04:27 --> URI Class Initialized
INFO - 2025-05-08 18:04:27 --> Router Class Initialized
INFO - 2025-05-08 18:04:27 --> Output Class Initialized
INFO - 2025-05-08 18:04:27 --> Security Class Initialized
DEBUG - 2025-05-08 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:04:27 --> Input Class Initialized
INFO - 2025-05-08 18:04:27 --> Language Class Initialized
INFO - 2025-05-08 18:04:27 --> Loader Class Initialized
INFO - 2025-05-08 18:04:27 --> Helper loaded: url_helper
INFO - 2025-05-08 18:04:27 --> Helper loaded: string_helper
INFO - 2025-05-08 18:04:27 --> Helper loaded: form_helper
INFO - 2025-05-08 18:04:27 --> Helper loaded: file_helper
INFO - 2025-05-08 18:04:27 --> Helper loaded: html_helper
INFO - 2025-05-08 18:04:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:04:27 --> Controller Class Initialized
INFO - 2025-05-08 18:04:27 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:04:27 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:04:27 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:04:29 --> Config Class Initialized
INFO - 2025-05-08 18:04:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:04:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:04:29 --> Utf8 Class Initialized
INFO - 2025-05-08 18:04:29 --> URI Class Initialized
INFO - 2025-05-08 18:04:29 --> Router Class Initialized
INFO - 2025-05-08 18:04:29 --> Output Class Initialized
INFO - 2025-05-08 18:04:29 --> Security Class Initialized
DEBUG - 2025-05-08 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:04:29 --> Input Class Initialized
INFO - 2025-05-08 18:04:29 --> Language Class Initialized
INFO - 2025-05-08 18:04:29 --> Loader Class Initialized
INFO - 2025-05-08 18:04:29 --> Helper loaded: url_helper
INFO - 2025-05-08 18:04:29 --> Helper loaded: string_helper
INFO - 2025-05-08 18:04:29 --> Helper loaded: form_helper
INFO - 2025-05-08 18:04:29 --> Helper loaded: file_helper
INFO - 2025-05-08 18:04:29 --> Helper loaded: html_helper
INFO - 2025-05-08 18:04:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:04:29 --> Controller Class Initialized
INFO - 2025-05-08 18:04:29 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:04:29 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:04:29 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:05:05 --> Config Class Initialized
INFO - 2025-05-08 18:05:05 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:05:05 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:05:05 --> Utf8 Class Initialized
INFO - 2025-05-08 18:05:05 --> URI Class Initialized
INFO - 2025-05-08 18:05:05 --> Router Class Initialized
INFO - 2025-05-08 18:05:05 --> Output Class Initialized
INFO - 2025-05-08 18:05:05 --> Security Class Initialized
DEBUG - 2025-05-08 18:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:05:05 --> Input Class Initialized
INFO - 2025-05-08 18:05:05 --> Language Class Initialized
INFO - 2025-05-08 18:05:05 --> Loader Class Initialized
INFO - 2025-05-08 18:05:05 --> Helper loaded: url_helper
INFO - 2025-05-08 18:05:05 --> Helper loaded: string_helper
INFO - 2025-05-08 18:05:05 --> Helper loaded: form_helper
INFO - 2025-05-08 18:05:05 --> Helper loaded: file_helper
INFO - 2025-05-08 18:05:05 --> Helper loaded: html_helper
INFO - 2025-05-08 18:05:05 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:05:05 --> Controller Class Initialized
INFO - 2025-05-08 18:05:05 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:05:05 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:05:05 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:05:06 --> Config Class Initialized
INFO - 2025-05-08 18:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:05:06 --> Utf8 Class Initialized
INFO - 2025-05-08 18:05:06 --> URI Class Initialized
INFO - 2025-05-08 18:05:06 --> Router Class Initialized
INFO - 2025-05-08 18:05:06 --> Output Class Initialized
INFO - 2025-05-08 18:05:06 --> Security Class Initialized
DEBUG - 2025-05-08 18:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:05:06 --> Input Class Initialized
INFO - 2025-05-08 18:05:06 --> Language Class Initialized
INFO - 2025-05-08 18:05:06 --> Loader Class Initialized
INFO - 2025-05-08 18:05:06 --> Helper loaded: url_helper
INFO - 2025-05-08 18:05:06 --> Helper loaded: string_helper
INFO - 2025-05-08 18:05:06 --> Helper loaded: form_helper
INFO - 2025-05-08 18:05:06 --> Helper loaded: file_helper
INFO - 2025-05-08 18:05:06 --> Helper loaded: html_helper
INFO - 2025-05-08 18:05:06 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:05:06 --> Controller Class Initialized
INFO - 2025-05-08 18:05:06 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:05:06 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:05:06 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:05:09 --> Config Class Initialized
INFO - 2025-05-08 18:05:09 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:05:09 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:05:09 --> Utf8 Class Initialized
INFO - 2025-05-08 18:05:09 --> URI Class Initialized
INFO - 2025-05-08 18:05:09 --> Router Class Initialized
INFO - 2025-05-08 18:05:09 --> Output Class Initialized
INFO - 2025-05-08 18:05:09 --> Security Class Initialized
DEBUG - 2025-05-08 18:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:05:09 --> Input Class Initialized
INFO - 2025-05-08 18:05:09 --> Language Class Initialized
INFO - 2025-05-08 18:05:09 --> Loader Class Initialized
INFO - 2025-05-08 18:05:09 --> Helper loaded: url_helper
INFO - 2025-05-08 18:05:09 --> Helper loaded: string_helper
INFO - 2025-05-08 18:05:09 --> Helper loaded: form_helper
INFO - 2025-05-08 18:05:09 --> Helper loaded: file_helper
INFO - 2025-05-08 18:05:09 --> Helper loaded: html_helper
INFO - 2025-05-08 18:05:09 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:05:09 --> Controller Class Initialized
INFO - 2025-05-08 18:05:09 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:05:09 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:05:09 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:06:25 --> Config Class Initialized
INFO - 2025-05-08 18:06:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:25 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:25 --> URI Class Initialized
INFO - 2025-05-08 18:06:25 --> Router Class Initialized
INFO - 2025-05-08 18:06:25 --> Output Class Initialized
INFO - 2025-05-08 18:06:25 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:25 --> Input Class Initialized
INFO - 2025-05-08 18:06:25 --> Language Class Initialized
INFO - 2025-05-08 18:06:25 --> Loader Class Initialized
INFO - 2025-05-08 18:06:25 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:25 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:25 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:25 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:25 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:25 --> Controller Class Initialized
INFO - 2025-05-08 18:06:25 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:06:25 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:25 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:25 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/staff/manage.php
INFO - 2025-05-08 18:06:25 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:25 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:25 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:25 --> Total execution time: 0.0344
INFO - 2025-05-08 18:06:26 --> Config Class Initialized
INFO - 2025-05-08 18:06:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:26 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:26 --> URI Class Initialized
INFO - 2025-05-08 18:06:26 --> Router Class Initialized
INFO - 2025-05-08 18:06:26 --> Output Class Initialized
INFO - 2025-05-08 18:06:26 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:26 --> Input Class Initialized
INFO - 2025-05-08 18:06:26 --> Language Class Initialized
INFO - 2025-05-08 18:06:27 --> Loader Class Initialized
INFO - 2025-05-08 18:06:27 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:27 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:27 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:27 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:27 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:27 --> Controller Class Initialized
INFO - 2025-05-08 18:06:27 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:06:27 --> Model "StaffModel" initialized
INFO - 2025-05-08 18:06:27 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:27 --> Total execution time: 0.0088
INFO - 2025-05-08 18:06:28 --> Config Class Initialized
INFO - 2025-05-08 18:06:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:28 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:28 --> URI Class Initialized
INFO - 2025-05-08 18:06:28 --> Router Class Initialized
INFO - 2025-05-08 18:06:28 --> Output Class Initialized
INFO - 2025-05-08 18:06:28 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:28 --> Input Class Initialized
INFO - 2025-05-08 18:06:28 --> Language Class Initialized
INFO - 2025-05-08 18:06:28 --> Loader Class Initialized
INFO - 2025-05-08 18:06:28 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:28 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:28 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:28 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:28 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:28 --> Controller Class Initialized
INFO - 2025-05-08 18:06:28 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:29 --> Config Class Initialized
INFO - 2025-05-08 18:06:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:29 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:29 --> URI Class Initialized
INFO - 2025-05-08 18:06:29 --> Router Class Initialized
INFO - 2025-05-08 18:06:29 --> Output Class Initialized
INFO - 2025-05-08 18:06:29 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:29 --> Input Class Initialized
INFO - 2025-05-08 18:06:29 --> Language Class Initialized
INFO - 2025-05-08 18:06:29 --> Loader Class Initialized
INFO - 2025-05-08 18:06:29 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:29 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:29 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:29 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:29 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:29 --> Controller Class Initialized
INFO - 2025-05-08 18:06:29 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:29 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:29 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:29 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:06:29 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:29 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:29 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:29 --> Total execution time: 0.0032
INFO - 2025-05-08 18:06:31 --> Config Class Initialized
INFO - 2025-05-08 18:06:31 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:31 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:31 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:31 --> URI Class Initialized
INFO - 2025-05-08 18:06:31 --> Router Class Initialized
INFO - 2025-05-08 18:06:31 --> Output Class Initialized
INFO - 2025-05-08 18:06:31 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:31 --> Input Class Initialized
INFO - 2025-05-08 18:06:31 --> Language Class Initialized
INFO - 2025-05-08 18:06:31 --> Loader Class Initialized
INFO - 2025-05-08 18:06:31 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:31 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:31 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:31 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:31 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:31 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:31 --> Controller Class Initialized
INFO - 2025-05-08 18:06:31 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:31 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:06:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:31 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:31 --> Total execution time: 0.0039
INFO - 2025-05-08 18:06:37 --> Config Class Initialized
INFO - 2025-05-08 18:06:37 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:37 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:37 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:37 --> URI Class Initialized
INFO - 2025-05-08 18:06:37 --> Router Class Initialized
INFO - 2025-05-08 18:06:37 --> Output Class Initialized
INFO - 2025-05-08 18:06:37 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:37 --> Input Class Initialized
INFO - 2025-05-08 18:06:37 --> Language Class Initialized
INFO - 2025-05-08 18:06:37 --> Loader Class Initialized
INFO - 2025-05-08 18:06:37 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:37 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:37 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:37 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:37 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:37 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:37 --> Controller Class Initialized
INFO - 2025-05-08 18:06:37 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:37 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:37 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:37 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:06:37 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:37 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:37 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:37 --> Total execution time: 0.0058
INFO - 2025-05-08 18:06:42 --> Config Class Initialized
INFO - 2025-05-08 18:06:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:42 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:42 --> URI Class Initialized
INFO - 2025-05-08 18:06:42 --> Router Class Initialized
INFO - 2025-05-08 18:06:42 --> Output Class Initialized
INFO - 2025-05-08 18:06:42 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:42 --> Input Class Initialized
INFO - 2025-05-08 18:06:42 --> Language Class Initialized
INFO - 2025-05-08 18:06:42 --> Loader Class Initialized
INFO - 2025-05-08 18:06:42 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:42 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:42 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:42 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:42 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:42 --> Controller Class Initialized
INFO - 2025-05-08 18:06:42 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:42 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:42 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:42 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:06:42 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:42 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:42 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:42 --> Total execution time: 0.0046
INFO - 2025-05-08 18:06:58 --> Config Class Initialized
INFO - 2025-05-08 18:06:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:06:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:06:58 --> Utf8 Class Initialized
INFO - 2025-05-08 18:06:58 --> URI Class Initialized
INFO - 2025-05-08 18:06:58 --> Router Class Initialized
INFO - 2025-05-08 18:06:58 --> Output Class Initialized
INFO - 2025-05-08 18:06:58 --> Security Class Initialized
DEBUG - 2025-05-08 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:06:58 --> Input Class Initialized
INFO - 2025-05-08 18:06:58 --> Language Class Initialized
INFO - 2025-05-08 18:06:58 --> Loader Class Initialized
INFO - 2025-05-08 18:06:58 --> Helper loaded: url_helper
INFO - 2025-05-08 18:06:58 --> Helper loaded: string_helper
INFO - 2025-05-08 18:06:58 --> Helper loaded: form_helper
INFO - 2025-05-08 18:06:58 --> Helper loaded: file_helper
INFO - 2025-05-08 18:06:58 --> Helper loaded: html_helper
INFO - 2025-05-08 18:06:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:06:58 --> Controller Class Initialized
INFO - 2025-05-08 18:06:58 --> Model "BankModel" initialized
INFO - 2025-05-08 18:06:58 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:06:58 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:06:58 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:06:58 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:06:58 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:06:58 --> Final output sent to browser
DEBUG - 2025-05-08 18:06:58 --> Total execution time: 0.0047
INFO - 2025-05-08 18:07:02 --> Config Class Initialized
INFO - 2025-05-08 18:07:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:07:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:07:02 --> Utf8 Class Initialized
INFO - 2025-05-08 18:07:02 --> URI Class Initialized
INFO - 2025-05-08 18:07:02 --> Router Class Initialized
INFO - 2025-05-08 18:07:02 --> Output Class Initialized
INFO - 2025-05-08 18:07:02 --> Security Class Initialized
DEBUG - 2025-05-08 18:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:07:02 --> Input Class Initialized
INFO - 2025-05-08 18:07:02 --> Language Class Initialized
INFO - 2025-05-08 18:07:02 --> Loader Class Initialized
INFO - 2025-05-08 18:07:02 --> Helper loaded: url_helper
INFO - 2025-05-08 18:07:02 --> Helper loaded: string_helper
INFO - 2025-05-08 18:07:02 --> Helper loaded: form_helper
INFO - 2025-05-08 18:07:02 --> Helper loaded: file_helper
INFO - 2025-05-08 18:07:02 --> Helper loaded: html_helper
INFO - 2025-05-08 18:07:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:07:02 --> Controller Class Initialized
INFO - 2025-05-08 18:07:02 --> Model "BankModel" initialized
INFO - 2025-05-08 18:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:07:02 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:07:02 --> Final output sent to browser
DEBUG - 2025-05-08 18:07:02 --> Total execution time: 0.0032
INFO - 2025-05-08 18:08:57 --> Config Class Initialized
INFO - 2025-05-08 18:08:57 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:08:57 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:08:57 --> Utf8 Class Initialized
INFO - 2025-05-08 18:08:57 --> URI Class Initialized
DEBUG - 2025-05-08 18:08:57 --> No URI present. Default controller set.
INFO - 2025-05-08 18:08:57 --> Router Class Initialized
INFO - 2025-05-08 18:08:57 --> Output Class Initialized
INFO - 2025-05-08 18:08:57 --> Security Class Initialized
DEBUG - 2025-05-08 18:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:08:57 --> Input Class Initialized
INFO - 2025-05-08 18:08:57 --> Language Class Initialized
INFO - 2025-05-08 18:08:57 --> Loader Class Initialized
INFO - 2025-05-08 18:08:57 --> Helper loaded: url_helper
INFO - 2025-05-08 18:08:57 --> Helper loaded: string_helper
INFO - 2025-05-08 18:08:57 --> Helper loaded: form_helper
INFO - 2025-05-08 18:08:57 --> Helper loaded: file_helper
INFO - 2025-05-08 18:08:57 --> Helper loaded: html_helper
INFO - 2025-05-08 18:08:57 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:08:57 --> Controller Class Initialized
INFO - 2025-05-08 18:08:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:08:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:08:57 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:08:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:08:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:08:57 --> Final output sent to browser
DEBUG - 2025-05-08 18:08:57 --> Total execution time: 0.0287
INFO - 2025-05-08 18:09:44 --> Config Class Initialized
INFO - 2025-05-08 18:09:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:44 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:44 --> URI Class Initialized
INFO - 2025-05-08 18:09:44 --> Router Class Initialized
INFO - 2025-05-08 18:09:44 --> Output Class Initialized
INFO - 2025-05-08 18:09:44 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:44 --> Input Class Initialized
INFO - 2025-05-08 18:09:44 --> Language Class Initialized
INFO - 2025-05-08 18:09:44 --> Loader Class Initialized
INFO - 2025-05-08 18:09:44 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:44 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:44 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:44 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:44 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:44 --> Controller Class Initialized
INFO - 2025-05-08 18:09:44 --> Model "BankModel" initialized
INFO - 2025-05-08 18:09:45 --> Config Class Initialized
INFO - 2025-05-08 18:09:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:45 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:45 --> URI Class Initialized
DEBUG - 2025-05-08 18:09:45 --> No URI present. Default controller set.
INFO - 2025-05-08 18:09:45 --> Router Class Initialized
INFO - 2025-05-08 18:09:45 --> Output Class Initialized
INFO - 2025-05-08 18:09:45 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:45 --> Input Class Initialized
INFO - 2025-05-08 18:09:45 --> Language Class Initialized
INFO - 2025-05-08 18:09:45 --> Loader Class Initialized
INFO - 2025-05-08 18:09:45 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:45 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:45 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:45 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:45 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:45 --> Controller Class Initialized
INFO - 2025-05-08 18:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:09:45 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:09:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:09:45 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:45 --> Total execution time: 0.0039
INFO - 2025-05-08 18:09:47 --> Config Class Initialized
INFO - 2025-05-08 18:09:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:47 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:47 --> URI Class Initialized
INFO - 2025-05-08 18:09:47 --> Router Class Initialized
INFO - 2025-05-08 18:09:47 --> Output Class Initialized
INFO - 2025-05-08 18:09:47 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:47 --> Input Class Initialized
INFO - 2025-05-08 18:09:47 --> Language Class Initialized
INFO - 2025-05-08 18:09:47 --> Loader Class Initialized
INFO - 2025-05-08 18:09:47 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:47 --> Controller Class Initialized
INFO - 2025-05-08 18:09:47 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:09:47 --> Config Class Initialized
INFO - 2025-05-08 18:09:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:47 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:47 --> URI Class Initialized
INFO - 2025-05-08 18:09:47 --> Router Class Initialized
INFO - 2025-05-08 18:09:47 --> Output Class Initialized
INFO - 2025-05-08 18:09:47 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:47 --> Input Class Initialized
INFO - 2025-05-08 18:09:47 --> Language Class Initialized
INFO - 2025-05-08 18:09:47 --> Loader Class Initialized
INFO - 2025-05-08 18:09:47 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:47 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:47 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:47 --> Controller Class Initialized
INFO - 2025-05-08 18:09:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:09:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:09:47 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 18:09:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:09:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:09:47 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:47 --> Total execution time: 0.0039
INFO - 2025-05-08 18:09:49 --> Config Class Initialized
INFO - 2025-05-08 18:09:49 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:49 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:49 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:49 --> URI Class Initialized
INFO - 2025-05-08 18:09:49 --> Router Class Initialized
INFO - 2025-05-08 18:09:49 --> Output Class Initialized
INFO - 2025-05-08 18:09:49 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:49 --> Input Class Initialized
INFO - 2025-05-08 18:09:49 --> Language Class Initialized
INFO - 2025-05-08 18:09:49 --> Loader Class Initialized
INFO - 2025-05-08 18:09:49 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:49 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:49 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:49 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:49 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:49 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:49 --> Controller Class Initialized
INFO - 2025-05-08 18:09:49 --> Model "BankModel" initialized
INFO - 2025-05-08 18:09:50 --> Config Class Initialized
INFO - 2025-05-08 18:09:50 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:50 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:50 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:50 --> URI Class Initialized
INFO - 2025-05-08 18:09:50 --> Router Class Initialized
INFO - 2025-05-08 18:09:50 --> Output Class Initialized
INFO - 2025-05-08 18:09:50 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:50 --> Input Class Initialized
INFO - 2025-05-08 18:09:50 --> Language Class Initialized
INFO - 2025-05-08 18:09:50 --> Loader Class Initialized
INFO - 2025-05-08 18:09:50 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:50 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:50 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:50 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:50 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:50 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:50 --> Controller Class Initialized
INFO - 2025-05-08 18:09:50 --> Model "BankModel" initialized
INFO - 2025-05-08 18:09:50 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:09:50 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:09:50 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:09:50 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:09:50 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:09:50 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:50 --> Total execution time: 0.0038
INFO - 2025-05-08 18:09:52 --> Config Class Initialized
INFO - 2025-05-08 18:09:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:52 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:52 --> URI Class Initialized
INFO - 2025-05-08 18:09:52 --> Router Class Initialized
INFO - 2025-05-08 18:09:52 --> Output Class Initialized
INFO - 2025-05-08 18:09:52 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:52 --> Input Class Initialized
INFO - 2025-05-08 18:09:52 --> Language Class Initialized
INFO - 2025-05-08 18:09:52 --> Loader Class Initialized
INFO - 2025-05-08 18:09:52 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:52 --> Controller Class Initialized
INFO - 2025-05-08 18:09:52 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:52 --> Config Class Initialized
INFO - 2025-05-08 18:09:52 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:52 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:52 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:52 --> URI Class Initialized
INFO - 2025-05-08 18:09:52 --> Router Class Initialized
INFO - 2025-05-08 18:09:52 --> Output Class Initialized
INFO - 2025-05-08 18:09:52 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:52 --> Input Class Initialized
INFO - 2025-05-08 18:09:52 --> Language Class Initialized
INFO - 2025-05-08 18:09:52 --> Loader Class Initialized
INFO - 2025-05-08 18:09:52 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:52 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:52 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:52 --> Controller Class Initialized
INFO - 2025-05-08 18:09:52 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:52 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:09:52 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:09:52 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/company/details.php
INFO - 2025-05-08 18:09:52 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:09:52 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:09:52 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:52 --> Total execution time: 0.0047
INFO - 2025-05-08 18:09:54 --> Config Class Initialized
INFO - 2025-05-08 18:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:54 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:54 --> URI Class Initialized
INFO - 2025-05-08 18:09:54 --> Router Class Initialized
INFO - 2025-05-08 18:09:54 --> Output Class Initialized
INFO - 2025-05-08 18:09:54 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:54 --> Input Class Initialized
INFO - 2025-05-08 18:09:54 --> Language Class Initialized
INFO - 2025-05-08 18:09:54 --> Loader Class Initialized
INFO - 2025-05-08 18:09:54 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:54 --> Controller Class Initialized
INFO - 2025-05-08 18:09:54 --> Config Class Initialized
INFO - 2025-05-08 18:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:54 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:54 --> URI Class Initialized
INFO - 2025-05-08 18:09:54 --> Router Class Initialized
INFO - 2025-05-08 18:09:54 --> Output Class Initialized
INFO - 2025-05-08 18:09:54 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:54 --> Input Class Initialized
INFO - 2025-05-08 18:09:54 --> Language Class Initialized
INFO - 2025-05-08 18:09:54 --> Loader Class Initialized
INFO - 2025-05-08 18:09:54 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:54 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:54 --> Controller Class Initialized
INFO - 2025-05-08 18:09:54 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:54 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:54 --> Total execution time: 0.0038
INFO - 2025-05-08 18:09:56 --> Config Class Initialized
INFO - 2025-05-08 18:09:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:56 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:56 --> URI Class Initialized
INFO - 2025-05-08 18:09:56 --> Router Class Initialized
INFO - 2025-05-08 18:09:56 --> Output Class Initialized
INFO - 2025-05-08 18:09:56 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:56 --> Input Class Initialized
INFO - 2025-05-08 18:09:56 --> Language Class Initialized
INFO - 2025-05-08 18:09:56 --> Loader Class Initialized
INFO - 2025-05-08 18:09:56 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:56 --> Controller Class Initialized
INFO - 2025-05-08 18:09:56 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:56 --> Config Class Initialized
INFO - 2025-05-08 18:09:56 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:56 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:56 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:56 --> URI Class Initialized
INFO - 2025-05-08 18:09:56 --> Router Class Initialized
INFO - 2025-05-08 18:09:56 --> Output Class Initialized
INFO - 2025-05-08 18:09:56 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:56 --> Input Class Initialized
INFO - 2025-05-08 18:09:56 --> Language Class Initialized
INFO - 2025-05-08 18:09:56 --> Loader Class Initialized
INFO - 2025-05-08 18:09:56 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:56 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:56 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:56 --> Controller Class Initialized
INFO - 2025-05-08 18:09:56 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:56 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:09:56 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:09:56 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/company/details.php
INFO - 2025-05-08 18:09:56 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:09:56 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:09:56 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:56 --> Total execution time: 0.0029
INFO - 2025-05-08 18:09:58 --> Config Class Initialized
INFO - 2025-05-08 18:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:58 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:58 --> URI Class Initialized
INFO - 2025-05-08 18:09:58 --> Router Class Initialized
INFO - 2025-05-08 18:09:58 --> Output Class Initialized
INFO - 2025-05-08 18:09:58 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:58 --> Input Class Initialized
INFO - 2025-05-08 18:09:58 --> Language Class Initialized
INFO - 2025-05-08 18:09:58 --> Loader Class Initialized
INFO - 2025-05-08 18:09:58 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:58 --> Controller Class Initialized
INFO - 2025-05-08 18:09:58 --> Config Class Initialized
INFO - 2025-05-08 18:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:09:58 --> Utf8 Class Initialized
INFO - 2025-05-08 18:09:58 --> URI Class Initialized
INFO - 2025-05-08 18:09:58 --> Router Class Initialized
INFO - 2025-05-08 18:09:58 --> Output Class Initialized
INFO - 2025-05-08 18:09:58 --> Security Class Initialized
DEBUG - 2025-05-08 18:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:09:58 --> Input Class Initialized
INFO - 2025-05-08 18:09:58 --> Language Class Initialized
INFO - 2025-05-08 18:09:58 --> Loader Class Initialized
INFO - 2025-05-08 18:09:58 --> Helper loaded: url_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: string_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: form_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: file_helper
INFO - 2025-05-08 18:09:58 --> Helper loaded: html_helper
INFO - 2025-05-08 18:09:58 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:09:58 --> Controller Class Initialized
INFO - 2025-05-08 18:09:58 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:09:58 --> Final output sent to browser
DEBUG - 2025-05-08 18:09:58 --> Total execution time: 0.0024
INFO - 2025-05-08 18:10:12 --> Config Class Initialized
INFO - 2025-05-08 18:10:12 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:10:12 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:10:12 --> Utf8 Class Initialized
INFO - 2025-05-08 18:10:12 --> URI Class Initialized
INFO - 2025-05-08 18:10:12 --> Router Class Initialized
INFO - 2025-05-08 18:10:12 --> Output Class Initialized
INFO - 2025-05-08 18:10:12 --> Security Class Initialized
DEBUG - 2025-05-08 18:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:10:12 --> Input Class Initialized
INFO - 2025-05-08 18:10:12 --> Language Class Initialized
INFO - 2025-05-08 18:10:12 --> Loader Class Initialized
INFO - 2025-05-08 18:10:12 --> Helper loaded: url_helper
INFO - 2025-05-08 18:10:12 --> Helper loaded: string_helper
INFO - 2025-05-08 18:10:12 --> Helper loaded: form_helper
INFO - 2025-05-08 18:10:12 --> Helper loaded: file_helper
INFO - 2025-05-08 18:10:12 --> Helper loaded: html_helper
INFO - 2025-05-08 18:10:12 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:10:12 --> Controller Class Initialized
INFO - 2025-05-08 18:10:12 --> Model "BankModel" initialized
INFO - 2025-05-08 18:10:13 --> Config Class Initialized
INFO - 2025-05-08 18:10:13 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:10:13 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:10:13 --> Utf8 Class Initialized
INFO - 2025-05-08 18:10:13 --> URI Class Initialized
INFO - 2025-05-08 18:10:13 --> Router Class Initialized
INFO - 2025-05-08 18:10:13 --> Output Class Initialized
INFO - 2025-05-08 18:10:13 --> Security Class Initialized
DEBUG - 2025-05-08 18:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:10:13 --> Input Class Initialized
INFO - 2025-05-08 18:10:13 --> Language Class Initialized
INFO - 2025-05-08 18:10:13 --> Loader Class Initialized
INFO - 2025-05-08 18:10:13 --> Helper loaded: url_helper
INFO - 2025-05-08 18:10:13 --> Helper loaded: string_helper
INFO - 2025-05-08 18:10:13 --> Helper loaded: form_helper
INFO - 2025-05-08 18:10:13 --> Helper loaded: file_helper
INFO - 2025-05-08 18:10:13 --> Helper loaded: html_helper
INFO - 2025-05-08 18:10:13 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:10:13 --> Controller Class Initialized
INFO - 2025-05-08 18:10:13 --> Model "BankModel" initialized
INFO - 2025-05-08 18:10:13 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:10:13 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:10:13 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:10:13 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:10:13 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:10:13 --> Final output sent to browser
DEBUG - 2025-05-08 18:10:13 --> Total execution time: 0.0035
INFO - 2025-05-08 18:10:20 --> Config Class Initialized
INFO - 2025-05-08 18:10:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:10:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:10:20 --> Utf8 Class Initialized
INFO - 2025-05-08 18:10:20 --> URI Class Initialized
INFO - 2025-05-08 18:10:20 --> Router Class Initialized
INFO - 2025-05-08 18:10:20 --> Output Class Initialized
INFO - 2025-05-08 18:10:20 --> Security Class Initialized
DEBUG - 2025-05-08 18:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:10:20 --> Input Class Initialized
INFO - 2025-05-08 18:10:20 --> Language Class Initialized
INFO - 2025-05-08 18:10:20 --> Loader Class Initialized
INFO - 2025-05-08 18:10:20 --> Helper loaded: url_helper
INFO - 2025-05-08 18:10:20 --> Helper loaded: string_helper
INFO - 2025-05-08 18:10:20 --> Helper loaded: form_helper
INFO - 2025-05-08 18:10:20 --> Helper loaded: file_helper
INFO - 2025-05-08 18:10:20 --> Helper loaded: html_helper
INFO - 2025-05-08 18:10:20 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:10:20 --> Controller Class Initialized
INFO - 2025-05-08 18:10:20 --> Model "BankModel" initialized
INFO - 2025-05-08 18:10:20 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:10:20 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:10:20 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:10:20 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:10:20 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:10:20 --> Final output sent to browser
DEBUG - 2025-05-08 18:10:20 --> Total execution time: 0.0035
INFO - 2025-05-08 18:11:02 --> Config Class Initialized
INFO - 2025-05-08 18:11:02 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:02 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:02 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:02 --> URI Class Initialized
INFO - 2025-05-08 18:11:02 --> Router Class Initialized
INFO - 2025-05-08 18:11:02 --> Output Class Initialized
INFO - 2025-05-08 18:11:02 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:02 --> Input Class Initialized
INFO - 2025-05-08 18:11:02 --> Language Class Initialized
INFO - 2025-05-08 18:11:02 --> Loader Class Initialized
INFO - 2025-05-08 18:11:02 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:02 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:02 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:02 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:02 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:02 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:02 --> Controller Class Initialized
INFO - 2025-05-08 18:11:02 --> Model "BankModel" initialized
INFO - 2025-05-08 18:11:02 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:11:02 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:11:02 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-08 18:11:02 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:11:02 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:11:02 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:02 --> Total execution time: 0.0348
INFO - 2025-05-08 18:11:25 --> Config Class Initialized
INFO - 2025-05-08 18:11:25 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:25 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:25 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:25 --> URI Class Initialized
INFO - 2025-05-08 18:11:25 --> Router Class Initialized
INFO - 2025-05-08 18:11:25 --> Output Class Initialized
INFO - 2025-05-08 18:11:25 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:25 --> Input Class Initialized
INFO - 2025-05-08 18:11:25 --> Language Class Initialized
INFO - 2025-05-08 18:11:25 --> Loader Class Initialized
INFO - 2025-05-08 18:11:25 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:25 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:25 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:25 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:25 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:25 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:25 --> Controller Class Initialized
INFO - 2025-05-08 18:11:25 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:11:25 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:11:25 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/index.php
INFO - 2025-05-08 18:11:25 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:11:25 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:11:25 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:25 --> Total execution time: 0.0048
INFO - 2025-05-08 18:11:26 --> Config Class Initialized
INFO - 2025-05-08 18:11:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:26 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:26 --> URI Class Initialized
INFO - 2025-05-08 18:11:26 --> Router Class Initialized
INFO - 2025-05-08 18:11:26 --> Output Class Initialized
INFO - 2025-05-08 18:11:26 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:26 --> Input Class Initialized
INFO - 2025-05-08 18:11:26 --> Language Class Initialized
INFO - 2025-05-08 18:11:26 --> Config Class Initialized
INFO - 2025-05-08 18:11:26 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:26 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:26 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:26 --> URI Class Initialized
INFO - 2025-05-08 18:11:26 --> Router Class Initialized
INFO - 2025-05-08 18:11:26 --> Output Class Initialized
INFO - 2025-05-08 18:11:26 --> Loader Class Initialized
INFO - 2025-05-08 18:11:26 --> Security Class Initialized
INFO - 2025-05-08 18:11:26 --> Helper loaded: url_helper
DEBUG - 2025-05-08 18:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:26 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:26 --> Input Class Initialized
INFO - 2025-05-08 18:11:26 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:26 --> Language Class Initialized
INFO - 2025-05-08 18:11:26 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:26 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:26 --> Loader Class Initialized
INFO - 2025-05-08 18:11:26 --> Database Driver Class Initialized
INFO - 2025-05-08 18:11:26 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:26 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:26 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:26 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:26 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:26 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:26 --> Controller Class Initialized
DEBUG - 2025-05-08 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:26 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:26 --> Total execution time: 0.0596
INFO - 2025-05-08 18:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:26 --> Controller Class Initialized
INFO - 2025-05-08 18:11:26 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:11:26 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:11:26 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:27 --> Config Class Initialized
INFO - 2025-05-08 18:11:27 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:27 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:27 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:27 --> URI Class Initialized
INFO - 2025-05-08 18:11:27 --> Router Class Initialized
INFO - 2025-05-08 18:11:27 --> Output Class Initialized
INFO - 2025-05-08 18:11:27 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:27 --> Input Class Initialized
INFO - 2025-05-08 18:11:27 --> Language Class Initialized
INFO - 2025-05-08 18:11:27 --> Loader Class Initialized
INFO - 2025-05-08 18:11:27 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:27 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:27 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:27 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:27 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:27 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:27 --> Controller Class Initialized
INFO - 2025-05-08 18:11:27 --> Model "UserModel" initialized
INFO - 2025-05-08 18:11:27 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:27 --> Total execution time: 0.0078
INFO - 2025-05-08 18:11:28 --> Config Class Initialized
INFO - 2025-05-08 18:11:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:28 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:28 --> URI Class Initialized
INFO - 2025-05-08 18:11:28 --> Router Class Initialized
INFO - 2025-05-08 18:11:28 --> Output Class Initialized
INFO - 2025-05-08 18:11:28 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:28 --> Input Class Initialized
INFO - 2025-05-08 18:11:28 --> Language Class Initialized
INFO - 2025-05-08 18:11:28 --> Loader Class Initialized
INFO - 2025-05-08 18:11:28 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:28 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:28 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:28 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:28 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:28 --> Controller Class Initialized
INFO - 2025-05-08 18:11:28 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:11:28 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:11:28 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:29 --> Config Class Initialized
INFO - 2025-05-08 18:11:29 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:29 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:29 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:29 --> URI Class Initialized
INFO - 2025-05-08 18:11:29 --> Router Class Initialized
INFO - 2025-05-08 18:11:29 --> Output Class Initialized
INFO - 2025-05-08 18:11:29 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:29 --> Input Class Initialized
INFO - 2025-05-08 18:11:29 --> Language Class Initialized
INFO - 2025-05-08 18:11:29 --> Loader Class Initialized
INFO - 2025-05-08 18:11:29 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:29 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:29 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:29 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:29 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:29 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:29 --> Controller Class Initialized
INFO - 2025-05-08 18:11:29 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:11:29 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-08 18:11:29 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:42 --> Config Class Initialized
INFO - 2025-05-08 18:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:42 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:42 --> URI Class Initialized
INFO - 2025-05-08 18:11:42 --> Router Class Initialized
INFO - 2025-05-08 18:11:42 --> Output Class Initialized
INFO - 2025-05-08 18:11:42 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:42 --> Input Class Initialized
INFO - 2025-05-08 18:11:42 --> Language Class Initialized
INFO - 2025-05-08 18:11:42 --> Loader Class Initialized
INFO - 2025-05-08 18:11:42 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:42 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:42 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:42 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:42 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:42 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:42 --> Controller Class Initialized
INFO - 2025-05-08 18:11:42 --> Model "CompanyModel" initialized
INFO - 2025-05-08 18:11:42 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:11:42 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:11:42 --> File loaded: /home/storagep/public_html/application/views/dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-08 18:11:42 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:11:42 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:11:42 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:42 --> Total execution time: 0.0053
INFO - 2025-05-08 18:11:43 --> Config Class Initialized
INFO - 2025-05-08 18:11:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:43 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:43 --> URI Class Initialized
INFO - 2025-05-08 18:11:43 --> Router Class Initialized
INFO - 2025-05-08 18:11:43 --> Output Class Initialized
INFO - 2025-05-08 18:11:43 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:43 --> Input Class Initialized
INFO - 2025-05-08 18:11:43 --> Language Class Initialized
INFO - 2025-05-08 18:11:43 --> Loader Class Initialized
INFO - 2025-05-08 18:11:43 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:43 --> Controller Class Initialized
INFO - 2025-05-08 18:11:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:43 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:43 --> Total execution time: 0.0025
INFO - 2025-05-08 18:11:43 --> Config Class Initialized
INFO - 2025-05-08 18:11:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:43 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:43 --> URI Class Initialized
INFO - 2025-05-08 18:11:43 --> Router Class Initialized
INFO - 2025-05-08 18:11:43 --> Output Class Initialized
INFO - 2025-05-08 18:11:43 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:43 --> Input Class Initialized
INFO - 2025-05-08 18:11:43 --> Language Class Initialized
INFO - 2025-05-08 18:11:43 --> Loader Class Initialized
INFO - 2025-05-08 18:11:43 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:43 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:43 --> Controller Class Initialized
INFO - 2025-05-08 18:11:43 --> Model "UserModel" initialized
INFO - 2025-05-08 18:11:43 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:43 --> Total execution time: 0.0033
INFO - 2025-05-08 18:11:44 --> Config Class Initialized
INFO - 2025-05-08 18:11:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:11:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:11:44 --> Utf8 Class Initialized
INFO - 2025-05-08 18:11:44 --> URI Class Initialized
INFO - 2025-05-08 18:11:44 --> Router Class Initialized
INFO - 2025-05-08 18:11:44 --> Output Class Initialized
INFO - 2025-05-08 18:11:44 --> Security Class Initialized
DEBUG - 2025-05-08 18:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:11:44 --> Input Class Initialized
INFO - 2025-05-08 18:11:44 --> Language Class Initialized
INFO - 2025-05-08 18:11:44 --> Loader Class Initialized
INFO - 2025-05-08 18:11:44 --> Helper loaded: url_helper
INFO - 2025-05-08 18:11:44 --> Helper loaded: string_helper
INFO - 2025-05-08 18:11:44 --> Helper loaded: form_helper
INFO - 2025-05-08 18:11:44 --> Helper loaded: file_helper
INFO - 2025-05-08 18:11:44 --> Helper loaded: html_helper
INFO - 2025-05-08 18:11:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:11:44 --> Controller Class Initialized
INFO - 2025-05-08 18:11:44 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:11:44 --> Final output sent to browser
DEBUG - 2025-05-08 18:11:44 --> Total execution time: 0.0027
INFO - 2025-05-08 18:12:32 --> Config Class Initialized
INFO - 2025-05-08 18:12:32 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:32 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:32 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:32 --> URI Class Initialized
INFO - 2025-05-08 18:12:32 --> Router Class Initialized
INFO - 2025-05-08 18:12:32 --> Output Class Initialized
INFO - 2025-05-08 18:12:32 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:32 --> Input Class Initialized
INFO - 2025-05-08 18:12:32 --> Language Class Initialized
INFO - 2025-05-08 18:12:32 --> Loader Class Initialized
INFO - 2025-05-08 18:12:32 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:32 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:32 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:32 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:32 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:32 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:33 --> Controller Class Initialized
INFO - 2025-05-08 18:12:33 --> Config Class Initialized
INFO - 2025-05-08 18:12:33 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:33 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:33 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:33 --> URI Class Initialized
INFO - 2025-05-08 18:12:33 --> Router Class Initialized
INFO - 2025-05-08 18:12:33 --> Output Class Initialized
INFO - 2025-05-08 18:12:33 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:33 --> Input Class Initialized
INFO - 2025-05-08 18:12:33 --> Language Class Initialized
INFO - 2025-05-08 18:12:33 --> Loader Class Initialized
INFO - 2025-05-08 18:12:33 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:33 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:33 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:33 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:33 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:33 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:33 --> Controller Class Initialized
INFO - 2025-05-08 18:12:34 --> Config Class Initialized
INFO - 2025-05-08 18:12:34 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:34 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:34 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:34 --> URI Class Initialized
DEBUG - 2025-05-08 18:12:34 --> No URI present. Default controller set.
INFO - 2025-05-08 18:12:34 --> Router Class Initialized
INFO - 2025-05-08 18:12:34 --> Output Class Initialized
INFO - 2025-05-08 18:12:34 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:34 --> Input Class Initialized
INFO - 2025-05-08 18:12:34 --> Language Class Initialized
INFO - 2025-05-08 18:12:34 --> Loader Class Initialized
INFO - 2025-05-08 18:12:34 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:34 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:34 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:34 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:34 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:34 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:34 --> Controller Class Initialized
INFO - 2025-05-08 18:12:34 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:12:34 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:12:34 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:12:34 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:12:34 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:12:34 --> Final output sent to browser
DEBUG - 2025-05-08 18:12:34 --> Total execution time: 0.0033
INFO - 2025-05-08 18:12:35 --> Config Class Initialized
INFO - 2025-05-08 18:12:35 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:35 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:35 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:35 --> URI Class Initialized
INFO - 2025-05-08 18:12:35 --> Router Class Initialized
INFO - 2025-05-08 18:12:35 --> Output Class Initialized
INFO - 2025-05-08 18:12:35 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:35 --> Input Class Initialized
INFO - 2025-05-08 18:12:35 --> Language Class Initialized
INFO - 2025-05-08 18:12:35 --> Loader Class Initialized
INFO - 2025-05-08 18:12:35 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:35 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:35 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:35 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:35 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:35 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:35 --> Controller Class Initialized
INFO - 2025-05-08 18:12:35 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:12:35 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:12:35 --> File loaded: /home/storagep/public_html/application/views/auctions/index.php
INFO - 2025-05-08 18:12:35 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:12:35 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:12:35 --> Final output sent to browser
DEBUG - 2025-05-08 18:12:35 --> Total execution time: 0.0047
INFO - 2025-05-08 18:12:43 --> Config Class Initialized
INFO - 2025-05-08 18:12:43 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:43 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:43 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:43 --> URI Class Initialized
INFO - 2025-05-08 18:12:43 --> Router Class Initialized
INFO - 2025-05-08 18:12:43 --> Output Class Initialized
INFO - 2025-05-08 18:12:43 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:43 --> Input Class Initialized
INFO - 2025-05-08 18:12:43 --> Language Class Initialized
INFO - 2025-05-08 18:12:43 --> Loader Class Initialized
INFO - 2025-05-08 18:12:43 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:43 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:43 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:43 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:43 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:43 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:43 --> Controller Class Initialized
INFO - 2025-05-08 18:12:43 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:12:44 --> Config Class Initialized
INFO - 2025-05-08 18:12:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:12:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:12:44 --> Utf8 Class Initialized
INFO - 2025-05-08 18:12:44 --> URI Class Initialized
INFO - 2025-05-08 18:12:44 --> Router Class Initialized
INFO - 2025-05-08 18:12:44 --> Output Class Initialized
INFO - 2025-05-08 18:12:44 --> Security Class Initialized
DEBUG - 2025-05-08 18:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:12:44 --> Input Class Initialized
INFO - 2025-05-08 18:12:44 --> Language Class Initialized
INFO - 2025-05-08 18:12:44 --> Loader Class Initialized
INFO - 2025-05-08 18:12:44 --> Helper loaded: url_helper
INFO - 2025-05-08 18:12:44 --> Helper loaded: string_helper
INFO - 2025-05-08 18:12:44 --> Helper loaded: form_helper
INFO - 2025-05-08 18:12:44 --> Helper loaded: file_helper
INFO - 2025-05-08 18:12:44 --> Helper loaded: html_helper
INFO - 2025-05-08 18:12:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:12:44 --> Controller Class Initialized
INFO - 2025-05-08 18:12:44 --> Model "AuctionModel" initialized
INFO - 2025-05-08 18:56:28 --> Config Class Initialized
INFO - 2025-05-08 18:56:28 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:56:28 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:56:28 --> Utf8 Class Initialized
INFO - 2025-05-08 18:56:28 --> URI Class Initialized
DEBUG - 2025-05-08 18:56:28 --> No URI present. Default controller set.
INFO - 2025-05-08 18:56:28 --> Router Class Initialized
INFO - 2025-05-08 18:56:28 --> Output Class Initialized
INFO - 2025-05-08 18:56:28 --> Security Class Initialized
DEBUG - 2025-05-08 18:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:56:28 --> Input Class Initialized
INFO - 2025-05-08 18:56:28 --> Language Class Initialized
INFO - 2025-05-08 18:56:28 --> Loader Class Initialized
INFO - 2025-05-08 18:56:28 --> Helper loaded: url_helper
INFO - 2025-05-08 18:56:28 --> Helper loaded: string_helper
INFO - 2025-05-08 18:56:28 --> Helper loaded: form_helper
INFO - 2025-05-08 18:56:28 --> Helper loaded: file_helper
INFO - 2025-05-08 18:56:28 --> Helper loaded: html_helper
INFO - 2025-05-08 18:56:28 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:56:28 --> Controller Class Initialized
INFO - 2025-05-08 18:56:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:56:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:56:28 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:56:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:56:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:56:28 --> Final output sent to browser
DEBUG - 2025-05-08 18:56:28 --> Total execution time: 0.0431
INFO - 2025-05-08 18:56:30 --> Config Class Initialized
INFO - 2025-05-08 18:56:30 --> Hooks Class Initialized
DEBUG - 2025-05-08 18:56:30 --> UTF-8 Support Enabled
INFO - 2025-05-08 18:56:30 --> Utf8 Class Initialized
INFO - 2025-05-08 18:56:30 --> URI Class Initialized
DEBUG - 2025-05-08 18:56:30 --> No URI present. Default controller set.
INFO - 2025-05-08 18:56:30 --> Router Class Initialized
INFO - 2025-05-08 18:56:30 --> Output Class Initialized
INFO - 2025-05-08 18:56:30 --> Security Class Initialized
DEBUG - 2025-05-08 18:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 18:56:30 --> Input Class Initialized
INFO - 2025-05-08 18:56:30 --> Language Class Initialized
INFO - 2025-05-08 18:56:30 --> Loader Class Initialized
INFO - 2025-05-08 18:56:30 --> Helper loaded: url_helper
INFO - 2025-05-08 18:56:30 --> Helper loaded: string_helper
INFO - 2025-05-08 18:56:30 --> Helper loaded: form_helper
INFO - 2025-05-08 18:56:30 --> Helper loaded: file_helper
INFO - 2025-05-08 18:56:30 --> Helper loaded: html_helper
INFO - 2025-05-08 18:56:30 --> Database Driver Class Initialized
DEBUG - 2025-05-08 18:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 18:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 18:56:30 --> Controller Class Initialized
INFO - 2025-05-08 18:56:30 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 18:56:30 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 18:56:30 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 18:56:30 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 18:56:30 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 18:56:30 --> Final output sent to browser
DEBUG - 2025-05-08 18:56:30 --> Total execution time: 0.0026
INFO - 2025-05-08 20:00:00 --> Config Class Initialized
INFO - 2025-05-08 20:00:00 --> Hooks Class Initialized
DEBUG - 2025-05-08 20:00:00 --> UTF-8 Support Enabled
INFO - 2025-05-08 20:00:00 --> Utf8 Class Initialized
INFO - 2025-05-08 20:00:00 --> URI Class Initialized
DEBUG - 2025-05-08 20:00:00 --> No URI present. Default controller set.
INFO - 2025-05-08 20:00:00 --> Router Class Initialized
INFO - 2025-05-08 20:00:00 --> Output Class Initialized
INFO - 2025-05-08 20:00:00 --> Security Class Initialized
DEBUG - 2025-05-08 20:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 20:00:00 --> Input Class Initialized
INFO - 2025-05-08 20:00:00 --> Language Class Initialized
INFO - 2025-05-08 20:00:00 --> Loader Class Initialized
INFO - 2025-05-08 20:00:00 --> Helper loaded: url_helper
INFO - 2025-05-08 20:00:00 --> Helper loaded: string_helper
INFO - 2025-05-08 20:00:00 --> Helper loaded: form_helper
INFO - 2025-05-08 20:00:00 --> Helper loaded: file_helper
INFO - 2025-05-08 20:00:00 --> Helper loaded: html_helper
INFO - 2025-05-08 20:00:00 --> Database Driver Class Initialized
DEBUG - 2025-05-08 20:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 20:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 20:00:00 --> Controller Class Initialized
INFO - 2025-05-08 20:00:00 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 20:00:00 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 20:00:00 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 20:00:00 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 20:00:00 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 20:00:00 --> Final output sent to browser
DEBUG - 2025-05-08 20:00:00 --> Total execution time: 0.0623
INFO - 2025-05-08 20:01:03 --> Config Class Initialized
INFO - 2025-05-08 20:01:03 --> Hooks Class Initialized
DEBUG - 2025-05-08 20:01:03 --> UTF-8 Support Enabled
INFO - 2025-05-08 20:01:03 --> Utf8 Class Initialized
INFO - 2025-05-08 20:01:03 --> URI Class Initialized
DEBUG - 2025-05-08 20:01:03 --> No URI present. Default controller set.
INFO - 2025-05-08 20:01:03 --> Router Class Initialized
INFO - 2025-05-08 20:01:03 --> Output Class Initialized
INFO - 2025-05-08 20:01:03 --> Security Class Initialized
DEBUG - 2025-05-08 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 20:01:03 --> Input Class Initialized
INFO - 2025-05-08 20:01:03 --> Language Class Initialized
INFO - 2025-05-08 20:01:03 --> Loader Class Initialized
INFO - 2025-05-08 20:01:03 --> Helper loaded: url_helper
INFO - 2025-05-08 20:01:03 --> Helper loaded: string_helper
INFO - 2025-05-08 20:01:03 --> Helper loaded: form_helper
INFO - 2025-05-08 20:01:03 --> Helper loaded: file_helper
INFO - 2025-05-08 20:01:03 --> Helper loaded: html_helper
INFO - 2025-05-08 20:01:03 --> Database Driver Class Initialized
DEBUG - 2025-05-08 20:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 20:01:03 --> Controller Class Initialized
INFO - 2025-05-08 20:01:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 20:01:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 20:01:03 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 20:01:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 20:01:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 20:01:03 --> Final output sent to browser
DEBUG - 2025-05-08 20:01:03 --> Total execution time: 0.0392
INFO - 2025-05-08 20:46:44 --> Config Class Initialized
INFO - 2025-05-08 20:46:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 20:46:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 20:46:44 --> Utf8 Class Initialized
INFO - 2025-05-08 20:46:44 --> URI Class Initialized
DEBUG - 2025-05-08 20:46:44 --> No URI present. Default controller set.
INFO - 2025-05-08 20:46:44 --> Router Class Initialized
INFO - 2025-05-08 20:46:44 --> Output Class Initialized
INFO - 2025-05-08 20:46:44 --> Security Class Initialized
DEBUG - 2025-05-08 20:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 20:46:44 --> Input Class Initialized
INFO - 2025-05-08 20:46:44 --> Language Class Initialized
INFO - 2025-05-08 20:46:44 --> Loader Class Initialized
INFO - 2025-05-08 20:46:44 --> Helper loaded: url_helper
INFO - 2025-05-08 20:46:44 --> Helper loaded: string_helper
INFO - 2025-05-08 20:46:44 --> Helper loaded: form_helper
INFO - 2025-05-08 20:46:44 --> Helper loaded: file_helper
INFO - 2025-05-08 20:46:44 --> Helper loaded: html_helper
INFO - 2025-05-08 20:46:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 20:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 20:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 20:46:44 --> Controller Class Initialized
INFO - 2025-05-08 20:46:44 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 20:46:44 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 20:46:44 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 20:46:44 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 20:46:44 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 20:46:44 --> Final output sent to browser
DEBUG - 2025-05-08 20:46:44 --> Total execution time: 0.0561
INFO - 2025-05-08 20:46:46 --> Config Class Initialized
INFO - 2025-05-08 20:46:46 --> Hooks Class Initialized
DEBUG - 2025-05-08 20:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-08 20:46:46 --> Utf8 Class Initialized
INFO - 2025-05-08 20:46:46 --> URI Class Initialized
INFO - 2025-05-08 20:46:46 --> Router Class Initialized
INFO - 2025-05-08 20:46:46 --> Output Class Initialized
INFO - 2025-05-08 20:46:46 --> Security Class Initialized
DEBUG - 2025-05-08 20:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 20:46:46 --> Input Class Initialized
INFO - 2025-05-08 20:46:46 --> Language Class Initialized
INFO - 2025-05-08 20:46:46 --> Loader Class Initialized
INFO - 2025-05-08 20:46:46 --> Helper loaded: url_helper
INFO - 2025-05-08 20:46:46 --> Helper loaded: string_helper
INFO - 2025-05-08 20:46:46 --> Helper loaded: form_helper
INFO - 2025-05-08 20:46:46 --> Helper loaded: file_helper
INFO - 2025-05-08 20:46:46 --> Helper loaded: html_helper
INFO - 2025-05-08 20:46:46 --> Database Driver Class Initialized
DEBUG - 2025-05-08 20:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 20:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 20:46:46 --> Controller Class Initialized
INFO - 2025-05-08 20:46:46 --> Model "AuctionModel" initialized
INFO - 2025-05-08 21:07:44 --> Config Class Initialized
INFO - 2025-05-08 21:07:44 --> Hooks Class Initialized
DEBUG - 2025-05-08 21:07:44 --> UTF-8 Support Enabled
INFO - 2025-05-08 21:07:44 --> Utf8 Class Initialized
INFO - 2025-05-08 21:07:44 --> URI Class Initialized
DEBUG - 2025-05-08 21:07:44 --> No URI present. Default controller set.
INFO - 2025-05-08 21:07:44 --> Router Class Initialized
INFO - 2025-05-08 21:07:44 --> Output Class Initialized
INFO - 2025-05-08 21:07:44 --> Security Class Initialized
DEBUG - 2025-05-08 21:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 21:07:44 --> Input Class Initialized
INFO - 2025-05-08 21:07:44 --> Language Class Initialized
INFO - 2025-05-08 21:07:44 --> Loader Class Initialized
INFO - 2025-05-08 21:07:44 --> Helper loaded: url_helper
INFO - 2025-05-08 21:07:44 --> Helper loaded: string_helper
INFO - 2025-05-08 21:07:44 --> Helper loaded: form_helper
INFO - 2025-05-08 21:07:44 --> Helper loaded: file_helper
INFO - 2025-05-08 21:07:44 --> Helper loaded: html_helper
INFO - 2025-05-08 21:07:44 --> Database Driver Class Initialized
DEBUG - 2025-05-08 21:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 21:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 21:07:44 --> Controller Class Initialized
INFO - 2025-05-08 21:07:44 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 21:07:44 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 21:07:44 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 21:07:44 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 21:07:44 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 21:07:44 --> Final output sent to browser
DEBUG - 2025-05-08 21:07:44 --> Total execution time: 0.0451
INFO - 2025-05-08 21:07:45 --> Config Class Initialized
INFO - 2025-05-08 21:07:45 --> Hooks Class Initialized
DEBUG - 2025-05-08 21:07:45 --> UTF-8 Support Enabled
INFO - 2025-05-08 21:07:45 --> Utf8 Class Initialized
INFO - 2025-05-08 21:07:45 --> URI Class Initialized
DEBUG - 2025-05-08 21:07:45 --> No URI present. Default controller set.
INFO - 2025-05-08 21:07:45 --> Router Class Initialized
INFO - 2025-05-08 21:07:45 --> Output Class Initialized
INFO - 2025-05-08 21:07:45 --> Security Class Initialized
DEBUG - 2025-05-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 21:07:45 --> Input Class Initialized
INFO - 2025-05-08 21:07:45 --> Language Class Initialized
INFO - 2025-05-08 21:07:45 --> Loader Class Initialized
INFO - 2025-05-08 21:07:45 --> Helper loaded: url_helper
INFO - 2025-05-08 21:07:45 --> Helper loaded: string_helper
INFO - 2025-05-08 21:07:45 --> Helper loaded: form_helper
INFO - 2025-05-08 21:07:45 --> Helper loaded: file_helper
INFO - 2025-05-08 21:07:45 --> Helper loaded: html_helper
INFO - 2025-05-08 21:07:45 --> Database Driver Class Initialized
DEBUG - 2025-05-08 21:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 21:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 21:07:45 --> Controller Class Initialized
INFO - 2025-05-08 21:07:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 21:07:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 21:07:45 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 21:07:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 21:07:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 21:07:45 --> Final output sent to browser
DEBUG - 2025-05-08 21:07:45 --> Total execution time: 0.0031
INFO - 2025-05-08 21:07:47 --> Config Class Initialized
INFO - 2025-05-08 21:07:47 --> Hooks Class Initialized
DEBUG - 2025-05-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2025-05-08 21:07:47 --> Utf8 Class Initialized
INFO - 2025-05-08 21:07:47 --> URI Class Initialized
INFO - 2025-05-08 21:07:47 --> Router Class Initialized
INFO - 2025-05-08 21:07:47 --> Output Class Initialized
INFO - 2025-05-08 21:07:47 --> Security Class Initialized
DEBUG - 2025-05-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 21:07:47 --> Input Class Initialized
INFO - 2025-05-08 21:07:47 --> Language Class Initialized
ERROR - 2025-05-08 21:07:47 --> 404 Page Not Found: Banner1png/index
INFO - 2025-05-08 21:26:17 --> Config Class Initialized
INFO - 2025-05-08 21:26:17 --> Hooks Class Initialized
DEBUG - 2025-05-08 21:26:17 --> UTF-8 Support Enabled
INFO - 2025-05-08 21:26:17 --> Utf8 Class Initialized
INFO - 2025-05-08 21:26:17 --> URI Class Initialized
DEBUG - 2025-05-08 21:26:17 --> No URI present. Default controller set.
INFO - 2025-05-08 21:26:17 --> Router Class Initialized
INFO - 2025-05-08 21:26:17 --> Output Class Initialized
INFO - 2025-05-08 21:26:17 --> Security Class Initialized
DEBUG - 2025-05-08 21:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 21:26:17 --> Input Class Initialized
INFO - 2025-05-08 21:26:17 --> Language Class Initialized
INFO - 2025-05-08 21:26:17 --> Loader Class Initialized
INFO - 2025-05-08 21:26:17 --> Helper loaded: url_helper
INFO - 2025-05-08 21:26:17 --> Helper loaded: string_helper
INFO - 2025-05-08 21:26:17 --> Helper loaded: form_helper
INFO - 2025-05-08 21:26:17 --> Helper loaded: file_helper
INFO - 2025-05-08 21:26:17 --> Helper loaded: html_helper
INFO - 2025-05-08 21:26:17 --> Database Driver Class Initialized
DEBUG - 2025-05-08 21:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 21:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 21:26:17 --> Controller Class Initialized
INFO - 2025-05-08 21:26:17 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 21:26:17 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 21:26:17 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 21:26:17 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 21:26:17 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 21:26:17 --> Final output sent to browser
DEBUG - 2025-05-08 21:26:17 --> Total execution time: 0.0298
INFO - 2025-05-08 22:42:20 --> Config Class Initialized
INFO - 2025-05-08 22:42:20 --> Hooks Class Initialized
DEBUG - 2025-05-08 22:42:20 --> UTF-8 Support Enabled
INFO - 2025-05-08 22:42:20 --> Utf8 Class Initialized
INFO - 2025-05-08 22:42:20 --> URI Class Initialized
INFO - 2025-05-08 22:42:20 --> Router Class Initialized
INFO - 2025-05-08 22:42:20 --> Output Class Initialized
INFO - 2025-05-08 22:42:20 --> Security Class Initialized
DEBUG - 2025-05-08 22:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 22:42:20 --> Input Class Initialized
INFO - 2025-05-08 22:42:20 --> Language Class Initialized
ERROR - 2025-05-08 22:42:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-08 22:42:21 --> Config Class Initialized
INFO - 2025-05-08 22:42:21 --> Hooks Class Initialized
DEBUG - 2025-05-08 22:42:21 --> UTF-8 Support Enabled
INFO - 2025-05-08 22:42:21 --> Utf8 Class Initialized
INFO - 2025-05-08 22:42:21 --> URI Class Initialized
DEBUG - 2025-05-08 22:42:21 --> No URI present. Default controller set.
INFO - 2025-05-08 22:42:21 --> Router Class Initialized
INFO - 2025-05-08 22:42:21 --> Output Class Initialized
INFO - 2025-05-08 22:42:21 --> Security Class Initialized
DEBUG - 2025-05-08 22:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-08 22:42:21 --> Input Class Initialized
INFO - 2025-05-08 22:42:21 --> Language Class Initialized
INFO - 2025-05-08 22:42:21 --> Loader Class Initialized
INFO - 2025-05-08 22:42:21 --> Helper loaded: url_helper
INFO - 2025-05-08 22:42:21 --> Helper loaded: string_helper
INFO - 2025-05-08 22:42:21 --> Helper loaded: form_helper
INFO - 2025-05-08 22:42:21 --> Helper loaded: file_helper
INFO - 2025-05-08 22:42:21 --> Helper loaded: html_helper
INFO - 2025-05-08 22:42:21 --> Database Driver Class Initialized
DEBUG - 2025-05-08 22:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-08 22:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-08 22:42:21 --> Controller Class Initialized
INFO - 2025-05-08 22:42:21 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-08 22:42:21 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-08 22:42:21 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-08 22:42:21 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-08 22:42:21 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-08 22:42:21 --> Final output sent to browser
DEBUG - 2025-05-08 22:42:21 --> Total execution time: 0.0371
