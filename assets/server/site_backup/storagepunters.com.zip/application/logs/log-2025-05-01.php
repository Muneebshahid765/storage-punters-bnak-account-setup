<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-01 11:49:20 --> Config Class Initialized
INFO - 2025-05-01 11:49:20 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:49:20 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:49:20 --> Utf8 Class Initialized
INFO - 2025-05-01 11:49:20 --> URI Class Initialized
INFO - 2025-05-01 11:49:20 --> Router Class Initialized
INFO - 2025-05-01 11:49:20 --> Output Class Initialized
INFO - 2025-05-01 11:49:20 --> Security Class Initialized
DEBUG - 2025-05-01 11:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:49:20 --> Input Class Initialized
INFO - 2025-05-01 11:49:20 --> Language Class Initialized
INFO - 2025-05-01 11:49:20 --> Loader Class Initialized
INFO - 2025-05-01 11:49:20 --> Helper loaded: url_helper
INFO - 2025-05-01 11:49:20 --> Helper loaded: string_helper
INFO - 2025-05-01 11:49:20 --> Helper loaded: form_helper
INFO - 2025-05-01 11:49:20 --> Helper loaded: file_helper
INFO - 2025-05-01 11:49:20 --> Helper loaded: html_helper
INFO - 2025-05-01 11:49:20 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 11:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 11:49:20 --> Controller Class Initialized
INFO - 2025-05-01 19:49:20 --> Auction ID 13 scheduled to run at Brisbane time: 2025-05-01 19:51:00 (timestamp: 1746093060)
DEBUG - 2025-05-01 19:49:20 --> Scheduled command: schtasks /Create /SC ONCE /TN auction_13_681343a0738a0 /TR "C:\xampp\php\php.exe C:\xampp\htdocs\storage_auctions\index.php CliWorker monitorAuctionEnd 13 1746093060" /ST 19:51 /SD 05/01/2025 /F
INFO - 2025-05-01 19:49:20 --> Final output sent to browser
DEBUG - 2025-05-01 19:49:20 --> Total execution time: 0.5592
INFO - 2025-05-01 11:52:22 --> Config Class Initialized
INFO - 2025-05-01 11:52:22 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:52:22 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:52:22 --> Utf8 Class Initialized
INFO - 2025-05-01 11:52:22 --> URI Class Initialized
INFO - 2025-05-01 11:52:22 --> Router Class Initialized
INFO - 2025-05-01 11:52:22 --> Output Class Initialized
INFO - 2025-05-01 11:52:22 --> Security Class Initialized
DEBUG - 2025-05-01 11:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:52:22 --> Input Class Initialized
INFO - 2025-05-01 11:52:22 --> Language Class Initialized
INFO - 2025-05-01 11:52:22 --> Loader Class Initialized
INFO - 2025-05-01 11:52:22 --> Helper loaded: url_helper
INFO - 2025-05-01 11:52:22 --> Helper loaded: string_helper
INFO - 2025-05-01 11:52:22 --> Helper loaded: form_helper
INFO - 2025-05-01 11:52:22 --> Helper loaded: file_helper
INFO - 2025-05-01 11:52:22 --> Helper loaded: html_helper
INFO - 2025-05-01 11:52:22 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:52:22 --> Session: Initialization under CLI aborted.
INFO - 2025-05-01 11:52:22 --> Controller Class Initialized
INFO - 2025-05-01 19:52:22 --> Model "AuctionModel" initialized
INFO - 2025-05-01 19:52:22 --> CliWorker: monitorAuctionEnd STARTED for auction ID 13 at 2025-05-01 19:52:22
DEBUG - 2025-05-01 19:52:22 --> CliWorker: Auction ID 13 already expired (timestamp difference = -82). Proceeding immediately.
INFO - 2025-05-01 19:52:22 --> Model "UserModel" initialized
INFO - 2025-05-01 19:52:22 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 19:52:22 --> CliWorker: Auction ID 13 marked as won.
INFO - 2025-05-01 19:52:22 --> CliWorker: Winner email queued for user ID 1 (Auction ID 13, Bid: 260)
INFO - 2025-05-01 19:52:22 --> Final output sent to browser
DEBUG - 2025-05-01 19:52:22 --> Total execution time: 0.3220
INFO - 2025-05-01 11:52:58 --> Config Class Initialized
INFO - 2025-05-01 11:52:58 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:52:58 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:52:58 --> Utf8 Class Initialized
INFO - 2025-05-01 11:52:58 --> URI Class Initialized
INFO - 2025-05-01 11:52:58 --> Router Class Initialized
INFO - 2025-05-01 11:52:58 --> Output Class Initialized
INFO - 2025-05-01 11:52:58 --> Security Class Initialized
DEBUG - 2025-05-01 11:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:52:58 --> Input Class Initialized
INFO - 2025-05-01 11:52:58 --> Language Class Initialized
INFO - 2025-05-01 11:52:58 --> Loader Class Initialized
INFO - 2025-05-01 11:52:58 --> Helper loaded: url_helper
INFO - 2025-05-01 11:52:58 --> Helper loaded: string_helper
INFO - 2025-05-01 11:52:58 --> Helper loaded: form_helper
INFO - 2025-05-01 11:52:58 --> Helper loaded: file_helper
INFO - 2025-05-01 11:52:58 --> Helper loaded: html_helper
INFO - 2025-05-01 11:52:58 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:52:58 --> Session: Initialization under CLI aborted.
INFO - 2025-05-01 11:52:58 --> Controller Class Initialized
INFO - 2025-05-01 19:52:58 --> Model "AuctionModel" initialized
INFO - 2025-05-01 19:52:58 --> CliWorker: monitorAuctionEnd STARTED for auction ID 13 at 2025-05-01 19:52:58
DEBUG - 2025-05-01 19:52:58 --> CliWorker: Auction ID 13 already expired (timestamp difference = -118). Proceeding immediately.
INFO - 2025-05-01 19:52:58 --> Model "UserModel" initialized
INFO - 2025-05-01 19:52:58 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 19:52:58 --> CliWorker: Auction ID 13 marked as won.
INFO - 2025-05-01 19:52:58 --> CliWorker: Winner email queued for user ID 1 (Auction ID 13, Bid: 260)
INFO - 2025-05-01 19:52:58 --> Final output sent to browser
DEBUG - 2025-05-01 19:52:58 --> Total execution time: 0.3058
INFO - 2025-05-01 11:54:11 --> Config Class Initialized
INFO - 2025-05-01 11:54:11 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:54:11 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:54:11 --> Utf8 Class Initialized
INFO - 2025-05-01 11:54:11 --> URI Class Initialized
INFO - 2025-05-01 11:54:11 --> Router Class Initialized
INFO - 2025-05-01 11:54:11 --> Output Class Initialized
INFO - 2025-05-01 11:54:11 --> Security Class Initialized
DEBUG - 2025-05-01 11:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:54:11 --> Input Class Initialized
INFO - 2025-05-01 11:54:11 --> Language Class Initialized
INFO - 2025-05-01 11:54:11 --> Loader Class Initialized
INFO - 2025-05-01 11:54:11 --> Helper loaded: url_helper
INFO - 2025-05-01 11:54:11 --> Helper loaded: string_helper
INFO - 2025-05-01 11:54:11 --> Helper loaded: form_helper
INFO - 2025-05-01 11:54:11 --> Helper loaded: file_helper
INFO - 2025-05-01 11:54:11 --> Helper loaded: html_helper
INFO - 2025-05-01 11:54:11 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:54:11 --> Session: Initialization under CLI aborted.
INFO - 2025-05-01 11:54:11 --> Controller Class Initialized
INFO - 2025-05-01 19:54:11 --> Model "AuctionModel" initialized
INFO - 2025-05-01 19:54:11 --> CliWorker: monitorAuctionEnd STARTED for auction ID 13 at 2025-05-01 19:54:11
DEBUG - 2025-05-01 19:54:11 --> CliWorker: Auction ID 13 already expired (timestamp difference = -191). Proceeding immediately.
INFO - 2025-05-01 19:54:11 --> Model "UserModel" initialized
INFO - 2025-05-01 19:54:11 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 19:54:11 --> CliWorker: Auction ID 13 marked as won.
INFO - 2025-05-01 19:54:11 --> CliWorker: Winner email queued for user ID 1 (Auction ID 13, Bid: 260)
INFO - 2025-05-01 11:54:12 --> Config Class Initialized
INFO - 2025-05-01 11:54:12 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:54:12 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:54:12 --> Utf8 Class Initialized
INFO - 2025-05-01 11:54:12 --> URI Class Initialized
INFO - 2025-05-01 11:54:12 --> Router Class Initialized
INFO - 2025-05-01 11:54:12 --> Output Class Initialized
INFO - 2025-05-01 11:54:12 --> Security Class Initialized
DEBUG - 2025-05-01 11:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:54:12 --> Input Class Initialized
INFO - 2025-05-01 11:54:12 --> Language Class Initialized
INFO - 2025-05-01 11:54:12 --> Loader Class Initialized
INFO - 2025-05-01 11:54:12 --> Helper loaded: url_helper
INFO - 2025-05-01 11:54:12 --> Helper loaded: string_helper
INFO - 2025-05-01 11:54:12 --> Helper loaded: form_helper
INFO - 2025-05-01 11:54:12 --> Helper loaded: file_helper
INFO - 2025-05-01 11:54:12 --> Helper loaded: html_helper
INFO - 2025-05-01 11:54:12 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:54:12 --> Session: Initialization under CLI aborted.
INFO - 2025-05-01 11:54:12 --> Controller Class Initialized
INFO - 2025-05-01 19:54:12 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 19:54:12 --> Model "AuctionModel" initialized
INFO - 2025-05-01 19:54:12 --> Model "InvoiceModel" initialized
DEBUG - 2025-05-01 19:54:12 --> PHPMailer class is loaded.
INFO - 2025-05-01 19:54:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_winner_email.php
INFO - 2025-05-01 11:54:22 --> Config Class Initialized
INFO - 2025-05-01 11:54:22 --> Hooks Class Initialized
DEBUG - 2025-05-01 11:54:22 --> UTF-8 Support Enabled
INFO - 2025-05-01 11:54:22 --> Utf8 Class Initialized
INFO - 2025-05-01 11:54:22 --> URI Class Initialized
INFO - 2025-05-01 11:54:22 --> Router Class Initialized
INFO - 2025-05-01 11:54:22 --> Output Class Initialized
INFO - 2025-05-01 11:54:22 --> Security Class Initialized
DEBUG - 2025-05-01 11:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 11:54:22 --> Input Class Initialized
INFO - 2025-05-01 11:54:22 --> Language Class Initialized
INFO - 2025-05-01 11:54:22 --> Loader Class Initialized
INFO - 2025-05-01 11:54:22 --> Helper loaded: url_helper
INFO - 2025-05-01 11:54:22 --> Helper loaded: string_helper
INFO - 2025-05-01 11:54:22 --> Helper loaded: form_helper
INFO - 2025-05-01 11:54:22 --> Helper loaded: file_helper
INFO - 2025-05-01 11:54:22 --> Helper loaded: html_helper
INFO - 2025-05-01 11:54:22 --> Database Driver Class Initialized
DEBUG - 2025-05-01 11:54:22 --> Session: Initialization under CLI aborted.
INFO - 2025-05-01 11:54:22 --> Controller Class Initialized
INFO - 2025-05-01 19:54:22 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 19:54:22 --> Model "AuctionModel" initialized
INFO - 2025-05-01 19:54:22 --> Model "InvoiceModel" initialized
INFO - 2025-05-01 19:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/pdf_invoice_template.php
DEBUG - 2025-05-01 19:54:23 --> PHPMailer class is loaded.
INFO - 2025-05-01 19:54:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_invoice_email.php
INFO - 2025-05-01 12:08:28 --> Config Class Initialized
INFO - 2025-05-01 12:08:28 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:28 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:28 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:28 --> URI Class Initialized
INFO - 2025-05-01 12:08:28 --> Router Class Initialized
INFO - 2025-05-01 12:08:28 --> Output Class Initialized
INFO - 2025-05-01 12:08:28 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:28 --> Input Class Initialized
INFO - 2025-05-01 12:08:28 --> Language Class Initialized
INFO - 2025-05-01 12:08:28 --> Loader Class Initialized
INFO - 2025-05-01 12:08:28 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:28 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:28 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:28 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:28 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:28 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:28 --> Controller Class Initialized
INFO - 2025-05-01 12:08:31 --> Config Class Initialized
INFO - 2025-05-01 12:08:31 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:31 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:31 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:31 --> URI Class Initialized
INFO - 2025-05-01 12:08:31 --> Router Class Initialized
INFO - 2025-05-01 12:08:31 --> Output Class Initialized
INFO - 2025-05-01 12:08:31 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:31 --> Input Class Initialized
INFO - 2025-05-01 12:08:31 --> Language Class Initialized
INFO - 2025-05-01 12:08:31 --> Loader Class Initialized
INFO - 2025-05-01 12:08:31 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:31 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:31 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:31 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:31 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:31 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:31 --> Controller Class Initialized
INFO - 2025-05-01 20:08:31 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:08:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:08:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:08:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:08:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:08:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:08:33 --> Final output sent to browser
DEBUG - 2025-05-01 20:08:33 --> Total execution time: 1.6929
INFO - 2025-05-01 12:08:36 --> Config Class Initialized
INFO - 2025-05-01 12:08:36 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:36 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:36 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:36 --> URI Class Initialized
INFO - 2025-05-01 12:08:36 --> Router Class Initialized
INFO - 2025-05-01 12:08:36 --> Output Class Initialized
INFO - 2025-05-01 12:08:36 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:36 --> Input Class Initialized
INFO - 2025-05-01 12:08:36 --> Language Class Initialized
INFO - 2025-05-01 12:08:36 --> Loader Class Initialized
INFO - 2025-05-01 12:08:36 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:36 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:36 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:36 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:36 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:36 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:36 --> Controller Class Initialized
INFO - 2025-05-01 12:08:36 --> Config Class Initialized
INFO - 2025-05-01 12:08:36 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:36 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:36 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:36 --> URI Class Initialized
INFO - 2025-05-01 12:08:37 --> Router Class Initialized
INFO - 2025-05-01 12:08:37 --> Output Class Initialized
INFO - 2025-05-01 12:08:37 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:37 --> Input Class Initialized
INFO - 2025-05-01 12:08:37 --> Language Class Initialized
INFO - 2025-05-01 12:08:37 --> Loader Class Initialized
INFO - 2025-05-01 12:08:37 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:37 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:37 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:37 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:37 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:37 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:37 --> Controller Class Initialized
INFO - 2025-05-01 20:08:37 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:08:41 --> Config Class Initialized
INFO - 2025-05-01 12:08:41 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:41 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:41 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:41 --> URI Class Initialized
INFO - 2025-05-01 12:08:41 --> Router Class Initialized
INFO - 2025-05-01 12:08:41 --> Output Class Initialized
INFO - 2025-05-01 12:08:41 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:41 --> Input Class Initialized
INFO - 2025-05-01 12:08:41 --> Language Class Initialized
INFO - 2025-05-01 12:08:41 --> Loader Class Initialized
INFO - 2025-05-01 12:08:41 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:41 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:41 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:41 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:41 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:41 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:41 --> Controller Class Initialized
INFO - 2025-05-01 20:08:41 --> Model "UserModel" initialized
INFO - 2025-05-01 12:08:42 --> Config Class Initialized
INFO - 2025-05-01 12:08:42 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:42 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:42 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:42 --> URI Class Initialized
INFO - 2025-05-01 12:08:42 --> Router Class Initialized
INFO - 2025-05-01 12:08:42 --> Output Class Initialized
INFO - 2025-05-01 12:08:42 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:42 --> Input Class Initialized
INFO - 2025-05-01 12:08:42 --> Language Class Initialized
INFO - 2025-05-01 12:08:42 --> Loader Class Initialized
INFO - 2025-05-01 12:08:42 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:42 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:42 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:42 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:42 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:42 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:42 --> Controller Class Initialized
INFO - 2025-05-01 20:08:42 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:08:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:08:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:08:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:08:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:08:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:08:42 --> Final output sent to browser
DEBUG - 2025-05-01 20:08:42 --> Total execution time: 0.2604
INFO - 2025-05-01 12:08:48 --> Config Class Initialized
INFO - 2025-05-01 12:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:48 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:48 --> URI Class Initialized
INFO - 2025-05-01 12:08:48 --> Router Class Initialized
INFO - 2025-05-01 12:08:48 --> Output Class Initialized
INFO - 2025-05-01 12:08:48 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:48 --> Input Class Initialized
INFO - 2025-05-01 12:08:48 --> Language Class Initialized
INFO - 2025-05-01 12:08:48 --> Loader Class Initialized
INFO - 2025-05-01 12:08:48 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:48 --> Controller Class Initialized
INFO - 2025-05-01 12:08:48 --> Config Class Initialized
INFO - 2025-05-01 12:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:48 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:48 --> URI Class Initialized
INFO - 2025-05-01 12:08:48 --> Router Class Initialized
INFO - 2025-05-01 12:08:48 --> Output Class Initialized
INFO - 2025-05-01 12:08:48 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:48 --> Input Class Initialized
INFO - 2025-05-01 12:08:48 --> Language Class Initialized
INFO - 2025-05-01 12:08:48 --> Loader Class Initialized
INFO - 2025-05-01 12:08:48 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:48 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:48 --> Controller Class Initialized
INFO - 2025-05-01 20:08:48 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:08:51 --> Config Class Initialized
INFO - 2025-05-01 12:08:51 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:51 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:51 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:51 --> URI Class Initialized
INFO - 2025-05-01 12:08:51 --> Router Class Initialized
INFO - 2025-05-01 12:08:51 --> Output Class Initialized
INFO - 2025-05-01 12:08:51 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:51 --> Input Class Initialized
INFO - 2025-05-01 12:08:51 --> Language Class Initialized
INFO - 2025-05-01 12:08:51 --> Loader Class Initialized
INFO - 2025-05-01 12:08:51 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:51 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:51 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:51 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:51 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:51 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:51 --> Controller Class Initialized
INFO - 2025-05-01 20:08:51 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:08:51 --> Final output sent to browser
DEBUG - 2025-05-01 20:08:51 --> Total execution time: 0.1761
INFO - 2025-05-01 12:08:52 --> Config Class Initialized
INFO - 2025-05-01 12:08:52 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:52 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:52 --> URI Class Initialized
INFO - 2025-05-01 12:08:52 --> Router Class Initialized
INFO - 2025-05-01 12:08:52 --> Output Class Initialized
INFO - 2025-05-01 12:08:52 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:52 --> Input Class Initialized
INFO - 2025-05-01 12:08:52 --> Language Class Initialized
INFO - 2025-05-01 12:08:53 --> Loader Class Initialized
INFO - 2025-05-01 12:08:53 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:53 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:53 --> Controller Class Initialized
INFO - 2025-05-01 12:08:53 --> Config Class Initialized
INFO - 2025-05-01 12:08:53 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:08:53 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:08:53 --> Utf8 Class Initialized
INFO - 2025-05-01 12:08:53 --> URI Class Initialized
INFO - 2025-05-01 12:08:53 --> Router Class Initialized
INFO - 2025-05-01 12:08:53 --> Output Class Initialized
INFO - 2025-05-01 12:08:53 --> Security Class Initialized
DEBUG - 2025-05-01 12:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:08:53 --> Input Class Initialized
INFO - 2025-05-01 12:08:53 --> Language Class Initialized
INFO - 2025-05-01 12:08:53 --> Loader Class Initialized
INFO - 2025-05-01 12:08:53 --> Helper loaded: url_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: string_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: form_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: file_helper
INFO - 2025-05-01 12:08:53 --> Helper loaded: html_helper
INFO - 2025-05-01 12:08:53 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:08:53 --> Controller Class Initialized
INFO - 2025-05-01 20:08:53 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:10:53 --> Config Class Initialized
INFO - 2025-05-01 12:10:53 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:10:53 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:10:53 --> Utf8 Class Initialized
INFO - 2025-05-01 12:10:53 --> URI Class Initialized
INFO - 2025-05-01 12:10:53 --> Router Class Initialized
INFO - 2025-05-01 12:10:53 --> Output Class Initialized
INFO - 2025-05-01 12:10:53 --> Security Class Initialized
DEBUG - 2025-05-01 12:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:10:53 --> Input Class Initialized
INFO - 2025-05-01 12:10:53 --> Language Class Initialized
INFO - 2025-05-01 12:10:53 --> Loader Class Initialized
INFO - 2025-05-01 12:10:53 --> Helper loaded: url_helper
INFO - 2025-05-01 12:10:53 --> Helper loaded: string_helper
INFO - 2025-05-01 12:10:53 --> Helper loaded: form_helper
INFO - 2025-05-01 12:10:53 --> Helper loaded: file_helper
INFO - 2025-05-01 12:10:53 --> Helper loaded: html_helper
INFO - 2025-05-01 12:10:53 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:10:53 --> Controller Class Initialized
INFO - 2025-05-01 20:10:53 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:10:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:10:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:10:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:10:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:10:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:10:53 --> Final output sent to browser
DEBUG - 2025-05-01 20:10:53 --> Total execution time: 0.1634
INFO - 2025-05-01 12:10:54 --> Config Class Initialized
INFO - 2025-05-01 12:10:54 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:10:54 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:10:54 --> Utf8 Class Initialized
INFO - 2025-05-01 12:10:54 --> URI Class Initialized
INFO - 2025-05-01 12:10:54 --> Router Class Initialized
INFO - 2025-05-01 12:10:54 --> Output Class Initialized
INFO - 2025-05-01 12:10:54 --> Security Class Initialized
DEBUG - 2025-05-01 12:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:10:54 --> Input Class Initialized
INFO - 2025-05-01 12:10:54 --> Language Class Initialized
INFO - 2025-05-01 12:10:54 --> Loader Class Initialized
INFO - 2025-05-01 12:10:54 --> Helper loaded: url_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: string_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: form_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: file_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: html_helper
INFO - 2025-05-01 12:10:54 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:10:54 --> Controller Class Initialized
INFO - 2025-05-01 12:10:54 --> Config Class Initialized
INFO - 2025-05-01 12:10:54 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:10:54 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:10:54 --> Utf8 Class Initialized
INFO - 2025-05-01 12:10:54 --> URI Class Initialized
INFO - 2025-05-01 12:10:54 --> Router Class Initialized
INFO - 2025-05-01 12:10:54 --> Output Class Initialized
INFO - 2025-05-01 12:10:54 --> Security Class Initialized
DEBUG - 2025-05-01 12:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:10:54 --> Input Class Initialized
INFO - 2025-05-01 12:10:54 --> Language Class Initialized
INFO - 2025-05-01 12:10:54 --> Loader Class Initialized
INFO - 2025-05-01 12:10:54 --> Helper loaded: url_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: string_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: form_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: file_helper
INFO - 2025-05-01 12:10:54 --> Helper loaded: html_helper
INFO - 2025-05-01 12:10:54 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:10:54 --> Controller Class Initialized
INFO - 2025-05-01 20:10:54 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:11:00 --> Config Class Initialized
INFO - 2025-05-01 12:11:00 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:00 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:00 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:00 --> URI Class Initialized
INFO - 2025-05-01 12:11:00 --> Router Class Initialized
INFO - 2025-05-01 12:11:00 --> Output Class Initialized
INFO - 2025-05-01 12:11:00 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:00 --> Input Class Initialized
INFO - 2025-05-01 12:11:00 --> Language Class Initialized
INFO - 2025-05-01 12:11:00 --> Loader Class Initialized
INFO - 2025-05-01 12:11:00 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:00 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:00 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:00 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:00 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:00 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:00 --> Controller Class Initialized
INFO - 2025-05-01 20:11:00 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:11:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:11:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:11:01 --> Final output sent to browser
DEBUG - 2025-05-01 20:11:01 --> Total execution time: 0.1390
INFO - 2025-05-01 12:11:02 --> Config Class Initialized
INFO - 2025-05-01 12:11:02 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:02 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:02 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:02 --> URI Class Initialized
INFO - 2025-05-01 12:11:02 --> Router Class Initialized
INFO - 2025-05-01 12:11:02 --> Output Class Initialized
INFO - 2025-05-01 12:11:02 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:02 --> Input Class Initialized
INFO - 2025-05-01 12:11:02 --> Language Class Initialized
INFO - 2025-05-01 12:11:02 --> Loader Class Initialized
INFO - 2025-05-01 12:11:02 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:02 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:02 --> Controller Class Initialized
INFO - 2025-05-01 12:11:02 --> Config Class Initialized
INFO - 2025-05-01 12:11:02 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:02 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:02 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:02 --> URI Class Initialized
INFO - 2025-05-01 12:11:02 --> Router Class Initialized
INFO - 2025-05-01 12:11:02 --> Output Class Initialized
INFO - 2025-05-01 12:11:02 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:02 --> Input Class Initialized
INFO - 2025-05-01 12:11:02 --> Language Class Initialized
INFO - 2025-05-01 12:11:02 --> Loader Class Initialized
INFO - 2025-05-01 12:11:02 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:02 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:02 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:02 --> Controller Class Initialized
INFO - 2025-05-01 20:11:02 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:11:42 --> Config Class Initialized
INFO - 2025-05-01 12:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:42 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:42 --> URI Class Initialized
INFO - 2025-05-01 12:11:42 --> Router Class Initialized
INFO - 2025-05-01 12:11:42 --> Output Class Initialized
INFO - 2025-05-01 12:11:42 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:42 --> Input Class Initialized
INFO - 2025-05-01 12:11:42 --> Language Class Initialized
INFO - 2025-05-01 12:11:42 --> Loader Class Initialized
INFO - 2025-05-01 12:11:42 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:42 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:42 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:42 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:42 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:42 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:42 --> Controller Class Initialized
INFO - 2025-05-01 20:11:42 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-01 20:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:11:42 --> Final output sent to browser
DEBUG - 2025-05-01 20:11:42 --> Total execution time: 0.1089
INFO - 2025-05-01 12:11:43 --> Config Class Initialized
INFO - 2025-05-01 12:11:43 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:43 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:43 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:43 --> URI Class Initialized
INFO - 2025-05-01 12:11:43 --> Router Class Initialized
INFO - 2025-05-01 12:11:43 --> Output Class Initialized
INFO - 2025-05-01 12:11:43 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:43 --> Input Class Initialized
INFO - 2025-05-01 12:11:43 --> Language Class Initialized
INFO - 2025-05-01 12:11:43 --> Loader Class Initialized
INFO - 2025-05-01 12:11:43 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:43 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:43 --> Controller Class Initialized
INFO - 2025-05-01 12:11:43 --> Config Class Initialized
INFO - 2025-05-01 12:11:43 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:43 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:43 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:43 --> URI Class Initialized
INFO - 2025-05-01 12:11:43 --> Router Class Initialized
INFO - 2025-05-01 12:11:43 --> Output Class Initialized
INFO - 2025-05-01 12:11:43 --> Security Class Initialized
DEBUG - 2025-05-01 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:11:43 --> Input Class Initialized
INFO - 2025-05-01 12:11:43 --> Language Class Initialized
INFO - 2025-05-01 12:11:43 --> Loader Class Initialized
INFO - 2025-05-01 12:11:43 --> Helper loaded: url_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: string_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: form_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: file_helper
INFO - 2025-05-01 12:11:43 --> Helper loaded: html_helper
INFO - 2025-05-01 12:11:43 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:11:43 --> Controller Class Initialized
INFO - 2025-05-01 20:11:43 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:11:45 --> Config Class Initialized
INFO - 2025-05-01 12:11:45 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:11:45 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:11:45 --> Utf8 Class Initialized
INFO - 2025-05-01 12:11:45 --> URI Class Initialized
INFO - 2025-05-01 12:11:45 --> Router Class Initialized
ERROR - 2025-05-01 20:11:45 --> Query error: Unknown column 'a.id' in 'where clause' - Invalid query: SELECT `asr`.`auction_type_id` as `auction_type_id`
FROM `tbl_auction_status_relationship` `asr`
WHERE `a`.`id` = 13
INFO - 2025-05-01 20:11:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-01 12:12:17 --> Config Class Initialized
INFO - 2025-05-01 12:12:17 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:12:17 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:12:17 --> Utf8 Class Initialized
INFO - 2025-05-01 12:12:17 --> URI Class Initialized
INFO - 2025-05-01 12:12:17 --> Router Class Initialized
INFO - 2025-05-01 12:12:17 --> Output Class Initialized
INFO - 2025-05-01 12:12:17 --> Security Class Initialized
DEBUG - 2025-05-01 12:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:12:17 --> Input Class Initialized
INFO - 2025-05-01 12:12:17 --> Language Class Initialized
INFO - 2025-05-01 12:12:18 --> Loader Class Initialized
INFO - 2025-05-01 12:12:18 --> Helper loaded: url_helper
INFO - 2025-05-01 12:12:18 --> Helper loaded: string_helper
INFO - 2025-05-01 12:12:18 --> Helper loaded: form_helper
INFO - 2025-05-01 12:12:18 --> Helper loaded: file_helper
INFO - 2025-05-01 12:12:18 --> Helper loaded: html_helper
INFO - 2025-05-01 12:12:18 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:12:18 --> Controller Class Initialized
INFO - 2025-05-01 20:12:18 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:12:50 --> Config Class Initialized
INFO - 2025-05-01 12:12:50 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:12:50 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:12:50 --> Utf8 Class Initialized
INFO - 2025-05-01 12:12:50 --> URI Class Initialized
INFO - 2025-05-01 12:12:50 --> Router Class Initialized
INFO - 2025-05-01 12:12:50 --> Output Class Initialized
INFO - 2025-05-01 12:12:50 --> Security Class Initialized
DEBUG - 2025-05-01 12:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:12:50 --> Input Class Initialized
INFO - 2025-05-01 12:12:50 --> Language Class Initialized
INFO - 2025-05-01 12:12:50 --> Loader Class Initialized
INFO - 2025-05-01 12:12:50 --> Helper loaded: url_helper
INFO - 2025-05-01 12:12:50 --> Helper loaded: string_helper
INFO - 2025-05-01 12:12:50 --> Helper loaded: form_helper
INFO - 2025-05-01 12:12:50 --> Helper loaded: file_helper
INFO - 2025-05-01 12:12:50 --> Helper loaded: html_helper
INFO - 2025-05-01 12:12:50 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:12:50 --> Controller Class Initialized
INFO - 2025-05-01 20:12:50 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:13:18 --> Config Class Initialized
INFO - 2025-05-01 12:13:18 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:13:18 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:13:18 --> Utf8 Class Initialized
INFO - 2025-05-01 12:13:18 --> URI Class Initialized
INFO - 2025-05-01 12:13:18 --> Router Class Initialized
INFO - 2025-05-01 12:13:18 --> Output Class Initialized
INFO - 2025-05-01 12:13:18 --> Security Class Initialized
DEBUG - 2025-05-01 12:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:13:18 --> Input Class Initialized
INFO - 2025-05-01 12:13:18 --> Language Class Initialized
INFO - 2025-05-01 12:13:18 --> Loader Class Initialized
INFO - 2025-05-01 12:13:18 --> Helper loaded: url_helper
INFO - 2025-05-01 12:13:18 --> Helper loaded: string_helper
INFO - 2025-05-01 12:13:18 --> Helper loaded: form_helper
INFO - 2025-05-01 12:13:18 --> Helper loaded: file_helper
INFO - 2025-05-01 12:13:18 --> Helper loaded: html_helper
INFO - 2025-05-01 12:13:18 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:13:18 --> Controller Class Initialized
INFO - 2025-05-01 20:13:18 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:13:22 --> Config Class Initialized
INFO - 2025-05-01 12:13:22 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:13:22 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:13:22 --> Utf8 Class Initialized
INFO - 2025-05-01 12:13:22 --> URI Class Initialized
INFO - 2025-05-01 12:13:22 --> Router Class Initialized
INFO - 2025-05-01 12:13:22 --> Output Class Initialized
INFO - 2025-05-01 12:13:22 --> Security Class Initialized
DEBUG - 2025-05-01 12:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:13:22 --> Input Class Initialized
INFO - 2025-05-01 12:13:22 --> Language Class Initialized
INFO - 2025-05-01 12:13:22 --> Loader Class Initialized
INFO - 2025-05-01 12:13:22 --> Helper loaded: url_helper
INFO - 2025-05-01 12:13:22 --> Helper loaded: string_helper
INFO - 2025-05-01 12:13:22 --> Helper loaded: form_helper
INFO - 2025-05-01 12:13:22 --> Helper loaded: file_helper
INFO - 2025-05-01 12:13:22 --> Helper loaded: html_helper
INFO - 2025-05-01 12:13:23 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:13:23 --> Controller Class Initialized
INFO - 2025-05-01 20:13:23 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:13:23 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 12:13:23 --> Config Class Initialized
INFO - 2025-05-01 12:13:23 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:13:23 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:13:23 --> Utf8 Class Initialized
INFO - 2025-05-01 12:13:23 --> URI Class Initialized
INFO - 2025-05-01 12:13:23 --> Router Class Initialized
INFO - 2025-05-01 12:13:23 --> Output Class Initialized
INFO - 2025-05-01 12:13:23 --> Security Class Initialized
DEBUG - 2025-05-01 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:13:23 --> Input Class Initialized
INFO - 2025-05-01 12:13:23 --> Language Class Initialized
INFO - 2025-05-01 12:13:23 --> Loader Class Initialized
INFO - 2025-05-01 12:13:23 --> Helper loaded: url_helper
INFO - 2025-05-01 12:13:23 --> Helper loaded: string_helper
INFO - 2025-05-01 12:13:23 --> Helper loaded: form_helper
INFO - 2025-05-01 12:13:23 --> Helper loaded: file_helper
INFO - 2025-05-01 12:13:23 --> Helper loaded: html_helper
INFO - 2025-05-01 12:13:23 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:13:23 --> Controller Class Initialized
INFO - 2025-05-01 20:13:23 --> Model "EmailQueueModel" initialized
DEBUG - 2025-05-01 20:13:23 --> PHPMailer class is loaded.
INFO - 2025-05-01 20:13:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
DEBUG - 2025-05-01 20:13:29 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-05-01 20:13:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
INFO - 2025-05-01 20:13:33 --> Final output sent to browser
DEBUG - 2025-05-01 20:13:33 --> Total execution time: 10.3070
INFO - 2025-05-01 12:15:21 --> Config Class Initialized
INFO - 2025-05-01 12:15:21 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:15:21 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:15:21 --> Utf8 Class Initialized
INFO - 2025-05-01 12:15:21 --> URI Class Initialized
INFO - 2025-05-01 12:15:21 --> Router Class Initialized
INFO - 2025-05-01 12:15:21 --> Output Class Initialized
INFO - 2025-05-01 12:15:21 --> Security Class Initialized
DEBUG - 2025-05-01 12:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:15:21 --> Input Class Initialized
INFO - 2025-05-01 12:15:21 --> Language Class Initialized
INFO - 2025-05-01 12:15:21 --> Loader Class Initialized
INFO - 2025-05-01 12:15:21 --> Helper loaded: url_helper
INFO - 2025-05-01 12:15:21 --> Helper loaded: string_helper
INFO - 2025-05-01 12:15:21 --> Helper loaded: form_helper
INFO - 2025-05-01 12:15:21 --> Helper loaded: file_helper
INFO - 2025-05-01 12:15:21 --> Helper loaded: html_helper
INFO - 2025-05-01 12:15:21 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:15:21 --> Controller Class Initialized
INFO - 2025-05-01 20:15:21 --> Model "AuctionModel" initialized
INFO - 2025-05-01 12:15:24 --> Config Class Initialized
INFO - 2025-05-01 12:15:24 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:15:24 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:15:24 --> Utf8 Class Initialized
INFO - 2025-05-01 12:15:24 --> URI Class Initialized
INFO - 2025-05-01 12:15:24 --> Router Class Initialized
INFO - 2025-05-01 12:15:24 --> Output Class Initialized
INFO - 2025-05-01 12:15:24 --> Security Class Initialized
DEBUG - 2025-05-01 12:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:15:24 --> Input Class Initialized
INFO - 2025-05-01 12:15:24 --> Language Class Initialized
INFO - 2025-05-01 12:15:24 --> Loader Class Initialized
INFO - 2025-05-01 12:15:24 --> Helper loaded: url_helper
INFO - 2025-05-01 12:15:24 --> Helper loaded: string_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: form_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: file_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: html_helper
INFO - 2025-05-01 12:15:25 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:15:25 --> Controller Class Initialized
INFO - 2025-05-01 20:15:25 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:15:25 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 12:15:25 --> Config Class Initialized
INFO - 2025-05-01 12:15:25 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:15:25 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:15:25 --> Utf8 Class Initialized
INFO - 2025-05-01 12:15:25 --> URI Class Initialized
INFO - 2025-05-01 12:15:25 --> Router Class Initialized
INFO - 2025-05-01 12:15:25 --> Output Class Initialized
INFO - 2025-05-01 12:15:25 --> Security Class Initialized
DEBUG - 2025-05-01 12:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:15:25 --> Input Class Initialized
INFO - 2025-05-01 12:15:25 --> Language Class Initialized
INFO - 2025-05-01 12:15:25 --> Loader Class Initialized
INFO - 2025-05-01 12:15:25 --> Helper loaded: url_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: string_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: form_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: file_helper
INFO - 2025-05-01 12:15:25 --> Helper loaded: html_helper
INFO - 2025-05-01 12:15:25 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:15:25 --> Controller Class Initialized
INFO - 2025-05-01 20:15:25 --> Model "EmailQueueModel" initialized
DEBUG - 2025-05-01 20:15:25 --> PHPMailer class is loaded.
INFO - 2025-05-01 20:15:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
DEBUG - 2025-05-01 20:15:33 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-05-01 20:15:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
INFO - 2025-05-01 20:15:41 --> Final output sent to browser
DEBUG - 2025-05-01 20:15:41 --> Total execution time: 16.2028
INFO - 2025-05-01 12:19:57 --> Config Class Initialized
INFO - 2025-05-01 12:19:57 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:19:57 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:19:57 --> Utf8 Class Initialized
INFO - 2025-05-01 12:19:57 --> URI Class Initialized
INFO - 2025-05-01 12:19:57 --> Router Class Initialized
INFO - 2025-05-01 12:19:57 --> Output Class Initialized
INFO - 2025-05-01 12:19:57 --> Security Class Initialized
DEBUG - 2025-05-01 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:19:57 --> Input Class Initialized
INFO - 2025-05-01 12:19:57 --> Language Class Initialized
INFO - 2025-05-01 12:19:57 --> Loader Class Initialized
INFO - 2025-05-01 12:19:57 --> Helper loaded: url_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: string_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: form_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: file_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: html_helper
INFO - 2025-05-01 12:19:57 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:19:57 --> Controller Class Initialized
INFO - 2025-05-01 20:19:57 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:19:57 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 12:19:57 --> Config Class Initialized
INFO - 2025-05-01 12:19:57 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:19:57 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:19:57 --> Utf8 Class Initialized
INFO - 2025-05-01 12:19:57 --> URI Class Initialized
INFO - 2025-05-01 12:19:57 --> Router Class Initialized
INFO - 2025-05-01 12:19:57 --> Output Class Initialized
INFO - 2025-05-01 12:19:57 --> Security Class Initialized
DEBUG - 2025-05-01 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:19:57 --> Input Class Initialized
INFO - 2025-05-01 12:19:57 --> Language Class Initialized
INFO - 2025-05-01 12:19:57 --> Loader Class Initialized
INFO - 2025-05-01 12:19:57 --> Helper loaded: url_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: string_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: form_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: file_helper
INFO - 2025-05-01 12:19:57 --> Helper loaded: html_helper
INFO - 2025-05-01 12:19:57 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:19:58 --> Controller Class Initialized
INFO - 2025-05-01 20:19:58 --> Model "EmailQueueModel" initialized
DEBUG - 2025-05-01 20:19:58 --> PHPMailer class is loaded.
INFO - 2025-05-01 20:19:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
DEBUG - 2025-05-01 20:20:10 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-05-01 20:20:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
INFO - 2025-05-01 20:20:20 --> Final output sent to browser
DEBUG - 2025-05-01 20:20:20 --> Total execution time: 22.1683
INFO - 2025-05-01 12:28:32 --> Config Class Initialized
INFO - 2025-05-01 12:28:32 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:28:33 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:28:33 --> Utf8 Class Initialized
INFO - 2025-05-01 12:28:33 --> URI Class Initialized
INFO - 2025-05-01 12:28:33 --> Router Class Initialized
INFO - 2025-05-01 12:28:33 --> Output Class Initialized
INFO - 2025-05-01 12:28:33 --> Security Class Initialized
DEBUG - 2025-05-01 12:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:28:33 --> Input Class Initialized
INFO - 2025-05-01 12:28:33 --> Language Class Initialized
INFO - 2025-05-01 12:28:33 --> Loader Class Initialized
INFO - 2025-05-01 12:28:33 --> Helper loaded: url_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: string_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: form_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: file_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: html_helper
INFO - 2025-05-01 12:28:33 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:28:33 --> Controller Class Initialized
INFO - 2025-05-01 20:28:33 --> Model "AuctionModel" initialized
INFO - 2025-05-01 20:28:33 --> Model "EmailQueueModel" initialized
INFO - 2025-05-01 12:28:33 --> Config Class Initialized
INFO - 2025-05-01 12:28:33 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:28:33 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:28:33 --> Utf8 Class Initialized
INFO - 2025-05-01 12:28:33 --> URI Class Initialized
INFO - 2025-05-01 12:28:33 --> Router Class Initialized
INFO - 2025-05-01 12:28:33 --> Output Class Initialized
INFO - 2025-05-01 12:28:33 --> Security Class Initialized
DEBUG - 2025-05-01 12:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:28:33 --> Input Class Initialized
INFO - 2025-05-01 12:28:33 --> Language Class Initialized
INFO - 2025-05-01 12:28:33 --> Loader Class Initialized
INFO - 2025-05-01 12:28:33 --> Helper loaded: url_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: string_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: form_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: file_helper
INFO - 2025-05-01 12:28:33 --> Helper loaded: html_helper
INFO - 2025-05-01 12:28:33 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:28:33 --> Controller Class Initialized
INFO - 2025-05-01 20:28:33 --> Model "EmailQueueModel" initialized
DEBUG - 2025-05-01 20:28:33 --> PHPMailer class is loaded.
INFO - 2025-05-01 20:28:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
DEBUG - 2025-05-01 20:28:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-05-01 20:28:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/auction_outbid_email.php
INFO - 2025-05-01 20:28:53 --> Final output sent to browser
DEBUG - 2025-05-01 20:28:53 --> Total execution time: 20.2613
INFO - 2025-05-01 12:36:12 --> Config Class Initialized
INFO - 2025-05-01 12:36:12 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:36:12 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:36:12 --> Utf8 Class Initialized
INFO - 2025-05-01 12:36:12 --> URI Class Initialized
INFO - 2025-05-01 12:36:12 --> Router Class Initialized
INFO - 2025-05-01 12:36:12 --> Output Class Initialized
INFO - 2025-05-01 12:36:12 --> Security Class Initialized
DEBUG - 2025-05-01 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:36:12 --> Input Class Initialized
INFO - 2025-05-01 12:36:12 --> Language Class Initialized
INFO - 2025-05-01 12:36:12 --> Loader Class Initialized
INFO - 2025-05-01 12:36:12 --> Helper loaded: url_helper
INFO - 2025-05-01 12:36:12 --> Helper loaded: string_helper
INFO - 2025-05-01 12:36:12 --> Helper loaded: form_helper
INFO - 2025-05-01 12:36:12 --> Helper loaded: file_helper
INFO - 2025-05-01 12:36:12 --> Helper loaded: html_helper
INFO - 2025-05-01 12:36:12 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:36:12 --> Controller Class Initialized
INFO - 2025-05-01 12:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 12:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 12:36:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-01 12:36:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 12:36:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 12:36:13 --> Final output sent to browser
DEBUG - 2025-05-01 12:36:13 --> Total execution time: 0.3020
INFO - 2025-05-01 12:36:14 --> Config Class Initialized
INFO - 2025-05-01 12:36:14 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:36:14 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:36:14 --> Utf8 Class Initialized
INFO - 2025-05-01 12:36:14 --> URI Class Initialized
INFO - 2025-05-01 12:36:14 --> Router Class Initialized
INFO - 2025-05-01 12:36:14 --> Output Class Initialized
INFO - 2025-05-01 12:36:14 --> Security Class Initialized
DEBUG - 2025-05-01 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:36:14 --> Input Class Initialized
INFO - 2025-05-01 12:36:14 --> Language Class Initialized
INFO - 2025-05-01 12:36:14 --> Loader Class Initialized
INFO - 2025-05-01 12:36:14 --> Helper loaded: url_helper
INFO - 2025-05-01 12:36:14 --> Helper loaded: string_helper
INFO - 2025-05-01 12:36:14 --> Helper loaded: form_helper
INFO - 2025-05-01 12:36:14 --> Helper loaded: file_helper
INFO - 2025-05-01 12:36:14 --> Helper loaded: html_helper
INFO - 2025-05-01 12:36:14 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:36:14 --> Controller Class Initialized
INFO - 2025-05-01 20:36:14 --> Model "UserModel" initialized
INFO - 2025-05-01 20:36:15 --> Final output sent to browser
DEBUG - 2025-05-01 20:36:15 --> Total execution time: 0.2702
INFO - 2025-05-01 12:36:22 --> Config Class Initialized
INFO - 2025-05-01 12:36:22 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:36:22 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:36:22 --> Utf8 Class Initialized
INFO - 2025-05-01 12:36:22 --> URI Class Initialized
INFO - 2025-05-01 12:36:22 --> Router Class Initialized
INFO - 2025-05-01 12:36:22 --> Output Class Initialized
INFO - 2025-05-01 12:36:22 --> Security Class Initialized
DEBUG - 2025-05-01 12:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:36:22 --> Input Class Initialized
INFO - 2025-05-01 12:36:22 --> Language Class Initialized
INFO - 2025-05-01 12:36:22 --> Loader Class Initialized
INFO - 2025-05-01 12:36:22 --> Helper loaded: url_helper
INFO - 2025-05-01 12:36:22 --> Helper loaded: string_helper
INFO - 2025-05-01 12:36:22 --> Helper loaded: form_helper
INFO - 2025-05-01 12:36:22 --> Helper loaded: file_helper
INFO - 2025-05-01 12:36:22 --> Helper loaded: html_helper
INFO - 2025-05-01 12:36:22 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:36:22 --> Controller Class Initialized
INFO - 2025-05-01 20:36:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:36:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:36:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 20:36:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:36:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:36:22 --> Final output sent to browser
DEBUG - 2025-05-01 20:36:22 --> Total execution time: 0.3226
INFO - 2025-05-01 12:36:42 --> Config Class Initialized
INFO - 2025-05-01 12:36:42 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:36:42 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:36:42 --> Utf8 Class Initialized
INFO - 2025-05-01 12:36:42 --> URI Class Initialized
INFO - 2025-05-01 12:36:42 --> Router Class Initialized
INFO - 2025-05-01 12:36:42 --> Output Class Initialized
INFO - 2025-05-01 12:36:42 --> Security Class Initialized
DEBUG - 2025-05-01 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:36:42 --> Input Class Initialized
INFO - 2025-05-01 12:36:42 --> Language Class Initialized
INFO - 2025-05-01 12:36:42 --> Loader Class Initialized
INFO - 2025-05-01 12:36:42 --> Helper loaded: url_helper
INFO - 2025-05-01 12:36:42 --> Helper loaded: string_helper
INFO - 2025-05-01 12:36:42 --> Helper loaded: form_helper
INFO - 2025-05-01 12:36:42 --> Helper loaded: file_helper
INFO - 2025-05-01 12:36:42 --> Helper loaded: html_helper
INFO - 2025-05-01 12:36:42 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:36:42 --> Controller Class Initialized
INFO - 2025-05-01 12:36:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 12:36:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 12:36:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-01 12:36:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 12:36:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 12:36:42 --> Final output sent to browser
DEBUG - 2025-05-01 12:36:42 --> Total execution time: 0.1877
INFO - 2025-05-01 12:36:44 --> Config Class Initialized
INFO - 2025-05-01 12:36:44 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:36:44 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:36:44 --> Utf8 Class Initialized
INFO - 2025-05-01 12:36:44 --> URI Class Initialized
INFO - 2025-05-01 12:36:44 --> Router Class Initialized
INFO - 2025-05-01 12:36:44 --> Output Class Initialized
INFO - 2025-05-01 12:36:44 --> Security Class Initialized
DEBUG - 2025-05-01 12:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:36:44 --> Input Class Initialized
INFO - 2025-05-01 12:36:44 --> Language Class Initialized
INFO - 2025-05-01 12:36:44 --> Loader Class Initialized
INFO - 2025-05-01 12:36:44 --> Helper loaded: url_helper
INFO - 2025-05-01 12:36:44 --> Helper loaded: string_helper
INFO - 2025-05-01 12:36:44 --> Helper loaded: form_helper
INFO - 2025-05-01 12:36:44 --> Helper loaded: file_helper
INFO - 2025-05-01 12:36:44 --> Helper loaded: html_helper
INFO - 2025-05-01 12:36:44 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:36:44 --> Controller Class Initialized
INFO - 2025-05-01 20:36:44 --> Model "UserModel" initialized
INFO - 2025-05-01 20:36:44 --> Final output sent to browser
DEBUG - 2025-05-01 20:36:44 --> Total execution time: 0.1832
INFO - 2025-05-01 12:38:32 --> Config Class Initialized
INFO - 2025-05-01 12:38:32 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:38:32 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:38:32 --> Utf8 Class Initialized
INFO - 2025-05-01 12:38:32 --> URI Class Initialized
INFO - 2025-05-01 12:38:32 --> Router Class Initialized
INFO - 2025-05-01 12:38:32 --> Output Class Initialized
INFO - 2025-05-01 12:38:32 --> Security Class Initialized
DEBUG - 2025-05-01 12:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:38:32 --> Input Class Initialized
INFO - 2025-05-01 12:38:32 --> Language Class Initialized
INFO - 2025-05-01 12:38:32 --> Loader Class Initialized
INFO - 2025-05-01 12:38:32 --> Helper loaded: url_helper
INFO - 2025-05-01 12:38:32 --> Helper loaded: string_helper
INFO - 2025-05-01 12:38:32 --> Helper loaded: form_helper
INFO - 2025-05-01 12:38:32 --> Helper loaded: file_helper
INFO - 2025-05-01 12:38:32 --> Helper loaded: html_helper
INFO - 2025-05-01 12:38:32 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:38:32 --> Controller Class Initialized
INFO - 2025-05-01 20:38:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:38:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:38:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 20:38:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:38:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:38:32 --> Final output sent to browser
DEBUG - 2025-05-01 20:38:32 --> Total execution time: 0.1657
INFO - 2025-05-01 12:39:11 --> Config Class Initialized
INFO - 2025-05-01 12:39:11 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:39:11 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:39:11 --> Utf8 Class Initialized
INFO - 2025-05-01 12:39:11 --> URI Class Initialized
INFO - 2025-05-01 12:39:11 --> Router Class Initialized
INFO - 2025-05-01 12:39:11 --> Output Class Initialized
INFO - 2025-05-01 12:39:11 --> Security Class Initialized
DEBUG - 2025-05-01 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:39:11 --> Input Class Initialized
INFO - 2025-05-01 12:39:11 --> Language Class Initialized
INFO - 2025-05-01 12:39:11 --> Loader Class Initialized
INFO - 2025-05-01 12:39:11 --> Helper loaded: url_helper
INFO - 2025-05-01 12:39:11 --> Helper loaded: string_helper
INFO - 2025-05-01 12:39:11 --> Helper loaded: form_helper
INFO - 2025-05-01 12:39:11 --> Helper loaded: file_helper
INFO - 2025-05-01 12:39:11 --> Helper loaded: html_helper
INFO - 2025-05-01 12:39:11 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:39:11 --> Controller Class Initialized
INFO - 2025-05-01 20:39:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:39:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:39:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 20:39:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:39:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:39:11 --> Final output sent to browser
DEBUG - 2025-05-01 20:39:11 --> Total execution time: 0.1457
INFO - 2025-05-01 12:43:09 --> Config Class Initialized
INFO - 2025-05-01 12:43:09 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:43:09 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:43:09 --> Utf8 Class Initialized
INFO - 2025-05-01 12:43:09 --> URI Class Initialized
INFO - 2025-05-01 12:43:09 --> Router Class Initialized
INFO - 2025-05-01 12:43:09 --> Output Class Initialized
INFO - 2025-05-01 12:43:09 --> Security Class Initialized
DEBUG - 2025-05-01 12:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:43:09 --> Input Class Initialized
INFO - 2025-05-01 12:43:09 --> Language Class Initialized
ERROR - 2025-05-01 12:43:09 --> Severity: error --> Exception: Unclosed '{' on line 23 does not match ')' C:\xampp\htdocs\storage_auctions\application\controllers\Auth.php 32
INFO - 2025-05-01 12:43:28 --> Config Class Initialized
INFO - 2025-05-01 12:43:28 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:43:28 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:43:28 --> Utf8 Class Initialized
INFO - 2025-05-01 12:43:28 --> URI Class Initialized
INFO - 2025-05-01 12:43:28 --> Router Class Initialized
INFO - 2025-05-01 12:43:28 --> Output Class Initialized
INFO - 2025-05-01 12:43:28 --> Security Class Initialized
DEBUG - 2025-05-01 12:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:43:28 --> Input Class Initialized
INFO - 2025-05-01 12:43:28 --> Language Class Initialized
INFO - 2025-05-01 12:43:28 --> Loader Class Initialized
INFO - 2025-05-01 12:43:28 --> Helper loaded: url_helper
INFO - 2025-05-01 12:43:28 --> Helper loaded: string_helper
INFO - 2025-05-01 12:43:28 --> Helper loaded: form_helper
INFO - 2025-05-01 12:43:28 --> Helper loaded: file_helper
INFO - 2025-05-01 12:43:28 --> Helper loaded: html_helper
INFO - 2025-05-01 12:43:28 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:43:28 --> Controller Class Initialized
INFO - 2025-05-01 20:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 20:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:43:28 --> Final output sent to browser
DEBUG - 2025-05-01 20:43:28 --> Total execution time: 0.3404
INFO - 2025-05-01 12:43:28 --> Config Class Initialized
INFO - 2025-05-01 12:43:28 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:43:28 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:43:28 --> Utf8 Class Initialized
INFO - 2025-05-01 12:43:28 --> URI Class Initialized
INFO - 2025-05-01 12:43:29 --> Router Class Initialized
INFO - 2025-05-01 12:43:29 --> Output Class Initialized
INFO - 2025-05-01 12:43:29 --> Security Class Initialized
DEBUG - 2025-05-01 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:43:29 --> Input Class Initialized
INFO - 2025-05-01 12:43:29 --> Language Class Initialized
ERROR - 2025-05-01 12:43:29 --> 404 Page Not Found: Assets/js
INFO - 2025-05-01 12:43:30 --> Config Class Initialized
INFO - 2025-05-01 12:43:30 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:43:30 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:43:30 --> Utf8 Class Initialized
INFO - 2025-05-01 12:43:30 --> URI Class Initialized
INFO - 2025-05-01 12:43:30 --> Router Class Initialized
INFO - 2025-05-01 12:43:30 --> Output Class Initialized
INFO - 2025-05-01 12:43:30 --> Security Class Initialized
DEBUG - 2025-05-01 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:43:30 --> Input Class Initialized
INFO - 2025-05-01 12:43:30 --> Language Class Initialized
ERROR - 2025-05-01 12:43:30 --> 404 Page Not Found: Assets/js
INFO - 2025-05-01 12:44:23 --> Config Class Initialized
INFO - 2025-05-01 12:44:23 --> Hooks Class Initialized
DEBUG - 2025-05-01 12:44:23 --> UTF-8 Support Enabled
INFO - 2025-05-01 12:44:23 --> Utf8 Class Initialized
INFO - 2025-05-01 12:44:23 --> URI Class Initialized
INFO - 2025-05-01 12:44:23 --> Router Class Initialized
INFO - 2025-05-01 12:44:23 --> Output Class Initialized
INFO - 2025-05-01 12:44:23 --> Security Class Initialized
DEBUG - 2025-05-01 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 12:44:23 --> Input Class Initialized
INFO - 2025-05-01 12:44:23 --> Language Class Initialized
INFO - 2025-05-01 12:44:23 --> Loader Class Initialized
INFO - 2025-05-01 12:44:23 --> Helper loaded: url_helper
INFO - 2025-05-01 12:44:23 --> Helper loaded: string_helper
INFO - 2025-05-01 12:44:23 --> Helper loaded: form_helper
INFO - 2025-05-01 12:44:23 --> Helper loaded: file_helper
INFO - 2025-05-01 12:44:23 --> Helper loaded: html_helper
INFO - 2025-05-01 12:44:23 --> Database Driver Class Initialized
DEBUG - 2025-05-01 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 12:44:23 --> Controller Class Initialized
INFO - 2025-05-01 20:44:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 20:44:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 20:44:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 20:44:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 20:44:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 20:44:23 --> Final output sent to browser
DEBUG - 2025-05-01 20:44:23 --> Total execution time: 0.2328
INFO - 2025-05-01 13:36:06 --> Config Class Initialized
INFO - 2025-05-01 13:36:06 --> Hooks Class Initialized
DEBUG - 2025-05-01 13:36:06 --> UTF-8 Support Enabled
INFO - 2025-05-01 13:36:06 --> Utf8 Class Initialized
INFO - 2025-05-01 13:36:06 --> URI Class Initialized
INFO - 2025-05-01 13:36:06 --> Router Class Initialized
INFO - 2025-05-01 13:36:06 --> Output Class Initialized
INFO - 2025-05-01 13:36:06 --> Security Class Initialized
DEBUG - 2025-05-01 13:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 13:36:06 --> Input Class Initialized
INFO - 2025-05-01 13:36:06 --> Language Class Initialized
INFO - 2025-05-01 13:36:06 --> Loader Class Initialized
INFO - 2025-05-01 13:36:06 --> Helper loaded: url_helper
INFO - 2025-05-01 13:36:06 --> Helper loaded: string_helper
INFO - 2025-05-01 13:36:06 --> Helper loaded: form_helper
INFO - 2025-05-01 13:36:06 --> Helper loaded: file_helper
INFO - 2025-05-01 13:36:06 --> Helper loaded: html_helper
INFO - 2025-05-01 13:36:06 --> Database Driver Class Initialized
DEBUG - 2025-05-01 13:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 13:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 13:36:06 --> Controller Class Initialized
INFO - 2025-05-01 21:36:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 21:36:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 21:36:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-01 21:36:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 21:36:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 21:36:06 --> Final output sent to browser
DEBUG - 2025-05-01 21:36:06 --> Total execution time: 0.2726
INFO - 2025-05-01 13:36:26 --> Config Class Initialized
INFO - 2025-05-01 13:36:26 --> Hooks Class Initialized
DEBUG - 2025-05-01 13:36:26 --> UTF-8 Support Enabled
INFO - 2025-05-01 13:36:26 --> Utf8 Class Initialized
INFO - 2025-05-01 13:36:26 --> URI Class Initialized
INFO - 2025-05-01 13:36:26 --> Router Class Initialized
INFO - 2025-05-01 13:36:26 --> Output Class Initialized
INFO - 2025-05-01 13:36:26 --> Security Class Initialized
DEBUG - 2025-05-01 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 13:36:26 --> Input Class Initialized
INFO - 2025-05-01 13:36:26 --> Language Class Initialized
INFO - 2025-05-01 13:36:26 --> Loader Class Initialized
INFO - 2025-05-01 13:36:26 --> Helper loaded: url_helper
INFO - 2025-05-01 13:36:26 --> Helper loaded: string_helper
INFO - 2025-05-01 13:36:26 --> Helper loaded: form_helper
INFO - 2025-05-01 13:36:26 --> Helper loaded: file_helper
INFO - 2025-05-01 13:36:26 --> Helper loaded: html_helper
INFO - 2025-05-01 13:36:26 --> Database Driver Class Initialized
DEBUG - 2025-05-01 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 13:36:26 --> Controller Class Initialized
INFO - 2025-05-01 21:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-01 21:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-01 21:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-01 21:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-01 21:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-01 21:36:26 --> Final output sent to browser
DEBUG - 2025-05-01 21:36:26 --> Total execution time: 0.1985
INFO - 2025-05-01 21:51:24 --> Config Class Initialized
INFO - 2025-05-01 21:51:24 --> Hooks Class Initialized
DEBUG - 2025-05-01 21:51:24 --> UTF-8 Support Enabled
INFO - 2025-05-01 21:51:24 --> Utf8 Class Initialized
INFO - 2025-05-01 21:51:24 --> URI Class Initialized
INFO - 2025-05-01 21:51:24 --> Router Class Initialized
INFO - 2025-05-01 21:51:24 --> Output Class Initialized
INFO - 2025-05-01 21:51:24 --> Security Class Initialized
DEBUG - 2025-05-01 21:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 21:51:24 --> Input Class Initialized
INFO - 2025-05-01 21:51:24 --> Language Class Initialized
INFO - 2025-05-01 21:51:24 --> Loader Class Initialized
INFO - 2025-05-01 21:51:24 --> Helper loaded: url_helper
INFO - 2025-05-01 21:51:24 --> Helper loaded: string_helper
INFO - 2025-05-01 21:51:24 --> Helper loaded: form_helper
INFO - 2025-05-01 21:51:24 --> Helper loaded: file_helper
INFO - 2025-05-01 21:51:24 --> Helper loaded: html_helper
INFO - 2025-05-01 21:51:24 --> Database Driver Class Initialized
DEBUG - 2025-05-01 21:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 21:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 21:51:24 --> Controller Class Initialized
INFO - 2025-05-01 21:51:31 --> Config Class Initialized
INFO - 2025-05-01 21:51:31 --> Hooks Class Initialized
DEBUG - 2025-05-01 21:51:31 --> UTF-8 Support Enabled
INFO - 2025-05-01 21:51:31 --> Utf8 Class Initialized
INFO - 2025-05-01 21:51:31 --> URI Class Initialized
INFO - 2025-05-01 21:51:31 --> Router Class Initialized
INFO - 2025-05-01 21:51:31 --> Output Class Initialized
INFO - 2025-05-01 21:51:31 --> Security Class Initialized
DEBUG - 2025-05-01 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 21:51:31 --> Input Class Initialized
INFO - 2025-05-01 21:51:31 --> Language Class Initialized
INFO - 2025-05-01 21:51:31 --> Loader Class Initialized
INFO - 2025-05-01 21:51:31 --> Helper loaded: url_helper
INFO - 2025-05-01 21:51:31 --> Helper loaded: string_helper
INFO - 2025-05-01 21:51:31 --> Helper loaded: form_helper
INFO - 2025-05-01 21:51:31 --> Helper loaded: file_helper
INFO - 2025-05-01 21:51:31 --> Helper loaded: html_helper
INFO - 2025-05-01 21:51:31 --> Database Driver Class Initialized
DEBUG - 2025-05-01 21:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 21:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 21:51:31 --> Controller Class Initialized
INFO - 2025-05-01 21:51:34 --> Config Class Initialized
INFO - 2025-05-01 21:51:34 --> Hooks Class Initialized
DEBUG - 2025-05-01 21:51:34 --> UTF-8 Support Enabled
INFO - 2025-05-01 21:51:34 --> Utf8 Class Initialized
INFO - 2025-05-01 21:51:34 --> URI Class Initialized
INFO - 2025-05-01 21:51:34 --> Router Class Initialized
INFO - 2025-05-01 21:51:34 --> Output Class Initialized
INFO - 2025-05-01 21:51:34 --> Security Class Initialized
DEBUG - 2025-05-01 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-01 21:51:34 --> Input Class Initialized
INFO - 2025-05-01 21:51:34 --> Language Class Initialized
INFO - 2025-05-01 21:51:34 --> Loader Class Initialized
INFO - 2025-05-01 21:51:34 --> Helper loaded: url_helper
INFO - 2025-05-01 21:51:34 --> Helper loaded: string_helper
INFO - 2025-05-01 21:51:34 --> Helper loaded: form_helper
INFO - 2025-05-01 21:51:34 --> Helper loaded: file_helper
INFO - 2025-05-01 21:51:34 --> Helper loaded: html_helper
INFO - 2025-05-01 21:51:34 --> Database Driver Class Initialized
DEBUG - 2025-05-01 21:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-01 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-01 21:51:34 --> Controller Class Initialized
