<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-03 09:55:55 --> Config Class Initialized
INFO - 2025-05-03 09:55:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:55:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:55:56 --> Utf8 Class Initialized
INFO - 2025-05-03 09:55:56 --> URI Class Initialized
INFO - 2025-05-03 09:55:56 --> Router Class Initialized
INFO - 2025-05-03 09:55:56 --> Output Class Initialized
INFO - 2025-05-03 09:55:56 --> Security Class Initialized
DEBUG - 2025-05-03 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:55:57 --> Input Class Initialized
INFO - 2025-05-03 09:55:57 --> Language Class Initialized
INFO - 2025-05-03 09:55:57 --> Loader Class Initialized
INFO - 2025-05-03 09:55:57 --> Helper loaded: url_helper
INFO - 2025-05-03 09:55:57 --> Helper loaded: string_helper
INFO - 2025-05-03 09:55:57 --> Helper loaded: form_helper
INFO - 2025-05-03 09:55:57 --> Helper loaded: file_helper
INFO - 2025-05-03 09:55:57 --> Helper loaded: html_helper
INFO - 2025-05-03 09:55:58 --> Database Driver Class Initialized
DEBUG - 2025-05-03 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:55:58 --> Controller Class Initialized
INFO - 2025-05-03 17:55:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 17:55:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 17:55:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 17:55:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 17:55:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 17:55:59 --> Final output sent to browser
DEBUG - 2025-05-03 17:55:59 --> Total execution time: 3.9514
INFO - 2025-05-03 10:09:00 --> Config Class Initialized
INFO - 2025-05-03 10:09:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:09:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:09:00 --> Utf8 Class Initialized
INFO - 2025-05-03 10:09:00 --> URI Class Initialized
INFO - 2025-05-03 10:09:00 --> Router Class Initialized
INFO - 2025-05-03 10:09:00 --> Output Class Initialized
INFO - 2025-05-03 10:09:00 --> Security Class Initialized
DEBUG - 2025-05-03 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:09:00 --> Input Class Initialized
INFO - 2025-05-03 10:09:00 --> Language Class Initialized
INFO - 2025-05-03 10:09:00 --> Loader Class Initialized
INFO - 2025-05-03 10:09:00 --> Helper loaded: url_helper
INFO - 2025-05-03 10:09:00 --> Helper loaded: string_helper
INFO - 2025-05-03 10:09:00 --> Helper loaded: form_helper
INFO - 2025-05-03 10:09:00 --> Helper loaded: file_helper
INFO - 2025-05-03 10:09:00 --> Helper loaded: html_helper
INFO - 2025-05-03 10:09:00 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:09:00 --> Controller Class Initialized
INFO - 2025-05-03 18:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:09:00 --> Final output sent to browser
DEBUG - 2025-05-03 18:09:00 --> Total execution time: 0.4481
INFO - 2025-05-03 10:14:26 --> Config Class Initialized
INFO - 2025-05-03 10:14:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:14:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:14:26 --> Utf8 Class Initialized
INFO - 2025-05-03 10:14:26 --> URI Class Initialized
INFO - 2025-05-03 10:14:26 --> Router Class Initialized
INFO - 2025-05-03 10:14:26 --> Output Class Initialized
INFO - 2025-05-03 10:14:26 --> Security Class Initialized
DEBUG - 2025-05-03 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:14:26 --> Input Class Initialized
INFO - 2025-05-03 10:14:26 --> Language Class Initialized
INFO - 2025-05-03 10:14:26 --> Loader Class Initialized
INFO - 2025-05-03 10:14:26 --> Helper loaded: url_helper
INFO - 2025-05-03 10:14:26 --> Helper loaded: string_helper
INFO - 2025-05-03 10:14:26 --> Helper loaded: form_helper
INFO - 2025-05-03 10:14:26 --> Helper loaded: file_helper
INFO - 2025-05-03 10:14:26 --> Helper loaded: html_helper
INFO - 2025-05-03 10:14:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:14:26 --> Controller Class Initialized
INFO - 2025-05-03 18:14:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:14:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:14:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:14:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:14:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:14:26 --> Final output sent to browser
DEBUG - 2025-05-03 18:14:26 --> Total execution time: 0.1209
INFO - 2025-05-03 10:17:06 --> Config Class Initialized
INFO - 2025-05-03 10:17:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:17:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:17:06 --> Utf8 Class Initialized
INFO - 2025-05-03 10:17:06 --> URI Class Initialized
INFO - 2025-05-03 10:17:06 --> Router Class Initialized
INFO - 2025-05-03 10:17:06 --> Output Class Initialized
INFO - 2025-05-03 10:17:06 --> Security Class Initialized
DEBUG - 2025-05-03 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:17:06 --> Input Class Initialized
INFO - 2025-05-03 10:17:06 --> Language Class Initialized
INFO - 2025-05-03 10:17:06 --> Loader Class Initialized
INFO - 2025-05-03 10:17:06 --> Helper loaded: url_helper
INFO - 2025-05-03 10:17:06 --> Helper loaded: string_helper
INFO - 2025-05-03 10:17:06 --> Helper loaded: form_helper
INFO - 2025-05-03 10:17:06 --> Helper loaded: file_helper
INFO - 2025-05-03 10:17:06 --> Helper loaded: html_helper
INFO - 2025-05-03 10:17:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:17:06 --> Controller Class Initialized
INFO - 2025-05-03 18:17:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:17:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:17:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:17:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:17:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:17:06 --> Final output sent to browser
DEBUG - 2025-05-03 18:17:06 --> Total execution time: 0.2400
INFO - 2025-05-03 10:31:19 --> Config Class Initialized
INFO - 2025-05-03 10:31:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:31:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:31:19 --> Utf8 Class Initialized
INFO - 2025-05-03 10:31:19 --> URI Class Initialized
INFO - 2025-05-03 10:31:19 --> Router Class Initialized
INFO - 2025-05-03 10:31:19 --> Output Class Initialized
INFO - 2025-05-03 10:31:19 --> Security Class Initialized
DEBUG - 2025-05-03 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:31:19 --> Input Class Initialized
INFO - 2025-05-03 10:31:19 --> Language Class Initialized
INFO - 2025-05-03 10:31:19 --> Loader Class Initialized
INFO - 2025-05-03 10:31:19 --> Helper loaded: url_helper
INFO - 2025-05-03 10:31:19 --> Helper loaded: string_helper
INFO - 2025-05-03 10:31:19 --> Helper loaded: form_helper
INFO - 2025-05-03 10:31:19 --> Helper loaded: file_helper
INFO - 2025-05-03 10:31:19 --> Helper loaded: html_helper
INFO - 2025-05-03 10:31:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:31:20 --> Controller Class Initialized
INFO - 2025-05-03 18:31:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:31:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:31:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:31:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:31:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:31:20 --> Final output sent to browser
DEBUG - 2025-05-03 18:31:20 --> Total execution time: 0.1452
INFO - 2025-05-03 10:31:31 --> Config Class Initialized
INFO - 2025-05-03 10:31:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:31:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:31:31 --> Utf8 Class Initialized
INFO - 2025-05-03 10:31:31 --> URI Class Initialized
INFO - 2025-05-03 10:31:31 --> Router Class Initialized
INFO - 2025-05-03 10:31:31 --> Output Class Initialized
INFO - 2025-05-03 10:31:31 --> Security Class Initialized
DEBUG - 2025-05-03 10:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:31:31 --> Input Class Initialized
INFO - 2025-05-03 10:31:31 --> Language Class Initialized
INFO - 2025-05-03 10:31:31 --> Loader Class Initialized
INFO - 2025-05-03 10:31:31 --> Helper loaded: url_helper
INFO - 2025-05-03 10:31:31 --> Helper loaded: string_helper
INFO - 2025-05-03 10:31:31 --> Helper loaded: form_helper
INFO - 2025-05-03 10:31:31 --> Helper loaded: file_helper
INFO - 2025-05-03 10:31:31 --> Helper loaded: html_helper
INFO - 2025-05-03 10:31:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:31:31 --> Controller Class Initialized
INFO - 2025-05-03 18:31:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:31:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:31:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:31:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:31:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:31:31 --> Final output sent to browser
DEBUG - 2025-05-03 18:31:31 --> Total execution time: 0.1367
INFO - 2025-05-03 10:31:46 --> Config Class Initialized
INFO - 2025-05-03 10:31:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:31:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:31:46 --> Utf8 Class Initialized
INFO - 2025-05-03 10:31:46 --> URI Class Initialized
INFO - 2025-05-03 10:31:46 --> Router Class Initialized
INFO - 2025-05-03 10:31:46 --> Output Class Initialized
INFO - 2025-05-03 10:31:46 --> Security Class Initialized
DEBUG - 2025-05-03 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:31:46 --> Input Class Initialized
INFO - 2025-05-03 10:31:46 --> Language Class Initialized
INFO - 2025-05-03 10:31:46 --> Loader Class Initialized
INFO - 2025-05-03 10:31:46 --> Helper loaded: url_helper
INFO - 2025-05-03 10:31:46 --> Helper loaded: string_helper
INFO - 2025-05-03 10:31:46 --> Helper loaded: form_helper
INFO - 2025-05-03 10:31:46 --> Helper loaded: file_helper
INFO - 2025-05-03 10:31:46 --> Helper loaded: html_helper
INFO - 2025-05-03 10:31:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:31:46 --> Controller Class Initialized
INFO - 2025-05-03 18:31:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:31:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:31:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:31:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:31:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:31:46 --> Final output sent to browser
DEBUG - 2025-05-03 18:31:46 --> Total execution time: 0.1085
INFO - 2025-05-03 10:31:47 --> Config Class Initialized
INFO - 2025-05-03 10:31:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:31:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:31:47 --> Utf8 Class Initialized
INFO - 2025-05-03 10:31:48 --> URI Class Initialized
INFO - 2025-05-03 10:31:48 --> Router Class Initialized
INFO - 2025-05-03 10:31:48 --> Output Class Initialized
INFO - 2025-05-03 10:31:48 --> Security Class Initialized
DEBUG - 2025-05-03 10:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:31:48 --> Input Class Initialized
INFO - 2025-05-03 10:31:48 --> Language Class Initialized
INFO - 2025-05-03 10:31:48 --> Loader Class Initialized
INFO - 2025-05-03 10:31:48 --> Helper loaded: url_helper
INFO - 2025-05-03 10:31:48 --> Helper loaded: string_helper
INFO - 2025-05-03 10:31:48 --> Helper loaded: form_helper
INFO - 2025-05-03 10:31:48 --> Helper loaded: file_helper
INFO - 2025-05-03 10:31:48 --> Helper loaded: html_helper
INFO - 2025-05-03 10:31:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:31:48 --> Controller Class Initialized
INFO - 2025-05-03 18:31:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:31:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:31:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:31:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:31:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:31:48 --> Final output sent to browser
DEBUG - 2025-05-03 18:31:48 --> Total execution time: 0.2101
INFO - 2025-05-03 10:31:52 --> Config Class Initialized
INFO - 2025-05-03 10:31:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:31:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:31:52 --> Utf8 Class Initialized
INFO - 2025-05-03 10:31:52 --> URI Class Initialized
INFO - 2025-05-03 10:31:52 --> Router Class Initialized
INFO - 2025-05-03 10:31:52 --> Output Class Initialized
INFO - 2025-05-03 10:31:52 --> Security Class Initialized
DEBUG - 2025-05-03 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:31:52 --> Input Class Initialized
INFO - 2025-05-03 10:31:52 --> Language Class Initialized
INFO - 2025-05-03 10:31:52 --> Loader Class Initialized
INFO - 2025-05-03 10:31:52 --> Helper loaded: url_helper
INFO - 2025-05-03 10:31:52 --> Helper loaded: string_helper
INFO - 2025-05-03 10:31:52 --> Helper loaded: form_helper
INFO - 2025-05-03 10:31:52 --> Helper loaded: file_helper
INFO - 2025-05-03 10:31:52 --> Helper loaded: html_helper
INFO - 2025-05-03 10:31:52 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:31:52 --> Controller Class Initialized
INFO - 2025-05-03 18:31:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:31:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:31:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:31:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:31:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:31:52 --> Final output sent to browser
DEBUG - 2025-05-03 18:31:52 --> Total execution time: 0.0859
INFO - 2025-05-03 10:32:19 --> Config Class Initialized
INFO - 2025-05-03 10:32:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:19 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:19 --> URI Class Initialized
INFO - 2025-05-03 10:32:19 --> Router Class Initialized
INFO - 2025-05-03 10:32:19 --> Output Class Initialized
INFO - 2025-05-03 10:32:19 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:19 --> Input Class Initialized
INFO - 2025-05-03 10:32:19 --> Language Class Initialized
INFO - 2025-05-03 10:32:19 --> Loader Class Initialized
INFO - 2025-05-03 10:32:19 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:19 --> Helper loaded: string_helper
INFO - 2025-05-03 10:32:19 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:19 --> Helper loaded: file_helper
INFO - 2025-05-03 10:32:19 --> Helper loaded: html_helper
INFO - 2025-05-03 10:32:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:19 --> Controller Class Initialized
INFO - 2025-05-03 18:32:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:32:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:32:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:32:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:32:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:32:19 --> Final output sent to browser
DEBUG - 2025-05-03 18:32:19 --> Total execution time: 0.1191
INFO - 2025-05-03 10:32:20 --> Config Class Initialized
INFO - 2025-05-03 10:32:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:20 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:20 --> URI Class Initialized
INFO - 2025-05-03 10:32:20 --> Router Class Initialized
INFO - 2025-05-03 10:32:20 --> Output Class Initialized
INFO - 2025-05-03 10:32:20 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:20 --> Input Class Initialized
INFO - 2025-05-03 10:32:20 --> Language Class Initialized
INFO - 2025-05-03 10:32:20 --> Loader Class Initialized
INFO - 2025-05-03 10:32:20 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:20 --> Helper loaded: string_helper
INFO - 2025-05-03 10:32:20 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:20 --> Helper loaded: file_helper
INFO - 2025-05-03 10:32:20 --> Helper loaded: html_helper
INFO - 2025-05-03 10:32:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:20 --> Controller Class Initialized
INFO - 2025-05-03 18:32:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:32:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:32:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:32:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:32:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:32:20 --> Final output sent to browser
DEBUG - 2025-05-03 18:32:20 --> Total execution time: 0.1678
INFO - 2025-05-03 10:33:35 --> Config Class Initialized
INFO - 2025-05-03 10:33:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:33:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:33:35 --> Utf8 Class Initialized
INFO - 2025-05-03 10:33:35 --> URI Class Initialized
INFO - 2025-05-03 10:33:35 --> Router Class Initialized
INFO - 2025-05-03 10:33:35 --> Output Class Initialized
INFO - 2025-05-03 10:33:35 --> Security Class Initialized
DEBUG - 2025-05-03 10:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:33:35 --> Input Class Initialized
INFO - 2025-05-03 10:33:35 --> Language Class Initialized
ERROR - 2025-05-03 10:33:35 --> 404 Page Not Found: Api/users
INFO - 2025-05-03 10:35:33 --> Config Class Initialized
INFO - 2025-05-03 10:35:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:35:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:35:33 --> Utf8 Class Initialized
INFO - 2025-05-03 10:35:33 --> URI Class Initialized
INFO - 2025-05-03 10:35:34 --> Router Class Initialized
INFO - 2025-05-03 10:35:34 --> Output Class Initialized
INFO - 2025-05-03 10:35:34 --> Security Class Initialized
DEBUG - 2025-05-03 10:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:35:34 --> Input Class Initialized
INFO - 2025-05-03 10:35:34 --> Language Class Initialized
INFO - 2025-05-03 10:35:34 --> Loader Class Initialized
INFO - 2025-05-03 10:35:34 --> Helper loaded: url_helper
INFO - 2025-05-03 10:35:34 --> Helper loaded: string_helper
INFO - 2025-05-03 10:35:34 --> Helper loaded: form_helper
INFO - 2025-05-03 10:35:34 --> Helper loaded: file_helper
INFO - 2025-05-03 10:35:34 --> Helper loaded: html_helper
INFO - 2025-05-03 10:35:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:35:34 --> Controller Class Initialized
INFO - 2025-05-03 18:35:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:35:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:35:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:35:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:35:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:35:34 --> Final output sent to browser
DEBUG - 2025-05-03 18:35:34 --> Total execution time: 0.2409
INFO - 2025-05-03 10:35:39 --> Config Class Initialized
INFO - 2025-05-03 10:35:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:35:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:35:39 --> Utf8 Class Initialized
INFO - 2025-05-03 10:35:39 --> URI Class Initialized
INFO - 2025-05-03 10:35:39 --> Router Class Initialized
INFO - 2025-05-03 10:35:39 --> Output Class Initialized
INFO - 2025-05-03 10:35:39 --> Security Class Initialized
DEBUG - 2025-05-03 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:35:39 --> Input Class Initialized
INFO - 2025-05-03 10:35:39 --> Language Class Initialized
INFO - 2025-05-03 10:35:39 --> Loader Class Initialized
INFO - 2025-05-03 10:35:39 --> Helper loaded: url_helper
INFO - 2025-05-03 10:35:39 --> Helper loaded: string_helper
INFO - 2025-05-03 10:35:39 --> Helper loaded: form_helper
INFO - 2025-05-03 10:35:39 --> Helper loaded: file_helper
INFO - 2025-05-03 10:35:39 --> Helper loaded: html_helper
INFO - 2025-05-03 10:35:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:35:39 --> Controller Class Initialized
INFO - 2025-05-03 18:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:35:39 --> Final output sent to browser
DEBUG - 2025-05-03 18:35:39 --> Total execution time: 0.1131
INFO - 2025-05-03 10:36:46 --> Config Class Initialized
INFO - 2025-05-03 10:36:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:36:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:36:46 --> Utf8 Class Initialized
INFO - 2025-05-03 10:36:46 --> URI Class Initialized
INFO - 2025-05-03 10:36:46 --> Router Class Initialized
INFO - 2025-05-03 10:36:46 --> Output Class Initialized
INFO - 2025-05-03 10:36:46 --> Security Class Initialized
DEBUG - 2025-05-03 10:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:36:46 --> Input Class Initialized
INFO - 2025-05-03 10:36:46 --> Language Class Initialized
INFO - 2025-05-03 10:36:47 --> Loader Class Initialized
INFO - 2025-05-03 10:36:47 --> Helper loaded: url_helper
INFO - 2025-05-03 10:36:47 --> Helper loaded: string_helper
INFO - 2025-05-03 10:36:47 --> Helper loaded: form_helper
INFO - 2025-05-03 10:36:47 --> Helper loaded: file_helper
INFO - 2025-05-03 10:36:47 --> Helper loaded: html_helper
INFO - 2025-05-03 10:36:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:36:47 --> Controller Class Initialized
ERROR - 2025-05-03 18:36:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 836
INFO - 2025-05-03 10:37:08 --> Config Class Initialized
INFO - 2025-05-03 10:37:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:37:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:37:08 --> Utf8 Class Initialized
INFO - 2025-05-03 10:37:08 --> URI Class Initialized
INFO - 2025-05-03 10:37:08 --> Router Class Initialized
INFO - 2025-05-03 10:37:08 --> Output Class Initialized
INFO - 2025-05-03 10:37:08 --> Security Class Initialized
DEBUG - 2025-05-03 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:37:08 --> Input Class Initialized
INFO - 2025-05-03 10:37:08 --> Language Class Initialized
INFO - 2025-05-03 10:37:08 --> Loader Class Initialized
INFO - 2025-05-03 10:37:08 --> Helper loaded: url_helper
INFO - 2025-05-03 10:37:08 --> Helper loaded: string_helper
INFO - 2025-05-03 10:37:08 --> Helper loaded: form_helper
INFO - 2025-05-03 10:37:08 --> Helper loaded: file_helper
INFO - 2025-05-03 10:37:08 --> Helper loaded: html_helper
INFO - 2025-05-03 10:37:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:37:08 --> Controller Class Initialized
ERROR - 2025-05-03 18:37:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 836
INFO - 2025-05-03 10:38:50 --> Config Class Initialized
INFO - 2025-05-03 10:38:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:38:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:38:50 --> Utf8 Class Initialized
INFO - 2025-05-03 10:38:50 --> URI Class Initialized
INFO - 2025-05-03 10:38:50 --> Router Class Initialized
INFO - 2025-05-03 10:38:50 --> Output Class Initialized
INFO - 2025-05-03 10:38:50 --> Security Class Initialized
DEBUG - 2025-05-03 10:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:38:50 --> Input Class Initialized
INFO - 2025-05-03 10:38:50 --> Language Class Initialized
INFO - 2025-05-03 10:38:50 --> Loader Class Initialized
INFO - 2025-05-03 10:38:50 --> Helper loaded: url_helper
INFO - 2025-05-03 10:38:50 --> Helper loaded: string_helper
INFO - 2025-05-03 10:38:50 --> Helper loaded: form_helper
INFO - 2025-05-03 10:38:50 --> Helper loaded: file_helper
INFO - 2025-05-03 10:38:50 --> Helper loaded: html_helper
INFO - 2025-05-03 10:38:50 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:38:50 --> Controller Class Initialized
ERROR - 2025-05-03 18:38:50 --> Severity: Warning --> Attempt to read property "toName" on array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 857
INFO - 2025-05-03 18:38:51 --> Model "UserModel" initialized
ERROR - 2025-05-03 18:38:51 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `email` = 'specialemailid2050@gmail.com'
INFO - 2025-05-03 18:38:51 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-03 10:40:47 --> Config Class Initialized
INFO - 2025-05-03 10:40:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:40:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:40:48 --> Utf8 Class Initialized
INFO - 2025-05-03 10:40:48 --> URI Class Initialized
INFO - 2025-05-03 10:40:48 --> Router Class Initialized
INFO - 2025-05-03 10:40:48 --> Output Class Initialized
INFO - 2025-05-03 10:40:48 --> Security Class Initialized
DEBUG - 2025-05-03 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:40:48 --> Input Class Initialized
INFO - 2025-05-03 10:40:48 --> Language Class Initialized
INFO - 2025-05-03 10:40:48 --> Loader Class Initialized
INFO - 2025-05-03 10:40:48 --> Helper loaded: url_helper
INFO - 2025-05-03 10:40:48 --> Helper loaded: string_helper
INFO - 2025-05-03 10:40:48 --> Helper loaded: form_helper
INFO - 2025-05-03 10:40:48 --> Helper loaded: file_helper
INFO - 2025-05-03 10:40:48 --> Helper loaded: html_helper
INFO - 2025-05-03 10:40:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:40:48 --> Controller Class Initialized
INFO - 2025-05-03 18:40:48 --> Model "UserModel" initialized
INFO - 2025-05-03 18:40:48 --> Final output sent to browser
DEBUG - 2025-05-03 18:40:48 --> Total execution time: 0.4806
INFO - 2025-05-03 10:41:09 --> Config Class Initialized
INFO - 2025-05-03 10:41:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:41:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:41:09 --> Utf8 Class Initialized
INFO - 2025-05-03 10:41:09 --> URI Class Initialized
INFO - 2025-05-03 10:41:09 --> Router Class Initialized
INFO - 2025-05-03 10:41:09 --> Output Class Initialized
INFO - 2025-05-03 10:41:09 --> Security Class Initialized
DEBUG - 2025-05-03 10:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:41:09 --> Input Class Initialized
INFO - 2025-05-03 10:41:09 --> Language Class Initialized
INFO - 2025-05-03 10:41:09 --> Loader Class Initialized
INFO - 2025-05-03 10:41:09 --> Helper loaded: url_helper
INFO - 2025-05-03 10:41:09 --> Helper loaded: string_helper
INFO - 2025-05-03 10:41:09 --> Helper loaded: form_helper
INFO - 2025-05-03 10:41:09 --> Helper loaded: file_helper
INFO - 2025-05-03 10:41:09 --> Helper loaded: html_helper
INFO - 2025-05-03 10:41:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:41:09 --> Controller Class Initialized
INFO - 2025-05-03 18:41:09 --> Model "UserModel" initialized
INFO - 2025-05-03 18:41:09 --> Final output sent to browser
DEBUG - 2025-05-03 18:41:09 --> Total execution time: 0.1151
INFO - 2025-05-03 10:45:36 --> Config Class Initialized
INFO - 2025-05-03 10:45:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:45:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:45:36 --> Utf8 Class Initialized
INFO - 2025-05-03 10:45:36 --> URI Class Initialized
INFO - 2025-05-03 10:45:36 --> Router Class Initialized
INFO - 2025-05-03 10:45:36 --> Output Class Initialized
INFO - 2025-05-03 10:45:36 --> Security Class Initialized
DEBUG - 2025-05-03 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:45:36 --> Input Class Initialized
INFO - 2025-05-03 10:45:36 --> Language Class Initialized
INFO - 2025-05-03 10:45:36 --> Loader Class Initialized
INFO - 2025-05-03 10:45:36 --> Helper loaded: url_helper
INFO - 2025-05-03 10:45:36 --> Helper loaded: string_helper
INFO - 2025-05-03 10:45:36 --> Helper loaded: form_helper
INFO - 2025-05-03 10:45:36 --> Helper loaded: file_helper
INFO - 2025-05-03 10:45:36 --> Helper loaded: html_helper
INFO - 2025-05-03 10:45:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:45:36 --> Controller Class Initialized
INFO - 2025-05-03 18:45:36 --> Model "UserModel" initialized
INFO - 2025-05-03 18:45:36 --> Final output sent to browser
DEBUG - 2025-05-03 18:45:36 --> Total execution time: 0.1494
INFO - 2025-05-03 10:46:16 --> Config Class Initialized
INFO - 2025-05-03 10:46:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:46:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:46:16 --> Utf8 Class Initialized
INFO - 2025-05-03 10:46:16 --> URI Class Initialized
INFO - 2025-05-03 10:46:16 --> Router Class Initialized
INFO - 2025-05-03 10:46:16 --> Output Class Initialized
INFO - 2025-05-03 10:46:16 --> Security Class Initialized
DEBUG - 2025-05-03 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:46:16 --> Input Class Initialized
INFO - 2025-05-03 10:46:16 --> Language Class Initialized
INFO - 2025-05-03 10:46:16 --> Loader Class Initialized
INFO - 2025-05-03 10:46:16 --> Helper loaded: url_helper
INFO - 2025-05-03 10:46:16 --> Helper loaded: string_helper
INFO - 2025-05-03 10:46:16 --> Helper loaded: form_helper
INFO - 2025-05-03 10:46:16 --> Helper loaded: file_helper
INFO - 2025-05-03 10:46:16 --> Helper loaded: html_helper
INFO - 2025-05-03 10:46:16 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:46:16 --> Controller Class Initialized
INFO - 2025-05-03 10:46:19 --> Config Class Initialized
INFO - 2025-05-03 10:46:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:46:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:46:19 --> Utf8 Class Initialized
INFO - 2025-05-03 10:46:19 --> URI Class Initialized
INFO - 2025-05-03 10:46:19 --> Router Class Initialized
INFO - 2025-05-03 10:46:19 --> Output Class Initialized
INFO - 2025-05-03 10:46:19 --> Security Class Initialized
DEBUG - 2025-05-03 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:46:19 --> Input Class Initialized
INFO - 2025-05-03 10:46:19 --> Language Class Initialized
INFO - 2025-05-03 10:46:19 --> Loader Class Initialized
INFO - 2025-05-03 10:46:19 --> Helper loaded: url_helper
INFO - 2025-05-03 10:46:19 --> Helper loaded: string_helper
INFO - 2025-05-03 10:46:19 --> Helper loaded: form_helper
INFO - 2025-05-03 10:46:19 --> Helper loaded: file_helper
INFO - 2025-05-03 10:46:19 --> Helper loaded: html_helper
INFO - 2025-05-03 10:46:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:46:19 --> Controller Class Initialized
INFO - 2025-05-03 18:46:19 --> Model "UserModel" initialized
INFO - 2025-05-03 18:46:19 --> Final output sent to browser
DEBUG - 2025-05-03 18:46:19 --> Total execution time: 0.3526
INFO - 2025-05-03 10:46:51 --> Config Class Initialized
INFO - 2025-05-03 10:46:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:46:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:46:51 --> Utf8 Class Initialized
INFO - 2025-05-03 10:46:51 --> URI Class Initialized
INFO - 2025-05-03 10:46:51 --> Router Class Initialized
INFO - 2025-05-03 10:46:51 --> Output Class Initialized
INFO - 2025-05-03 10:46:51 --> Security Class Initialized
DEBUG - 2025-05-03 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:46:51 --> Input Class Initialized
INFO - 2025-05-03 10:46:51 --> Language Class Initialized
INFO - 2025-05-03 10:46:52 --> Loader Class Initialized
INFO - 2025-05-03 10:46:52 --> Helper loaded: url_helper
INFO - 2025-05-03 10:46:52 --> Helper loaded: string_helper
INFO - 2025-05-03 10:46:52 --> Helper loaded: form_helper
INFO - 2025-05-03 10:46:52 --> Helper loaded: file_helper
INFO - 2025-05-03 10:46:52 --> Helper loaded: html_helper
INFO - 2025-05-03 10:46:52 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:46:52 --> Controller Class Initialized
INFO - 2025-05-03 18:46:52 --> Model "UserModel" initialized
INFO - 2025-05-03 18:46:52 --> Final output sent to browser
DEBUG - 2025-05-03 18:46:52 --> Total execution time: 0.2296
INFO - 2025-05-03 10:47:48 --> Config Class Initialized
INFO - 2025-05-03 10:47:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:47:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:47:48 --> Utf8 Class Initialized
INFO - 2025-05-03 10:47:48 --> URI Class Initialized
INFO - 2025-05-03 10:47:49 --> Router Class Initialized
INFO - 2025-05-03 10:47:49 --> Output Class Initialized
INFO - 2025-05-03 10:47:49 --> Security Class Initialized
DEBUG - 2025-05-03 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:47:49 --> Input Class Initialized
INFO - 2025-05-03 10:47:49 --> Language Class Initialized
INFO - 2025-05-03 10:47:49 --> Loader Class Initialized
INFO - 2025-05-03 10:47:49 --> Helper loaded: url_helper
INFO - 2025-05-03 10:47:49 --> Helper loaded: string_helper
INFO - 2025-05-03 10:47:49 --> Helper loaded: form_helper
INFO - 2025-05-03 10:47:49 --> Helper loaded: file_helper
INFO - 2025-05-03 10:47:49 --> Helper loaded: html_helper
INFO - 2025-05-03 10:47:49 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:47:49 --> Controller Class Initialized
ERROR - 2025-05-03 18:47:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 934
INFO - 2025-05-03 10:49:30 --> Config Class Initialized
INFO - 2025-05-03 10:49:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:49:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:49:30 --> Utf8 Class Initialized
INFO - 2025-05-03 10:49:30 --> URI Class Initialized
INFO - 2025-05-03 10:49:30 --> Router Class Initialized
INFO - 2025-05-03 10:49:30 --> Output Class Initialized
INFO - 2025-05-03 10:49:30 --> Security Class Initialized
DEBUG - 2025-05-03 10:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:49:30 --> Input Class Initialized
INFO - 2025-05-03 10:49:30 --> Language Class Initialized
INFO - 2025-05-03 10:49:30 --> Loader Class Initialized
INFO - 2025-05-03 10:49:30 --> Helper loaded: url_helper
INFO - 2025-05-03 10:49:30 --> Helper loaded: string_helper
INFO - 2025-05-03 10:49:30 --> Helper loaded: form_helper
INFO - 2025-05-03 10:49:30 --> Helper loaded: file_helper
INFO - 2025-05-03 10:49:30 --> Helper loaded: html_helper
INFO - 2025-05-03 10:49:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:49:30 --> Controller Class Initialized
INFO - 2025-05-03 18:49:30 --> Model "UserModel" initialized
INFO - 2025-05-03 18:49:30 --> Final output sent to browser
DEBUG - 2025-05-03 18:49:30 --> Total execution time: 0.2825
INFO - 2025-05-03 10:49:57 --> Config Class Initialized
INFO - 2025-05-03 10:49:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:49:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:49:57 --> Utf8 Class Initialized
INFO - 2025-05-03 10:49:57 --> URI Class Initialized
INFO - 2025-05-03 10:49:57 --> Router Class Initialized
INFO - 2025-05-03 10:49:57 --> Output Class Initialized
INFO - 2025-05-03 10:49:57 --> Security Class Initialized
DEBUG - 2025-05-03 10:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:49:57 --> Input Class Initialized
INFO - 2025-05-03 10:49:57 --> Language Class Initialized
INFO - 2025-05-03 10:49:57 --> Loader Class Initialized
INFO - 2025-05-03 10:49:57 --> Helper loaded: url_helper
INFO - 2025-05-03 10:49:57 --> Helper loaded: string_helper
INFO - 2025-05-03 10:49:57 --> Helper loaded: form_helper
INFO - 2025-05-03 10:49:57 --> Helper loaded: file_helper
INFO - 2025-05-03 10:49:57 --> Helper loaded: html_helper
INFO - 2025-05-03 10:49:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:49:57 --> Controller Class Initialized
INFO - 2025-05-03 18:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:49:57 --> Final output sent to browser
DEBUG - 2025-05-03 18:49:57 --> Total execution time: 0.1002
INFO - 2025-05-03 10:53:44 --> Config Class Initialized
INFO - 2025-05-03 10:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:53:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:53:44 --> Utf8 Class Initialized
INFO - 2025-05-03 10:53:44 --> URI Class Initialized
INFO - 2025-05-03 10:53:44 --> Router Class Initialized
INFO - 2025-05-03 10:53:44 --> Output Class Initialized
INFO - 2025-05-03 10:53:44 --> Security Class Initialized
DEBUG - 2025-05-03 10:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:53:44 --> Input Class Initialized
INFO - 2025-05-03 10:53:44 --> Language Class Initialized
INFO - 2025-05-03 10:53:44 --> Loader Class Initialized
INFO - 2025-05-03 10:53:44 --> Helper loaded: url_helper
INFO - 2025-05-03 10:53:44 --> Helper loaded: string_helper
INFO - 2025-05-03 10:53:44 --> Helper loaded: form_helper
INFO - 2025-05-03 10:53:44 --> Helper loaded: file_helper
INFO - 2025-05-03 10:53:44 --> Helper loaded: html_helper
INFO - 2025-05-03 10:53:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:53:44 --> Controller Class Initialized
INFO - 2025-05-03 18:53:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:53:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:53:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:53:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:53:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:53:44 --> Final output sent to browser
DEBUG - 2025-05-03 18:53:44 --> Total execution time: 0.1762
INFO - 2025-05-03 10:55:20 --> Config Class Initialized
INFO - 2025-05-03 10:55:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:55:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:55:20 --> Utf8 Class Initialized
INFO - 2025-05-03 10:55:20 --> URI Class Initialized
INFO - 2025-05-03 10:55:20 --> Router Class Initialized
INFO - 2025-05-03 10:55:20 --> Output Class Initialized
INFO - 2025-05-03 10:55:20 --> Security Class Initialized
DEBUG - 2025-05-03 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:55:20 --> Input Class Initialized
INFO - 2025-05-03 10:55:20 --> Language Class Initialized
INFO - 2025-05-03 10:55:20 --> Loader Class Initialized
INFO - 2025-05-03 10:55:20 --> Helper loaded: url_helper
INFO - 2025-05-03 10:55:20 --> Helper loaded: string_helper
INFO - 2025-05-03 10:55:20 --> Helper loaded: form_helper
INFO - 2025-05-03 10:55:20 --> Helper loaded: file_helper
INFO - 2025-05-03 10:55:20 --> Helper loaded: html_helper
INFO - 2025-05-03 10:55:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:55:20 --> Controller Class Initialized
INFO - 2025-05-03 18:55:21 --> Model "UserModel" initialized
DEBUG - 2025-05-03 18:55:21 --> PHPMailer class is loaded.
INFO - 2025-05-03 18:55:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 18:55:25 --> Final output sent to browser
DEBUG - 2025-05-03 18:55:25 --> Total execution time: 4.7951
INFO - 2025-05-03 10:56:21 --> Config Class Initialized
INFO - 2025-05-03 10:56:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:56:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:56:21 --> Utf8 Class Initialized
INFO - 2025-05-03 10:56:21 --> URI Class Initialized
INFO - 2025-05-03 10:56:21 --> Router Class Initialized
INFO - 2025-05-03 10:56:21 --> Output Class Initialized
INFO - 2025-05-03 10:56:21 --> Security Class Initialized
DEBUG - 2025-05-03 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:56:21 --> Input Class Initialized
INFO - 2025-05-03 10:56:21 --> Language Class Initialized
INFO - 2025-05-03 10:56:21 --> Loader Class Initialized
INFO - 2025-05-03 10:56:21 --> Helper loaded: url_helper
INFO - 2025-05-03 10:56:21 --> Helper loaded: string_helper
INFO - 2025-05-03 10:56:21 --> Helper loaded: form_helper
INFO - 2025-05-03 10:56:21 --> Helper loaded: file_helper
INFO - 2025-05-03 10:56:21 --> Helper loaded: html_helper
INFO - 2025-05-03 10:56:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:56:21 --> Controller Class Initialized
INFO - 2025-05-03 18:56:21 --> Model "UserModel" initialized
DEBUG - 2025-05-03 18:56:21 --> PHPMailer class is loaded.
INFO - 2025-05-03 18:56:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
ERROR - 2025-05-03 18:56:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 885
INFO - 2025-05-03 18:56:25 --> Final output sent to browser
DEBUG - 2025-05-03 18:56:25 --> Total execution time: 3.9488
INFO - 2025-05-03 10:58:56 --> Config Class Initialized
INFO - 2025-05-03 10:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:58:56 --> Utf8 Class Initialized
INFO - 2025-05-03 10:58:56 --> URI Class Initialized
INFO - 2025-05-03 10:58:56 --> Router Class Initialized
INFO - 2025-05-03 10:58:56 --> Output Class Initialized
INFO - 2025-05-03 10:58:56 --> Security Class Initialized
DEBUG - 2025-05-03 10:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:58:56 --> Input Class Initialized
INFO - 2025-05-03 10:58:56 --> Language Class Initialized
INFO - 2025-05-03 10:58:56 --> Loader Class Initialized
INFO - 2025-05-03 10:58:56 --> Helper loaded: url_helper
INFO - 2025-05-03 10:58:56 --> Helper loaded: string_helper
INFO - 2025-05-03 10:58:56 --> Helper loaded: form_helper
INFO - 2025-05-03 10:58:56 --> Helper loaded: file_helper
INFO - 2025-05-03 10:58:56 --> Helper loaded: html_helper
INFO - 2025-05-03 10:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:58:56 --> Controller Class Initialized
INFO - 2025-05-03 18:58:56 --> Model "UserModel" initialized
DEBUG - 2025-05-03 18:58:56 --> PHPMailer class is loaded.
INFO - 2025-05-03 18:58:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 18:59:00 --> Final output sent to browser
DEBUG - 2025-05-03 18:59:00 --> Total execution time: 4.2408
INFO - 2025-05-03 10:59:16 --> Config Class Initialized
INFO - 2025-05-03 10:59:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:59:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:59:16 --> Utf8 Class Initialized
INFO - 2025-05-03 10:59:16 --> URI Class Initialized
INFO - 2025-05-03 10:59:16 --> Router Class Initialized
INFO - 2025-05-03 10:59:16 --> Output Class Initialized
INFO - 2025-05-03 10:59:16 --> Security Class Initialized
DEBUG - 2025-05-03 10:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:59:16 --> Input Class Initialized
INFO - 2025-05-03 10:59:16 --> Language Class Initialized
INFO - 2025-05-03 10:59:16 --> Loader Class Initialized
INFO - 2025-05-03 10:59:16 --> Helper loaded: url_helper
INFO - 2025-05-03 10:59:16 --> Helper loaded: string_helper
INFO - 2025-05-03 10:59:17 --> Helper loaded: form_helper
INFO - 2025-05-03 10:59:17 --> Helper loaded: file_helper
INFO - 2025-05-03 10:59:17 --> Helper loaded: html_helper
INFO - 2025-05-03 10:59:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 10:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:59:17 --> Controller Class Initialized
INFO - 2025-05-03 18:59:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 18:59:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 18:59:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 18:59:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 18:59:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 18:59:17 --> Final output sent to browser
DEBUG - 2025-05-03 18:59:17 --> Total execution time: 0.9074
INFO - 2025-05-03 11:01:08 --> Config Class Initialized
INFO - 2025-05-03 11:01:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:01:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:01:08 --> Utf8 Class Initialized
INFO - 2025-05-03 11:01:08 --> URI Class Initialized
INFO - 2025-05-03 11:01:08 --> Router Class Initialized
INFO - 2025-05-03 11:01:08 --> Output Class Initialized
INFO - 2025-05-03 11:01:08 --> Security Class Initialized
DEBUG - 2025-05-03 11:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:01:08 --> Input Class Initialized
INFO - 2025-05-03 11:01:08 --> Language Class Initialized
INFO - 2025-05-03 11:01:08 --> Loader Class Initialized
INFO - 2025-05-03 11:01:08 --> Helper loaded: url_helper
INFO - 2025-05-03 11:01:08 --> Helper loaded: string_helper
INFO - 2025-05-03 11:01:08 --> Helper loaded: form_helper
INFO - 2025-05-03 11:01:08 --> Helper loaded: file_helper
INFO - 2025-05-03 11:01:08 --> Helper loaded: html_helper
INFO - 2025-05-03 11:01:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:01:08 --> Controller Class Initialized
INFO - 2025-05-03 19:01:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:01:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:01:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:01:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:01:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:01:08 --> Final output sent to browser
DEBUG - 2025-05-03 19:01:08 --> Total execution time: 0.2180
INFO - 2025-05-03 11:01:35 --> Config Class Initialized
INFO - 2025-05-03 11:01:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:01:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:01:35 --> Utf8 Class Initialized
INFO - 2025-05-03 11:01:35 --> URI Class Initialized
INFO - 2025-05-03 11:01:35 --> Router Class Initialized
INFO - 2025-05-03 11:01:35 --> Output Class Initialized
INFO - 2025-05-03 11:01:35 --> Security Class Initialized
DEBUG - 2025-05-03 11:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:01:35 --> Input Class Initialized
INFO - 2025-05-03 11:01:35 --> Language Class Initialized
INFO - 2025-05-03 11:01:35 --> Loader Class Initialized
INFO - 2025-05-03 11:01:35 --> Helper loaded: url_helper
INFO - 2025-05-03 11:01:35 --> Helper loaded: string_helper
INFO - 2025-05-03 11:01:35 --> Helper loaded: form_helper
INFO - 2025-05-03 11:01:35 --> Helper loaded: file_helper
INFO - 2025-05-03 11:01:35 --> Helper loaded: html_helper
INFO - 2025-05-03 11:01:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:01:35 --> Controller Class Initialized
INFO - 2025-05-03 19:01:35 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:01:35 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:01:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:01:43 --> Final output sent to browser
DEBUG - 2025-05-03 19:01:43 --> Total execution time: 8.0726
INFO - 2025-05-03 11:02:20 --> Config Class Initialized
INFO - 2025-05-03 11:02:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:02:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:02:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:02:20 --> URI Class Initialized
INFO - 2025-05-03 11:02:20 --> Router Class Initialized
INFO - 2025-05-03 11:02:20 --> Output Class Initialized
INFO - 2025-05-03 11:02:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:02:20 --> Input Class Initialized
INFO - 2025-05-03 11:02:20 --> Language Class Initialized
INFO - 2025-05-03 11:02:20 --> Loader Class Initialized
INFO - 2025-05-03 11:02:20 --> Helper loaded: url_helper
INFO - 2025-05-03 11:02:20 --> Helper loaded: string_helper
INFO - 2025-05-03 11:02:20 --> Helper loaded: form_helper
INFO - 2025-05-03 11:02:20 --> Helper loaded: file_helper
INFO - 2025-05-03 11:02:20 --> Helper loaded: html_helper
INFO - 2025-05-03 11:02:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:02:20 --> Controller Class Initialized
INFO - 2025-05-03 19:02:20 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:02:20 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:02:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:02:24 --> Final output sent to browser
DEBUG - 2025-05-03 19:02:24 --> Total execution time: 3.8293
INFO - 2025-05-03 11:03:25 --> Config Class Initialized
INFO - 2025-05-03 11:03:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:03:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:03:25 --> Utf8 Class Initialized
INFO - 2025-05-03 11:03:25 --> URI Class Initialized
INFO - 2025-05-03 11:03:25 --> Router Class Initialized
INFO - 2025-05-03 11:03:25 --> Output Class Initialized
INFO - 2025-05-03 11:03:25 --> Security Class Initialized
DEBUG - 2025-05-03 11:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:03:25 --> Input Class Initialized
INFO - 2025-05-03 11:03:25 --> Language Class Initialized
INFO - 2025-05-03 11:03:25 --> Loader Class Initialized
INFO - 2025-05-03 11:03:25 --> Helper loaded: url_helper
INFO - 2025-05-03 11:03:25 --> Helper loaded: string_helper
INFO - 2025-05-03 11:03:25 --> Helper loaded: form_helper
INFO - 2025-05-03 11:03:25 --> Helper loaded: file_helper
INFO - 2025-05-03 11:03:25 --> Helper loaded: html_helper
INFO - 2025-05-03 11:03:25 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:03:25 --> Controller Class Initialized
INFO - 2025-05-03 19:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:03:25 --> Final output sent to browser
DEBUG - 2025-05-03 19:03:25 --> Total execution time: 0.1461
INFO - 2025-05-03 11:03:45 --> Config Class Initialized
INFO - 2025-05-03 11:03:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:03:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:03:45 --> Utf8 Class Initialized
INFO - 2025-05-03 11:03:45 --> URI Class Initialized
INFO - 2025-05-03 11:03:45 --> Router Class Initialized
INFO - 2025-05-03 11:03:45 --> Output Class Initialized
INFO - 2025-05-03 11:03:45 --> Security Class Initialized
DEBUG - 2025-05-03 11:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:03:45 --> Input Class Initialized
INFO - 2025-05-03 11:03:45 --> Language Class Initialized
INFO - 2025-05-03 11:03:45 --> Loader Class Initialized
INFO - 2025-05-03 11:03:45 --> Helper loaded: url_helper
INFO - 2025-05-03 11:03:45 --> Helper loaded: string_helper
INFO - 2025-05-03 11:03:45 --> Helper loaded: form_helper
INFO - 2025-05-03 11:03:45 --> Helper loaded: file_helper
INFO - 2025-05-03 11:03:45 --> Helper loaded: html_helper
INFO - 2025-05-03 11:03:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:03:45 --> Controller Class Initialized
INFO - 2025-05-03 19:03:45 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:03:45 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:03:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:03:49 --> Final output sent to browser
DEBUG - 2025-05-03 19:03:49 --> Total execution time: 3.9403
INFO - 2025-05-03 11:04:20 --> Config Class Initialized
INFO - 2025-05-03 11:04:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:04:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:04:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:04:20 --> URI Class Initialized
INFO - 2025-05-03 11:04:20 --> Router Class Initialized
INFO - 2025-05-03 11:04:20 --> Output Class Initialized
INFO - 2025-05-03 11:04:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:04:20 --> Input Class Initialized
INFO - 2025-05-03 11:04:20 --> Language Class Initialized
INFO - 2025-05-03 11:04:20 --> Loader Class Initialized
INFO - 2025-05-03 11:04:20 --> Helper loaded: url_helper
INFO - 2025-05-03 11:04:20 --> Helper loaded: string_helper
INFO - 2025-05-03 11:04:20 --> Helper loaded: form_helper
INFO - 2025-05-03 11:04:20 --> Helper loaded: file_helper
INFO - 2025-05-03 11:04:20 --> Helper loaded: html_helper
INFO - 2025-05-03 11:04:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:04:20 --> Controller Class Initialized
INFO - 2025-05-03 19:04:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:04:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:04:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:04:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:04:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:04:20 --> Final output sent to browser
DEBUG - 2025-05-03 19:04:20 --> Total execution time: 0.1682
INFO - 2025-05-03 11:04:33 --> Config Class Initialized
INFO - 2025-05-03 11:04:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:04:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:04:33 --> Utf8 Class Initialized
INFO - 2025-05-03 11:04:33 --> URI Class Initialized
INFO - 2025-05-03 11:04:33 --> Router Class Initialized
INFO - 2025-05-03 11:04:33 --> Output Class Initialized
INFO - 2025-05-03 11:04:33 --> Security Class Initialized
DEBUG - 2025-05-03 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:04:33 --> Input Class Initialized
INFO - 2025-05-03 11:04:33 --> Language Class Initialized
INFO - 2025-05-03 11:04:33 --> Loader Class Initialized
INFO - 2025-05-03 11:04:33 --> Helper loaded: url_helper
INFO - 2025-05-03 11:04:33 --> Helper loaded: string_helper
INFO - 2025-05-03 11:04:33 --> Helper loaded: form_helper
INFO - 2025-05-03 11:04:33 --> Helper loaded: file_helper
INFO - 2025-05-03 11:04:33 --> Helper loaded: html_helper
INFO - 2025-05-03 11:04:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:04:33 --> Controller Class Initialized
INFO - 2025-05-03 19:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:04:33 --> Final output sent to browser
DEBUG - 2025-05-03 19:04:33 --> Total execution time: 0.2127
INFO - 2025-05-03 11:04:46 --> Config Class Initialized
INFO - 2025-05-03 11:04:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:04:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:04:46 --> Utf8 Class Initialized
INFO - 2025-05-03 11:04:46 --> URI Class Initialized
INFO - 2025-05-03 11:04:46 --> Router Class Initialized
INFO - 2025-05-03 11:04:46 --> Output Class Initialized
INFO - 2025-05-03 11:04:46 --> Security Class Initialized
DEBUG - 2025-05-03 11:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:04:46 --> Input Class Initialized
INFO - 2025-05-03 11:04:46 --> Language Class Initialized
INFO - 2025-05-03 11:04:46 --> Loader Class Initialized
INFO - 2025-05-03 11:04:46 --> Helper loaded: url_helper
INFO - 2025-05-03 11:04:46 --> Helper loaded: string_helper
INFO - 2025-05-03 11:04:46 --> Helper loaded: form_helper
INFO - 2025-05-03 11:04:46 --> Helper loaded: file_helper
INFO - 2025-05-03 11:04:46 --> Helper loaded: html_helper
INFO - 2025-05-03 11:04:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:04:46 --> Controller Class Initialized
INFO - 2025-05-03 19:04:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:04:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:04:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:04:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:04:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:04:46 --> Final output sent to browser
DEBUG - 2025-05-03 19:04:46 --> Total execution time: 0.1586
INFO - 2025-05-03 11:05:06 --> Config Class Initialized
INFO - 2025-05-03 11:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:05:06 --> Utf8 Class Initialized
INFO - 2025-05-03 11:05:06 --> URI Class Initialized
INFO - 2025-05-03 11:05:06 --> Router Class Initialized
INFO - 2025-05-03 11:05:06 --> Output Class Initialized
INFO - 2025-05-03 11:05:06 --> Security Class Initialized
DEBUG - 2025-05-03 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:05:06 --> Input Class Initialized
INFO - 2025-05-03 11:05:06 --> Language Class Initialized
INFO - 2025-05-03 11:05:06 --> Loader Class Initialized
INFO - 2025-05-03 11:05:06 --> Helper loaded: url_helper
INFO - 2025-05-03 11:05:06 --> Helper loaded: string_helper
INFO - 2025-05-03 11:05:06 --> Helper loaded: form_helper
INFO - 2025-05-03 11:05:06 --> Helper loaded: file_helper
INFO - 2025-05-03 11:05:06 --> Helper loaded: html_helper
INFO - 2025-05-03 11:05:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:05:06 --> Controller Class Initialized
INFO - 2025-05-03 19:05:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:05:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:05:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:05:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:05:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:05:06 --> Final output sent to browser
DEBUG - 2025-05-03 19:05:06 --> Total execution time: 0.1134
INFO - 2025-05-03 11:05:14 --> Config Class Initialized
INFO - 2025-05-03 11:05:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:05:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:05:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:05:14 --> URI Class Initialized
INFO - 2025-05-03 11:05:14 --> Router Class Initialized
INFO - 2025-05-03 11:05:14 --> Output Class Initialized
INFO - 2025-05-03 11:05:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:05:14 --> Input Class Initialized
INFO - 2025-05-03 11:05:14 --> Language Class Initialized
INFO - 2025-05-03 11:05:14 --> Loader Class Initialized
INFO - 2025-05-03 11:05:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:05:14 --> Helper loaded: string_helper
INFO - 2025-05-03 11:05:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:05:14 --> Helper loaded: file_helper
INFO - 2025-05-03 11:05:14 --> Helper loaded: html_helper
INFO - 2025-05-03 11:05:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:05:15 --> Controller Class Initialized
INFO - 2025-05-03 19:05:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:05:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:05:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:05:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:05:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:05:15 --> Final output sent to browser
DEBUG - 2025-05-03 19:05:15 --> Total execution time: 0.1677
INFO - 2025-05-03 11:05:39 --> Config Class Initialized
INFO - 2025-05-03 11:05:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:05:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:05:39 --> Utf8 Class Initialized
INFO - 2025-05-03 11:05:39 --> URI Class Initialized
INFO - 2025-05-03 11:05:39 --> Router Class Initialized
INFO - 2025-05-03 11:05:39 --> Output Class Initialized
INFO - 2025-05-03 11:05:39 --> Security Class Initialized
DEBUG - 2025-05-03 11:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:05:39 --> Input Class Initialized
INFO - 2025-05-03 11:05:39 --> Language Class Initialized
INFO - 2025-05-03 11:05:39 --> Loader Class Initialized
INFO - 2025-05-03 11:05:39 --> Helper loaded: url_helper
INFO - 2025-05-03 11:05:39 --> Helper loaded: string_helper
INFO - 2025-05-03 11:05:39 --> Helper loaded: form_helper
INFO - 2025-05-03 11:05:39 --> Helper loaded: file_helper
INFO - 2025-05-03 11:05:39 --> Helper loaded: html_helper
INFO - 2025-05-03 11:05:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:05:39 --> Controller Class Initialized
INFO - 2025-05-03 19:05:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:05:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:05:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:05:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:05:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:05:39 --> Final output sent to browser
DEBUG - 2025-05-03 19:05:39 --> Total execution time: 0.1321
INFO - 2025-05-03 11:05:54 --> Config Class Initialized
INFO - 2025-05-03 11:05:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:05:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:05:54 --> Utf8 Class Initialized
INFO - 2025-05-03 11:05:54 --> URI Class Initialized
INFO - 2025-05-03 11:05:54 --> Router Class Initialized
INFO - 2025-05-03 11:05:54 --> Output Class Initialized
INFO - 2025-05-03 11:05:54 --> Security Class Initialized
DEBUG - 2025-05-03 11:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:05:54 --> Input Class Initialized
INFO - 2025-05-03 11:05:54 --> Language Class Initialized
INFO - 2025-05-03 11:05:54 --> Loader Class Initialized
INFO - 2025-05-03 11:05:54 --> Helper loaded: url_helper
INFO - 2025-05-03 11:05:54 --> Helper loaded: string_helper
INFO - 2025-05-03 11:05:54 --> Helper loaded: form_helper
INFO - 2025-05-03 11:05:54 --> Helper loaded: file_helper
INFO - 2025-05-03 11:05:54 --> Helper loaded: html_helper
INFO - 2025-05-03 11:05:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:05:54 --> Controller Class Initialized
INFO - 2025-05-03 19:05:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:05:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:05:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:05:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:05:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:05:54 --> Final output sent to browser
DEBUG - 2025-05-03 19:05:54 --> Total execution time: 0.1924
INFO - 2025-05-03 11:06:13 --> Config Class Initialized
INFO - 2025-05-03 11:06:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:06:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:06:13 --> Utf8 Class Initialized
INFO - 2025-05-03 11:06:13 --> URI Class Initialized
INFO - 2025-05-03 11:06:13 --> Router Class Initialized
INFO - 2025-05-03 11:06:13 --> Output Class Initialized
INFO - 2025-05-03 11:06:13 --> Security Class Initialized
DEBUG - 2025-05-03 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:06:13 --> Input Class Initialized
INFO - 2025-05-03 11:06:13 --> Language Class Initialized
INFO - 2025-05-03 11:06:13 --> Loader Class Initialized
INFO - 2025-05-03 11:06:13 --> Helper loaded: url_helper
INFO - 2025-05-03 11:06:13 --> Helper loaded: string_helper
INFO - 2025-05-03 11:06:13 --> Helper loaded: form_helper
INFO - 2025-05-03 11:06:13 --> Helper loaded: file_helper
INFO - 2025-05-03 11:06:13 --> Helper loaded: html_helper
INFO - 2025-05-03 11:06:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:06:13 --> Controller Class Initialized
INFO - 2025-05-03 19:06:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:06:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:06:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:06:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:06:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:06:13 --> Final output sent to browser
DEBUG - 2025-05-03 19:06:13 --> Total execution time: 0.1408
INFO - 2025-05-03 11:06:23 --> Config Class Initialized
INFO - 2025-05-03 11:06:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:06:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:06:23 --> Utf8 Class Initialized
INFO - 2025-05-03 11:06:23 --> URI Class Initialized
INFO - 2025-05-03 11:06:23 --> Router Class Initialized
INFO - 2025-05-03 11:06:23 --> Output Class Initialized
INFO - 2025-05-03 11:06:23 --> Security Class Initialized
DEBUG - 2025-05-03 11:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:06:23 --> Input Class Initialized
INFO - 2025-05-03 11:06:23 --> Language Class Initialized
INFO - 2025-05-03 11:06:23 --> Loader Class Initialized
INFO - 2025-05-03 11:06:23 --> Helper loaded: url_helper
INFO - 2025-05-03 11:06:23 --> Helper loaded: string_helper
INFO - 2025-05-03 11:06:23 --> Helper loaded: form_helper
INFO - 2025-05-03 11:06:23 --> Helper loaded: file_helper
INFO - 2025-05-03 11:06:23 --> Helper loaded: html_helper
INFO - 2025-05-03 11:06:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:06:23 --> Controller Class Initialized
INFO - 2025-05-03 19:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:06:23 --> Final output sent to browser
DEBUG - 2025-05-03 19:06:23 --> Total execution time: 0.3019
INFO - 2025-05-03 11:06:37 --> Config Class Initialized
INFO - 2025-05-03 11:06:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:06:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:06:37 --> Utf8 Class Initialized
INFO - 2025-05-03 11:06:37 --> URI Class Initialized
INFO - 2025-05-03 11:06:37 --> Router Class Initialized
INFO - 2025-05-03 11:06:37 --> Output Class Initialized
INFO - 2025-05-03 11:06:37 --> Security Class Initialized
DEBUG - 2025-05-03 11:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:06:37 --> Input Class Initialized
INFO - 2025-05-03 11:06:37 --> Language Class Initialized
INFO - 2025-05-03 11:06:37 --> Loader Class Initialized
INFO - 2025-05-03 11:06:37 --> Helper loaded: url_helper
INFO - 2025-05-03 11:06:37 --> Helper loaded: string_helper
INFO - 2025-05-03 11:06:37 --> Helper loaded: form_helper
INFO - 2025-05-03 11:06:37 --> Helper loaded: file_helper
INFO - 2025-05-03 11:06:37 --> Helper loaded: html_helper
INFO - 2025-05-03 11:06:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:06:37 --> Controller Class Initialized
INFO - 2025-05-03 19:06:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:06:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:06:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:06:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:06:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:06:37 --> Final output sent to browser
DEBUG - 2025-05-03 19:06:37 --> Total execution time: 0.3243
INFO - 2025-05-03 11:07:30 --> Config Class Initialized
INFO - 2025-05-03 11:07:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:07:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:07:30 --> Utf8 Class Initialized
INFO - 2025-05-03 11:07:30 --> URI Class Initialized
INFO - 2025-05-03 11:07:30 --> Router Class Initialized
INFO - 2025-05-03 11:07:30 --> Output Class Initialized
INFO - 2025-05-03 11:07:30 --> Security Class Initialized
DEBUG - 2025-05-03 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:07:30 --> Input Class Initialized
INFO - 2025-05-03 11:07:30 --> Language Class Initialized
INFO - 2025-05-03 11:07:30 --> Loader Class Initialized
INFO - 2025-05-03 11:07:30 --> Helper loaded: url_helper
INFO - 2025-05-03 11:07:30 --> Helper loaded: string_helper
INFO - 2025-05-03 11:07:30 --> Helper loaded: form_helper
INFO - 2025-05-03 11:07:30 --> Helper loaded: file_helper
INFO - 2025-05-03 11:07:30 --> Helper loaded: html_helper
INFO - 2025-05-03 11:07:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:07:30 --> Controller Class Initialized
INFO - 2025-05-03 19:07:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:07:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:07:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:07:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:07:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:07:30 --> Final output sent to browser
DEBUG - 2025-05-03 19:07:30 --> Total execution time: 0.1587
INFO - 2025-05-03 11:08:01 --> Config Class Initialized
INFO - 2025-05-03 11:08:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:08:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:08:01 --> Utf8 Class Initialized
INFO - 2025-05-03 11:08:01 --> URI Class Initialized
INFO - 2025-05-03 11:08:02 --> Router Class Initialized
INFO - 2025-05-03 11:08:02 --> Output Class Initialized
INFO - 2025-05-03 11:08:02 --> Security Class Initialized
DEBUG - 2025-05-03 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:08:02 --> Input Class Initialized
INFO - 2025-05-03 11:08:02 --> Language Class Initialized
INFO - 2025-05-03 11:08:02 --> Loader Class Initialized
INFO - 2025-05-03 11:08:02 --> Helper loaded: url_helper
INFO - 2025-05-03 11:08:02 --> Helper loaded: string_helper
INFO - 2025-05-03 11:08:02 --> Helper loaded: form_helper
INFO - 2025-05-03 11:08:02 --> Helper loaded: file_helper
INFO - 2025-05-03 11:08:02 --> Helper loaded: html_helper
INFO - 2025-05-03 11:08:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:08:02 --> Controller Class Initialized
INFO - 2025-05-03 19:08:02 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:08:02 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:08:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:08:08 --> Final output sent to browser
DEBUG - 2025-05-03 19:08:08 --> Total execution time: 6.9790
INFO - 2025-05-03 11:09:02 --> Config Class Initialized
INFO - 2025-05-03 11:09:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:09:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:09:02 --> Utf8 Class Initialized
INFO - 2025-05-03 11:09:02 --> URI Class Initialized
INFO - 2025-05-03 11:09:02 --> Router Class Initialized
INFO - 2025-05-03 11:09:02 --> Output Class Initialized
INFO - 2025-05-03 11:09:02 --> Security Class Initialized
DEBUG - 2025-05-03 11:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:09:02 --> Input Class Initialized
INFO - 2025-05-03 11:09:02 --> Language Class Initialized
INFO - 2025-05-03 11:09:03 --> Loader Class Initialized
INFO - 2025-05-03 11:09:03 --> Helper loaded: url_helper
INFO - 2025-05-03 11:09:03 --> Helper loaded: string_helper
INFO - 2025-05-03 11:09:03 --> Helper loaded: form_helper
INFO - 2025-05-03 11:09:03 --> Helper loaded: file_helper
INFO - 2025-05-03 11:09:03 --> Helper loaded: html_helper
INFO - 2025-05-03 11:09:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:09:03 --> Controller Class Initialized
INFO - 2025-05-03 19:09:03 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:09:03 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:09:06 --> Final output sent to browser
DEBUG - 2025-05-03 19:09:06 --> Total execution time: 3.8101
INFO - 2025-05-03 11:10:08 --> Config Class Initialized
INFO - 2025-05-03 11:10:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:10:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:10:08 --> Utf8 Class Initialized
INFO - 2025-05-03 11:10:08 --> URI Class Initialized
INFO - 2025-05-03 11:10:08 --> Router Class Initialized
INFO - 2025-05-03 11:10:08 --> Output Class Initialized
INFO - 2025-05-03 11:10:08 --> Security Class Initialized
DEBUG - 2025-05-03 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:10:08 --> Input Class Initialized
INFO - 2025-05-03 11:10:08 --> Language Class Initialized
INFO - 2025-05-03 11:10:08 --> Loader Class Initialized
INFO - 2025-05-03 11:10:08 --> Helper loaded: url_helper
INFO - 2025-05-03 11:10:08 --> Helper loaded: string_helper
INFO - 2025-05-03 11:10:08 --> Helper loaded: form_helper
INFO - 2025-05-03 11:10:08 --> Helper loaded: file_helper
INFO - 2025-05-03 11:10:08 --> Helper loaded: html_helper
INFO - 2025-05-03 11:10:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:10:08 --> Controller Class Initialized
INFO - 2025-05-03 19:10:08 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:10:08 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:10:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:10:15 --> Final output sent to browser
DEBUG - 2025-05-03 19:10:15 --> Total execution time: 6.4760
INFO - 2025-05-03 11:12:20 --> Config Class Initialized
INFO - 2025-05-03 11:12:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:12:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:12:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:12:20 --> URI Class Initialized
INFO - 2025-05-03 11:12:20 --> Router Class Initialized
INFO - 2025-05-03 11:12:20 --> Output Class Initialized
INFO - 2025-05-03 11:12:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:12:20 --> Input Class Initialized
INFO - 2025-05-03 11:12:20 --> Language Class Initialized
INFO - 2025-05-03 11:12:20 --> Loader Class Initialized
INFO - 2025-05-03 11:12:20 --> Helper loaded: url_helper
INFO - 2025-05-03 11:12:20 --> Helper loaded: string_helper
INFO - 2025-05-03 11:12:20 --> Helper loaded: form_helper
INFO - 2025-05-03 11:12:20 --> Helper loaded: file_helper
INFO - 2025-05-03 11:12:20 --> Helper loaded: html_helper
INFO - 2025-05-03 11:12:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:12:20 --> Controller Class Initialized
INFO - 2025-05-03 19:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:12:20 --> Final output sent to browser
DEBUG - 2025-05-03 19:12:20 --> Total execution time: 0.1863
INFO - 2025-05-03 11:12:50 --> Config Class Initialized
INFO - 2025-05-03 11:12:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:12:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:12:50 --> Utf8 Class Initialized
INFO - 2025-05-03 11:12:50 --> URI Class Initialized
INFO - 2025-05-03 11:12:50 --> Router Class Initialized
INFO - 2025-05-03 11:12:50 --> Output Class Initialized
INFO - 2025-05-03 11:12:50 --> Security Class Initialized
DEBUG - 2025-05-03 11:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:12:50 --> Input Class Initialized
INFO - 2025-05-03 11:12:50 --> Language Class Initialized
INFO - 2025-05-03 11:12:50 --> Loader Class Initialized
INFO - 2025-05-03 11:12:50 --> Helper loaded: url_helper
INFO - 2025-05-03 11:12:50 --> Helper loaded: string_helper
INFO - 2025-05-03 11:12:50 --> Helper loaded: form_helper
INFO - 2025-05-03 11:12:50 --> Helper loaded: file_helper
INFO - 2025-05-03 11:12:50 --> Helper loaded: html_helper
INFO - 2025-05-03 11:12:50 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:12:50 --> Controller Class Initialized
INFO - 2025-05-03 19:12:50 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:12:50 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:12:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:12:56 --> Final output sent to browser
DEBUG - 2025-05-03 19:12:56 --> Total execution time: 6.3937
INFO - 2025-05-03 11:13:13 --> Config Class Initialized
INFO - 2025-05-03 11:13:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:13:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:13:13 --> Utf8 Class Initialized
INFO - 2025-05-03 11:13:13 --> URI Class Initialized
INFO - 2025-05-03 11:13:13 --> Router Class Initialized
INFO - 2025-05-03 11:13:13 --> Output Class Initialized
INFO - 2025-05-03 11:13:13 --> Security Class Initialized
DEBUG - 2025-05-03 11:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:13:13 --> Input Class Initialized
INFO - 2025-05-03 11:13:13 --> Language Class Initialized
INFO - 2025-05-03 11:13:13 --> Loader Class Initialized
INFO - 2025-05-03 11:13:13 --> Helper loaded: url_helper
INFO - 2025-05-03 11:13:13 --> Helper loaded: string_helper
INFO - 2025-05-03 11:13:13 --> Helper loaded: form_helper
INFO - 2025-05-03 11:13:13 --> Helper loaded: file_helper
INFO - 2025-05-03 11:13:13 --> Helper loaded: html_helper
INFO - 2025-05-03 11:13:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:13:13 --> Controller Class Initialized
INFO - 2025-05-03 19:13:13 --> Model "UserModel" initialized
INFO - 2025-05-03 19:13:13 --> Final output sent to browser
DEBUG - 2025-05-03 19:13:13 --> Total execution time: 0.1974
INFO - 2025-05-03 11:13:48 --> Config Class Initialized
INFO - 2025-05-03 11:13:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:13:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:13:48 --> Utf8 Class Initialized
INFO - 2025-05-03 11:13:48 --> URI Class Initialized
INFO - 2025-05-03 11:13:48 --> Router Class Initialized
INFO - 2025-05-03 11:13:48 --> Output Class Initialized
INFO - 2025-05-03 11:13:48 --> Security Class Initialized
DEBUG - 2025-05-03 11:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:13:48 --> Input Class Initialized
INFO - 2025-05-03 11:13:48 --> Language Class Initialized
INFO - 2025-05-03 11:13:48 --> Loader Class Initialized
INFO - 2025-05-03 11:13:48 --> Helper loaded: url_helper
INFO - 2025-05-03 11:13:48 --> Helper loaded: string_helper
INFO - 2025-05-03 11:13:48 --> Helper loaded: form_helper
INFO - 2025-05-03 11:13:48 --> Helper loaded: file_helper
INFO - 2025-05-03 11:13:48 --> Helper loaded: html_helper
INFO - 2025-05-03 11:13:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:13:48 --> Controller Class Initialized
INFO - 2025-05-03 19:13:48 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:13:48 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:13:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:13:55 --> Final output sent to browser
DEBUG - 2025-05-03 19:13:55 --> Total execution time: 6.8282
INFO - 2025-05-03 11:14:11 --> Config Class Initialized
INFO - 2025-05-03 11:14:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:14:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:14:11 --> Utf8 Class Initialized
INFO - 2025-05-03 11:14:11 --> URI Class Initialized
INFO - 2025-05-03 11:14:11 --> Router Class Initialized
INFO - 2025-05-03 11:14:11 --> Output Class Initialized
INFO - 2025-05-03 11:14:11 --> Security Class Initialized
DEBUG - 2025-05-03 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:14:11 --> Input Class Initialized
INFO - 2025-05-03 11:14:11 --> Language Class Initialized
INFO - 2025-05-03 11:14:11 --> Loader Class Initialized
INFO - 2025-05-03 11:14:11 --> Helper loaded: url_helper
INFO - 2025-05-03 11:14:11 --> Helper loaded: string_helper
INFO - 2025-05-03 11:14:11 --> Helper loaded: form_helper
INFO - 2025-05-03 11:14:11 --> Helper loaded: file_helper
INFO - 2025-05-03 11:14:11 --> Helper loaded: html_helper
INFO - 2025-05-03 11:14:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:14:11 --> Controller Class Initialized
INFO - 2025-05-03 19:14:11 --> Model "UserModel" initialized
INFO - 2025-05-03 19:14:11 --> Final output sent to browser
DEBUG - 2025-05-03 19:14:11 --> Total execution time: 0.4017
INFO - 2025-05-03 11:14:15 --> Config Class Initialized
INFO - 2025-05-03 11:14:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:14:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:14:15 --> Utf8 Class Initialized
INFO - 2025-05-03 11:14:15 --> URI Class Initialized
INFO - 2025-05-03 11:14:15 --> Router Class Initialized
INFO - 2025-05-03 11:14:15 --> Output Class Initialized
INFO - 2025-05-03 11:14:15 --> Security Class Initialized
DEBUG - 2025-05-03 11:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:14:15 --> Input Class Initialized
INFO - 2025-05-03 11:14:15 --> Language Class Initialized
INFO - 2025-05-03 11:14:15 --> Loader Class Initialized
INFO - 2025-05-03 11:14:15 --> Helper loaded: url_helper
INFO - 2025-05-03 11:14:15 --> Helper loaded: string_helper
INFO - 2025-05-03 11:14:15 --> Helper loaded: form_helper
INFO - 2025-05-03 11:14:15 --> Helper loaded: file_helper
INFO - 2025-05-03 11:14:15 --> Helper loaded: html_helper
INFO - 2025-05-03 11:14:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:14:15 --> Controller Class Initialized
INFO - 2025-05-03 19:14:15 --> Model "UserModel" initialized
INFO - 2025-05-03 19:14:15 --> Final output sent to browser
DEBUG - 2025-05-03 19:14:15 --> Total execution time: 0.1789
INFO - 2025-05-03 11:14:18 --> Config Class Initialized
INFO - 2025-05-03 11:14:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:14:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:14:18 --> Utf8 Class Initialized
INFO - 2025-05-03 11:14:18 --> URI Class Initialized
INFO - 2025-05-03 11:14:18 --> Router Class Initialized
INFO - 2025-05-03 11:14:18 --> Output Class Initialized
INFO - 2025-05-03 11:14:18 --> Security Class Initialized
DEBUG - 2025-05-03 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:14:18 --> Input Class Initialized
INFO - 2025-05-03 11:14:18 --> Language Class Initialized
INFO - 2025-05-03 11:14:18 --> Loader Class Initialized
INFO - 2025-05-03 11:14:18 --> Helper loaded: url_helper
INFO - 2025-05-03 11:14:18 --> Helper loaded: string_helper
INFO - 2025-05-03 11:14:18 --> Helper loaded: form_helper
INFO - 2025-05-03 11:14:18 --> Helper loaded: file_helper
INFO - 2025-05-03 11:14:18 --> Helper loaded: html_helper
INFO - 2025-05-03 11:14:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:14:18 --> Controller Class Initialized
INFO - 2025-05-03 19:14:18 --> Model "UserModel" initialized
INFO - 2025-05-03 19:14:18 --> Final output sent to browser
DEBUG - 2025-05-03 19:14:18 --> Total execution time: 0.1970
INFO - 2025-05-03 11:15:21 --> Config Class Initialized
INFO - 2025-05-03 11:15:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:15:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:15:21 --> Utf8 Class Initialized
INFO - 2025-05-03 11:15:21 --> URI Class Initialized
INFO - 2025-05-03 11:15:21 --> Router Class Initialized
INFO - 2025-05-03 11:15:21 --> Output Class Initialized
INFO - 2025-05-03 11:15:21 --> Security Class Initialized
DEBUG - 2025-05-03 11:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:15:21 --> Input Class Initialized
INFO - 2025-05-03 11:15:21 --> Language Class Initialized
INFO - 2025-05-03 11:15:21 --> Loader Class Initialized
INFO - 2025-05-03 11:15:21 --> Helper loaded: url_helper
INFO - 2025-05-03 11:15:21 --> Helper loaded: string_helper
INFO - 2025-05-03 11:15:21 --> Helper loaded: form_helper
INFO - 2025-05-03 11:15:21 --> Helper loaded: file_helper
INFO - 2025-05-03 11:15:21 --> Helper loaded: html_helper
INFO - 2025-05-03 11:15:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:15:21 --> Controller Class Initialized
INFO - 2025-05-03 19:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:15:21 --> Final output sent to browser
DEBUG - 2025-05-03 19:15:21 --> Total execution time: 0.1603
INFO - 2025-05-03 11:16:29 --> Config Class Initialized
INFO - 2025-05-03 11:16:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:16:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:16:29 --> Utf8 Class Initialized
INFO - 2025-05-03 11:16:29 --> URI Class Initialized
INFO - 2025-05-03 11:16:29 --> Router Class Initialized
INFO - 2025-05-03 11:16:29 --> Output Class Initialized
INFO - 2025-05-03 11:16:29 --> Security Class Initialized
DEBUG - 2025-05-03 11:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:16:29 --> Input Class Initialized
INFO - 2025-05-03 11:16:29 --> Language Class Initialized
INFO - 2025-05-03 11:16:29 --> Loader Class Initialized
INFO - 2025-05-03 11:16:29 --> Helper loaded: url_helper
INFO - 2025-05-03 11:16:29 --> Helper loaded: string_helper
INFO - 2025-05-03 11:16:29 --> Helper loaded: form_helper
INFO - 2025-05-03 11:16:29 --> Helper loaded: file_helper
INFO - 2025-05-03 11:16:29 --> Helper loaded: html_helper
INFO - 2025-05-03 11:16:29 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:16:29 --> Controller Class Initialized
INFO - 2025-05-03 19:16:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:16:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:16:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:16:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:16:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:16:29 --> Final output sent to browser
DEBUG - 2025-05-03 19:16:29 --> Total execution time: 0.1692
INFO - 2025-05-03 11:17:18 --> Config Class Initialized
INFO - 2025-05-03 11:17:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:17:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:17:18 --> Utf8 Class Initialized
INFO - 2025-05-03 11:17:18 --> URI Class Initialized
INFO - 2025-05-03 11:17:18 --> Router Class Initialized
INFO - 2025-05-03 11:17:18 --> Output Class Initialized
INFO - 2025-05-03 11:17:18 --> Security Class Initialized
DEBUG - 2025-05-03 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:17:18 --> Input Class Initialized
INFO - 2025-05-03 11:17:18 --> Language Class Initialized
INFO - 2025-05-03 11:17:18 --> Loader Class Initialized
INFO - 2025-05-03 11:17:18 --> Helper loaded: url_helper
INFO - 2025-05-03 11:17:18 --> Helper loaded: string_helper
INFO - 2025-05-03 11:17:18 --> Helper loaded: form_helper
INFO - 2025-05-03 11:17:18 --> Helper loaded: file_helper
INFO - 2025-05-03 11:17:18 --> Helper loaded: html_helper
INFO - 2025-05-03 11:17:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:17:18 --> Controller Class Initialized
INFO - 2025-05-03 19:17:18 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:17:18 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:17:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:17:26 --> Final output sent to browser
DEBUG - 2025-05-03 19:17:26 --> Total execution time: 8.1940
INFO - 2025-05-03 11:18:03 --> Config Class Initialized
INFO - 2025-05-03 11:18:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:18:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:18:03 --> Utf8 Class Initialized
INFO - 2025-05-03 11:18:03 --> URI Class Initialized
INFO - 2025-05-03 11:18:03 --> Router Class Initialized
INFO - 2025-05-03 11:18:03 --> Output Class Initialized
INFO - 2025-05-03 11:18:03 --> Security Class Initialized
DEBUG - 2025-05-03 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:18:03 --> Input Class Initialized
INFO - 2025-05-03 11:18:03 --> Language Class Initialized
INFO - 2025-05-03 11:18:03 --> Loader Class Initialized
INFO - 2025-05-03 11:18:03 --> Helper loaded: url_helper
INFO - 2025-05-03 11:18:03 --> Helper loaded: string_helper
INFO - 2025-05-03 11:18:03 --> Helper loaded: form_helper
INFO - 2025-05-03 11:18:03 --> Helper loaded: file_helper
INFO - 2025-05-03 11:18:03 --> Helper loaded: html_helper
INFO - 2025-05-03 11:18:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:18:03 --> Controller Class Initialized
INFO - 2025-05-03 19:18:03 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:18:03 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:18:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:18:09 --> Final output sent to browser
DEBUG - 2025-05-03 19:18:09 --> Total execution time: 6.4155
INFO - 2025-05-03 11:18:13 --> Config Class Initialized
INFO - 2025-05-03 11:18:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:18:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:18:13 --> Utf8 Class Initialized
INFO - 2025-05-03 11:18:13 --> URI Class Initialized
INFO - 2025-05-03 11:18:13 --> Router Class Initialized
INFO - 2025-05-03 11:18:13 --> Output Class Initialized
INFO - 2025-05-03 11:18:13 --> Security Class Initialized
DEBUG - 2025-05-03 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:18:13 --> Input Class Initialized
INFO - 2025-05-03 11:18:13 --> Language Class Initialized
INFO - 2025-05-03 11:18:13 --> Loader Class Initialized
INFO - 2025-05-03 11:18:13 --> Helper loaded: url_helper
INFO - 2025-05-03 11:18:13 --> Helper loaded: string_helper
INFO - 2025-05-03 11:18:13 --> Helper loaded: form_helper
INFO - 2025-05-03 11:18:13 --> Helper loaded: file_helper
INFO - 2025-05-03 11:18:13 --> Helper loaded: html_helper
INFO - 2025-05-03 11:18:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:18:13 --> Controller Class Initialized
INFO - 2025-05-03 19:18:13 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:18:13 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:18:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:18:20 --> Final output sent to browser
DEBUG - 2025-05-03 19:18:20 --> Total execution time: 6.5865
INFO - 2025-05-03 11:19:20 --> Config Class Initialized
INFO - 2025-05-03 11:19:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:19:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:19:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:19:20 --> URI Class Initialized
INFO - 2025-05-03 11:19:20 --> Router Class Initialized
INFO - 2025-05-03 11:19:20 --> Output Class Initialized
INFO - 2025-05-03 11:19:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:19:20 --> Input Class Initialized
INFO - 2025-05-03 11:19:20 --> Language Class Initialized
INFO - 2025-05-03 11:19:21 --> Loader Class Initialized
INFO - 2025-05-03 11:19:21 --> Helper loaded: url_helper
INFO - 2025-05-03 11:19:21 --> Helper loaded: string_helper
INFO - 2025-05-03 11:19:21 --> Helper loaded: form_helper
INFO - 2025-05-03 11:19:21 --> Helper loaded: file_helper
INFO - 2025-05-03 11:19:21 --> Helper loaded: html_helper
INFO - 2025-05-03 11:19:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:19:21 --> Controller Class Initialized
INFO - 2025-05-03 19:19:21 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:19:21 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:19:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:19:28 --> Final output sent to browser
DEBUG - 2025-05-03 19:19:28 --> Total execution time: 7.7440
INFO - 2025-05-03 11:19:37 --> Config Class Initialized
INFO - 2025-05-03 11:19:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:19:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:19:37 --> Utf8 Class Initialized
INFO - 2025-05-03 11:19:37 --> URI Class Initialized
INFO - 2025-05-03 11:19:37 --> Router Class Initialized
INFO - 2025-05-03 11:19:37 --> Output Class Initialized
INFO - 2025-05-03 11:19:37 --> Security Class Initialized
DEBUG - 2025-05-03 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:19:37 --> Input Class Initialized
INFO - 2025-05-03 11:19:37 --> Language Class Initialized
INFO - 2025-05-03 11:19:37 --> Loader Class Initialized
INFO - 2025-05-03 11:19:37 --> Helper loaded: url_helper
INFO - 2025-05-03 11:19:37 --> Helper loaded: string_helper
INFO - 2025-05-03 11:19:37 --> Helper loaded: form_helper
INFO - 2025-05-03 11:19:37 --> Helper loaded: file_helper
INFO - 2025-05-03 11:19:37 --> Helper loaded: html_helper
INFO - 2025-05-03 11:19:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:19:37 --> Controller Class Initialized
INFO - 2025-05-03 19:19:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:19:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:19:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:19:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:19:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:19:37 --> Final output sent to browser
DEBUG - 2025-05-03 19:19:37 --> Total execution time: 0.1584
INFO - 2025-05-03 11:23:57 --> Config Class Initialized
INFO - 2025-05-03 11:23:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:23:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:23:57 --> Utf8 Class Initialized
INFO - 2025-05-03 11:23:57 --> URI Class Initialized
INFO - 2025-05-03 11:23:57 --> Router Class Initialized
INFO - 2025-05-03 11:23:57 --> Output Class Initialized
INFO - 2025-05-03 11:23:57 --> Security Class Initialized
DEBUG - 2025-05-03 11:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:23:57 --> Input Class Initialized
INFO - 2025-05-03 11:23:57 --> Language Class Initialized
INFO - 2025-05-03 11:23:57 --> Loader Class Initialized
INFO - 2025-05-03 11:23:57 --> Helper loaded: url_helper
INFO - 2025-05-03 11:23:57 --> Helper loaded: string_helper
INFO - 2025-05-03 11:23:57 --> Helper loaded: form_helper
INFO - 2025-05-03 11:23:57 --> Helper loaded: file_helper
INFO - 2025-05-03 11:23:57 --> Helper loaded: html_helper
INFO - 2025-05-03 11:23:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:23:57 --> Controller Class Initialized
INFO - 2025-05-03 19:23:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:23:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:23:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:23:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:23:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:23:57 --> Final output sent to browser
DEBUG - 2025-05-03 19:23:57 --> Total execution time: 0.3561
INFO - 2025-05-03 11:24:48 --> Config Class Initialized
INFO - 2025-05-03 11:24:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:24:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:24:48 --> Utf8 Class Initialized
INFO - 2025-05-03 11:24:48 --> URI Class Initialized
INFO - 2025-05-03 11:24:48 --> Router Class Initialized
INFO - 2025-05-03 11:24:48 --> Output Class Initialized
INFO - 2025-05-03 11:24:48 --> Security Class Initialized
DEBUG - 2025-05-03 11:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:24:48 --> Input Class Initialized
INFO - 2025-05-03 11:24:48 --> Language Class Initialized
INFO - 2025-05-03 11:24:48 --> Loader Class Initialized
INFO - 2025-05-03 11:24:48 --> Helper loaded: url_helper
INFO - 2025-05-03 11:24:48 --> Helper loaded: string_helper
INFO - 2025-05-03 11:24:48 --> Helper loaded: form_helper
INFO - 2025-05-03 11:24:48 --> Helper loaded: file_helper
INFO - 2025-05-03 11:24:48 --> Helper loaded: html_helper
INFO - 2025-05-03 11:24:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:24:48 --> Controller Class Initialized
INFO - 2025-05-03 19:24:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:24:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:24:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:24:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:24:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:24:48 --> Final output sent to browser
DEBUG - 2025-05-03 19:24:48 --> Total execution time: 0.1799
INFO - 2025-05-03 11:26:14 --> Config Class Initialized
INFO - 2025-05-03 11:26:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:26:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:26:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:26:14 --> URI Class Initialized
INFO - 2025-05-03 11:26:14 --> Router Class Initialized
INFO - 2025-05-03 11:26:14 --> Output Class Initialized
INFO - 2025-05-03 11:26:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:26:14 --> Input Class Initialized
INFO - 2025-05-03 11:26:14 --> Language Class Initialized
INFO - 2025-05-03 11:26:14 --> Loader Class Initialized
INFO - 2025-05-03 11:26:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: string_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: file_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: html_helper
INFO - 2025-05-03 11:26:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:26:14 --> Controller Class Initialized
INFO - 2025-05-03 11:26:14 --> Config Class Initialized
INFO - 2025-05-03 11:26:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:26:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:26:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:26:14 --> URI Class Initialized
DEBUG - 2025-05-03 11:26:14 --> No URI present. Default controller set.
INFO - 2025-05-03 11:26:14 --> Router Class Initialized
INFO - 2025-05-03 11:26:14 --> Output Class Initialized
INFO - 2025-05-03 11:26:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:26:14 --> Input Class Initialized
INFO - 2025-05-03 11:26:14 --> Language Class Initialized
INFO - 2025-05-03 11:26:14 --> Loader Class Initialized
INFO - 2025-05-03 11:26:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: string_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: file_helper
INFO - 2025-05-03 11:26:14 --> Helper loaded: html_helper
INFO - 2025-05-03 11:26:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:26:14 --> Controller Class Initialized
INFO - 2025-05-03 11:26:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 11:26:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 11:26:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 11:26:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 11:26:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 11:26:14 --> Final output sent to browser
DEBUG - 2025-05-03 11:26:14 --> Total execution time: 0.1413
INFO - 2025-05-03 11:26:15 --> Config Class Initialized
INFO - 2025-05-03 11:26:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:26:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:26:15 --> Utf8 Class Initialized
INFO - 2025-05-03 11:26:15 --> URI Class Initialized
INFO - 2025-05-03 11:26:15 --> Router Class Initialized
INFO - 2025-05-03 11:26:15 --> Output Class Initialized
INFO - 2025-05-03 11:26:16 --> Security Class Initialized
DEBUG - 2025-05-03 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:26:16 --> Input Class Initialized
INFO - 2025-05-03 11:26:16 --> Language Class Initialized
INFO - 2025-05-03 11:26:16 --> Loader Class Initialized
INFO - 2025-05-03 11:26:21 --> Config Class Initialized
INFO - 2025-05-03 11:26:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:26:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:26:21 --> Utf8 Class Initialized
INFO - 2025-05-03 11:26:22 --> URI Class Initialized
INFO - 2025-05-03 11:26:22 --> Router Class Initialized
INFO - 2025-05-03 11:26:22 --> Output Class Initialized
INFO - 2025-05-03 11:26:22 --> Security Class Initialized
DEBUG - 2025-05-03 11:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:26:22 --> Input Class Initialized
INFO - 2025-05-03 11:26:22 --> Language Class Initialized
INFO - 2025-05-03 11:26:22 --> Loader Class Initialized
INFO - 2025-05-03 11:26:22 --> Helper loaded: url_helper
INFO - 2025-05-03 11:26:22 --> Helper loaded: string_helper
INFO - 2025-05-03 11:26:22 --> Helper loaded: form_helper
INFO - 2025-05-03 11:26:22 --> Helper loaded: file_helper
INFO - 2025-05-03 11:26:22 --> Helper loaded: html_helper
INFO - 2025-05-03 11:26:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:26:22 --> Controller Class Initialized
INFO - 2025-05-03 19:26:22 --> Model "AuctionModel" initialized
INFO - 2025-05-03 11:26:35 --> Config Class Initialized
INFO - 2025-05-03 11:26:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:26:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:26:35 --> Utf8 Class Initialized
INFO - 2025-05-03 11:26:35 --> URI Class Initialized
INFO - 2025-05-03 11:26:35 --> Router Class Initialized
INFO - 2025-05-03 11:26:36 --> Output Class Initialized
INFO - 2025-05-03 11:26:36 --> Security Class Initialized
DEBUG - 2025-05-03 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:26:36 --> Input Class Initialized
INFO - 2025-05-03 11:26:36 --> Language Class Initialized
INFO - 2025-05-03 11:26:36 --> Loader Class Initialized
INFO - 2025-05-03 11:26:36 --> Helper loaded: url_helper
INFO - 2025-05-03 11:26:36 --> Helper loaded: string_helper
INFO - 2025-05-03 11:26:36 --> Helper loaded: form_helper
INFO - 2025-05-03 11:26:36 --> Helper loaded: file_helper
INFO - 2025-05-03 11:26:36 --> Helper loaded: html_helper
INFO - 2025-05-03 11:26:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:26:36 --> Controller Class Initialized
INFO - 2025-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:26:36 --> Final output sent to browser
DEBUG - 2025-05-03 19:26:36 --> Total execution time: 0.2648
INFO - 2025-05-03 11:29:06 --> Config Class Initialized
INFO - 2025-05-03 11:29:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:06 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:06 --> URI Class Initialized
INFO - 2025-05-03 11:29:06 --> Router Class Initialized
INFO - 2025-05-03 11:29:06 --> Output Class Initialized
INFO - 2025-05-03 11:29:06 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:06 --> Input Class Initialized
INFO - 2025-05-03 11:29:06 --> Language Class Initialized
INFO - 2025-05-03 11:29:06 --> Loader Class Initialized
INFO - 2025-05-03 11:29:06 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:06 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:06 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:06 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:06 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:06 --> Controller Class Initialized
INFO - 2025-05-03 19:29:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:06 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:06 --> Total execution time: 0.2266
INFO - 2025-05-03 11:29:24 --> Config Class Initialized
INFO - 2025-05-03 11:29:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:24 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:24 --> URI Class Initialized
INFO - 2025-05-03 11:29:24 --> Router Class Initialized
INFO - 2025-05-03 11:29:24 --> Output Class Initialized
INFO - 2025-05-03 11:29:24 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:24 --> Input Class Initialized
INFO - 2025-05-03 11:29:24 --> Language Class Initialized
INFO - 2025-05-03 11:29:24 --> Loader Class Initialized
INFO - 2025-05-03 11:29:24 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:24 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:24 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:24 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:24 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:24 --> Controller Class Initialized
INFO - 2025-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:24 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:24 --> Total execution time: 0.1580
INFO - 2025-05-03 11:29:31 --> Config Class Initialized
INFO - 2025-05-03 11:29:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:31 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:31 --> URI Class Initialized
INFO - 2025-05-03 11:29:31 --> Router Class Initialized
INFO - 2025-05-03 11:29:31 --> Output Class Initialized
INFO - 2025-05-03 11:29:31 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:31 --> Input Class Initialized
INFO - 2025-05-03 11:29:31 --> Language Class Initialized
INFO - 2025-05-03 11:29:31 --> Loader Class Initialized
INFO - 2025-05-03 11:29:31 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:31 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:31 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:31 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:31 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:31 --> Controller Class Initialized
INFO - 2025-05-03 19:29:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:31 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:31 --> Total execution time: 0.2130
INFO - 2025-05-03 11:29:50 --> Config Class Initialized
INFO - 2025-05-03 11:29:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:50 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:50 --> URI Class Initialized
INFO - 2025-05-03 11:29:50 --> Router Class Initialized
INFO - 2025-05-03 11:29:50 --> Output Class Initialized
INFO - 2025-05-03 11:29:50 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:50 --> Input Class Initialized
INFO - 2025-05-03 11:29:50 --> Language Class Initialized
INFO - 2025-05-03 11:29:50 --> Loader Class Initialized
INFO - 2025-05-03 11:29:50 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:50 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:50 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:51 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:51 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:51 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:51 --> Controller Class Initialized
INFO - 2025-05-03 19:29:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:51 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:51 --> Total execution time: 0.1504
INFO - 2025-05-03 11:29:53 --> Config Class Initialized
INFO - 2025-05-03 11:29:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:53 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:53 --> URI Class Initialized
INFO - 2025-05-03 11:29:53 --> Router Class Initialized
INFO - 2025-05-03 11:29:53 --> Output Class Initialized
INFO - 2025-05-03 11:29:53 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:53 --> Input Class Initialized
INFO - 2025-05-03 11:29:53 --> Language Class Initialized
INFO - 2025-05-03 11:29:53 --> Loader Class Initialized
INFO - 2025-05-03 11:29:53 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:53 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:53 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:53 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:53 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:53 --> Controller Class Initialized
INFO - 2025-05-03 19:29:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:53 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:53 --> Total execution time: 0.1075
INFO - 2025-05-03 11:29:55 --> Config Class Initialized
INFO - 2025-05-03 11:29:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:29:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:29:55 --> Utf8 Class Initialized
INFO - 2025-05-03 11:29:55 --> URI Class Initialized
INFO - 2025-05-03 11:29:55 --> Router Class Initialized
INFO - 2025-05-03 11:29:55 --> Output Class Initialized
INFO - 2025-05-03 11:29:55 --> Security Class Initialized
DEBUG - 2025-05-03 11:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:29:55 --> Input Class Initialized
INFO - 2025-05-03 11:29:55 --> Language Class Initialized
INFO - 2025-05-03 11:29:55 --> Loader Class Initialized
INFO - 2025-05-03 11:29:55 --> Helper loaded: url_helper
INFO - 2025-05-03 11:29:55 --> Helper loaded: string_helper
INFO - 2025-05-03 11:29:55 --> Helper loaded: form_helper
INFO - 2025-05-03 11:29:55 --> Helper loaded: file_helper
INFO - 2025-05-03 11:29:55 --> Helper loaded: html_helper
INFO - 2025-05-03 11:29:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:29:55 --> Controller Class Initialized
INFO - 2025-05-03 19:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:29:55 --> Final output sent to browser
DEBUG - 2025-05-03 19:29:55 --> Total execution time: 0.2048
INFO - 2025-05-03 11:31:18 --> Config Class Initialized
INFO - 2025-05-03 11:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:31:18 --> Utf8 Class Initialized
INFO - 2025-05-03 11:31:18 --> URI Class Initialized
INFO - 2025-05-03 11:31:18 --> Router Class Initialized
INFO - 2025-05-03 11:31:18 --> Output Class Initialized
INFO - 2025-05-03 11:31:18 --> Security Class Initialized
DEBUG - 2025-05-03 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:31:18 --> Input Class Initialized
INFO - 2025-05-03 11:31:18 --> Language Class Initialized
INFO - 2025-05-03 11:31:18 --> Loader Class Initialized
INFO - 2025-05-03 11:31:18 --> Helper loaded: url_helper
INFO - 2025-05-03 11:31:18 --> Helper loaded: string_helper
INFO - 2025-05-03 11:31:18 --> Helper loaded: form_helper
INFO - 2025-05-03 11:31:18 --> Helper loaded: file_helper
INFO - 2025-05-03 11:31:18 --> Helper loaded: html_helper
INFO - 2025-05-03 11:31:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:31:18 --> Controller Class Initialized
INFO - 2025-05-03 19:31:18 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:31:18 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:31:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:31:27 --> Final output sent to browser
DEBUG - 2025-05-03 19:31:27 --> Total execution time: 8.3255
INFO - 2025-05-03 11:31:44 --> Config Class Initialized
INFO - 2025-05-03 11:31:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:31:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:31:44 --> Utf8 Class Initialized
INFO - 2025-05-03 11:31:44 --> URI Class Initialized
INFO - 2025-05-03 11:31:44 --> Router Class Initialized
INFO - 2025-05-03 11:31:44 --> Output Class Initialized
INFO - 2025-05-03 11:31:44 --> Security Class Initialized
DEBUG - 2025-05-03 11:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:31:44 --> Input Class Initialized
INFO - 2025-05-03 11:31:44 --> Language Class Initialized
INFO - 2025-05-03 11:31:44 --> Loader Class Initialized
INFO - 2025-05-03 11:31:44 --> Helper loaded: url_helper
INFO - 2025-05-03 11:31:44 --> Helper loaded: string_helper
INFO - 2025-05-03 11:31:44 --> Helper loaded: form_helper
INFO - 2025-05-03 11:31:44 --> Helper loaded: file_helper
INFO - 2025-05-03 11:31:44 --> Helper loaded: html_helper
INFO - 2025-05-03 11:31:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:31:44 --> Controller Class Initialized
INFO - 2025-05-03 19:31:44 --> Model "UserModel" initialized
INFO - 2025-05-03 19:31:44 --> Final output sent to browser
DEBUG - 2025-05-03 19:31:44 --> Total execution time: 0.1841
INFO - 2025-05-03 11:31:57 --> Config Class Initialized
INFO - 2025-05-03 11:31:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:31:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:31:57 --> Utf8 Class Initialized
INFO - 2025-05-03 11:31:57 --> URI Class Initialized
INFO - 2025-05-03 11:31:57 --> Router Class Initialized
INFO - 2025-05-03 11:31:57 --> Output Class Initialized
INFO - 2025-05-03 11:31:57 --> Security Class Initialized
DEBUG - 2025-05-03 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:31:57 --> Input Class Initialized
INFO - 2025-05-03 11:31:57 --> Language Class Initialized
INFO - 2025-05-03 11:31:57 --> Loader Class Initialized
INFO - 2025-05-03 11:31:57 --> Helper loaded: url_helper
INFO - 2025-05-03 11:31:57 --> Helper loaded: string_helper
INFO - 2025-05-03 11:31:57 --> Helper loaded: form_helper
INFO - 2025-05-03 11:31:57 --> Helper loaded: file_helper
INFO - 2025-05-03 11:31:57 --> Helper loaded: html_helper
INFO - 2025-05-03 11:31:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:31:57 --> Controller Class Initialized
INFO - 2025-05-03 19:31:57 --> Model "UserModel" initialized
INFO - 2025-05-03 19:31:57 --> Final output sent to browser
DEBUG - 2025-05-03 19:31:57 --> Total execution time: 0.3058
INFO - 2025-05-03 11:32:04 --> Config Class Initialized
INFO - 2025-05-03 11:32:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:32:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:32:04 --> Utf8 Class Initialized
INFO - 2025-05-03 11:32:04 --> URI Class Initialized
INFO - 2025-05-03 11:32:04 --> Router Class Initialized
INFO - 2025-05-03 11:32:04 --> Output Class Initialized
INFO - 2025-05-03 11:32:04 --> Security Class Initialized
DEBUG - 2025-05-03 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:32:04 --> Input Class Initialized
INFO - 2025-05-03 11:32:04 --> Language Class Initialized
INFO - 2025-05-03 11:32:04 --> Loader Class Initialized
INFO - 2025-05-03 11:32:04 --> Helper loaded: url_helper
INFO - 2025-05-03 11:32:04 --> Helper loaded: string_helper
INFO - 2025-05-03 11:32:04 --> Helper loaded: form_helper
INFO - 2025-05-03 11:32:05 --> Helper loaded: file_helper
INFO - 2025-05-03 11:32:05 --> Helper loaded: html_helper
INFO - 2025-05-03 11:32:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:32:05 --> Controller Class Initialized
INFO - 2025-05-03 19:32:05 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:32:05 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:32:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:32:08 --> Final output sent to browser
DEBUG - 2025-05-03 19:32:08 --> Total execution time: 4.0229
INFO - 2025-05-03 11:32:20 --> Config Class Initialized
INFO - 2025-05-03 11:32:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:32:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:32:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:32:20 --> URI Class Initialized
INFO - 2025-05-03 11:32:20 --> Router Class Initialized
INFO - 2025-05-03 11:32:20 --> Output Class Initialized
INFO - 2025-05-03 11:32:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:32:20 --> Input Class Initialized
INFO - 2025-05-03 11:32:20 --> Language Class Initialized
INFO - 2025-05-03 11:32:20 --> Loader Class Initialized
INFO - 2025-05-03 11:32:20 --> Helper loaded: url_helper
INFO - 2025-05-03 11:32:20 --> Helper loaded: string_helper
INFO - 2025-05-03 11:32:20 --> Helper loaded: form_helper
INFO - 2025-05-03 11:32:20 --> Helper loaded: file_helper
INFO - 2025-05-03 11:32:20 --> Helper loaded: html_helper
INFO - 2025-05-03 11:32:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:32:20 --> Controller Class Initialized
INFO - 2025-05-03 19:32:20 --> Model "UserModel" initialized
INFO - 2025-05-03 19:32:20 --> Final output sent to browser
DEBUG - 2025-05-03 19:32:20 --> Total execution time: 0.1193
INFO - 2025-05-03 11:32:23 --> Config Class Initialized
INFO - 2025-05-03 11:32:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:32:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:32:23 --> Utf8 Class Initialized
INFO - 2025-05-03 11:32:23 --> URI Class Initialized
INFO - 2025-05-03 11:32:23 --> Router Class Initialized
INFO - 2025-05-03 11:32:23 --> Output Class Initialized
INFO - 2025-05-03 11:32:23 --> Security Class Initialized
DEBUG - 2025-05-03 11:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:32:23 --> Input Class Initialized
INFO - 2025-05-03 11:32:23 --> Language Class Initialized
INFO - 2025-05-03 11:32:23 --> Loader Class Initialized
INFO - 2025-05-03 11:32:23 --> Helper loaded: url_helper
INFO - 2025-05-03 11:32:23 --> Helper loaded: string_helper
INFO - 2025-05-03 11:32:23 --> Helper loaded: form_helper
INFO - 2025-05-03 11:32:23 --> Helper loaded: file_helper
INFO - 2025-05-03 11:32:23 --> Helper loaded: html_helper
INFO - 2025-05-03 11:32:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:32:23 --> Controller Class Initialized
INFO - 2025-05-03 19:32:23 --> Model "UserModel" initialized
INFO - 2025-05-03 19:32:23 --> Final output sent to browser
DEBUG - 2025-05-03 19:32:23 --> Total execution time: 0.1895
INFO - 2025-05-03 11:32:33 --> Config Class Initialized
INFO - 2025-05-03 11:32:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:32:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:32:33 --> Utf8 Class Initialized
INFO - 2025-05-03 11:32:33 --> URI Class Initialized
INFO - 2025-05-03 11:32:33 --> Router Class Initialized
INFO - 2025-05-03 11:32:33 --> Output Class Initialized
INFO - 2025-05-03 11:32:33 --> Security Class Initialized
DEBUG - 2025-05-03 11:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:32:33 --> Input Class Initialized
INFO - 2025-05-03 11:32:33 --> Language Class Initialized
INFO - 2025-05-03 11:32:33 --> Loader Class Initialized
INFO - 2025-05-03 11:32:33 --> Helper loaded: url_helper
INFO - 2025-05-03 11:32:33 --> Helper loaded: string_helper
INFO - 2025-05-03 11:32:33 --> Helper loaded: form_helper
INFO - 2025-05-03 11:32:33 --> Helper loaded: file_helper
INFO - 2025-05-03 11:32:33 --> Helper loaded: html_helper
INFO - 2025-05-03 11:32:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:32:33 --> Controller Class Initialized
INFO - 2025-05-03 19:32:33 --> Model "UserModel" initialized
INFO - 2025-05-03 19:32:33 --> Final output sent to browser
DEBUG - 2025-05-03 19:32:33 --> Total execution time: 0.1941
INFO - 2025-05-03 11:32:37 --> Config Class Initialized
INFO - 2025-05-03 11:32:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:32:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:32:37 --> Utf8 Class Initialized
INFO - 2025-05-03 11:32:37 --> URI Class Initialized
INFO - 2025-05-03 11:32:37 --> Router Class Initialized
INFO - 2025-05-03 11:32:37 --> Output Class Initialized
INFO - 2025-05-03 11:32:37 --> Security Class Initialized
DEBUG - 2025-05-03 11:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:32:37 --> Input Class Initialized
INFO - 2025-05-03 11:32:37 --> Language Class Initialized
ERROR - 2025-05-03 11:32:37 --> 404 Page Not Found: Api/users
INFO - 2025-05-03 11:33:59 --> Config Class Initialized
INFO - 2025-05-03 11:33:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:33:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:33:59 --> Utf8 Class Initialized
INFO - 2025-05-03 11:33:59 --> URI Class Initialized
INFO - 2025-05-03 11:33:59 --> Router Class Initialized
INFO - 2025-05-03 11:33:59 --> Output Class Initialized
INFO - 2025-05-03 11:33:59 --> Security Class Initialized
DEBUG - 2025-05-03 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:33:59 --> Input Class Initialized
INFO - 2025-05-03 11:33:59 --> Language Class Initialized
INFO - 2025-05-03 11:33:59 --> Loader Class Initialized
INFO - 2025-05-03 11:33:59 --> Helper loaded: url_helper
INFO - 2025-05-03 11:33:59 --> Helper loaded: string_helper
INFO - 2025-05-03 11:33:59 --> Helper loaded: form_helper
INFO - 2025-05-03 11:33:59 --> Helper loaded: file_helper
INFO - 2025-05-03 11:33:59 --> Helper loaded: html_helper
INFO - 2025-05-03 11:33:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:33:59 --> Controller Class Initialized
INFO - 2025-05-03 19:33:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:33:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:33:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:33:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:33:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:33:59 --> Final output sent to browser
DEBUG - 2025-05-03 19:33:59 --> Total execution time: 0.2672
INFO - 2025-05-03 11:36:28 --> Config Class Initialized
INFO - 2025-05-03 11:36:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:36:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:36:28 --> Utf8 Class Initialized
INFO - 2025-05-03 11:36:28 --> URI Class Initialized
INFO - 2025-05-03 11:36:28 --> Router Class Initialized
INFO - 2025-05-03 11:36:28 --> Output Class Initialized
INFO - 2025-05-03 11:36:28 --> Security Class Initialized
DEBUG - 2025-05-03 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:36:28 --> Input Class Initialized
INFO - 2025-05-03 11:36:28 --> Language Class Initialized
INFO - 2025-05-03 11:36:28 --> Loader Class Initialized
INFO - 2025-05-03 11:36:28 --> Helper loaded: url_helper
INFO - 2025-05-03 11:36:28 --> Helper loaded: string_helper
INFO - 2025-05-03 11:36:28 --> Helper loaded: form_helper
INFO - 2025-05-03 11:36:28 --> Helper loaded: file_helper
INFO - 2025-05-03 11:36:28 --> Helper loaded: html_helper
INFO - 2025-05-03 11:36:28 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:36:28 --> Controller Class Initialized
INFO - 2025-05-03 19:36:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:36:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:36:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:36:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:36:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:36:28 --> Final output sent to browser
DEBUG - 2025-05-03 19:36:28 --> Total execution time: 0.1512
INFO - 2025-05-03 11:36:55 --> Config Class Initialized
INFO - 2025-05-03 11:36:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:36:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:36:55 --> Utf8 Class Initialized
INFO - 2025-05-03 11:36:55 --> URI Class Initialized
INFO - 2025-05-03 11:36:55 --> Router Class Initialized
INFO - 2025-05-03 11:36:55 --> Output Class Initialized
INFO - 2025-05-03 11:36:55 --> Security Class Initialized
DEBUG - 2025-05-03 11:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:36:55 --> Input Class Initialized
INFO - 2025-05-03 11:36:55 --> Language Class Initialized
INFO - 2025-05-03 11:36:56 --> Loader Class Initialized
INFO - 2025-05-03 11:36:56 --> Helper loaded: url_helper
INFO - 2025-05-03 11:36:56 --> Helper loaded: string_helper
INFO - 2025-05-03 11:36:56 --> Helper loaded: form_helper
INFO - 2025-05-03 11:36:56 --> Helper loaded: file_helper
INFO - 2025-05-03 11:36:56 --> Helper loaded: html_helper
INFO - 2025-05-03 11:36:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:36:56 --> Controller Class Initialized
INFO - 2025-05-03 19:36:56 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:36:56 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:36:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:37:01 --> Final output sent to browser
DEBUG - 2025-05-03 19:37:01 --> Total execution time: 6.0381
INFO - 2025-05-03 11:37:21 --> Config Class Initialized
INFO - 2025-05-03 11:37:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:37:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:37:21 --> Utf8 Class Initialized
INFO - 2025-05-03 11:37:21 --> URI Class Initialized
INFO - 2025-05-03 11:37:22 --> Router Class Initialized
INFO - 2025-05-03 11:37:22 --> Output Class Initialized
INFO - 2025-05-03 11:37:22 --> Security Class Initialized
DEBUG - 2025-05-03 11:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:37:22 --> Input Class Initialized
INFO - 2025-05-03 11:37:22 --> Language Class Initialized
INFO - 2025-05-03 11:37:22 --> Loader Class Initialized
INFO - 2025-05-03 11:37:22 --> Helper loaded: url_helper
INFO - 2025-05-03 11:37:22 --> Helper loaded: string_helper
INFO - 2025-05-03 11:37:22 --> Helper loaded: form_helper
INFO - 2025-05-03 11:37:22 --> Helper loaded: file_helper
INFO - 2025-05-03 11:37:22 --> Helper loaded: html_helper
INFO - 2025-05-03 11:37:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:37:22 --> Controller Class Initialized
INFO - 2025-05-03 19:37:22 --> Model "UserModel" initialized
INFO - 2025-05-03 19:37:22 --> Final output sent to browser
DEBUG - 2025-05-03 19:37:22 --> Total execution time: 0.2315
INFO - 2025-05-03 11:37:23 --> Config Class Initialized
INFO - 2025-05-03 11:37:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:37:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:37:23 --> Utf8 Class Initialized
INFO - 2025-05-03 11:37:23 --> URI Class Initialized
INFO - 2025-05-03 11:37:23 --> Router Class Initialized
INFO - 2025-05-03 11:37:23 --> Output Class Initialized
INFO - 2025-05-03 11:37:23 --> Security Class Initialized
DEBUG - 2025-05-03 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:37:23 --> Input Class Initialized
INFO - 2025-05-03 11:37:23 --> Language Class Initialized
INFO - 2025-05-03 11:37:23 --> Loader Class Initialized
INFO - 2025-05-03 11:37:23 --> Helper loaded: url_helper
INFO - 2025-05-03 11:37:23 --> Helper loaded: string_helper
INFO - 2025-05-03 11:37:23 --> Helper loaded: form_helper
INFO - 2025-05-03 11:37:23 --> Helper loaded: file_helper
INFO - 2025-05-03 11:37:23 --> Helper loaded: html_helper
INFO - 2025-05-03 11:37:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:37:24 --> Controller Class Initialized
INFO - 2025-05-03 19:37:24 --> Model "UserModel" initialized
INFO - 2025-05-03 19:37:24 --> Final output sent to browser
DEBUG - 2025-05-03 19:37:24 --> Total execution time: 0.2146
INFO - 2025-05-03 11:37:41 --> Config Class Initialized
INFO - 2025-05-03 11:37:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:37:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:37:41 --> Utf8 Class Initialized
INFO - 2025-05-03 11:37:41 --> URI Class Initialized
INFO - 2025-05-03 11:37:41 --> Router Class Initialized
INFO - 2025-05-03 11:37:41 --> Output Class Initialized
INFO - 2025-05-03 11:37:41 --> Security Class Initialized
DEBUG - 2025-05-03 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:37:41 --> Input Class Initialized
INFO - 2025-05-03 11:37:41 --> Language Class Initialized
INFO - 2025-05-03 11:37:41 --> Loader Class Initialized
INFO - 2025-05-03 11:37:41 --> Helper loaded: url_helper
INFO - 2025-05-03 11:37:41 --> Helper loaded: string_helper
INFO - 2025-05-03 11:37:41 --> Helper loaded: form_helper
INFO - 2025-05-03 11:37:41 --> Helper loaded: file_helper
INFO - 2025-05-03 11:37:41 --> Helper loaded: html_helper
INFO - 2025-05-03 11:37:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:37:41 --> Controller Class Initialized
INFO - 2025-05-03 19:37:41 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:37:41 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:37:47 --> Final output sent to browser
DEBUG - 2025-05-03 19:37:47 --> Total execution time: 5.4831
INFO - 2025-05-03 11:38:01 --> Config Class Initialized
INFO - 2025-05-03 11:38:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:38:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:38:01 --> Utf8 Class Initialized
INFO - 2025-05-03 11:38:01 --> URI Class Initialized
INFO - 2025-05-03 11:38:01 --> Router Class Initialized
INFO - 2025-05-03 11:38:01 --> Output Class Initialized
INFO - 2025-05-03 11:38:01 --> Security Class Initialized
DEBUG - 2025-05-03 11:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:38:01 --> Input Class Initialized
INFO - 2025-05-03 11:38:01 --> Language Class Initialized
INFO - 2025-05-03 11:38:01 --> Loader Class Initialized
INFO - 2025-05-03 11:38:01 --> Helper loaded: url_helper
INFO - 2025-05-03 11:38:01 --> Helper loaded: string_helper
INFO - 2025-05-03 11:38:01 --> Helper loaded: form_helper
INFO - 2025-05-03 11:38:01 --> Helper loaded: file_helper
INFO - 2025-05-03 11:38:01 --> Helper loaded: html_helper
INFO - 2025-05-03 11:38:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:38:01 --> Controller Class Initialized
INFO - 2025-05-03 19:38:01 --> Model "UserModel" initialized
INFO - 2025-05-03 19:38:01 --> Final output sent to browser
DEBUG - 2025-05-03 19:38:01 --> Total execution time: 0.1526
INFO - 2025-05-03 11:38:04 --> Config Class Initialized
INFO - 2025-05-03 11:38:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:38:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:38:04 --> Utf8 Class Initialized
INFO - 2025-05-03 11:38:04 --> URI Class Initialized
INFO - 2025-05-03 11:38:04 --> Router Class Initialized
INFO - 2025-05-03 11:38:04 --> Output Class Initialized
INFO - 2025-05-03 11:38:04 --> Security Class Initialized
DEBUG - 2025-05-03 11:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:38:04 --> Input Class Initialized
INFO - 2025-05-03 11:38:04 --> Language Class Initialized
INFO - 2025-05-03 11:38:04 --> Loader Class Initialized
INFO - 2025-05-03 11:38:04 --> Helper loaded: url_helper
INFO - 2025-05-03 11:38:04 --> Helper loaded: string_helper
INFO - 2025-05-03 11:38:04 --> Helper loaded: form_helper
INFO - 2025-05-03 11:38:04 --> Helper loaded: file_helper
INFO - 2025-05-03 11:38:04 --> Helper loaded: html_helper
INFO - 2025-05-03 11:38:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:38:04 --> Controller Class Initialized
INFO - 2025-05-03 19:38:04 --> Model "UserModel" initialized
INFO - 2025-05-03 11:38:15 --> Config Class Initialized
INFO - 2025-05-03 11:38:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:38:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:38:15 --> Utf8 Class Initialized
INFO - 2025-05-03 11:38:15 --> URI Class Initialized
INFO - 2025-05-03 11:38:15 --> Router Class Initialized
INFO - 2025-05-03 11:38:15 --> Output Class Initialized
INFO - 2025-05-03 11:38:15 --> Security Class Initialized
DEBUG - 2025-05-03 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:38:15 --> Input Class Initialized
INFO - 2025-05-03 11:38:15 --> Language Class Initialized
INFO - 2025-05-03 11:38:15 --> Loader Class Initialized
INFO - 2025-05-03 11:38:15 --> Helper loaded: url_helper
INFO - 2025-05-03 11:38:15 --> Helper loaded: string_helper
INFO - 2025-05-03 11:38:15 --> Helper loaded: form_helper
INFO - 2025-05-03 11:38:15 --> Helper loaded: file_helper
INFO - 2025-05-03 11:38:15 --> Helper loaded: html_helper
INFO - 2025-05-03 11:38:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:38:15 --> Controller Class Initialized
INFO - 2025-05-03 19:38:15 --> Model "UserModel" initialized
INFO - 2025-05-03 11:39:31 --> Config Class Initialized
INFO - 2025-05-03 11:39:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:39:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:39:31 --> Utf8 Class Initialized
INFO - 2025-05-03 11:39:31 --> URI Class Initialized
INFO - 2025-05-03 11:39:31 --> Router Class Initialized
INFO - 2025-05-03 11:39:31 --> Output Class Initialized
INFO - 2025-05-03 11:39:31 --> Security Class Initialized
DEBUG - 2025-05-03 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:39:31 --> Input Class Initialized
INFO - 2025-05-03 11:39:31 --> Language Class Initialized
INFO - 2025-05-03 11:39:31 --> Loader Class Initialized
INFO - 2025-05-03 11:39:31 --> Helper loaded: url_helper
INFO - 2025-05-03 11:39:31 --> Helper loaded: string_helper
INFO - 2025-05-03 11:39:31 --> Helper loaded: form_helper
INFO - 2025-05-03 11:39:31 --> Helper loaded: file_helper
INFO - 2025-05-03 11:39:31 --> Helper loaded: html_helper
INFO - 2025-05-03 11:39:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:39:31 --> Controller Class Initialized
INFO - 2025-05-03 19:39:31 --> Model "UserModel" initialized
INFO - 2025-05-03 11:41:52 --> Config Class Initialized
INFO - 2025-05-03 11:41:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:41:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:41:52 --> Utf8 Class Initialized
INFO - 2025-05-03 11:41:52 --> URI Class Initialized
INFO - 2025-05-03 11:41:52 --> Router Class Initialized
INFO - 2025-05-03 11:41:52 --> Output Class Initialized
INFO - 2025-05-03 11:41:52 --> Security Class Initialized
DEBUG - 2025-05-03 11:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:41:52 --> Input Class Initialized
INFO - 2025-05-03 11:41:52 --> Language Class Initialized
INFO - 2025-05-03 11:41:53 --> Loader Class Initialized
INFO - 2025-05-03 11:41:53 --> Helper loaded: url_helper
INFO - 2025-05-03 11:41:53 --> Helper loaded: string_helper
INFO - 2025-05-03 11:41:53 --> Helper loaded: form_helper
INFO - 2025-05-03 11:41:53 --> Helper loaded: file_helper
INFO - 2025-05-03 11:41:53 --> Helper loaded: html_helper
INFO - 2025-05-03 11:41:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:41:53 --> Controller Class Initialized
INFO - 2025-05-03 19:41:53 --> Model "UserModel" initialized
ERROR - 2025-05-03 19:41:53 --> Query error: Column 'first_name' cannot be null - Invalid query: INSERT INTO `tbl_users` (`first_name`, `last_name`, `created_at`, `updated_at`) VALUES (NULL, NULL, '2025-05-03 19:41:53', '2025-05-03 19:41:53')
INFO - 2025-05-03 19:41:53 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-03 11:45:57 --> Config Class Initialized
INFO - 2025-05-03 11:45:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:57 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:57 --> URI Class Initialized
INFO - 2025-05-03 11:45:57 --> Router Class Initialized
INFO - 2025-05-03 11:45:57 --> Output Class Initialized
INFO - 2025-05-03 11:45:57 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:57 --> Input Class Initialized
INFO - 2025-05-03 11:45:57 --> Language Class Initialized
INFO - 2025-05-03 11:45:57 --> Loader Class Initialized
INFO - 2025-05-03 11:45:57 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:57 --> Helper loaded: string_helper
INFO - 2025-05-03 11:45:57 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:57 --> Helper loaded: file_helper
INFO - 2025-05-03 11:45:57 --> Helper loaded: html_helper
INFO - 2025-05-03 11:45:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:57 --> Controller Class Initialized
INFO - 2025-05-03 19:45:57 --> Model "UserModel" initialized
INFO - 2025-05-03 11:45:58 --> Config Class Initialized
INFO - 2025-05-03 11:45:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:58 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:58 --> URI Class Initialized
DEBUG - 2025-05-03 11:45:58 --> No URI present. Default controller set.
INFO - 2025-05-03 11:45:58 --> Router Class Initialized
INFO - 2025-05-03 11:45:58 --> Output Class Initialized
INFO - 2025-05-03 11:45:58 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:58 --> Input Class Initialized
INFO - 2025-05-03 11:45:58 --> Language Class Initialized
INFO - 2025-05-03 11:45:58 --> Loader Class Initialized
INFO - 2025-05-03 11:45:58 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:58 --> Helper loaded: string_helper
INFO - 2025-05-03 11:45:58 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:58 --> Helper loaded: file_helper
INFO - 2025-05-03 11:45:58 --> Helper loaded: html_helper
INFO - 2025-05-03 11:45:58 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:58 --> Controller Class Initialized
INFO - 2025-05-03 11:45:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 11:45:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 11:45:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 11:45:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 11:45:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 11:45:58 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:58 --> Total execution time: 0.1746
INFO - 2025-05-03 11:46:01 --> Config Class Initialized
INFO - 2025-05-03 11:46:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:02 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:02 --> URI Class Initialized
INFO - 2025-05-03 11:46:02 --> Router Class Initialized
INFO - 2025-05-03 11:46:02 --> Output Class Initialized
INFO - 2025-05-03 11:46:02 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:02 --> Input Class Initialized
INFO - 2025-05-03 11:46:02 --> Language Class Initialized
INFO - 2025-05-03 11:46:02 --> Loader Class Initialized
INFO - 2025-05-03 11:46:02 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:02 --> Helper loaded: string_helper
INFO - 2025-05-03 11:46:02 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:02 --> Helper loaded: file_helper
INFO - 2025-05-03 11:46:02 --> Helper loaded: html_helper
INFO - 2025-05-03 11:46:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:02 --> Controller Class Initialized
INFO - 2025-05-03 11:46:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 11:46:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 11:46:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 11:46:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 11:46:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 11:46:02 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:02 --> Total execution time: 0.3169
INFO - 2025-05-03 11:46:04 --> Config Class Initialized
INFO - 2025-05-03 11:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:04 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:04 --> URI Class Initialized
INFO - 2025-05-03 11:46:04 --> Router Class Initialized
INFO - 2025-05-03 11:46:04 --> Output Class Initialized
INFO - 2025-05-03 11:46:04 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:04 --> Input Class Initialized
INFO - 2025-05-03 11:46:04 --> Language Class Initialized
INFO - 2025-05-03 11:46:04 --> Loader Class Initialized
INFO - 2025-05-03 11:46:04 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: string_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: file_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: html_helper
INFO - 2025-05-03 11:46:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:04 --> Controller Class Initialized
INFO - 2025-05-03 11:46:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 11:46:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 11:46:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-03 11:46:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 11:46:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 11:46:04 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:04 --> Total execution time: 0.1806
INFO - 2025-05-03 11:46:04 --> Config Class Initialized
INFO - 2025-05-03 11:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:04 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:04 --> URI Class Initialized
INFO - 2025-05-03 11:46:04 --> Router Class Initialized
INFO - 2025-05-03 11:46:04 --> Output Class Initialized
INFO - 2025-05-03 11:46:04 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:04 --> Input Class Initialized
INFO - 2025-05-03 11:46:04 --> Language Class Initialized
INFO - 2025-05-03 11:46:04 --> Loader Class Initialized
INFO - 2025-05-03 11:46:04 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: string_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: file_helper
INFO - 2025-05-03 11:46:04 --> Helper loaded: html_helper
INFO - 2025-05-03 11:46:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:04 --> Controller Class Initialized
INFO - 2025-05-03 19:46:04 --> Model "AuctionModel" initialized
INFO - 2025-05-03 19:46:04 --> Final output sent to browser
DEBUG - 2025-05-03 19:46:04 --> Total execution time: 0.1754
INFO - 2025-05-03 11:46:06 --> Config Class Initialized
INFO - 2025-05-03 11:46:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:06 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:06 --> URI Class Initialized
INFO - 2025-05-03 11:46:06 --> Router Class Initialized
INFO - 2025-05-03 11:46:06 --> Output Class Initialized
INFO - 2025-05-03 11:46:06 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:06 --> Input Class Initialized
INFO - 2025-05-03 11:46:06 --> Language Class Initialized
INFO - 2025-05-03 11:46:06 --> Loader Class Initialized
INFO - 2025-05-03 11:46:07 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:07 --> Helper loaded: string_helper
INFO - 2025-05-03 11:46:07 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:07 --> Helper loaded: file_helper
INFO - 2025-05-03 11:46:07 --> Helper loaded: html_helper
INFO - 2025-05-03 11:46:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:07 --> Controller Class Initialized
INFO - 2025-05-03 19:46:07 --> Model "UserModel" initialized
INFO - 2025-05-03 19:46:07 --> Final output sent to browser
DEBUG - 2025-05-03 19:46:07 --> Total execution time: 0.3080
INFO - 2025-05-03 11:49:49 --> Config Class Initialized
INFO - 2025-05-03 11:49:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:49:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:49:49 --> Utf8 Class Initialized
INFO - 2025-05-03 11:49:49 --> URI Class Initialized
INFO - 2025-05-03 11:49:49 --> Router Class Initialized
INFO - 2025-05-03 11:49:49 --> Output Class Initialized
INFO - 2025-05-03 11:49:49 --> Security Class Initialized
DEBUG - 2025-05-03 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:49:49 --> Input Class Initialized
INFO - 2025-05-03 11:49:49 --> Language Class Initialized
INFO - 2025-05-03 11:49:49 --> Loader Class Initialized
INFO - 2025-05-03 11:49:49 --> Helper loaded: url_helper
INFO - 2025-05-03 11:49:49 --> Helper loaded: string_helper
INFO - 2025-05-03 11:49:49 --> Helper loaded: form_helper
INFO - 2025-05-03 11:49:49 --> Helper loaded: file_helper
INFO - 2025-05-03 11:49:49 --> Helper loaded: html_helper
INFO - 2025-05-03 11:49:49 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:49:49 --> Controller Class Initialized
INFO - 2025-05-03 19:49:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:49:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:49:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:49:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:49:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:49:49 --> Final output sent to browser
DEBUG - 2025-05-03 19:49:49 --> Total execution time: 0.1670
INFO - 2025-05-03 11:51:36 --> Config Class Initialized
INFO - 2025-05-03 11:51:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:51:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:51:36 --> Utf8 Class Initialized
INFO - 2025-05-03 11:51:36 --> URI Class Initialized
INFO - 2025-05-03 11:51:36 --> Router Class Initialized
INFO - 2025-05-03 11:51:36 --> Output Class Initialized
INFO - 2025-05-03 11:51:36 --> Security Class Initialized
DEBUG - 2025-05-03 11:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:51:36 --> Input Class Initialized
INFO - 2025-05-03 11:51:36 --> Language Class Initialized
INFO - 2025-05-03 11:51:36 --> Loader Class Initialized
INFO - 2025-05-03 11:51:36 --> Helper loaded: url_helper
INFO - 2025-05-03 11:51:36 --> Helper loaded: string_helper
INFO - 2025-05-03 11:51:36 --> Helper loaded: form_helper
INFO - 2025-05-03 11:51:36 --> Helper loaded: file_helper
INFO - 2025-05-03 11:51:36 --> Helper loaded: html_helper
INFO - 2025-05-03 11:51:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:51:36 --> Controller Class Initialized
INFO - 2025-05-03 19:51:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:51:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:51:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:51:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:51:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:51:36 --> Final output sent to browser
DEBUG - 2025-05-03 19:51:36 --> Total execution time: 0.1829
INFO - 2025-05-03 11:53:06 --> Config Class Initialized
INFO - 2025-05-03 11:53:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:53:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:53:06 --> Utf8 Class Initialized
INFO - 2025-05-03 11:53:06 --> URI Class Initialized
INFO - 2025-05-03 11:53:06 --> Router Class Initialized
INFO - 2025-05-03 11:53:06 --> Output Class Initialized
INFO - 2025-05-03 11:53:06 --> Security Class Initialized
DEBUG - 2025-05-03 11:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:53:06 --> Input Class Initialized
INFO - 2025-05-03 11:53:06 --> Language Class Initialized
INFO - 2025-05-03 11:53:06 --> Loader Class Initialized
INFO - 2025-05-03 11:53:06 --> Helper loaded: url_helper
INFO - 2025-05-03 11:53:06 --> Helper loaded: string_helper
INFO - 2025-05-03 11:53:06 --> Helper loaded: form_helper
INFO - 2025-05-03 11:53:06 --> Helper loaded: file_helper
INFO - 2025-05-03 11:53:06 --> Helper loaded: html_helper
INFO - 2025-05-03 11:53:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:53:06 --> Controller Class Initialized
INFO - 2025-05-03 19:53:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:53:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:53:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:53:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:53:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:53:06 --> Final output sent to browser
DEBUG - 2025-05-03 19:53:06 --> Total execution time: 0.1710
INFO - 2025-05-03 11:55:26 --> Config Class Initialized
INFO - 2025-05-03 11:55:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:26 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:27 --> URI Class Initialized
INFO - 2025-05-03 11:55:27 --> Router Class Initialized
INFO - 2025-05-03 11:55:27 --> Output Class Initialized
INFO - 2025-05-03 11:55:27 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:27 --> Input Class Initialized
INFO - 2025-05-03 11:55:27 --> Language Class Initialized
INFO - 2025-05-03 11:55:27 --> Loader Class Initialized
INFO - 2025-05-03 11:55:27 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:27 --> Helper loaded: string_helper
INFO - 2025-05-03 11:55:27 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:27 --> Helper loaded: file_helper
INFO - 2025-05-03 11:55:27 --> Helper loaded: html_helper
INFO - 2025-05-03 11:55:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:27 --> Controller Class Initialized
INFO - 2025-05-03 19:55:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:55:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:55:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:55:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:55:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:55:27 --> Final output sent to browser
DEBUG - 2025-05-03 19:55:27 --> Total execution time: 0.1847
INFO - 2025-05-03 11:55:54 --> Config Class Initialized
INFO - 2025-05-03 11:55:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:54 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:54 --> URI Class Initialized
INFO - 2025-05-03 11:55:54 --> Router Class Initialized
INFO - 2025-05-03 11:55:54 --> Output Class Initialized
INFO - 2025-05-03 11:55:54 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:54 --> Input Class Initialized
INFO - 2025-05-03 11:55:54 --> Language Class Initialized
INFO - 2025-05-03 11:55:55 --> Loader Class Initialized
INFO - 2025-05-03 11:55:55 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:55 --> Helper loaded: string_helper
INFO - 2025-05-03 11:55:55 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:55 --> Helper loaded: file_helper
INFO - 2025-05-03 11:55:55 --> Helper loaded: html_helper
INFO - 2025-05-03 11:55:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:55 --> Controller Class Initialized
INFO - 2025-05-03 19:55:55 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:55:55 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:55:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:56:02 --> Final output sent to browser
DEBUG - 2025-05-03 19:56:02 --> Total execution time: 7.2364
INFO - 2025-05-03 11:57:11 --> Config Class Initialized
INFO - 2025-05-03 11:57:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:11 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:11 --> URI Class Initialized
INFO - 2025-05-03 11:57:11 --> Router Class Initialized
INFO - 2025-05-03 11:57:11 --> Output Class Initialized
INFO - 2025-05-03 11:57:11 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:11 --> Input Class Initialized
INFO - 2025-05-03 11:57:11 --> Language Class Initialized
INFO - 2025-05-03 11:57:11 --> Loader Class Initialized
INFO - 2025-05-03 11:57:11 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:11 --> Helper loaded: string_helper
INFO - 2025-05-03 11:57:11 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:11 --> Helper loaded: file_helper
INFO - 2025-05-03 11:57:11 --> Helper loaded: html_helper
INFO - 2025-05-03 11:57:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:11 --> Controller Class Initialized
INFO - 2025-05-03 19:57:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:57:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:57:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:57:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:57:12 --> Final output sent to browser
DEBUG - 2025-05-03 19:57:12 --> Total execution time: 0.1581
INFO - 2025-05-03 11:57:39 --> Config Class Initialized
INFO - 2025-05-03 11:57:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:39 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:39 --> URI Class Initialized
INFO - 2025-05-03 11:57:39 --> Router Class Initialized
INFO - 2025-05-03 11:57:39 --> Output Class Initialized
INFO - 2025-05-03 11:57:39 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:39 --> Input Class Initialized
INFO - 2025-05-03 11:57:39 --> Language Class Initialized
INFO - 2025-05-03 11:57:39 --> Loader Class Initialized
INFO - 2025-05-03 11:57:39 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: string_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: file_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: html_helper
INFO - 2025-05-03 11:57:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:39 --> Controller Class Initialized
INFO - 2025-05-03 19:57:39 --> Model "UserModel" initialized
DEBUG - 2025-05-03 19:57:39 --> PHPMailer class is loaded.
INFO - 2025-05-03 19:57:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 19:57:44 --> Final output sent to browser
DEBUG - 2025-05-03 19:57:44 --> Total execution time: 4.4996
INFO - 2025-05-03 11:58:35 --> Config Class Initialized
INFO - 2025-05-03 11:58:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:58:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:58:35 --> Utf8 Class Initialized
INFO - 2025-05-03 11:58:35 --> URI Class Initialized
INFO - 2025-05-03 11:58:35 --> Router Class Initialized
INFO - 2025-05-03 11:58:35 --> Output Class Initialized
INFO - 2025-05-03 11:58:35 --> Security Class Initialized
DEBUG - 2025-05-03 11:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:58:35 --> Input Class Initialized
INFO - 2025-05-03 11:58:35 --> Language Class Initialized
INFO - 2025-05-03 11:58:35 --> Loader Class Initialized
INFO - 2025-05-03 11:58:35 --> Helper loaded: url_helper
INFO - 2025-05-03 11:58:35 --> Helper loaded: string_helper
INFO - 2025-05-03 11:58:35 --> Helper loaded: form_helper
INFO - 2025-05-03 11:58:35 --> Helper loaded: file_helper
INFO - 2025-05-03 11:58:35 --> Helper loaded: html_helper
INFO - 2025-05-03 11:58:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:58:35 --> Controller Class Initialized
INFO - 2025-05-03 19:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:58:35 --> Final output sent to browser
DEBUG - 2025-05-03 19:58:35 --> Total execution time: 0.1329
INFO - 2025-05-03 11:58:49 --> Config Class Initialized
INFO - 2025-05-03 11:58:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:58:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:58:49 --> Utf8 Class Initialized
INFO - 2025-05-03 11:58:49 --> URI Class Initialized
INFO - 2025-05-03 11:58:49 --> Router Class Initialized
INFO - 2025-05-03 11:58:49 --> Output Class Initialized
INFO - 2025-05-03 11:58:49 --> Security Class Initialized
DEBUG - 2025-05-03 11:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:58:49 --> Input Class Initialized
INFO - 2025-05-03 11:58:49 --> Language Class Initialized
INFO - 2025-05-03 11:58:49 --> Loader Class Initialized
INFO - 2025-05-03 11:58:49 --> Helper loaded: url_helper
INFO - 2025-05-03 11:58:49 --> Helper loaded: string_helper
INFO - 2025-05-03 11:58:49 --> Helper loaded: form_helper
INFO - 2025-05-03 11:58:49 --> Helper loaded: file_helper
INFO - 2025-05-03 11:58:49 --> Helper loaded: html_helper
INFO - 2025-05-03 11:58:49 --> Database Driver Class Initialized
DEBUG - 2025-05-03 11:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 11:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:58:49 --> Controller Class Initialized
INFO - 2025-05-03 19:58:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 19:58:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 19:58:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 19:58:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 19:58:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 19:58:49 --> Final output sent to browser
DEBUG - 2025-05-03 19:58:49 --> Total execution time: 0.2206
INFO - 2025-05-03 12:00:02 --> Config Class Initialized
INFO - 2025-05-03 12:00:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:00:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:00:02 --> Utf8 Class Initialized
INFO - 2025-05-03 12:00:02 --> URI Class Initialized
INFO - 2025-05-03 12:00:02 --> Router Class Initialized
INFO - 2025-05-03 12:00:02 --> Output Class Initialized
INFO - 2025-05-03 12:00:02 --> Security Class Initialized
DEBUG - 2025-05-03 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:00:02 --> Input Class Initialized
INFO - 2025-05-03 12:00:02 --> Language Class Initialized
INFO - 2025-05-03 12:00:02 --> Loader Class Initialized
INFO - 2025-05-03 12:00:02 --> Helper loaded: url_helper
INFO - 2025-05-03 12:00:02 --> Helper loaded: string_helper
INFO - 2025-05-03 12:00:02 --> Helper loaded: form_helper
INFO - 2025-05-03 12:00:02 --> Helper loaded: file_helper
INFO - 2025-05-03 12:00:02 --> Helper loaded: html_helper
INFO - 2025-05-03 12:00:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:00:02 --> Controller Class Initialized
INFO - 2025-05-03 20:00:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 20:00:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 20:00:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 20:00:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 20:00:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 20:00:02 --> Final output sent to browser
DEBUG - 2025-05-03 20:00:02 --> Total execution time: 0.1506
INFO - 2025-05-03 12:00:40 --> Config Class Initialized
INFO - 2025-05-03 12:00:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:00:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:00:40 --> Utf8 Class Initialized
INFO - 2025-05-03 12:00:40 --> URI Class Initialized
INFO - 2025-05-03 12:00:40 --> Router Class Initialized
INFO - 2025-05-03 12:00:40 --> Output Class Initialized
INFO - 2025-05-03 12:00:40 --> Security Class Initialized
DEBUG - 2025-05-03 12:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:00:40 --> Input Class Initialized
INFO - 2025-05-03 12:00:40 --> Language Class Initialized
INFO - 2025-05-03 12:00:40 --> Loader Class Initialized
INFO - 2025-05-03 12:00:40 --> Helper loaded: url_helper
INFO - 2025-05-03 12:00:40 --> Helper loaded: string_helper
INFO - 2025-05-03 12:00:40 --> Helper loaded: form_helper
INFO - 2025-05-03 12:00:40 --> Helper loaded: file_helper
INFO - 2025-05-03 12:00:40 --> Helper loaded: html_helper
INFO - 2025-05-03 12:00:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:00:40 --> Controller Class Initialized
INFO - 2025-05-03 20:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 20:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 20:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 20:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 20:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 20:00:40 --> Final output sent to browser
DEBUG - 2025-05-03 20:00:40 --> Total execution time: 0.1446
INFO - 2025-05-03 12:01:09 --> Config Class Initialized
INFO - 2025-05-03 12:01:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:01:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:01:09 --> Utf8 Class Initialized
INFO - 2025-05-03 12:01:09 --> URI Class Initialized
INFO - 2025-05-03 12:01:09 --> Router Class Initialized
INFO - 2025-05-03 12:01:09 --> Output Class Initialized
INFO - 2025-05-03 12:01:09 --> Security Class Initialized
DEBUG - 2025-05-03 12:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:01:09 --> Input Class Initialized
INFO - 2025-05-03 12:01:09 --> Language Class Initialized
INFO - 2025-05-03 12:01:09 --> Loader Class Initialized
INFO - 2025-05-03 12:01:09 --> Helper loaded: url_helper
INFO - 2025-05-03 12:01:10 --> Helper loaded: string_helper
INFO - 2025-05-03 12:01:10 --> Helper loaded: form_helper
INFO - 2025-05-03 12:01:10 --> Helper loaded: file_helper
INFO - 2025-05-03 12:01:10 --> Helper loaded: html_helper
INFO - 2025-05-03 12:01:10 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:01:10 --> Controller Class Initialized
INFO - 2025-05-03 20:01:10 --> Model "UserModel" initialized
DEBUG - 2025-05-03 20:01:10 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:01:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 20:01:17 --> Final output sent to browser
DEBUG - 2025-05-03 20:01:17 --> Total execution time: 7.9131
INFO - 2025-05-03 12:01:34 --> Config Class Initialized
INFO - 2025-05-03 12:01:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:01:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:01:34 --> Utf8 Class Initialized
INFO - 2025-05-03 12:01:34 --> URI Class Initialized
INFO - 2025-05-03 12:01:34 --> Router Class Initialized
INFO - 2025-05-03 12:01:34 --> Output Class Initialized
INFO - 2025-05-03 12:01:34 --> Security Class Initialized
DEBUG - 2025-05-03 12:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:01:34 --> Input Class Initialized
INFO - 2025-05-03 12:01:34 --> Language Class Initialized
INFO - 2025-05-03 12:01:34 --> Loader Class Initialized
INFO - 2025-05-03 12:01:34 --> Helper loaded: url_helper
INFO - 2025-05-03 12:01:34 --> Helper loaded: string_helper
INFO - 2025-05-03 12:01:34 --> Helper loaded: form_helper
INFO - 2025-05-03 12:01:34 --> Helper loaded: file_helper
INFO - 2025-05-03 12:01:34 --> Helper loaded: html_helper
INFO - 2025-05-03 12:01:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:01:34 --> Controller Class Initialized
INFO - 2025-05-03 20:01:34 --> Model "UserModel" initialized
INFO - 2025-05-03 20:01:34 --> Final output sent to browser
DEBUG - 2025-05-03 20:01:34 --> Total execution time: 0.2085
INFO - 2025-05-03 12:01:44 --> Config Class Initialized
INFO - 2025-05-03 12:01:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:01:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:01:44 --> Utf8 Class Initialized
INFO - 2025-05-03 12:01:44 --> URI Class Initialized
INFO - 2025-05-03 12:01:44 --> Router Class Initialized
INFO - 2025-05-03 12:01:44 --> Output Class Initialized
INFO - 2025-05-03 12:01:44 --> Security Class Initialized
DEBUG - 2025-05-03 12:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:01:44 --> Input Class Initialized
INFO - 2025-05-03 12:01:44 --> Language Class Initialized
INFO - 2025-05-03 12:01:44 --> Loader Class Initialized
INFO - 2025-05-03 12:01:44 --> Helper loaded: url_helper
INFO - 2025-05-03 12:01:44 --> Helper loaded: string_helper
INFO - 2025-05-03 12:01:44 --> Helper loaded: form_helper
INFO - 2025-05-03 12:01:44 --> Helper loaded: file_helper
INFO - 2025-05-03 12:01:44 --> Helper loaded: html_helper
INFO - 2025-05-03 12:01:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:01:44 --> Controller Class Initialized
INFO - 2025-05-03 20:01:44 --> Model "UserModel" initialized
INFO - 2025-05-03 20:01:44 --> Final output sent to browser
DEBUG - 2025-05-03 20:01:44 --> Total execution time: 0.0943
INFO - 2025-05-03 12:01:47 --> Config Class Initialized
INFO - 2025-05-03 12:01:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:01:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:01:47 --> Utf8 Class Initialized
INFO - 2025-05-03 12:01:47 --> URI Class Initialized
INFO - 2025-05-03 12:01:47 --> Router Class Initialized
INFO - 2025-05-03 12:01:47 --> Output Class Initialized
INFO - 2025-05-03 12:01:47 --> Security Class Initialized
DEBUG - 2025-05-03 12:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:01:47 --> Input Class Initialized
INFO - 2025-05-03 12:01:47 --> Language Class Initialized
INFO - 2025-05-03 12:01:47 --> Loader Class Initialized
INFO - 2025-05-03 12:01:47 --> Helper loaded: url_helper
INFO - 2025-05-03 12:01:47 --> Helper loaded: string_helper
INFO - 2025-05-03 12:01:47 --> Helper loaded: form_helper
INFO - 2025-05-03 12:01:47 --> Helper loaded: file_helper
INFO - 2025-05-03 12:01:47 --> Helper loaded: html_helper
INFO - 2025-05-03 12:01:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:01:47 --> Controller Class Initialized
INFO - 2025-05-03 20:01:47 --> Model "UserModel" initialized
ERROR - 2025-05-03 20:01:47 --> Query error: Unknown column 'roleId' in 'field list' - Invalid query: INSERT INTO `tbl_user_role_relationship` (`roleId`, `user_id`, `created_at`, `updated_at`) VALUES (2, 8, '2025-05-03 20:01:47', '2025-05-03 20:01:47')
DEBUG - 2025-05-03 20:01:47 --> DB Transaction Failure
INFO - 2025-05-03 20:01:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-03 12:02:54 --> Config Class Initialized
INFO - 2025-05-03 12:02:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:02:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:02:54 --> Utf8 Class Initialized
INFO - 2025-05-03 12:02:54 --> URI Class Initialized
INFO - 2025-05-03 12:02:54 --> Router Class Initialized
INFO - 2025-05-03 12:02:54 --> Output Class Initialized
INFO - 2025-05-03 12:02:54 --> Security Class Initialized
DEBUG - 2025-05-03 12:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:02:54 --> Input Class Initialized
INFO - 2025-05-03 12:02:54 --> Language Class Initialized
INFO - 2025-05-03 12:02:54 --> Loader Class Initialized
INFO - 2025-05-03 12:02:54 --> Helper loaded: url_helper
INFO - 2025-05-03 12:02:54 --> Helper loaded: string_helper
INFO - 2025-05-03 12:02:54 --> Helper loaded: form_helper
INFO - 2025-05-03 12:02:54 --> Helper loaded: file_helper
INFO - 2025-05-03 12:02:54 --> Helper loaded: html_helper
INFO - 2025-05-03 12:02:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:02:54 --> Controller Class Initialized
INFO - 2025-05-03 20:02:54 --> Model "UserModel" initialized
INFO - 2025-05-03 12:02:57 --> Config Class Initialized
INFO - 2025-05-03 12:02:57 --> Helper loaded: html_helper
INFO - 2025-05-03 12:02:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:02:57 --> Controller Class Initialized
INFO - 2025-05-03 20:02:57 --> Model "UserModel" initialized
INFO - 2025-05-03 20:02:57 --> Final output sent to browser
DEBUG - 2025-05-03 20:02:57 --> Total execution time: 0.1114
INFO - 2025-05-03 12:03:06 --> Config Class Initialized
INFO - 2025-05-03 12:03:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:03:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:03:06 --> Utf8 Class Initialized
INFO - 2025-05-03 12:03:06 --> URI Class Initialized
INFO - 2025-05-03 12:03:06 --> Router Class Initialized
INFO - 2025-05-03 12:03:06 --> Output Class Initialized
INFO - 2025-05-03 12:03:06 --> Security Class Initialized
DEBUG - 2025-05-03 12:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:03:06 --> Input Class Initialized
INFO - 2025-05-03 12:03:06 --> Language Class Initialized
INFO - 2025-05-03 12:03:06 --> Loader Class Initialized
INFO - 2025-05-03 12:03:06 --> Helper loaded: url_helper
INFO - 2025-05-03 12:03:06 --> Helper loaded: string_helper
INFO - 2025-05-03 12:03:06 --> Helper loaded: form_helper
INFO - 2025-05-03 12:03:06 --> Helper loaded: file_helper
INFO - 2025-05-03 12:03:06 --> Helper loaded: html_helper
INFO - 2025-05-03 12:03:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:03:06 --> Controller Class Initialized
INFO - 2025-05-03 20:03:06 --> Model "UserModel" initialized
ERROR - 2025-05-03 20:03:06 --> Query error: Unknown column 'cell_phone' in 'field list' - Invalid query: INSERT INTO `tbl_locations` (`street_address`, `apt_suite`, `city`, `postal_code`, `state`, `country`, `cell_phone`, `created_at`, `updated_at`) VALUES ('Full Street Address', '', 'City Name', '123456', 'South Australia', 'Australia', '(123) 456-7890', '2025-05-03 20:03:06', '2025-05-03 20:03:06')
DEBUG - 2025-05-03 20:03:06 --> DB Transaction Failure
INFO - 2025-05-03 20:03:06 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-03 12:27:35 --> Config Class Initialized
INFO - 2025-05-03 12:27:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:27:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:27:35 --> Utf8 Class Initialized
INFO - 2025-05-03 12:27:35 --> URI Class Initialized
INFO - 2025-05-03 12:27:35 --> Router Class Initialized
INFO - 2025-05-03 12:27:35 --> Output Class Initialized
INFO - 2025-05-03 12:27:35 --> Security Class Initialized
DEBUG - 2025-05-03 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:27:35 --> Input Class Initialized
INFO - 2025-05-03 12:27:35 --> Language Class Initialized
INFO - 2025-05-03 12:27:35 --> Loader Class Initialized
INFO - 2025-05-03 12:27:35 --> Helper loaded: url_helper
INFO - 2025-05-03 12:27:35 --> Helper loaded: string_helper
INFO - 2025-05-03 12:27:35 --> Helper loaded: form_helper
INFO - 2025-05-03 12:27:35 --> Helper loaded: file_helper
INFO - 2025-05-03 12:27:35 --> Helper loaded: html_helper
INFO - 2025-05-03 12:27:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:27:35 --> Controller Class Initialized
INFO - 2025-05-03 20:27:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 20:27:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 20:27:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 20:27:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 20:27:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 20:27:35 --> Final output sent to browser
DEBUG - 2025-05-03 20:27:35 --> Total execution time: 0.2210
INFO - 2025-05-03 12:28:09 --> Config Class Initialized
INFO - 2025-05-03 12:28:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:28:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:28:09 --> Utf8 Class Initialized
INFO - 2025-05-03 12:28:09 --> URI Class Initialized
INFO - 2025-05-03 12:28:09 --> Router Class Initialized
INFO - 2025-05-03 12:28:09 --> Output Class Initialized
INFO - 2025-05-03 12:28:09 --> Security Class Initialized
DEBUG - 2025-05-03 12:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:28:09 --> Input Class Initialized
INFO - 2025-05-03 12:28:09 --> Language Class Initialized
INFO - 2025-05-03 12:28:09 --> Loader Class Initialized
INFO - 2025-05-03 12:28:09 --> Helper loaded: url_helper
INFO - 2025-05-03 12:28:09 --> Helper loaded: string_helper
INFO - 2025-05-03 12:28:09 --> Helper loaded: form_helper
INFO - 2025-05-03 12:28:09 --> Helper loaded: file_helper
INFO - 2025-05-03 12:28:09 --> Helper loaded: html_helper
INFO - 2025-05-03 12:28:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:28:09 --> Controller Class Initialized
INFO - 2025-05-03 20:28:09 --> Model "UserModel" initialized
DEBUG - 2025-05-03 20:28:09 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:28:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 20:28:14 --> Final output sent to browser
DEBUG - 2025-05-03 20:28:14 --> Total execution time: 4.6611
INFO - 2025-05-03 12:28:21 --> Config Class Initialized
INFO - 2025-05-03 12:28:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:28:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:28:21 --> Utf8 Class Initialized
INFO - 2025-05-03 12:28:21 --> URI Class Initialized
INFO - 2025-05-03 12:28:21 --> Router Class Initialized
INFO - 2025-05-03 12:28:21 --> Output Class Initialized
INFO - 2025-05-03 12:28:21 --> Security Class Initialized
DEBUG - 2025-05-03 12:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:28:21 --> Input Class Initialized
INFO - 2025-05-03 12:28:21 --> Language Class Initialized
INFO - 2025-05-03 12:28:21 --> Loader Class Initialized
INFO - 2025-05-03 12:28:21 --> Helper loaded: url_helper
INFO - 2025-05-03 12:28:21 --> Helper loaded: string_helper
INFO - 2025-05-03 12:28:21 --> Helper loaded: form_helper
INFO - 2025-05-03 12:28:21 --> Helper loaded: file_helper
INFO - 2025-05-03 12:28:21 --> Helper loaded: html_helper
INFO - 2025-05-03 12:28:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:28:21 --> Controller Class Initialized
INFO - 2025-05-03 20:28:21 --> Model "UserModel" initialized
INFO - 2025-05-03 20:28:21 --> Final output sent to browser
DEBUG - 2025-05-03 20:28:21 --> Total execution time: 0.2090
INFO - 2025-05-03 12:28:45 --> Config Class Initialized
INFO - 2025-05-03 12:28:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:28:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:28:45 --> Utf8 Class Initialized
INFO - 2025-05-03 12:28:45 --> URI Class Initialized
INFO - 2025-05-03 12:28:45 --> Router Class Initialized
INFO - 2025-05-03 12:28:45 --> Output Class Initialized
INFO - 2025-05-03 12:28:45 --> Security Class Initialized
DEBUG - 2025-05-03 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:28:45 --> Input Class Initialized
INFO - 2025-05-03 12:28:45 --> Language Class Initialized
INFO - 2025-05-03 12:28:45 --> Loader Class Initialized
INFO - 2025-05-03 12:28:45 --> Helper loaded: url_helper
INFO - 2025-05-03 12:28:45 --> Helper loaded: string_helper
INFO - 2025-05-03 12:28:45 --> Helper loaded: form_helper
INFO - 2025-05-03 12:28:45 --> Helper loaded: file_helper
INFO - 2025-05-03 12:28:45 --> Helper loaded: html_helper
INFO - 2025-05-03 12:28:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:28:45 --> Controller Class Initialized
INFO - 2025-05-03 20:28:45 --> Model "UserModel" initialized
INFO - 2025-05-03 20:28:45 --> Final output sent to browser
DEBUG - 2025-05-03 20:28:45 --> Total execution time: 0.1401
INFO - 2025-05-03 12:37:21 --> Config Class Initialized
INFO - 2025-05-03 12:37:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:37:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:37:21 --> Utf8 Class Initialized
INFO - 2025-05-03 12:37:21 --> URI Class Initialized
INFO - 2025-05-03 12:37:21 --> Router Class Initialized
INFO - 2025-05-03 12:37:21 --> Output Class Initialized
INFO - 2025-05-03 12:37:21 --> Security Class Initialized
DEBUG - 2025-05-03 12:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:37:21 --> Input Class Initialized
INFO - 2025-05-03 12:37:21 --> Language Class Initialized
INFO - 2025-05-03 12:37:21 --> Loader Class Initialized
INFO - 2025-05-03 12:37:21 --> Helper loaded: url_helper
INFO - 2025-05-03 12:37:21 --> Helper loaded: string_helper
INFO - 2025-05-03 12:37:21 --> Helper loaded: form_helper
INFO - 2025-05-03 12:37:21 --> Helper loaded: file_helper
INFO - 2025-05-03 12:37:21 --> Helper loaded: html_helper
INFO - 2025-05-03 12:37:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:37:21 --> Controller Class Initialized
INFO - 2025-05-03 20:37:21 --> Model "UserModel" initialized
INFO - 2025-05-03 12:37:22 --> Config Class Initialized
INFO - 2025-05-03 12:37:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:37:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:37:22 --> Utf8 Class Initialized
INFO - 2025-05-03 12:37:22 --> URI Class Initialized
INFO - 2025-05-03 12:37:22 --> Router Class Initialized
INFO - 2025-05-03 12:37:22 --> Output Class Initialized
INFO - 2025-05-03 12:37:22 --> Security Class Initialized
DEBUG - 2025-05-03 12:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:37:22 --> Input Class Initialized
INFO - 2025-05-03 12:37:22 --> Language Class Initialized
INFO - 2025-05-03 12:37:22 --> Loader Class Initialized
INFO - 2025-05-03 12:37:23 --> Helper loaded: url_helper
INFO - 2025-05-03 12:37:23 --> Helper loaded: string_helper
INFO - 2025-05-03 12:37:23 --> Helper loaded: form_helper
INFO - 2025-05-03 12:37:23 --> Helper loaded: file_helper
INFO - 2025-05-03 12:37:23 --> Helper loaded: html_helper
INFO - 2025-05-03 12:37:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:37:23 --> Controller Class Initialized
INFO - 2025-05-03 20:37:23 --> Final output sent to browser
DEBUG - 2025-05-03 20:37:23 --> Total execution time: 0.1743
INFO - 2025-05-03 12:39:16 --> Config Class Initialized
INFO - 2025-05-03 12:39:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:39:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:39:16 --> Utf8 Class Initialized
INFO - 2025-05-03 12:39:16 --> URI Class Initialized
INFO - 2025-05-03 12:39:16 --> Router Class Initialized
INFO - 2025-05-03 12:39:16 --> Output Class Initialized
INFO - 2025-05-03 12:39:16 --> Security Class Initialized
DEBUG - 2025-05-03 12:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:39:16 --> Input Class Initialized
INFO - 2025-05-03 12:39:16 --> Language Class Initialized
INFO - 2025-05-03 12:39:16 --> Loader Class Initialized
INFO - 2025-05-03 12:39:16 --> Helper loaded: url_helper
INFO - 2025-05-03 12:39:16 --> Helper loaded: string_helper
INFO - 2025-05-03 12:39:16 --> Helper loaded: form_helper
INFO - 2025-05-03 12:39:16 --> Helper loaded: file_helper
INFO - 2025-05-03 12:39:16 --> Helper loaded: html_helper
INFO - 2025-05-03 12:39:16 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:39:16 --> Controller Class Initialized
INFO - 2025-05-03 20:39:16 --> Model "UserModel" initialized
INFO - 2025-05-03 12:39:17 --> Config Class Initialized
INFO - 2025-05-03 12:39:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:39:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:39:17 --> Utf8 Class Initialized
INFO - 2025-05-03 12:39:17 --> URI Class Initialized
INFO - 2025-05-03 12:39:17 --> Router Class Initialized
INFO - 2025-05-03 12:39:17 --> Output Class Initialized
INFO - 2025-05-03 12:39:17 --> Security Class Initialized
DEBUG - 2025-05-03 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:39:17 --> Input Class Initialized
INFO - 2025-05-03 12:39:17 --> Language Class Initialized
INFO - 2025-05-03 12:39:17 --> Loader Class Initialized
INFO - 2025-05-03 12:39:17 --> Helper loaded: url_helper
INFO - 2025-05-03 12:39:17 --> Helper loaded: string_helper
INFO - 2025-05-03 12:39:17 --> Helper loaded: form_helper
INFO - 2025-05-03 12:39:17 --> Helper loaded: file_helper
INFO - 2025-05-03 12:39:17 --> Helper loaded: html_helper
INFO - 2025-05-03 12:39:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:39:17 --> Controller Class Initialized
INFO - 2025-05-03 20:39:17 --> Model "UserModel" initialized
ERROR - 2025-05-03 20:39:17 --> Severity: Warning --> Attempt to read property "email" on array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 455
ERROR - 2025-05-03 20:39:17 --> Severity: Warning --> Attempt to read property "toName" on array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 458
DEBUG - 2025-05-03 20:39:17 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:39:17 --> Final output sent to browser
DEBUG - 2025-05-03 20:39:17 --> Total execution time: 0.3809
INFO - 2025-05-03 12:41:40 --> Config Class Initialized
INFO - 2025-05-03 12:41:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:41:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:41:40 --> Utf8 Class Initialized
INFO - 2025-05-03 12:41:40 --> URI Class Initialized
INFO - 2025-05-03 12:41:40 --> Router Class Initialized
INFO - 2025-05-03 12:41:40 --> Output Class Initialized
INFO - 2025-05-03 12:41:40 --> Security Class Initialized
DEBUG - 2025-05-03 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:41:40 --> Input Class Initialized
INFO - 2025-05-03 12:41:40 --> Language Class Initialized
INFO - 2025-05-03 12:41:40 --> Loader Class Initialized
INFO - 2025-05-03 12:41:40 --> Helper loaded: url_helper
INFO - 2025-05-03 12:41:40 --> Helper loaded: string_helper
INFO - 2025-05-03 12:41:40 --> Helper loaded: form_helper
INFO - 2025-05-03 12:41:40 --> Helper loaded: file_helper
INFO - 2025-05-03 12:41:40 --> Helper loaded: html_helper
INFO - 2025-05-03 12:41:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:41:40 --> Controller Class Initialized
INFO - 2025-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 20:41:40 --> Final output sent to browser
DEBUG - 2025-05-03 20:41:40 --> Total execution time: 0.1864
INFO - 2025-05-03 12:42:20 --> Config Class Initialized
INFO - 2025-05-03 12:42:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:42:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:42:20 --> Utf8 Class Initialized
INFO - 2025-05-03 12:42:20 --> URI Class Initialized
INFO - 2025-05-03 12:42:20 --> Router Class Initialized
INFO - 2025-05-03 12:42:20 --> Output Class Initialized
INFO - 2025-05-03 12:42:20 --> Security Class Initialized
DEBUG - 2025-05-03 12:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:42:20 --> Input Class Initialized
INFO - 2025-05-03 12:42:20 --> Language Class Initialized
INFO - 2025-05-03 12:42:20 --> Loader Class Initialized
INFO - 2025-05-03 12:42:20 --> Helper loaded: url_helper
INFO - 2025-05-03 12:42:20 --> Helper loaded: string_helper
INFO - 2025-05-03 12:42:20 --> Helper loaded: form_helper
INFO - 2025-05-03 12:42:20 --> Helper loaded: file_helper
INFO - 2025-05-03 12:42:20 --> Helper loaded: html_helper
INFO - 2025-05-03 12:42:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:42:20 --> Controller Class Initialized
INFO - 2025-05-03 20:42:20 --> Model "UserModel" initialized
DEBUG - 2025-05-03 20:42:20 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:42:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 20:42:24 --> Final output sent to browser
DEBUG - 2025-05-03 20:42:24 --> Total execution time: 4.7176
INFO - 2025-05-03 12:42:34 --> Config Class Initialized
INFO - 2025-05-03 12:42:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:42:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:42:34 --> Utf8 Class Initialized
INFO - 2025-05-03 12:42:34 --> URI Class Initialized
INFO - 2025-05-03 12:42:34 --> Router Class Initialized
INFO - 2025-05-03 12:42:34 --> Output Class Initialized
INFO - 2025-05-03 12:42:34 --> Security Class Initialized
DEBUG - 2025-05-03 12:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:42:34 --> Input Class Initialized
INFO - 2025-05-03 12:42:34 --> Language Class Initialized
INFO - 2025-05-03 12:42:34 --> Loader Class Initialized
INFO - 2025-05-03 12:42:34 --> Helper loaded: url_helper
INFO - 2025-05-03 12:42:34 --> Helper loaded: string_helper
INFO - 2025-05-03 12:42:34 --> Helper loaded: form_helper
INFO - 2025-05-03 12:42:34 --> Helper loaded: file_helper
INFO - 2025-05-03 12:42:34 --> Helper loaded: html_helper
INFO - 2025-05-03 12:42:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:42:34 --> Controller Class Initialized
INFO - 2025-05-03 20:42:34 --> Model "UserModel" initialized
INFO - 2025-05-03 20:42:34 --> Final output sent to browser
DEBUG - 2025-05-03 20:42:34 --> Total execution time: 0.1480
INFO - 2025-05-03 12:42:55 --> Config Class Initialized
INFO - 2025-05-03 12:42:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:42:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:42:55 --> Utf8 Class Initialized
INFO - 2025-05-03 12:42:55 --> URI Class Initialized
INFO - 2025-05-03 12:42:55 --> Router Class Initialized
INFO - 2025-05-03 12:42:55 --> Output Class Initialized
INFO - 2025-05-03 12:42:55 --> Security Class Initialized
DEBUG - 2025-05-03 12:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:42:55 --> Input Class Initialized
INFO - 2025-05-03 12:42:55 --> Language Class Initialized
INFO - 2025-05-03 12:42:55 --> Loader Class Initialized
INFO - 2025-05-03 12:42:55 --> Helper loaded: url_helper
INFO - 2025-05-03 12:42:55 --> Helper loaded: string_helper
INFO - 2025-05-03 12:42:55 --> Helper loaded: form_helper
INFO - 2025-05-03 12:42:55 --> Helper loaded: file_helper
INFO - 2025-05-03 12:42:55 --> Helper loaded: html_helper
INFO - 2025-05-03 12:42:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:42:55 --> Controller Class Initialized
INFO - 2025-05-03 20:42:55 --> Model "UserModel" initialized
INFO - 2025-05-03 20:42:55 --> Final output sent to browser
DEBUG - 2025-05-03 20:42:55 --> Total execution time: 0.2729
INFO - 2025-05-03 12:42:56 --> Config Class Initialized
INFO - 2025-05-03 12:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:42:56 --> Utf8 Class Initialized
INFO - 2025-05-03 12:42:57 --> URI Class Initialized
INFO - 2025-05-03 12:42:57 --> Router Class Initialized
INFO - 2025-05-03 12:42:57 --> Output Class Initialized
INFO - 2025-05-03 12:42:57 --> Security Class Initialized
DEBUG - 2025-05-03 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:42:57 --> Input Class Initialized
INFO - 2025-05-03 12:42:57 --> Language Class Initialized
INFO - 2025-05-03 12:42:57 --> Loader Class Initialized
INFO - 2025-05-03 12:42:57 --> Helper loaded: url_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: string_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: form_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: file_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: html_helper
INFO - 2025-05-03 12:42:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:42:57 --> Controller Class Initialized
INFO - 2025-05-03 20:42:57 --> Model "UserModel" initialized
INFO - 2025-05-03 12:42:57 --> Config Class Initialized
INFO - 2025-05-03 12:42:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:42:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:42:57 --> Utf8 Class Initialized
INFO - 2025-05-03 12:42:57 --> URI Class Initialized
INFO - 2025-05-03 12:42:57 --> Router Class Initialized
INFO - 2025-05-03 12:42:57 --> Output Class Initialized
INFO - 2025-05-03 12:42:57 --> Security Class Initialized
DEBUG - 2025-05-03 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:42:57 --> Input Class Initialized
INFO - 2025-05-03 12:42:57 --> Language Class Initialized
INFO - 2025-05-03 12:42:57 --> Loader Class Initialized
INFO - 2025-05-03 12:42:57 --> Helper loaded: url_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: string_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: form_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: file_helper
INFO - 2025-05-03 12:42:57 --> Helper loaded: html_helper
INFO - 2025-05-03 12:42:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:42:57 --> Controller Class Initialized
INFO - 2025-05-03 20:42:57 --> Model "UserModel" initialized
ERROR - 2025-05-03 20:42:57 --> Severity: Warning --> Attempt to read property "toName" on array C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 458
DEBUG - 2025-05-03 20:42:57 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:42:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/register_welcome_email_for_bidder.php
INFO - 2025-05-03 20:43:01 --> Final output sent to browser
DEBUG - 2025-05-03 20:43:01 --> Total execution time: 3.9822
INFO - 2025-05-03 12:43:38 --> Config Class Initialized
INFO - 2025-05-03 12:43:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:43:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:43:38 --> Utf8 Class Initialized
INFO - 2025-05-03 12:43:38 --> URI Class Initialized
INFO - 2025-05-03 12:43:38 --> Router Class Initialized
INFO - 2025-05-03 12:43:38 --> Output Class Initialized
INFO - 2025-05-03 12:43:38 --> Security Class Initialized
DEBUG - 2025-05-03 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:43:38 --> Input Class Initialized
INFO - 2025-05-03 12:43:38 --> Language Class Initialized
INFO - 2025-05-03 12:43:38 --> Loader Class Initialized
INFO - 2025-05-03 12:43:38 --> Helper loaded: url_helper
INFO - 2025-05-03 12:43:38 --> Helper loaded: string_helper
INFO - 2025-05-03 12:43:38 --> Helper loaded: form_helper
INFO - 2025-05-03 12:43:38 --> Helper loaded: file_helper
INFO - 2025-05-03 12:43:38 --> Helper loaded: html_helper
INFO - 2025-05-03 12:43:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:43:38 --> Controller Class Initialized
INFO - 2025-05-03 20:43:38 --> Model "UserModel" initialized
INFO - 2025-05-03 12:44:01 --> Config Class Initialized
INFO - 2025-05-03 12:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:44:01 --> Utf8 Class Initialized
INFO - 2025-05-03 12:44:01 --> URI Class Initialized
INFO - 2025-05-03 12:44:01 --> Router Class Initialized
INFO - 2025-05-03 12:44:01 --> Output Class Initialized
INFO - 2025-05-03 12:44:01 --> Security Class Initialized
DEBUG - 2025-05-03 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:44:01 --> Input Class Initialized
INFO - 2025-05-03 12:44:01 --> Language Class Initialized
INFO - 2025-05-03 12:44:01 --> Loader Class Initialized
INFO - 2025-05-03 12:44:01 --> Helper loaded: url_helper
INFO - 2025-05-03 12:44:01 --> Helper loaded: string_helper
INFO - 2025-05-03 12:44:01 --> Helper loaded: form_helper
INFO - 2025-05-03 12:44:01 --> Helper loaded: file_helper
INFO - 2025-05-03 12:44:01 --> Helper loaded: html_helper
INFO - 2025-05-03 12:44:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:44:01 --> Controller Class Initialized
INFO - 2025-05-03 20:44:01 --> Model "UserModel" initialized
INFO - 2025-05-03 12:44:19 --> Config Class Initialized
INFO - 2025-05-03 12:44:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:44:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:44:19 --> Utf8 Class Initialized
INFO - 2025-05-03 12:44:19 --> URI Class Initialized
INFO - 2025-05-03 12:44:19 --> Router Class Initialized
INFO - 2025-05-03 12:44:19 --> Output Class Initialized
INFO - 2025-05-03 12:44:19 --> Security Class Initialized
DEBUG - 2025-05-03 12:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:44:19 --> Input Class Initialized
INFO - 2025-05-03 12:44:19 --> Language Class Initialized
INFO - 2025-05-03 12:44:19 --> Loader Class Initialized
INFO - 2025-05-03 12:44:19 --> Helper loaded: url_helper
INFO - 2025-05-03 12:44:19 --> Helper loaded: string_helper
INFO - 2025-05-03 12:44:19 --> Helper loaded: form_helper
INFO - 2025-05-03 12:44:19 --> Helper loaded: file_helper
INFO - 2025-05-03 12:44:19 --> Helper loaded: html_helper
INFO - 2025-05-03 12:44:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:44:19 --> Controller Class Initialized
INFO - 2025-05-03 20:44:19 --> Model "UserModel" initialized
INFO - 2025-05-03 12:44:24 --> Config Class Initialized
INFO - 2025-05-03 12:44:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:44:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:44:24 --> Utf8 Class Initialized
INFO - 2025-05-03 12:44:24 --> URI Class Initialized
INFO - 2025-05-03 12:44:24 --> Router Class Initialized
INFO - 2025-05-03 12:44:24 --> Output Class Initialized
INFO - 2025-05-03 12:44:24 --> Security Class Initialized
DEBUG - 2025-05-03 12:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:44:24 --> Input Class Initialized
INFO - 2025-05-03 12:44:24 --> Language Class Initialized
INFO - 2025-05-03 12:44:24 --> Loader Class Initialized
INFO - 2025-05-03 12:44:24 --> Helper loaded: url_helper
INFO - 2025-05-03 12:44:24 --> Helper loaded: string_helper
INFO - 2025-05-03 12:44:24 --> Helper loaded: form_helper
INFO - 2025-05-03 12:44:24 --> Helper loaded: file_helper
INFO - 2025-05-03 12:44:24 --> Helper loaded: html_helper
INFO - 2025-05-03 12:44:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:44:24 --> Controller Class Initialized
INFO - 2025-05-03 20:44:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 20:44:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 20:44:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 20:44:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 20:44:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 20:44:24 --> Final output sent to browser
DEBUG - 2025-05-03 20:44:24 --> Total execution time: 0.0939
INFO - 2025-05-03 12:45:04 --> Config Class Initialized
INFO - 2025-05-03 12:45:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:45:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:45:04 --> Utf8 Class Initialized
INFO - 2025-05-03 12:45:04 --> URI Class Initialized
INFO - 2025-05-03 12:45:04 --> Router Class Initialized
INFO - 2025-05-03 12:45:04 --> Output Class Initialized
INFO - 2025-05-03 12:45:04 --> Security Class Initialized
DEBUG - 2025-05-03 12:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:45:04 --> Input Class Initialized
INFO - 2025-05-03 12:45:04 --> Language Class Initialized
INFO - 2025-05-03 12:45:04 --> Loader Class Initialized
INFO - 2025-05-03 12:45:04 --> Helper loaded: url_helper
INFO - 2025-05-03 12:45:04 --> Helper loaded: string_helper
INFO - 2025-05-03 12:45:04 --> Helper loaded: form_helper
INFO - 2025-05-03 12:45:04 --> Helper loaded: file_helper
INFO - 2025-05-03 12:45:04 --> Helper loaded: html_helper
INFO - 2025-05-03 12:45:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:45:04 --> Controller Class Initialized
INFO - 2025-05-03 20:45:04 --> Model "UserModel" initialized
DEBUG - 2025-05-03 20:45:04 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:45:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_bidder_registration_otp_email.php
INFO - 2025-05-03 20:45:08 --> Final output sent to browser
DEBUG - 2025-05-03 20:45:08 --> Total execution time: 4.1063
INFO - 2025-05-03 12:45:36 --> Config Class Initialized
INFO - 2025-05-03 12:45:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:45:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:45:36 --> Utf8 Class Initialized
INFO - 2025-05-03 12:45:36 --> URI Class Initialized
INFO - 2025-05-03 12:45:36 --> Router Class Initialized
INFO - 2025-05-03 12:45:36 --> Output Class Initialized
INFO - 2025-05-03 12:45:36 --> Security Class Initialized
DEBUG - 2025-05-03 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:45:36 --> Input Class Initialized
INFO - 2025-05-03 12:45:36 --> Language Class Initialized
INFO - 2025-05-03 12:45:36 --> Loader Class Initialized
INFO - 2025-05-03 12:45:36 --> Helper loaded: url_helper
INFO - 2025-05-03 12:45:36 --> Helper loaded: string_helper
INFO - 2025-05-03 12:45:36 --> Helper loaded: form_helper
INFO - 2025-05-03 12:45:36 --> Helper loaded: file_helper
INFO - 2025-05-03 12:45:36 --> Helper loaded: html_helper
INFO - 2025-05-03 12:45:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:45:36 --> Controller Class Initialized
INFO - 2025-05-03 20:45:36 --> Model "UserModel" initialized
INFO - 2025-05-03 20:45:36 --> Final output sent to browser
DEBUG - 2025-05-03 20:45:36 --> Total execution time: 0.1675
INFO - 2025-05-03 12:45:37 --> Config Class Initialized
INFO - 2025-05-03 12:45:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:45:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:45:37 --> Utf8 Class Initialized
INFO - 2025-05-03 12:45:37 --> URI Class Initialized
INFO - 2025-05-03 12:45:37 --> Router Class Initialized
INFO - 2025-05-03 12:45:37 --> Output Class Initialized
INFO - 2025-05-03 12:45:37 --> Security Class Initialized
DEBUG - 2025-05-03 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:45:37 --> Input Class Initialized
INFO - 2025-05-03 12:45:37 --> Language Class Initialized
INFO - 2025-05-03 12:45:37 --> Loader Class Initialized
INFO - 2025-05-03 12:45:37 --> Helper loaded: url_helper
INFO - 2025-05-03 12:45:37 --> Helper loaded: string_helper
INFO - 2025-05-03 12:45:37 --> Helper loaded: form_helper
INFO - 2025-05-03 12:45:37 --> Helper loaded: file_helper
INFO - 2025-05-03 12:45:37 --> Helper loaded: html_helper
INFO - 2025-05-03 12:45:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:45:37 --> Controller Class Initialized
INFO - 2025-05-03 20:45:37 --> Model "UserModel" initialized
INFO - 2025-05-03 12:45:38 --> Config Class Initialized
INFO - 2025-05-03 12:45:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:45:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:45:38 --> Utf8 Class Initialized
INFO - 2025-05-03 12:45:38 --> URI Class Initialized
INFO - 2025-05-03 12:45:38 --> Router Class Initialized
INFO - 2025-05-03 12:45:38 --> Output Class Initialized
INFO - 2025-05-03 12:45:38 --> Security Class Initialized
DEBUG - 2025-05-03 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:45:38 --> Input Class Initialized
INFO - 2025-05-03 12:45:38 --> Language Class Initialized
INFO - 2025-05-03 12:45:38 --> Loader Class Initialized
INFO - 2025-05-03 12:45:38 --> Helper loaded: url_helper
INFO - 2025-05-03 12:45:38 --> Helper loaded: string_helper
INFO - 2025-05-03 12:45:38 --> Helper loaded: form_helper
INFO - 2025-05-03 12:45:38 --> Helper loaded: file_helper
INFO - 2025-05-03 12:45:38 --> Helper loaded: html_helper
INFO - 2025-05-03 12:45:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:45:38 --> Controller Class Initialized
INFO - 2025-05-03 20:45:38 --> Model "UserModel" initialized
DEBUG - 2025-05-03 20:45:38 --> PHPMailer class is loaded.
INFO - 2025-05-03 20:45:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/register_welcome_email_for_bidder.php
INFO - 2025-05-03 20:45:43 --> Final output sent to browser
DEBUG - 2025-05-03 20:45:43 --> Total execution time: 5.4074
INFO - 2025-05-03 12:47:14 --> Config Class Initialized
INFO - 2025-05-03 12:47:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:47:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:47:14 --> Utf8 Class Initialized
INFO - 2025-05-03 12:47:14 --> URI Class Initialized
INFO - 2025-05-03 12:47:14 --> Router Class Initialized
INFO - 2025-05-03 12:47:14 --> Output Class Initialized
INFO - 2025-05-03 12:47:14 --> Security Class Initialized
DEBUG - 2025-05-03 12:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:47:14 --> Input Class Initialized
INFO - 2025-05-03 12:47:14 --> Language Class Initialized
ERROR - 2025-05-03 12:47:14 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 12:48:31 --> Config Class Initialized
INFO - 2025-05-03 12:48:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:48:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:48:31 --> Utf8 Class Initialized
INFO - 2025-05-03 12:48:31 --> URI Class Initialized
INFO - 2025-05-03 12:48:31 --> Router Class Initialized
INFO - 2025-05-03 12:48:31 --> Output Class Initialized
INFO - 2025-05-03 12:48:31 --> Security Class Initialized
DEBUG - 2025-05-03 12:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:48:31 --> Input Class Initialized
INFO - 2025-05-03 12:48:31 --> Language Class Initialized
ERROR - 2025-05-03 12:48:31 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 12:53:44 --> Config Class Initialized
INFO - 2025-05-03 12:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:53:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:53:44 --> Utf8 Class Initialized
INFO - 2025-05-03 12:53:44 --> URI Class Initialized
INFO - 2025-05-03 12:53:44 --> Router Class Initialized
INFO - 2025-05-03 12:53:44 --> Output Class Initialized
INFO - 2025-05-03 12:53:44 --> Security Class Initialized
DEBUG - 2025-05-03 12:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:53:44 --> Input Class Initialized
INFO - 2025-05-03 12:53:44 --> Language Class Initialized
INFO - 2025-05-03 12:53:44 --> Loader Class Initialized
INFO - 2025-05-03 12:53:44 --> Helper loaded: url_helper
INFO - 2025-05-03 12:53:44 --> Helper loaded: string_helper
INFO - 2025-05-03 12:53:44 --> Helper loaded: form_helper
INFO - 2025-05-03 12:53:44 --> Helper loaded: file_helper
INFO - 2025-05-03 12:53:44 --> Helper loaded: html_helper
INFO - 2025-05-03 12:53:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:53:44 --> Controller Class Initialized
INFO - 2025-05-03 12:53:46 --> Config Class Initialized
INFO - 2025-05-03 12:53:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:53:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:53:46 --> Utf8 Class Initialized
INFO - 2025-05-03 12:53:46 --> URI Class Initialized
INFO - 2025-05-03 12:53:46 --> Router Class Initialized
INFO - 2025-05-03 12:53:46 --> Output Class Initialized
INFO - 2025-05-03 12:53:46 --> Security Class Initialized
DEBUG - 2025-05-03 12:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:53:46 --> Input Class Initialized
INFO - 2025-05-03 12:53:46 --> Language Class Initialized
INFO - 2025-05-03 12:53:46 --> Loader Class Initialized
INFO - 2025-05-03 12:53:46 --> Helper loaded: url_helper
INFO - 2025-05-03 12:53:46 --> Helper loaded: string_helper
INFO - 2025-05-03 12:53:46 --> Helper loaded: form_helper
INFO - 2025-05-03 12:53:46 --> Helper loaded: file_helper
INFO - 2025-05-03 12:53:46 --> Helper loaded: html_helper
INFO - 2025-05-03 12:53:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:53:46 --> Controller Class Initialized
INFO - 2025-05-03 12:53:47 --> Config Class Initialized
INFO - 2025-05-03 12:53:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:53:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:53:47 --> Utf8 Class Initialized
INFO - 2025-05-03 12:53:47 --> URI Class Initialized
DEBUG - 2025-05-03 12:53:47 --> No URI present. Default controller set.
INFO - 2025-05-03 12:53:47 --> Router Class Initialized
INFO - 2025-05-03 12:53:47 --> Output Class Initialized
INFO - 2025-05-03 12:53:47 --> Security Class Initialized
DEBUG - 2025-05-03 12:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:53:47 --> Input Class Initialized
INFO - 2025-05-03 12:53:47 --> Language Class Initialized
INFO - 2025-05-03 12:53:47 --> Loader Class Initialized
INFO - 2025-05-03 12:53:47 --> Helper loaded: url_helper
INFO - 2025-05-03 12:53:47 --> Helper loaded: string_helper
INFO - 2025-05-03 12:53:47 --> Helper loaded: form_helper
INFO - 2025-05-03 12:53:47 --> Helper loaded: file_helper
INFO - 2025-05-03 12:53:47 --> Helper loaded: html_helper
INFO - 2025-05-03 12:53:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:53:47 --> Controller Class Initialized
INFO - 2025-05-03 12:53:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 12:53:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 12:53:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 12:53:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 12:53:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 12:53:47 --> Final output sent to browser
DEBUG - 2025-05-03 12:53:47 --> Total execution time: 0.2331
INFO - 2025-05-03 12:54:02 --> Config Class Initialized
INFO - 2025-05-03 12:54:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:54:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:54:02 --> Utf8 Class Initialized
INFO - 2025-05-03 12:54:02 --> URI Class Initialized
INFO - 2025-05-03 12:54:02 --> Router Class Initialized
INFO - 2025-05-03 12:54:02 --> Output Class Initialized
INFO - 2025-05-03 12:54:02 --> Security Class Initialized
DEBUG - 2025-05-03 12:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:54:02 --> Input Class Initialized
INFO - 2025-05-03 12:54:02 --> Language Class Initialized
INFO - 2025-05-03 12:54:02 --> Loader Class Initialized
INFO - 2025-05-03 12:54:02 --> Helper loaded: url_helper
INFO - 2025-05-03 12:54:02 --> Helper loaded: string_helper
INFO - 2025-05-03 12:54:02 --> Helper loaded: form_helper
INFO - 2025-05-03 12:54:02 --> Helper loaded: file_helper
INFO - 2025-05-03 12:54:02 --> Helper loaded: html_helper
INFO - 2025-05-03 12:54:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:54:03 --> Controller Class Initialized
INFO - 2025-05-03 20:54:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 12:54:09 --> Config Class Initialized
INFO - 2025-05-03 12:54:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:54:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:54:09 --> Utf8 Class Initialized
INFO - 2025-05-03 12:54:09 --> URI Class Initialized
INFO - 2025-05-03 12:54:09 --> Router Class Initialized
INFO - 2025-05-03 12:54:09 --> Output Class Initialized
INFO - 2025-05-03 12:54:09 --> Security Class Initialized
DEBUG - 2025-05-03 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:54:09 --> Input Class Initialized
INFO - 2025-05-03 12:54:09 --> Language Class Initialized
INFO - 2025-05-03 12:54:09 --> Loader Class Initialized
INFO - 2025-05-03 12:54:09 --> Helper loaded: url_helper
INFO - 2025-05-03 12:54:09 --> Helper loaded: string_helper
INFO - 2025-05-03 12:54:09 --> Helper loaded: form_helper
INFO - 2025-05-03 12:54:09 --> Helper loaded: file_helper
INFO - 2025-05-03 12:54:09 --> Helper loaded: html_helper
INFO - 2025-05-03 12:54:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 12:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 12:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:54:09 --> Controller Class Initialized
INFO - 2025-05-03 20:54:09 --> Model "UserModel" initialized
INFO - 2025-05-03 13:05:46 --> Config Class Initialized
INFO - 2025-05-03 13:05:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:05:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:05:46 --> Utf8 Class Initialized
INFO - 2025-05-03 13:05:46 --> URI Class Initialized
INFO - 2025-05-03 13:05:46 --> Router Class Initialized
INFO - 2025-05-03 13:05:46 --> Output Class Initialized
INFO - 2025-05-03 13:05:46 --> Security Class Initialized
DEBUG - 2025-05-03 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:05:46 --> Input Class Initialized
INFO - 2025-05-03 13:05:46 --> Language Class Initialized
ERROR - 2025-05-03 13:05:47 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:06:15 --> Config Class Initialized
INFO - 2025-05-03 13:06:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:06:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:06:15 --> Utf8 Class Initialized
INFO - 2025-05-03 13:06:15 --> URI Class Initialized
INFO - 2025-05-03 13:06:16 --> Router Class Initialized
INFO - 2025-05-03 13:06:16 --> Output Class Initialized
INFO - 2025-05-03 13:06:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:06:16 --> Input Class Initialized
INFO - 2025-05-03 13:06:16 --> Language Class Initialized
ERROR - 2025-05-03 13:06:16 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:06:45 --> Config Class Initialized
INFO - 2025-05-03 13:06:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:06:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:06:45 --> Utf8 Class Initialized
INFO - 2025-05-03 13:06:45 --> URI Class Initialized
INFO - 2025-05-03 13:06:45 --> Router Class Initialized
INFO - 2025-05-03 13:06:45 --> Output Class Initialized
INFO - 2025-05-03 13:06:45 --> Security Class Initialized
DEBUG - 2025-05-03 13:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:06:45 --> Input Class Initialized
INFO - 2025-05-03 13:06:45 --> Language Class Initialized
ERROR - 2025-05-03 13:06:45 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:07:16 --> Config Class Initialized
INFO - 2025-05-03 13:07:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:07:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:07:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:07:16 --> URI Class Initialized
INFO - 2025-05-03 13:07:16 --> Router Class Initialized
INFO - 2025-05-03 13:07:16 --> Output Class Initialized
INFO - 2025-05-03 13:07:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:07:16 --> Input Class Initialized
INFO - 2025-05-03 13:07:16 --> Language Class Initialized
ERROR - 2025-05-03 13:07:16 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:16:16 --> Config Class Initialized
INFO - 2025-05-03 13:16:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:16:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:16:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:16:16 --> URI Class Initialized
INFO - 2025-05-03 13:16:16 --> Router Class Initialized
INFO - 2025-05-03 13:16:16 --> Output Class Initialized
INFO - 2025-05-03 13:16:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:16:17 --> Input Class Initialized
INFO - 2025-05-03 13:16:17 --> Language Class Initialized
ERROR - 2025-05-03 13:16:17 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:17:12 --> Config Class Initialized
INFO - 2025-05-03 13:17:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:17:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:17:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:17:12 --> URI Class Initialized
INFO - 2025-05-03 13:17:12 --> Router Class Initialized
INFO - 2025-05-03 13:17:12 --> Output Class Initialized
INFO - 2025-05-03 13:17:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:17:12 --> Input Class Initialized
INFO - 2025-05-03 13:17:12 --> Language Class Initialized
ERROR - 2025-05-03 13:17:12 --> 404 Page Not Found: Activate-account/index
INFO - 2025-05-03 13:17:51 --> Config Class Initialized
INFO - 2025-05-03 13:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:17:51 --> Utf8 Class Initialized
INFO - 2025-05-03 13:17:51 --> URI Class Initialized
INFO - 2025-05-03 13:17:51 --> Router Class Initialized
INFO - 2025-05-03 13:17:51 --> Output Class Initialized
INFO - 2025-05-03 13:17:51 --> Security Class Initialized
DEBUG - 2025-05-03 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:17:51 --> Input Class Initialized
INFO - 2025-05-03 13:17:51 --> Language Class Initialized
INFO - 2025-05-03 13:17:51 --> Loader Class Initialized
INFO - 2025-05-03 13:17:51 --> Helper loaded: url_helper
INFO - 2025-05-03 13:17:51 --> Helper loaded: string_helper
INFO - 2025-05-03 13:17:51 --> Helper loaded: form_helper
INFO - 2025-05-03 13:17:51 --> Helper loaded: file_helper
INFO - 2025-05-03 13:17:51 --> Helper loaded: html_helper
INFO - 2025-05-03 13:17:51 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:17:52 --> Controller Class Initialized
INFO - 2025-05-03 21:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:17:52 --> Final output sent to browser
DEBUG - 2025-05-03 21:17:52 --> Total execution time: 0.9428
INFO - 2025-05-03 13:18:14 --> Config Class Initialized
INFO - 2025-05-03 13:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:18:14 --> Utf8 Class Initialized
INFO - 2025-05-03 13:18:14 --> URI Class Initialized
DEBUG - 2025-05-03 13:18:14 --> No URI present. Default controller set.
INFO - 2025-05-03 13:18:14 --> Router Class Initialized
INFO - 2025-05-03 13:18:14 --> Output Class Initialized
INFO - 2025-05-03 13:18:14 --> Security Class Initialized
DEBUG - 2025-05-03 13:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:18:14 --> Input Class Initialized
INFO - 2025-05-03 13:18:14 --> Language Class Initialized
INFO - 2025-05-03 13:18:14 --> Loader Class Initialized
INFO - 2025-05-03 13:18:14 --> Helper loaded: url_helper
INFO - 2025-05-03 13:18:14 --> Helper loaded: string_helper
INFO - 2025-05-03 13:18:14 --> Helper loaded: form_helper
INFO - 2025-05-03 13:18:14 --> Helper loaded: file_helper
INFO - 2025-05-03 13:18:14 --> Helper loaded: html_helper
INFO - 2025-05-03 13:18:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:18:14 --> Controller Class Initialized
INFO - 2025-05-03 13:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 13:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:18:15 --> Final output sent to browser
DEBUG - 2025-05-03 13:18:15 --> Total execution time: 0.0868
INFO - 2025-05-03 13:18:17 --> Config Class Initialized
INFO - 2025-05-03 13:18:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:18:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:18:17 --> Utf8 Class Initialized
INFO - 2025-05-03 13:18:17 --> URI Class Initialized
INFO - 2025-05-03 13:18:17 --> Router Class Initialized
INFO - 2025-05-03 13:18:17 --> Output Class Initialized
INFO - 2025-05-03 13:18:17 --> Security Class Initialized
DEBUG - 2025-05-03 13:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:18:17 --> Input Class Initialized
INFO - 2025-05-03 13:18:17 --> Language Class Initialized
INFO - 2025-05-03 13:18:17 --> Loader Class Initialized
INFO - 2025-05-03 13:18:17 --> Helper loaded: url_helper
INFO - 2025-05-03 13:18:17 --> Helper loaded: string_helper
INFO - 2025-05-03 13:18:17 --> Helper loaded: form_helper
INFO - 2025-05-03 13:18:17 --> Helper loaded: file_helper
INFO - 2025-05-03 13:18:17 --> Helper loaded: html_helper
INFO - 2025-05-03 13:18:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:18:17 --> Controller Class Initialized
INFO - 2025-05-03 21:18:17 --> Model "AuctionModel" initialized
INFO - 2025-05-03 13:19:44 --> Config Class Initialized
INFO - 2025-05-03 13:19:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:19:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:19:44 --> Utf8 Class Initialized
INFO - 2025-05-03 13:19:44 --> URI Class Initialized
INFO - 2025-05-03 13:19:44 --> Router Class Initialized
INFO - 2025-05-03 13:19:44 --> Output Class Initialized
INFO - 2025-05-03 13:19:44 --> Security Class Initialized
DEBUG - 2025-05-03 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:19:44 --> Input Class Initialized
INFO - 2025-05-03 13:19:44 --> Language Class Initialized
INFO - 2025-05-03 13:19:44 --> Loader Class Initialized
INFO - 2025-05-03 13:19:44 --> Helper loaded: url_helper
INFO - 2025-05-03 13:19:44 --> Helper loaded: string_helper
INFO - 2025-05-03 13:19:44 --> Helper loaded: form_helper
INFO - 2025-05-03 13:19:44 --> Helper loaded: file_helper
INFO - 2025-05-03 13:19:44 --> Helper loaded: html_helper
INFO - 2025-05-03 13:19:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:19:44 --> Controller Class Initialized
ERROR - 2025-05-03 21:19:44 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\storage_auctions\application\views\user\activation\invalid.php 19
ERROR - 2025-05-03 21:19:44 --> Severity: Warning --> Undefined variable $verify_link C:\xampp\htdocs\storage_auctions\application\views\user\activation\invalid.php 26
INFO - 2025-05-03 21:19:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:19:44 --> Final output sent to browser
DEBUG - 2025-05-03 21:19:44 --> Total execution time: 0.1935
INFO - 2025-05-03 13:20:27 --> Config Class Initialized
INFO - 2025-05-03 13:20:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:20:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:20:27 --> Utf8 Class Initialized
INFO - 2025-05-03 13:20:27 --> URI Class Initialized
INFO - 2025-05-03 13:20:27 --> Router Class Initialized
INFO - 2025-05-03 13:20:27 --> Output Class Initialized
INFO - 2025-05-03 13:20:27 --> Security Class Initialized
DEBUG - 2025-05-03 13:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:20:27 --> Input Class Initialized
INFO - 2025-05-03 13:20:27 --> Language Class Initialized
INFO - 2025-05-03 13:20:27 --> Loader Class Initialized
INFO - 2025-05-03 13:20:27 --> Helper loaded: url_helper
INFO - 2025-05-03 13:20:27 --> Helper loaded: string_helper
INFO - 2025-05-03 13:20:27 --> Helper loaded: form_helper
INFO - 2025-05-03 13:20:27 --> Helper loaded: file_helper
INFO - 2025-05-03 13:20:27 --> Helper loaded: html_helper
INFO - 2025-05-03 13:20:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:20:27 --> Controller Class Initialized
INFO - 2025-05-03 21:20:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:20:27 --> Final output sent to browser
DEBUG - 2025-05-03 21:20:27 --> Total execution time: 0.2090
INFO - 2025-05-03 13:21:03 --> Config Class Initialized
INFO - 2025-05-03 13:21:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:21:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:21:03 --> Utf8 Class Initialized
INFO - 2025-05-03 13:21:03 --> URI Class Initialized
INFO - 2025-05-03 13:21:03 --> Router Class Initialized
INFO - 2025-05-03 13:21:03 --> Output Class Initialized
INFO - 2025-05-03 13:21:03 --> Security Class Initialized
DEBUG - 2025-05-03 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:21:03 --> Input Class Initialized
INFO - 2025-05-03 13:21:03 --> Language Class Initialized
INFO - 2025-05-03 13:21:03 --> Loader Class Initialized
INFO - 2025-05-03 13:21:03 --> Helper loaded: url_helper
INFO - 2025-05-03 13:21:03 --> Helper loaded: string_helper
INFO - 2025-05-03 13:21:03 --> Helper loaded: form_helper
INFO - 2025-05-03 13:21:03 --> Helper loaded: file_helper
INFO - 2025-05-03 13:21:03 --> Helper loaded: html_helper
INFO - 2025-05-03 13:21:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:21:03 --> Controller Class Initialized
INFO - 2025-05-03 21:21:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:21:03 --> Final output sent to browser
DEBUG - 2025-05-03 21:21:03 --> Total execution time: 0.1383
INFO - 2025-05-03 13:21:17 --> Config Class Initialized
INFO - 2025-05-03 13:21:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:21:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:21:17 --> Utf8 Class Initialized
INFO - 2025-05-03 13:21:17 --> URI Class Initialized
INFO - 2025-05-03 13:21:17 --> Router Class Initialized
INFO - 2025-05-03 13:21:17 --> Output Class Initialized
INFO - 2025-05-03 13:21:17 --> Security Class Initialized
DEBUG - 2025-05-03 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:21:17 --> Input Class Initialized
INFO - 2025-05-03 13:21:17 --> Language Class Initialized
INFO - 2025-05-03 13:21:17 --> Loader Class Initialized
INFO - 2025-05-03 13:21:17 --> Helper loaded: url_helper
INFO - 2025-05-03 13:21:17 --> Helper loaded: string_helper
INFO - 2025-05-03 13:21:17 --> Helper loaded: form_helper
INFO - 2025-05-03 13:21:17 --> Helper loaded: file_helper
INFO - 2025-05-03 13:21:17 --> Helper loaded: html_helper
INFO - 2025-05-03 13:21:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:21:17 --> Controller Class Initialized
INFO - 2025-05-03 21:21:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:21:17 --> Final output sent to browser
DEBUG - 2025-05-03 21:21:17 --> Total execution time: 0.2313
INFO - 2025-05-03 13:21:33 --> Config Class Initialized
INFO - 2025-05-03 13:21:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:21:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:21:33 --> Utf8 Class Initialized
INFO - 2025-05-03 13:21:33 --> URI Class Initialized
INFO - 2025-05-03 13:21:33 --> Router Class Initialized
INFO - 2025-05-03 13:21:33 --> Output Class Initialized
INFO - 2025-05-03 13:21:33 --> Security Class Initialized
DEBUG - 2025-05-03 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:21:33 --> Input Class Initialized
INFO - 2025-05-03 13:21:33 --> Language Class Initialized
INFO - 2025-05-03 13:21:33 --> Loader Class Initialized
INFO - 2025-05-03 13:21:33 --> Helper loaded: url_helper
INFO - 2025-05-03 13:21:33 --> Helper loaded: string_helper
INFO - 2025-05-03 13:21:33 --> Helper loaded: form_helper
INFO - 2025-05-03 13:21:33 --> Helper loaded: file_helper
INFO - 2025-05-03 13:21:33 --> Helper loaded: html_helper
INFO - 2025-05-03 13:21:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:21:33 --> Controller Class Initialized
INFO - 2025-05-03 21:21:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:21:33 --> Final output sent to browser
DEBUG - 2025-05-03 21:21:33 --> Total execution time: 0.1683
INFO - 2025-05-03 13:21:46 --> Config Class Initialized
INFO - 2025-05-03 13:21:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:21:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:21:46 --> Utf8 Class Initialized
INFO - 2025-05-03 13:21:46 --> URI Class Initialized
INFO - 2025-05-03 13:21:46 --> Router Class Initialized
INFO - 2025-05-03 13:21:46 --> Output Class Initialized
INFO - 2025-05-03 13:21:46 --> Security Class Initialized
DEBUG - 2025-05-03 13:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:21:46 --> Input Class Initialized
INFO - 2025-05-03 13:21:46 --> Language Class Initialized
INFO - 2025-05-03 13:21:46 --> Loader Class Initialized
INFO - 2025-05-03 13:21:46 --> Helper loaded: url_helper
INFO - 2025-05-03 13:21:46 --> Helper loaded: string_helper
INFO - 2025-05-03 13:21:46 --> Helper loaded: form_helper
INFO - 2025-05-03 13:21:46 --> Helper loaded: file_helper
INFO - 2025-05-03 13:21:46 --> Helper loaded: html_helper
INFO - 2025-05-03 13:21:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:21:46 --> Controller Class Initialized
INFO - 2025-05-03 21:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:21:46 --> Final output sent to browser
DEBUG - 2025-05-03 21:21:46 --> Total execution time: 0.1084
INFO - 2025-05-03 13:22:01 --> Config Class Initialized
INFO - 2025-05-03 13:22:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:22:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:22:01 --> Utf8 Class Initialized
INFO - 2025-05-03 13:22:01 --> URI Class Initialized
INFO - 2025-05-03 13:22:01 --> Router Class Initialized
INFO - 2025-05-03 13:22:01 --> Output Class Initialized
INFO - 2025-05-03 13:22:01 --> Security Class Initialized
DEBUG - 2025-05-03 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:22:01 --> Input Class Initialized
INFO - 2025-05-03 13:22:01 --> Language Class Initialized
INFO - 2025-05-03 13:22:01 --> Loader Class Initialized
INFO - 2025-05-03 13:22:01 --> Helper loaded: url_helper
INFO - 2025-05-03 13:22:01 --> Helper loaded: string_helper
INFO - 2025-05-03 13:22:01 --> Helper loaded: form_helper
INFO - 2025-05-03 13:22:01 --> Helper loaded: file_helper
INFO - 2025-05-03 13:22:01 --> Helper loaded: html_helper
INFO - 2025-05-03 13:22:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:22:01 --> Controller Class Initialized
INFO - 2025-05-03 21:22:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:22:01 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:01 --> Total execution time: 0.1683
INFO - 2025-05-03 13:22:18 --> Config Class Initialized
INFO - 2025-05-03 13:22:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:22:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:22:18 --> Utf8 Class Initialized
INFO - 2025-05-03 13:22:18 --> URI Class Initialized
INFO - 2025-05-03 13:22:18 --> Router Class Initialized
INFO - 2025-05-03 13:22:18 --> Output Class Initialized
INFO - 2025-05-03 13:22:18 --> Security Class Initialized
DEBUG - 2025-05-03 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:22:18 --> Input Class Initialized
INFO - 2025-05-03 13:22:18 --> Language Class Initialized
INFO - 2025-05-03 13:22:18 --> Loader Class Initialized
INFO - 2025-05-03 13:22:18 --> Helper loaded: url_helper
INFO - 2025-05-03 13:22:18 --> Helper loaded: string_helper
INFO - 2025-05-03 13:22:18 --> Helper loaded: form_helper
INFO - 2025-05-03 13:22:18 --> Helper loaded: file_helper
INFO - 2025-05-03 13:22:18 --> Helper loaded: html_helper
INFO - 2025-05-03 13:22:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:22:18 --> Controller Class Initialized
INFO - 2025-05-03 21:22:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:22:18 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:18 --> Total execution time: 0.2869
INFO - 2025-05-03 13:22:37 --> Config Class Initialized
INFO - 2025-05-03 13:22:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:22:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:22:37 --> Utf8 Class Initialized
INFO - 2025-05-03 13:22:37 --> URI Class Initialized
INFO - 2025-05-03 13:22:37 --> Router Class Initialized
INFO - 2025-05-03 13:22:37 --> Output Class Initialized
INFO - 2025-05-03 13:22:37 --> Security Class Initialized
DEBUG - 2025-05-03 13:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:22:37 --> Input Class Initialized
INFO - 2025-05-03 13:22:37 --> Language Class Initialized
INFO - 2025-05-03 13:22:37 --> Loader Class Initialized
INFO - 2025-05-03 13:22:37 --> Helper loaded: url_helper
INFO - 2025-05-03 13:22:37 --> Helper loaded: string_helper
INFO - 2025-05-03 13:22:37 --> Helper loaded: form_helper
INFO - 2025-05-03 13:22:37 --> Helper loaded: file_helper
INFO - 2025-05-03 13:22:37 --> Helper loaded: html_helper
INFO - 2025-05-03 13:22:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:22:37 --> Controller Class Initialized
INFO - 2025-05-03 21:22:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:22:37 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:37 --> Total execution time: 0.1250
INFO - 2025-05-03 13:22:47 --> Config Class Initialized
INFO - 2025-05-03 13:22:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:22:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:22:47 --> Utf8 Class Initialized
INFO - 2025-05-03 13:22:47 --> URI Class Initialized
INFO - 2025-05-03 13:22:47 --> Router Class Initialized
INFO - 2025-05-03 13:22:47 --> Output Class Initialized
INFO - 2025-05-03 13:22:47 --> Security Class Initialized
DEBUG - 2025-05-03 13:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:22:47 --> Input Class Initialized
INFO - 2025-05-03 13:22:47 --> Language Class Initialized
INFO - 2025-05-03 13:22:47 --> Loader Class Initialized
INFO - 2025-05-03 13:22:47 --> Helper loaded: url_helper
INFO - 2025-05-03 13:22:47 --> Helper loaded: string_helper
INFO - 2025-05-03 13:22:47 --> Helper loaded: form_helper
INFO - 2025-05-03 13:22:47 --> Helper loaded: file_helper
INFO - 2025-05-03 13:22:47 --> Helper loaded: html_helper
INFO - 2025-05-03 13:22:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:22:47 --> Controller Class Initialized
INFO - 2025-05-03 21:22:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:22:47 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:47 --> Total execution time: 0.1308
INFO - 2025-05-03 13:23:16 --> Config Class Initialized
INFO - 2025-05-03 13:23:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:23:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:23:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:23:16 --> URI Class Initialized
INFO - 2025-05-03 13:23:16 --> Router Class Initialized
INFO - 2025-05-03 13:23:16 --> Output Class Initialized
INFO - 2025-05-03 13:23:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:23:16 --> Input Class Initialized
INFO - 2025-05-03 13:23:16 --> Language Class Initialized
INFO - 2025-05-03 13:23:16 --> Loader Class Initialized
INFO - 2025-05-03 13:23:16 --> Helper loaded: url_helper
INFO - 2025-05-03 13:23:16 --> Helper loaded: string_helper
INFO - 2025-05-03 13:23:16 --> Helper loaded: form_helper
INFO - 2025-05-03 13:23:16 --> Helper loaded: file_helper
INFO - 2025-05-03 13:23:16 --> Helper loaded: html_helper
INFO - 2025-05-03 13:23:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:23:17 --> Controller Class Initialized
INFO - 2025-05-03 21:23:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:23:17 --> Final output sent to browser
DEBUG - 2025-05-03 21:23:17 --> Total execution time: 0.2482
INFO - 2025-05-03 13:24:05 --> Config Class Initialized
INFO - 2025-05-03 13:24:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:24:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:24:05 --> Utf8 Class Initialized
INFO - 2025-05-03 13:24:05 --> URI Class Initialized
INFO - 2025-05-03 13:24:05 --> Router Class Initialized
INFO - 2025-05-03 13:24:05 --> Output Class Initialized
INFO - 2025-05-03 13:24:05 --> Security Class Initialized
DEBUG - 2025-05-03 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:24:05 --> Input Class Initialized
INFO - 2025-05-03 13:24:05 --> Language Class Initialized
INFO - 2025-05-03 13:24:05 --> Loader Class Initialized
INFO - 2025-05-03 13:24:05 --> Helper loaded: url_helper
INFO - 2025-05-03 13:24:05 --> Helper loaded: string_helper
INFO - 2025-05-03 13:24:05 --> Helper loaded: form_helper
INFO - 2025-05-03 13:24:05 --> Helper loaded: file_helper
INFO - 2025-05-03 13:24:05 --> Helper loaded: html_helper
INFO - 2025-05-03 13:24:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:24:05 --> Controller Class Initialized
INFO - 2025-05-03 21:24:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:24:06 --> Final output sent to browser
DEBUG - 2025-05-03 21:24:06 --> Total execution time: 0.2962
INFO - 2025-05-03 13:25:12 --> Config Class Initialized
INFO - 2025-05-03 13:25:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:12 --> URI Class Initialized
INFO - 2025-05-03 13:25:12 --> Router Class Initialized
INFO - 2025-05-03 13:25:12 --> Output Class Initialized
INFO - 2025-05-03 13:25:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:12 --> Input Class Initialized
INFO - 2025-05-03 13:25:12 --> Language Class Initialized
INFO - 2025-05-03 13:25:12 --> Loader Class Initialized
INFO - 2025-05-03 13:25:12 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:12 --> Helper loaded: string_helper
INFO - 2025-05-03 13:25:12 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:12 --> Helper loaded: file_helper
INFO - 2025-05-03 13:25:12 --> Helper loaded: html_helper
INFO - 2025-05-03 13:25:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:13 --> Controller Class Initialized
INFO - 2025-05-03 21:25:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:25:13 --> Final output sent to browser
DEBUG - 2025-05-03 21:25:13 --> Total execution time: 0.3938
INFO - 2025-05-03 13:25:43 --> Config Class Initialized
INFO - 2025-05-03 13:25:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:43 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:43 --> URI Class Initialized
INFO - 2025-05-03 13:25:43 --> Router Class Initialized
INFO - 2025-05-03 13:25:43 --> Output Class Initialized
INFO - 2025-05-03 13:25:43 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:43 --> Input Class Initialized
INFO - 2025-05-03 13:25:43 --> Language Class Initialized
INFO - 2025-05-03 13:25:43 --> Loader Class Initialized
INFO - 2025-05-03 13:25:43 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:43 --> Helper loaded: string_helper
INFO - 2025-05-03 13:25:43 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:43 --> Helper loaded: file_helper
INFO - 2025-05-03 13:25:43 --> Helper loaded: html_helper
INFO - 2025-05-03 13:25:43 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:43 --> Controller Class Initialized
INFO - 2025-05-03 21:25:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:25:43 --> Final output sent to browser
DEBUG - 2025-05-03 21:25:43 --> Total execution time: 0.3367
INFO - 2025-05-03 13:25:46 --> Config Class Initialized
INFO - 2025-05-03 13:25:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:46 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:46 --> URI Class Initialized
INFO - 2025-05-03 13:25:46 --> Router Class Initialized
INFO - 2025-05-03 13:25:46 --> Output Class Initialized
INFO - 2025-05-03 13:25:46 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:46 --> Input Class Initialized
INFO - 2025-05-03 13:25:46 --> Language Class Initialized
INFO - 2025-05-03 13:25:46 --> Loader Class Initialized
INFO - 2025-05-03 13:25:46 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:46 --> Helper loaded: string_helper
INFO - 2025-05-03 13:25:46 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:46 --> Helper loaded: file_helper
INFO - 2025-05-03 13:25:46 --> Helper loaded: html_helper
INFO - 2025-05-03 13:25:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:46 --> Controller Class Initialized
INFO - 2025-05-03 21:25:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:25:46 --> Final output sent to browser
DEBUG - 2025-05-03 21:25:46 --> Total execution time: 0.1698
INFO - 2025-05-03 13:25:53 --> Config Class Initialized
INFO - 2025-05-03 13:25:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:53 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:53 --> URI Class Initialized
INFO - 2025-05-03 13:25:53 --> Router Class Initialized
INFO - 2025-05-03 13:25:53 --> Output Class Initialized
INFO - 2025-05-03 13:25:53 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:53 --> Input Class Initialized
INFO - 2025-05-03 13:25:53 --> Language Class Initialized
INFO - 2025-05-03 13:25:53 --> Loader Class Initialized
INFO - 2025-05-03 13:25:53 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:53 --> Helper loaded: string_helper
INFO - 2025-05-03 13:25:53 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:53 --> Helper loaded: file_helper
INFO - 2025-05-03 13:25:53 --> Helper loaded: html_helper
INFO - 2025-05-03 13:25:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:53 --> Controller Class Initialized
INFO - 2025-05-03 21:25:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:25:53 --> Final output sent to browser
DEBUG - 2025-05-03 21:25:53 --> Total execution time: 0.3904
INFO - 2025-05-03 13:26:40 --> Config Class Initialized
INFO - 2025-05-03 13:26:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:26:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:26:40 --> Utf8 Class Initialized
INFO - 2025-05-03 13:26:40 --> URI Class Initialized
INFO - 2025-05-03 13:26:40 --> Router Class Initialized
INFO - 2025-05-03 13:26:40 --> Output Class Initialized
INFO - 2025-05-03 13:26:40 --> Security Class Initialized
DEBUG - 2025-05-03 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:26:40 --> Input Class Initialized
INFO - 2025-05-03 13:26:40 --> Language Class Initialized
INFO - 2025-05-03 13:26:40 --> Loader Class Initialized
INFO - 2025-05-03 13:26:40 --> Helper loaded: url_helper
INFO - 2025-05-03 13:26:40 --> Helper loaded: string_helper
INFO - 2025-05-03 13:26:40 --> Helper loaded: form_helper
INFO - 2025-05-03 13:26:40 --> Helper loaded: file_helper
INFO - 2025-05-03 13:26:40 --> Helper loaded: html_helper
INFO - 2025-05-03 13:26:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:26:40 --> Controller Class Initialized
INFO - 2025-05-03 21:26:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:26:40 --> Final output sent to browser
DEBUG - 2025-05-03 21:26:40 --> Total execution time: 0.1661
INFO - 2025-05-03 13:26:47 --> Config Class Initialized
INFO - 2025-05-03 13:26:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:26:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:26:47 --> Utf8 Class Initialized
INFO - 2025-05-03 13:26:47 --> URI Class Initialized
INFO - 2025-05-03 13:26:47 --> Router Class Initialized
INFO - 2025-05-03 13:26:47 --> Output Class Initialized
INFO - 2025-05-03 13:26:47 --> Security Class Initialized
DEBUG - 2025-05-03 13:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:26:47 --> Input Class Initialized
INFO - 2025-05-03 13:26:47 --> Language Class Initialized
INFO - 2025-05-03 13:26:47 --> Loader Class Initialized
INFO - 2025-05-03 13:26:47 --> Helper loaded: url_helper
INFO - 2025-05-03 13:26:47 --> Helper loaded: string_helper
INFO - 2025-05-03 13:26:47 --> Helper loaded: form_helper
INFO - 2025-05-03 13:26:47 --> Helper loaded: file_helper
INFO - 2025-05-03 13:26:47 --> Helper loaded: html_helper
INFO - 2025-05-03 13:26:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:26:47 --> Controller Class Initialized
INFO - 2025-05-03 21:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:26:47 --> Final output sent to browser
DEBUG - 2025-05-03 21:26:47 --> Total execution time: 0.2783
INFO - 2025-05-03 13:27:08 --> Config Class Initialized
INFO - 2025-05-03 13:27:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:27:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:27:08 --> Utf8 Class Initialized
INFO - 2025-05-03 13:27:08 --> URI Class Initialized
INFO - 2025-05-03 13:27:08 --> Router Class Initialized
INFO - 2025-05-03 13:27:08 --> Output Class Initialized
INFO - 2025-05-03 13:27:08 --> Security Class Initialized
DEBUG - 2025-05-03 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:27:08 --> Input Class Initialized
INFO - 2025-05-03 13:27:08 --> Language Class Initialized
INFO - 2025-05-03 13:27:08 --> Loader Class Initialized
INFO - 2025-05-03 13:27:08 --> Helper loaded: url_helper
INFO - 2025-05-03 13:27:08 --> Helper loaded: string_helper
INFO - 2025-05-03 13:27:08 --> Helper loaded: form_helper
INFO - 2025-05-03 13:27:08 --> Helper loaded: file_helper
INFO - 2025-05-03 13:27:08 --> Helper loaded: html_helper
INFO - 2025-05-03 13:27:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:27:08 --> Controller Class Initialized
INFO - 2025-05-03 21:27:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:27:08 --> Final output sent to browser
DEBUG - 2025-05-03 21:27:08 --> Total execution time: 0.1966
INFO - 2025-05-03 13:27:34 --> Config Class Initialized
INFO - 2025-05-03 13:27:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:27:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:27:34 --> Utf8 Class Initialized
INFO - 2025-05-03 13:27:34 --> URI Class Initialized
INFO - 2025-05-03 13:27:34 --> Router Class Initialized
INFO - 2025-05-03 13:27:34 --> Output Class Initialized
INFO - 2025-05-03 13:27:34 --> Security Class Initialized
DEBUG - 2025-05-03 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:27:34 --> Input Class Initialized
INFO - 2025-05-03 13:27:34 --> Language Class Initialized
INFO - 2025-05-03 13:27:34 --> Loader Class Initialized
INFO - 2025-05-03 13:27:34 --> Helper loaded: url_helper
INFO - 2025-05-03 13:27:34 --> Helper loaded: string_helper
INFO - 2025-05-03 13:27:34 --> Helper loaded: form_helper
INFO - 2025-05-03 13:27:34 --> Helper loaded: file_helper
INFO - 2025-05-03 13:27:34 --> Helper loaded: html_helper
INFO - 2025-05-03 13:27:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:27:34 --> Controller Class Initialized
INFO - 2025-05-03 21:27:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:27:34 --> Final output sent to browser
DEBUG - 2025-05-03 21:27:34 --> Total execution time: 0.1473
INFO - 2025-05-03 13:27:43 --> Config Class Initialized
INFO - 2025-05-03 13:27:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:27:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:27:43 --> Utf8 Class Initialized
INFO - 2025-05-03 13:27:43 --> URI Class Initialized
INFO - 2025-05-03 13:27:43 --> Router Class Initialized
INFO - 2025-05-03 13:27:43 --> Output Class Initialized
INFO - 2025-05-03 13:27:43 --> Security Class Initialized
DEBUG - 2025-05-03 13:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:27:43 --> Input Class Initialized
INFO - 2025-05-03 13:27:43 --> Language Class Initialized
INFO - 2025-05-03 13:27:43 --> Loader Class Initialized
INFO - 2025-05-03 13:27:43 --> Helper loaded: url_helper
INFO - 2025-05-03 13:27:43 --> Helper loaded: string_helper
INFO - 2025-05-03 13:27:43 --> Helper loaded: form_helper
INFO - 2025-05-03 13:27:43 --> Helper loaded: file_helper
INFO - 2025-05-03 13:27:43 --> Helper loaded: html_helper
INFO - 2025-05-03 13:27:43 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:27:43 --> Controller Class Initialized
INFO - 2025-05-03 21:27:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:27:43 --> Final output sent to browser
DEBUG - 2025-05-03 21:27:43 --> Total execution time: 0.1982
INFO - 2025-05-03 13:27:45 --> Config Class Initialized
INFO - 2025-05-03 13:27:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:27:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:27:45 --> Utf8 Class Initialized
INFO - 2025-05-03 13:27:45 --> URI Class Initialized
INFO - 2025-05-03 13:27:45 --> Router Class Initialized
INFO - 2025-05-03 13:27:45 --> Output Class Initialized
INFO - 2025-05-03 13:27:45 --> Security Class Initialized
DEBUG - 2025-05-03 13:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:27:45 --> Input Class Initialized
INFO - 2025-05-03 13:27:45 --> Language Class Initialized
INFO - 2025-05-03 13:27:45 --> Loader Class Initialized
INFO - 2025-05-03 13:27:45 --> Helper loaded: url_helper
INFO - 2025-05-03 13:27:45 --> Helper loaded: string_helper
INFO - 2025-05-03 13:27:45 --> Helper loaded: form_helper
INFO - 2025-05-03 13:27:45 --> Helper loaded: file_helper
INFO - 2025-05-03 13:27:45 --> Helper loaded: html_helper
INFO - 2025-05-03 13:27:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:27:46 --> Controller Class Initialized
INFO - 2025-05-03 21:27:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:27:46 --> Final output sent to browser
DEBUG - 2025-05-03 21:27:46 --> Total execution time: 0.1109
INFO - 2025-05-03 13:28:00 --> Config Class Initialized
INFO - 2025-05-03 13:28:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:28:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:28:00 --> Utf8 Class Initialized
INFO - 2025-05-03 13:28:00 --> URI Class Initialized
INFO - 2025-05-03 13:28:00 --> Router Class Initialized
INFO - 2025-05-03 13:28:00 --> Output Class Initialized
INFO - 2025-05-03 13:28:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:28:00 --> Input Class Initialized
INFO - 2025-05-03 13:28:00 --> Language Class Initialized
INFO - 2025-05-03 13:28:00 --> Loader Class Initialized
INFO - 2025-05-03 13:28:00 --> Helper loaded: url_helper
INFO - 2025-05-03 13:28:00 --> Helper loaded: string_helper
INFO - 2025-05-03 13:28:00 --> Helper loaded: form_helper
INFO - 2025-05-03 13:28:00 --> Helper loaded: file_helper
INFO - 2025-05-03 13:28:00 --> Helper loaded: html_helper
INFO - 2025-05-03 13:28:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:28:01 --> Controller Class Initialized
INFO - 2025-05-03 21:28:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:28:01 --> Final output sent to browser
DEBUG - 2025-05-03 21:28:01 --> Total execution time: 0.1692
INFO - 2025-05-03 13:28:12 --> Config Class Initialized
INFO - 2025-05-03 13:28:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:28:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:28:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:28:12 --> URI Class Initialized
INFO - 2025-05-03 13:28:12 --> Router Class Initialized
INFO - 2025-05-03 13:28:12 --> Output Class Initialized
INFO - 2025-05-03 13:28:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:28:12 --> Input Class Initialized
INFO - 2025-05-03 13:28:12 --> Language Class Initialized
INFO - 2025-05-03 13:28:12 --> Loader Class Initialized
INFO - 2025-05-03 13:28:12 --> Helper loaded: url_helper
INFO - 2025-05-03 13:28:12 --> Helper loaded: string_helper
INFO - 2025-05-03 13:28:12 --> Helper loaded: form_helper
INFO - 2025-05-03 13:28:12 --> Helper loaded: file_helper
INFO - 2025-05-03 13:28:12 --> Helper loaded: html_helper
INFO - 2025-05-03 13:28:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:28:12 --> Controller Class Initialized
INFO - 2025-05-03 21:28:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:28:13 --> Final output sent to browser
DEBUG - 2025-05-03 21:28:13 --> Total execution time: 0.2441
INFO - 2025-05-03 13:28:20 --> Config Class Initialized
INFO - 2025-05-03 13:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:28:20 --> Utf8 Class Initialized
INFO - 2025-05-03 13:28:20 --> URI Class Initialized
INFO - 2025-05-03 13:28:20 --> Router Class Initialized
INFO - 2025-05-03 13:28:20 --> Output Class Initialized
INFO - 2025-05-03 13:28:20 --> Security Class Initialized
DEBUG - 2025-05-03 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:28:20 --> Input Class Initialized
INFO - 2025-05-03 13:28:20 --> Language Class Initialized
INFO - 2025-05-03 13:28:20 --> Loader Class Initialized
INFO - 2025-05-03 13:28:20 --> Helper loaded: url_helper
INFO - 2025-05-03 13:28:20 --> Helper loaded: string_helper
INFO - 2025-05-03 13:28:20 --> Helper loaded: form_helper
INFO - 2025-05-03 13:28:20 --> Helper loaded: file_helper
INFO - 2025-05-03 13:28:20 --> Helper loaded: html_helper
INFO - 2025-05-03 13:28:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:28:20 --> Controller Class Initialized
INFO - 2025-05-03 21:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:28:20 --> Final output sent to browser
DEBUG - 2025-05-03 21:28:20 --> Total execution time: 0.2468
INFO - 2025-05-03 13:28:26 --> Config Class Initialized
INFO - 2025-05-03 13:28:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:28:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:28:26 --> Utf8 Class Initialized
INFO - 2025-05-03 13:28:26 --> URI Class Initialized
INFO - 2025-05-03 13:28:26 --> Router Class Initialized
INFO - 2025-05-03 13:28:26 --> Output Class Initialized
INFO - 2025-05-03 13:28:26 --> Security Class Initialized
DEBUG - 2025-05-03 13:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:28:26 --> Input Class Initialized
INFO - 2025-05-03 13:28:26 --> Language Class Initialized
INFO - 2025-05-03 13:28:26 --> Loader Class Initialized
INFO - 2025-05-03 13:28:26 --> Helper loaded: url_helper
INFO - 2025-05-03 13:28:26 --> Helper loaded: string_helper
INFO - 2025-05-03 13:28:26 --> Helper loaded: form_helper
INFO - 2025-05-03 13:28:26 --> Helper loaded: file_helper
INFO - 2025-05-03 13:28:26 --> Helper loaded: html_helper
INFO - 2025-05-03 13:28:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:28:26 --> Controller Class Initialized
INFO - 2025-05-03 21:28:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:28:26 --> Final output sent to browser
DEBUG - 2025-05-03 21:28:26 --> Total execution time: 0.1334
INFO - 2025-05-03 13:28:40 --> Config Class Initialized
INFO - 2025-05-03 13:28:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:28:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:28:40 --> Utf8 Class Initialized
INFO - 2025-05-03 13:28:40 --> URI Class Initialized
INFO - 2025-05-03 13:28:40 --> Router Class Initialized
INFO - 2025-05-03 13:28:40 --> Output Class Initialized
INFO - 2025-05-03 13:28:40 --> Security Class Initialized
DEBUG - 2025-05-03 13:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:28:40 --> Input Class Initialized
INFO - 2025-05-03 13:28:40 --> Language Class Initialized
INFO - 2025-05-03 13:28:40 --> Loader Class Initialized
INFO - 2025-05-03 13:28:40 --> Helper loaded: url_helper
INFO - 2025-05-03 13:28:40 --> Helper loaded: string_helper
INFO - 2025-05-03 13:28:40 --> Helper loaded: form_helper
INFO - 2025-05-03 13:28:40 --> Helper loaded: file_helper
INFO - 2025-05-03 13:28:40 --> Helper loaded: html_helper
INFO - 2025-05-03 13:28:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:28:40 --> Controller Class Initialized
INFO - 2025-05-03 21:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:28:40 --> Final output sent to browser
DEBUG - 2025-05-03 21:28:40 --> Total execution time: 0.2099
INFO - 2025-05-03 13:29:49 --> Config Class Initialized
INFO - 2025-05-03 13:29:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:29:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:29:49 --> Utf8 Class Initialized
INFO - 2025-05-03 13:29:49 --> URI Class Initialized
INFO - 2025-05-03 13:29:49 --> Router Class Initialized
INFO - 2025-05-03 13:29:49 --> Output Class Initialized
INFO - 2025-05-03 13:29:49 --> Security Class Initialized
DEBUG - 2025-05-03 13:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:29:49 --> Input Class Initialized
INFO - 2025-05-03 13:29:49 --> Language Class Initialized
INFO - 2025-05-03 13:29:49 --> Loader Class Initialized
INFO - 2025-05-03 13:29:49 --> Helper loaded: url_helper
INFO - 2025-05-03 13:29:49 --> Helper loaded: string_helper
INFO - 2025-05-03 13:29:49 --> Helper loaded: form_helper
INFO - 2025-05-03 13:29:49 --> Helper loaded: file_helper
INFO - 2025-05-03 13:29:49 --> Helper loaded: html_helper
INFO - 2025-05-03 13:29:49 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:29:49 --> Controller Class Initialized
INFO - 2025-05-03 21:29:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:29:49 --> Final output sent to browser
DEBUG - 2025-05-03 21:29:49 --> Total execution time: 0.1710
INFO - 2025-05-03 13:30:13 --> Config Class Initialized
INFO - 2025-05-03 13:30:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:30:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:30:13 --> Utf8 Class Initialized
INFO - 2025-05-03 13:30:13 --> URI Class Initialized
INFO - 2025-05-03 13:30:13 --> Router Class Initialized
INFO - 2025-05-03 13:30:13 --> Output Class Initialized
INFO - 2025-05-03 13:30:13 --> Security Class Initialized
DEBUG - 2025-05-03 13:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:30:13 --> Input Class Initialized
INFO - 2025-05-03 13:30:13 --> Language Class Initialized
INFO - 2025-05-03 13:30:13 --> Loader Class Initialized
INFO - 2025-05-03 13:30:13 --> Helper loaded: url_helper
INFO - 2025-05-03 13:30:13 --> Helper loaded: string_helper
INFO - 2025-05-03 13:30:13 --> Helper loaded: form_helper
INFO - 2025-05-03 13:30:13 --> Helper loaded: file_helper
INFO - 2025-05-03 13:30:13 --> Helper loaded: html_helper
INFO - 2025-05-03 13:30:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:30:13 --> Controller Class Initialized
INFO - 2025-05-03 21:30:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:30:13 --> Final output sent to browser
DEBUG - 2025-05-03 21:30:13 --> Total execution time: 0.1615
INFO - 2025-05-03 13:30:28 --> Config Class Initialized
INFO - 2025-05-03 13:30:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:30:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:30:28 --> Utf8 Class Initialized
INFO - 2025-05-03 13:30:28 --> URI Class Initialized
INFO - 2025-05-03 13:30:28 --> Router Class Initialized
INFO - 2025-05-03 13:30:28 --> Output Class Initialized
INFO - 2025-05-03 13:30:28 --> Security Class Initialized
DEBUG - 2025-05-03 13:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:30:28 --> Input Class Initialized
INFO - 2025-05-03 13:30:28 --> Language Class Initialized
INFO - 2025-05-03 13:30:28 --> Loader Class Initialized
INFO - 2025-05-03 13:30:28 --> Helper loaded: url_helper
INFO - 2025-05-03 13:30:28 --> Helper loaded: string_helper
INFO - 2025-05-03 13:30:28 --> Helper loaded: form_helper
INFO - 2025-05-03 13:30:28 --> Helper loaded: file_helper
INFO - 2025-05-03 13:30:28 --> Helper loaded: html_helper
INFO - 2025-05-03 13:30:28 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:30:28 --> Controller Class Initialized
INFO - 2025-05-03 21:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:30:29 --> Final output sent to browser
DEBUG - 2025-05-03 21:30:29 --> Total execution time: 0.1718
INFO - 2025-05-03 13:30:34 --> Config Class Initialized
INFO - 2025-05-03 13:30:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:30:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:30:34 --> Utf8 Class Initialized
INFO - 2025-05-03 13:30:34 --> URI Class Initialized
INFO - 2025-05-03 13:30:34 --> Router Class Initialized
INFO - 2025-05-03 13:30:34 --> Output Class Initialized
INFO - 2025-05-03 13:30:34 --> Security Class Initialized
DEBUG - 2025-05-03 13:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:30:34 --> Input Class Initialized
INFO - 2025-05-03 13:30:34 --> Language Class Initialized
INFO - 2025-05-03 13:30:34 --> Loader Class Initialized
INFO - 2025-05-03 13:30:34 --> Helper loaded: url_helper
INFO - 2025-05-03 13:30:34 --> Helper loaded: string_helper
INFO - 2025-05-03 13:30:34 --> Helper loaded: form_helper
INFO - 2025-05-03 13:30:34 --> Helper loaded: file_helper
INFO - 2025-05-03 13:30:34 --> Helper loaded: html_helper
INFO - 2025-05-03 13:30:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:30:34 --> Controller Class Initialized
INFO - 2025-05-03 21:30:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-03 21:30:34 --> Final output sent to browser
DEBUG - 2025-05-03 21:30:34 --> Total execution time: 0.0983
INFO - 2025-05-03 13:31:02 --> Config Class Initialized
INFO - 2025-05-03 13:31:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:31:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:31:02 --> Utf8 Class Initialized
INFO - 2025-05-03 13:31:02 --> URI Class Initialized
INFO - 2025-05-03 13:31:02 --> Router Class Initialized
INFO - 2025-05-03 13:31:02 --> Output Class Initialized
INFO - 2025-05-03 13:31:02 --> Security Class Initialized
DEBUG - 2025-05-03 13:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:31:02 --> Input Class Initialized
INFO - 2025-05-03 13:31:02 --> Language Class Initialized
INFO - 2025-05-03 13:31:03 --> Loader Class Initialized
INFO - 2025-05-03 13:31:03 --> Helper loaded: url_helper
INFO - 2025-05-03 13:31:03 --> Helper loaded: string_helper
INFO - 2025-05-03 13:31:03 --> Helper loaded: form_helper
INFO - 2025-05-03 13:31:03 --> Helper loaded: file_helper
INFO - 2025-05-03 13:31:03 --> Helper loaded: html_helper
INFO - 2025-05-03 13:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:31:03 --> Controller Class Initialized
INFO - 2025-05-03 21:31:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:31:03 --> Final output sent to browser
DEBUG - 2025-05-03 21:31:03 --> Total execution time: 0.4378
INFO - 2025-05-03 13:31:35 --> Config Class Initialized
INFO - 2025-05-03 13:31:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:31:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:31:36 --> Utf8 Class Initialized
INFO - 2025-05-03 13:31:36 --> URI Class Initialized
INFO - 2025-05-03 13:31:36 --> Router Class Initialized
INFO - 2025-05-03 13:31:36 --> Output Class Initialized
INFO - 2025-05-03 13:31:36 --> Security Class Initialized
DEBUG - 2025-05-03 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:31:36 --> Input Class Initialized
INFO - 2025-05-03 13:31:36 --> Language Class Initialized
INFO - 2025-05-03 13:31:36 --> Loader Class Initialized
INFO - 2025-05-03 13:31:36 --> Helper loaded: url_helper
INFO - 2025-05-03 13:31:36 --> Helper loaded: string_helper
INFO - 2025-05-03 13:31:36 --> Helper loaded: form_helper
INFO - 2025-05-03 13:31:36 --> Helper loaded: file_helper
INFO - 2025-05-03 13:31:36 --> Helper loaded: html_helper
INFO - 2025-05-03 13:31:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:31:36 --> Controller Class Initialized
INFO - 2025-05-03 21:31:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:31:36 --> Final output sent to browser
DEBUG - 2025-05-03 21:31:36 --> Total execution time: 0.2373
INFO - 2025-05-03 13:31:38 --> Config Class Initialized
INFO - 2025-05-03 13:31:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:31:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:31:38 --> Utf8 Class Initialized
INFO - 2025-05-03 13:31:38 --> URI Class Initialized
DEBUG - 2025-05-03 13:31:38 --> No URI present. Default controller set.
INFO - 2025-05-03 13:31:38 --> Router Class Initialized
INFO - 2025-05-03 13:31:38 --> Output Class Initialized
INFO - 2025-05-03 13:31:38 --> Security Class Initialized
DEBUG - 2025-05-03 13:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:31:38 --> Input Class Initialized
INFO - 2025-05-03 13:31:38 --> Language Class Initialized
INFO - 2025-05-03 13:31:38 --> Loader Class Initialized
INFO - 2025-05-03 13:31:38 --> Helper loaded: url_helper
INFO - 2025-05-03 13:31:38 --> Helper loaded: string_helper
INFO - 2025-05-03 13:31:38 --> Helper loaded: form_helper
INFO - 2025-05-03 13:31:38 --> Helper loaded: file_helper
INFO - 2025-05-03 13:31:38 --> Helper loaded: html_helper
INFO - 2025-05-03 13:31:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:31:38 --> Controller Class Initialized
INFO - 2025-05-03 13:31:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:31:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:31:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 13:31:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:31:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:31:38 --> Final output sent to browser
DEBUG - 2025-05-03 13:31:38 --> Total execution time: 0.1350
INFO - 2025-05-03 13:31:41 --> Config Class Initialized
INFO - 2025-05-03 13:31:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:31:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:31:41 --> Utf8 Class Initialized
INFO - 2025-05-03 13:31:41 --> URI Class Initialized
INFO - 2025-05-03 13:31:41 --> Router Class Initialized
INFO - 2025-05-03 13:31:41 --> Output Class Initialized
INFO - 2025-05-03 13:31:41 --> Security Class Initialized
DEBUG - 2025-05-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:31:41 --> Input Class Initialized
INFO - 2025-05-03 13:31:41 --> Language Class Initialized
INFO - 2025-05-03 13:31:42 --> Loader Class Initialized
INFO - 2025-05-03 13:31:42 --> Helper loaded: url_helper
INFO - 2025-05-03 13:31:42 --> Helper loaded: string_helper
INFO - 2025-05-03 13:31:42 --> Helper loaded: form_helper
INFO - 2025-05-03 13:31:42 --> Helper loaded: file_helper
INFO - 2025-05-03 13:31:42 --> Helper loaded: html_helper
INFO - 2025-05-03 13:31:42 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:31:42 --> Controller Class Initialized
INFO - 2025-05-03 21:31:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:31:42 --> Final output sent to browser
DEBUG - 2025-05-03 21:31:42 --> Total execution time: 0.2441
INFO - 2025-05-03 13:33:04 --> Config Class Initialized
INFO - 2025-05-03 13:33:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:33:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:33:04 --> Utf8 Class Initialized
INFO - 2025-05-03 13:33:04 --> URI Class Initialized
INFO - 2025-05-03 13:33:04 --> Router Class Initialized
INFO - 2025-05-03 13:33:04 --> Output Class Initialized
INFO - 2025-05-03 13:33:04 --> Security Class Initialized
DEBUG - 2025-05-03 13:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:33:04 --> Input Class Initialized
INFO - 2025-05-03 13:33:04 --> Language Class Initialized
INFO - 2025-05-03 13:33:04 --> Loader Class Initialized
INFO - 2025-05-03 13:33:04 --> Helper loaded: url_helper
INFO - 2025-05-03 13:33:04 --> Helper loaded: string_helper
INFO - 2025-05-03 13:33:04 --> Helper loaded: form_helper
INFO - 2025-05-03 13:33:04 --> Helper loaded: file_helper
INFO - 2025-05-03 13:33:04 --> Helper loaded: html_helper
INFO - 2025-05-03 13:33:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:33:04 --> Controller Class Initialized
INFO - 2025-05-03 21:33:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:33:04 --> Final output sent to browser
DEBUG - 2025-05-03 21:33:04 --> Total execution time: 0.2240
INFO - 2025-05-03 13:33:15 --> Config Class Initialized
INFO - 2025-05-03 13:33:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:33:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:33:15 --> Utf8 Class Initialized
INFO - 2025-05-03 13:33:15 --> URI Class Initialized
INFO - 2025-05-03 13:33:15 --> Router Class Initialized
INFO - 2025-05-03 13:33:15 --> Output Class Initialized
INFO - 2025-05-03 13:33:15 --> Security Class Initialized
DEBUG - 2025-05-03 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:33:15 --> Input Class Initialized
INFO - 2025-05-03 13:33:15 --> Language Class Initialized
INFO - 2025-05-03 13:33:15 --> Loader Class Initialized
INFO - 2025-05-03 13:33:15 --> Helper loaded: url_helper
INFO - 2025-05-03 13:33:15 --> Helper loaded: string_helper
INFO - 2025-05-03 13:33:15 --> Helper loaded: form_helper
INFO - 2025-05-03 13:33:15 --> Helper loaded: file_helper
INFO - 2025-05-03 13:33:15 --> Helper loaded: html_helper
INFO - 2025-05-03 13:33:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:33:15 --> Controller Class Initialized
INFO - 2025-05-03 21:33:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:33:15 --> Final output sent to browser
DEBUG - 2025-05-03 21:33:15 --> Total execution time: 0.1535
INFO - 2025-05-03 13:33:50 --> Config Class Initialized
INFO - 2025-05-03 13:33:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:33:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:33:50 --> Utf8 Class Initialized
INFO - 2025-05-03 13:33:50 --> URI Class Initialized
INFO - 2025-05-03 13:33:50 --> Router Class Initialized
INFO - 2025-05-03 13:33:50 --> Output Class Initialized
INFO - 2025-05-03 13:33:50 --> Security Class Initialized
DEBUG - 2025-05-03 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:33:50 --> Input Class Initialized
INFO - 2025-05-03 13:33:50 --> Language Class Initialized
INFO - 2025-05-03 13:33:50 --> Loader Class Initialized
INFO - 2025-05-03 13:33:50 --> Helper loaded: url_helper
INFO - 2025-05-03 13:33:50 --> Helper loaded: string_helper
INFO - 2025-05-03 13:33:50 --> Helper loaded: form_helper
INFO - 2025-05-03 13:33:50 --> Helper loaded: file_helper
INFO - 2025-05-03 13:33:50 --> Helper loaded: html_helper
INFO - 2025-05-03 13:33:50 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:33:50 --> Controller Class Initialized
INFO - 2025-05-03 21:33:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:33:50 --> Final output sent to browser
DEBUG - 2025-05-03 21:33:50 --> Total execution time: 0.1337
INFO - 2025-05-03 13:36:03 --> Config Class Initialized
INFO - 2025-05-03 13:36:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:36:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:36:03 --> Utf8 Class Initialized
INFO - 2025-05-03 13:36:03 --> URI Class Initialized
INFO - 2025-05-03 13:36:03 --> Router Class Initialized
INFO - 2025-05-03 13:36:03 --> Output Class Initialized
INFO - 2025-05-03 13:36:03 --> Security Class Initialized
DEBUG - 2025-05-03 13:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:36:03 --> Input Class Initialized
INFO - 2025-05-03 13:36:03 --> Language Class Initialized
INFO - 2025-05-03 13:36:03 --> Loader Class Initialized
INFO - 2025-05-03 13:36:03 --> Helper loaded: url_helper
INFO - 2025-05-03 13:36:03 --> Helper loaded: string_helper
INFO - 2025-05-03 13:36:03 --> Helper loaded: form_helper
INFO - 2025-05-03 13:36:03 --> Helper loaded: file_helper
INFO - 2025-05-03 13:36:03 --> Helper loaded: html_helper
INFO - 2025-05-03 13:36:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:36:03 --> Controller Class Initialized
INFO - 2025-05-03 21:36:03 --> Model "UserModel" initialized
ERROR - 2025-05-03 21:36:03 --> Query error: Table 'db_storage_auctions.tbl_user_status_type_relationship' doesn't exist - Invalid query: UPDATE `tbl_user_status_type_relationship` SET `user_status_type_id` = 1, `updated_at` = '2025-05-03 21:36:03'
WHERE `user_id` = '13'
INFO - 2025-05-03 21:36:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-03 13:38:54 --> Config Class Initialized
INFO - 2025-05-03 13:38:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:38:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:38:54 --> Utf8 Class Initialized
INFO - 2025-05-03 13:38:54 --> URI Class Initialized
INFO - 2025-05-03 13:38:54 --> Router Class Initialized
INFO - 2025-05-03 13:38:54 --> Output Class Initialized
INFO - 2025-05-03 13:38:54 --> Security Class Initialized
DEBUG - 2025-05-03 13:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:38:54 --> Input Class Initialized
INFO - 2025-05-03 13:38:54 --> Language Class Initialized
INFO - 2025-05-03 13:38:54 --> Loader Class Initialized
INFO - 2025-05-03 13:38:54 --> Helper loaded: url_helper
INFO - 2025-05-03 13:38:54 --> Helper loaded: string_helper
INFO - 2025-05-03 13:38:54 --> Helper loaded: form_helper
INFO - 2025-05-03 13:38:54 --> Helper loaded: file_helper
INFO - 2025-05-03 13:38:54 --> Helper loaded: html_helper
INFO - 2025-05-03 13:38:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:38:54 --> Controller Class Initialized
INFO - 2025-05-03 21:38:54 --> Model "UserModel" initialized
INFO - 2025-05-03 21:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-03 21:38:54 --> Final output sent to browser
DEBUG - 2025-05-03 21:38:54 --> Total execution time: 0.2220
INFO - 2025-05-03 13:39:03 --> Config Class Initialized
INFO - 2025-05-03 13:39:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:03 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:03 --> URI Class Initialized
INFO - 2025-05-03 13:39:03 --> Router Class Initialized
INFO - 2025-05-03 13:39:03 --> Output Class Initialized
INFO - 2025-05-03 13:39:03 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:03 --> Input Class Initialized
INFO - 2025-05-03 13:39:03 --> Language Class Initialized
INFO - 2025-05-03 13:39:03 --> Loader Class Initialized
INFO - 2025-05-03 13:39:03 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:03 --> Helper loaded: string_helper
INFO - 2025-05-03 13:39:03 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:03 --> Helper loaded: file_helper
INFO - 2025-05-03 13:39:03 --> Helper loaded: html_helper
INFO - 2025-05-03 13:39:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:03 --> Controller Class Initialized
INFO - 2025-05-03 21:39:03 --> Model "UserModel" initialized
INFO - 2025-05-03 21:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:39:03 --> Final output sent to browser
DEBUG - 2025-05-03 21:39:03 --> Total execution time: 0.1089
INFO - 2025-05-03 13:39:06 --> Config Class Initialized
INFO - 2025-05-03 13:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:06 --> URI Class Initialized
INFO - 2025-05-03 13:39:06 --> Router Class Initialized
INFO - 2025-05-03 13:39:06 --> Output Class Initialized
INFO - 2025-05-03 13:39:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:06 --> Input Class Initialized
INFO - 2025-05-03 13:39:06 --> Language Class Initialized
INFO - 2025-05-03 13:39:06 --> Loader Class Initialized
INFO - 2025-05-03 13:39:06 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:06 --> Helper loaded: string_helper
INFO - 2025-05-03 13:39:06 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:06 --> Helper loaded: file_helper
INFO - 2025-05-03 13:39:06 --> Helper loaded: html_helper
INFO - 2025-05-03 13:39:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:06 --> Controller Class Initialized
INFO - 2025-05-03 21:39:06 --> Model "UserModel" initialized
INFO - 2025-05-03 21:39:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:39:06 --> Final output sent to browser
DEBUG - 2025-05-03 21:39:06 --> Total execution time: 0.1151
INFO - 2025-05-03 13:39:48 --> Config Class Initialized
INFO - 2025-05-03 13:39:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:48 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:48 --> URI Class Initialized
INFO - 2025-05-03 13:39:48 --> Router Class Initialized
INFO - 2025-05-03 13:39:48 --> Output Class Initialized
INFO - 2025-05-03 13:39:48 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:48 --> Input Class Initialized
INFO - 2025-05-03 13:39:48 --> Language Class Initialized
INFO - 2025-05-03 13:39:48 --> Loader Class Initialized
INFO - 2025-05-03 13:39:48 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:48 --> Helper loaded: string_helper
INFO - 2025-05-03 13:39:48 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:48 --> Helper loaded: file_helper
INFO - 2025-05-03 13:39:48 --> Helper loaded: html_helper
INFO - 2025-05-03 13:39:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:48 --> Controller Class Initialized
INFO - 2025-05-03 21:39:48 --> Model "UserModel" initialized
INFO - 2025-05-03 21:39:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-03 21:39:48 --> Final output sent to browser
DEBUG - 2025-05-03 21:39:48 --> Total execution time: 0.1087
INFO - 2025-05-03 13:39:56 --> Config Class Initialized
INFO - 2025-05-03 13:39:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:56 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:56 --> URI Class Initialized
INFO - 2025-05-03 13:39:56 --> Router Class Initialized
INFO - 2025-05-03 13:39:56 --> Output Class Initialized
INFO - 2025-05-03 13:39:56 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:56 --> Input Class Initialized
INFO - 2025-05-03 13:39:56 --> Language Class Initialized
INFO - 2025-05-03 13:39:56 --> Loader Class Initialized
INFO - 2025-05-03 13:39:56 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:56 --> Helper loaded: string_helper
INFO - 2025-05-03 13:39:56 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:56 --> Helper loaded: file_helper
INFO - 2025-05-03 13:39:56 --> Helper loaded: html_helper
INFO - 2025-05-03 13:39:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:57 --> Controller Class Initialized
INFO - 2025-05-03 21:39:57 --> Model "UserModel" initialized
INFO - 2025-05-03 13:39:58 --> Config Class Initialized
INFO - 2025-05-03 13:39:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:58 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:58 --> URI Class Initialized
DEBUG - 2025-05-03 13:39:58 --> No URI present. Default controller set.
INFO - 2025-05-03 13:39:58 --> Router Class Initialized
INFO - 2025-05-03 13:39:58 --> Output Class Initialized
INFO - 2025-05-03 13:39:58 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:58 --> Input Class Initialized
INFO - 2025-05-03 13:39:58 --> Language Class Initialized
INFO - 2025-05-03 13:39:58 --> Loader Class Initialized
INFO - 2025-05-03 13:39:58 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:58 --> Helper loaded: string_helper
INFO - 2025-05-03 13:39:58 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:58 --> Helper loaded: file_helper
INFO - 2025-05-03 13:39:58 --> Helper loaded: html_helper
INFO - 2025-05-03 13:39:58 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:58 --> Controller Class Initialized
INFO - 2025-05-03 13:39:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:39:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:39:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 13:39:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:39:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:39:58 --> Final output sent to browser
DEBUG - 2025-05-03 13:39:58 --> Total execution time: 0.1279
INFO - 2025-05-03 13:40:00 --> Config Class Initialized
INFO - 2025-05-03 13:40:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:00 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:00 --> URI Class Initialized
INFO - 2025-05-03 13:40:00 --> Router Class Initialized
INFO - 2025-05-03 13:40:00 --> Output Class Initialized
INFO - 2025-05-03 13:40:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:00 --> Input Class Initialized
INFO - 2025-05-03 13:40:00 --> Language Class Initialized
INFO - 2025-05-03 13:40:00 --> Loader Class Initialized
INFO - 2025-05-03 13:40:00 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:00 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:00 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:00 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:00 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:00 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:00 --> Controller Class Initialized
INFO - 2025-05-03 21:40:00 --> Model "AuctionModel" initialized
INFO - 2025-05-03 13:40:01 --> Config Class Initialized
INFO - 2025-05-03 13:40:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:01 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:01 --> URI Class Initialized
INFO - 2025-05-03 13:40:01 --> Router Class Initialized
INFO - 2025-05-03 13:40:01 --> Output Class Initialized
INFO - 2025-05-03 13:40:01 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:01 --> Input Class Initialized
INFO - 2025-05-03 13:40:01 --> Language Class Initialized
INFO - 2025-05-03 13:40:01 --> Loader Class Initialized
INFO - 2025-05-03 13:40:01 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:01 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:01 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:01 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:01 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:01 --> Controller Class Initialized
INFO - 2025-05-03 13:40:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:40:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:40:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:40:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:40:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:40:01 --> Final output sent to browser
DEBUG - 2025-05-03 13:40:01 --> Total execution time: 0.1553
INFO - 2025-05-03 13:40:03 --> Config Class Initialized
INFO - 2025-05-03 13:40:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:03 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:03 --> URI Class Initialized
INFO - 2025-05-03 13:40:03 --> Router Class Initialized
INFO - 2025-05-03 13:40:03 --> Output Class Initialized
INFO - 2025-05-03 13:40:03 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:03 --> Input Class Initialized
INFO - 2025-05-03 13:40:03 --> Language Class Initialized
INFO - 2025-05-03 13:40:03 --> Loader Class Initialized
INFO - 2025-05-03 13:40:03 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:03 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:03 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:03 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:03 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:03 --> Controller Class Initialized
INFO - 2025-05-03 21:40:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:40:03 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:03 --> Total execution time: 0.1641
INFO - 2025-05-03 13:40:04 --> Config Class Initialized
INFO - 2025-05-03 13:40:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:04 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:04 --> URI Class Initialized
INFO - 2025-05-03 13:40:04 --> Router Class Initialized
INFO - 2025-05-03 13:40:04 --> Output Class Initialized
INFO - 2025-05-03 13:40:04 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:04 --> Input Class Initialized
INFO - 2025-05-03 13:40:04 --> Language Class Initialized
INFO - 2025-05-03 13:40:04 --> Loader Class Initialized
INFO - 2025-05-03 13:40:04 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:04 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:04 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:04 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:04 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:04 --> Controller Class Initialized
INFO - 2025-05-03 21:40:04 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:40:04 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:04 --> Total execution time: 0.2436
INFO - 2025-05-03 13:40:05 --> Config Class Initialized
INFO - 2025-05-03 13:40:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:05 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:05 --> URI Class Initialized
INFO - 2025-05-03 13:40:05 --> Router Class Initialized
INFO - 2025-05-03 13:40:05 --> Output Class Initialized
INFO - 2025-05-03 13:40:05 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:05 --> Input Class Initialized
INFO - 2025-05-03 13:40:05 --> Language Class Initialized
INFO - 2025-05-03 13:40:05 --> Loader Class Initialized
INFO - 2025-05-03 13:40:05 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:05 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:05 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:05 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:05 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:05 --> Controller Class Initialized
INFO - 2025-05-03 21:40:05 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:40:05 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:05 --> Total execution time: 0.1795
INFO - 2025-05-03 13:40:06 --> Config Class Initialized
INFO - 2025-05-03 13:40:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:06 --> URI Class Initialized
INFO - 2025-05-03 13:40:06 --> Router Class Initialized
INFO - 2025-05-03 13:40:06 --> Output Class Initialized
INFO - 2025-05-03 13:40:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:06 --> Input Class Initialized
INFO - 2025-05-03 13:40:06 --> Language Class Initialized
INFO - 2025-05-03 13:40:06 --> Loader Class Initialized
INFO - 2025-05-03 13:40:06 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:06 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:06 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:06 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:06 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:06 --> Controller Class Initialized
INFO - 2025-05-03 21:40:06 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:40:06 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:06 --> Total execution time: 0.1683
INFO - 2025-05-03 13:40:06 --> Config Class Initialized
INFO - 2025-05-03 13:40:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:06 --> URI Class Initialized
INFO - 2025-05-03 13:40:06 --> Router Class Initialized
INFO - 2025-05-03 13:40:06 --> Output Class Initialized
INFO - 2025-05-03 13:40:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:06 --> Input Class Initialized
INFO - 2025-05-03 13:40:06 --> Language Class Initialized
INFO - 2025-05-03 13:40:07 --> Loader Class Initialized
INFO - 2025-05-03 13:40:07 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:07 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:07 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:07 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:07 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:07 --> Controller Class Initialized
INFO - 2025-05-03 21:40:07 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:40:50 --> Config Class Initialized
INFO - 2025-05-03 13:40:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:50 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:50 --> URI Class Initialized
INFO - 2025-05-03 13:40:50 --> Router Class Initialized
INFO - 2025-05-03 13:40:50 --> Output Class Initialized
INFO - 2025-05-03 13:40:50 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:50 --> Input Class Initialized
INFO - 2025-05-03 13:40:50 --> Language Class Initialized
INFO - 2025-05-03 13:40:50 --> Loader Class Initialized
INFO - 2025-05-03 13:40:50 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:50 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:50 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:50 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:50 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:50 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:50 --> Controller Class Initialized
INFO - 2025-05-03 13:40:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:40:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:40:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-03 13:40:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:40:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:40:50 --> Final output sent to browser
DEBUG - 2025-05-03 13:40:50 --> Total execution time: 0.1243
INFO - 2025-05-03 13:40:52 --> Config Class Initialized
INFO - 2025-05-03 13:40:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:52 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:52 --> URI Class Initialized
INFO - 2025-05-03 13:40:52 --> Router Class Initialized
INFO - 2025-05-03 13:40:52 --> Output Class Initialized
INFO - 2025-05-03 13:40:52 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:52 --> Input Class Initialized
INFO - 2025-05-03 13:40:52 --> Language Class Initialized
INFO - 2025-05-03 13:40:52 --> Loader Class Initialized
INFO - 2025-05-03 13:40:52 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:52 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:52 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:52 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:52 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:52 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:52 --> Controller Class Initialized
INFO - 2025-05-03 21:40:52 --> Model "UserModel" initialized
INFO - 2025-05-03 21:40:52 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:52 --> Total execution time: 0.1305
INFO - 2025-05-03 13:40:55 --> Config Class Initialized
INFO - 2025-05-03 13:40:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:55 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:55 --> URI Class Initialized
INFO - 2025-05-03 13:40:55 --> Router Class Initialized
INFO - 2025-05-03 13:40:55 --> Output Class Initialized
INFO - 2025-05-03 13:40:55 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:55 --> Input Class Initialized
INFO - 2025-05-03 13:40:55 --> Language Class Initialized
INFO - 2025-05-03 13:40:55 --> Loader Class Initialized
INFO - 2025-05-03 13:40:55 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:55 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:55 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:55 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:55 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:55 --> Controller Class Initialized
INFO - 2025-05-03 13:40:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:40:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:40:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/payment.php
INFO - 2025-05-03 13:40:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:40:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:40:55 --> Final output sent to browser
DEBUG - 2025-05-03 13:40:55 --> Total execution time: 0.1211
INFO - 2025-05-03 13:40:56 --> Config Class Initialized
INFO - 2025-05-03 13:40:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:40:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:40:56 --> Utf8 Class Initialized
INFO - 2025-05-03 13:40:56 --> URI Class Initialized
INFO - 2025-05-03 13:40:56 --> Router Class Initialized
INFO - 2025-05-03 13:40:56 --> Output Class Initialized
INFO - 2025-05-03 13:40:56 --> Security Class Initialized
DEBUG - 2025-05-03 13:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:40:56 --> Input Class Initialized
INFO - 2025-05-03 13:40:56 --> Language Class Initialized
INFO - 2025-05-03 13:40:56 --> Loader Class Initialized
INFO - 2025-05-03 13:40:56 --> Helper loaded: url_helper
INFO - 2025-05-03 13:40:56 --> Helper loaded: string_helper
INFO - 2025-05-03 13:40:56 --> Helper loaded: form_helper
INFO - 2025-05-03 13:40:56 --> Helper loaded: file_helper
INFO - 2025-05-03 13:40:57 --> Helper loaded: html_helper
INFO - 2025-05-03 13:40:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:40:57 --> Controller Class Initialized
INFO - 2025-05-03 21:40:57 --> Model "UserModel" initialized
INFO - 2025-05-03 21:40:57 --> Final output sent to browser
DEBUG - 2025-05-03 21:40:57 --> Total execution time: 0.4979
INFO - 2025-05-03 13:41:00 --> Config Class Initialized
INFO - 2025-05-03 13:41:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:00 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:00 --> URI Class Initialized
INFO - 2025-05-03 13:41:00 --> Router Class Initialized
INFO - 2025-05-03 13:41:00 --> Output Class Initialized
INFO - 2025-05-03 13:41:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:00 --> Input Class Initialized
INFO - 2025-05-03 13:41:00 --> Language Class Initialized
INFO - 2025-05-03 13:41:00 --> Loader Class Initialized
INFO - 2025-05-03 13:41:00 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:00 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:00 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:00 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:00 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:00 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:00 --> Controller Class Initialized
INFO - 2025-05-03 13:41:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:41:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:41:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/notifications.php
INFO - 2025-05-03 13:41:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:41:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:41:01 --> Final output sent to browser
DEBUG - 2025-05-03 13:41:01 --> Total execution time: 0.2069
INFO - 2025-05-03 13:41:02 --> Config Class Initialized
INFO - 2025-05-03 13:41:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:02 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:02 --> URI Class Initialized
INFO - 2025-05-03 13:41:02 --> Router Class Initialized
INFO - 2025-05-03 13:41:02 --> Output Class Initialized
INFO - 2025-05-03 13:41:02 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:02 --> Input Class Initialized
INFO - 2025-05-03 13:41:02 --> Language Class Initialized
INFO - 2025-05-03 13:41:02 --> Loader Class Initialized
INFO - 2025-05-03 13:41:02 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:02 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:02 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:02 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:02 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:03 --> Controller Class Initialized
INFO - 2025-05-03 21:41:03 --> Model "NotificationsModel" initialized
INFO - 2025-05-03 21:41:03 --> Final output sent to browser
DEBUG - 2025-05-03 21:41:03 --> Total execution time: 0.3912
INFO - 2025-05-03 13:41:08 --> Config Class Initialized
INFO - 2025-05-03 13:41:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:08 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:08 --> URI Class Initialized
INFO - 2025-05-03 13:41:08 --> Router Class Initialized
INFO - 2025-05-03 13:41:08 --> Output Class Initialized
INFO - 2025-05-03 13:41:08 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:08 --> Input Class Initialized
INFO - 2025-05-03 13:41:08 --> Language Class Initialized
INFO - 2025-05-03 13:41:08 --> Loader Class Initialized
INFO - 2025-05-03 13:41:08 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:08 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:08 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:08 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:08 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:08 --> Controller Class Initialized
INFO - 2025-05-03 13:41:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:41:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:41:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:41:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:41:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:41:08 --> Final output sent to browser
DEBUG - 2025-05-03 13:41:08 --> Total execution time: 0.1429
INFO - 2025-05-03 13:41:11 --> Config Class Initialized
INFO - 2025-05-03 13:41:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:11 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:11 --> URI Class Initialized
INFO - 2025-05-03 13:41:11 --> Router Class Initialized
INFO - 2025-05-03 13:41:11 --> Output Class Initialized
INFO - 2025-05-03 13:41:11 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:11 --> Input Class Initialized
INFO - 2025-05-03 13:41:11 --> Language Class Initialized
INFO - 2025-05-03 13:41:11 --> Loader Class Initialized
INFO - 2025-05-03 13:41:11 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:11 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:11 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:11 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:11 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:11 --> Controller Class Initialized
INFO - 2025-05-03 21:41:11 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:41:11 --> Final output sent to browser
DEBUG - 2025-05-03 21:41:11 --> Total execution time: 0.1143
INFO - 2025-05-03 13:41:29 --> Config Class Initialized
INFO - 2025-05-03 13:41:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:29 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:29 --> URI Class Initialized
INFO - 2025-05-03 13:41:29 --> Router Class Initialized
INFO - 2025-05-03 13:41:29 --> Output Class Initialized
INFO - 2025-05-03 13:41:29 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:29 --> Input Class Initialized
INFO - 2025-05-03 13:41:29 --> Language Class Initialized
INFO - 2025-05-03 13:41:30 --> Loader Class Initialized
INFO - 2025-05-03 13:41:30 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:30 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:30 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:30 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:30 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:30 --> Controller Class Initialized
INFO - 2025-05-03 21:41:30 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:41:38 --> Config Class Initialized
INFO - 2025-05-03 13:41:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:38 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:38 --> URI Class Initialized
INFO - 2025-05-03 13:41:38 --> Router Class Initialized
INFO - 2025-05-03 13:41:38 --> Output Class Initialized
INFO - 2025-05-03 13:41:38 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:38 --> Input Class Initialized
INFO - 2025-05-03 13:41:38 --> Language Class Initialized
INFO - 2025-05-03 13:41:38 --> Loader Class Initialized
INFO - 2025-05-03 13:41:38 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:38 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:38 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:38 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:38 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:38 --> Controller Class Initialized
INFO - 2025-05-03 21:41:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:41:38 --> Final output sent to browser
DEBUG - 2025-05-03 21:41:38 --> Total execution time: 0.1301
INFO - 2025-05-03 13:41:39 --> Config Class Initialized
INFO - 2025-05-03 13:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:39 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:39 --> URI Class Initialized
INFO - 2025-05-03 13:41:39 --> Router Class Initialized
INFO - 2025-05-03 13:41:39 --> Output Class Initialized
INFO - 2025-05-03 13:41:39 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:39 --> Input Class Initialized
INFO - 2025-05-03 13:41:39 --> Language Class Initialized
INFO - 2025-05-03 13:41:39 --> Loader Class Initialized
INFO - 2025-05-03 13:41:39 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:39 --> Helper loaded: string_helper
INFO - 2025-05-03 13:41:39 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:39 --> Helper loaded: file_helper
INFO - 2025-05-03 13:41:39 --> Helper loaded: html_helper
INFO - 2025-05-03 13:41:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:39 --> Controller Class Initialized
INFO - 2025-05-03 21:41:39 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:42:15 --> Config Class Initialized
INFO - 2025-05-03 13:42:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:15 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:15 --> URI Class Initialized
INFO - 2025-05-03 13:42:15 --> Router Class Initialized
INFO - 2025-05-03 13:42:15 --> Output Class Initialized
INFO - 2025-05-03 13:42:15 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:15 --> Input Class Initialized
INFO - 2025-05-03 13:42:15 --> Language Class Initialized
INFO - 2025-05-03 13:42:15 --> Loader Class Initialized
INFO - 2025-05-03 13:42:15 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:15 --> Helper loaded: string_helper
INFO - 2025-05-03 13:42:15 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:15 --> Helper loaded: file_helper
INFO - 2025-05-03 13:42:15 --> Helper loaded: html_helper
INFO - 2025-05-03 13:42:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:15 --> Controller Class Initialized
INFO - 2025-05-03 21:42:15 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:42:18 --> Config Class Initialized
INFO - 2025-05-03 13:42:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:18 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:18 --> URI Class Initialized
INFO - 2025-05-03 13:42:18 --> Router Class Initialized
INFO - 2025-05-03 13:42:18 --> Output Class Initialized
INFO - 2025-05-03 13:42:18 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:18 --> Input Class Initialized
INFO - 2025-05-03 13:42:18 --> Language Class Initialized
INFO - 2025-05-03 13:42:18 --> Loader Class Initialized
INFO - 2025-05-03 13:42:18 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:18 --> Helper loaded: string_helper
INFO - 2025-05-03 13:42:18 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:18 --> Helper loaded: file_helper
INFO - 2025-05-03 13:42:18 --> Helper loaded: html_helper
INFO - 2025-05-03 13:42:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:18 --> Controller Class Initialized
INFO - 2025-05-03 21:42:18 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:42:56 --> Config Class Initialized
INFO - 2025-05-03 13:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:56 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:56 --> URI Class Initialized
INFO - 2025-05-03 13:42:56 --> Router Class Initialized
INFO - 2025-05-03 13:42:56 --> Output Class Initialized
INFO - 2025-05-03 13:42:56 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:56 --> Input Class Initialized
INFO - 2025-05-03 13:42:56 --> Language Class Initialized
INFO - 2025-05-03 13:42:56 --> Loader Class Initialized
INFO - 2025-05-03 13:42:56 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:56 --> Helper loaded: string_helper
INFO - 2025-05-03 13:42:56 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:56 --> Helper loaded: file_helper
INFO - 2025-05-03 13:42:56 --> Helper loaded: html_helper
INFO - 2025-05-03 13:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:56 --> Controller Class Initialized
INFO - 2025-05-03 21:42:56 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:42:56 --> Final output sent to browser
DEBUG - 2025-05-03 21:42:56 --> Total execution time: 0.1994
INFO - 2025-05-03 13:42:57 --> Config Class Initialized
INFO - 2025-05-03 13:42:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:57 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:57 --> URI Class Initialized
INFO - 2025-05-03 13:42:57 --> Router Class Initialized
INFO - 2025-05-03 13:42:57 --> Output Class Initialized
INFO - 2025-05-03 13:42:57 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:57 --> Input Class Initialized
INFO - 2025-05-03 13:42:57 --> Language Class Initialized
INFO - 2025-05-03 13:42:57 --> Loader Class Initialized
INFO - 2025-05-03 13:42:57 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:57 --> Helper loaded: string_helper
INFO - 2025-05-03 13:42:57 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:57 --> Helper loaded: file_helper
INFO - 2025-05-03 13:42:57 --> Helper loaded: html_helper
INFO - 2025-05-03 13:42:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:57 --> Controller Class Initialized
INFO - 2025-05-03 21:42:57 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:43:01 --> Config Class Initialized
INFO - 2025-05-03 13:43:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:43:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:43:01 --> Utf8 Class Initialized
INFO - 2025-05-03 13:43:01 --> URI Class Initialized
INFO - 2025-05-03 13:43:01 --> Router Class Initialized
INFO - 2025-05-03 13:43:01 --> Output Class Initialized
INFO - 2025-05-03 13:43:01 --> Security Class Initialized
DEBUG - 2025-05-03 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:43:01 --> Input Class Initialized
INFO - 2025-05-03 13:43:01 --> Language Class Initialized
INFO - 2025-05-03 13:43:01 --> Loader Class Initialized
INFO - 2025-05-03 13:43:01 --> Helper loaded: url_helper
INFO - 2025-05-03 13:43:01 --> Helper loaded: string_helper
INFO - 2025-05-03 13:43:02 --> Helper loaded: form_helper
INFO - 2025-05-03 13:43:02 --> Helper loaded: file_helper
INFO - 2025-05-03 13:43:02 --> Helper loaded: html_helper
INFO - 2025-05-03 13:43:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:43:02 --> Controller Class Initialized
INFO - 2025-05-03 21:43:02 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:43:09 --> Config Class Initialized
INFO - 2025-05-03 13:43:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:43:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:43:09 --> Utf8 Class Initialized
INFO - 2025-05-03 13:43:09 --> URI Class Initialized
INFO - 2025-05-03 13:43:09 --> Router Class Initialized
INFO - 2025-05-03 13:43:09 --> Output Class Initialized
INFO - 2025-05-03 13:43:09 --> Security Class Initialized
DEBUG - 2025-05-03 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:43:09 --> Input Class Initialized
INFO - 2025-05-03 13:43:09 --> Language Class Initialized
INFO - 2025-05-03 13:43:09 --> Loader Class Initialized
INFO - 2025-05-03 13:43:09 --> Helper loaded: url_helper
INFO - 2025-05-03 13:43:09 --> Helper loaded: string_helper
INFO - 2025-05-03 13:43:09 --> Helper loaded: form_helper
INFO - 2025-05-03 13:43:09 --> Helper loaded: file_helper
INFO - 2025-05-03 13:43:09 --> Helper loaded: html_helper
INFO - 2025-05-03 13:43:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:43:09 --> Controller Class Initialized
INFO - 2025-05-03 21:43:09 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:43:09 --> Final output sent to browser
DEBUG - 2025-05-03 21:43:09 --> Total execution time: 0.2303
INFO - 2025-05-03 13:43:13 --> Config Class Initialized
INFO - 2025-05-03 13:43:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:43:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:43:13 --> Utf8 Class Initialized
INFO - 2025-05-03 13:43:13 --> URI Class Initialized
INFO - 2025-05-03 13:43:13 --> Router Class Initialized
INFO - 2025-05-03 13:43:13 --> Output Class Initialized
INFO - 2025-05-03 13:43:13 --> Security Class Initialized
DEBUG - 2025-05-03 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:43:13 --> Input Class Initialized
INFO - 2025-05-03 13:43:13 --> Language Class Initialized
INFO - 2025-05-03 13:43:13 --> Loader Class Initialized
INFO - 2025-05-03 13:43:13 --> Helper loaded: url_helper
INFO - 2025-05-03 13:43:13 --> Helper loaded: string_helper
INFO - 2025-05-03 13:43:13 --> Helper loaded: form_helper
INFO - 2025-05-03 13:43:13 --> Helper loaded: file_helper
INFO - 2025-05-03 13:43:13 --> Helper loaded: html_helper
INFO - 2025-05-03 13:43:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:43:13 --> Controller Class Initialized
INFO - 2025-05-03 21:43:13 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:43:40 --> Config Class Initialized
INFO - 2025-05-03 13:43:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:43:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:43:40 --> Utf8 Class Initialized
INFO - 2025-05-03 13:43:40 --> URI Class Initialized
INFO - 2025-05-03 13:43:40 --> Router Class Initialized
INFO - 2025-05-03 13:43:40 --> Output Class Initialized
INFO - 2025-05-03 13:43:40 --> Security Class Initialized
DEBUG - 2025-05-03 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:43:40 --> Input Class Initialized
INFO - 2025-05-03 13:43:40 --> Language Class Initialized
INFO - 2025-05-03 13:43:40 --> Loader Class Initialized
INFO - 2025-05-03 13:43:40 --> Helper loaded: url_helper
INFO - 2025-05-03 13:43:40 --> Helper loaded: string_helper
INFO - 2025-05-03 13:43:40 --> Helper loaded: form_helper
INFO - 2025-05-03 13:43:40 --> Helper loaded: file_helper
INFO - 2025-05-03 13:43:40 --> Helper loaded: html_helper
INFO - 2025-05-03 13:43:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:43:40 --> Controller Class Initialized
INFO - 2025-05-03 21:43:40 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:43:40 --> Final output sent to browser
DEBUG - 2025-05-03 21:43:40 --> Total execution time: 0.2167
INFO - 2025-05-03 13:43:57 --> Config Class Initialized
INFO - 2025-05-03 13:43:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:43:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:43:57 --> Utf8 Class Initialized
INFO - 2025-05-03 13:43:57 --> URI Class Initialized
INFO - 2025-05-03 13:43:57 --> Router Class Initialized
INFO - 2025-05-03 13:43:57 --> Output Class Initialized
INFO - 2025-05-03 13:43:57 --> Security Class Initialized
DEBUG - 2025-05-03 13:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:43:57 --> Input Class Initialized
INFO - 2025-05-03 13:43:57 --> Language Class Initialized
INFO - 2025-05-03 13:43:57 --> Loader Class Initialized
INFO - 2025-05-03 13:43:57 --> Helper loaded: url_helper
INFO - 2025-05-03 13:43:57 --> Helper loaded: string_helper
INFO - 2025-05-03 13:43:57 --> Helper loaded: form_helper
INFO - 2025-05-03 13:43:57 --> Helper loaded: file_helper
INFO - 2025-05-03 13:43:57 --> Helper loaded: html_helper
INFO - 2025-05-03 13:43:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:43:57 --> Controller Class Initialized
INFO - 2025-05-03 21:43:57 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:43:57 --> Final output sent to browser
DEBUG - 2025-05-03 21:43:57 --> Total execution time: 0.3892
INFO - 2025-05-03 13:44:42 --> Config Class Initialized
INFO - 2025-05-03 13:44:42 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:44:42 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:44:42 --> Utf8 Class Initialized
INFO - 2025-05-03 13:44:42 --> URI Class Initialized
INFO - 2025-05-03 13:44:42 --> Router Class Initialized
INFO - 2025-05-03 13:44:42 --> Output Class Initialized
INFO - 2025-05-03 13:44:42 --> Security Class Initialized
DEBUG - 2025-05-03 13:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:44:42 --> Input Class Initialized
INFO - 2025-05-03 13:44:42 --> Language Class Initialized
INFO - 2025-05-03 13:44:42 --> Loader Class Initialized
INFO - 2025-05-03 13:44:42 --> Helper loaded: url_helper
INFO - 2025-05-03 13:44:42 --> Helper loaded: string_helper
INFO - 2025-05-03 13:44:42 --> Helper loaded: form_helper
INFO - 2025-05-03 13:44:42 --> Helper loaded: file_helper
INFO - 2025-05-03 13:44:42 --> Helper loaded: html_helper
INFO - 2025-05-03 13:44:42 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:44:42 --> Controller Class Initialized
INFO - 2025-05-03 21:44:42 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:44:58 --> Config Class Initialized
INFO - 2025-05-03 13:44:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:44:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:44:58 --> Utf8 Class Initialized
INFO - 2025-05-03 13:44:58 --> URI Class Initialized
INFO - 2025-05-03 13:44:58 --> Router Class Initialized
INFO - 2025-05-03 13:44:58 --> Output Class Initialized
INFO - 2025-05-03 13:44:58 --> Security Class Initialized
DEBUG - 2025-05-03 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:44:58 --> Input Class Initialized
INFO - 2025-05-03 13:44:58 --> Language Class Initialized
INFO - 2025-05-03 13:44:58 --> Loader Class Initialized
INFO - 2025-05-03 13:44:58 --> Helper loaded: url_helper
INFO - 2025-05-03 13:44:58 --> Helper loaded: string_helper
INFO - 2025-05-03 13:44:58 --> Helper loaded: form_helper
INFO - 2025-05-03 13:44:58 --> Helper loaded: file_helper
INFO - 2025-05-03 13:44:58 --> Helper loaded: html_helper
INFO - 2025-05-03 13:44:58 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:44:58 --> Controller Class Initialized
INFO - 2025-05-03 21:44:58 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:44:58 --> Final output sent to browser
DEBUG - 2025-05-03 21:44:58 --> Total execution time: 0.2698
INFO - 2025-05-03 13:45:06 --> Config Class Initialized
INFO - 2025-05-03 13:45:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:06 --> URI Class Initialized
INFO - 2025-05-03 13:45:06 --> Router Class Initialized
INFO - 2025-05-03 13:45:06 --> Output Class Initialized
INFO - 2025-05-03 13:45:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:06 --> Input Class Initialized
INFO - 2025-05-03 13:45:06 --> Language Class Initialized
INFO - 2025-05-03 13:45:06 --> Loader Class Initialized
INFO - 2025-05-03 13:45:06 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:06 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:06 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:06 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:06 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:06 --> Controller Class Initialized
INFO - 2025-05-03 21:45:06 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:45:30 --> Config Class Initialized
INFO - 2025-05-03 13:45:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:30 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:30 --> URI Class Initialized
INFO - 2025-05-03 13:45:30 --> Router Class Initialized
INFO - 2025-05-03 13:45:30 --> Output Class Initialized
INFO - 2025-05-03 13:45:30 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:30 --> Input Class Initialized
INFO - 2025-05-03 13:45:30 --> Language Class Initialized
INFO - 2025-05-03 13:45:30 --> Loader Class Initialized
INFO - 2025-05-03 13:45:30 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:30 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:30 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:30 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:30 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:30 --> Controller Class Initialized
INFO - 2025-05-03 13:45:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:45:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:45:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:45:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:45:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:45:30 --> Final output sent to browser
DEBUG - 2025-05-03 13:45:30 --> Total execution time: 0.1404
INFO - 2025-05-03 13:45:32 --> Config Class Initialized
INFO - 2025-05-03 13:45:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:32 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:32 --> URI Class Initialized
INFO - 2025-05-03 13:45:32 --> Router Class Initialized
INFO - 2025-05-03 13:45:32 --> Output Class Initialized
INFO - 2025-05-03 13:45:32 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:32 --> Input Class Initialized
INFO - 2025-05-03 13:45:32 --> Language Class Initialized
INFO - 2025-05-03 13:45:32 --> Loader Class Initialized
INFO - 2025-05-03 13:45:32 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:32 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:32 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:32 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:32 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:32 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:32 --> Controller Class Initialized
INFO - 2025-05-03 21:45:32 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:45:32 --> Final output sent to browser
DEBUG - 2025-05-03 21:45:32 --> Total execution time: 0.2559
INFO - 2025-05-03 13:45:35 --> Config Class Initialized
INFO - 2025-05-03 13:45:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:35 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:35 --> URI Class Initialized
INFO - 2025-05-03 13:45:35 --> Router Class Initialized
INFO - 2025-05-03 13:45:35 --> Output Class Initialized
INFO - 2025-05-03 13:45:35 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:35 --> Input Class Initialized
INFO - 2025-05-03 13:45:35 --> Language Class Initialized
INFO - 2025-05-03 13:45:35 --> Loader Class Initialized
INFO - 2025-05-03 13:45:35 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:35 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:35 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:35 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:35 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:35 --> Controller Class Initialized
INFO - 2025-05-03 21:45:35 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:45:38 --> Config Class Initialized
INFO - 2025-05-03 13:45:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:38 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:38 --> URI Class Initialized
INFO - 2025-05-03 13:45:38 --> Router Class Initialized
INFO - 2025-05-03 13:45:38 --> Output Class Initialized
INFO - 2025-05-03 13:45:38 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:38 --> Input Class Initialized
INFO - 2025-05-03 13:45:38 --> Language Class Initialized
INFO - 2025-05-03 13:45:38 --> Loader Class Initialized
INFO - 2025-05-03 13:45:38 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:38 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:38 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:38 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:38 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:38 --> Controller Class Initialized
INFO - 2025-05-03 21:45:38 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:45:39 --> Config Class Initialized
INFO - 2025-05-03 13:45:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:39 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:39 --> URI Class Initialized
INFO - 2025-05-03 13:45:39 --> Router Class Initialized
INFO - 2025-05-03 13:45:39 --> Output Class Initialized
INFO - 2025-05-03 13:45:39 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:39 --> Input Class Initialized
INFO - 2025-05-03 13:45:39 --> Language Class Initialized
INFO - 2025-05-03 13:45:39 --> Loader Class Initialized
INFO - 2025-05-03 13:45:39 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:39 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:39 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:39 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:39 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:39 --> Controller Class Initialized
INFO - 2025-05-03 21:45:39 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:45:42 --> Config Class Initialized
INFO - 2025-05-03 13:45:42 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:45:42 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:45:42 --> Utf8 Class Initialized
INFO - 2025-05-03 13:45:42 --> URI Class Initialized
INFO - 2025-05-03 13:45:42 --> Router Class Initialized
INFO - 2025-05-03 13:45:42 --> Output Class Initialized
INFO - 2025-05-03 13:45:42 --> Security Class Initialized
DEBUG - 2025-05-03 13:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:45:42 --> Input Class Initialized
INFO - 2025-05-03 13:45:42 --> Language Class Initialized
INFO - 2025-05-03 13:45:42 --> Loader Class Initialized
INFO - 2025-05-03 13:45:42 --> Helper loaded: url_helper
INFO - 2025-05-03 13:45:42 --> Helper loaded: string_helper
INFO - 2025-05-03 13:45:42 --> Helper loaded: form_helper
INFO - 2025-05-03 13:45:42 --> Helper loaded: file_helper
INFO - 2025-05-03 13:45:42 --> Helper loaded: html_helper
INFO - 2025-05-03 13:45:42 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:45:42 --> Controller Class Initialized
INFO - 2025-05-03 21:45:42 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:46:05 --> Config Class Initialized
INFO - 2025-05-03 13:46:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:46:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:46:05 --> Utf8 Class Initialized
INFO - 2025-05-03 13:46:05 --> URI Class Initialized
INFO - 2025-05-03 13:46:05 --> Router Class Initialized
INFO - 2025-05-03 13:46:05 --> Output Class Initialized
INFO - 2025-05-03 13:46:05 --> Security Class Initialized
DEBUG - 2025-05-03 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:46:05 --> Input Class Initialized
INFO - 2025-05-03 13:46:05 --> Language Class Initialized
INFO - 2025-05-03 13:46:05 --> Loader Class Initialized
INFO - 2025-05-03 13:46:05 --> Helper loaded: url_helper
INFO - 2025-05-03 13:46:05 --> Helper loaded: string_helper
INFO - 2025-05-03 13:46:05 --> Helper loaded: form_helper
INFO - 2025-05-03 13:46:05 --> Helper loaded: file_helper
INFO - 2025-05-03 13:46:05 --> Helper loaded: html_helper
INFO - 2025-05-03 13:46:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:46:05 --> Controller Class Initialized
INFO - 2025-05-03 13:46:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:46:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:46:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:46:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:46:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:46:05 --> Final output sent to browser
DEBUG - 2025-05-03 13:46:05 --> Total execution time: 0.1196
INFO - 2025-05-03 13:46:06 --> Config Class Initialized
INFO - 2025-05-03 13:46:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:46:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:46:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:46:06 --> URI Class Initialized
INFO - 2025-05-03 13:46:06 --> Router Class Initialized
INFO - 2025-05-03 13:46:06 --> Output Class Initialized
INFO - 2025-05-03 13:46:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:46:06 --> Input Class Initialized
INFO - 2025-05-03 13:46:06 --> Language Class Initialized
INFO - 2025-05-03 13:46:06 --> Loader Class Initialized
INFO - 2025-05-03 13:46:06 --> Helper loaded: url_helper
INFO - 2025-05-03 13:46:06 --> Helper loaded: string_helper
INFO - 2025-05-03 13:46:06 --> Helper loaded: form_helper
INFO - 2025-05-03 13:46:06 --> Helper loaded: file_helper
INFO - 2025-05-03 13:46:06 --> Helper loaded: html_helper
INFO - 2025-05-03 13:46:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:46:06 --> Controller Class Initialized
INFO - 2025-05-03 21:46:06 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:46:06 --> Final output sent to browser
DEBUG - 2025-05-03 21:46:06 --> Total execution time: 0.1858
INFO - 2025-05-03 13:46:09 --> Config Class Initialized
INFO - 2025-05-03 13:46:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:46:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:46:09 --> Utf8 Class Initialized
INFO - 2025-05-03 13:46:09 --> URI Class Initialized
INFO - 2025-05-03 13:46:09 --> Router Class Initialized
INFO - 2025-05-03 13:46:09 --> Output Class Initialized
INFO - 2025-05-03 13:46:09 --> Security Class Initialized
DEBUG - 2025-05-03 13:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:46:09 --> Input Class Initialized
INFO - 2025-05-03 13:46:09 --> Language Class Initialized
INFO - 2025-05-03 13:46:09 --> Loader Class Initialized
INFO - 2025-05-03 13:46:09 --> Helper loaded: url_helper
INFO - 2025-05-03 13:46:09 --> Helper loaded: string_helper
INFO - 2025-05-03 13:46:09 --> Helper loaded: form_helper
INFO - 2025-05-03 13:46:09 --> Helper loaded: file_helper
INFO - 2025-05-03 13:46:09 --> Helper loaded: html_helper
INFO - 2025-05-03 13:46:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:46:09 --> Controller Class Initialized
INFO - 2025-05-03 21:46:09 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:47:12 --> Config Class Initialized
INFO - 2025-05-03 13:47:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:12 --> URI Class Initialized
INFO - 2025-05-03 13:47:12 --> Router Class Initialized
INFO - 2025-05-03 13:47:12 --> Output Class Initialized
INFO - 2025-05-03 13:47:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:12 --> Input Class Initialized
INFO - 2025-05-03 13:47:12 --> Language Class Initialized
INFO - 2025-05-03 13:47:12 --> Loader Class Initialized
INFO - 2025-05-03 13:47:12 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:12 --> Controller Class Initialized
INFO - 2025-05-03 21:47:12 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:12 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:12 --> Total execution time: 0.1916
INFO - 2025-05-03 13:47:12 --> Config Class Initialized
INFO - 2025-05-03 13:47:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:12 --> URI Class Initialized
INFO - 2025-05-03 13:47:12 --> Router Class Initialized
INFO - 2025-05-03 13:47:12 --> Output Class Initialized
INFO - 2025-05-03 13:47:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:12 --> Input Class Initialized
INFO - 2025-05-03 13:47:12 --> Language Class Initialized
INFO - 2025-05-03 13:47:12 --> Loader Class Initialized
INFO - 2025-05-03 13:47:12 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:12 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:12 --> Controller Class Initialized
INFO - 2025-05-03 21:47:12 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:13 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:13 --> Total execution time: 0.2419
INFO - 2025-05-03 13:47:13 --> Config Class Initialized
INFO - 2025-05-03 13:47:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:13 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:13 --> URI Class Initialized
INFO - 2025-05-03 13:47:13 --> Router Class Initialized
INFO - 2025-05-03 13:47:13 --> Output Class Initialized
INFO - 2025-05-03 13:47:13 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:13 --> Input Class Initialized
INFO - 2025-05-03 13:47:13 --> Language Class Initialized
INFO - 2025-05-03 13:47:13 --> Loader Class Initialized
INFO - 2025-05-03 13:47:13 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:13 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:13 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:13 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:13 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:13 --> Controller Class Initialized
INFO - 2025-05-03 21:47:13 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:47:14 --> Config Class Initialized
INFO - 2025-05-03 13:47:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:14 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:14 --> URI Class Initialized
INFO - 2025-05-03 13:47:14 --> Router Class Initialized
INFO - 2025-05-03 13:47:14 --> Output Class Initialized
INFO - 2025-05-03 13:47:14 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:14 --> Input Class Initialized
INFO - 2025-05-03 13:47:14 --> Language Class Initialized
INFO - 2025-05-03 13:47:14 --> Loader Class Initialized
INFO - 2025-05-03 13:47:14 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:14 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:14 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:14 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:14 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:14 --> Controller Class Initialized
INFO - 2025-05-03 13:47:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:47:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:47:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/payment.php
INFO - 2025-05-03 13:47:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:47:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:47:14 --> Final output sent to browser
DEBUG - 2025-05-03 13:47:14 --> Total execution time: 0.1222
INFO - 2025-05-03 13:47:16 --> Config Class Initialized
INFO - 2025-05-03 13:47:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:16 --> URI Class Initialized
INFO - 2025-05-03 13:47:16 --> Router Class Initialized
INFO - 2025-05-03 13:47:16 --> Output Class Initialized
INFO - 2025-05-03 13:47:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:16 --> Input Class Initialized
INFO - 2025-05-03 13:47:16 --> Language Class Initialized
INFO - 2025-05-03 13:47:16 --> Loader Class Initialized
INFO - 2025-05-03 13:47:16 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:16 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:16 --> Helper loaded: form_helper
INFO - 2025-05-03 21:47:16 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:16 --> Total execution time: 0.2149
INFO - 2025-05-03 13:47:24 --> Config Class Initialized
INFO - 2025-05-03 13:47:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:24 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:24 --> URI Class Initialized
INFO - 2025-05-03 13:47:24 --> Router Class Initialized
INFO - 2025-05-03 13:47:24 --> Output Class Initialized
INFO - 2025-05-03 13:47:24 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:24 --> Input Class Initialized
INFO - 2025-05-03 13:47:24 --> Language Class Initialized
INFO - 2025-05-03 13:47:24 --> Loader Class Initialized
INFO - 2025-05-03 13:47:24 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:24 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:24 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:24 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:24 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:24 --> Controller Class Initialized
INFO - 2025-05-03 13:47:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:47:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:47:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/notifications.php
INFO - 2025-05-03 13:47:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:47:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:47:24 --> Final output sent to browser
DEBUG - 2025-05-03 13:47:24 --> Total execution time: 0.1226
INFO - 2025-05-03 13:47:26 --> Config Class Initialized
INFO - 2025-05-03 13:47:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:26 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:26 --> URI Class Initialized
INFO - 2025-05-03 13:47:26 --> Router Class Initialized
INFO - 2025-05-03 13:47:26 --> Output Class Initialized
INFO - 2025-05-03 13:47:26 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:26 --> Input Class Initialized
INFO - 2025-05-03 13:47:26 --> Language Class Initialized
INFO - 2025-05-03 13:47:26 --> Loader Class Initialized
INFO - 2025-05-03 13:47:26 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:26 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:26 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:26 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:26 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:26 --> Controller Class Initialized
INFO - 2025-05-03 21:47:26 --> Model "NotificationsModel" initialized
INFO - 2025-05-03 21:47:26 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:26 --> Total execution time: 0.2327
INFO - 2025-05-03 13:47:27 --> Config Class Initialized
INFO - 2025-05-03 13:47:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:27 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:27 --> URI Class Initialized
INFO - 2025-05-03 13:47:27 --> Router Class Initialized
INFO - 2025-05-03 13:47:27 --> Output Class Initialized
INFO - 2025-05-03 13:47:27 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:27 --> Input Class Initialized
INFO - 2025-05-03 13:47:27 --> Language Class Initialized
INFO - 2025-05-03 13:47:27 --> Loader Class Initialized
INFO - 2025-05-03 13:47:27 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:27 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:27 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:27 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:27 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:27 --> Controller Class Initialized
INFO - 2025-05-03 13:47:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:47:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:47:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:47:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:47:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:47:27 --> Final output sent to browser
DEBUG - 2025-05-03 13:47:27 --> Total execution time: 0.3260
INFO - 2025-05-03 13:47:28 --> Config Class Initialized
INFO - 2025-05-03 13:47:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:28 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:28 --> URI Class Initialized
INFO - 2025-05-03 13:47:28 --> Router Class Initialized
INFO - 2025-05-03 13:47:28 --> Output Class Initialized
INFO - 2025-05-03 13:47:29 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:29 --> Input Class Initialized
INFO - 2025-05-03 13:47:29 --> Language Class Initialized
INFO - 2025-05-03 13:47:29 --> Loader Class Initialized
INFO - 2025-05-03 13:47:29 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:29 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:29 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:29 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:29 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:29 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:29 --> Controller Class Initialized
INFO - 2025-05-03 21:47:29 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:29 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:29 --> Total execution time: 0.2396
INFO - 2025-05-03 13:47:30 --> Config Class Initialized
INFO - 2025-05-03 13:47:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:30 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:30 --> URI Class Initialized
INFO - 2025-05-03 13:47:30 --> Router Class Initialized
INFO - 2025-05-03 13:47:30 --> Output Class Initialized
INFO - 2025-05-03 13:47:30 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:30 --> Input Class Initialized
INFO - 2025-05-03 13:47:30 --> Language Class Initialized
INFO - 2025-05-03 13:47:30 --> Loader Class Initialized
INFO - 2025-05-03 13:47:30 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:30 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:30 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:30 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:30 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:30 --> Controller Class Initialized
INFO - 2025-05-03 21:47:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:30 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:30 --> Total execution time: 0.2934
INFO - 2025-05-03 13:47:31 --> Config Class Initialized
INFO - 2025-05-03 13:47:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:31 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:31 --> URI Class Initialized
INFO - 2025-05-03 13:47:31 --> Router Class Initialized
INFO - 2025-05-03 13:47:31 --> Output Class Initialized
INFO - 2025-05-03 13:47:31 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:31 --> Input Class Initialized
INFO - 2025-05-03 13:47:31 --> Language Class Initialized
INFO - 2025-05-03 13:47:31 --> Loader Class Initialized
INFO - 2025-05-03 13:47:31 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:31 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:31 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:31 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:31 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:31 --> Controller Class Initialized
INFO - 2025-05-03 21:47:31 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:32 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:32 --> Total execution time: 0.3016
INFO - 2025-05-03 13:47:32 --> Config Class Initialized
INFO - 2025-05-03 13:47:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:32 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:32 --> URI Class Initialized
INFO - 2025-05-03 13:47:32 --> Router Class Initialized
INFO - 2025-05-03 13:47:32 --> Output Class Initialized
INFO - 2025-05-03 13:47:32 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:32 --> Input Class Initialized
INFO - 2025-05-03 13:47:32 --> Language Class Initialized
INFO - 2025-05-03 13:47:32 --> Loader Class Initialized
INFO - 2025-05-03 13:47:32 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:32 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:32 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:32 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:32 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:32 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:32 --> Controller Class Initialized
INFO - 2025-05-03 21:47:32 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:47:32 --> Final output sent to browser
DEBUG - 2025-05-03 21:47:32 --> Total execution time: 0.2277
INFO - 2025-05-03 13:47:33 --> Config Class Initialized
INFO - 2025-05-03 13:47:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:47:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:47:33 --> Utf8 Class Initialized
INFO - 2025-05-03 13:47:33 --> URI Class Initialized
INFO - 2025-05-03 13:47:33 --> Router Class Initialized
INFO - 2025-05-03 13:47:33 --> Output Class Initialized
INFO - 2025-05-03 13:47:33 --> Security Class Initialized
DEBUG - 2025-05-03 13:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:47:33 --> Input Class Initialized
INFO - 2025-05-03 13:47:33 --> Language Class Initialized
INFO - 2025-05-03 13:47:33 --> Loader Class Initialized
INFO - 2025-05-03 13:47:33 --> Helper loaded: url_helper
INFO - 2025-05-03 13:47:33 --> Helper loaded: string_helper
INFO - 2025-05-03 13:47:33 --> Helper loaded: form_helper
INFO - 2025-05-03 13:47:33 --> Helper loaded: file_helper
INFO - 2025-05-03 13:47:33 --> Helper loaded: html_helper
INFO - 2025-05-03 13:47:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:47:33 --> Controller Class Initialized
INFO - 2025-05-03 21:47:33 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:49:37 --> Config Class Initialized
INFO - 2025-05-03 13:49:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:49:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:49:37 --> Utf8 Class Initialized
INFO - 2025-05-03 13:49:37 --> URI Class Initialized
INFO - 2025-05-03 13:49:37 --> Router Class Initialized
INFO - 2025-05-03 13:49:37 --> Output Class Initialized
INFO - 2025-05-03 13:49:37 --> Security Class Initialized
DEBUG - 2025-05-03 13:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:49:37 --> Input Class Initialized
INFO - 2025-05-03 13:49:37 --> Language Class Initialized
INFO - 2025-05-03 13:49:37 --> Loader Class Initialized
INFO - 2025-05-03 13:49:37 --> Helper loaded: url_helper
INFO - 2025-05-03 13:49:37 --> Helper loaded: string_helper
INFO - 2025-05-03 13:49:37 --> Helper loaded: form_helper
INFO - 2025-05-03 13:49:37 --> Helper loaded: file_helper
INFO - 2025-05-03 13:49:37 --> Helper loaded: html_helper
INFO - 2025-05-03 13:49:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:49:37 --> Controller Class Initialized
INFO - 2025-05-03 21:49:37 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:51:48 --> Config Class Initialized
INFO - 2025-05-03 13:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:51:48 --> Utf8 Class Initialized
INFO - 2025-05-03 13:51:48 --> URI Class Initialized
INFO - 2025-05-03 13:51:48 --> Router Class Initialized
INFO - 2025-05-03 13:51:48 --> Output Class Initialized
INFO - 2025-05-03 13:51:48 --> Security Class Initialized
DEBUG - 2025-05-03 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:51:48 --> Input Class Initialized
INFO - 2025-05-03 13:51:48 --> Language Class Initialized
INFO - 2025-05-03 13:51:48 --> Loader Class Initialized
INFO - 2025-05-03 13:51:48 --> Helper loaded: url_helper
INFO - 2025-05-03 13:51:48 --> Helper loaded: string_helper
INFO - 2025-05-03 13:51:48 --> Helper loaded: form_helper
INFO - 2025-05-03 13:51:48 --> Helper loaded: file_helper
INFO - 2025-05-03 13:51:48 --> Helper loaded: html_helper
INFO - 2025-05-03 13:51:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:51:48 --> Controller Class Initialized
INFO - 2025-05-03 21:51:48 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:51:59 --> Config Class Initialized
INFO - 2025-05-03 13:51:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:51:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:51:59 --> Utf8 Class Initialized
INFO - 2025-05-03 13:51:59 --> URI Class Initialized
INFO - 2025-05-03 13:51:59 --> Router Class Initialized
INFO - 2025-05-03 13:51:59 --> Output Class Initialized
INFO - 2025-05-03 13:51:59 --> Security Class Initialized
DEBUG - 2025-05-03 13:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:51:59 --> Input Class Initialized
INFO - 2025-05-03 13:51:59 --> Language Class Initialized
INFO - 2025-05-03 13:51:59 --> Loader Class Initialized
INFO - 2025-05-03 13:51:59 --> Helper loaded: url_helper
INFO - 2025-05-03 13:51:59 --> Helper loaded: string_helper
INFO - 2025-05-03 13:51:59 --> Helper loaded: form_helper
INFO - 2025-05-03 13:51:59 --> Helper loaded: file_helper
INFO - 2025-05-03 13:51:59 --> Helper loaded: html_helper
INFO - 2025-05-03 13:51:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:51:59 --> Controller Class Initialized
INFO - 2025-05-03 21:51:59 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:52:04 --> Config Class Initialized
INFO - 2025-05-03 13:52:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:04 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:04 --> URI Class Initialized
INFO - 2025-05-03 13:52:04 --> Router Class Initialized
INFO - 2025-05-03 13:52:04 --> Output Class Initialized
INFO - 2025-05-03 13:52:04 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:04 --> Input Class Initialized
INFO - 2025-05-03 13:52:04 --> Language Class Initialized
INFO - 2025-05-03 13:52:04 --> Loader Class Initialized
INFO - 2025-05-03 13:52:04 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:04 --> Helper loaded: string_helper
INFO - 2025-05-03 13:52:12 --> Config Class Initialized
INFO - 2025-05-03 13:52:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:12 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:12 --> URI Class Initialized
INFO - 2025-05-03 13:52:12 --> Router Class Initialized
INFO - 2025-05-03 13:52:12 --> Output Class Initialized
INFO - 2025-05-03 13:52:12 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:12 --> Input Class Initialized
INFO - 2025-05-03 13:52:12 --> Language Class Initialized
INFO - 2025-05-03 13:52:12 --> Loader Class Initialized
INFO - 2025-05-03 13:52:12 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:12 --> Helper loaded: string_helper
INFO - 2025-05-03 13:52:12 --> Helper loaded: form_helper
INFO - 2025-05-03 13:52:12 --> Helper loaded: file_helper
INFO - 2025-05-03 13:52:12 --> Helper loaded: html_helper
INFO - 2025-05-03 13:52:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:52:12 --> Controller Class Initialized
INFO - 2025-05-03 13:52:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:52:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:52:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:52:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:52:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:52:12 --> Final output sent to browser
DEBUG - 2025-05-03 13:52:12 --> Total execution time: 0.1787
INFO - 2025-05-03 13:52:14 --> Config Class Initialized
INFO - 2025-05-03 13:52:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:14 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:14 --> URI Class Initialized
INFO - 2025-05-03 13:52:14 --> Router Class Initialized
INFO - 2025-05-03 13:52:14 --> Output Class Initialized
INFO - 2025-05-03 13:52:14 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:14 --> Input Class Initialized
INFO - 2025-05-03 13:52:14 --> Language Class Initialized
INFO - 2025-05-03 13:52:14 --> Loader Class Initialized
INFO - 2025-05-03 13:52:14 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:14 --> Helper loaded: string_helper
INFO - 2025-05-03 13:52:14 --> Helper loaded: form_helper
INFO - 2025-05-03 13:52:14 --> Helper loaded: file_helper
INFO - 2025-05-03 13:52:14 --> Helper loaded: html_helper
INFO - 2025-05-03 13:52:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:52:14 --> Controller Class Initialized
INFO - 2025-05-03 21:52:14 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:52:14 --> Final output sent to browser
DEBUG - 2025-05-03 21:52:14 --> Total execution time: 0.2348
INFO - 2025-05-03 13:52:15 --> Config Class Initialized
INFO - 2025-05-03 13:52:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:15 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:15 --> URI Class Initialized
INFO - 2025-05-03 13:52:15 --> Router Class Initialized
INFO - 2025-05-03 13:52:15 --> Output Class Initialized
INFO - 2025-05-03 13:52:15 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:15 --> Input Class Initialized
INFO - 2025-05-03 13:52:15 --> Language Class Initialized
INFO - 2025-05-03 13:52:15 --> Loader Class Initialized
INFO - 2025-05-03 13:52:15 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:15 --> Helper loaded: string_helper
INFO - 2025-05-03 13:52:15 --> Helper loaded: form_helper
INFO - 2025-05-03 13:52:15 --> Helper loaded: file_helper
INFO - 2025-05-03 13:52:15 --> Helper loaded: html_helper
INFO - 2025-05-03 13:52:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:52:15 --> Controller Class Initialized
INFO - 2025-05-03 21:52:15 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:52:16 --> Final output sent to browser
DEBUG - 2025-05-03 21:52:16 --> Total execution time: 0.1704
INFO - 2025-05-03 13:52:16 --> Config Class Initialized
INFO - 2025-05-03 13:52:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:16 --> URI Class Initialized
INFO - 2025-05-03 13:52:16 --> Router Class Initialized
INFO - 2025-05-03 13:52:16 --> Output Class Initialized
INFO - 2025-05-03 13:52:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:16 --> Input Class Initialized
INFO - 2025-05-03 13:52:16 --> Language Class Initialized
INFO - 2025-05-03 13:52:16 --> Loader Class Initialized
INFO - 2025-05-03 13:52:16 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:16 --> Helper loaded: string_helper
INFO - 2025-05-03 13:52:16 --> Helper loaded: form_helper
INFO - 2025-05-03 13:52:16 --> Helper loaded: file_helper
INFO - 2025-05-03 13:52:16 --> Helper loaded: html_helper
INFO - 2025-05-03 13:52:16 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:52:16 --> Controller Class Initialized
INFO - 2025-05-03 21:52:16 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:55:19 --> Config Class Initialized
INFO - 2025-05-03 13:55:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:19 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:19 --> URI Class Initialized
INFO - 2025-05-03 13:55:19 --> Router Class Initialized
INFO - 2025-05-03 13:55:19 --> Output Class Initialized
INFO - 2025-05-03 13:55:19 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:19 --> Input Class Initialized
INFO - 2025-05-03 13:55:19 --> Language Class Initialized
INFO - 2025-05-03 13:55:19 --> Loader Class Initialized
INFO - 2025-05-03 13:55:19 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:19 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:19 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:19 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:19 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:19 --> Controller Class Initialized
INFO - 2025-05-03 13:55:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:55:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:55:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:55:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:55:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:55:19 --> Final output sent to browser
DEBUG - 2025-05-03 13:55:19 --> Total execution time: 0.4234
INFO - 2025-05-03 13:55:23 --> Config Class Initialized
INFO - 2025-05-03 13:55:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:23 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:23 --> URI Class Initialized
INFO - 2025-05-03 13:55:23 --> Router Class Initialized
INFO - 2025-05-03 13:55:23 --> Output Class Initialized
INFO - 2025-05-03 13:55:23 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:23 --> Input Class Initialized
INFO - 2025-05-03 13:55:23 --> Language Class Initialized
INFO - 2025-05-03 13:55:24 --> Loader Class Initialized
INFO - 2025-05-03 13:55:24 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:24 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:24 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:24 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:24 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:24 --> Controller Class Initialized
INFO - 2025-05-03 21:55:24 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:55:24 --> Final output sent to browser
DEBUG - 2025-05-03 21:55:24 --> Total execution time: 0.7659
INFO - 2025-05-03 13:55:29 --> Config Class Initialized
INFO - 2025-05-03 13:55:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:29 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:29 --> URI Class Initialized
INFO - 2025-05-03 13:55:29 --> Router Class Initialized
INFO - 2025-05-03 13:55:29 --> Output Class Initialized
INFO - 2025-05-03 13:55:29 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:29 --> Input Class Initialized
INFO - 2025-05-03 13:55:29 --> Language Class Initialized
INFO - 2025-05-03 13:55:29 --> Loader Class Initialized
INFO - 2025-05-03 13:55:29 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:29 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:29 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:29 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:29 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:29 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:29 --> Controller Class Initialized
INFO - 2025-05-03 21:55:29 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:55:34 --> Config Class Initialized
INFO - 2025-05-03 13:55:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:34 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:34 --> URI Class Initialized
INFO - 2025-05-03 13:55:34 --> Router Class Initialized
INFO - 2025-05-03 13:55:34 --> Output Class Initialized
INFO - 2025-05-03 13:55:34 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:34 --> Input Class Initialized
INFO - 2025-05-03 13:55:34 --> Language Class Initialized
INFO - 2025-05-03 13:55:34 --> Loader Class Initialized
INFO - 2025-05-03 13:55:34 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:34 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:34 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:34 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:34 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:34 --> Controller Class Initialized
INFO - 2025-05-03 21:55:34 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:55:37 --> Config Class Initialized
INFO - 2025-05-03 13:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:37 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:37 --> URI Class Initialized
INFO - 2025-05-03 13:55:37 --> Router Class Initialized
INFO - 2025-05-03 13:55:37 --> Output Class Initialized
INFO - 2025-05-03 13:55:37 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:37 --> Input Class Initialized
INFO - 2025-05-03 13:55:37 --> Language Class Initialized
INFO - 2025-05-03 13:55:37 --> Loader Class Initialized
INFO - 2025-05-03 13:55:37 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:37 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:37 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:37 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:37 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:37 --> Controller Class Initialized
INFO - 2025-05-03 21:55:37 --> Model "AuctionModel" initialized
INFO - 2025-05-03 21:55:38 --> Final output sent to browser
DEBUG - 2025-05-03 21:55:38 --> Total execution time: 0.2273
INFO - 2025-05-03 13:55:38 --> Config Class Initialized
INFO - 2025-05-03 13:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:55:38 --> Utf8 Class Initialized
INFO - 2025-05-03 13:55:38 --> URI Class Initialized
INFO - 2025-05-03 13:55:38 --> Router Class Initialized
INFO - 2025-05-03 13:55:38 --> Output Class Initialized
INFO - 2025-05-03 13:55:38 --> Security Class Initialized
DEBUG - 2025-05-03 13:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:55:38 --> Input Class Initialized
INFO - 2025-05-03 13:55:38 --> Language Class Initialized
INFO - 2025-05-03 13:55:38 --> Loader Class Initialized
INFO - 2025-05-03 13:55:38 --> Helper loaded: url_helper
INFO - 2025-05-03 13:55:38 --> Helper loaded: string_helper
INFO - 2025-05-03 13:55:39 --> Helper loaded: form_helper
INFO - 2025-05-03 13:55:39 --> Helper loaded: file_helper
INFO - 2025-05-03 13:55:39 --> Helper loaded: html_helper
INFO - 2025-05-03 13:55:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:55:39 --> Controller Class Initialized
INFO - 2025-05-03 21:55:39 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:57:44 --> Config Class Initialized
INFO - 2025-05-03 13:57:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:57:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:57:44 --> Utf8 Class Initialized
INFO - 2025-05-03 13:57:44 --> URI Class Initialized
INFO - 2025-05-03 13:57:44 --> Router Class Initialized
INFO - 2025-05-03 13:57:44 --> Output Class Initialized
INFO - 2025-05-03 13:57:44 --> Security Class Initialized
DEBUG - 2025-05-03 13:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:57:44 --> Input Class Initialized
INFO - 2025-05-03 13:57:44 --> Language Class Initialized
INFO - 2025-05-03 13:57:44 --> Loader Class Initialized
INFO - 2025-05-03 13:57:44 --> Helper loaded: url_helper
INFO - 2025-05-03 13:57:44 --> Helper loaded: string_helper
INFO - 2025-05-03 13:57:44 --> Helper loaded: form_helper
INFO - 2025-05-03 13:57:44 --> Helper loaded: file_helper
INFO - 2025-05-03 13:57:44 --> Helper loaded: html_helper
INFO - 2025-05-03 13:57:44 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:57:44 --> Controller Class Initialized
INFO - 2025-05-03 13:57:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 13:57:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 13:57:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 13:57:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 13:57:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 13:57:44 --> Final output sent to browser
DEBUG - 2025-05-03 13:57:44 --> Total execution time: 0.1862
INFO - 2025-05-03 13:57:46 --> Config Class Initialized
INFO - 2025-05-03 13:57:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:57:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:57:46 --> Utf8 Class Initialized
INFO - 2025-05-03 13:57:46 --> URI Class Initialized
INFO - 2025-05-03 13:57:46 --> Router Class Initialized
INFO - 2025-05-03 13:57:47 --> Output Class Initialized
INFO - 2025-05-03 13:57:47 --> Security Class Initialized
DEBUG - 2025-05-03 13:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:57:47 --> Input Class Initialized
INFO - 2025-05-03 13:57:47 --> Language Class Initialized
INFO - 2025-05-03 13:57:47 --> Loader Class Initialized
INFO - 2025-05-03 13:57:47 --> Helper loaded: url_helper
INFO - 2025-05-03 13:57:47 --> Helper loaded: string_helper
INFO - 2025-05-03 13:57:47 --> Helper loaded: form_helper
INFO - 2025-05-03 13:57:47 --> Helper loaded: file_helper
INFO - 2025-05-03 13:57:47 --> Helper loaded: html_helper
INFO - 2025-05-03 13:57:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:57:47 --> Controller Class Initialized
INFO - 2025-05-03 21:57:47 --> Model "AuctionModel" initialized
INFO - 2025-05-03 13:57:48 --> Config Class Initialized
INFO - 2025-05-03 13:57:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:57:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:57:48 --> Utf8 Class Initialized
INFO - 2025-05-03 13:57:48 --> URI Class Initialized
INFO - 2025-05-03 13:57:48 --> Router Class Initialized
INFO - 2025-05-03 13:57:48 --> Output Class Initialized
INFO - 2025-05-03 13:57:48 --> Security Class Initialized
DEBUG - 2025-05-03 13:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:57:48 --> Input Class Initialized
INFO - 2025-05-03 13:57:48 --> Language Class Initialized
INFO - 2025-05-03 13:57:48 --> Loader Class Initialized
INFO - 2025-05-03 13:57:48 --> Helper loaded: url_helper
INFO - 2025-05-03 13:57:48 --> Helper loaded: string_helper
INFO - 2025-05-03 13:57:48 --> Helper loaded: form_helper
INFO - 2025-05-03 13:57:48 --> Helper loaded: file_helper
INFO - 2025-05-03 13:57:48 --> Helper loaded: html_helper
INFO - 2025-05-03 13:57:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:57:48 --> Controller Class Initialized
INFO - 2025-05-03 21:57:48 --> Model "CompanyModel" initialized
INFO - 2025-05-03 13:57:53 --> Config Class Initialized
INFO - 2025-05-03 13:57:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:57:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:57:53 --> Utf8 Class Initialized
INFO - 2025-05-03 13:57:53 --> URI Class Initialized
INFO - 2025-05-03 13:57:53 --> Router Class Initialized
INFO - 2025-05-03 13:57:53 --> Output Class Initialized
INFO - 2025-05-03 13:57:53 --> Security Class Initialized
DEBUG - 2025-05-03 13:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:57:53 --> Input Class Initialized
INFO - 2025-05-03 13:57:53 --> Language Class Initialized
INFO - 2025-05-03 13:57:53 --> Loader Class Initialized
INFO - 2025-05-03 13:57:53 --> Helper loaded: url_helper
INFO - 2025-05-03 13:57:53 --> Helper loaded: string_helper
INFO - 2025-05-03 13:57:53 --> Helper loaded: form_helper
INFO - 2025-05-03 13:57:53 --> Helper loaded: file_helper
INFO - 2025-05-03 13:57:53 --> Helper loaded: html_helper
INFO - 2025-05-03 13:57:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 13:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 13:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:57:53 --> Controller Class Initialized
INFO - 2025-05-03 21:57:53 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:00:14 --> Config Class Initialized
INFO - 2025-05-03 14:00:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:00:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:00:14 --> Utf8 Class Initialized
INFO - 2025-05-03 14:00:14 --> URI Class Initialized
INFO - 2025-05-03 14:00:14 --> Router Class Initialized
INFO - 2025-05-03 14:00:14 --> Output Class Initialized
INFO - 2025-05-03 14:00:14 --> Security Class Initialized
DEBUG - 2025-05-03 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:00:14 --> Input Class Initialized
INFO - 2025-05-03 14:00:14 --> Language Class Initialized
INFO - 2025-05-03 14:00:14 --> Loader Class Initialized
INFO - 2025-05-03 14:00:14 --> Helper loaded: url_helper
INFO - 2025-05-03 14:00:14 --> Helper loaded: string_helper
INFO - 2025-05-03 14:00:14 --> Helper loaded: form_helper
INFO - 2025-05-03 14:00:14 --> Helper loaded: file_helper
INFO - 2025-05-03 14:00:14 --> Helper loaded: html_helper
INFO - 2025-05-03 14:00:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:00:14 --> Controller Class Initialized
INFO - 2025-05-03 14:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:00:15 --> Final output sent to browser
DEBUG - 2025-05-03 14:00:15 --> Total execution time: 0.2343
INFO - 2025-05-03 14:00:22 --> Config Class Initialized
INFO - 2025-05-03 14:00:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:00:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:00:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:00:22 --> URI Class Initialized
INFO - 2025-05-03 14:00:22 --> Router Class Initialized
INFO - 2025-05-03 14:00:22 --> Output Class Initialized
INFO - 2025-05-03 14:00:22 --> Security Class Initialized
DEBUG - 2025-05-03 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:00:22 --> Input Class Initialized
INFO - 2025-05-03 14:00:22 --> Language Class Initialized
INFO - 2025-05-03 14:00:22 --> Loader Class Initialized
INFO - 2025-05-03 14:00:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:00:22 --> Helper loaded: string_helper
INFO - 2025-05-03 14:00:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:00:22 --> Helper loaded: file_helper
INFO - 2025-05-03 14:00:22 --> Helper loaded: html_helper
INFO - 2025-05-03 14:00:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:00:22 --> Controller Class Initialized
INFO - 2025-05-03 22:00:22 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:00:22 --> Final output sent to browser
DEBUG - 2025-05-03 22:00:22 --> Total execution time: 0.6962
INFO - 2025-05-03 14:00:23 --> Config Class Initialized
INFO - 2025-05-03 14:00:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:00:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:00:23 --> Utf8 Class Initialized
INFO - 2025-05-03 14:00:23 --> URI Class Initialized
INFO - 2025-05-03 14:00:23 --> Router Class Initialized
INFO - 2025-05-03 14:00:23 --> Output Class Initialized
INFO - 2025-05-03 14:00:23 --> Security Class Initialized
DEBUG - 2025-05-03 14:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:00:23 --> Input Class Initialized
INFO - 2025-05-03 14:00:23 --> Language Class Initialized
INFO - 2025-05-03 14:00:23 --> Loader Class Initialized
INFO - 2025-05-03 14:00:23 --> Helper loaded: url_helper
INFO - 2025-05-03 14:00:23 --> Helper loaded: string_helper
INFO - 2025-05-03 14:00:23 --> Helper loaded: form_helper
INFO - 2025-05-03 14:00:23 --> Helper loaded: file_helper
INFO - 2025-05-03 14:00:23 --> Helper loaded: html_helper
INFO - 2025-05-03 14:00:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:00:24 --> Controller Class Initialized
INFO - 2025-05-03 22:00:24 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:00:26 --> Config Class Initialized
INFO - 2025-05-03 14:00:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:00:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:00:26 --> Utf8 Class Initialized
INFO - 2025-05-03 14:00:26 --> URI Class Initialized
INFO - 2025-05-03 14:00:26 --> Router Class Initialized
INFO - 2025-05-03 14:00:26 --> Output Class Initialized
INFO - 2025-05-03 14:00:26 --> Security Class Initialized
DEBUG - 2025-05-03 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:00:26 --> Input Class Initialized
INFO - 2025-05-03 14:00:26 --> Language Class Initialized
INFO - 2025-05-03 14:00:26 --> Loader Class Initialized
INFO - 2025-05-03 14:00:26 --> Helper loaded: url_helper
INFO - 2025-05-03 14:00:26 --> Helper loaded: string_helper
INFO - 2025-05-03 14:00:26 --> Helper loaded: form_helper
INFO - 2025-05-03 14:00:26 --> Helper loaded: file_helper
INFO - 2025-05-03 14:00:26 --> Helper loaded: html_helper
INFO - 2025-05-03 14:00:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:00:26 --> Controller Class Initialized
INFO - 2025-05-03 22:00:26 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:01:11 --> Config Class Initialized
INFO - 2025-05-03 14:01:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:11 --> URI Class Initialized
INFO - 2025-05-03 14:01:11 --> Router Class Initialized
INFO - 2025-05-03 14:01:11 --> Output Class Initialized
INFO - 2025-05-03 14:01:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:11 --> Input Class Initialized
INFO - 2025-05-03 14:01:11 --> Language Class Initialized
INFO - 2025-05-03 14:01:11 --> Loader Class Initialized
INFO - 2025-05-03 14:01:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:11 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:11 --> Controller Class Initialized
INFO - 2025-05-03 14:01:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:01:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:01:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:01:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:01:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:01:11 --> Final output sent to browser
DEBUG - 2025-05-03 14:01:11 --> Total execution time: 0.2433
INFO - 2025-05-03 14:01:19 --> Config Class Initialized
INFO - 2025-05-03 14:01:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:19 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:19 --> URI Class Initialized
INFO - 2025-05-03 14:01:19 --> Router Class Initialized
INFO - 2025-05-03 14:01:19 --> Output Class Initialized
INFO - 2025-05-03 14:01:19 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:19 --> Input Class Initialized
INFO - 2025-05-03 14:01:19 --> Language Class Initialized
INFO - 2025-05-03 14:01:19 --> Loader Class Initialized
INFO - 2025-05-03 14:01:20 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:20 --> Controller Class Initialized
INFO - 2025-05-03 22:01:20 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:01:20 --> Final output sent to browser
DEBUG - 2025-05-03 22:01:20 --> Total execution time: 0.5339
INFO - 2025-05-03 14:01:20 --> Config Class Initialized
INFO - 2025-05-03 14:01:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:20 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:20 --> URI Class Initialized
INFO - 2025-05-03 14:01:20 --> Router Class Initialized
INFO - 2025-05-03 14:01:20 --> Output Class Initialized
INFO - 2025-05-03 14:01:20 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:20 --> Input Class Initialized
INFO - 2025-05-03 14:01:20 --> Language Class Initialized
INFO - 2025-05-03 14:01:20 --> Loader Class Initialized
INFO - 2025-05-03 14:01:20 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:20 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:20 --> Controller Class Initialized
INFO - 2025-05-03 22:01:20 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:01:35 --> Config Class Initialized
INFO - 2025-05-03 14:01:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:35 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:35 --> URI Class Initialized
INFO - 2025-05-03 14:01:35 --> Router Class Initialized
INFO - 2025-05-03 14:01:35 --> Output Class Initialized
INFO - 2025-05-03 14:01:35 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:35 --> Input Class Initialized
INFO - 2025-05-03 14:01:35 --> Language Class Initialized
INFO - 2025-05-03 14:01:36 --> Loader Class Initialized
INFO - 2025-05-03 14:01:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:36 --> Controller Class Initialized
INFO - 2025-05-03 22:01:36 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:01:38 --> Config Class Initialized
INFO - 2025-05-03 14:01:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:38 --> URI Class Initialized
INFO - 2025-05-03 14:01:38 --> Router Class Initialized
INFO - 2025-05-03 14:01:38 --> Output Class Initialized
INFO - 2025-05-03 14:01:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:38 --> Input Class Initialized
INFO - 2025-05-03 14:01:38 --> Language Class Initialized
INFO - 2025-05-03 14:01:38 --> Loader Class Initialized
INFO - 2025-05-03 14:01:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:38 --> Controller Class Initialized
INFO - 2025-05-03 22:01:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:01:39 --> Final output sent to browser
DEBUG - 2025-05-03 22:01:39 --> Total execution time: 0.2259
INFO - 2025-05-03 14:01:39 --> Config Class Initialized
INFO - 2025-05-03 14:01:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:39 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:39 --> URI Class Initialized
INFO - 2025-05-03 14:01:39 --> Router Class Initialized
INFO - 2025-05-03 14:01:39 --> Output Class Initialized
INFO - 2025-05-03 14:01:39 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:39 --> Input Class Initialized
INFO - 2025-05-03 14:01:39 --> Language Class Initialized
INFO - 2025-05-03 14:01:39 --> Loader Class Initialized
INFO - 2025-05-03 14:01:39 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:39 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:39 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:39 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:39 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:40 --> Controller Class Initialized
INFO - 2025-05-03 22:01:40 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:01:42 --> Config Class Initialized
INFO - 2025-05-03 14:01:42 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:42 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:42 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:42 --> URI Class Initialized
INFO - 2025-05-03 14:01:42 --> Router Class Initialized
INFO - 2025-05-03 14:01:42 --> Output Class Initialized
INFO - 2025-05-03 14:01:42 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:42 --> Input Class Initialized
INFO - 2025-05-03 14:01:42 --> Language Class Initialized
INFO - 2025-05-03 14:01:42 --> Loader Class Initialized
INFO - 2025-05-03 14:01:42 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:42 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:42 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:42 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:42 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:42 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:42 --> Controller Class Initialized
INFO - 2025-05-03 22:01:42 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:01:42 --> Final output sent to browser
DEBUG - 2025-05-03 22:01:42 --> Total execution time: 0.2677
INFO - 2025-05-03 14:01:43 --> Config Class Initialized
INFO - 2025-05-03 14:01:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:01:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:01:43 --> Utf8 Class Initialized
INFO - 2025-05-03 14:01:43 --> URI Class Initialized
INFO - 2025-05-03 14:01:43 --> Router Class Initialized
INFO - 2025-05-03 14:01:43 --> Output Class Initialized
INFO - 2025-05-03 14:01:43 --> Security Class Initialized
DEBUG - 2025-05-03 14:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:01:43 --> Input Class Initialized
INFO - 2025-05-03 14:01:43 --> Language Class Initialized
INFO - 2025-05-03 14:01:43 --> Loader Class Initialized
INFO - 2025-05-03 14:01:43 --> Helper loaded: url_helper
INFO - 2025-05-03 14:01:43 --> Helper loaded: string_helper
INFO - 2025-05-03 14:01:43 --> Helper loaded: form_helper
INFO - 2025-05-03 14:01:43 --> Helper loaded: file_helper
INFO - 2025-05-03 14:01:43 --> Helper loaded: html_helper
INFO - 2025-05-03 14:01:43 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:01:43 --> Controller Class Initialized
INFO - 2025-05-03 22:01:43 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:03:35 --> Config Class Initialized
INFO - 2025-05-03 14:03:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:35 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:35 --> URI Class Initialized
INFO - 2025-05-03 14:03:35 --> Router Class Initialized
INFO - 2025-05-03 14:03:35 --> Output Class Initialized
INFO - 2025-05-03 14:03:35 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:35 --> Input Class Initialized
INFO - 2025-05-03 14:03:35 --> Language Class Initialized
INFO - 2025-05-03 14:03:35 --> Loader Class Initialized
INFO - 2025-05-03 14:03:35 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:35 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:35 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:35 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:35 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:35 --> Controller Class Initialized
INFO - 2025-05-03 14:03:36 --> Config Class Initialized
INFO - 2025-05-03 14:03:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:36 --> URI Class Initialized
INFO - 2025-05-03 14:03:36 --> Router Class Initialized
INFO - 2025-05-03 14:03:36 --> Output Class Initialized
INFO - 2025-05-03 14:03:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:36 --> Input Class Initialized
INFO - 2025-05-03 14:03:36 --> Language Class Initialized
INFO - 2025-05-03 14:03:36 --> Loader Class Initialized
INFO - 2025-05-03 14:03:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:36 --> Controller Class Initialized
INFO - 2025-05-03 14:03:36 --> Config Class Initialized
INFO - 2025-05-03 14:03:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:36 --> URI Class Initialized
DEBUG - 2025-05-03 14:03:36 --> No URI present. Default controller set.
INFO - 2025-05-03 14:03:36 --> Router Class Initialized
INFO - 2025-05-03 14:03:36 --> Output Class Initialized
INFO - 2025-05-03 14:03:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:36 --> Input Class Initialized
INFO - 2025-05-03 14:03:36 --> Language Class Initialized
INFO - 2025-05-03 14:03:36 --> Loader Class Initialized
INFO - 2025-05-03 14:03:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:36 --> Controller Class Initialized
INFO - 2025-05-03 14:03:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:03:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:03:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 14:03:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:03:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:03:36 --> Final output sent to browser
DEBUG - 2025-05-03 14:03:36 --> Total execution time: 0.1127
INFO - 2025-05-03 14:03:38 --> Config Class Initialized
INFO - 2025-05-03 14:03:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:38 --> URI Class Initialized
INFO - 2025-05-03 14:03:38 --> Router Class Initialized
INFO - 2025-05-03 14:03:38 --> Output Class Initialized
INFO - 2025-05-03 14:03:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:38 --> Input Class Initialized
INFO - 2025-05-03 14:03:38 --> Language Class Initialized
INFO - 2025-05-03 14:03:38 --> Loader Class Initialized
INFO - 2025-05-03 14:03:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:38 --> Controller Class Initialized
INFO - 2025-05-03 22:03:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:03:47 --> Config Class Initialized
INFO - 2025-05-03 14:03:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:47 --> URI Class Initialized
INFO - 2025-05-03 14:03:47 --> Router Class Initialized
INFO - 2025-05-03 14:03:47 --> Output Class Initialized
INFO - 2025-05-03 14:03:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:47 --> Input Class Initialized
INFO - 2025-05-03 14:03:47 --> Language Class Initialized
INFO - 2025-05-03 14:03:47 --> Loader Class Initialized
INFO - 2025-05-03 14:03:47 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:47 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:47 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:47 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:47 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:47 --> Controller Class Initialized
INFO - 2025-05-03 22:03:47 --> Model "UserModel" initialized
INFO - 2025-05-03 14:03:53 --> Config Class Initialized
INFO - 2025-05-03 14:03:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:53 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:53 --> URI Class Initialized
INFO - 2025-05-03 14:03:53 --> Router Class Initialized
INFO - 2025-05-03 14:03:53 --> Output Class Initialized
INFO - 2025-05-03 14:03:53 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:53 --> Input Class Initialized
INFO - 2025-05-03 14:03:53 --> Language Class Initialized
INFO - 2025-05-03 14:03:53 --> Loader Class Initialized
INFO - 2025-05-03 14:03:53 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:53 --> Controller Class Initialized
INFO - 2025-05-03 22:03:53 --> Model "UserModel" initialized
INFO - 2025-05-03 14:03:53 --> Config Class Initialized
INFO - 2025-05-03 14:03:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:53 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:53 --> URI Class Initialized
DEBUG - 2025-05-03 14:03:53 --> No URI present. Default controller set.
INFO - 2025-05-03 14:03:53 --> Router Class Initialized
INFO - 2025-05-03 14:03:53 --> Output Class Initialized
INFO - 2025-05-03 14:03:53 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:53 --> Input Class Initialized
INFO - 2025-05-03 14:03:53 --> Language Class Initialized
INFO - 2025-05-03 14:03:53 --> Loader Class Initialized
INFO - 2025-05-03 14:03:53 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:53 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:54 --> Controller Class Initialized
INFO - 2025-05-03 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:03:54 --> Final output sent to browser
DEBUG - 2025-05-03 14:03:54 --> Total execution time: 0.1347
INFO - 2025-05-03 14:03:55 --> Config Class Initialized
INFO - 2025-05-03 14:03:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:55 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:55 --> URI Class Initialized
INFO - 2025-05-03 14:03:55 --> Router Class Initialized
INFO - 2025-05-03 14:03:55 --> Output Class Initialized
INFO - 2025-05-03 14:03:55 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:55 --> Input Class Initialized
INFO - 2025-05-03 14:03:55 --> Language Class Initialized
INFO - 2025-05-03 14:03:55 --> Loader Class Initialized
INFO - 2025-05-03 14:03:55 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:55 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:55 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:55 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:55 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:55 --> Controller Class Initialized
INFO - 2025-05-03 22:03:55 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:03:56 --> Config Class Initialized
INFO - 2025-05-03 14:03:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:56 --> URI Class Initialized
INFO - 2025-05-03 14:03:56 --> Router Class Initialized
INFO - 2025-05-03 14:03:56 --> Output Class Initialized
INFO - 2025-05-03 14:03:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:56 --> Input Class Initialized
INFO - 2025-05-03 14:03:56 --> Language Class Initialized
INFO - 2025-05-03 14:03:56 --> Loader Class Initialized
INFO - 2025-05-03 14:03:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:56 --> Controller Class Initialized
INFO - 2025-05-03 14:03:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:03:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:03:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:03:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:03:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:03:56 --> Final output sent to browser
DEBUG - 2025-05-03 14:03:56 --> Total execution time: 0.2201
INFO - 2025-05-03 14:03:58 --> Config Class Initialized
INFO - 2025-05-03 14:03:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:58 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:58 --> URI Class Initialized
INFO - 2025-05-03 14:03:58 --> Router Class Initialized
INFO - 2025-05-03 14:03:58 --> Output Class Initialized
INFO - 2025-05-03 14:03:58 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:58 --> Input Class Initialized
INFO - 2025-05-03 14:03:58 --> Language Class Initialized
INFO - 2025-05-03 14:03:58 --> Loader Class Initialized
INFO - 2025-05-03 14:03:58 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:58 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:58 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:58 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:58 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:58 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:58 --> Controller Class Initialized
INFO - 2025-05-03 22:03:58 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:03:58 --> Final output sent to browser
DEBUG - 2025-05-03 22:03:58 --> Total execution time: 0.2280
INFO - 2025-05-03 14:03:58 --> Config Class Initialized
INFO - 2025-05-03 14:03:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:03:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:03:58 --> Utf8 Class Initialized
INFO - 2025-05-03 14:03:58 --> URI Class Initialized
INFO - 2025-05-03 14:03:59 --> Router Class Initialized
INFO - 2025-05-03 14:03:59 --> Output Class Initialized
INFO - 2025-05-03 14:03:59 --> Security Class Initialized
DEBUG - 2025-05-03 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:03:59 --> Input Class Initialized
INFO - 2025-05-03 14:03:59 --> Language Class Initialized
INFO - 2025-05-03 14:03:59 --> Loader Class Initialized
INFO - 2025-05-03 14:03:59 --> Helper loaded: url_helper
INFO - 2025-05-03 14:03:59 --> Helper loaded: string_helper
INFO - 2025-05-03 14:03:59 --> Helper loaded: form_helper
INFO - 2025-05-03 14:03:59 --> Helper loaded: file_helper
INFO - 2025-05-03 14:03:59 --> Helper loaded: html_helper
INFO - 2025-05-03 14:03:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:03:59 --> Controller Class Initialized
INFO - 2025-05-03 22:03:59 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:03:59 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:03:59 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:04:07 --> Config Class Initialized
INFO - 2025-05-03 14:04:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:04:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:04:07 --> Utf8 Class Initialized
INFO - 2025-05-03 14:04:07 --> URI Class Initialized
INFO - 2025-05-03 14:04:07 --> Router Class Initialized
INFO - 2025-05-03 14:04:07 --> Output Class Initialized
INFO - 2025-05-03 14:04:07 --> Security Class Initialized
DEBUG - 2025-05-03 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:04:07 --> Input Class Initialized
INFO - 2025-05-03 14:04:07 --> Language Class Initialized
INFO - 2025-05-03 14:04:07 --> Loader Class Initialized
INFO - 2025-05-03 14:04:07 --> Helper loaded: url_helper
INFO - 2025-05-03 14:04:07 --> Helper loaded: string_helper
INFO - 2025-05-03 14:04:07 --> Helper loaded: form_helper
INFO - 2025-05-03 14:04:07 --> Helper loaded: file_helper
INFO - 2025-05-03 14:04:07 --> Helper loaded: html_helper
INFO - 2025-05-03 14:04:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:04:07 --> Controller Class Initialized
INFO - 2025-05-03 22:04:07 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:04:07 --> Final output sent to browser
DEBUG - 2025-05-03 22:04:07 --> Total execution time: 0.3936
INFO - 2025-05-03 14:04:09 --> Config Class Initialized
INFO - 2025-05-03 14:04:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:04:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:04:09 --> Utf8 Class Initialized
INFO - 2025-05-03 14:04:09 --> URI Class Initialized
INFO - 2025-05-03 14:04:09 --> Router Class Initialized
INFO - 2025-05-03 14:04:09 --> Output Class Initialized
INFO - 2025-05-03 14:04:09 --> Security Class Initialized
DEBUG - 2025-05-03 14:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:04:09 --> Input Class Initialized
INFO - 2025-05-03 14:04:09 --> Language Class Initialized
INFO - 2025-05-03 14:04:09 --> Loader Class Initialized
INFO - 2025-05-03 14:04:09 --> Helper loaded: url_helper
INFO - 2025-05-03 14:04:09 --> Helper loaded: string_helper
INFO - 2025-05-03 14:04:09 --> Helper loaded: form_helper
INFO - 2025-05-03 14:04:09 --> Helper loaded: file_helper
INFO - 2025-05-03 14:04:09 --> Helper loaded: html_helper
INFO - 2025-05-03 14:04:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:04:09 --> Controller Class Initialized
INFO - 2025-05-03 22:04:09 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:04:09 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:04:09 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:10:34 --> Config Class Initialized
INFO - 2025-05-03 14:10:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:10:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:10:34 --> Utf8 Class Initialized
INFO - 2025-05-03 14:10:34 --> URI Class Initialized
INFO - 2025-05-03 14:10:34 --> Router Class Initialized
INFO - 2025-05-03 14:10:34 --> Output Class Initialized
INFO - 2025-05-03 14:10:34 --> Security Class Initialized
DEBUG - 2025-05-03 14:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:10:34 --> Input Class Initialized
INFO - 2025-05-03 14:10:34 --> Language Class Initialized
INFO - 2025-05-03 14:10:34 --> Loader Class Initialized
INFO - 2025-05-03 14:10:34 --> Helper loaded: url_helper
INFO - 2025-05-03 14:10:34 --> Helper loaded: string_helper
INFO - 2025-05-03 14:10:34 --> Helper loaded: form_helper
INFO - 2025-05-03 14:10:34 --> Helper loaded: file_helper
INFO - 2025-05-03 14:10:34 --> Helper loaded: html_helper
INFO - 2025-05-03 14:10:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:10:34 --> Controller Class Initialized
INFO - 2025-05-03 22:10:34 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:10:34 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:10:34 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:10:40 --> Config Class Initialized
INFO - 2025-05-03 14:10:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:10:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:10:40 --> Utf8 Class Initialized
INFO - 2025-05-03 14:10:40 --> URI Class Initialized
INFO - 2025-05-03 14:10:40 --> Router Class Initialized
INFO - 2025-05-03 14:10:40 --> Output Class Initialized
INFO - 2025-05-03 14:10:40 --> Security Class Initialized
DEBUG - 2025-05-03 14:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:10:40 --> Input Class Initialized
INFO - 2025-05-03 14:10:40 --> Language Class Initialized
INFO - 2025-05-03 14:10:40 --> Loader Class Initialized
INFO - 2025-05-03 14:10:40 --> Helper loaded: url_helper
INFO - 2025-05-03 14:10:40 --> Helper loaded: string_helper
INFO - 2025-05-03 14:10:40 --> Helper loaded: form_helper
INFO - 2025-05-03 14:10:40 --> Helper loaded: file_helper
INFO - 2025-05-03 14:10:40 --> Helper loaded: html_helper
INFO - 2025-05-03 14:10:40 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:10:40 --> Controller Class Initialized
INFO - 2025-05-03 22:10:40 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:10:41 --> Final output sent to browser
DEBUG - 2025-05-03 22:10:41 --> Total execution time: 0.1074
INFO - 2025-05-03 14:10:41 --> Config Class Initialized
INFO - 2025-05-03 14:10:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:10:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:10:41 --> Utf8 Class Initialized
INFO - 2025-05-03 14:10:41 --> URI Class Initialized
INFO - 2025-05-03 14:10:41 --> Router Class Initialized
INFO - 2025-05-03 14:10:41 --> Output Class Initialized
INFO - 2025-05-03 14:10:41 --> Security Class Initialized
DEBUG - 2025-05-03 14:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:10:41 --> Input Class Initialized
INFO - 2025-05-03 14:10:41 --> Language Class Initialized
INFO - 2025-05-03 14:10:41 --> Loader Class Initialized
INFO - 2025-05-03 14:10:41 --> Helper loaded: url_helper
INFO - 2025-05-03 14:10:41 --> Helper loaded: string_helper
INFO - 2025-05-03 14:10:41 --> Helper loaded: form_helper
INFO - 2025-05-03 14:10:41 --> Helper loaded: file_helper
INFO - 2025-05-03 14:10:41 --> Helper loaded: html_helper
INFO - 2025-05-03 14:10:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:10:41 --> Controller Class Initialized
INFO - 2025-05-03 22:10:42 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:10:42 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:10:42 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:10:51 --> Config Class Initialized
INFO - 2025-05-03 14:10:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:10:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:10:51 --> Utf8 Class Initialized
INFO - 2025-05-03 14:10:51 --> URI Class Initialized
INFO - 2025-05-03 14:10:51 --> Router Class Initialized
INFO - 2025-05-03 14:10:51 --> Output Class Initialized
INFO - 2025-05-03 14:10:51 --> Security Class Initialized
DEBUG - 2025-05-03 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:10:51 --> Input Class Initialized
INFO - 2025-05-03 14:10:51 --> Language Class Initialized
INFO - 2025-05-03 14:10:51 --> Loader Class Initialized
INFO - 2025-05-03 14:10:51 --> Helper loaded: url_helper
INFO - 2025-05-03 14:10:51 --> Helper loaded: string_helper
INFO - 2025-05-03 14:10:51 --> Helper loaded: form_helper
INFO - 2025-05-03 14:10:51 --> Helper loaded: file_helper
INFO - 2025-05-03 14:10:51 --> Helper loaded: html_helper
INFO - 2025-05-03 14:10:51 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:10:51 --> Controller Class Initialized
INFO - 2025-05-03 22:10:51 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:10:51 --> Final output sent to browser
DEBUG - 2025-05-03 22:10:51 --> Total execution time: 0.1243
INFO - 2025-05-03 14:12:14 --> Config Class Initialized
INFO - 2025-05-03 14:12:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:12:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:12:14 --> Utf8 Class Initialized
INFO - 2025-05-03 14:12:14 --> URI Class Initialized
INFO - 2025-05-03 14:12:14 --> Router Class Initialized
INFO - 2025-05-03 14:12:14 --> Output Class Initialized
INFO - 2025-05-03 14:12:14 --> Security Class Initialized
DEBUG - 2025-05-03 14:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:12:14 --> Input Class Initialized
INFO - 2025-05-03 14:12:14 --> Language Class Initialized
INFO - 2025-05-03 14:12:14 --> Loader Class Initialized
INFO - 2025-05-03 14:12:14 --> Helper loaded: url_helper
INFO - 2025-05-03 14:12:14 --> Helper loaded: string_helper
INFO - 2025-05-03 14:12:14 --> Helper loaded: form_helper
INFO - 2025-05-03 14:12:14 --> Helper loaded: file_helper
INFO - 2025-05-03 14:12:14 --> Helper loaded: html_helper
INFO - 2025-05-03 14:12:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:12:15 --> Controller Class Initialized
INFO - 2025-05-03 22:12:15 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:12:15 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:12:15 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:12:37 --> Config Class Initialized
INFO - 2025-05-03 14:12:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:12:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:12:37 --> Utf8 Class Initialized
INFO - 2025-05-03 14:12:37 --> URI Class Initialized
INFO - 2025-05-03 14:12:37 --> Router Class Initialized
INFO - 2025-05-03 14:12:37 --> Output Class Initialized
INFO - 2025-05-03 14:12:37 --> Security Class Initialized
DEBUG - 2025-05-03 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:12:37 --> Input Class Initialized
INFO - 2025-05-03 14:12:37 --> Language Class Initialized
INFO - 2025-05-03 14:12:37 --> Loader Class Initialized
INFO - 2025-05-03 14:12:37 --> Helper loaded: url_helper
INFO - 2025-05-03 14:12:37 --> Helper loaded: string_helper
INFO - 2025-05-03 14:12:37 --> Helper loaded: form_helper
INFO - 2025-05-03 14:12:37 --> Helper loaded: file_helper
INFO - 2025-05-03 14:12:37 --> Helper loaded: html_helper
INFO - 2025-05-03 14:12:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:12:37 --> Controller Class Initialized
INFO - 2025-05-03 22:12:37 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:12:37 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:12:37 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:12:47 --> Config Class Initialized
INFO - 2025-05-03 14:12:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:12:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:12:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:12:47 --> URI Class Initialized
INFO - 2025-05-03 14:12:47 --> Router Class Initialized
INFO - 2025-05-03 14:12:47 --> Output Class Initialized
INFO - 2025-05-03 14:12:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:12:47 --> Input Class Initialized
INFO - 2025-05-03 14:12:47 --> Language Class Initialized
INFO - 2025-05-03 14:12:47 --> Loader Class Initialized
INFO - 2025-05-03 14:12:47 --> Helper loaded: url_helper
INFO - 2025-05-03 14:12:47 --> Helper loaded: string_helper
INFO - 2025-05-03 14:12:47 --> Helper loaded: form_helper
INFO - 2025-05-03 14:12:47 --> Helper loaded: file_helper
INFO - 2025-05-03 14:12:47 --> Helper loaded: html_helper
INFO - 2025-05-03 14:12:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:12:47 --> Controller Class Initialized
INFO - 2025-05-03 22:12:47 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:12:47 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:12:47 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:12:56 --> Config Class Initialized
INFO - 2025-05-03 14:12:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:12:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:12:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:12:56 --> URI Class Initialized
INFO - 2025-05-03 14:12:56 --> Router Class Initialized
INFO - 2025-05-03 14:12:56 --> Output Class Initialized
INFO - 2025-05-03 14:12:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:12:56 --> Input Class Initialized
INFO - 2025-05-03 14:12:56 --> Language Class Initialized
INFO - 2025-05-03 14:12:56 --> Loader Class Initialized
INFO - 2025-05-03 14:12:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:12:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:12:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:12:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:12:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:12:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:12:56 --> Controller Class Initialized
INFO - 2025-05-03 22:12:56 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:12:56 --> Final output sent to browser
DEBUG - 2025-05-03 22:12:56 --> Total execution time: 0.1840
INFO - 2025-05-03 14:12:57 --> Config Class Initialized
INFO - 2025-05-03 14:12:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:12:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:12:57 --> Utf8 Class Initialized
INFO - 2025-05-03 14:12:57 --> URI Class Initialized
INFO - 2025-05-03 14:12:57 --> Router Class Initialized
INFO - 2025-05-03 14:12:57 --> Output Class Initialized
INFO - 2025-05-03 14:12:57 --> Security Class Initialized
DEBUG - 2025-05-03 14:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:12:57 --> Input Class Initialized
INFO - 2025-05-03 14:12:57 --> Language Class Initialized
INFO - 2025-05-03 14:12:57 --> Loader Class Initialized
INFO - 2025-05-03 14:12:57 --> Helper loaded: url_helper
INFO - 2025-05-03 14:12:57 --> Helper loaded: string_helper
INFO - 2025-05-03 14:12:57 --> Helper loaded: form_helper
INFO - 2025-05-03 14:12:57 --> Helper loaded: file_helper
INFO - 2025-05-03 14:12:57 --> Helper loaded: html_helper
INFO - 2025-05-03 14:12:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:12:57 --> Controller Class Initialized
INFO - 2025-05-03 22:12:57 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:12:57 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:12:57 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:13:11 --> Config Class Initialized
INFO - 2025-05-03 14:13:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:13:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:13:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:13:11 --> URI Class Initialized
INFO - 2025-05-03 14:13:11 --> Router Class Initialized
INFO - 2025-05-03 14:13:11 --> Output Class Initialized
INFO - 2025-05-03 14:13:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:13:11 --> Input Class Initialized
INFO - 2025-05-03 14:13:11 --> Language Class Initialized
INFO - 2025-05-03 14:13:11 --> Loader Class Initialized
INFO - 2025-05-03 14:13:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:13:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:13:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:13:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:13:12 --> Helper loaded: html_helper
INFO - 2025-05-03 14:13:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:13:12 --> Controller Class Initialized
INFO - 2025-05-03 14:13:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:13:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:13:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:13:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:13:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:13:12 --> Final output sent to browser
DEBUG - 2025-05-03 14:13:12 --> Total execution time: 0.1704
INFO - 2025-05-03 14:13:14 --> Config Class Initialized
INFO - 2025-05-03 14:13:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:13:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:13:14 --> Utf8 Class Initialized
INFO - 2025-05-03 14:13:14 --> URI Class Initialized
INFO - 2025-05-03 14:13:14 --> Router Class Initialized
INFO - 2025-05-03 14:13:14 --> Output Class Initialized
INFO - 2025-05-03 14:13:14 --> Security Class Initialized
DEBUG - 2025-05-03 14:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:13:14 --> Input Class Initialized
INFO - 2025-05-03 14:13:14 --> Language Class Initialized
INFO - 2025-05-03 14:13:14 --> Loader Class Initialized
INFO - 2025-05-03 14:13:14 --> Helper loaded: url_helper
INFO - 2025-05-03 14:13:14 --> Helper loaded: string_helper
INFO - 2025-05-03 14:13:14 --> Helper loaded: form_helper
INFO - 2025-05-03 14:13:14 --> Helper loaded: file_helper
INFO - 2025-05-03 14:13:14 --> Helper loaded: html_helper
INFO - 2025-05-03 14:13:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:13:14 --> Controller Class Initialized
INFO - 2025-05-03 22:13:14 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:13:14 --> Final output sent to browser
DEBUG - 2025-05-03 22:13:14 --> Total execution time: 0.1607
INFO - 2025-05-03 14:13:16 --> Config Class Initialized
INFO - 2025-05-03 14:13:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:13:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:13:16 --> Utf8 Class Initialized
INFO - 2025-05-03 14:13:16 --> URI Class Initialized
INFO - 2025-05-03 14:13:16 --> Router Class Initialized
INFO - 2025-05-03 14:13:16 --> Output Class Initialized
INFO - 2025-05-03 14:13:16 --> Security Class Initialized
DEBUG - 2025-05-03 14:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:13:16 --> Input Class Initialized
INFO - 2025-05-03 14:13:16 --> Language Class Initialized
INFO - 2025-05-03 14:13:16 --> Loader Class Initialized
INFO - 2025-05-03 14:13:16 --> Helper loaded: url_helper
INFO - 2025-05-03 14:13:16 --> Helper loaded: string_helper
INFO - 2025-05-03 14:13:16 --> Helper loaded: form_helper
INFO - 2025-05-03 14:13:16 --> Helper loaded: file_helper
INFO - 2025-05-03 14:13:16 --> Helper loaded: html_helper
INFO - 2025-05-03 14:13:16 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:13:16 --> Controller Class Initialized
INFO - 2025-05-03 22:13:16 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:13:16 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:13:16 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:13:45 --> Config Class Initialized
INFO - 2025-05-03 14:13:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:13:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:13:45 --> Utf8 Class Initialized
INFO - 2025-05-03 14:13:45 --> URI Class Initialized
INFO - 2025-05-03 14:13:45 --> Router Class Initialized
INFO - 2025-05-03 14:13:45 --> Output Class Initialized
INFO - 2025-05-03 14:13:45 --> Security Class Initialized
DEBUG - 2025-05-03 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:13:45 --> Input Class Initialized
INFO - 2025-05-03 14:13:45 --> Language Class Initialized
INFO - 2025-05-03 14:13:45 --> Loader Class Initialized
INFO - 2025-05-03 14:13:45 --> Helper loaded: url_helper
INFO - 2025-05-03 14:13:45 --> Helper loaded: string_helper
INFO - 2025-05-03 14:13:45 --> Helper loaded: form_helper
INFO - 2025-05-03 14:13:45 --> Helper loaded: file_helper
INFO - 2025-05-03 14:13:45 --> Helper loaded: html_helper
INFO - 2025-05-03 14:13:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:13:45 --> Controller Class Initialized
INFO - 2025-05-03 22:13:45 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:13:45 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:13:45 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:13:49 --> Config Class Initialized
INFO - 2025-05-03 14:13:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:13:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:13:49 --> Utf8 Class Initialized
INFO - 2025-05-03 14:13:49 --> URI Class Initialized
INFO - 2025-05-03 14:13:49 --> Router Class Initialized
INFO - 2025-05-03 14:13:49 --> Output Class Initialized
INFO - 2025-05-03 14:13:49 --> Security Class Initialized
DEBUG - 2025-05-03 14:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:13:49 --> Input Class Initialized
INFO - 2025-05-03 14:13:49 --> Language Class Initialized
INFO - 2025-05-03 14:13:49 --> Loader Class Initialized
INFO - 2025-05-03 14:13:49 --> Helper loaded: url_helper
INFO - 2025-05-03 14:13:49 --> Helper loaded: string_helper
INFO - 2025-05-03 14:13:49 --> Helper loaded: form_helper
INFO - 2025-05-03 14:13:49 --> Helper loaded: file_helper
INFO - 2025-05-03 14:13:49 --> Helper loaded: html_helper
INFO - 2025-05-03 14:13:49 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:13:49 --> Controller Class Initialized
INFO - 2025-05-03 22:13:49 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:13:49 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:13:49 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:14:38 --> Config Class Initialized
INFO - 2025-05-03 14:14:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:14:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:14:39 --> Utf8 Class Initialized
INFO - 2025-05-03 14:14:39 --> URI Class Initialized
INFO - 2025-05-03 14:14:39 --> Router Class Initialized
INFO - 2025-05-03 14:14:39 --> Output Class Initialized
INFO - 2025-05-03 14:14:39 --> Security Class Initialized
DEBUG - 2025-05-03 14:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:14:39 --> Input Class Initialized
INFO - 2025-05-03 14:14:39 --> Language Class Initialized
INFO - 2025-05-03 14:14:39 --> Loader Class Initialized
INFO - 2025-05-03 14:14:39 --> Helper loaded: url_helper
INFO - 2025-05-03 14:14:39 --> Helper loaded: string_helper
INFO - 2025-05-03 14:14:39 --> Helper loaded: form_helper
INFO - 2025-05-03 14:14:39 --> Helper loaded: file_helper
INFO - 2025-05-03 14:14:39 --> Helper loaded: html_helper
INFO - 2025-05-03 14:14:39 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:14:39 --> Controller Class Initialized
INFO - 2025-05-03 22:14:39 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:14:39 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:14:39 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:15:09 --> Config Class Initialized
INFO - 2025-05-03 14:15:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:15:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:15:09 --> Utf8 Class Initialized
INFO - 2025-05-03 14:15:09 --> URI Class Initialized
INFO - 2025-05-03 14:15:09 --> Router Class Initialized
INFO - 2025-05-03 14:15:10 --> Output Class Initialized
INFO - 2025-05-03 14:15:10 --> Security Class Initialized
DEBUG - 2025-05-03 14:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:15:10 --> Input Class Initialized
INFO - 2025-05-03 14:15:10 --> Language Class Initialized
INFO - 2025-05-03 14:15:10 --> Loader Class Initialized
INFO - 2025-05-03 14:15:10 --> Helper loaded: url_helper
INFO - 2025-05-03 14:15:10 --> Helper loaded: string_helper
INFO - 2025-05-03 14:15:10 --> Helper loaded: form_helper
INFO - 2025-05-03 14:15:10 --> Helper loaded: file_helper
INFO - 2025-05-03 14:15:10 --> Helper loaded: html_helper
INFO - 2025-05-03 14:15:10 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:15:10 --> Controller Class Initialized
INFO - 2025-05-03 22:15:10 --> Model "InvoiceModel" initialized
ERROR - 2025-05-03 22:15:10 --> Severity: Warning --> Undefined variable $auctionIds C:\xampp\htdocs\storage_auctions\application\controllers\Invoices.php 170
ERROR - 2025-05-03 22:15:10 --> Severity: Warning --> Undefined variable $auctionIds C:\xampp\htdocs\storage_auctions\application\controllers\Invoices.php 171
ERROR - 2025-05-03 22:15:10 --> Severity: Warning --> Undefined variable $auctionIds C:\xampp\htdocs\storage_auctions\application\controllers\Invoices.php 172
INFO - 2025-05-03 22:15:10 --> Final output sent to browser
DEBUG - 2025-05-03 22:15:10 --> Total execution time: 0.4322
INFO - 2025-05-03 14:19:44 --> Config Class Initialized
INFO - 2025-05-03 14:19:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:19:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:19:45 --> Utf8 Class Initialized
INFO - 2025-05-03 14:19:45 --> URI Class Initialized
INFO - 2025-05-03 14:19:45 --> Router Class Initialized
INFO - 2025-05-03 14:19:45 --> Output Class Initialized
INFO - 2025-05-03 14:19:45 --> Security Class Initialized
DEBUG - 2025-05-03 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:19:45 --> Input Class Initialized
INFO - 2025-05-03 14:19:45 --> Language Class Initialized
INFO - 2025-05-03 14:19:45 --> Loader Class Initialized
INFO - 2025-05-03 14:19:45 --> Helper loaded: url_helper
INFO - 2025-05-03 14:19:45 --> Helper loaded: string_helper
INFO - 2025-05-03 14:19:45 --> Helper loaded: form_helper
INFO - 2025-05-03 14:19:45 --> Helper loaded: file_helper
INFO - 2025-05-03 14:19:45 --> Helper loaded: html_helper
INFO - 2025-05-03 14:19:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:19:45 --> Controller Class Initialized
ERROR - 2025-05-03 22:19:45 --> Severity: Warning --> Undefined property: Invoices::$AuctionModel C:\xampp\htdocs\storage_auctions\application\controllers\Invoices.php 148
ERROR - 2025-05-03 22:19:45 --> Severity: error --> Exception: Call to a member function getAuctionIdsByUserId() on null C:\xampp\htdocs\storage_auctions\application\controllers\Invoices.php 148
INFO - 2025-05-03 14:20:21 --> Config Class Initialized
INFO - 2025-05-03 14:20:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:21 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:21 --> URI Class Initialized
INFO - 2025-05-03 14:20:21 --> Router Class Initialized
INFO - 2025-05-03 14:20:21 --> Output Class Initialized
INFO - 2025-05-03 14:20:21 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:21 --> Input Class Initialized
INFO - 2025-05-03 14:20:21 --> Language Class Initialized
INFO - 2025-05-03 14:20:21 --> Loader Class Initialized
INFO - 2025-05-03 14:20:21 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:21 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:21 --> Helper loaded: form_helper
INFO - 2025-05-03 14:20:21 --> Helper loaded: file_helper
INFO - 2025-05-03 14:20:21 --> Helper loaded: html_helper
INFO - 2025-05-03 14:20:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:20:21 --> Controller Class Initialized
INFO - 2025-05-03 22:20:21 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:20:21 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:20:21 --> Final output sent to browser
DEBUG - 2025-05-03 22:20:21 --> Total execution time: 0.3509
INFO - 2025-05-03 14:20:28 --> Config Class Initialized
INFO - 2025-05-03 14:20:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:28 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:28 --> URI Class Initialized
INFO - 2025-05-03 14:20:28 --> Router Class Initialized
INFO - 2025-05-03 14:20:28 --> Output Class Initialized
INFO - 2025-05-03 14:20:28 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:28 --> Input Class Initialized
INFO - 2025-05-03 14:20:28 --> Language Class Initialized
INFO - 2025-05-03 14:20:28 --> Loader Class Initialized
INFO - 2025-05-03 14:20:28 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:28 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:28 --> Helper loaded: form_helper
INFO - 2025-05-03 14:20:28 --> Helper loaded: file_helper
INFO - 2025-05-03 14:20:28 --> Helper loaded: html_helper
INFO - 2025-05-03 14:20:28 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:20:28 --> Controller Class Initialized
INFO - 2025-05-03 22:20:28 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:20:28 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:20:29 --> Final output sent to browser
DEBUG - 2025-05-03 22:20:29 --> Total execution time: 0.2427
INFO - 2025-05-03 14:20:30 --> Config Class Initialized
INFO - 2025-05-03 14:20:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:30 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:30 --> URI Class Initialized
INFO - 2025-05-03 14:20:30 --> Router Class Initialized
INFO - 2025-05-03 14:20:30 --> Output Class Initialized
INFO - 2025-05-03 14:20:30 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:30 --> Input Class Initialized
INFO - 2025-05-03 14:20:30 --> Language Class Initialized
INFO - 2025-05-03 14:20:30 --> Loader Class Initialized
INFO - 2025-05-03 14:20:30 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:30 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:30 --> Helper loaded: form_helper
INFO - 2025-05-03 14:20:30 --> Helper loaded: file_helper
INFO - 2025-05-03 14:20:30 --> Helper loaded: html_helper
INFO - 2025-05-03 14:20:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:20:30 --> Controller Class Initialized
INFO - 2025-05-03 22:20:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:20:30 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:20:30 --> Final output sent to browser
DEBUG - 2025-05-03 22:20:30 --> Total execution time: 0.1727
INFO - 2025-05-03 14:20:56 --> Config Class Initialized
INFO - 2025-05-03 14:20:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:56 --> URI Class Initialized
INFO - 2025-05-03 14:20:56 --> Router Class Initialized
INFO - 2025-05-03 14:20:56 --> Output Class Initialized
INFO - 2025-05-03 14:20:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:56 --> Input Class Initialized
INFO - 2025-05-03 14:20:56 --> Language Class Initialized
INFO - 2025-05-03 14:20:56 --> Loader Class Initialized
INFO - 2025-05-03 14:20:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:20:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:20:56 --> Controller Class Initialized
INFO - 2025-05-03 14:20:56 --> Config Class Initialized
INFO - 2025-05-03 14:20:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:56 --> URI Class Initialized
DEBUG - 2025-05-03 14:20:56 --> No URI present. Default controller set.
INFO - 2025-05-03 14:20:56 --> Router Class Initialized
INFO - 2025-05-03 14:20:56 --> Output Class Initialized
INFO - 2025-05-03 14:20:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:56 --> Input Class Initialized
INFO - 2025-05-03 14:20:56 --> Language Class Initialized
INFO - 2025-05-03 14:20:56 --> Loader Class Initialized
INFO - 2025-05-03 14:20:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:20:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:20:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:20:56 --> Controller Class Initialized
INFO - 2025-05-03 14:20:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:20:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:20:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 14:20:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:20:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:20:56 --> Final output sent to browser
DEBUG - 2025-05-03 14:20:56 --> Total execution time: 0.1295
INFO - 2025-05-03 14:20:59 --> Config Class Initialized
INFO - 2025-05-03 14:20:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:20:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:20:59 --> Utf8 Class Initialized
INFO - 2025-05-03 14:20:59 --> URI Class Initialized
INFO - 2025-05-03 14:20:59 --> Router Class Initialized
INFO - 2025-05-03 14:20:59 --> Output Class Initialized
INFO - 2025-05-03 14:20:59 --> Security Class Initialized
DEBUG - 2025-05-03 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:20:59 --> Input Class Initialized
INFO - 2025-05-03 14:20:59 --> Language Class Initialized
INFO - 2025-05-03 14:20:59 --> Loader Class Initialized
INFO - 2025-05-03 14:20:59 --> Helper loaded: url_helper
INFO - 2025-05-03 14:20:59 --> Helper loaded: string_helper
INFO - 2025-05-03 14:20:59 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:09 --> Config Class Initialized
INFO - 2025-05-03 14:21:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:09 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:09 --> URI Class Initialized
INFO - 2025-05-03 14:21:09 --> Router Class Initialized
INFO - 2025-05-03 14:21:09 --> Output Class Initialized
INFO - 2025-05-03 14:21:09 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:09 --> Input Class Initialized
INFO - 2025-05-03 14:21:09 --> Language Class Initialized
INFO - 2025-05-03 14:21:09 --> Loader Class Initialized
INFO - 2025-05-03 14:21:09 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:09 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:09 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:09 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:09 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:09 --> Controller Class Initialized
INFO - 2025-05-03 22:21:09 --> Model "UserModel" initialized
INFO - 2025-05-03 14:21:10 --> Config Class Initialized
INFO - 2025-05-03 14:21:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:10 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:10 --> URI Class Initialized
DEBUG - 2025-05-03 14:21:10 --> No URI present. Default controller set.
INFO - 2025-05-03 14:21:10 --> Router Class Initialized
INFO - 2025-05-03 14:21:10 --> Output Class Initialized
INFO - 2025-05-03 14:21:10 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:10 --> Input Class Initialized
INFO - 2025-05-03 14:21:10 --> Language Class Initialized
INFO - 2025-05-03 14:21:10 --> Loader Class Initialized
INFO - 2025-05-03 14:21:10 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:10 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:10 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:10 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:10 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:10 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:10 --> Controller Class Initialized
INFO - 2025-05-03 14:21:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:21:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:21:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 14:21:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:21:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:21:10 --> Final output sent to browser
DEBUG - 2025-05-03 14:21:10 --> Total execution time: 0.1825
INFO - 2025-05-03 14:21:11 --> Config Class Initialized
INFO - 2025-05-03 14:21:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:11 --> URI Class Initialized
INFO - 2025-05-03 14:21:11 --> Router Class Initialized
INFO - 2025-05-03 14:21:11 --> Output Class Initialized
INFO - 2025-05-03 14:21:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:11 --> Input Class Initialized
INFO - 2025-05-03 14:21:11 --> Language Class Initialized
INFO - 2025-05-03 14:21:11 --> Loader Class Initialized
INFO - 2025-05-03 14:21:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:11 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:11 --> Controller Class Initialized
INFO - 2025-05-03 22:21:11 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:21:15 --> Config Class Initialized
INFO - 2025-05-03 14:21:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:15 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:15 --> URI Class Initialized
INFO - 2025-05-03 14:21:15 --> Router Class Initialized
INFO - 2025-05-03 14:21:15 --> Output Class Initialized
INFO - 2025-05-03 14:21:15 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:15 --> Input Class Initialized
INFO - 2025-05-03 14:21:15 --> Language Class Initialized
INFO - 2025-05-03 14:21:15 --> Loader Class Initialized
INFO - 2025-05-03 14:21:15 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:15 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:15 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:15 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:15 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:15 --> Controller Class Initialized
INFO - 2025-05-03 14:21:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:21:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:21:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:21:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:21:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:21:15 --> Final output sent to browser
DEBUG - 2025-05-03 14:21:15 --> Total execution time: 0.5773
INFO - 2025-05-03 14:21:16 --> Config Class Initialized
INFO - 2025-05-03 14:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:16 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:16 --> Config Class Initialized
INFO - 2025-05-03 14:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:16 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:16 --> URI Class Initialized
INFO - 2025-05-03 14:21:16 --> URI Class Initialized
INFO - 2025-05-03 14:21:16 --> Router Class Initialized
INFO - 2025-05-03 14:21:16 --> Output Class Initialized
INFO - 2025-05-03 14:21:16 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:16 --> Input Class Initialized
INFO - 2025-05-03 14:21:16 --> Language Class Initialized
INFO - 2025-05-03 14:21:16 --> Loader Class Initialized
INFO - 2025-05-03 14:21:16 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:16 --> Router Class Initialized
INFO - 2025-05-03 14:21:16 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:16 --> Output Class Initialized
INFO - 2025-05-03 14:21:16 --> Security Class Initialized
INFO - 2025-05-03 14:21:16 --> Helper loaded: form_helper
DEBUG - 2025-05-03 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:16 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:16 --> Input Class Initialized
INFO - 2025-05-03 14:21:16 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:16 --> Language Class Initialized
INFO - 2025-05-03 14:21:16 --> Database Driver Class Initialized
INFO - 2025-05-03 14:21:16 --> Loader Class Initialized
INFO - 2025-05-03 14:21:16 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:16 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:16 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:16 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:16 --> Helper loaded: html_helper
DEBUG - 2025-05-03 14:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:16 --> Controller Class Initialized
INFO - 2025-05-03 22:21:16 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:21:16 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:21:16 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:16 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:16 --> Total execution time: 0.5260
INFO - 2025-05-03 14:21:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:17 --> Controller Class Initialized
INFO - 2025-05-03 22:21:17 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:17 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:17 --> Total execution time: 0.9162
INFO - 2025-05-03 14:21:17 --> Config Class Initialized
INFO - 2025-05-03 14:21:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:17 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:17 --> URI Class Initialized
INFO - 2025-05-03 14:21:17 --> Router Class Initialized
INFO - 2025-05-03 14:21:17 --> Output Class Initialized
INFO - 2025-05-03 14:21:17 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:17 --> Input Class Initialized
INFO - 2025-05-03 14:21:17 --> Language Class Initialized
INFO - 2025-05-03 14:21:17 --> Loader Class Initialized
INFO - 2025-05-03 14:21:17 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:17 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:17 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:17 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:17 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:17 --> Controller Class Initialized
INFO - 2025-05-03 14:21:17 --> Model "UserModel" initialized
INFO - 2025-05-03 14:21:17 --> Final output sent to browser
DEBUG - 2025-05-03 14:21:17 --> Total execution time: 0.3049
INFO - 2025-05-03 14:21:19 --> Config Class Initialized
INFO - 2025-05-03 14:21:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:19 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:19 --> URI Class Initialized
INFO - 2025-05-03 14:21:19 --> Router Class Initialized
INFO - 2025-05-03 14:21:19 --> Output Class Initialized
INFO - 2025-05-03 14:21:19 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:19 --> Input Class Initialized
INFO - 2025-05-03 14:21:19 --> Language Class Initialized
INFO - 2025-05-03 14:21:19 --> Loader Class Initialized
INFO - 2025-05-03 14:21:19 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:19 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:19 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:19 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:19 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:19 --> Controller Class Initialized
INFO - 2025-05-03 22:21:19 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:21:19 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:21:19 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:19 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:21:19 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:19 --> Total execution time: 0.2381
INFO - 2025-05-03 14:21:45 --> Config Class Initialized
INFO - 2025-05-03 14:21:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:45 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:45 --> URI Class Initialized
INFO - 2025-05-03 14:21:45 --> Router Class Initialized
INFO - 2025-05-03 14:21:45 --> Output Class Initialized
INFO - 2025-05-03 14:21:45 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:45 --> Input Class Initialized
INFO - 2025-05-03 14:21:45 --> Language Class Initialized
INFO - 2025-05-03 14:21:45 --> Loader Class Initialized
INFO - 2025-05-03 14:21:45 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:45 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:45 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:45 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:45 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:45 --> Controller Class Initialized
INFO - 2025-05-03 22:21:45 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:45 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:21:45 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:45 --> Total execution time: 0.2887
INFO - 2025-05-03 14:21:50 --> Config Class Initialized
INFO - 2025-05-03 14:21:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:50 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:50 --> URI Class Initialized
INFO - 2025-05-03 14:21:50 --> Router Class Initialized
INFO - 2025-05-03 14:21:50 --> Output Class Initialized
INFO - 2025-05-03 14:21:50 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:50 --> Input Class Initialized
INFO - 2025-05-03 14:21:50 --> Language Class Initialized
INFO - 2025-05-03 14:21:50 --> Loader Class Initialized
INFO - 2025-05-03 14:21:50 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:50 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:50 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:50 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:50 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:50 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:50 --> Controller Class Initialized
INFO - 2025-05-03 22:21:50 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:21:50 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:21:50 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:50 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:21:50 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:50 --> Total execution time: 0.1715
INFO - 2025-05-03 14:21:52 --> Config Class Initialized
INFO - 2025-05-03 14:21:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:52 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:52 --> URI Class Initialized
INFO - 2025-05-03 14:21:52 --> Router Class Initialized
INFO - 2025-05-03 14:21:52 --> Output Class Initialized
INFO - 2025-05-03 14:21:52 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:52 --> Input Class Initialized
INFO - 2025-05-03 14:21:52 --> Language Class Initialized
INFO - 2025-05-03 14:21:52 --> Loader Class Initialized
INFO - 2025-05-03 14:21:52 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:52 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:52 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:52 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:52 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:52 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:52 --> Controller Class Initialized
INFO - 2025-05-03 22:21:52 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:21:52 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:21:52 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:52 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:21:52 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:52 --> Total execution time: 0.1417
INFO - 2025-05-03 14:21:56 --> Config Class Initialized
INFO - 2025-05-03 14:21:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:56 --> URI Class Initialized
INFO - 2025-05-03 14:21:56 --> Router Class Initialized
INFO - 2025-05-03 14:21:56 --> Output Class Initialized
INFO - 2025-05-03 14:21:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:56 --> Input Class Initialized
INFO - 2025-05-03 14:21:56 --> Language Class Initialized
INFO - 2025-05-03 14:21:56 --> Loader Class Initialized
INFO - 2025-05-03 14:21:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:21:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:21:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:21:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:56 --> Controller Class Initialized
INFO - 2025-05-03 22:21:56 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:21:56 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:21:56 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:21:56 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:21:57 --> Final output sent to browser
DEBUG - 2025-05-03 22:21:57 --> Total execution time: 0.1634
INFO - 2025-05-03 14:24:11 --> Config Class Initialized
INFO - 2025-05-03 14:24:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:24:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:24:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:24:11 --> URI Class Initialized
INFO - 2025-05-03 14:24:11 --> Router Class Initialized
INFO - 2025-05-03 14:24:11 --> Output Class Initialized
INFO - 2025-05-03 14:24:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:24:11 --> Input Class Initialized
INFO - 2025-05-03 14:24:11 --> Language Class Initialized
INFO - 2025-05-03 14:24:11 --> Loader Class Initialized
INFO - 2025-05-03 14:24:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:24:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:24:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:24:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:24:11 --> Helper loaded: html_helper
INFO - 2025-05-03 14:24:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:24:11 --> Controller Class Initialized
INFO - 2025-05-03 22:24:11 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:24:11 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:24:12 --> Final output sent to browser
DEBUG - 2025-05-03 22:24:12 --> Total execution time: 0.4295
INFO - 2025-05-03 14:25:03 --> Config Class Initialized
INFO - 2025-05-03 14:25:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:25:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:25:03 --> Utf8 Class Initialized
INFO - 2025-05-03 14:25:03 --> URI Class Initialized
INFO - 2025-05-03 14:25:03 --> Router Class Initialized
INFO - 2025-05-03 14:25:03 --> Output Class Initialized
INFO - 2025-05-03 14:25:03 --> Security Class Initialized
DEBUG - 2025-05-03 14:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:25:03 --> Input Class Initialized
INFO - 2025-05-03 14:25:03 --> Language Class Initialized
INFO - 2025-05-03 14:25:03 --> Loader Class Initialized
INFO - 2025-05-03 14:25:03 --> Helper loaded: url_helper
INFO - 2025-05-03 14:25:03 --> Helper loaded: string_helper
INFO - 2025-05-03 14:25:03 --> Helper loaded: form_helper
INFO - 2025-05-03 14:25:03 --> Helper loaded: file_helper
INFO - 2025-05-03 14:25:03 --> Helper loaded: html_helper
INFO - 2025-05-03 14:25:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:25:03 --> Controller Class Initialized
INFO - 2025-05-03 22:25:03 --> Model "LogsModel" initialized
INFO - 2025-05-03 22:25:03 --> Final output sent to browser
DEBUG - 2025-05-03 22:25:03 --> Total execution time: 0.5026
INFO - 2025-05-03 14:25:05 --> Config Class Initialized
INFO - 2025-05-03 14:25:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:25:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:25:05 --> Utf8 Class Initialized
INFO - 2025-05-03 14:25:05 --> URI Class Initialized
INFO - 2025-05-03 14:25:05 --> Router Class Initialized
INFO - 2025-05-03 14:25:05 --> Output Class Initialized
INFO - 2025-05-03 14:25:05 --> Security Class Initialized
DEBUG - 2025-05-03 14:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:25:05 --> Input Class Initialized
INFO - 2025-05-03 14:25:05 --> Language Class Initialized
INFO - 2025-05-03 14:25:05 --> Loader Class Initialized
INFO - 2025-05-03 14:25:05 --> Helper loaded: url_helper
INFO - 2025-05-03 14:25:05 --> Helper loaded: string_helper
INFO - 2025-05-03 14:25:05 --> Helper loaded: form_helper
INFO - 2025-05-03 14:25:05 --> Helper loaded: file_helper
INFO - 2025-05-03 14:25:05 --> Helper loaded: html_helper
INFO - 2025-05-03 14:25:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:25:05 --> Controller Class Initialized
INFO - 2025-05-03 22:25:05 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:25:05 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:25:05 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:25:05 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:25:05 --> Final output sent to browser
DEBUG - 2025-05-03 22:25:05 --> Total execution time: 0.1580
INFO - 2025-05-03 14:25:06 --> Config Class Initialized
INFO - 2025-05-03 14:25:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:25:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:25:06 --> Utf8 Class Initialized
INFO - 2025-05-03 14:25:06 --> URI Class Initialized
INFO - 2025-05-03 14:25:06 --> Router Class Initialized
INFO - 2025-05-03 14:25:06 --> Output Class Initialized
INFO - 2025-05-03 14:25:06 --> Security Class Initialized
DEBUG - 2025-05-03 14:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:25:06 --> Input Class Initialized
INFO - 2025-05-03 14:25:06 --> Language Class Initialized
INFO - 2025-05-03 14:25:06 --> Loader Class Initialized
INFO - 2025-05-03 14:25:06 --> Helper loaded: url_helper
INFO - 2025-05-03 14:25:06 --> Helper loaded: string_helper
INFO - 2025-05-03 14:25:06 --> Helper loaded: form_helper
INFO - 2025-05-03 14:25:06 --> Helper loaded: file_helper
INFO - 2025-05-03 14:25:06 --> Helper loaded: html_helper
INFO - 2025-05-03 14:25:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:25:06 --> Controller Class Initialized
INFO - 2025-05-03 22:25:06 --> Model "LogsModel" initialized
INFO - 2025-05-03 22:25:06 --> Final output sent to browser
DEBUG - 2025-05-03 22:25:06 --> Total execution time: 0.1932
INFO - 2025-05-03 14:25:07 --> Config Class Initialized
INFO - 2025-05-03 14:25:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:25:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:25:07 --> Utf8 Class Initialized
INFO - 2025-05-03 14:25:07 --> URI Class Initialized
INFO - 2025-05-03 14:25:07 --> Router Class Initialized
INFO - 2025-05-03 14:25:07 --> Output Class Initialized
INFO - 2025-05-03 14:25:07 --> Security Class Initialized
DEBUG - 2025-05-03 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:25:07 --> Input Class Initialized
INFO - 2025-05-03 14:25:07 --> Language Class Initialized
INFO - 2025-05-03 14:25:07 --> Loader Class Initialized
INFO - 2025-05-03 14:25:07 --> Helper loaded: url_helper
INFO - 2025-05-03 14:25:07 --> Helper loaded: string_helper
INFO - 2025-05-03 14:25:07 --> Helper loaded: form_helper
INFO - 2025-05-03 14:25:07 --> Helper loaded: file_helper
INFO - 2025-05-03 14:25:07 --> Helper loaded: html_helper
INFO - 2025-05-03 14:25:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:25:07 --> Controller Class Initialized
INFO - 2025-05-03 22:25:07 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:25:07 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:25:07 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:25:07 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:25:07 --> Final output sent to browser
DEBUG - 2025-05-03 22:25:07 --> Total execution time: 0.1481
INFO - 2025-05-03 14:27:22 --> Config Class Initialized
INFO - 2025-05-03 14:27:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:22 --> URI Class Initialized
INFO - 2025-05-03 14:27:22 --> Router Class Initialized
INFO - 2025-05-03 14:27:22 --> Output Class Initialized
INFO - 2025-05-03 14:27:22 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:22 --> Input Class Initialized
INFO - 2025-05-03 14:27:22 --> Language Class Initialized
INFO - 2025-05-03 14:27:22 --> Loader Class Initialized
INFO - 2025-05-03 14:27:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:22 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:22 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:22 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:22 --> Controller Class Initialized
INFO - 2025-05-03 14:27:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:27:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:27:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:27:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:27:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:27:22 --> Final output sent to browser
DEBUG - 2025-05-03 14:27:22 --> Total execution time: 0.1431
INFO - 2025-05-03 14:27:23 --> Config Class Initialized
INFO - 2025-05-03 14:27:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:23 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:23 --> URI Class Initialized
INFO - 2025-05-03 14:27:23 --> Router Class Initialized
INFO - 2025-05-03 14:27:23 --> Output Class Initialized
INFO - 2025-05-03 14:27:23 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:24 --> Input Class Initialized
INFO - 2025-05-03 14:27:24 --> Language Class Initialized
INFO - 2025-05-03 14:27:24 --> Loader Class Initialized
INFO - 2025-05-03 14:27:24 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:24 --> Controller Class Initialized
INFO - 2025-05-03 22:27:24 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:27:24 --> Final output sent to browser
DEBUG - 2025-05-03 22:27:24 --> Total execution time: 0.7285
INFO - 2025-05-03 14:27:24 --> Config Class Initialized
INFO - 2025-05-03 14:27:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:24 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:24 --> URI Class Initialized
INFO - 2025-05-03 14:27:24 --> Router Class Initialized
INFO - 2025-05-03 14:27:24 --> Output Class Initialized
INFO - 2025-05-03 14:27:24 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:24 --> Input Class Initialized
INFO - 2025-05-03 14:27:24 --> Language Class Initialized
INFO - 2025-05-03 14:27:24 --> Loader Class Initialized
INFO - 2025-05-03 14:27:24 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:24 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:25 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:25 --> Controller Class Initialized
INFO - 2025-05-03 14:27:25 --> Model "UserModel" initialized
INFO - 2025-05-03 14:27:25 --> Final output sent to browser
DEBUG - 2025-05-03 14:27:25 --> Total execution time: 0.3872
INFO - 2025-05-03 14:27:35 --> Config Class Initialized
INFO - 2025-05-03 14:27:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:35 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:35 --> URI Class Initialized
INFO - 2025-05-03 14:27:35 --> Router Class Initialized
INFO - 2025-05-03 14:27:35 --> Output Class Initialized
INFO - 2025-05-03 14:27:35 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:35 --> Input Class Initialized
INFO - 2025-05-03 14:27:35 --> Language Class Initialized
INFO - 2025-05-03 14:27:35 --> Loader Class Initialized
INFO - 2025-05-03 14:27:35 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:35 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:35 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:35 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:36 --> Controller Class Initialized
INFO - 2025-05-03 14:27:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:27:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:27:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:27:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:27:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:27:36 --> Final output sent to browser
DEBUG - 2025-05-03 14:27:36 --> Total execution time: 0.1387
INFO - 2025-05-03 14:27:36 --> Config Class Initialized
INFO - 2025-05-03 14:27:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:36 --> URI Class Initialized
INFO - 2025-05-03 14:27:36 --> Router Class Initialized
INFO - 2025-05-03 14:27:36 --> Output Class Initialized
INFO - 2025-05-03 14:27:36 --> Security Class Initialized
INFO - 2025-05-03 14:27:36 --> Config Class Initialized
INFO - 2025-05-03 14:27:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:36 --> Utf8 Class Initialized
DEBUG - 2025-05-03 14:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:36 --> URI Class Initialized
INFO - 2025-05-03 14:27:36 --> Input Class Initialized
INFO - 2025-05-03 14:27:36 --> Language Class Initialized
INFO - 2025-05-03 14:27:36 --> Loader Class Initialized
INFO - 2025-05-03 14:27:36 --> Router Class Initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:36 --> Output Class Initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:36 --> Security Class Initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: file_helper
DEBUG - 2025-05-03 14:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:36 --> Input Class Initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:36 --> Language Class Initialized
INFO - 2025-05-03 14:27:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:36 --> Loader Class Initialized
INFO - 2025-05-03 14:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:36 --> Controller Class Initialized
INFO - 2025-05-03 22:27:36 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:36 --> Helper loaded: file_helper
INFO - 2025-05-03 22:27:36 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 14:27:36 --> Helper loaded: html_helper
INFO - 2025-05-03 22:27:36 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:27:36 --> Final output sent to browser
DEBUG - 2025-05-03 22:27:36 --> Total execution time: 0.2167
INFO - 2025-05-03 14:27:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:37 --> Controller Class Initialized
INFO - 2025-05-03 22:27:37 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:27:37 --> Final output sent to browser
DEBUG - 2025-05-03 22:27:37 --> Total execution time: 0.2186
INFO - 2025-05-03 14:27:37 --> Config Class Initialized
INFO - 2025-05-03 14:27:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:37 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:37 --> URI Class Initialized
INFO - 2025-05-03 14:27:37 --> Router Class Initialized
INFO - 2025-05-03 14:27:37 --> Output Class Initialized
INFO - 2025-05-03 14:27:37 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:37 --> Input Class Initialized
INFO - 2025-05-03 14:27:37 --> Language Class Initialized
INFO - 2025-05-03 14:27:37 --> Loader Class Initialized
INFO - 2025-05-03 14:27:37 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:37 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:37 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:37 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:37 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:37 --> Controller Class Initialized
INFO - 2025-05-03 14:27:37 --> Model "UserModel" initialized
INFO - 2025-05-03 14:27:37 --> Final output sent to browser
DEBUG - 2025-05-03 14:27:37 --> Total execution time: 0.1295
INFO - 2025-05-03 14:27:38 --> Config Class Initialized
INFO - 2025-05-03 14:27:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:27:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:27:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:27:38 --> URI Class Initialized
INFO - 2025-05-03 14:27:38 --> Router Class Initialized
INFO - 2025-05-03 14:27:38 --> Output Class Initialized
INFO - 2025-05-03 14:27:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:27:38 --> Input Class Initialized
INFO - 2025-05-03 14:27:38 --> Language Class Initialized
INFO - 2025-05-03 14:27:38 --> Loader Class Initialized
INFO - 2025-05-03 14:27:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:27:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:27:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:27:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:27:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:27:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:27:38 --> Controller Class Initialized
INFO - 2025-05-03 22:27:38 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:27:38 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:27:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:27:38 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:27:38 --> Final output sent to browser
DEBUG - 2025-05-03 22:27:38 --> Total execution time: 0.2320
INFO - 2025-05-03 14:28:20 --> Config Class Initialized
INFO - 2025-05-03 14:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:20 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:20 --> URI Class Initialized
INFO - 2025-05-03 14:28:20 --> Router Class Initialized
INFO - 2025-05-03 14:28:20 --> Output Class Initialized
INFO - 2025-05-03 14:28:20 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:20 --> Input Class Initialized
INFO - 2025-05-03 14:28:20 --> Language Class Initialized
INFO - 2025-05-03 14:28:20 --> Loader Class Initialized
INFO - 2025-05-03 14:28:20 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:20 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:20 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:20 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:20 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:20 --> Controller Class Initialized
INFO - 2025-05-03 14:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:28:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:28:20 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:20 --> Total execution time: 0.0789
INFO - 2025-05-03 14:28:22 --> Config Class Initialized
INFO - 2025-05-03 14:28:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:22 --> Config Class Initialized
INFO - 2025-05-03 14:28:22 --> Hooks Class Initialized
INFO - 2025-05-03 14:28:22 --> URI Class Initialized
DEBUG - 2025-05-03 14:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:22 --> Router Class Initialized
INFO - 2025-05-03 14:28:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:22 --> URI Class Initialized
INFO - 2025-05-03 14:28:22 --> Output Class Initialized
INFO - 2025-05-03 14:28:22 --> Router Class Initialized
INFO - 2025-05-03 14:28:22 --> Security Class Initialized
INFO - 2025-05-03 14:28:22 --> Output Class Initialized
INFO - 2025-05-03 14:28:22 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:22 --> Input Class Initialized
DEBUG - 2025-05-03 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:22 --> Input Class Initialized
INFO - 2025-05-03 14:28:22 --> Language Class Initialized
INFO - 2025-05-03 14:28:22 --> Language Class Initialized
INFO - 2025-05-03 14:28:22 --> Loader Class Initialized
INFO - 2025-05-03 14:28:22 --> Loader Class Initialized
INFO - 2025-05-03 14:28:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:22 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:22 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-03 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:22 --> Controller Class Initialized
INFO - 2025-05-03 22:28:22 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:28:22 --> Final output sent to browser
DEBUG - 2025-05-03 22:28:22 --> Total execution time: 0.0995
INFO - 2025-05-03 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:22 --> Controller Class Initialized
INFO - 2025-05-03 22:28:22 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:28:22 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:28:22 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:28:23 --> Final output sent to browser
DEBUG - 2025-05-03 22:28:23 --> Total execution time: 0.1543
INFO - 2025-05-03 14:28:23 --> Config Class Initialized
INFO - 2025-05-03 14:28:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:23 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:23 --> URI Class Initialized
INFO - 2025-05-03 14:28:23 --> Router Class Initialized
INFO - 2025-05-03 14:28:23 --> Output Class Initialized
INFO - 2025-05-03 14:28:23 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:23 --> Input Class Initialized
INFO - 2025-05-03 14:28:23 --> Language Class Initialized
INFO - 2025-05-03 14:28:23 --> Loader Class Initialized
INFO - 2025-05-03 14:28:23 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:23 --> Controller Class Initialized
INFO - 2025-05-03 14:28:23 --> Model "UserModel" initialized
INFO - 2025-05-03 14:28:23 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:23 --> Total execution time: 0.1042
INFO - 2025-05-03 14:28:23 --> Config Class Initialized
INFO - 2025-05-03 14:28:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:23 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:23 --> URI Class Initialized
INFO - 2025-05-03 14:28:23 --> Router Class Initialized
INFO - 2025-05-03 14:28:23 --> Output Class Initialized
INFO - 2025-05-03 14:28:23 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:23 --> Input Class Initialized
INFO - 2025-05-03 14:28:23 --> Language Class Initialized
INFO - 2025-05-03 14:28:23 --> Loader Class Initialized
INFO - 2025-05-03 14:28:23 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:23 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:24 --> Controller Class Initialized
INFO - 2025-05-03 22:28:24 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:28:24 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:28:24 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:28:24 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:28:24 --> Final output sent to browser
DEBUG - 2025-05-03 22:28:24 --> Total execution time: 0.1892
INFO - 2025-05-03 14:28:46 --> Config Class Initialized
INFO - 2025-05-03 14:28:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:46 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:46 --> URI Class Initialized
INFO - 2025-05-03 14:28:46 --> Router Class Initialized
INFO - 2025-05-03 14:28:46 --> Output Class Initialized
INFO - 2025-05-03 14:28:46 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:46 --> Input Class Initialized
INFO - 2025-05-03 14:28:46 --> Language Class Initialized
INFO - 2025-05-03 14:28:46 --> Loader Class Initialized
INFO - 2025-05-03 14:28:46 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:46 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:46 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:46 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:46 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:46 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:46 --> Controller Class Initialized
INFO - 2025-05-03 14:28:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:28:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:28:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:28:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:28:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:28:46 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:46 --> Total execution time: 0.1073
INFO - 2025-05-03 14:28:47 --> Config Class Initialized
INFO - 2025-05-03 14:28:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:47 --> URI Class Initialized
INFO - 2025-05-03 14:28:47 --> Router Class Initialized
INFO - 2025-05-03 14:28:47 --> Output Class Initialized
INFO - 2025-05-03 14:28:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:47 --> Input Class Initialized
INFO - 2025-05-03 14:28:47 --> Language Class Initialized
INFO - 2025-05-03 14:28:47 --> Config Class Initialized
INFO - 2025-05-03 14:28:47 --> Hooks Class Initialized
INFO - 2025-05-03 14:28:47 --> Loader Class Initialized
INFO - 2025-05-03 14:28:47 --> Helper loaded: url_helper
DEBUG - 2025-05-03 14:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:47 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:47 --> URI Class Initialized
INFO - 2025-05-03 14:28:47 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:47 --> Router Class Initialized
INFO - 2025-05-03 14:28:47 --> Output Class Initialized
INFO - 2025-05-03 14:28:47 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:47 --> Controller Class Initialized
DEBUG - 2025-05-03 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:47 --> Input Class Initialized
INFO - 2025-05-03 14:28:47 --> Language Class Initialized
INFO - 2025-05-03 22:28:47 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:28:47 --> Final output sent to browser
DEBUG - 2025-05-03 22:28:47 --> Total execution time: 0.2541
INFO - 2025-05-03 14:28:47 --> Config Class Initialized
INFO - 2025-05-03 14:28:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:47 --> URI Class Initialized
INFO - 2025-05-03 14:28:47 --> Router Class Initialized
INFO - 2025-05-03 14:28:47 --> Output Class Initialized
INFO - 2025-05-03 14:28:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:47 --> Input Class Initialized
INFO - 2025-05-03 14:28:47 --> Language Class Initialized
INFO - 2025-05-03 14:28:47 --> Loader Class Initialized
INFO - 2025-05-03 14:28:47 --> Loader Class Initialized
INFO - 2025-05-03 14:28:47 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:47 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:48 --> Helper loaded: string_helper
INFO - 2025-05-03 14:28:48 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:48 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:48 --> Helper loaded: file_helper
INFO - 2025-05-03 14:28:48 --> Helper loaded: html_helper
INFO - 2025-05-03 14:28:48 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-03 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:28:48 --> Controller Class Initialized
INFO - 2025-05-03 22:28:48 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:28:48 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:28:48 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:28:48 --> Final output sent to browser
DEBUG - 2025-05-03 22:28:48 --> Total execution time: 0.7314
INFO - 2025-05-03 14:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:48 --> Controller Class Initialized
INFO - 2025-05-03 14:28:48 --> Model "UserModel" initialized
INFO - 2025-05-03 14:28:48 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:48 --> Total execution time: 0.5822
INFO - 2025-05-03 14:29:02 --> Config Class Initialized
INFO - 2025-05-03 14:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:02 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:02 --> URI Class Initialized
INFO - 2025-05-03 14:29:02 --> Router Class Initialized
INFO - 2025-05-03 14:29:02 --> Output Class Initialized
INFO - 2025-05-03 14:29:02 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:02 --> Input Class Initialized
INFO - 2025-05-03 14:29:02 --> Language Class Initialized
INFO - 2025-05-03 14:29:02 --> Loader Class Initialized
INFO - 2025-05-03 14:29:02 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:02 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:02 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:02 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:02 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:02 --> Controller Class Initialized
INFO - 2025-05-03 14:29:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:29:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:29:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 14:29:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:29:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:29:02 --> Final output sent to browser
DEBUG - 2025-05-03 14:29:02 --> Total execution time: 0.1266
INFO - 2025-05-03 14:29:03 --> Config Class Initialized
INFO - 2025-05-03 14:29:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:03 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:03 --> URI Class Initialized
INFO - 2025-05-03 14:29:03 --> Router Class Initialized
INFO - 2025-05-03 14:29:03 --> Output Class Initialized
INFO - 2025-05-03 14:29:03 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:03 --> Input Class Initialized
INFO - 2025-05-03 14:29:03 --> Language Class Initialized
INFO - 2025-05-03 14:29:03 --> Loader Class Initialized
INFO - 2025-05-03 14:29:03 --> Config Class Initialized
INFO - 2025-05-03 14:29:03 --> Hooks Class Initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: string_helper
DEBUG - 2025-05-03 14:29:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:03 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:03 --> URI Class Initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:03 --> Router Class Initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:03 --> Output Class Initialized
INFO - 2025-05-03 14:29:03 --> Security Class Initialized
INFO - 2025-05-03 14:29:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:03 --> Input Class Initialized
INFO - 2025-05-03 14:29:03 --> Language Class Initialized
INFO - 2025-05-03 14:29:03 --> Loader Class Initialized
DEBUG - 2025-05-03 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:03 --> Controller Class Initialized
INFO - 2025-05-03 22:29:03 --> Model "CompanyModel" initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: string_helper
INFO - 2025-05-03 22:29:03 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: file_helper
INFO - 2025-05-03 22:29:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:03 --> Database Driver Class Initialized
INFO - 2025-05-03 22:29:03 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:03 --> Total execution time: 0.6624
DEBUG - 2025-05-03 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:03 --> Controller Class Initialized
INFO - 2025-05-03 22:29:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:03 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:03 --> Total execution time: 0.5164
INFO - 2025-05-03 14:29:03 --> Config Class Initialized
INFO - 2025-05-03 14:29:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:03 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:03 --> URI Class Initialized
INFO - 2025-05-03 14:29:03 --> Router Class Initialized
INFO - 2025-05-03 14:29:03 --> Output Class Initialized
INFO - 2025-05-03 14:29:03 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:03 --> Input Class Initialized
INFO - 2025-05-03 14:29:03 --> Language Class Initialized
INFO - 2025-05-03 14:29:03 --> Loader Class Initialized
INFO - 2025-05-03 14:29:03 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:03 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:03 --> Controller Class Initialized
INFO - 2025-05-03 14:29:03 --> Model "UserModel" initialized
INFO - 2025-05-03 14:29:03 --> Final output sent to browser
DEBUG - 2025-05-03 14:29:03 --> Total execution time: 0.1458
INFO - 2025-05-03 14:29:05 --> Config Class Initialized
INFO - 2025-05-03 14:29:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:05 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:05 --> URI Class Initialized
INFO - 2025-05-03 14:29:05 --> Router Class Initialized
INFO - 2025-05-03 14:29:05 --> Output Class Initialized
INFO - 2025-05-03 14:29:05 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:05 --> Input Class Initialized
INFO - 2025-05-03 14:29:05 --> Language Class Initialized
INFO - 2025-05-03 14:29:05 --> Loader Class Initialized
INFO - 2025-05-03 14:29:05 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:05 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:05 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:05 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:05 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:05 --> Controller Class Initialized
INFO - 2025-05-03 22:29:05 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:05 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:05 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:05 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:05 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:05 --> Total execution time: 0.1971
INFO - 2025-05-03 14:29:07 --> Config Class Initialized
INFO - 2025-05-03 14:29:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:07 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:07 --> URI Class Initialized
INFO - 2025-05-03 14:29:07 --> Router Class Initialized
INFO - 2025-05-03 14:29:07 --> Output Class Initialized
INFO - 2025-05-03 14:29:07 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:07 --> Input Class Initialized
INFO - 2025-05-03 14:29:07 --> Language Class Initialized
INFO - 2025-05-03 14:29:07 --> Loader Class Initialized
INFO - 2025-05-03 14:29:07 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:07 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:07 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:07 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:07 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:07 --> Controller Class Initialized
INFO - 2025-05-03 22:29:07 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:07 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:07 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:07 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:07 --> Total execution time: 0.2099
INFO - 2025-05-03 14:29:08 --> Config Class Initialized
INFO - 2025-05-03 14:29:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:08 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:08 --> URI Class Initialized
INFO - 2025-05-03 14:29:08 --> Router Class Initialized
INFO - 2025-05-03 14:29:08 --> Output Class Initialized
INFO - 2025-05-03 14:29:08 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:08 --> Input Class Initialized
INFO - 2025-05-03 14:29:08 --> Language Class Initialized
INFO - 2025-05-03 14:29:08 --> Loader Class Initialized
INFO - 2025-05-03 14:29:08 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:08 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:08 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:08 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:08 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:08 --> Controller Class Initialized
INFO - 2025-05-03 22:29:08 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:08 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:08 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:08 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:08 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:08 --> Total execution time: 0.1706
INFO - 2025-05-03 14:29:15 --> Config Class Initialized
INFO - 2025-05-03 14:29:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:15 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:15 --> URI Class Initialized
INFO - 2025-05-03 14:29:15 --> Router Class Initialized
INFO - 2025-05-03 14:29:15 --> Output Class Initialized
INFO - 2025-05-03 14:29:15 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:15 --> Input Class Initialized
INFO - 2025-05-03 14:29:15 --> Language Class Initialized
INFO - 2025-05-03 14:29:15 --> Loader Class Initialized
INFO - 2025-05-03 14:29:15 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:15 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:15 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:15 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:15 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:15 --> Controller Class Initialized
INFO - 2025-05-03 22:29:15 --> Model "LogsModel" initialized
INFO - 2025-05-03 22:29:15 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:15 --> Total execution time: 0.1457
INFO - 2025-05-03 14:29:17 --> Config Class Initialized
INFO - 2025-05-03 14:29:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:17 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:17 --> URI Class Initialized
INFO - 2025-05-03 14:29:17 --> Router Class Initialized
INFO - 2025-05-03 14:29:17 --> Output Class Initialized
INFO - 2025-05-03 14:29:17 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:17 --> Input Class Initialized
INFO - 2025-05-03 14:29:17 --> Language Class Initialized
INFO - 2025-05-03 14:29:17 --> Loader Class Initialized
INFO - 2025-05-03 14:29:17 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:17 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:17 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:17 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:17 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:17 --> Controller Class Initialized
INFO - 2025-05-03 22:29:17 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:17 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:17 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:17 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:17 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:17 --> Total execution time: 0.1402
INFO - 2025-05-03 14:29:22 --> Config Class Initialized
INFO - 2025-05-03 14:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:22 --> URI Class Initialized
INFO - 2025-05-03 14:29:22 --> Router Class Initialized
INFO - 2025-05-03 14:29:22 --> Output Class Initialized
INFO - 2025-05-03 14:29:22 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:22 --> Input Class Initialized
INFO - 2025-05-03 14:29:22 --> Language Class Initialized
INFO - 2025-05-03 14:29:22 --> Loader Class Initialized
INFO - 2025-05-03 14:29:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:22 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:22 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:22 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:22 --> Controller Class Initialized
INFO - 2025-05-03 22:29:22 --> Model "LogsModel" initialized
INFO - 2025-05-03 22:29:22 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:22 --> Total execution time: 0.1151
INFO - 2025-05-03 14:29:24 --> Config Class Initialized
INFO - 2025-05-03 14:29:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:24 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:24 --> URI Class Initialized
INFO - 2025-05-03 14:29:24 --> Router Class Initialized
INFO - 2025-05-03 14:29:24 --> Output Class Initialized
INFO - 2025-05-03 14:29:24 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:24 --> Input Class Initialized
INFO - 2025-05-03 14:29:24 --> Language Class Initialized
INFO - 2025-05-03 14:29:24 --> Loader Class Initialized
INFO - 2025-05-03 14:29:24 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:24 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:24 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:24 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:24 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:24 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:24 --> Controller Class Initialized
INFO - 2025-05-03 22:29:24 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:24 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:24 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:24 --> Total execution time: 0.2997
INFO - 2025-05-03 14:29:36 --> Config Class Initialized
INFO - 2025-05-03 14:29:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:36 --> URI Class Initialized
INFO - 2025-05-03 14:29:36 --> Router Class Initialized
INFO - 2025-05-03 14:29:36 --> Output Class Initialized
INFO - 2025-05-03 14:29:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:36 --> Input Class Initialized
INFO - 2025-05-03 14:29:36 --> Language Class Initialized
INFO - 2025-05-03 14:29:36 --> Loader Class Initialized
INFO - 2025-05-03 14:29:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:36 --> Controller Class Initialized
INFO - 2025-05-03 22:29:36 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:36 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:36 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:36 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:36 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:36 --> Total execution time: 0.1270
INFO - 2025-05-03 14:29:38 --> Config Class Initialized
INFO - 2025-05-03 14:29:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:38 --> URI Class Initialized
INFO - 2025-05-03 14:29:38 --> Router Class Initialized
INFO - 2025-05-03 14:29:38 --> Output Class Initialized
INFO - 2025-05-03 14:29:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:38 --> Input Class Initialized
INFO - 2025-05-03 14:29:38 --> Language Class Initialized
INFO - 2025-05-03 14:29:38 --> Loader Class Initialized
INFO - 2025-05-03 14:29:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:38 --> Controller Class Initialized
INFO - 2025-05-03 22:29:38 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:38 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:38 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:38 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:38 --> Total execution time: 0.1942
INFO - 2025-05-03 14:29:59 --> Config Class Initialized
INFO - 2025-05-03 14:29:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:59 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:59 --> URI Class Initialized
INFO - 2025-05-03 14:29:59 --> Router Class Initialized
INFO - 2025-05-03 14:29:59 --> Output Class Initialized
INFO - 2025-05-03 14:29:59 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:59 --> Input Class Initialized
INFO - 2025-05-03 14:29:59 --> Language Class Initialized
INFO - 2025-05-03 14:29:59 --> Loader Class Initialized
INFO - 2025-05-03 14:29:59 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:59 --> Helper loaded: string_helper
INFO - 2025-05-03 14:29:59 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:59 --> Helper loaded: file_helper
INFO - 2025-05-03 14:29:59 --> Helper loaded: html_helper
INFO - 2025-05-03 14:29:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:59 --> Controller Class Initialized
INFO - 2025-05-03 22:29:59 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:29:59 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:29:59 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:29:59 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:29:59 --> Final output sent to browser
DEBUG - 2025-05-03 22:29:59 --> Total execution time: 0.2459
INFO - 2025-05-03 14:30:01 --> Config Class Initialized
INFO - 2025-05-03 14:30:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:01 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:01 --> URI Class Initialized
INFO - 2025-05-03 14:30:01 --> Router Class Initialized
INFO - 2025-05-03 14:30:01 --> Output Class Initialized
INFO - 2025-05-03 14:30:01 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:01 --> Input Class Initialized
INFO - 2025-05-03 14:30:01 --> Language Class Initialized
INFO - 2025-05-03 14:30:01 --> Loader Class Initialized
INFO - 2025-05-03 14:30:01 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:01 --> Helper loaded: string_helper
INFO - 2025-05-03 14:30:01 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:01 --> Helper loaded: file_helper
INFO - 2025-05-03 14:30:01 --> Helper loaded: html_helper
INFO - 2025-05-03 14:30:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:01 --> Controller Class Initialized
INFO - 2025-05-03 22:30:01 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:30:01 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:30:01 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:30:01 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:30:01 --> Final output sent to browser
DEBUG - 2025-05-03 22:30:01 --> Total execution time: 0.1395
INFO - 2025-05-03 14:30:11 --> Config Class Initialized
INFO - 2025-05-03 14:30:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:11 --> URI Class Initialized
INFO - 2025-05-03 14:30:11 --> Router Class Initialized
INFO - 2025-05-03 14:30:11 --> Output Class Initialized
INFO - 2025-05-03 14:30:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:11 --> Input Class Initialized
INFO - 2025-05-03 14:30:11 --> Language Class Initialized
INFO - 2025-05-03 14:30:11 --> Loader Class Initialized
INFO - 2025-05-03 14:30:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:30:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:30:11 --> Helper loaded: html_helper
INFO - 2025-05-03 14:30:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:11 --> Controller Class Initialized
INFO - 2025-05-03 22:30:11 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:30:11 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:30:11 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:30:11 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:30:11 --> Final output sent to browser
DEBUG - 2025-05-03 22:30:11 --> Total execution time: 0.2908
INFO - 2025-05-03 14:30:47 --> Config Class Initialized
INFO - 2025-05-03 14:30:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:47 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:47 --> URI Class Initialized
INFO - 2025-05-03 14:30:47 --> Router Class Initialized
INFO - 2025-05-03 14:30:47 --> Output Class Initialized
INFO - 2025-05-03 14:30:47 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:47 --> Input Class Initialized
INFO - 2025-05-03 14:30:47 --> Language Class Initialized
INFO - 2025-05-03 14:30:47 --> Loader Class Initialized
INFO - 2025-05-03 14:30:47 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:47 --> Helper loaded: string_helper
INFO - 2025-05-03 14:30:47 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:47 --> Helper loaded: file_helper
INFO - 2025-05-03 14:30:47 --> Helper loaded: html_helper
INFO - 2025-05-03 14:30:47 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:47 --> Controller Class Initialized
INFO - 2025-05-03 22:30:47 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:30:47 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:30:47 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:30:47 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:30:47 --> Final output sent to browser
DEBUG - 2025-05-03 22:30:47 --> Total execution time: 0.1628
INFO - 2025-05-03 14:31:09 --> Config Class Initialized
INFO - 2025-05-03 14:31:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:31:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:31:09 --> Utf8 Class Initialized
INFO - 2025-05-03 14:31:09 --> URI Class Initialized
INFO - 2025-05-03 14:31:09 --> Router Class Initialized
INFO - 2025-05-03 14:31:09 --> Output Class Initialized
INFO - 2025-05-03 14:31:09 --> Security Class Initialized
DEBUG - 2025-05-03 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:31:09 --> Input Class Initialized
INFO - 2025-05-03 14:31:09 --> Language Class Initialized
INFO - 2025-05-03 14:31:09 --> Loader Class Initialized
INFO - 2025-05-03 14:31:09 --> Helper loaded: url_helper
INFO - 2025-05-03 14:31:09 --> Helper loaded: string_helper
INFO - 2025-05-03 14:31:09 --> Helper loaded: form_helper
INFO - 2025-05-03 14:31:09 --> Helper loaded: file_helper
INFO - 2025-05-03 14:31:09 --> Helper loaded: html_helper
INFO - 2025-05-03 14:31:09 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:31:09 --> Controller Class Initialized
INFO - 2025-05-03 22:31:09 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:31:09 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:31:10 --> Final output sent to browser
DEBUG - 2025-05-03 22:31:10 --> Total execution time: 0.2187
INFO - 2025-05-03 14:32:56 --> Config Class Initialized
INFO - 2025-05-03 14:32:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:32:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:32:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:32:56 --> URI Class Initialized
INFO - 2025-05-03 14:32:56 --> Router Class Initialized
INFO - 2025-05-03 14:32:56 --> Output Class Initialized
INFO - 2025-05-03 14:32:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:32:56 --> Input Class Initialized
INFO - 2025-05-03 14:32:56 --> Language Class Initialized
INFO - 2025-05-03 14:32:56 --> Loader Class Initialized
INFO - 2025-05-03 14:32:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:32:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:32:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:32:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:32:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:32:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:32:56 --> Controller Class Initialized
INFO - 2025-05-03 22:32:56 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:32:56 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:32:56 --> Final output sent to browser
DEBUG - 2025-05-03 22:32:56 --> Total execution time: 0.3713
INFO - 2025-05-03 14:33:03 --> Config Class Initialized
INFO - 2025-05-03 14:33:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:33:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:33:03 --> Utf8 Class Initialized
INFO - 2025-05-03 14:33:03 --> URI Class Initialized
INFO - 2025-05-03 14:33:03 --> Router Class Initialized
INFO - 2025-05-03 14:33:03 --> Output Class Initialized
INFO - 2025-05-03 14:33:03 --> Security Class Initialized
DEBUG - 2025-05-03 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:33:03 --> Input Class Initialized
INFO - 2025-05-03 14:33:03 --> Language Class Initialized
INFO - 2025-05-03 14:33:03 --> Loader Class Initialized
INFO - 2025-05-03 14:33:03 --> Helper loaded: url_helper
INFO - 2025-05-03 14:33:03 --> Helper loaded: string_helper
INFO - 2025-05-03 14:33:03 --> Helper loaded: form_helper
INFO - 2025-05-03 14:33:03 --> Helper loaded: file_helper
INFO - 2025-05-03 14:33:03 --> Helper loaded: html_helper
INFO - 2025-05-03 14:33:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:33:03 --> Controller Class Initialized
INFO - 2025-05-03 22:33:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:33:17 --> Config Class Initialized
INFO - 2025-05-03 14:33:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:33:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:33:17 --> Utf8 Class Initialized
INFO - 2025-05-03 14:33:17 --> URI Class Initialized
INFO - 2025-05-03 14:33:17 --> Router Class Initialized
INFO - 2025-05-03 14:33:17 --> Output Class Initialized
INFO - 2025-05-03 14:33:17 --> Security Class Initialized
DEBUG - 2025-05-03 14:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:33:17 --> Input Class Initialized
INFO - 2025-05-03 14:33:17 --> Language Class Initialized
INFO - 2025-05-03 14:33:17 --> Loader Class Initialized
INFO - 2025-05-03 14:33:17 --> Helper loaded: url_helper
INFO - 2025-05-03 14:33:17 --> Helper loaded: string_helper
INFO - 2025-05-03 14:33:17 --> Helper loaded: form_helper
INFO - 2025-05-03 14:33:17 --> Helper loaded: file_helper
INFO - 2025-05-03 14:33:17 --> Helper loaded: html_helper
INFO - 2025-05-03 14:33:17 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:33:17 --> Controller Class Initialized
INFO - 2025-05-03 22:33:17 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:33:51 --> Config Class Initialized
INFO - 2025-05-03 14:33:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:33:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:33:51 --> Utf8 Class Initialized
INFO - 2025-05-03 14:33:51 --> URI Class Initialized
INFO - 2025-05-03 14:33:51 --> Router Class Initialized
INFO - 2025-05-03 14:33:51 --> Output Class Initialized
INFO - 2025-05-03 14:33:51 --> Security Class Initialized
DEBUG - 2025-05-03 14:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:33:51 --> Input Class Initialized
INFO - 2025-05-03 14:33:51 --> Language Class Initialized
INFO - 2025-05-03 14:33:51 --> Loader Class Initialized
INFO - 2025-05-03 14:33:51 --> Helper loaded: url_helper
INFO - 2025-05-03 14:33:51 --> Helper loaded: string_helper
INFO - 2025-05-03 14:33:51 --> Helper loaded: form_helper
INFO - 2025-05-03 14:33:51 --> Helper loaded: file_helper
INFO - 2025-05-03 14:33:51 --> Helper loaded: html_helper
INFO - 2025-05-03 14:33:51 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:33:51 --> Controller Class Initialized
INFO - 2025-05-03 22:33:51 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:35:30 --> Config Class Initialized
INFO - 2025-05-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:35:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:35:30 --> Utf8 Class Initialized
INFO - 2025-05-03 14:35:30 --> URI Class Initialized
INFO - 2025-05-03 14:35:30 --> Router Class Initialized
INFO - 2025-05-03 14:35:30 --> Output Class Initialized
INFO - 2025-05-03 14:35:30 --> Security Class Initialized
DEBUG - 2025-05-03 14:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:35:30 --> Input Class Initialized
INFO - 2025-05-03 14:35:30 --> Language Class Initialized
INFO - 2025-05-03 14:35:30 --> Loader Class Initialized
INFO - 2025-05-03 14:35:30 --> Helper loaded: url_helper
INFO - 2025-05-03 14:35:30 --> Helper loaded: string_helper
INFO - 2025-05-03 14:35:30 --> Helper loaded: form_helper
INFO - 2025-05-03 14:35:30 --> Helper loaded: file_helper
INFO - 2025-05-03 14:35:30 --> Helper loaded: html_helper
INFO - 2025-05-03 14:35:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:35:30 --> Controller Class Initialized
INFO - 2025-05-03 22:35:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:35:38 --> Config Class Initialized
INFO - 2025-05-03 14:35:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:35:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:35:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:35:38 --> URI Class Initialized
INFO - 2025-05-03 14:35:38 --> Router Class Initialized
INFO - 2025-05-03 14:35:38 --> Output Class Initialized
INFO - 2025-05-03 14:35:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:35:38 --> Input Class Initialized
INFO - 2025-05-03 14:35:38 --> Language Class Initialized
INFO - 2025-05-03 14:35:38 --> Loader Class Initialized
INFO - 2025-05-03 14:35:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:35:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:35:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:35:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:35:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:35:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:35:38 --> Controller Class Initialized
INFO - 2025-05-03 22:35:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:35:39 --> Final output sent to browser
DEBUG - 2025-05-03 22:35:39 --> Total execution time: 0.2658
INFO - 2025-05-03 14:35:54 --> Config Class Initialized
INFO - 2025-05-03 14:35:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:35:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:35:54 --> Utf8 Class Initialized
INFO - 2025-05-03 14:35:54 --> URI Class Initialized
INFO - 2025-05-03 14:35:54 --> Router Class Initialized
INFO - 2025-05-03 14:35:54 --> Output Class Initialized
INFO - 2025-05-03 14:35:54 --> Security Class Initialized
DEBUG - 2025-05-03 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:35:54 --> Input Class Initialized
INFO - 2025-05-03 14:35:54 --> Language Class Initialized
INFO - 2025-05-03 14:35:54 --> Loader Class Initialized
INFO - 2025-05-03 14:35:54 --> Helper loaded: url_helper
INFO - 2025-05-03 14:35:54 --> Helper loaded: string_helper
INFO - 2025-05-03 14:35:54 --> Helper loaded: form_helper
INFO - 2025-05-03 14:35:54 --> Helper loaded: file_helper
INFO - 2025-05-03 14:35:54 --> Helper loaded: html_helper
INFO - 2025-05-03 14:35:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:35:54 --> Controller Class Initialized
INFO - 2025-05-03 22:35:54 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:35:54 --> Final output sent to browser
DEBUG - 2025-05-03 22:35:54 --> Total execution time: 0.1959
INFO - 2025-05-03 14:35:56 --> Config Class Initialized
INFO - 2025-05-03 14:35:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:35:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:35:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:35:56 --> URI Class Initialized
INFO - 2025-05-03 14:35:56 --> Router Class Initialized
INFO - 2025-05-03 14:35:56 --> Output Class Initialized
INFO - 2025-05-03 14:35:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:35:56 --> Input Class Initialized
INFO - 2025-05-03 14:35:56 --> Language Class Initialized
INFO - 2025-05-03 14:35:56 --> Loader Class Initialized
INFO - 2025-05-03 14:35:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:35:56 --> Helper loaded: string_helper
INFO - 2025-05-03 14:35:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:35:56 --> Helper loaded: file_helper
INFO - 2025-05-03 14:35:56 --> Helper loaded: html_helper
INFO - 2025-05-03 14:35:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:35:56 --> Controller Class Initialized
INFO - 2025-05-03 22:35:56 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:35:56 --> Final output sent to browser
DEBUG - 2025-05-03 22:35:56 --> Total execution time: 0.1463
INFO - 2025-05-03 14:35:57 --> Config Class Initialized
INFO - 2025-05-03 14:35:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:35:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:35:57 --> Utf8 Class Initialized
INFO - 2025-05-03 14:35:57 --> URI Class Initialized
INFO - 2025-05-03 14:35:57 --> Router Class Initialized
INFO - 2025-05-03 14:35:57 --> Output Class Initialized
INFO - 2025-05-03 14:35:57 --> Security Class Initialized
DEBUG - 2025-05-03 14:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:35:57 --> Input Class Initialized
INFO - 2025-05-03 14:35:57 --> Language Class Initialized
INFO - 2025-05-03 14:35:57 --> Loader Class Initialized
INFO - 2025-05-03 14:35:57 --> Helper loaded: url_helper
INFO - 2025-05-03 14:35:57 --> Helper loaded: string_helper
INFO - 2025-05-03 14:35:57 --> Helper loaded: form_helper
INFO - 2025-05-03 14:35:57 --> Helper loaded: file_helper
INFO - 2025-05-03 14:35:57 --> Helper loaded: html_helper
INFO - 2025-05-03 14:35:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:35:57 --> Controller Class Initialized
INFO - 2025-05-03 22:35:57 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:35:57 --> Final output sent to browser
DEBUG - 2025-05-03 22:35:57 --> Total execution time: 0.1329
INFO - 2025-05-03 14:36:08 --> Config Class Initialized
INFO - 2025-05-03 14:36:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:36:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:36:08 --> Utf8 Class Initialized
INFO - 2025-05-03 14:36:08 --> URI Class Initialized
INFO - 2025-05-03 14:36:08 --> Router Class Initialized
INFO - 2025-05-03 14:36:08 --> Output Class Initialized
INFO - 2025-05-03 14:36:08 --> Security Class Initialized
DEBUG - 2025-05-03 14:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:36:08 --> Input Class Initialized
INFO - 2025-05-03 14:36:08 --> Language Class Initialized
INFO - 2025-05-03 14:36:08 --> Loader Class Initialized
INFO - 2025-05-03 14:36:08 --> Helper loaded: url_helper
INFO - 2025-05-03 14:36:08 --> Helper loaded: string_helper
INFO - 2025-05-03 14:36:08 --> Helper loaded: form_helper
INFO - 2025-05-03 14:36:08 --> Helper loaded: file_helper
INFO - 2025-05-03 14:36:08 --> Helper loaded: html_helper
INFO - 2025-05-03 14:36:08 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:36:08 --> Controller Class Initialized
INFO - 2025-05-03 22:36:08 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:36:26 --> Config Class Initialized
INFO - 2025-05-03 14:36:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:36:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:36:26 --> Utf8 Class Initialized
INFO - 2025-05-03 14:36:26 --> URI Class Initialized
INFO - 2025-05-03 14:36:26 --> Router Class Initialized
INFO - 2025-05-03 14:36:26 --> Output Class Initialized
INFO - 2025-05-03 14:36:26 --> Security Class Initialized
DEBUG - 2025-05-03 14:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:36:26 --> Input Class Initialized
INFO - 2025-05-03 14:36:26 --> Language Class Initialized
INFO - 2025-05-03 14:36:26 --> Loader Class Initialized
INFO - 2025-05-03 14:36:26 --> Helper loaded: url_helper
INFO - 2025-05-03 14:36:26 --> Helper loaded: string_helper
INFO - 2025-05-03 14:36:26 --> Helper loaded: form_helper
INFO - 2025-05-03 14:36:26 --> Helper loaded: file_helper
INFO - 2025-05-03 14:36:26 --> Helper loaded: html_helper
INFO - 2025-05-03 14:36:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:36:26 --> Controller Class Initialized
INFO - 2025-05-03 14:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/add_storage_facility.php
INFO - 2025-05-03 14:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:36:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:36:26 --> Final output sent to browser
DEBUG - 2025-05-03 14:36:26 --> Total execution time: 0.3049
INFO - 2025-05-03 14:36:28 --> Config Class Initialized
INFO - 2025-05-03 14:36:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:36:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:36:28 --> Utf8 Class Initialized
INFO - 2025-05-03 14:36:28 --> URI Class Initialized
INFO - 2025-05-03 14:36:28 --> Router Class Initialized
INFO - 2025-05-03 14:36:28 --> Output Class Initialized
INFO - 2025-05-03 14:36:28 --> Security Class Initialized
DEBUG - 2025-05-03 14:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:36:28 --> Input Class Initialized
INFO - 2025-05-03 14:36:28 --> Language Class Initialized
INFO - 2025-05-03 14:36:28 --> Loader Class Initialized
INFO - 2025-05-03 14:36:28 --> Helper loaded: url_helper
INFO - 2025-05-03 14:36:28 --> Helper loaded: string_helper
INFO - 2025-05-03 14:36:28 --> Helper loaded: form_helper
INFO - 2025-05-03 14:36:28 --> Helper loaded: file_helper
INFO - 2025-05-03 14:36:28 --> Helper loaded: html_helper
INFO - 2025-05-03 14:36:28 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:36:28 --> Controller Class Initialized
INFO - 2025-05-03 22:36:28 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:36:28 --> Final output sent to browser
DEBUG - 2025-05-03 22:36:28 --> Total execution time: 0.3215
INFO - 2025-05-03 14:36:31 --> Config Class Initialized
INFO - 2025-05-03 14:36:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:36:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:36:31 --> Utf8 Class Initialized
INFO - 2025-05-03 14:36:31 --> URI Class Initialized
INFO - 2025-05-03 14:36:31 --> Router Class Initialized
INFO - 2025-05-03 14:36:31 --> Output Class Initialized
INFO - 2025-05-03 14:36:31 --> Security Class Initialized
DEBUG - 2025-05-03 14:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:36:32 --> Input Class Initialized
INFO - 2025-05-03 14:36:32 --> Language Class Initialized
INFO - 2025-05-03 14:36:32 --> Loader Class Initialized
INFO - 2025-05-03 14:36:32 --> Helper loaded: url_helper
INFO - 2025-05-03 14:36:32 --> Helper loaded: string_helper
INFO - 2025-05-03 14:36:32 --> Helper loaded: form_helper
INFO - 2025-05-03 14:36:32 --> Helper loaded: file_helper
INFO - 2025-05-03 14:36:32 --> Helper loaded: html_helper
INFO - 2025-05-03 14:36:32 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:36:32 --> Controller Class Initialized
INFO - 2025-05-03 22:36:32 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:36:32 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:36:32 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:36:32 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:36:32 --> Final output sent to browser
DEBUG - 2025-05-03 22:36:32 --> Total execution time: 0.2208
INFO - 2025-05-03 14:37:19 --> Config Class Initialized
INFO - 2025-05-03 14:37:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:37:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:37:19 --> Utf8 Class Initialized
INFO - 2025-05-03 14:37:19 --> URI Class Initialized
INFO - 2025-05-03 14:37:19 --> Router Class Initialized
INFO - 2025-05-03 14:37:19 --> Output Class Initialized
INFO - 2025-05-03 14:37:19 --> Security Class Initialized
DEBUG - 2025-05-03 14:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:37:19 --> Input Class Initialized
INFO - 2025-05-03 14:37:19 --> Language Class Initialized
INFO - 2025-05-03 14:37:19 --> Loader Class Initialized
INFO - 2025-05-03 14:37:19 --> Helper loaded: url_helper
INFO - 2025-05-03 14:37:19 --> Helper loaded: string_helper
INFO - 2025-05-03 14:37:19 --> Helper loaded: form_helper
INFO - 2025-05-03 14:37:19 --> Helper loaded: file_helper
INFO - 2025-05-03 14:37:19 --> Helper loaded: html_helper
INFO - 2025-05-03 14:37:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:37:19 --> Controller Class Initialized
INFO - 2025-05-03 22:37:19 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:37:35 --> Config Class Initialized
INFO - 2025-05-03 14:37:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:37:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:37:35 --> Utf8 Class Initialized
INFO - 2025-05-03 14:37:35 --> URI Class Initialized
INFO - 2025-05-03 14:37:35 --> Router Class Initialized
INFO - 2025-05-03 14:37:35 --> Output Class Initialized
INFO - 2025-05-03 14:37:35 --> Security Class Initialized
DEBUG - 2025-05-03 14:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:37:35 --> Input Class Initialized
INFO - 2025-05-03 14:37:35 --> Language Class Initialized
INFO - 2025-05-03 14:37:35 --> Loader Class Initialized
INFO - 2025-05-03 14:37:35 --> Helper loaded: url_helper
INFO - 2025-05-03 14:37:35 --> Helper loaded: string_helper
INFO - 2025-05-03 14:37:35 --> Helper loaded: form_helper
INFO - 2025-05-03 14:37:35 --> Helper loaded: file_helper
INFO - 2025-05-03 14:37:35 --> Helper loaded: html_helper
INFO - 2025-05-03 14:37:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:37:35 --> Controller Class Initialized
INFO - 2025-05-03 22:37:35 --> Model "CompanyModel" initialized
INFO - 2025-05-03 22:37:36 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 22:37:36 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:37:36 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 22:37:36 --> Final output sent to browser
DEBUG - 2025-05-03 22:37:36 --> Total execution time: 0.3583
INFO - 2025-05-03 14:38:34 --> Config Class Initialized
INFO - 2025-05-03 14:38:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:38:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:38:34 --> Utf8 Class Initialized
INFO - 2025-05-03 14:38:34 --> URI Class Initialized
INFO - 2025-05-03 14:38:34 --> Router Class Initialized
INFO - 2025-05-03 14:38:34 --> Output Class Initialized
INFO - 2025-05-03 14:38:34 --> Security Class Initialized
DEBUG - 2025-05-03 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:38:34 --> Input Class Initialized
INFO - 2025-05-03 14:38:34 --> Language Class Initialized
INFO - 2025-05-03 14:38:34 --> Loader Class Initialized
INFO - 2025-05-03 14:38:34 --> Helper loaded: url_helper
INFO - 2025-05-03 14:38:34 --> Helper loaded: string_helper
INFO - 2025-05-03 14:38:34 --> Helper loaded: form_helper
INFO - 2025-05-03 14:38:34 --> Helper loaded: file_helper
INFO - 2025-05-03 14:38:34 --> Helper loaded: html_helper
INFO - 2025-05-03 14:38:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:38:34 --> Controller Class Initialized
INFO - 2025-05-03 22:38:34 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:38:48 --> Config Class Initialized
INFO - 2025-05-03 14:38:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:38:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:38:48 --> Utf8 Class Initialized
INFO - 2025-05-03 14:38:48 --> URI Class Initialized
INFO - 2025-05-03 14:38:48 --> Router Class Initialized
INFO - 2025-05-03 14:38:48 --> Output Class Initialized
INFO - 2025-05-03 14:38:48 --> Security Class Initialized
DEBUG - 2025-05-03 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:38:48 --> Input Class Initialized
INFO - 2025-05-03 14:38:48 --> Language Class Initialized
INFO - 2025-05-03 14:38:48 --> Loader Class Initialized
INFO - 2025-05-03 14:38:48 --> Helper loaded: url_helper
INFO - 2025-05-03 14:38:48 --> Helper loaded: string_helper
INFO - 2025-05-03 14:38:48 --> Helper loaded: form_helper
INFO - 2025-05-03 14:38:48 --> Helper loaded: file_helper
INFO - 2025-05-03 14:38:48 --> Helper loaded: html_helper
INFO - 2025-05-03 14:38:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:38:48 --> Controller Class Initialized
INFO - 2025-05-03 22:38:48 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:38:48 --> Final output sent to browser
DEBUG - 2025-05-03 22:38:48 --> Total execution time: 0.3272
INFO - 2025-05-03 14:38:52 --> Config Class Initialized
INFO - 2025-05-03 14:38:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:38:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:38:52 --> Utf8 Class Initialized
INFO - 2025-05-03 14:38:52 --> URI Class Initialized
INFO - 2025-05-03 14:38:52 --> Router Class Initialized
INFO - 2025-05-03 14:38:52 --> Output Class Initialized
INFO - 2025-05-03 14:38:52 --> Security Class Initialized
DEBUG - 2025-05-03 14:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:38:52 --> Input Class Initialized
INFO - 2025-05-03 14:38:52 --> Language Class Initialized
INFO - 2025-05-03 14:38:52 --> Loader Class Initialized
INFO - 2025-05-03 14:38:52 --> Helper loaded: url_helper
INFO - 2025-05-03 14:38:52 --> Helper loaded: string_helper
INFO - 2025-05-03 14:38:52 --> Helper loaded: form_helper
INFO - 2025-05-03 14:38:52 --> Helper loaded: file_helper
INFO - 2025-05-03 14:38:52 --> Helper loaded: html_helper
INFO - 2025-05-03 14:38:52 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:38:52 --> Controller Class Initialized
INFO - 2025-05-03 22:38:52 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:39:41 --> Config Class Initialized
INFO - 2025-05-03 14:39:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:39:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:39:41 --> Utf8 Class Initialized
INFO - 2025-05-03 14:39:41 --> URI Class Initialized
INFO - 2025-05-03 14:39:41 --> Router Class Initialized
INFO - 2025-05-03 14:39:41 --> Output Class Initialized
INFO - 2025-05-03 14:39:41 --> Security Class Initialized
DEBUG - 2025-05-03 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:39:41 --> Input Class Initialized
INFO - 2025-05-03 14:39:41 --> Language Class Initialized
INFO - 2025-05-03 14:39:41 --> Loader Class Initialized
INFO - 2025-05-03 14:39:41 --> Helper loaded: url_helper
INFO - 2025-05-03 14:39:41 --> Helper loaded: string_helper
INFO - 2025-05-03 14:39:41 --> Helper loaded: form_helper
INFO - 2025-05-03 14:39:41 --> Helper loaded: file_helper
INFO - 2025-05-03 14:39:41 --> Helper loaded: html_helper
INFO - 2025-05-03 14:39:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:39:41 --> Controller Class Initialized
INFO - 2025-05-03 14:39:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:39:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:39:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:39:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:39:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:39:41 --> Final output sent to browser
DEBUG - 2025-05-03 14:39:41 --> Total execution time: 0.1200
INFO - 2025-05-03 14:39:43 --> Config Class Initialized
INFO - 2025-05-03 14:39:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:39:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:39:43 --> Utf8 Class Initialized
INFO - 2025-05-03 14:39:43 --> URI Class Initialized
INFO - 2025-05-03 14:39:43 --> Router Class Initialized
INFO - 2025-05-03 14:39:43 --> Output Class Initialized
INFO - 2025-05-03 14:39:43 --> Security Class Initialized
DEBUG - 2025-05-03 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:39:43 --> Input Class Initialized
INFO - 2025-05-03 14:39:43 --> Language Class Initialized
INFO - 2025-05-03 14:39:43 --> Loader Class Initialized
INFO - 2025-05-03 14:39:43 --> Helper loaded: url_helper
INFO - 2025-05-03 14:39:43 --> Helper loaded: string_helper
INFO - 2025-05-03 14:39:43 --> Helper loaded: form_helper
INFO - 2025-05-03 14:39:43 --> Helper loaded: file_helper
INFO - 2025-05-03 14:39:43 --> Helper loaded: html_helper
INFO - 2025-05-03 14:39:43 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:39:43 --> Controller Class Initialized
INFO - 2025-05-03 22:39:43 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:39:43 --> Final output sent to browser
DEBUG - 2025-05-03 22:39:43 --> Total execution time: 0.1829
INFO - 2025-05-03 14:39:45 --> Config Class Initialized
INFO - 2025-05-03 14:39:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:39:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:39:45 --> Utf8 Class Initialized
INFO - 2025-05-03 14:39:45 --> URI Class Initialized
INFO - 2025-05-03 14:39:45 --> Router Class Initialized
INFO - 2025-05-03 14:39:45 --> Output Class Initialized
INFO - 2025-05-03 14:39:45 --> Security Class Initialized
DEBUG - 2025-05-03 14:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:39:45 --> Input Class Initialized
INFO - 2025-05-03 14:39:45 --> Language Class Initialized
INFO - 2025-05-03 14:39:45 --> Loader Class Initialized
INFO - 2025-05-03 14:39:45 --> Helper loaded: url_helper
INFO - 2025-05-03 14:39:45 --> Helper loaded: string_helper
INFO - 2025-05-03 14:39:45 --> Helper loaded: form_helper
INFO - 2025-05-03 14:39:45 --> Helper loaded: file_helper
INFO - 2025-05-03 14:39:45 --> Helper loaded: html_helper
INFO - 2025-05-03 14:39:45 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:39:45 --> Controller Class Initialized
INFO - 2025-05-03 22:39:45 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:40:18 --> Config Class Initialized
INFO - 2025-05-03 14:40:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:40:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:40:18 --> Utf8 Class Initialized
INFO - 2025-05-03 14:40:18 --> URI Class Initialized
INFO - 2025-05-03 14:40:18 --> Router Class Initialized
INFO - 2025-05-03 14:40:18 --> Output Class Initialized
INFO - 2025-05-03 14:40:18 --> Security Class Initialized
DEBUG - 2025-05-03 14:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:40:18 --> Input Class Initialized
INFO - 2025-05-03 14:40:18 --> Language Class Initialized
INFO - 2025-05-03 14:40:18 --> Loader Class Initialized
INFO - 2025-05-03 14:40:18 --> Helper loaded: url_helper
INFO - 2025-05-03 14:40:18 --> Helper loaded: string_helper
INFO - 2025-05-03 14:40:18 --> Helper loaded: form_helper
INFO - 2025-05-03 14:40:18 --> Helper loaded: file_helper
INFO - 2025-05-03 14:40:18 --> Helper loaded: html_helper
INFO - 2025-05-03 14:40:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:40:18 --> Controller Class Initialized
INFO - 2025-05-03 14:40:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:40:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:40:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:40:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:40:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:40:18 --> Final output sent to browser
DEBUG - 2025-05-03 14:40:18 --> Total execution time: 0.1870
INFO - 2025-05-03 14:40:20 --> Config Class Initialized
INFO - 2025-05-03 14:40:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:40:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:40:20 --> Utf8 Class Initialized
INFO - 2025-05-03 14:40:20 --> URI Class Initialized
INFO - 2025-05-03 14:40:20 --> Router Class Initialized
INFO - 2025-05-03 14:40:20 --> Output Class Initialized
INFO - 2025-05-03 14:40:20 --> Security Class Initialized
DEBUG - 2025-05-03 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:40:20 --> Input Class Initialized
INFO - 2025-05-03 14:40:20 --> Language Class Initialized
INFO - 2025-05-03 14:40:20 --> Loader Class Initialized
INFO - 2025-05-03 14:40:20 --> Helper loaded: url_helper
INFO - 2025-05-03 14:40:20 --> Helper loaded: string_helper
INFO - 2025-05-03 14:40:20 --> Helper loaded: form_helper
INFO - 2025-05-03 14:40:20 --> Helper loaded: file_helper
INFO - 2025-05-03 14:40:20 --> Helper loaded: html_helper
INFO - 2025-05-03 14:40:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:40:20 --> Controller Class Initialized
INFO - 2025-05-03 22:40:20 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:40:20 --> Final output sent to browser
DEBUG - 2025-05-03 22:40:20 --> Total execution time: 0.2012
INFO - 2025-05-03 14:40:21 --> Config Class Initialized
INFO - 2025-05-03 14:40:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:40:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:40:21 --> Utf8 Class Initialized
INFO - 2025-05-03 14:40:21 --> URI Class Initialized
INFO - 2025-05-03 14:40:21 --> Router Class Initialized
INFO - 2025-05-03 14:40:21 --> Output Class Initialized
INFO - 2025-05-03 14:40:21 --> Security Class Initialized
DEBUG - 2025-05-03 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:40:21 --> Input Class Initialized
INFO - 2025-05-03 14:40:21 --> Language Class Initialized
INFO - 2025-05-03 14:40:21 --> Loader Class Initialized
INFO - 2025-05-03 14:40:21 --> Helper loaded: url_helper
INFO - 2025-05-03 14:40:21 --> Helper loaded: string_helper
INFO - 2025-05-03 14:40:21 --> Helper loaded: form_helper
INFO - 2025-05-03 14:40:21 --> Helper loaded: file_helper
INFO - 2025-05-03 14:40:21 --> Helper loaded: html_helper
INFO - 2025-05-03 14:40:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:40:21 --> Controller Class Initialized
INFO - 2025-05-03 22:40:21 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:41:04 --> Config Class Initialized
INFO - 2025-05-03 14:41:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:41:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:41:04 --> Utf8 Class Initialized
INFO - 2025-05-03 14:41:04 --> URI Class Initialized
INFO - 2025-05-03 14:41:04 --> Router Class Initialized
INFO - 2025-05-03 14:41:04 --> Output Class Initialized
INFO - 2025-05-03 14:41:04 --> Security Class Initialized
DEBUG - 2025-05-03 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:41:04 --> Input Class Initialized
INFO - 2025-05-03 14:41:04 --> Language Class Initialized
INFO - 2025-05-03 14:41:05 --> Loader Class Initialized
INFO - 2025-05-03 14:41:05 --> Helper loaded: url_helper
INFO - 2025-05-03 14:41:05 --> Helper loaded: string_helper
INFO - 2025-05-03 14:41:05 --> Helper loaded: form_helper
INFO - 2025-05-03 14:41:05 --> Helper loaded: file_helper
INFO - 2025-05-03 14:41:05 --> Helper loaded: html_helper
INFO - 2025-05-03 14:41:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:41:05 --> Controller Class Initialized
INFO - 2025-05-03 22:41:05 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:41:05 --> Final output sent to browser
DEBUG - 2025-05-03 22:41:05 --> Total execution time: 0.2066
INFO - 2025-05-03 14:41:15 --> Config Class Initialized
INFO - 2025-05-03 14:41:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:41:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:41:15 --> Utf8 Class Initialized
INFO - 2025-05-03 14:41:15 --> URI Class Initialized
INFO - 2025-05-03 14:41:15 --> Router Class Initialized
INFO - 2025-05-03 14:41:15 --> Output Class Initialized
INFO - 2025-05-03 14:41:15 --> Security Class Initialized
DEBUG - 2025-05-03 14:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:41:15 --> Input Class Initialized
INFO - 2025-05-03 14:41:15 --> Language Class Initialized
INFO - 2025-05-03 14:41:15 --> Loader Class Initialized
INFO - 2025-05-03 14:41:15 --> Helper loaded: url_helper
INFO - 2025-05-03 14:41:15 --> Helper loaded: string_helper
INFO - 2025-05-03 14:41:15 --> Helper loaded: form_helper
INFO - 2025-05-03 14:41:15 --> Helper loaded: file_helper
INFO - 2025-05-03 14:41:15 --> Helper loaded: html_helper
INFO - 2025-05-03 14:41:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:41:15 --> Controller Class Initialized
INFO - 2025-05-03 22:41:15 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:41:33 --> Config Class Initialized
INFO - 2025-05-03 14:41:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:41:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:41:33 --> Utf8 Class Initialized
INFO - 2025-05-03 14:41:33 --> URI Class Initialized
INFO - 2025-05-03 14:41:33 --> Router Class Initialized
INFO - 2025-05-03 14:41:33 --> Output Class Initialized
INFO - 2025-05-03 14:41:33 --> Security Class Initialized
DEBUG - 2025-05-03 14:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:41:33 --> Input Class Initialized
INFO - 2025-05-03 14:41:33 --> Language Class Initialized
INFO - 2025-05-03 14:41:33 --> Loader Class Initialized
INFO - 2025-05-03 14:41:33 --> Helper loaded: url_helper
INFO - 2025-05-03 14:41:33 --> Helper loaded: string_helper
INFO - 2025-05-03 14:41:33 --> Helper loaded: form_helper
INFO - 2025-05-03 14:41:33 --> Helper loaded: file_helper
INFO - 2025-05-03 14:41:33 --> Helper loaded: html_helper
INFO - 2025-05-03 14:41:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:41:33 --> Controller Class Initialized
INFO - 2025-05-03 22:41:33 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:41:33 --> Final output sent to browser
DEBUG - 2025-05-03 22:41:33 --> Total execution time: 0.5149
INFO - 2025-05-03 14:41:57 --> Config Class Initialized
INFO - 2025-05-03 14:41:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:41:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:41:57 --> Utf8 Class Initialized
INFO - 2025-05-03 14:41:57 --> URI Class Initialized
INFO - 2025-05-03 14:41:57 --> Router Class Initialized
INFO - 2025-05-03 14:41:57 --> Output Class Initialized
INFO - 2025-05-03 14:41:57 --> Security Class Initialized
DEBUG - 2025-05-03 14:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:41:57 --> Input Class Initialized
INFO - 2025-05-03 14:41:57 --> Language Class Initialized
INFO - 2025-05-03 14:41:57 --> Loader Class Initialized
INFO - 2025-05-03 14:41:57 --> Helper loaded: url_helper
INFO - 2025-05-03 14:41:57 --> Helper loaded: string_helper
INFO - 2025-05-03 14:41:57 --> Helper loaded: form_helper
INFO - 2025-05-03 14:41:57 --> Helper loaded: file_helper
INFO - 2025-05-03 14:41:57 --> Helper loaded: html_helper
INFO - 2025-05-03 14:41:57 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:41:57 --> Controller Class Initialized
INFO - 2025-05-03 22:41:57 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:42:26 --> Config Class Initialized
INFO - 2025-05-03 14:42:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:42:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:42:26 --> Utf8 Class Initialized
INFO - 2025-05-03 14:42:26 --> URI Class Initialized
INFO - 2025-05-03 14:42:26 --> Router Class Initialized
INFO - 2025-05-03 14:42:26 --> Output Class Initialized
INFO - 2025-05-03 14:42:26 --> Security Class Initialized
DEBUG - 2025-05-03 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:42:26 --> Input Class Initialized
INFO - 2025-05-03 14:42:26 --> Language Class Initialized
INFO - 2025-05-03 14:42:26 --> Loader Class Initialized
INFO - 2025-05-03 14:42:26 --> Helper loaded: url_helper
INFO - 2025-05-03 14:42:26 --> Helper loaded: string_helper
INFO - 2025-05-03 14:42:26 --> Helper loaded: form_helper
INFO - 2025-05-03 14:42:26 --> Helper loaded: file_helper
INFO - 2025-05-03 14:42:26 --> Helper loaded: html_helper
INFO - 2025-05-03 14:42:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:42:26 --> Controller Class Initialized
INFO - 2025-05-03 22:42:26 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:42:26 --> Final output sent to browser
DEBUG - 2025-05-03 22:42:26 --> Total execution time: 0.1152
INFO - 2025-05-03 14:42:35 --> Config Class Initialized
INFO - 2025-05-03 14:42:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:42:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:42:35 --> Utf8 Class Initialized
INFO - 2025-05-03 14:42:35 --> URI Class Initialized
INFO - 2025-05-03 14:42:35 --> Router Class Initialized
INFO - 2025-05-03 14:42:35 --> Output Class Initialized
INFO - 2025-05-03 14:42:35 --> Security Class Initialized
DEBUG - 2025-05-03 14:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:42:35 --> Input Class Initialized
INFO - 2025-05-03 14:42:35 --> Language Class Initialized
INFO - 2025-05-03 14:42:35 --> Loader Class Initialized
INFO - 2025-05-03 14:42:35 --> Helper loaded: url_helper
INFO - 2025-05-03 14:42:35 --> Helper loaded: string_helper
INFO - 2025-05-03 14:42:35 --> Helper loaded: form_helper
INFO - 2025-05-03 14:42:35 --> Helper loaded: file_helper
INFO - 2025-05-03 14:42:35 --> Helper loaded: html_helper
INFO - 2025-05-03 14:42:35 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:42:35 --> Controller Class Initialized
INFO - 2025-05-03 22:42:35 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:52:01 --> Config Class Initialized
INFO - 2025-05-03 14:52:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:01 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:01 --> URI Class Initialized
INFO - 2025-05-03 14:52:01 --> Router Class Initialized
INFO - 2025-05-03 14:52:01 --> Output Class Initialized
INFO - 2025-05-03 14:52:01 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:01 --> Input Class Initialized
INFO - 2025-05-03 14:52:01 --> Language Class Initialized
INFO - 2025-05-03 14:52:01 --> Loader Class Initialized
INFO - 2025-05-03 14:52:01 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:01 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:01 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:01 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:01 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:01 --> Controller Class Initialized
INFO - 2025-05-03 14:52:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:52:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:52:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/payment.php
INFO - 2025-05-03 14:52:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:52:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:52:01 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:01 --> Total execution time: 0.4860
INFO - 2025-05-03 14:52:04 --> Config Class Initialized
INFO - 2025-05-03 14:52:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:04 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:04 --> URI Class Initialized
INFO - 2025-05-03 14:52:04 --> Router Class Initialized
INFO - 2025-05-03 14:52:04 --> Output Class Initialized
INFO - 2025-05-03 14:52:04 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:04 --> Input Class Initialized
INFO - 2025-05-03 14:52:04 --> Language Class Initialized
INFO - 2025-05-03 14:52:04 --> Loader Class Initialized
INFO - 2025-05-03 14:52:04 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:04 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:04 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:04 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:04 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:04 --> Controller Class Initialized
INFO - 2025-05-03 22:52:04 --> Model "UserModel" initialized
INFO - 2025-05-03 22:52:20 --> Final output sent to browser
DEBUG - 2025-05-03 22:52:20 --> Total execution time: 16.0329
INFO - 2025-05-03 14:52:30 --> Config Class Initialized
INFO - 2025-05-03 14:52:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:30 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:30 --> URI Class Initialized
INFO - 2025-05-03 14:52:30 --> Router Class Initialized
INFO - 2025-05-03 14:52:30 --> Output Class Initialized
INFO - 2025-05-03 14:52:30 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:30 --> Input Class Initialized
INFO - 2025-05-03 14:52:30 --> Language Class Initialized
INFO - 2025-05-03 14:52:30 --> Loader Class Initialized
INFO - 2025-05-03 14:52:30 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:30 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:30 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:30 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:30 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:30 --> Controller Class Initialized
INFO - 2025-05-03 14:52:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:52:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:52:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/payment.php
INFO - 2025-05-03 14:52:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:52:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:52:30 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:30 --> Total execution time: 0.1029
INFO - 2025-05-03 14:52:36 --> Config Class Initialized
INFO - 2025-05-03 14:52:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:36 --> URI Class Initialized
INFO - 2025-05-03 14:52:36 --> Router Class Initialized
INFO - 2025-05-03 14:52:36 --> Output Class Initialized
INFO - 2025-05-03 14:52:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:36 --> Input Class Initialized
INFO - 2025-05-03 14:52:36 --> Language Class Initialized
INFO - 2025-05-03 14:52:36 --> Loader Class Initialized
INFO - 2025-05-03 14:52:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:36 --> Controller Class Initialized
INFO - 2025-05-03 22:52:36 --> Model "UserModel" initialized
INFO - 2025-05-03 22:52:38 --> Final output sent to browser
DEBUG - 2025-05-03 22:52:38 --> Total execution time: 2.2973
INFO - 2025-05-03 14:52:48 --> Config Class Initialized
INFO - 2025-05-03 14:52:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:48 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:48 --> URI Class Initialized
INFO - 2025-05-03 14:52:48 --> Router Class Initialized
INFO - 2025-05-03 14:52:48 --> Output Class Initialized
INFO - 2025-05-03 14:52:48 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:48 --> Input Class Initialized
INFO - 2025-05-03 14:52:48 --> Language Class Initialized
INFO - 2025-05-03 14:52:48 --> Loader Class Initialized
INFO - 2025-05-03 14:52:48 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:48 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:48 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:48 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:48 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:48 --> Controller Class Initialized
INFO - 2025-05-03 14:52:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:52:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:52:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:52:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:52:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:52:48 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:48 --> Total execution time: 0.1333
INFO - 2025-05-03 14:52:53 --> Config Class Initialized
INFO - 2025-05-03 14:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:53 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:53 --> URI Class Initialized
INFO - 2025-05-03 14:52:53 --> Router Class Initialized
INFO - 2025-05-03 14:52:53 --> Output Class Initialized
INFO - 2025-05-03 14:52:53 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:53 --> Input Class Initialized
INFO - 2025-05-03 14:52:53 --> Language Class Initialized
INFO - 2025-05-03 14:52:53 --> Loader Class Initialized
INFO - 2025-05-03 14:52:53 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:53 --> Helper loaded: string_helper
INFO - 2025-05-03 14:52:53 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:53 --> Helper loaded: file_helper
INFO - 2025-05-03 14:52:53 --> Helper loaded: html_helper
INFO - 2025-05-03 14:52:53 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:53 --> Controller Class Initialized
INFO - 2025-05-03 22:52:53 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:52:53 --> Final output sent to browser
DEBUG - 2025-05-03 22:52:53 --> Total execution time: 0.1894
INFO - 2025-05-03 14:54:01 --> Config Class Initialized
INFO - 2025-05-03 14:54:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:54:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:54:01 --> Utf8 Class Initialized
INFO - 2025-05-03 14:54:01 --> URI Class Initialized
INFO - 2025-05-03 14:54:01 --> Router Class Initialized
INFO - 2025-05-03 14:54:01 --> Output Class Initialized
INFO - 2025-05-03 14:54:01 --> Security Class Initialized
DEBUG - 2025-05-03 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:54:01 --> Input Class Initialized
INFO - 2025-05-03 14:54:01 --> Language Class Initialized
INFO - 2025-05-03 14:54:01 --> Loader Class Initialized
INFO - 2025-05-03 14:54:01 --> Helper loaded: url_helper
INFO - 2025-05-03 14:54:01 --> Helper loaded: string_helper
INFO - 2025-05-03 14:54:01 --> Helper loaded: form_helper
INFO - 2025-05-03 14:54:01 --> Helper loaded: file_helper
INFO - 2025-05-03 14:54:01 --> Helper loaded: html_helper
INFO - 2025-05-03 14:54:01 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:54:01 --> Controller Class Initialized
INFO - 2025-05-03 22:54:01 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:55:31 --> Config Class Initialized
INFO - 2025-05-03 14:55:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:31 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:31 --> URI Class Initialized
INFO - 2025-05-03 14:55:31 --> Router Class Initialized
INFO - 2025-05-03 14:55:31 --> Output Class Initialized
INFO - 2025-05-03 14:55:31 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:31 --> Input Class Initialized
INFO - 2025-05-03 14:55:31 --> Language Class Initialized
INFO - 2025-05-03 14:55:31 --> Loader Class Initialized
INFO - 2025-05-03 14:55:31 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:31 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:31 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:31 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:31 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:31 --> Controller Class Initialized
INFO - 2025-05-03 22:55:31 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:55:31 --> Final output sent to browser
DEBUG - 2025-05-03 22:55:31 --> Total execution time: 0.6900
INFO - 2025-05-03 14:55:32 --> Config Class Initialized
INFO - 2025-05-03 14:55:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:32 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:32 --> URI Class Initialized
INFO - 2025-05-03 14:55:32 --> Router Class Initialized
INFO - 2025-05-03 14:55:32 --> Output Class Initialized
INFO - 2025-05-03 14:55:32 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:32 --> Input Class Initialized
INFO - 2025-05-03 14:55:32 --> Language Class Initialized
INFO - 2025-05-03 14:55:32 --> Loader Class Initialized
INFO - 2025-05-03 14:55:32 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:32 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:32 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:32 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:32 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:32 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:32 --> Controller Class Initialized
INFO - 2025-05-03 22:55:32 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:55:32 --> Final output sent to browser
DEBUG - 2025-05-03 22:55:32 --> Total execution time: 0.1604
INFO - 2025-05-03 14:55:33 --> Config Class Initialized
INFO - 2025-05-03 14:55:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:33 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:33 --> URI Class Initialized
INFO - 2025-05-03 14:55:33 --> Router Class Initialized
INFO - 2025-05-03 14:55:33 --> Output Class Initialized
INFO - 2025-05-03 14:55:33 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:33 --> Input Class Initialized
INFO - 2025-05-03 14:55:33 --> Language Class Initialized
INFO - 2025-05-03 14:55:33 --> Loader Class Initialized
INFO - 2025-05-03 14:55:33 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:33 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:33 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:33 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:33 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:33 --> Controller Class Initialized
INFO - 2025-05-03 22:55:33 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:55:36 --> Config Class Initialized
INFO - 2025-05-03 14:55:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:36 --> URI Class Initialized
INFO - 2025-05-03 14:55:36 --> Router Class Initialized
INFO - 2025-05-03 14:55:36 --> Output Class Initialized
INFO - 2025-05-03 14:55:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:36 --> Input Class Initialized
INFO - 2025-05-03 14:55:36 --> Language Class Initialized
INFO - 2025-05-03 14:55:36 --> Loader Class Initialized
INFO - 2025-05-03 14:55:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:36 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:36 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:36 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:36 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:36 --> Controller Class Initialized
INFO - 2025-05-03 22:55:36 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:55:37 --> Config Class Initialized
INFO - 2025-05-03 14:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:37 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:37 --> URI Class Initialized
INFO - 2025-05-03 14:55:37 --> Router Class Initialized
INFO - 2025-05-03 14:55:37 --> Output Class Initialized
INFO - 2025-05-03 14:55:37 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:37 --> Input Class Initialized
INFO - 2025-05-03 14:55:37 --> Language Class Initialized
INFO - 2025-05-03 14:55:37 --> Loader Class Initialized
INFO - 2025-05-03 14:55:37 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:37 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:37 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:37 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:37 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:37 --> Controller Class Initialized
INFO - 2025-05-03 22:55:37 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:55:37 --> Final output sent to browser
DEBUG - 2025-05-03 22:55:37 --> Total execution time: 0.1505
INFO - 2025-05-03 14:55:38 --> Config Class Initialized
INFO - 2025-05-03 14:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:55:38 --> Utf8 Class Initialized
INFO - 2025-05-03 14:55:38 --> URI Class Initialized
INFO - 2025-05-03 14:55:38 --> Router Class Initialized
INFO - 2025-05-03 14:55:38 --> Output Class Initialized
INFO - 2025-05-03 14:55:38 --> Security Class Initialized
DEBUG - 2025-05-03 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:55:38 --> Input Class Initialized
INFO - 2025-05-03 14:55:38 --> Language Class Initialized
INFO - 2025-05-03 14:55:38 --> Loader Class Initialized
INFO - 2025-05-03 14:55:38 --> Helper loaded: url_helper
INFO - 2025-05-03 14:55:38 --> Helper loaded: string_helper
INFO - 2025-05-03 14:55:38 --> Helper loaded: form_helper
INFO - 2025-05-03 14:55:38 --> Helper loaded: file_helper
INFO - 2025-05-03 14:55:38 --> Helper loaded: html_helper
INFO - 2025-05-03 14:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:55:38 --> Controller Class Initialized
INFO - 2025-05-03 22:55:38 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:56:51 --> Config Class Initialized
INFO - 2025-05-03 14:56:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:56:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:56:51 --> Utf8 Class Initialized
INFO - 2025-05-03 14:56:51 --> URI Class Initialized
INFO - 2025-05-03 14:56:51 --> Router Class Initialized
INFO - 2025-05-03 14:56:51 --> Output Class Initialized
INFO - 2025-05-03 14:56:51 --> Security Class Initialized
DEBUG - 2025-05-03 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:56:51 --> Input Class Initialized
INFO - 2025-05-03 14:56:51 --> Language Class Initialized
INFO - 2025-05-03 14:56:51 --> Loader Class Initialized
INFO - 2025-05-03 14:56:51 --> Helper loaded: url_helper
INFO - 2025-05-03 14:56:51 --> Helper loaded: string_helper
INFO - 2025-05-03 14:56:51 --> Helper loaded: form_helper
INFO - 2025-05-03 14:56:51 --> Helper loaded: file_helper
INFO - 2025-05-03 14:56:51 --> Helper loaded: html_helper
INFO - 2025-05-03 14:56:51 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:56:51 --> Controller Class Initialized
INFO - 2025-05-03 22:56:51 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:57:11 --> Config Class Initialized
INFO - 2025-05-03 14:57:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:57:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:57:11 --> Utf8 Class Initialized
INFO - 2025-05-03 14:57:11 --> URI Class Initialized
INFO - 2025-05-03 14:57:11 --> Router Class Initialized
INFO - 2025-05-03 14:57:11 --> Output Class Initialized
INFO - 2025-05-03 14:57:11 --> Security Class Initialized
DEBUG - 2025-05-03 14:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:57:11 --> Input Class Initialized
INFO - 2025-05-03 14:57:11 --> Language Class Initialized
INFO - 2025-05-03 14:57:11 --> Loader Class Initialized
INFO - 2025-05-03 14:57:11 --> Helper loaded: url_helper
INFO - 2025-05-03 14:57:11 --> Helper loaded: string_helper
INFO - 2025-05-03 14:57:11 --> Helper loaded: form_helper
INFO - 2025-05-03 14:57:11 --> Helper loaded: file_helper
INFO - 2025-05-03 14:57:11 --> Helper loaded: html_helper
INFO - 2025-05-03 14:57:11 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:57:11 --> Controller Class Initialized
INFO - 2025-05-03 22:57:11 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:57:11 --> Final output sent to browser
DEBUG - 2025-05-03 22:57:11 --> Total execution time: 0.1439
INFO - 2025-05-03 14:57:12 --> Config Class Initialized
INFO - 2025-05-03 14:57:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:57:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:57:12 --> Utf8 Class Initialized
INFO - 2025-05-03 14:57:12 --> URI Class Initialized
INFO - 2025-05-03 14:57:12 --> Router Class Initialized
INFO - 2025-05-03 14:57:12 --> Output Class Initialized
INFO - 2025-05-03 14:57:12 --> Security Class Initialized
DEBUG - 2025-05-03 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:57:12 --> Input Class Initialized
INFO - 2025-05-03 14:57:12 --> Language Class Initialized
INFO - 2025-05-03 14:57:12 --> Loader Class Initialized
INFO - 2025-05-03 14:57:12 --> Helper loaded: url_helper
INFO - 2025-05-03 14:57:12 --> Helper loaded: string_helper
INFO - 2025-05-03 14:57:12 --> Helper loaded: form_helper
INFO - 2025-05-03 14:57:12 --> Helper loaded: file_helper
INFO - 2025-05-03 14:57:12 --> Helper loaded: html_helper
INFO - 2025-05-03 14:57:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:57:12 --> Controller Class Initialized
INFO - 2025-05-03 22:57:12 --> Model "AuctionModel" initialized
INFO - 2025-05-03 22:57:12 --> Final output sent to browser
DEBUG - 2025-05-03 22:57:12 --> Total execution time: 0.1905
INFO - 2025-05-03 14:57:15 --> Config Class Initialized
INFO - 2025-05-03 14:57:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:57:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:57:15 --> Utf8 Class Initialized
INFO - 2025-05-03 14:57:15 --> URI Class Initialized
INFO - 2025-05-03 14:57:15 --> Router Class Initialized
INFO - 2025-05-03 14:57:15 --> Output Class Initialized
INFO - 2025-05-03 14:57:15 --> Security Class Initialized
DEBUG - 2025-05-03 14:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:57:15 --> Input Class Initialized
INFO - 2025-05-03 14:57:15 --> Language Class Initialized
INFO - 2025-05-03 14:57:15 --> Loader Class Initialized
INFO - 2025-05-03 14:57:15 --> Helper loaded: url_helper
INFO - 2025-05-03 14:57:15 --> Helper loaded: string_helper
INFO - 2025-05-03 14:57:15 --> Helper loaded: form_helper
INFO - 2025-05-03 14:57:15 --> Helper loaded: file_helper
INFO - 2025-05-03 14:57:15 --> Helper loaded: html_helper
INFO - 2025-05-03 14:57:15 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:57:15 --> Controller Class Initialized
INFO - 2025-05-03 22:57:15 --> Model "AuctionModel" initialized
INFO - 2025-05-03 14:59:55 --> Config Class Initialized
INFO - 2025-05-03 14:59:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:59:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:59:55 --> Utf8 Class Initialized
INFO - 2025-05-03 14:59:55 --> URI Class Initialized
INFO - 2025-05-03 14:59:55 --> Router Class Initialized
INFO - 2025-05-03 14:59:55 --> Output Class Initialized
INFO - 2025-05-03 14:59:55 --> Security Class Initialized
DEBUG - 2025-05-03 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:59:55 --> Input Class Initialized
INFO - 2025-05-03 14:59:55 --> Language Class Initialized
INFO - 2025-05-03 14:59:55 --> Loader Class Initialized
INFO - 2025-05-03 14:59:55 --> Helper loaded: url_helper
INFO - 2025-05-03 14:59:55 --> Helper loaded: string_helper
INFO - 2025-05-03 14:59:55 --> Helper loaded: form_helper
INFO - 2025-05-03 14:59:55 --> Helper loaded: file_helper
INFO - 2025-05-03 14:59:55 --> Helper loaded: html_helper
INFO - 2025-05-03 14:59:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 14:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:59:55 --> Controller Class Initialized
INFO - 2025-05-03 14:59:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 14:59:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 14:59:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 14:59:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 14:59:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 14:59:55 --> Final output sent to browser
DEBUG - 2025-05-03 14:59:55 --> Total execution time: 0.2902
INFO - 2025-05-03 15:00:02 --> Config Class Initialized
INFO - 2025-05-03 15:00:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:00:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:00:02 --> Utf8 Class Initialized
INFO - 2025-05-03 15:00:02 --> URI Class Initialized
INFO - 2025-05-03 15:00:02 --> Router Class Initialized
INFO - 2025-05-03 15:00:02 --> Output Class Initialized
INFO - 2025-05-03 15:00:02 --> Security Class Initialized
DEBUG - 2025-05-03 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:00:02 --> Input Class Initialized
INFO - 2025-05-03 15:00:02 --> Language Class Initialized
INFO - 2025-05-03 15:00:02 --> Loader Class Initialized
INFO - 2025-05-03 15:00:02 --> Helper loaded: url_helper
INFO - 2025-05-03 15:00:02 --> Helper loaded: string_helper
INFO - 2025-05-03 15:00:02 --> Helper loaded: form_helper
INFO - 2025-05-03 15:00:02 --> Helper loaded: file_helper
INFO - 2025-05-03 15:00:02 --> Helper loaded: html_helper
INFO - 2025-05-03 15:00:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:00:02 --> Controller Class Initialized
INFO - 2025-05-03 23:00:02 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:00:02 --> Final output sent to browser
DEBUG - 2025-05-03 23:00:02 --> Total execution time: 0.2433
INFO - 2025-05-03 15:00:04 --> Config Class Initialized
INFO - 2025-05-03 15:00:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:00:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:00:04 --> Utf8 Class Initialized
INFO - 2025-05-03 15:00:04 --> URI Class Initialized
INFO - 2025-05-03 15:00:04 --> Router Class Initialized
INFO - 2025-05-03 15:00:04 --> Output Class Initialized
INFO - 2025-05-03 15:00:04 --> Security Class Initialized
DEBUG - 2025-05-03 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:00:04 --> Input Class Initialized
INFO - 2025-05-03 15:00:04 --> Language Class Initialized
INFO - 2025-05-03 15:00:04 --> Loader Class Initialized
INFO - 2025-05-03 15:00:04 --> Helper loaded: url_helper
INFO - 2025-05-03 15:00:04 --> Helper loaded: string_helper
INFO - 2025-05-03 15:00:04 --> Helper loaded: form_helper
INFO - 2025-05-03 15:00:04 --> Helper loaded: file_helper
INFO - 2025-05-03 15:00:04 --> Helper loaded: html_helper
INFO - 2025-05-03 15:00:04 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:00:04 --> Controller Class Initialized
INFO - 2025-05-03 23:00:04 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:00:48 --> Config Class Initialized
INFO - 2025-05-03 15:00:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:00:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:00:48 --> Utf8 Class Initialized
INFO - 2025-05-03 15:00:48 --> URI Class Initialized
INFO - 2025-05-03 15:00:48 --> Router Class Initialized
INFO - 2025-05-03 15:00:48 --> Output Class Initialized
INFO - 2025-05-03 15:00:48 --> Security Class Initialized
DEBUG - 2025-05-03 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:00:48 --> Input Class Initialized
INFO - 2025-05-03 15:00:48 --> Language Class Initialized
INFO - 2025-05-03 15:00:48 --> Loader Class Initialized
INFO - 2025-05-03 15:00:48 --> Helper loaded: url_helper
INFO - 2025-05-03 15:00:48 --> Helper loaded: string_helper
INFO - 2025-05-03 15:00:48 --> Helper loaded: form_helper
INFO - 2025-05-03 15:00:48 --> Helper loaded: file_helper
INFO - 2025-05-03 15:00:48 --> Helper loaded: html_helper
INFO - 2025-05-03 15:00:48 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:00:48 --> Controller Class Initialized
INFO - 2025-05-03 15:00:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:00:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:00:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 15:00:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:00:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:00:48 --> Final output sent to browser
DEBUG - 2025-05-03 15:00:48 --> Total execution time: 0.1029
INFO - 2025-05-03 15:00:54 --> Config Class Initialized
INFO - 2025-05-03 15:00:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:00:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:00:54 --> Utf8 Class Initialized
INFO - 2025-05-03 15:00:54 --> URI Class Initialized
INFO - 2025-05-03 15:00:54 --> Router Class Initialized
INFO - 2025-05-03 15:00:54 --> Output Class Initialized
INFO - 2025-05-03 15:00:54 --> Security Class Initialized
DEBUG - 2025-05-03 15:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:00:54 --> Input Class Initialized
INFO - 2025-05-03 15:00:54 --> Language Class Initialized
INFO - 2025-05-03 15:00:54 --> Loader Class Initialized
INFO - 2025-05-03 15:00:54 --> Helper loaded: url_helper
INFO - 2025-05-03 15:00:54 --> Helper loaded: string_helper
INFO - 2025-05-03 15:00:54 --> Helper loaded: form_helper
INFO - 2025-05-03 15:00:54 --> Helper loaded: file_helper
INFO - 2025-05-03 15:00:54 --> Helper loaded: html_helper
INFO - 2025-05-03 15:00:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:00:54 --> Controller Class Initialized
INFO - 2025-05-03 23:00:54 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:00:55 --> Final output sent to browser
DEBUG - 2025-05-03 23:00:55 --> Total execution time: 0.4015
INFO - 2025-05-03 15:00:59 --> Config Class Initialized
INFO - 2025-05-03 15:00:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:00:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:00:59 --> Utf8 Class Initialized
INFO - 2025-05-03 15:00:59 --> URI Class Initialized
INFO - 2025-05-03 15:00:59 --> Router Class Initialized
INFO - 2025-05-03 15:00:59 --> Output Class Initialized
INFO - 2025-05-03 15:00:59 --> Security Class Initialized
DEBUG - 2025-05-03 15:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:00:59 --> Input Class Initialized
INFO - 2025-05-03 15:00:59 --> Language Class Initialized
INFO - 2025-05-03 15:00:59 --> Loader Class Initialized
INFO - 2025-05-03 15:00:59 --> Helper loaded: url_helper
INFO - 2025-05-03 15:00:59 --> Helper loaded: string_helper
INFO - 2025-05-03 15:00:59 --> Helper loaded: form_helper
INFO - 2025-05-03 15:00:59 --> Helper loaded: file_helper
INFO - 2025-05-03 15:00:59 --> Helper loaded: html_helper
INFO - 2025-05-03 15:00:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:00:59 --> Controller Class Initialized
INFO - 2025-05-03 23:00:59 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:01:27 --> Config Class Initialized
INFO - 2025-05-03 15:01:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:01:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:01:27 --> Utf8 Class Initialized
INFO - 2025-05-03 15:01:27 --> URI Class Initialized
INFO - 2025-05-03 15:01:27 --> Router Class Initialized
INFO - 2025-05-03 15:01:27 --> Output Class Initialized
INFO - 2025-05-03 15:01:27 --> Security Class Initialized
DEBUG - 2025-05-03 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:01:27 --> Input Class Initialized
INFO - 2025-05-03 15:01:27 --> Language Class Initialized
INFO - 2025-05-03 15:01:27 --> Loader Class Initialized
INFO - 2025-05-03 15:01:27 --> Helper loaded: url_helper
INFO - 2025-05-03 15:01:27 --> Helper loaded: string_helper
INFO - 2025-05-03 15:01:27 --> Helper loaded: form_helper
INFO - 2025-05-03 15:01:27 --> Helper loaded: file_helper
INFO - 2025-05-03 15:01:27 --> Helper loaded: html_helper
INFO - 2025-05-03 15:01:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:01:27 --> Controller Class Initialized
INFO - 2025-05-03 15:01:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:01:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:01:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 15:01:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:01:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:01:27 --> Final output sent to browser
DEBUG - 2025-05-03 15:01:27 --> Total execution time: 0.1760
INFO - 2025-05-03 15:01:30 --> Config Class Initialized
INFO - 2025-05-03 15:01:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:01:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:01:30 --> Utf8 Class Initialized
INFO - 2025-05-03 15:01:30 --> URI Class Initialized
INFO - 2025-05-03 15:01:30 --> Router Class Initialized
INFO - 2025-05-03 15:01:30 --> Output Class Initialized
INFO - 2025-05-03 15:01:30 --> Security Class Initialized
DEBUG - 2025-05-03 15:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:01:30 --> Input Class Initialized
INFO - 2025-05-03 15:01:30 --> Language Class Initialized
INFO - 2025-05-03 15:01:30 --> Loader Class Initialized
INFO - 2025-05-03 15:01:30 --> Helper loaded: url_helper
INFO - 2025-05-03 15:01:30 --> Helper loaded: string_helper
INFO - 2025-05-03 15:01:30 --> Helper loaded: form_helper
INFO - 2025-05-03 15:01:30 --> Helper loaded: file_helper
INFO - 2025-05-03 15:01:30 --> Helper loaded: html_helper
INFO - 2025-05-03 15:01:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:01:30 --> Controller Class Initialized
INFO - 2025-05-03 23:01:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:01:30 --> Final output sent to browser
DEBUG - 2025-05-03 23:01:30 --> Total execution time: 0.1271
INFO - 2025-05-03 15:03:22 --> Config Class Initialized
INFO - 2025-05-03 15:03:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:03:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:03:22 --> Utf8 Class Initialized
INFO - 2025-05-03 15:03:22 --> URI Class Initialized
INFO - 2025-05-03 15:03:22 --> Router Class Initialized
INFO - 2025-05-03 15:03:22 --> Output Class Initialized
INFO - 2025-05-03 15:03:22 --> Security Class Initialized
DEBUG - 2025-05-03 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:03:22 --> Input Class Initialized
INFO - 2025-05-03 15:03:22 --> Language Class Initialized
INFO - 2025-05-03 15:03:22 --> Loader Class Initialized
INFO - 2025-05-03 15:03:22 --> Helper loaded: url_helper
INFO - 2025-05-03 15:03:22 --> Helper loaded: string_helper
INFO - 2025-05-03 15:03:22 --> Helper loaded: form_helper
INFO - 2025-05-03 15:03:22 --> Helper loaded: file_helper
INFO - 2025-05-03 15:03:22 --> Helper loaded: html_helper
INFO - 2025-05-03 15:03:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:03:22 --> Controller Class Initialized
INFO - 2025-05-03 15:03:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:03:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:03:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 15:03:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:03:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:03:22 --> Final output sent to browser
DEBUG - 2025-05-03 15:03:22 --> Total execution time: 0.1223
INFO - 2025-05-03 15:03:25 --> Config Class Initialized
INFO - 2025-05-03 15:03:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:03:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:03:25 --> Utf8 Class Initialized
INFO - 2025-05-03 15:03:25 --> URI Class Initialized
INFO - 2025-05-03 15:03:25 --> Router Class Initialized
INFO - 2025-05-03 15:03:25 --> Output Class Initialized
INFO - 2025-05-03 15:03:25 --> Security Class Initialized
DEBUG - 2025-05-03 15:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:03:25 --> Input Class Initialized
INFO - 2025-05-03 15:03:25 --> Language Class Initialized
INFO - 2025-05-03 15:03:26 --> Loader Class Initialized
INFO - 2025-05-03 15:03:26 --> Helper loaded: url_helper
INFO - 2025-05-03 15:03:26 --> Helper loaded: string_helper
INFO - 2025-05-03 15:03:26 --> Helper loaded: form_helper
INFO - 2025-05-03 15:03:26 --> Helper loaded: file_helper
INFO - 2025-05-03 15:03:26 --> Helper loaded: html_helper
INFO - 2025-05-03 15:03:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:03:26 --> Controller Class Initialized
INFO - 2025-05-03 23:03:26 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:03:26 --> Final output sent to browser
DEBUG - 2025-05-03 23:03:26 --> Total execution time: 0.7883
INFO - 2025-05-03 15:03:27 --> Config Class Initialized
INFO - 2025-05-03 15:03:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:03:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:03:27 --> Utf8 Class Initialized
INFO - 2025-05-03 15:03:27 --> URI Class Initialized
INFO - 2025-05-03 15:03:27 --> Router Class Initialized
INFO - 2025-05-03 15:03:27 --> Output Class Initialized
INFO - 2025-05-03 15:03:27 --> Security Class Initialized
DEBUG - 2025-05-03 15:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:03:27 --> Input Class Initialized
INFO - 2025-05-03 15:03:27 --> Language Class Initialized
INFO - 2025-05-03 15:03:27 --> Loader Class Initialized
INFO - 2025-05-03 15:03:27 --> Helper loaded: url_helper
INFO - 2025-05-03 15:03:27 --> Helper loaded: string_helper
INFO - 2025-05-03 15:03:27 --> Helper loaded: form_helper
INFO - 2025-05-03 15:03:27 --> Helper loaded: file_helper
INFO - 2025-05-03 15:03:27 --> Helper loaded: html_helper
INFO - 2025-05-03 15:03:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:03:27 --> Controller Class Initialized
INFO - 2025-05-03 23:03:27 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:04:01 --> Config Class Initialized
INFO - 2025-05-03 15:04:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:04:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:04:02 --> Utf8 Class Initialized
INFO - 2025-05-03 15:04:02 --> URI Class Initialized
INFO - 2025-05-03 15:04:02 --> Router Class Initialized
INFO - 2025-05-03 15:04:02 --> Output Class Initialized
INFO - 2025-05-03 15:04:02 --> Security Class Initialized
DEBUG - 2025-05-03 15:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:04:02 --> Input Class Initialized
INFO - 2025-05-03 15:04:02 --> Language Class Initialized
INFO - 2025-05-03 15:04:02 --> Loader Class Initialized
INFO - 2025-05-03 15:04:02 --> Helper loaded: url_helper
INFO - 2025-05-03 15:04:02 --> Helper loaded: string_helper
INFO - 2025-05-03 15:04:02 --> Helper loaded: form_helper
INFO - 2025-05-03 15:04:02 --> Helper loaded: file_helper
INFO - 2025-05-03 15:04:02 --> Helper loaded: html_helper
INFO - 2025-05-03 15:04:02 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:04:02 --> Controller Class Initialized
INFO - 2025-05-03 23:04:02 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:04:02 --> Final output sent to browser
DEBUG - 2025-05-03 23:04:02 --> Total execution time: 0.2058
INFO - 2025-05-03 15:04:03 --> Config Class Initialized
INFO - 2025-05-03 15:04:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:04:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:04:03 --> Utf8 Class Initialized
INFO - 2025-05-03 15:04:03 --> URI Class Initialized
INFO - 2025-05-03 15:04:03 --> Router Class Initialized
INFO - 2025-05-03 15:04:03 --> Output Class Initialized
INFO - 2025-05-03 15:04:03 --> Security Class Initialized
DEBUG - 2025-05-03 15:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:04:03 --> Input Class Initialized
INFO - 2025-05-03 15:04:03 --> Language Class Initialized
INFO - 2025-05-03 15:04:03 --> Loader Class Initialized
INFO - 2025-05-03 15:04:03 --> Helper loaded: url_helper
INFO - 2025-05-03 15:04:03 --> Helper loaded: string_helper
INFO - 2025-05-03 15:04:03 --> Helper loaded: form_helper
INFO - 2025-05-03 15:04:03 --> Helper loaded: file_helper
INFO - 2025-05-03 15:04:03 --> Helper loaded: html_helper
INFO - 2025-05-03 15:04:03 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:04:03 --> Controller Class Initialized
INFO - 2025-05-03 23:04:03 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:04:03 --> Final output sent to browser
DEBUG - 2025-05-03 23:04:03 --> Total execution time: 0.1601
INFO - 2025-05-03 15:04:05 --> Config Class Initialized
INFO - 2025-05-03 15:04:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:04:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:04:05 --> Utf8 Class Initialized
INFO - 2025-05-03 15:04:05 --> URI Class Initialized
INFO - 2025-05-03 15:04:05 --> Router Class Initialized
INFO - 2025-05-03 15:04:05 --> Output Class Initialized
INFO - 2025-05-03 15:04:05 --> Security Class Initialized
DEBUG - 2025-05-03 15:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:04:05 --> Input Class Initialized
INFO - 2025-05-03 15:04:05 --> Language Class Initialized
INFO - 2025-05-03 15:04:05 --> Loader Class Initialized
INFO - 2025-05-03 15:04:05 --> Helper loaded: url_helper
INFO - 2025-05-03 15:04:05 --> Helper loaded: string_helper
INFO - 2025-05-03 15:04:05 --> Helper loaded: form_helper
INFO - 2025-05-03 15:04:05 --> Helper loaded: file_helper
INFO - 2025-05-03 15:04:05 --> Helper loaded: html_helper
INFO - 2025-05-03 15:04:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:04:05 --> Controller Class Initialized
INFO - 2025-05-03 23:04:05 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:04:05 --> Final output sent to browser
DEBUG - 2025-05-03 23:04:05 --> Total execution time: 0.1911
INFO - 2025-05-03 15:04:07 --> Config Class Initialized
INFO - 2025-05-03 15:04:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:04:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:04:07 --> Utf8 Class Initialized
INFO - 2025-05-03 15:04:07 --> URI Class Initialized
INFO - 2025-05-03 15:04:07 --> Router Class Initialized
INFO - 2025-05-03 15:04:07 --> Output Class Initialized
INFO - 2025-05-03 15:04:07 --> Security Class Initialized
DEBUG - 2025-05-03 15:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:04:07 --> Input Class Initialized
INFO - 2025-05-03 15:04:07 --> Language Class Initialized
INFO - 2025-05-03 15:04:07 --> Loader Class Initialized
INFO - 2025-05-03 15:04:07 --> Helper loaded: url_helper
INFO - 2025-05-03 15:04:07 --> Helper loaded: string_helper
INFO - 2025-05-03 15:04:07 --> Helper loaded: form_helper
INFO - 2025-05-03 15:04:07 --> Helper loaded: file_helper
INFO - 2025-05-03 15:04:07 --> Helper loaded: html_helper
INFO - 2025-05-03 15:04:07 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:04:07 --> Controller Class Initialized
INFO - 2025-05-03 23:04:07 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:04:34 --> Config Class Initialized
INFO - 2025-05-03 15:04:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:04:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:04:34 --> Utf8 Class Initialized
INFO - 2025-05-03 15:04:34 --> URI Class Initialized
INFO - 2025-05-03 15:04:34 --> Router Class Initialized
INFO - 2025-05-03 15:04:34 --> Output Class Initialized
INFO - 2025-05-03 15:04:34 --> Security Class Initialized
DEBUG - 2025-05-03 15:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:04:34 --> Input Class Initialized
INFO - 2025-05-03 15:04:34 --> Language Class Initialized
INFO - 2025-05-03 15:04:34 --> Loader Class Initialized
INFO - 2025-05-03 15:04:34 --> Helper loaded: url_helper
INFO - 2025-05-03 15:04:34 --> Helper loaded: string_helper
INFO - 2025-05-03 15:04:34 --> Helper loaded: form_helper
INFO - 2025-05-03 15:04:34 --> Helper loaded: file_helper
INFO - 2025-05-03 15:04:34 --> Helper loaded: html_helper
INFO - 2025-05-03 15:04:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:04:34 --> Controller Class Initialized
INFO - 2025-05-03 23:04:34 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:06:06 --> Config Class Initialized
INFO - 2025-05-03 15:06:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:06:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:06:06 --> Utf8 Class Initialized
INFO - 2025-05-03 15:06:06 --> URI Class Initialized
INFO - 2025-05-03 15:06:06 --> Router Class Initialized
INFO - 2025-05-03 15:06:06 --> Output Class Initialized
INFO - 2025-05-03 15:06:06 --> Security Class Initialized
DEBUG - 2025-05-03 15:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:06:06 --> Input Class Initialized
INFO - 2025-05-03 15:06:06 --> Language Class Initialized
INFO - 2025-05-03 15:06:06 --> Loader Class Initialized
INFO - 2025-05-03 15:06:06 --> Helper loaded: url_helper
INFO - 2025-05-03 15:06:06 --> Helper loaded: string_helper
INFO - 2025-05-03 15:06:06 --> Helper loaded: form_helper
INFO - 2025-05-03 15:06:06 --> Helper loaded: file_helper
INFO - 2025-05-03 15:06:06 --> Helper loaded: html_helper
INFO - 2025-05-03 15:06:06 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:06:06 --> Controller Class Initialized
INFO - 2025-05-03 15:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-03 15:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:06:06 --> Final output sent to browser
DEBUG - 2025-05-03 15:06:06 --> Total execution time: 0.1609
INFO - 2025-05-03 15:06:14 --> Config Class Initialized
INFO - 2025-05-03 15:06:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:06:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:06:14 --> Utf8 Class Initialized
INFO - 2025-05-03 15:06:14 --> URI Class Initialized
INFO - 2025-05-03 15:06:14 --> Router Class Initialized
INFO - 2025-05-03 15:06:14 --> Output Class Initialized
INFO - 2025-05-03 15:06:14 --> Security Class Initialized
DEBUG - 2025-05-03 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:06:14 --> Input Class Initialized
INFO - 2025-05-03 15:06:14 --> Language Class Initialized
INFO - 2025-05-03 15:06:14 --> Loader Class Initialized
INFO - 2025-05-03 15:06:14 --> Helper loaded: url_helper
INFO - 2025-05-03 15:06:14 --> Helper loaded: string_helper
INFO - 2025-05-03 15:06:14 --> Helper loaded: form_helper
INFO - 2025-05-03 15:06:14 --> Helper loaded: file_helper
INFO - 2025-05-03 15:06:14 --> Helper loaded: html_helper
INFO - 2025-05-03 15:06:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:06:14 --> Controller Class Initialized
INFO - 2025-05-03 23:06:14 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:06:14 --> Final output sent to browser
DEBUG - 2025-05-03 23:06:14 --> Total execution time: 0.2205
INFO - 2025-05-03 15:06:15 --> Config Class Initialized
INFO - 2025-05-03 15:06:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:06:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:06:15 --> Utf8 Class Initialized
INFO - 2025-05-03 15:06:15 --> URI Class Initialized
INFO - 2025-05-03 15:06:15 --> Router Class Initialized
INFO - 2025-05-03 15:06:15 --> Output Class Initialized
INFO - 2025-05-03 15:06:15 --> Security Class Initialized
DEBUG - 2025-05-03 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:06:15 --> Input Class Initialized
INFO - 2025-05-03 15:06:16 --> Language Class Initialized
INFO - 2025-05-03 15:06:16 --> Loader Class Initialized
INFO - 2025-05-03 15:06:16 --> Helper loaded: url_helper
INFO - 2025-05-03 15:06:16 --> Helper loaded: string_helper
INFO - 2025-05-03 15:06:16 --> Helper loaded: form_helper
INFO - 2025-05-03 15:06:16 --> Helper loaded: file_helper
INFO - 2025-05-03 15:06:16 --> Helper loaded: html_helper
INFO - 2025-05-03 15:06:16 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:06:16 --> Controller Class Initialized
INFO - 2025-05-03 23:06:16 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:06:33 --> Config Class Initialized
INFO - 2025-05-03 15:06:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:06:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:06:33 --> Utf8 Class Initialized
INFO - 2025-05-03 15:06:33 --> URI Class Initialized
INFO - 2025-05-03 15:06:33 --> Router Class Initialized
INFO - 2025-05-03 15:06:33 --> Output Class Initialized
INFO - 2025-05-03 15:06:33 --> Security Class Initialized
DEBUG - 2025-05-03 15:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:06:33 --> Input Class Initialized
INFO - 2025-05-03 15:06:33 --> Language Class Initialized
INFO - 2025-05-03 15:06:33 --> Loader Class Initialized
INFO - 2025-05-03 15:06:33 --> Helper loaded: url_helper
INFO - 2025-05-03 15:06:33 --> Helper loaded: string_helper
INFO - 2025-05-03 15:06:33 --> Helper loaded: form_helper
INFO - 2025-05-03 15:06:33 --> Helper loaded: file_helper
INFO - 2025-05-03 15:06:33 --> Helper loaded: html_helper
INFO - 2025-05-03 15:06:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:06:33 --> Controller Class Initialized
INFO - 2025-05-03 23:06:33 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:06:33 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 23:06:34 --> Final output sent to browser
DEBUG - 2025-05-03 23:06:34 --> Total execution time: 0.3219
INFO - 2025-05-03 15:07:14 --> Config Class Initialized
INFO - 2025-05-03 15:07:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:14 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:14 --> URI Class Initialized
INFO - 2025-05-03 15:07:14 --> Router Class Initialized
INFO - 2025-05-03 15:07:14 --> Output Class Initialized
INFO - 2025-05-03 15:07:14 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:14 --> Input Class Initialized
INFO - 2025-05-03 15:07:14 --> Language Class Initialized
INFO - 2025-05-03 15:07:14 --> Loader Class Initialized
INFO - 2025-05-03 15:07:14 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:14 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:14 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:14 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:14 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:14 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:07:14 --> Controller Class Initialized
INFO - 2025-05-03 23:07:14 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:07:14 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:07:14 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:07:14 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 23:07:14 --> Final output sent to browser
DEBUG - 2025-05-03 23:07:14 --> Total execution time: 0.3272
INFO - 2025-05-03 15:07:16 --> Config Class Initialized
INFO - 2025-05-03 15:07:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:16 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:16 --> URI Class Initialized
INFO - 2025-05-03 15:07:16 --> Router Class Initialized
INFO - 2025-05-03 15:07:16 --> Output Class Initialized
INFO - 2025-05-03 15:07:16 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:16 --> Input Class Initialized
INFO - 2025-05-03 15:07:16 --> Language Class Initialized
INFO - 2025-05-03 15:07:16 --> Loader Class Initialized
INFO - 2025-05-03 15:07:16 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:16 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:16 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:16 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:16 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:16 --> Database Driver Class Initialized
INFO - 2025-05-03 15:07:20 --> Config Class Initialized
INFO - 2025-05-03 15:07:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:20 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:20 --> URI Class Initialized
INFO - 2025-05-03 15:07:21 --> Router Class Initialized
INFO - 2025-05-03 15:07:21 --> Output Class Initialized
INFO - 2025-05-03 15:07:21 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:21 --> Input Class Initialized
INFO - 2025-05-03 15:07:21 --> Language Class Initialized
INFO - 2025-05-03 15:07:21 --> Config Class Initialized
INFO - 2025-05-03 15:07:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:21 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:21 --> URI Class Initialized
INFO - 2025-05-03 15:07:21 --> Loader Class Initialized
INFO - 2025-05-03 15:07:21 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:21 --> Router Class Initialized
INFO - 2025-05-03 15:07:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:07:21 --> Controller Class Initialized
INFO - 2025-05-03 23:07:21 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:07:21 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:07:21 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:07:21 --> Output Class Initialized
INFO - 2025-05-03 23:07:21 --> Final output sent to browser
DEBUG - 2025-05-03 23:07:21 --> Total execution time: 0.5854
INFO - 2025-05-03 15:07:21 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:21 --> Input Class Initialized
INFO - 2025-05-03 15:07:21 --> Language Class Initialized
INFO - 2025-05-03 15:07:21 --> Loader Class Initialized
INFO - 2025-05-03 15:07:21 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:21 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:07:22 --> Controller Class Initialized
INFO - 2025-05-03 23:07:22 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:07:22 --> Final output sent to browser
DEBUG - 2025-05-03 23:07:22 --> Total execution time: 1.2028
INFO - 2025-05-03 15:07:22 --> Config Class Initialized
INFO - 2025-05-03 15:07:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:22 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:22 --> URI Class Initialized
INFO - 2025-05-03 15:07:22 --> Router Class Initialized
INFO - 2025-05-03 15:07:22 --> Output Class Initialized
INFO - 2025-05-03 15:07:22 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:22 --> Input Class Initialized
INFO - 2025-05-03 15:07:22 --> Language Class Initialized
INFO - 2025-05-03 15:07:22 --> Loader Class Initialized
INFO - 2025-05-03 15:07:22 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:22 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:22 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:22 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:22 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:22 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:07:22 --> Controller Class Initialized
INFO - 2025-05-03 15:07:22 --> Model "UserModel" initialized
INFO - 2025-05-03 15:07:22 --> Final output sent to browser
DEBUG - 2025-05-03 15:07:22 --> Total execution time: 0.4944
INFO - 2025-05-03 15:07:34 --> Config Class Initialized
INFO - 2025-05-03 15:07:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:07:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:07:34 --> Utf8 Class Initialized
INFO - 2025-05-03 15:07:34 --> URI Class Initialized
INFO - 2025-05-03 15:07:34 --> Router Class Initialized
INFO - 2025-05-03 15:07:34 --> Output Class Initialized
INFO - 2025-05-03 15:07:34 --> Security Class Initialized
DEBUG - 2025-05-03 15:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:07:34 --> Input Class Initialized
INFO - 2025-05-03 15:07:34 --> Language Class Initialized
INFO - 2025-05-03 15:07:34 --> Loader Class Initialized
INFO - 2025-05-03 15:07:34 --> Helper loaded: url_helper
INFO - 2025-05-03 15:07:34 --> Helper loaded: string_helper
INFO - 2025-05-03 15:07:34 --> Helper loaded: form_helper
INFO - 2025-05-03 15:07:34 --> Helper loaded: file_helper
INFO - 2025-05-03 15:07:34 --> Helper loaded: html_helper
INFO - 2025-05-03 15:07:34 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:07:34 --> Controller Class Initialized
INFO - 2025-05-03 23:07:34 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:07:34 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:07:34 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:07:34 --> Model "InvoiceModel" initialized
INFO - 2025-05-03 23:07:34 --> Final output sent to browser
DEBUG - 2025-05-03 23:07:34 --> Total execution time: 0.3189
INFO - 2025-05-03 15:08:10 --> Config Class Initialized
INFO - 2025-05-03 15:08:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:10 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:10 --> URI Class Initialized
INFO - 2025-05-03 15:08:10 --> Router Class Initialized
INFO - 2025-05-03 15:08:10 --> Output Class Initialized
INFO - 2025-05-03 15:08:10 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:10 --> Input Class Initialized
INFO - 2025-05-03 15:08:10 --> Language Class Initialized
INFO - 2025-05-03 15:08:10 --> Loader Class Initialized
INFO - 2025-05-03 15:08:10 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:10 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:10 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:10 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:10 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:10 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:10 --> Controller Class Initialized
INFO - 2025-05-03 23:08:10 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:10 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:10 --> Total execution time: 0.2715
INFO - 2025-05-03 15:08:12 --> Config Class Initialized
INFO - 2025-05-03 15:08:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:12 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:12 --> URI Class Initialized
INFO - 2025-05-03 15:08:12 --> Router Class Initialized
INFO - 2025-05-03 15:08:12 --> Output Class Initialized
INFO - 2025-05-03 15:08:12 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:12 --> Input Class Initialized
INFO - 2025-05-03 15:08:12 --> Language Class Initialized
INFO - 2025-05-03 15:08:12 --> Loader Class Initialized
INFO - 2025-05-03 15:08:12 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:12 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:12 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:12 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:12 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:12 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:13 --> Controller Class Initialized
INFO - 2025-05-03 23:08:13 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:13 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:13 --> Total execution time: 0.2046
INFO - 2025-05-03 15:08:13 --> Config Class Initialized
INFO - 2025-05-03 15:08:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:13 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:13 --> URI Class Initialized
INFO - 2025-05-03 15:08:13 --> Router Class Initialized
INFO - 2025-05-03 15:08:13 --> Output Class Initialized
INFO - 2025-05-03 15:08:13 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:13 --> Input Class Initialized
INFO - 2025-05-03 15:08:13 --> Language Class Initialized
INFO - 2025-05-03 15:08:13 --> Loader Class Initialized
INFO - 2025-05-03 15:08:13 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:13 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:13 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:13 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:13 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:13 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:13 --> Controller Class Initialized
INFO - 2025-05-03 23:08:13 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:13 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:13 --> Total execution time: 0.2239
INFO - 2025-05-03 15:08:18 --> Config Class Initialized
INFO - 2025-05-03 15:08:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:18 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:18 --> URI Class Initialized
INFO - 2025-05-03 15:08:18 --> Router Class Initialized
INFO - 2025-05-03 15:08:18 --> Output Class Initialized
INFO - 2025-05-03 15:08:18 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:18 --> Input Class Initialized
INFO - 2025-05-03 15:08:18 --> Language Class Initialized
INFO - 2025-05-03 15:08:18 --> Loader Class Initialized
INFO - 2025-05-03 15:08:18 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:18 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:18 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:18 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:18 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:18 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:18 --> Controller Class Initialized
INFO - 2025-05-03 23:08:18 --> Model "CompanyModel" initialized
INFO - 2025-05-03 15:08:18 --> Config Class Initialized
INFO - 2025-05-03 15:08:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:18 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:18 --> URI Class Initialized
INFO - 2025-05-03 15:08:18 --> Router Class Initialized
INFO - 2025-05-03 15:08:18 --> Output Class Initialized
INFO - 2025-05-03 15:08:18 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:18 --> Input Class Initialized
INFO - 2025-05-03 15:08:18 --> Language Class Initialized
INFO - 2025-05-03 23:08:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-03 23:08:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 23:08:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 23:08:19 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:19 --> Total execution time: 0.2084
INFO - 2025-05-03 15:08:19 --> Config Class Initialized
INFO - 2025-05-03 15:08:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:19 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:19 --> URI Class Initialized
INFO - 2025-05-03 15:08:19 --> Router Class Initialized
INFO - 2025-05-03 15:08:19 --> Output Class Initialized
INFO - 2025-05-03 15:08:19 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:19 --> Input Class Initialized
INFO - 2025-05-03 15:08:19 --> Language Class Initialized
INFO - 2025-05-03 15:08:19 --> Loader Class Initialized
INFO - 2025-05-03 15:08:19 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:19 --> Controller Class Initialized
INFO - 2025-05-03 15:08:19 --> Config Class Initialized
INFO - 2025-05-03 15:08:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:19 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:19 --> URI Class Initialized
INFO - 2025-05-03 15:08:19 --> Router Class Initialized
INFO - 2025-05-03 15:08:19 --> Output Class Initialized
INFO - 2025-05-03 15:08:19 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:19 --> Input Class Initialized
INFO - 2025-05-03 15:08:19 --> Language Class Initialized
INFO - 2025-05-03 15:08:19 --> Loader Class Initialized
INFO - 2025-05-03 15:08:19 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:19 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:19 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:20 --> Controller Class Initialized
INFO - 2025-05-03 23:08:20 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:20 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:20 --> Total execution time: 0.1949
INFO - 2025-05-03 15:08:21 --> Config Class Initialized
INFO - 2025-05-03 15:08:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:21 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:21 --> URI Class Initialized
INFO - 2025-05-03 15:08:21 --> Router Class Initialized
INFO - 2025-05-03 15:08:21 --> Output Class Initialized
INFO - 2025-05-03 15:08:21 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:21 --> Input Class Initialized
INFO - 2025-05-03 15:08:21 --> Language Class Initialized
INFO - 2025-05-03 15:08:21 --> Loader Class Initialized
INFO - 2025-05-03 15:08:21 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:21 --> Controller Class Initialized
INFO - 2025-05-03 23:08:21 --> Model "BankModel" initialized
INFO - 2025-05-03 15:08:21 --> Config Class Initialized
INFO - 2025-05-03 15:08:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:21 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:21 --> URI Class Initialized
INFO - 2025-05-03 15:08:21 --> Router Class Initialized
INFO - 2025-05-03 15:08:21 --> Output Class Initialized
INFO - 2025-05-03 15:08:21 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:21 --> Input Class Initialized
INFO - 2025-05-03 15:08:21 --> Language Class Initialized
INFO - 2025-05-03 15:08:21 --> Loader Class Initialized
INFO - 2025-05-03 15:08:21 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:21 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:21 --> Controller Class Initialized
INFO - 2025-05-03 23:08:21 --> Model "BankModel" initialized
INFO - 2025-05-03 23:08:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 23:08:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 23:08:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-03 23:08:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 23:08:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 23:08:21 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:21 --> Total execution time: 0.1981
INFO - 2025-05-03 15:08:23 --> Config Class Initialized
INFO - 2025-05-03 15:08:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:23 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:23 --> URI Class Initialized
INFO - 2025-05-03 15:08:23 --> Router Class Initialized
INFO - 2025-05-03 15:08:23 --> Output Class Initialized
INFO - 2025-05-03 15:08:23 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:23 --> Input Class Initialized
INFO - 2025-05-03 15:08:23 --> Language Class Initialized
INFO - 2025-05-03 15:08:23 --> Loader Class Initialized
INFO - 2025-05-03 15:08:23 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:23 --> Controller Class Initialized
INFO - 2025-05-03 15:08:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:08:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:08:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-03 15:08:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:08:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:08:23 --> Final output sent to browser
DEBUG - 2025-05-03 15:08:23 --> Total execution time: 0.3594
INFO - 2025-05-03 15:08:23 --> Config Class Initialized
INFO - 2025-05-03 15:08:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:23 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:23 --> URI Class Initialized
INFO - 2025-05-03 15:08:23 --> Router Class Initialized
INFO - 2025-05-03 15:08:23 --> Output Class Initialized
INFO - 2025-05-03 15:08:23 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:23 --> Input Class Initialized
INFO - 2025-05-03 15:08:23 --> Language Class Initialized
INFO - 2025-05-03 15:08:23 --> Loader Class Initialized
INFO - 2025-05-03 15:08:23 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:23 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:23 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:24 --> Controller Class Initialized
INFO - 2025-05-03 23:08:24 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:24 --> Model "StaffModel" initialized
INFO - 2025-05-03 23:08:24 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:24 --> Total execution time: 0.3335
INFO - 2025-05-03 15:08:29 --> Config Class Initialized
INFO - 2025-05-03 15:08:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:29 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:29 --> URI Class Initialized
INFO - 2025-05-03 15:08:29 --> Router Class Initialized
INFO - 2025-05-03 15:08:29 --> Output Class Initialized
INFO - 2025-05-03 15:08:29 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:29 --> Input Class Initialized
INFO - 2025-05-03 15:08:29 --> Language Class Initialized
INFO - 2025-05-03 15:08:29 --> Loader Class Initialized
INFO - 2025-05-03 15:08:29 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:29 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:29 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:29 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:29 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:29 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:29 --> Controller Class Initialized
INFO - 2025-05-03 15:08:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:08:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:08:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 15:08:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:08:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:08:29 --> Final output sent to browser
DEBUG - 2025-05-03 15:08:29 --> Total execution time: 0.2354
INFO - 2025-05-03 15:08:30 --> Config Class Initialized
INFO - 2025-05-03 15:08:30 --> Hooks Class Initialized
INFO - 2025-05-03 15:08:30 --> Config Class Initialized
INFO - 2025-05-03 15:08:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:30 --> Utf8 Class Initialized
DEBUG - 2025-05-03 15:08:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:30 --> URI Class Initialized
INFO - 2025-05-03 15:08:30 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:30 --> Router Class Initialized
INFO - 2025-05-03 15:08:30 --> URI Class Initialized
INFO - 2025-05-03 15:08:30 --> Output Class Initialized
INFO - 2025-05-03 15:08:30 --> Router Class Initialized
INFO - 2025-05-03 15:08:30 --> Security Class Initialized
INFO - 2025-05-03 15:08:30 --> Output Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:30 --> Security Class Initialized
INFO - 2025-05-03 15:08:30 --> Input Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:30 --> Input Class Initialized
INFO - 2025-05-03 15:08:30 --> Language Class Initialized
INFO - 2025-05-03 15:08:30 --> Language Class Initialized
INFO - 2025-05-03 15:08:30 --> Loader Class Initialized
INFO - 2025-05-03 15:08:30 --> Loader Class Initialized
INFO - 2025-05-03 15:08:30 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:30 --> Database Driver Class Initialized
INFO - 2025-05-03 15:08:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:30 --> Controller Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 23:08:30 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:30 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:08:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:30 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:30 --> Total execution time: 0.2323
INFO - 2025-05-03 15:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:30 --> Controller Class Initialized
INFO - 2025-05-03 23:08:30 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:30 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:30 --> Total execution time: 0.2575
INFO - 2025-05-03 15:08:30 --> Config Class Initialized
INFO - 2025-05-03 15:08:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:30 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:30 --> URI Class Initialized
INFO - 2025-05-03 15:08:30 --> Router Class Initialized
INFO - 2025-05-03 15:08:30 --> Output Class Initialized
INFO - 2025-05-03 15:08:30 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:30 --> Input Class Initialized
INFO - 2025-05-03 15:08:30 --> Language Class Initialized
INFO - 2025-05-03 15:08:30 --> Loader Class Initialized
INFO - 2025-05-03 15:08:30 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:30 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:30 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:30 --> Controller Class Initialized
INFO - 2025-05-03 15:08:30 --> Model "UserModel" initialized
INFO - 2025-05-03 15:08:30 --> Final output sent to browser
DEBUG - 2025-05-03 15:08:30 --> Total execution time: 0.1167
INFO - 2025-05-03 15:08:32 --> Config Class Initialized
INFO - 2025-05-03 15:08:32 --> Hooks Class Initialized
INFO - 2025-05-03 15:08:32 --> Config Class Initialized
INFO - 2025-05-03 15:08:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:32 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:32 --> URI Class Initialized
INFO - 2025-05-03 15:08:32 --> Router Class Initialized
INFO - 2025-05-03 15:08:32 --> Output Class Initialized
INFO - 2025-05-03 15:08:32 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:32 --> Input Class Initialized
INFO - 2025-05-03 15:08:32 --> Language Class Initialized
INFO - 2025-05-03 15:08:32 --> Loader Class Initialized
INFO - 2025-05-03 15:08:32 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:32 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:32 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:33 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:33 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:33 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:33 --> Controller Class Initialized
INFO - 2025-05-03 23:08:33 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:33 --> Model "StaffModel" initialized
INFO - 2025-05-03 23:08:33 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:33 --> Total execution time: 0.2452
INFO - 2025-05-03 15:08:40 --> Config Class Initialized
INFO - 2025-05-03 15:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:40 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:41 --> URI Class Initialized
INFO - 2025-05-03 15:08:41 --> Router Class Initialized
INFO - 2025-05-03 15:08:41 --> Output Class Initialized
INFO - 2025-05-03 15:08:41 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:41 --> Input Class Initialized
INFO - 2025-05-03 15:08:41 --> Language Class Initialized
INFO - 2025-05-03 15:08:41 --> Loader Class Initialized
INFO - 2025-05-03 15:08:41 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:41 --> Controller Class Initialized
INFO - 2025-05-03 15:08:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:08:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:08:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-03 15:08:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:08:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:08:41 --> Final output sent to browser
DEBUG - 2025-05-03 15:08:41 --> Total execution time: 0.2187
INFO - 2025-05-03 15:08:41 --> Config Class Initialized
INFO - 2025-05-03 15:08:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:41 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:41 --> URI Class Initialized
INFO - 2025-05-03 15:08:41 --> Router Class Initialized
INFO - 2025-05-03 15:08:41 --> Config Class Initialized
INFO - 2025-05-03 15:08:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:41 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:41 --> URI Class Initialized
INFO - 2025-05-03 15:08:41 --> Output Class Initialized
INFO - 2025-05-03 15:08:41 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:41 --> Input Class Initialized
INFO - 2025-05-03 15:08:41 --> Router Class Initialized
INFO - 2025-05-03 15:08:41 --> Language Class Initialized
INFO - 2025-05-03 15:08:41 --> Output Class Initialized
INFO - 2025-05-03 15:08:41 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:41 --> Input Class Initialized
INFO - 2025-05-03 15:08:41 --> Language Class Initialized
INFO - 2025-05-03 15:08:41 --> Loader Class Initialized
INFO - 2025-05-03 15:08:41 --> Loader Class Initialized
INFO - 2025-05-03 15:08:41 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:41 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:41 --> Controller Class Initialized
INFO - 2025-05-03 15:08:41 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: html_helper
INFO - 2025-05-03 23:08:41 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:41 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:41 --> Total execution time: 0.2504
INFO - 2025-05-03 15:08:41 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:41 --> Controller Class Initialized
INFO - 2025-05-03 23:08:41 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:41 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:08:41 --> Model "AuctionModel" initialized
INFO - 2025-05-03 15:08:41 --> Config Class Initialized
INFO - 2025-05-03 15:08:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:41 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:41 --> URI Class Initialized
INFO - 2025-05-03 23:08:41 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:41 --> Total execution time: 0.3508
INFO - 2025-05-03 15:08:41 --> Router Class Initialized
INFO - 2025-05-03 15:08:41 --> Output Class Initialized
INFO - 2025-05-03 15:08:41 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:41 --> Input Class Initialized
INFO - 2025-05-03 15:08:41 --> Language Class Initialized
INFO - 2025-05-03 15:08:41 --> Loader Class Initialized
INFO - 2025-05-03 15:08:41 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:41 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:42 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:42 --> Controller Class Initialized
INFO - 2025-05-03 15:08:42 --> Model "UserModel" initialized
INFO - 2025-05-03 15:08:42 --> Final output sent to browser
DEBUG - 2025-05-03 15:08:42 --> Total execution time: 0.1588
INFO - 2025-05-03 15:08:59 --> Config Class Initialized
INFO - 2025-05-03 15:08:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:08:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:08:59 --> Utf8 Class Initialized
INFO - 2025-05-03 15:08:59 --> URI Class Initialized
INFO - 2025-05-03 15:08:59 --> Router Class Initialized
INFO - 2025-05-03 15:08:59 --> Output Class Initialized
INFO - 2025-05-03 15:08:59 --> Security Class Initialized
DEBUG - 2025-05-03 15:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:08:59 --> Input Class Initialized
INFO - 2025-05-03 15:08:59 --> Language Class Initialized
INFO - 2025-05-03 15:08:59 --> Loader Class Initialized
INFO - 2025-05-03 15:08:59 --> Helper loaded: url_helper
INFO - 2025-05-03 15:08:59 --> Helper loaded: string_helper
INFO - 2025-05-03 15:08:59 --> Helper loaded: form_helper
INFO - 2025-05-03 15:08:59 --> Helper loaded: file_helper
INFO - 2025-05-03 15:08:59 --> Helper loaded: html_helper
INFO - 2025-05-03 15:08:59 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:08:59 --> Controller Class Initialized
INFO - 2025-05-03 23:08:59 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:08:59 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:08:59 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:08:59 --> Final output sent to browser
DEBUG - 2025-05-03 23:08:59 --> Total execution time: 0.1583
INFO - 2025-05-03 15:09:20 --> Config Class Initialized
INFO - 2025-05-03 15:09:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:20 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:20 --> URI Class Initialized
INFO - 2025-05-03 15:09:20 --> Router Class Initialized
INFO - 2025-05-03 15:09:20 --> Output Class Initialized
INFO - 2025-05-03 15:09:20 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:20 --> Input Class Initialized
INFO - 2025-05-03 15:09:20 --> Language Class Initialized
INFO - 2025-05-03 15:09:20 --> Loader Class Initialized
INFO - 2025-05-03 15:09:20 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:20 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:20 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:20 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:20 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:20 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:20 --> Controller Class Initialized
INFO - 2025-05-03 23:09:20 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:20 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:20 --> Total execution time: 0.1534
INFO - 2025-05-03 15:09:21 --> Config Class Initialized
INFO - 2025-05-03 15:09:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:21 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:21 --> URI Class Initialized
INFO - 2025-05-03 15:09:21 --> Router Class Initialized
INFO - 2025-05-03 15:09:21 --> Output Class Initialized
INFO - 2025-05-03 15:09:21 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:21 --> Input Class Initialized
INFO - 2025-05-03 15:09:21 --> Language Class Initialized
INFO - 2025-05-03 15:09:21 --> Loader Class Initialized
INFO - 2025-05-03 15:09:21 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:21 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:21 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:21 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:21 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:21 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:21 --> Controller Class Initialized
INFO - 2025-05-03 23:09:21 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:21 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:21 --> Total execution time: 0.1531
INFO - 2025-05-03 15:09:26 --> Config Class Initialized
INFO - 2025-05-03 15:09:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:26 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:26 --> URI Class Initialized
INFO - 2025-05-03 15:09:26 --> Router Class Initialized
INFO - 2025-05-03 15:09:26 --> Output Class Initialized
INFO - 2025-05-03 15:09:26 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:26 --> Input Class Initialized
INFO - 2025-05-03 15:09:26 --> Language Class Initialized
INFO - 2025-05-03 15:09:26 --> Loader Class Initialized
INFO - 2025-05-03 15:09:26 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:26 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:26 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:26 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:26 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:26 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:26 --> Controller Class Initialized
INFO - 2025-05-03 23:09:26 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:09:26 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:09:26 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:26 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:26 --> Total execution time: 0.1559
INFO - 2025-05-03 15:09:27 --> Config Class Initialized
INFO - 2025-05-03 15:09:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:27 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:27 --> URI Class Initialized
INFO - 2025-05-03 15:09:27 --> Router Class Initialized
INFO - 2025-05-03 15:09:27 --> Output Class Initialized
INFO - 2025-05-03 15:09:27 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:27 --> Input Class Initialized
INFO - 2025-05-03 15:09:27 --> Language Class Initialized
INFO - 2025-05-03 15:09:27 --> Loader Class Initialized
INFO - 2025-05-03 15:09:27 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:27 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:27 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:27 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:27 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:27 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:27 --> Controller Class Initialized
INFO - 2025-05-03 23:09:27 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:09:27 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:09:27 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:27 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:27 --> Total execution time: 0.1458
INFO - 2025-05-03 15:09:29 --> Config Class Initialized
INFO - 2025-05-03 15:09:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:29 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:29 --> URI Class Initialized
INFO - 2025-05-03 15:09:29 --> Router Class Initialized
INFO - 2025-05-03 15:09:29 --> Output Class Initialized
INFO - 2025-05-03 15:09:29 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:29 --> Input Class Initialized
INFO - 2025-05-03 15:09:29 --> Language Class Initialized
INFO - 2025-05-03 15:09:29 --> Loader Class Initialized
INFO - 2025-05-03 15:09:29 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:29 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:29 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:29 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:29 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:29 --> Controller Class Initialized
INFO - 2025-05-03 23:09:29 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:09:29 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:09:29 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:29 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:29 --> Total execution time: 0.1228
INFO - 2025-05-03 15:09:31 --> Config Class Initialized
INFO - 2025-05-03 15:09:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:31 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:31 --> URI Class Initialized
INFO - 2025-05-03 15:09:31 --> Router Class Initialized
INFO - 2025-05-03 15:09:31 --> Output Class Initialized
INFO - 2025-05-03 15:09:31 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:31 --> Input Class Initialized
INFO - 2025-05-03 15:09:31 --> Language Class Initialized
INFO - 2025-05-03 15:09:31 --> Loader Class Initialized
INFO - 2025-05-03 15:09:31 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:31 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:31 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:31 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:31 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:31 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:31 --> Controller Class Initialized
INFO - 2025-05-03 23:09:31 --> Model "CompanyModel" initialized
INFO - 2025-05-03 23:09:31 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-03 23:09:31 --> Model "AuctionModel" initialized
INFO - 2025-05-03 23:09:32 --> Final output sent to browser
DEBUG - 2025-05-03 23:09:32 --> Total execution time: 0.1542
INFO - 2025-05-03 15:09:54 --> Config Class Initialized
INFO - 2025-05-03 15:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:54 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:54 --> URI Class Initialized
INFO - 2025-05-03 15:09:54 --> Router Class Initialized
INFO - 2025-05-03 15:09:54 --> Output Class Initialized
INFO - 2025-05-03 15:09:54 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:54 --> Input Class Initialized
INFO - 2025-05-03 15:09:54 --> Language Class Initialized
INFO - 2025-05-03 15:09:54 --> Loader Class Initialized
INFO - 2025-05-03 15:09:54 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:54 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:54 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:54 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:54 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:54 --> Controller Class Initialized
INFO - 2025-05-03 15:09:55 --> Config Class Initialized
INFO - 2025-05-03 15:09:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:55 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:55 --> URI Class Initialized
INFO - 2025-05-03 15:09:55 --> Router Class Initialized
INFO - 2025-05-03 15:09:55 --> Output Class Initialized
INFO - 2025-05-03 15:09:55 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:55 --> Input Class Initialized
INFO - 2025-05-03 15:09:55 --> Language Class Initialized
INFO - 2025-05-03 15:09:55 --> Loader Class Initialized
INFO - 2025-05-03 15:09:55 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:55 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:55 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:55 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:55 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:55 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:55 --> Controller Class Initialized
INFO - 2025-05-03 15:09:56 --> Config Class Initialized
INFO - 2025-05-03 15:09:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:09:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:09:56 --> Utf8 Class Initialized
INFO - 2025-05-03 15:09:56 --> URI Class Initialized
DEBUG - 2025-05-03 15:09:56 --> No URI present. Default controller set.
INFO - 2025-05-03 15:09:56 --> Router Class Initialized
INFO - 2025-05-03 15:09:56 --> Output Class Initialized
INFO - 2025-05-03 15:09:56 --> Security Class Initialized
DEBUG - 2025-05-03 15:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:09:56 --> Input Class Initialized
INFO - 2025-05-03 15:09:56 --> Language Class Initialized
INFO - 2025-05-03 15:09:56 --> Loader Class Initialized
INFO - 2025-05-03 15:09:56 --> Helper loaded: url_helper
INFO - 2025-05-03 15:09:56 --> Helper loaded: string_helper
INFO - 2025-05-03 15:09:56 --> Helper loaded: form_helper
INFO - 2025-05-03 15:09:56 --> Helper loaded: file_helper
INFO - 2025-05-03 15:09:56 --> Helper loaded: html_helper
INFO - 2025-05-03 15:09:56 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:09:56 --> Controller Class Initialized
INFO - 2025-05-03 15:09:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 15:09:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 15:09:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-03 15:09:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 15:09:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 15:09:56 --> Final output sent to browser
DEBUG - 2025-05-03 15:09:56 --> Total execution time: 0.1131
INFO - 2025-05-03 15:10:00 --> Config Class Initialized
INFO - 2025-05-03 15:10:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:10:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:10:00 --> Utf8 Class Initialized
INFO - 2025-05-03 15:10:00 --> URI Class Initialized
INFO - 2025-05-03 15:10:00 --> Router Class Initialized
INFO - 2025-05-03 15:10:00 --> Output Class Initialized
INFO - 2025-05-03 15:10:00 --> Security Class Initialized
DEBUG - 2025-05-03 15:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:10:00 --> Input Class Initialized
INFO - 2025-05-03 15:10:00 --> Language Class Initialized
INFO - 2025-05-03 15:10:00 --> Loader Class Initialized
INFO - 2025-05-03 15:10:00 --> Helper loaded: url_helper
INFO - 2025-05-03 15:10:00 --> Helper loaded: string_helper
INFO - 2025-05-03 15:10:00 --> Helper loaded: form_helper
INFO - 2025-05-03 15:10:00 --> Helper loaded: file_helper
INFO - 2025-05-03 15:10:00 --> Helper loaded: html_helper
INFO - 2025-05-03 15:10:00 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:10:00 --> Controller Class Initialized
INFO - 2025-05-03 23:10:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 23:10:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 23:10:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-03 23:10:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 23:10:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 23:10:00 --> Final output sent to browser
DEBUG - 2025-05-03 23:10:00 --> Total execution time: 0.1583
INFO - 2025-05-03 15:10:05 --> Config Class Initialized
INFO - 2025-05-03 15:10:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:10:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:10:05 --> Utf8 Class Initialized
INFO - 2025-05-03 15:10:05 --> URI Class Initialized
INFO - 2025-05-03 15:10:05 --> Router Class Initialized
INFO - 2025-05-03 15:10:05 --> Output Class Initialized
INFO - 2025-05-03 15:10:05 --> Security Class Initialized
DEBUG - 2025-05-03 15:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:10:05 --> Input Class Initialized
INFO - 2025-05-03 15:10:05 --> Language Class Initialized
INFO - 2025-05-03 15:10:05 --> Loader Class Initialized
INFO - 2025-05-03 15:10:05 --> Helper loaded: url_helper
INFO - 2025-05-03 15:10:05 --> Helper loaded: string_helper
INFO - 2025-05-03 15:10:05 --> Helper loaded: form_helper
INFO - 2025-05-03 15:10:05 --> Helper loaded: file_helper
INFO - 2025-05-03 15:10:05 --> Helper loaded: html_helper
INFO - 2025-05-03 15:10:05 --> Database Driver Class Initialized
DEBUG - 2025-05-03 15:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-03 15:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:10:05 --> Controller Class Initialized
INFO - 2025-05-03 23:10:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-03 23:10:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-03 23:10:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-03 23:10:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-03 23:10:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-03 23:10:05 --> Final output sent to browser
DEBUG - 2025-05-03 23:10:05 --> Total execution time: 0.2208
