<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-04 04:43:28 --> Config Class Initialized
INFO - 2025-05-04 04:43:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:43:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:43:28 --> Utf8 Class Initialized
INFO - 2025-05-04 04:43:28 --> URI Class Initialized
INFO - 2025-05-04 04:43:28 --> Router Class Initialized
INFO - 2025-05-04 04:43:28 --> Output Class Initialized
INFO - 2025-05-04 04:43:28 --> Security Class Initialized
DEBUG - 2025-05-04 04:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:43:28 --> Input Class Initialized
INFO - 2025-05-04 04:43:28 --> Language Class Initialized
INFO - 2025-05-04 04:43:28 --> Loader Class Initialized
INFO - 2025-05-04 04:43:28 --> Helper loaded: url_helper
INFO - 2025-05-04 04:43:28 --> Helper loaded: string_helper
INFO - 2025-05-04 04:43:28 --> Helper loaded: form_helper
INFO - 2025-05-04 04:43:28 --> Helper loaded: file_helper
INFO - 2025-05-04 04:43:28 --> Helper loaded: html_helper
INFO - 2025-05-04 04:43:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:43:28 --> Controller Class Initialized
INFO - 2025-05-04 12:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:43:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:43:28 --> Final output sent to browser
DEBUG - 2025-05-04 12:43:28 --> Total execution time: 0.1930
INFO - 2025-05-04 04:46:22 --> Config Class Initialized
INFO - 2025-05-04 04:46:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:46:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:46:22 --> Utf8 Class Initialized
INFO - 2025-05-04 04:46:22 --> URI Class Initialized
INFO - 2025-05-04 04:46:22 --> Router Class Initialized
INFO - 2025-05-04 04:46:22 --> Output Class Initialized
INFO - 2025-05-04 04:46:22 --> Security Class Initialized
DEBUG - 2025-05-04 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:46:22 --> Input Class Initialized
INFO - 2025-05-04 04:46:22 --> Language Class Initialized
INFO - 2025-05-04 04:46:22 --> Loader Class Initialized
INFO - 2025-05-04 04:46:22 --> Helper loaded: url_helper
INFO - 2025-05-04 04:46:22 --> Helper loaded: string_helper
INFO - 2025-05-04 04:46:22 --> Helper loaded: form_helper
INFO - 2025-05-04 04:46:22 --> Helper loaded: file_helper
INFO - 2025-05-04 04:46:22 --> Helper loaded: html_helper
INFO - 2025-05-04 04:46:22 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:46:22 --> Controller Class Initialized
INFO - 2025-05-04 12:46:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:46:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:46:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:46:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:46:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:46:22 --> Final output sent to browser
DEBUG - 2025-05-04 12:46:22 --> Total execution time: 0.2737
INFO - 2025-05-04 04:46:59 --> Config Class Initialized
INFO - 2025-05-04 04:46:59 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:46:59 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:46:59 --> Utf8 Class Initialized
INFO - 2025-05-04 04:46:59 --> URI Class Initialized
INFO - 2025-05-04 04:46:59 --> Router Class Initialized
INFO - 2025-05-04 04:46:59 --> Output Class Initialized
INFO - 2025-05-04 04:46:59 --> Security Class Initialized
DEBUG - 2025-05-04 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:46:59 --> Input Class Initialized
INFO - 2025-05-04 04:46:59 --> Language Class Initialized
INFO - 2025-05-04 04:46:59 --> Loader Class Initialized
INFO - 2025-05-04 04:46:59 --> Helper loaded: url_helper
INFO - 2025-05-04 04:46:59 --> Helper loaded: string_helper
INFO - 2025-05-04 04:46:59 --> Helper loaded: form_helper
INFO - 2025-05-04 04:46:59 --> Helper loaded: file_helper
INFO - 2025-05-04 04:46:59 --> Helper loaded: html_helper
INFO - 2025-05-04 04:46:59 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:46:59 --> Controller Class Initialized
INFO - 2025-05-04 12:46:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:46:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:46:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:46:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:46:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:46:59 --> Final output sent to browser
DEBUG - 2025-05-04 12:46:59 --> Total execution time: 0.1576
INFO - 2025-05-04 04:47:29 --> Config Class Initialized
INFO - 2025-05-04 04:47:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:47:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:47:29 --> Utf8 Class Initialized
INFO - 2025-05-04 04:47:29 --> URI Class Initialized
INFO - 2025-05-04 04:47:29 --> Router Class Initialized
INFO - 2025-05-04 04:47:29 --> Output Class Initialized
INFO - 2025-05-04 04:47:29 --> Security Class Initialized
DEBUG - 2025-05-04 04:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:47:29 --> Input Class Initialized
INFO - 2025-05-04 04:47:29 --> Language Class Initialized
INFO - 2025-05-04 04:47:30 --> Loader Class Initialized
INFO - 2025-05-04 04:47:30 --> Helper loaded: url_helper
INFO - 2025-05-04 04:47:30 --> Helper loaded: string_helper
INFO - 2025-05-04 04:47:30 --> Helper loaded: form_helper
INFO - 2025-05-04 04:47:30 --> Helper loaded: file_helper
INFO - 2025-05-04 04:47:30 --> Helper loaded: html_helper
INFO - 2025-05-04 04:47:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:47:30 --> Controller Class Initialized
INFO - 2025-05-04 12:47:30 --> Model "UserModel" initialized
INFO - 2025-05-04 12:47:30 --> Final output sent to browser
DEBUG - 2025-05-04 12:47:30 --> Total execution time: 1.3847
INFO - 2025-05-04 04:47:58 --> Config Class Initialized
INFO - 2025-05-04 04:47:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:47:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:47:58 --> Utf8 Class Initialized
INFO - 2025-05-04 04:47:58 --> URI Class Initialized
INFO - 2025-05-04 04:47:58 --> Router Class Initialized
INFO - 2025-05-04 04:47:58 --> Output Class Initialized
INFO - 2025-05-04 04:47:58 --> Security Class Initialized
DEBUG - 2025-05-04 04:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:47:58 --> Input Class Initialized
INFO - 2025-05-04 04:47:58 --> Language Class Initialized
INFO - 2025-05-04 04:47:58 --> Loader Class Initialized
INFO - 2025-05-04 04:47:58 --> Helper loaded: url_helper
INFO - 2025-05-04 04:47:58 --> Helper loaded: string_helper
INFO - 2025-05-04 04:47:58 --> Helper loaded: form_helper
INFO - 2025-05-04 04:47:58 --> Helper loaded: file_helper
INFO - 2025-05-04 04:47:58 --> Helper loaded: html_helper
INFO - 2025-05-04 04:47:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:47:59 --> Controller Class Initialized
INFO - 2025-05-04 12:47:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:47:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:47:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:47:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:47:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:47:59 --> Final output sent to browser
DEBUG - 2025-05-04 12:47:59 --> Total execution time: 0.3416
INFO - 2025-05-04 04:48:44 --> Config Class Initialized
INFO - 2025-05-04 04:48:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:48:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:48:44 --> Utf8 Class Initialized
INFO - 2025-05-04 04:48:44 --> URI Class Initialized
INFO - 2025-05-04 04:48:44 --> Router Class Initialized
INFO - 2025-05-04 04:48:44 --> Output Class Initialized
INFO - 2025-05-04 04:48:44 --> Security Class Initialized
DEBUG - 2025-05-04 04:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:48:44 --> Input Class Initialized
INFO - 2025-05-04 04:48:44 --> Language Class Initialized
INFO - 2025-05-04 04:48:44 --> Loader Class Initialized
INFO - 2025-05-04 04:48:44 --> Helper loaded: url_helper
INFO - 2025-05-04 04:48:44 --> Helper loaded: string_helper
INFO - 2025-05-04 04:48:44 --> Helper loaded: form_helper
INFO - 2025-05-04 04:48:44 --> Helper loaded: file_helper
INFO - 2025-05-04 04:48:44 --> Helper loaded: html_helper
INFO - 2025-05-04 04:48:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:48:44 --> Controller Class Initialized
INFO - 2025-05-04 12:48:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:48:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:48:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:48:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:48:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:48:45 --> Final output sent to browser
DEBUG - 2025-05-04 12:48:45 --> Total execution time: 0.5874
INFO - 2025-05-04 04:48:49 --> Config Class Initialized
INFO - 2025-05-04 04:48:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:48:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:48:49 --> Utf8 Class Initialized
INFO - 2025-05-04 04:48:49 --> URI Class Initialized
INFO - 2025-05-04 04:48:49 --> Router Class Initialized
INFO - 2025-05-04 04:48:49 --> Output Class Initialized
INFO - 2025-05-04 04:48:49 --> Security Class Initialized
DEBUG - 2025-05-04 04:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:48:49 --> Input Class Initialized
INFO - 2025-05-04 04:48:49 --> Language Class Initialized
INFO - 2025-05-04 04:48:49 --> Loader Class Initialized
INFO - 2025-05-04 04:48:49 --> Helper loaded: url_helper
INFO - 2025-05-04 04:48:49 --> Helper loaded: string_helper
INFO - 2025-05-04 04:48:49 --> Helper loaded: form_helper
INFO - 2025-05-04 04:48:49 --> Helper loaded: file_helper
INFO - 2025-05-04 04:48:49 --> Helper loaded: html_helper
INFO - 2025-05-04 04:48:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:48:49 --> Controller Class Initialized
INFO - 2025-05-04 12:48:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:48:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:48:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:48:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:48:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:48:49 --> Final output sent to browser
DEBUG - 2025-05-04 12:48:49 --> Total execution time: 0.3150
INFO - 2025-05-04 04:49:56 --> Config Class Initialized
INFO - 2025-05-04 04:49:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:49:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:49:56 --> Utf8 Class Initialized
INFO - 2025-05-04 04:49:56 --> URI Class Initialized
INFO - 2025-05-04 04:49:56 --> Router Class Initialized
INFO - 2025-05-04 04:49:56 --> Output Class Initialized
INFO - 2025-05-04 04:49:56 --> Security Class Initialized
DEBUG - 2025-05-04 04:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:49:56 --> Input Class Initialized
INFO - 2025-05-04 04:49:56 --> Language Class Initialized
INFO - 2025-05-04 04:49:56 --> Loader Class Initialized
INFO - 2025-05-04 04:49:56 --> Helper loaded: url_helper
INFO - 2025-05-04 04:49:56 --> Helper loaded: string_helper
INFO - 2025-05-04 04:49:56 --> Helper loaded: form_helper
INFO - 2025-05-04 04:49:56 --> Helper loaded: file_helper
INFO - 2025-05-04 04:49:56 --> Helper loaded: html_helper
INFO - 2025-05-04 04:49:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:49:56 --> Controller Class Initialized
INFO - 2025-05-04 12:49:56 --> Model "UserModel" initialized
INFO - 2025-05-04 04:49:57 --> Config Class Initialized
INFO - 2025-05-04 04:49:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:49:57 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:49:57 --> Utf8 Class Initialized
INFO - 2025-05-04 04:49:57 --> URI Class Initialized
INFO - 2025-05-04 04:49:57 --> Router Class Initialized
INFO - 2025-05-04 04:49:57 --> Output Class Initialized
INFO - 2025-05-04 04:49:57 --> Security Class Initialized
DEBUG - 2025-05-04 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:49:57 --> Input Class Initialized
INFO - 2025-05-04 04:49:57 --> Language Class Initialized
INFO - 2025-05-04 04:49:57 --> Loader Class Initialized
INFO - 2025-05-04 04:49:57 --> Helper loaded: url_helper
INFO - 2025-05-04 04:49:57 --> Helper loaded: string_helper
INFO - 2025-05-04 04:49:57 --> Helper loaded: form_helper
INFO - 2025-05-04 04:49:57 --> Helper loaded: file_helper
INFO - 2025-05-04 04:49:57 --> Helper loaded: html_helper
INFO - 2025-05-04 04:49:57 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:49:57 --> Controller Class Initialized
INFO - 2025-05-04 12:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:49:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:49:57 --> Final output sent to browser
DEBUG - 2025-05-04 12:49:57 --> Total execution time: 0.1363
INFO - 2025-05-04 04:50:02 --> Config Class Initialized
INFO - 2025-05-04 04:50:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:02 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:02 --> URI Class Initialized
INFO - 2025-05-04 04:50:02 --> Router Class Initialized
INFO - 2025-05-04 04:50:02 --> Output Class Initialized
INFO - 2025-05-04 04:50:02 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:02 --> Input Class Initialized
INFO - 2025-05-04 04:50:02 --> Language Class Initialized
INFO - 2025-05-04 04:50:02 --> Loader Class Initialized
INFO - 2025-05-04 04:50:02 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:02 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:02 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:02 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:02 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:02 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:02 --> Controller Class Initialized
INFO - 2025-05-04 04:50:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:50:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:50:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-04 04:50:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:50:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:50:02 --> Final output sent to browser
DEBUG - 2025-05-04 04:50:02 --> Total execution time: 0.2360
INFO - 2025-05-04 04:50:07 --> Config Class Initialized
INFO - 2025-05-04 04:50:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:07 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:07 --> URI Class Initialized
INFO - 2025-05-04 04:50:07 --> Router Class Initialized
INFO - 2025-05-04 04:50:07 --> Output Class Initialized
INFO - 2025-05-04 04:50:07 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:07 --> Input Class Initialized
INFO - 2025-05-04 04:50:07 --> Language Class Initialized
INFO - 2025-05-04 04:50:07 --> Loader Class Initialized
INFO - 2025-05-04 04:50:07 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:07 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:07 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:07 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:07 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:07 --> Controller Class Initialized
INFO - 2025-05-04 12:50:07 --> Model "UserModel" initialized
INFO - 2025-05-04 12:50:07 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:07 --> Total execution time: 0.4987
INFO - 2025-05-04 04:50:09 --> Config Class Initialized
INFO - 2025-05-04 04:50:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:09 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:09 --> URI Class Initialized
INFO - 2025-05-04 04:50:09 --> Router Class Initialized
INFO - 2025-05-04 04:50:09 --> Output Class Initialized
INFO - 2025-05-04 04:50:09 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:09 --> Input Class Initialized
INFO - 2025-05-04 04:50:09 --> Language Class Initialized
INFO - 2025-05-04 04:50:09 --> Loader Class Initialized
INFO - 2025-05-04 04:50:09 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:09 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:09 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:09 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:09 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:10 --> Controller Class Initialized
INFO - 2025-05-04 04:50:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:50:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:50:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-04 04:50:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:50:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:50:10 --> Final output sent to browser
DEBUG - 2025-05-04 04:50:10 --> Total execution time: 0.1278
INFO - 2025-05-04 04:50:11 --> Config Class Initialized
INFO - 2025-05-04 04:50:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:11 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:11 --> URI Class Initialized
INFO - 2025-05-04 04:50:11 --> Router Class Initialized
INFO - 2025-05-04 04:50:11 --> Output Class Initialized
INFO - 2025-05-04 04:50:11 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:11 --> Input Class Initialized
INFO - 2025-05-04 04:50:11 --> Language Class Initialized
INFO - 2025-05-04 04:50:11 --> Loader Class Initialized
INFO - 2025-05-04 04:50:11 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:11 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:11 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:11 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:11 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:11 --> Controller Class Initialized
INFO - 2025-05-04 12:50:11 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:11 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:11 --> Total execution time: 0.2004
INFO - 2025-05-04 04:50:12 --> Config Class Initialized
INFO - 2025-05-04 04:50:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:12 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:12 --> URI Class Initialized
INFO - 2025-05-04 04:50:12 --> Router Class Initialized
INFO - 2025-05-04 04:50:12 --> Output Class Initialized
INFO - 2025-05-04 04:50:12 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:12 --> Input Class Initialized
INFO - 2025-05-04 04:50:12 --> Language Class Initialized
INFO - 2025-05-04 04:50:12 --> Loader Class Initialized
INFO - 2025-05-04 04:50:12 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:12 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:12 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:12 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:12 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:12 --> Controller Class Initialized
INFO - 2025-05-04 12:50:12 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:12 --> Model "InvoiceModel" initialized
INFO - 2025-05-04 12:50:12 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:12 --> Total execution time: 0.2833
INFO - 2025-05-04 04:50:16 --> Config Class Initialized
INFO - 2025-05-04 04:50:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:16 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:16 --> URI Class Initialized
INFO - 2025-05-04 04:50:16 --> Router Class Initialized
INFO - 2025-05-04 04:50:16 --> Output Class Initialized
INFO - 2025-05-04 04:50:16 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:16 --> Input Class Initialized
INFO - 2025-05-04 04:50:16 --> Language Class Initialized
INFO - 2025-05-04 04:50:16 --> Loader Class Initialized
INFO - 2025-05-04 04:50:17 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:17 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:17 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:17 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:17 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:17 --> Controller Class Initialized
INFO - 2025-05-04 12:50:17 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:17 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:17 --> Total execution time: 0.1908
INFO - 2025-05-04 04:50:20 --> Config Class Initialized
INFO - 2025-05-04 04:50:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:20 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:20 --> URI Class Initialized
INFO - 2025-05-04 04:50:20 --> Router Class Initialized
INFO - 2025-05-04 04:50:20 --> Output Class Initialized
INFO - 2025-05-04 04:50:20 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:20 --> Input Class Initialized
INFO - 2025-05-04 04:50:20 --> Language Class Initialized
INFO - 2025-05-04 04:50:20 --> Loader Class Initialized
INFO - 2025-05-04 04:50:20 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:20 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:20 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:20 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:20 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:20 --> Controller Class Initialized
INFO - 2025-05-04 12:50:20 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:20 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:20 --> Total execution time: 0.2001
INFO - 2025-05-04 04:50:21 --> Config Class Initialized
INFO - 2025-05-04 04:50:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:21 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:21 --> URI Class Initialized
INFO - 2025-05-04 04:50:21 --> Router Class Initialized
INFO - 2025-05-04 04:50:21 --> Output Class Initialized
INFO - 2025-05-04 04:50:21 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:21 --> Input Class Initialized
INFO - 2025-05-04 04:50:21 --> Language Class Initialized
INFO - 2025-05-04 04:50:21 --> Loader Class Initialized
INFO - 2025-05-04 04:50:21 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:21 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:21 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:21 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:21 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:21 --> Controller Class Initialized
INFO - 2025-05-04 12:50:21 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:21 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:21 --> Total execution time: 0.3453
INFO - 2025-05-04 04:50:22 --> Config Class Initialized
INFO - 2025-05-04 04:50:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:22 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:22 --> URI Class Initialized
INFO - 2025-05-04 04:50:22 --> Router Class Initialized
INFO - 2025-05-04 04:50:22 --> Output Class Initialized
INFO - 2025-05-04 04:50:22 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:22 --> Input Class Initialized
INFO - 2025-05-04 04:50:22 --> Language Class Initialized
INFO - 2025-05-04 04:50:22 --> Loader Class Initialized
INFO - 2025-05-04 04:50:22 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:22 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:22 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:22 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:22 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:22 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:22 --> Controller Class Initialized
INFO - 2025-05-04 12:50:22 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:50:22 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:22 --> Total execution time: 0.2850
INFO - 2025-05-04 04:50:25 --> Config Class Initialized
INFO - 2025-05-04 04:50:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:25 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:25 --> URI Class Initialized
INFO - 2025-05-04 04:50:25 --> Router Class Initialized
INFO - 2025-05-04 04:50:25 --> Output Class Initialized
INFO - 2025-05-04 04:50:25 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:25 --> Input Class Initialized
INFO - 2025-05-04 04:50:25 --> Language Class Initialized
INFO - 2025-05-04 04:50:25 --> Loader Class Initialized
INFO - 2025-05-04 04:50:25 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:25 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:25 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:25 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:25 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:25 --> Controller Class Initialized
INFO - 2025-05-04 04:50:26 --> Config Class Initialized
INFO - 2025-05-04 04:50:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:26 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:26 --> URI Class Initialized
INFO - 2025-05-04 04:50:26 --> Router Class Initialized
INFO - 2025-05-04 04:50:26 --> Output Class Initialized
INFO - 2025-05-04 04:50:26 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:26 --> Input Class Initialized
INFO - 2025-05-04 04:50:26 --> Language Class Initialized
INFO - 2025-05-04 04:50:26 --> Loader Class Initialized
INFO - 2025-05-04 04:50:26 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:26 --> Controller Class Initialized
INFO - 2025-05-04 04:50:26 --> Config Class Initialized
INFO - 2025-05-04 04:50:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:26 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:26 --> URI Class Initialized
DEBUG - 2025-05-04 04:50:26 --> No URI present. Default controller set.
INFO - 2025-05-04 04:50:26 --> Router Class Initialized
INFO - 2025-05-04 04:50:26 --> Output Class Initialized
INFO - 2025-05-04 04:50:26 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:26 --> Input Class Initialized
INFO - 2025-05-04 04:50:26 --> Language Class Initialized
INFO - 2025-05-04 04:50:26 --> Loader Class Initialized
INFO - 2025-05-04 04:50:26 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:26 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:26 --> Controller Class Initialized
INFO - 2025-05-04 04:50:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:50:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:50:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 04:50:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:50:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:50:26 --> Final output sent to browser
DEBUG - 2025-05-04 04:50:26 --> Total execution time: 0.1098
INFO - 2025-05-04 04:50:29 --> Config Class Initialized
INFO - 2025-05-04 04:50:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:29 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:29 --> URI Class Initialized
INFO - 2025-05-04 04:50:29 --> Router Class Initialized
INFO - 2025-05-04 04:50:29 --> Output Class Initialized
INFO - 2025-05-04 04:50:29 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:29 --> Input Class Initialized
INFO - 2025-05-04 04:50:29 --> Language Class Initialized
INFO - 2025-05-04 04:50:29 --> Loader Class Initialized
INFO - 2025-05-04 04:50:29 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:29 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:29 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:29 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:29 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:29 --> Controller Class Initialized
INFO - 2025-05-04 12:50:29 --> Model "AuctionModel" initialized
INFO - 2025-05-04 04:50:30 --> Config Class Initialized
INFO - 2025-05-04 04:50:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:50:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:50:30 --> Utf8 Class Initialized
INFO - 2025-05-04 04:50:30 --> URI Class Initialized
INFO - 2025-05-04 04:50:30 --> Router Class Initialized
INFO - 2025-05-04 04:50:30 --> Output Class Initialized
INFO - 2025-05-04 04:50:30 --> Security Class Initialized
DEBUG - 2025-05-04 04:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:50:30 --> Input Class Initialized
INFO - 2025-05-04 04:50:30 --> Language Class Initialized
INFO - 2025-05-04 04:50:30 --> Loader Class Initialized
INFO - 2025-05-04 04:50:30 --> Helper loaded: url_helper
INFO - 2025-05-04 04:50:30 --> Helper loaded: string_helper
INFO - 2025-05-04 04:50:30 --> Helper loaded: form_helper
INFO - 2025-05-04 04:50:30 --> Helper loaded: file_helper
INFO - 2025-05-04 04:50:30 --> Helper loaded: html_helper
INFO - 2025-05-04 04:50:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:50:30 --> Controller Class Initialized
INFO - 2025-05-04 12:50:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:50:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:50:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:50:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:50:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:50:30 --> Final output sent to browser
DEBUG - 2025-05-04 12:50:30 --> Total execution time: 0.1787
INFO - 2025-05-04 04:51:13 --> Config Class Initialized
INFO - 2025-05-04 04:51:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:51:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:51:13 --> Utf8 Class Initialized
INFO - 2025-05-04 04:51:13 --> URI Class Initialized
INFO - 2025-05-04 04:51:13 --> Router Class Initialized
INFO - 2025-05-04 04:51:13 --> Output Class Initialized
INFO - 2025-05-04 04:51:13 --> Security Class Initialized
DEBUG - 2025-05-04 04:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:51:13 --> Input Class Initialized
INFO - 2025-05-04 04:51:13 --> Language Class Initialized
INFO - 2025-05-04 04:51:13 --> Loader Class Initialized
INFO - 2025-05-04 04:51:13 --> Helper loaded: url_helper
INFO - 2025-05-04 04:51:13 --> Helper loaded: string_helper
INFO - 2025-05-04 04:51:13 --> Helper loaded: form_helper
INFO - 2025-05-04 04:51:13 --> Helper loaded: file_helper
INFO - 2025-05-04 04:51:13 --> Helper loaded: html_helper
INFO - 2025-05-04 04:51:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:51:13 --> Controller Class Initialized
INFO - 2025-05-04 12:51:13 --> Model "UserModel" initialized
DEBUG - 2025-05-04 12:51:13 --> PHPMailer class is loaded.
INFO - 2025-05-04 12:51:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/new_registration_otp_email.php
INFO - 2025-05-04 12:51:26 --> Final output sent to browser
DEBUG - 2025-05-04 12:51:26 --> Total execution time: 13.1968
INFO - 2025-05-04 04:51:48 --> Config Class Initialized
INFO - 2025-05-04 04:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:51:48 --> Utf8 Class Initialized
INFO - 2025-05-04 04:51:48 --> URI Class Initialized
INFO - 2025-05-04 04:51:48 --> Router Class Initialized
INFO - 2025-05-04 04:51:48 --> Output Class Initialized
INFO - 2025-05-04 04:51:48 --> Security Class Initialized
DEBUG - 2025-05-04 04:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:51:48 --> Input Class Initialized
INFO - 2025-05-04 04:51:48 --> Language Class Initialized
INFO - 2025-05-04 04:51:48 --> Loader Class Initialized
INFO - 2025-05-04 04:51:48 --> Helper loaded: url_helper
INFO - 2025-05-04 04:51:48 --> Helper loaded: string_helper
INFO - 2025-05-04 04:51:48 --> Helper loaded: form_helper
INFO - 2025-05-04 04:51:48 --> Helper loaded: file_helper
INFO - 2025-05-04 04:51:48 --> Helper loaded: html_helper
INFO - 2025-05-04 04:51:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:51:49 --> Controller Class Initialized
INFO - 2025-05-04 12:51:49 --> Model "UserModel" initialized
INFO - 2025-05-04 12:51:49 --> Final output sent to browser
DEBUG - 2025-05-04 12:51:49 --> Total execution time: 0.5421
INFO - 2025-05-04 04:51:55 --> Config Class Initialized
INFO - 2025-05-04 04:51:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:51:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:51:55 --> Utf8 Class Initialized
INFO - 2025-05-04 04:51:55 --> URI Class Initialized
INFO - 2025-05-04 04:51:55 --> Router Class Initialized
INFO - 2025-05-04 04:51:55 --> Output Class Initialized
INFO - 2025-05-04 04:51:55 --> Security Class Initialized
DEBUG - 2025-05-04 04:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:51:55 --> Input Class Initialized
INFO - 2025-05-04 04:51:55 --> Language Class Initialized
INFO - 2025-05-04 04:51:55 --> Loader Class Initialized
INFO - 2025-05-04 04:51:55 --> Helper loaded: url_helper
INFO - 2025-05-04 04:51:55 --> Helper loaded: string_helper
INFO - 2025-05-04 04:51:55 --> Helper loaded: form_helper
INFO - 2025-05-04 04:51:55 --> Helper loaded: file_helper
INFO - 2025-05-04 04:51:55 --> Helper loaded: html_helper
INFO - 2025-05-04 04:51:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:51:55 --> Controller Class Initialized
INFO - 2025-05-04 12:51:55 --> Model "UserModel" initialized
INFO - 2025-05-04 12:51:55 --> Final output sent to browser
DEBUG - 2025-05-04 12:51:55 --> Total execution time: 0.2205
INFO - 2025-05-04 04:52:05 --> Config Class Initialized
INFO - 2025-05-04 04:52:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:52:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:52:05 --> Utf8 Class Initialized
INFO - 2025-05-04 04:52:05 --> URI Class Initialized
INFO - 2025-05-04 04:52:06 --> Router Class Initialized
INFO - 2025-05-04 04:52:06 --> Output Class Initialized
INFO - 2025-05-04 04:52:06 --> Security Class Initialized
DEBUG - 2025-05-04 04:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:52:06 --> Input Class Initialized
INFO - 2025-05-04 04:52:06 --> Language Class Initialized
INFO - 2025-05-04 04:52:07 --> Loader Class Initialized
INFO - 2025-05-04 04:52:07 --> Helper loaded: url_helper
INFO - 2025-05-04 04:52:07 --> Helper loaded: string_helper
INFO - 2025-05-04 04:52:07 --> Helper loaded: form_helper
INFO - 2025-05-04 04:52:07 --> Helper loaded: file_helper
INFO - 2025-05-04 04:52:07 --> Helper loaded: html_helper
INFO - 2025-05-04 04:52:08 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:52:08 --> Controller Class Initialized
INFO - 2025-05-04 12:52:09 --> Model "UserModel" initialized
INFO - 2025-05-04 12:52:09 --> Final output sent to browser
DEBUG - 2025-05-04 12:52:09 --> Total execution time: 4.1348
INFO - 2025-05-04 04:52:12 --> Config Class Initialized
INFO - 2025-05-04 04:52:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:52:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:52:12 --> Utf8 Class Initialized
INFO - 2025-05-04 04:52:12 --> URI Class Initialized
INFO - 2025-05-04 04:52:12 --> Router Class Initialized
INFO - 2025-05-04 04:52:12 --> Output Class Initialized
INFO - 2025-05-04 04:52:12 --> Security Class Initialized
DEBUG - 2025-05-04 04:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:52:12 --> Input Class Initialized
INFO - 2025-05-04 04:52:12 --> Language Class Initialized
INFO - 2025-05-04 04:52:13 --> Loader Class Initialized
INFO - 2025-05-04 04:52:13 --> Helper loaded: url_helper
INFO - 2025-05-04 04:52:13 --> Helper loaded: string_helper
INFO - 2025-05-04 04:52:13 --> Helper loaded: form_helper
INFO - 2025-05-04 04:52:13 --> Helper loaded: file_helper
INFO - 2025-05-04 04:52:13 --> Helper loaded: html_helper
INFO - 2025-05-04 04:52:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:52:13 --> Controller Class Initialized
INFO - 2025-05-04 12:52:13 --> Model "UserModel" initialized
INFO - 2025-05-04 04:52:13 --> Config Class Initialized
INFO - 2025-05-04 04:52:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:52:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:52:13 --> Utf8 Class Initialized
INFO - 2025-05-04 04:52:14 --> URI Class Initialized
INFO - 2025-05-04 04:52:14 --> Router Class Initialized
INFO - 2025-05-04 04:52:14 --> Output Class Initialized
INFO - 2025-05-04 04:52:14 --> Security Class Initialized
DEBUG - 2025-05-04 04:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:52:14 --> Input Class Initialized
INFO - 2025-05-04 04:52:14 --> Language Class Initialized
INFO - 2025-05-04 04:52:14 --> Loader Class Initialized
INFO - 2025-05-04 04:52:14 --> Helper loaded: url_helper
INFO - 2025-05-04 04:52:14 --> Helper loaded: string_helper
INFO - 2025-05-04 04:52:14 --> Helper loaded: form_helper
INFO - 2025-05-04 04:52:14 --> Helper loaded: file_helper
INFO - 2025-05-04 04:52:14 --> Helper loaded: html_helper
INFO - 2025-05-04 04:52:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:52:14 --> Controller Class Initialized
INFO - 2025-05-04 12:52:14 --> Model "UserModel" initialized
DEBUG - 2025-05-04 12:52:14 --> PHPMailer class is loaded.
INFO - 2025-05-04 12:52:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/register_welcome_email_for_bidder.php
INFO - 2025-05-04 12:52:23 --> Final output sent to browser
DEBUG - 2025-05-04 12:52:23 --> Total execution time: 9.9784
INFO - 2025-05-04 04:53:55 --> Config Class Initialized
INFO - 2025-05-04 04:53:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:53:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:53:55 --> Utf8 Class Initialized
INFO - 2025-05-04 04:53:55 --> URI Class Initialized
INFO - 2025-05-04 04:53:55 --> Router Class Initialized
INFO - 2025-05-04 04:53:55 --> Output Class Initialized
INFO - 2025-05-04 04:53:55 --> Security Class Initialized
DEBUG - 2025-05-04 04:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:53:55 --> Input Class Initialized
INFO - 2025-05-04 04:53:55 --> Language Class Initialized
INFO - 2025-05-04 04:53:55 --> Loader Class Initialized
INFO - 2025-05-04 04:53:55 --> Helper loaded: url_helper
INFO - 2025-05-04 04:53:55 --> Helper loaded: string_helper
INFO - 2025-05-04 04:53:55 --> Helper loaded: form_helper
INFO - 2025-05-04 04:53:55 --> Helper loaded: file_helper
INFO - 2025-05-04 04:53:55 --> Helper loaded: html_helper
INFO - 2025-05-04 04:53:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:53:55 --> Controller Class Initialized
INFO - 2025-05-04 12:53:55 --> Model "UserModel" initialized
INFO - 2025-05-04 04:53:58 --> Config Class Initialized
INFO - 2025-05-04 04:53:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:53:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:53:58 --> Utf8 Class Initialized
INFO - 2025-05-04 04:53:58 --> URI Class Initialized
INFO - 2025-05-04 04:53:58 --> Router Class Initialized
INFO - 2025-05-04 04:53:58 --> Output Class Initialized
INFO - 2025-05-04 04:53:58 --> Security Class Initialized
DEBUG - 2025-05-04 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:53:58 --> Input Class Initialized
INFO - 2025-05-04 04:53:58 --> Language Class Initialized
INFO - 2025-05-04 04:53:58 --> Loader Class Initialized
INFO - 2025-05-04 04:53:58 --> Helper loaded: url_helper
INFO - 2025-05-04 04:53:58 --> Helper loaded: string_helper
INFO - 2025-05-04 04:53:58 --> Helper loaded: form_helper
INFO - 2025-05-04 04:53:58 --> Helper loaded: file_helper
INFO - 2025-05-04 04:53:58 --> Helper loaded: html_helper
INFO - 2025-05-04 04:53:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:53:58 --> Controller Class Initialized
INFO - 2025-05-04 12:53:58 --> Model "UserModel" initialized
INFO - 2025-05-04 04:54:03 --> Config Class Initialized
INFO - 2025-05-04 04:54:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:03 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:03 --> URI Class Initialized
INFO - 2025-05-04 04:54:03 --> Router Class Initialized
INFO - 2025-05-04 04:54:03 --> Output Class Initialized
INFO - 2025-05-04 04:54:03 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:03 --> Input Class Initialized
INFO - 2025-05-04 04:54:03 --> Language Class Initialized
INFO - 2025-05-04 04:54:03 --> Loader Class Initialized
INFO - 2025-05-04 04:54:03 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:03 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:03 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:03 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:03 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:03 --> Controller Class Initialized
INFO - 2025-05-04 12:54:03 --> Model "UserModel" initialized
INFO - 2025-05-04 04:54:04 --> Config Class Initialized
INFO - 2025-05-04 04:54:04 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:04 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:04 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:04 --> URI Class Initialized
INFO - 2025-05-04 04:54:04 --> Router Class Initialized
INFO - 2025-05-04 04:54:04 --> Output Class Initialized
INFO - 2025-05-04 04:54:04 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:04 --> Input Class Initialized
INFO - 2025-05-04 04:54:04 --> Language Class Initialized
INFO - 2025-05-04 04:54:04 --> Loader Class Initialized
INFO - 2025-05-04 04:54:04 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:04 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:04 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:04 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:04 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:05 --> Controller Class Initialized
INFO - 2025-05-04 12:54:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:54:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:54:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_storage_facility.php
INFO - 2025-05-04 12:54:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:54:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:54:06 --> Final output sent to browser
DEBUG - 2025-05-04 12:54:06 --> Total execution time: 2.1051
INFO - 2025-05-04 04:54:08 --> Config Class Initialized
INFO - 2025-05-04 04:54:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:08 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:08 --> URI Class Initialized
INFO - 2025-05-04 04:54:08 --> Router Class Initialized
INFO - 2025-05-04 04:54:08 --> Output Class Initialized
INFO - 2025-05-04 04:54:08 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:09 --> Input Class Initialized
INFO - 2025-05-04 04:54:09 --> Language Class Initialized
INFO - 2025-05-04 04:54:09 --> Loader Class Initialized
INFO - 2025-05-04 04:54:09 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:09 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:09 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:09 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:09 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:09 --> Controller Class Initialized
INFO - 2025-05-04 12:54:09 --> Model "UserModel" initialized
INFO - 2025-05-04 12:54:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-04 12:54:09 --> Final output sent to browser
DEBUG - 2025-05-04 12:54:09 --> Total execution time: 0.7500
INFO - 2025-05-04 04:54:17 --> Config Class Initialized
INFO - 2025-05-04 04:54:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:17 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:17 --> URI Class Initialized
INFO - 2025-05-04 04:54:17 --> Router Class Initialized
INFO - 2025-05-04 04:54:17 --> Output Class Initialized
INFO - 2025-05-04 04:54:17 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:17 --> Input Class Initialized
INFO - 2025-05-04 04:54:17 --> Language Class Initialized
INFO - 2025-05-04 04:54:17 --> Loader Class Initialized
INFO - 2025-05-04 04:54:17 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:17 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:17 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:17 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:17 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:17 --> Controller Class Initialized
INFO - 2025-05-04 04:54:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:54:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:54:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-04 04:54:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:54:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:54:17 --> Final output sent to browser
DEBUG - 2025-05-04 04:54:17 --> Total execution time: 0.2899
INFO - 2025-05-04 04:54:20 --> Config Class Initialized
INFO - 2025-05-04 04:54:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:20 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:20 --> URI Class Initialized
INFO - 2025-05-04 04:54:20 --> Router Class Initialized
INFO - 2025-05-04 04:54:20 --> Output Class Initialized
INFO - 2025-05-04 04:54:20 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:20 --> Input Class Initialized
INFO - 2025-05-04 04:54:20 --> Language Class Initialized
INFO - 2025-05-04 04:54:20 --> Loader Class Initialized
INFO - 2025-05-04 04:54:20 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:20 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:20 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:20 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:20 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:20 --> Controller Class Initialized
INFO - 2025-05-04 12:54:20 --> Model "UserModel" initialized
INFO - 2025-05-04 12:54:20 --> Final output sent to browser
DEBUG - 2025-05-04 12:54:20 --> Total execution time: 0.2517
INFO - 2025-05-04 04:54:22 --> Config Class Initialized
INFO - 2025-05-04 04:54:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:22 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:22 --> URI Class Initialized
INFO - 2025-05-04 04:54:22 --> Router Class Initialized
INFO - 2025-05-04 04:54:22 --> Output Class Initialized
INFO - 2025-05-04 04:54:22 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:22 --> Input Class Initialized
INFO - 2025-05-04 04:54:22 --> Language Class Initialized
INFO - 2025-05-04 04:54:22 --> Loader Class Initialized
INFO - 2025-05-04 04:54:22 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:22 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:22 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:22 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:22 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:22 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:22 --> Controller Class Initialized
INFO - 2025-05-04 04:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 04:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:54:22 --> Final output sent to browser
DEBUG - 2025-05-04 04:54:22 --> Total execution time: 0.2850
INFO - 2025-05-04 04:54:24 --> Config Class Initialized
INFO - 2025-05-04 04:54:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:24 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:24 --> URI Class Initialized
INFO - 2025-05-04 04:54:24 --> Router Class Initialized
INFO - 2025-05-04 04:54:24 --> Output Class Initialized
INFO - 2025-05-04 04:54:24 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:24 --> Input Class Initialized
INFO - 2025-05-04 04:54:24 --> Language Class Initialized
INFO - 2025-05-04 04:54:25 --> Loader Class Initialized
INFO - 2025-05-04 04:54:25 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:25 --> Controller Class Initialized
INFO - 2025-05-04 12:54:25 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:25 --> Config Class Initialized
INFO - 2025-05-04 04:54:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:25 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:25 --> URI Class Initialized
INFO - 2025-05-04 04:54:25 --> Router Class Initialized
INFO - 2025-05-04 04:54:25 --> Output Class Initialized
INFO - 2025-05-04 04:54:25 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:25 --> Input Class Initialized
INFO - 2025-05-04 04:54:25 --> Language Class Initialized
INFO - 2025-05-04 04:54:25 --> Loader Class Initialized
INFO - 2025-05-04 04:54:25 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:25 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:26 --> Controller Class Initialized
INFO - 2025-05-04 12:54:26 --> Model "AuctionModel" initialized
INFO - 2025-05-04 12:54:26 --> Final output sent to browser
DEBUG - 2025-05-04 12:54:26 --> Total execution time: 0.8255
INFO - 2025-05-04 04:54:26 --> Config Class Initialized
INFO - 2025-05-04 04:54:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:26 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:26 --> URI Class Initialized
INFO - 2025-05-04 04:54:26 --> Router Class Initialized
INFO - 2025-05-04 04:54:26 --> Output Class Initialized
INFO - 2025-05-04 04:54:26 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:26 --> Input Class Initialized
INFO - 2025-05-04 04:54:26 --> Language Class Initialized
INFO - 2025-05-04 04:54:26 --> Loader Class Initialized
INFO - 2025-05-04 04:54:26 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:26 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:26 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:26 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:26 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:26 --> Controller Class Initialized
INFO - 2025-05-04 04:54:26 --> Model "UserModel" initialized
INFO - 2025-05-04 04:54:29 --> Config Class Initialized
INFO - 2025-05-04 04:54:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:29 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:29 --> URI Class Initialized
INFO - 2025-05-04 04:54:29 --> Router Class Initialized
INFO - 2025-05-04 04:54:29 --> Output Class Initialized
INFO - 2025-05-04 04:54:29 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:29 --> Input Class Initialized
INFO - 2025-05-04 04:54:29 --> Language Class Initialized
INFO - 2025-05-04 04:54:29 --> Loader Class Initialized
INFO - 2025-05-04 04:54:29 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:29 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:29 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:29 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:29 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:29 --> Controller Class Initialized
INFO - 2025-05-04 12:54:30 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:31 --> Config Class Initialized
INFO - 2025-05-04 04:54:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:31 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:31 --> URI Class Initialized
INFO - 2025-05-04 04:54:31 --> Router Class Initialized
INFO - 2025-05-04 04:54:31 --> Output Class Initialized
INFO - 2025-05-04 04:54:31 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:31 --> Input Class Initialized
INFO - 2025-05-04 04:54:31 --> Language Class Initialized
INFO - 2025-05-04 04:54:31 --> Loader Class Initialized
INFO - 2025-05-04 04:54:31 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:31 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:31 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:31 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:31 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:31 --> Controller Class Initialized
INFO - 2025-05-04 12:54:31 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:38 --> Config Class Initialized
INFO - 2025-05-04 04:54:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:38 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:38 --> URI Class Initialized
INFO - 2025-05-04 04:54:38 --> Router Class Initialized
INFO - 2025-05-04 04:54:38 --> Output Class Initialized
INFO - 2025-05-04 04:54:38 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:38 --> Input Class Initialized
INFO - 2025-05-04 04:54:38 --> Language Class Initialized
INFO - 2025-05-04 04:54:38 --> Loader Class Initialized
INFO - 2025-05-04 04:54:38 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:38 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:38 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:38 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:38 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:39 --> Controller Class Initialized
INFO - 2025-05-04 12:54:39 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:41 --> Config Class Initialized
INFO - 2025-05-04 04:54:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:41 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:41 --> URI Class Initialized
INFO - 2025-05-04 04:54:41 --> Router Class Initialized
INFO - 2025-05-04 04:54:41 --> Output Class Initialized
INFO - 2025-05-04 04:54:41 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:41 --> Input Class Initialized
INFO - 2025-05-04 04:54:41 --> Language Class Initialized
INFO - 2025-05-04 04:54:41 --> Loader Class Initialized
INFO - 2025-05-04 04:54:41 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:41 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:41 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:41 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:41 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:41 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:41 --> Controller Class Initialized
INFO - 2025-05-04 12:54:41 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:42 --> Config Class Initialized
INFO - 2025-05-04 04:54:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:42 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:42 --> URI Class Initialized
INFO - 2025-05-04 04:54:42 --> Router Class Initialized
INFO - 2025-05-04 04:54:42 --> Output Class Initialized
INFO - 2025-05-04 04:54:42 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:42 --> Input Class Initialized
INFO - 2025-05-04 04:54:42 --> Language Class Initialized
INFO - 2025-05-04 04:54:42 --> Loader Class Initialized
INFO - 2025-05-04 04:54:42 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:42 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:42 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:42 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:42 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:42 --> Controller Class Initialized
INFO - 2025-05-04 12:54:42 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:46 --> Config Class Initialized
INFO - 2025-05-04 04:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:46 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:46 --> URI Class Initialized
INFO - 2025-05-04 04:54:46 --> Router Class Initialized
INFO - 2025-05-04 04:54:46 --> Output Class Initialized
INFO - 2025-05-04 04:54:46 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:46 --> Input Class Initialized
INFO - 2025-05-04 04:54:46 --> Language Class Initialized
INFO - 2025-05-04 04:54:46 --> Loader Class Initialized
INFO - 2025-05-04 04:54:46 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:46 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:46 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:46 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:46 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:46 --> Controller Class Initialized
INFO - 2025-05-04 12:54:46 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:47 --> Config Class Initialized
INFO - 2025-05-04 04:54:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:47 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:47 --> URI Class Initialized
INFO - 2025-05-04 04:54:47 --> Router Class Initialized
INFO - 2025-05-04 04:54:47 --> Output Class Initialized
INFO - 2025-05-04 04:54:47 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:47 --> Input Class Initialized
INFO - 2025-05-04 04:54:47 --> Language Class Initialized
INFO - 2025-05-04 04:54:47 --> Loader Class Initialized
INFO - 2025-05-04 04:54:47 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:47 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:47 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:47 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:47 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:47 --> Controller Class Initialized
INFO - 2025-05-04 12:54:47 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:53 --> Config Class Initialized
INFO - 2025-05-04 04:54:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:53 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:53 --> URI Class Initialized
INFO - 2025-05-04 04:54:53 --> Router Class Initialized
INFO - 2025-05-04 04:54:53 --> Output Class Initialized
INFO - 2025-05-04 04:54:53 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:53 --> Input Class Initialized
INFO - 2025-05-04 04:54:53 --> Language Class Initialized
INFO - 2025-05-04 04:54:53 --> Loader Class Initialized
INFO - 2025-05-04 04:54:53 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:53 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:53 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:53 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:53 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:53 --> Controller Class Initialized
INFO - 2025-05-04 04:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 04:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:54:53 --> Final output sent to browser
DEBUG - 2025-05-04 04:54:53 --> Total execution time: 0.1701
INFO - 2025-05-04 04:54:55 --> Config Class Initialized
INFO - 2025-05-04 04:54:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:55 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:55 --> URI Class Initialized
INFO - 2025-05-04 04:54:55 --> Router Class Initialized
INFO - 2025-05-04 04:54:55 --> Output Class Initialized
INFO - 2025-05-04 04:54:55 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:55 --> Input Class Initialized
INFO - 2025-05-04 04:54:55 --> Language Class Initialized
INFO - 2025-05-04 04:54:55 --> Loader Class Initialized
INFO - 2025-05-04 04:54:55 --> Helper loaded: url_helper
INFO - 2025-05-04 04:54:55 --> Helper loaded: string_helper
INFO - 2025-05-04 04:54:55 --> Helper loaded: form_helper
INFO - 2025-05-04 04:54:55 --> Helper loaded: file_helper
INFO - 2025-05-04 04:54:55 --> Helper loaded: html_helper
INFO - 2025-05-04 04:54:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:54:55 --> Controller Class Initialized
INFO - 2025-05-04 12:54:55 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:54:59 --> Config Class Initialized
INFO - 2025-05-04 04:54:59 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:54:59 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:54:59 --> Utf8 Class Initialized
INFO - 2025-05-04 04:54:59 --> URI Class Initialized
INFO - 2025-05-04 04:54:59 --> Router Class Initialized
INFO - 2025-05-04 04:54:59 --> Output Class Initialized
INFO - 2025-05-04 04:54:59 --> Security Class Initialized
DEBUG - 2025-05-04 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:54:59 --> Input Class Initialized
INFO - 2025-05-04 04:54:59 --> Language Class Initialized
INFO - 2025-05-04 04:55:00 --> Loader Class Initialized
INFO - 2025-05-04 04:55:00 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:00 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:00 --> Controller Class Initialized
INFO - 2025-05-04 12:55:00 --> Model "BankModel" initialized
INFO - 2025-05-04 04:55:00 --> Config Class Initialized
INFO - 2025-05-04 04:55:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:55:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:55:00 --> Utf8 Class Initialized
INFO - 2025-05-04 04:55:00 --> URI Class Initialized
INFO - 2025-05-04 04:55:00 --> Router Class Initialized
INFO - 2025-05-04 04:55:00 --> Output Class Initialized
INFO - 2025-05-04 04:55:00 --> Security Class Initialized
DEBUG - 2025-05-04 04:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:55:00 --> Input Class Initialized
INFO - 2025-05-04 04:55:00 --> Language Class Initialized
INFO - 2025-05-04 04:55:00 --> Loader Class Initialized
INFO - 2025-05-04 04:55:00 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:00 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:00 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:00 --> Controller Class Initialized
INFO - 2025-05-04 12:55:00 --> Model "BankModel" initialized
INFO - 2025-05-04 12:55:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:55:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:55:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-04 12:55:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:55:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:55:00 --> Final output sent to browser
DEBUG - 2025-05-04 12:55:00 --> Total execution time: 0.3166
INFO - 2025-05-04 04:55:03 --> Config Class Initialized
INFO - 2025-05-04 04:55:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:55:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:55:03 --> Utf8 Class Initialized
INFO - 2025-05-04 04:55:03 --> URI Class Initialized
INFO - 2025-05-04 04:55:03 --> Router Class Initialized
INFO - 2025-05-04 04:55:03 --> Output Class Initialized
INFO - 2025-05-04 04:55:03 --> Security Class Initialized
DEBUG - 2025-05-04 04:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:55:03 --> Input Class Initialized
INFO - 2025-05-04 04:55:03 --> Language Class Initialized
INFO - 2025-05-04 04:55:03 --> Loader Class Initialized
INFO - 2025-05-04 04:55:03 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:03 --> Controller Class Initialized
INFO - 2025-05-04 12:55:03 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:55:03 --> Config Class Initialized
INFO - 2025-05-04 04:55:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:55:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:55:03 --> Utf8 Class Initialized
INFO - 2025-05-04 04:55:03 --> URI Class Initialized
INFO - 2025-05-04 04:55:03 --> Router Class Initialized
INFO - 2025-05-04 04:55:03 --> Output Class Initialized
INFO - 2025-05-04 04:55:03 --> Security Class Initialized
DEBUG - 2025-05-04 04:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:55:03 --> Input Class Initialized
INFO - 2025-05-04 04:55:03 --> Language Class Initialized
INFO - 2025-05-04 04:55:03 --> Loader Class Initialized
INFO - 2025-05-04 04:55:03 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:03 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:03 --> Controller Class Initialized
INFO - 2025-05-04 12:55:03 --> Model "CompanyModel" initialized
INFO - 2025-05-04 12:55:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:55:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:55:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 12:55:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:55:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:55:03 --> Final output sent to browser
DEBUG - 2025-05-04 12:55:03 --> Total execution time: 0.2772
INFO - 2025-05-04 04:55:07 --> Config Class Initialized
INFO - 2025-05-04 04:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:55:07 --> Utf8 Class Initialized
INFO - 2025-05-04 04:55:07 --> URI Class Initialized
INFO - 2025-05-04 04:55:07 --> Router Class Initialized
INFO - 2025-05-04 04:55:07 --> Output Class Initialized
INFO - 2025-05-04 04:55:07 --> Security Class Initialized
DEBUG - 2025-05-04 04:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:55:07 --> Input Class Initialized
INFO - 2025-05-04 04:55:07 --> Language Class Initialized
INFO - 2025-05-04 04:55:07 --> Loader Class Initialized
INFO - 2025-05-04 04:55:07 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:07 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:07 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:07 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:07 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:07 --> Controller Class Initialized
INFO - 2025-05-04 04:55:10 --> Config Class Initialized
INFO - 2025-05-04 04:55:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:55:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:55:11 --> Utf8 Class Initialized
INFO - 2025-05-04 04:55:11 --> URI Class Initialized
INFO - 2025-05-04 04:55:11 --> Router Class Initialized
INFO - 2025-05-04 04:55:11 --> Output Class Initialized
INFO - 2025-05-04 04:55:11 --> Security Class Initialized
DEBUG - 2025-05-04 04:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:55:11 --> Input Class Initialized
INFO - 2025-05-04 04:55:11 --> Language Class Initialized
INFO - 2025-05-04 04:55:11 --> Loader Class Initialized
INFO - 2025-05-04 04:55:11 --> Helper loaded: url_helper
INFO - 2025-05-04 04:55:11 --> Helper loaded: string_helper
INFO - 2025-05-04 04:55:11 --> Helper loaded: form_helper
INFO - 2025-05-04 04:55:11 --> Helper loaded: file_helper
INFO - 2025-05-04 04:55:11 --> Helper loaded: html_helper
INFO - 2025-05-04 04:55:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:55:11 --> Controller Class Initialized
INFO - 2025-05-04 04:56:12 --> Config Class Initialized
INFO - 2025-05-04 04:56:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:12 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:12 --> URI Class Initialized
INFO - 2025-05-04 04:56:12 --> Router Class Initialized
INFO - 2025-05-04 04:56:12 --> Output Class Initialized
INFO - 2025-05-04 04:56:12 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:12 --> Input Class Initialized
INFO - 2025-05-04 04:56:12 --> Language Class Initialized
INFO - 2025-05-04 04:56:12 --> Loader Class Initialized
INFO - 2025-05-04 04:56:12 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:12 --> Controller Class Initialized
INFO - 2025-05-04 04:56:12 --> Config Class Initialized
INFO - 2025-05-04 04:56:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:12 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:12 --> URI Class Initialized
DEBUG - 2025-05-04 04:56:12 --> No URI present. Default controller set.
INFO - 2025-05-04 04:56:12 --> Router Class Initialized
INFO - 2025-05-04 04:56:12 --> Output Class Initialized
INFO - 2025-05-04 04:56:12 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:12 --> Input Class Initialized
INFO - 2025-05-04 04:56:12 --> Language Class Initialized
INFO - 2025-05-04 04:56:12 --> Loader Class Initialized
INFO - 2025-05-04 04:56:12 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:12 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:12 --> Controller Class Initialized
INFO - 2025-05-04 04:56:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:56:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:56:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 04:56:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:56:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:56:12 --> Final output sent to browser
DEBUG - 2025-05-04 04:56:12 --> Total execution time: 0.2925
INFO - 2025-05-04 04:56:13 --> Config Class Initialized
INFO - 2025-05-04 04:56:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:13 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:13 --> URI Class Initialized
INFO - 2025-05-04 04:56:13 --> Router Class Initialized
INFO - 2025-05-04 04:56:13 --> Output Class Initialized
INFO - 2025-05-04 04:56:13 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:13 --> Input Class Initialized
INFO - 2025-05-04 04:56:13 --> Language Class Initialized
INFO - 2025-05-04 04:56:13 --> Loader Class Initialized
INFO - 2025-05-04 04:56:13 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:13 --> Controller Class Initialized
INFO - 2025-05-04 04:56:13 --> Config Class Initialized
INFO - 2025-05-04 04:56:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:13 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:13 --> URI Class Initialized
DEBUG - 2025-05-04 04:56:13 --> No URI present. Default controller set.
INFO - 2025-05-04 04:56:13 --> Router Class Initialized
INFO - 2025-05-04 04:56:13 --> Output Class Initialized
INFO - 2025-05-04 04:56:13 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:13 --> Input Class Initialized
INFO - 2025-05-04 04:56:13 --> Language Class Initialized
INFO - 2025-05-04 04:56:13 --> Loader Class Initialized
INFO - 2025-05-04 04:56:13 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:13 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:13 --> Controller Class Initialized
INFO - 2025-05-04 04:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 04:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:56:13 --> Final output sent to browser
DEBUG - 2025-05-04 04:56:13 --> Total execution time: 0.1373
INFO - 2025-05-04 04:56:16 --> Config Class Initialized
INFO - 2025-05-04 04:56:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:16 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:16 --> URI Class Initialized
INFO - 2025-05-04 04:56:16 --> Router Class Initialized
INFO - 2025-05-04 04:56:16 --> Output Class Initialized
INFO - 2025-05-04 04:56:16 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:16 --> Input Class Initialized
INFO - 2025-05-04 04:56:16 --> Language Class Initialized
INFO - 2025-05-04 04:56:16 --> Loader Class Initialized
INFO - 2025-05-04 04:56:16 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:16 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:16 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:16 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:16 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:16 --> Controller Class Initialized
INFO - 2025-05-04 12:56:16 --> Model "AuctionModel" initialized
INFO - 2025-05-04 04:56:18 --> Config Class Initialized
INFO - 2025-05-04 04:56:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:18 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:18 --> URI Class Initialized
INFO - 2025-05-04 04:56:18 --> Router Class Initialized
INFO - 2025-05-04 04:56:18 --> Output Class Initialized
INFO - 2025-05-04 04:56:18 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:18 --> Input Class Initialized
INFO - 2025-05-04 04:56:18 --> Language Class Initialized
INFO - 2025-05-04 04:56:18 --> Loader Class Initialized
INFO - 2025-05-04 04:56:18 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:18 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:18 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:18 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:18 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:18 --> Controller Class Initialized
INFO - 2025-05-04 12:56:18 --> Model "AuctionModel" initialized
INFO - 2025-05-04 04:56:48 --> Config Class Initialized
INFO - 2025-05-04 04:56:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:48 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:48 --> URI Class Initialized
INFO - 2025-05-04 04:56:48 --> Router Class Initialized
INFO - 2025-05-04 04:56:48 --> Output Class Initialized
INFO - 2025-05-04 04:56:48 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:48 --> Input Class Initialized
INFO - 2025-05-04 04:56:48 --> Language Class Initialized
INFO - 2025-05-04 04:56:48 --> Loader Class Initialized
INFO - 2025-05-04 04:56:48 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:48 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:48 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:48 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:48 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:48 --> Controller Class Initialized
INFO - 2025-05-04 12:56:48 --> Model "UserModel" initialized
INFO - 2025-05-04 12:56:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-04 12:56:48 --> Final output sent to browser
DEBUG - 2025-05-04 12:56:48 --> Total execution time: 0.1369
INFO - 2025-05-04 04:56:52 --> Config Class Initialized
INFO - 2025-05-04 04:56:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:52 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:52 --> URI Class Initialized
DEBUG - 2025-05-04 04:56:52 --> No URI present. Default controller set.
INFO - 2025-05-04 04:56:52 --> Router Class Initialized
INFO - 2025-05-04 04:56:52 --> Output Class Initialized
INFO - 2025-05-04 04:56:52 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:52 --> Input Class Initialized
INFO - 2025-05-04 04:56:52 --> Language Class Initialized
INFO - 2025-05-04 04:56:52 --> Loader Class Initialized
INFO - 2025-05-04 04:56:52 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:52 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:52 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:52 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:52 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:52 --> Controller Class Initialized
INFO - 2025-05-04 04:56:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:56:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:56:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 04:56:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:56:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:56:52 --> Final output sent to browser
DEBUG - 2025-05-04 04:56:52 --> Total execution time: 0.1063
INFO - 2025-05-04 04:56:53 --> Config Class Initialized
INFO - 2025-05-04 04:56:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:56:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:56:53 --> Utf8 Class Initialized
INFO - 2025-05-04 04:56:53 --> URI Class Initialized
INFO - 2025-05-04 04:56:53 --> Router Class Initialized
INFO - 2025-05-04 04:56:53 --> Output Class Initialized
INFO - 2025-05-04 04:56:53 --> Security Class Initialized
DEBUG - 2025-05-04 04:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:56:53 --> Input Class Initialized
INFO - 2025-05-04 04:56:53 --> Language Class Initialized
INFO - 2025-05-04 04:56:53 --> Loader Class Initialized
INFO - 2025-05-04 04:56:53 --> Helper loaded: url_helper
INFO - 2025-05-04 04:56:53 --> Helper loaded: string_helper
INFO - 2025-05-04 04:56:53 --> Helper loaded: form_helper
INFO - 2025-05-04 04:56:53 --> Helper loaded: file_helper
INFO - 2025-05-04 04:56:53 --> Helper loaded: html_helper
INFO - 2025-05-04 04:56:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:56:53 --> Controller Class Initialized
INFO - 2025-05-04 12:56:53 --> Model "AuctionModel" initialized
INFO - 2025-05-04 04:57:02 --> Config Class Initialized
INFO - 2025-05-04 04:57:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:57:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:57:02 --> Utf8 Class Initialized
INFO - 2025-05-04 04:57:02 --> URI Class Initialized
INFO - 2025-05-04 04:57:02 --> Router Class Initialized
INFO - 2025-05-04 04:57:02 --> Output Class Initialized
INFO - 2025-05-04 04:57:02 --> Security Class Initialized
DEBUG - 2025-05-04 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:57:02 --> Input Class Initialized
INFO - 2025-05-04 04:57:02 --> Language Class Initialized
INFO - 2025-05-04 04:57:02 --> Loader Class Initialized
INFO - 2025-05-04 04:57:02 --> Helper loaded: url_helper
INFO - 2025-05-04 04:57:02 --> Helper loaded: string_helper
INFO - 2025-05-04 04:57:02 --> Helper loaded: form_helper
INFO - 2025-05-04 04:57:02 --> Helper loaded: file_helper
INFO - 2025-05-04 04:57:02 --> Helper loaded: html_helper
INFO - 2025-05-04 04:57:02 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:57:02 --> Controller Class Initialized
INFO - 2025-05-04 04:58:11 --> Config Class Initialized
INFO - 2025-05-04 04:58:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:58:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:58:11 --> Utf8 Class Initialized
INFO - 2025-05-04 04:58:11 --> URI Class Initialized
INFO - 2025-05-04 04:58:11 --> Router Class Initialized
INFO - 2025-05-04 04:58:11 --> Output Class Initialized
INFO - 2025-05-04 04:58:11 --> Security Class Initialized
DEBUG - 2025-05-04 04:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:58:11 --> Input Class Initialized
INFO - 2025-05-04 04:58:11 --> Language Class Initialized
INFO - 2025-05-04 04:58:11 --> Loader Class Initialized
INFO - 2025-05-04 04:58:11 --> Helper loaded: url_helper
INFO - 2025-05-04 04:58:11 --> Helper loaded: string_helper
INFO - 2025-05-04 04:58:11 --> Helper loaded: form_helper
INFO - 2025-05-04 04:58:11 --> Helper loaded: file_helper
INFO - 2025-05-04 04:58:11 --> Helper loaded: html_helper
INFO - 2025-05-04 04:58:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:58:12 --> Controller Class Initialized
INFO - 2025-05-04 04:58:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:58:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:58:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 04:58:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:58:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:58:12 --> Final output sent to browser
DEBUG - 2025-05-04 04:58:12 --> Total execution time: 0.4280
INFO - 2025-05-04 04:58:14 --> Config Class Initialized
INFO - 2025-05-04 04:58:14 --> Hooks Class Initialized
INFO - 2025-05-04 04:58:14 --> Helper loaded: string_helper
INFO - 2025-05-04 04:58:14 --> Helper loaded: form_helper
INFO - 2025-05-04 04:58:14 --> Helper loaded: file_helper
INFO - 2025-05-04 04:58:14 --> Helper loaded: html_helper
INFO - 2025-05-04 04:58:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:58:14 --> Controller Class Initialized
INFO - 2025-05-04 12:58:14 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:59:00 --> Config Class Initialized
INFO - 2025-05-04 04:59:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:00 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:00 --> URI Class Initialized
INFO - 2025-05-04 04:59:00 --> Router Class Initialized
INFO - 2025-05-04 04:59:00 --> Output Class Initialized
INFO - 2025-05-04 04:59:00 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:00 --> Input Class Initialized
INFO - 2025-05-04 04:59:00 --> Language Class Initialized
INFO - 2025-05-04 04:59:01 --> Loader Class Initialized
INFO - 2025-05-04 04:59:01 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:01 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:01 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:01 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:01 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:01 --> Controller Class Initialized
INFO - 2025-05-04 04:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 04:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:59:01 --> Final output sent to browser
DEBUG - 2025-05-04 04:59:01 --> Total execution time: 0.9708
DEBUG - 2025-05-04 04:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:04 --> Input Class Initialized
INFO - 2025-05-04 04:59:04 --> Language Class Initialized
INFO - 2025-05-04 04:59:04 --> Loader Class Initialized
INFO - 2025-05-04 04:59:04 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:04 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:04 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:04 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:04 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:04 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:04 --> Controller Class Initialized
INFO - 2025-05-04 12:59:04 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:59:43 --> Config Class Initialized
INFO - 2025-05-04 04:59:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:43 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:43 --> URI Class Initialized
INFO - 2025-05-04 04:59:43 --> Router Class Initialized
INFO - 2025-05-04 04:59:43 --> Output Class Initialized
INFO - 2025-05-04 04:59:43 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:43 --> Input Class Initialized
INFO - 2025-05-04 04:59:43 --> Language Class Initialized
INFO - 2025-05-04 04:59:43 --> Loader Class Initialized
INFO - 2025-05-04 04:59:43 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:43 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:43 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:43 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:43 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:43 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:43 --> Controller Class Initialized
INFO - 2025-05-04 04:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 04:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:59:43 --> Final output sent to browser
DEBUG - 2025-05-04 04:59:43 --> Total execution time: 0.2200
INFO - 2025-05-04 04:59:45 --> Config Class Initialized
INFO - 2025-05-04 04:59:45 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:45 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:45 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:45 --> URI Class Initialized
INFO - 2025-05-04 04:59:45 --> Router Class Initialized
INFO - 2025-05-04 04:59:45 --> Output Class Initialized
INFO - 2025-05-04 04:59:45 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:45 --> Input Class Initialized
INFO - 2025-05-04 04:59:45 --> Language Class Initialized
INFO - 2025-05-04 04:59:45 --> Loader Class Initialized
INFO - 2025-05-04 04:59:45 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:45 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:45 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:45 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:45 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:45 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:45 --> Controller Class Initialized
INFO - 2025-05-04 12:59:45 --> Model "CompanyModel" initialized
INFO - 2025-05-04 04:59:52 --> Config Class Initialized
INFO - 2025-05-04 04:59:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:52 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:52 --> URI Class Initialized
INFO - 2025-05-04 04:59:52 --> Router Class Initialized
INFO - 2025-05-04 04:59:52 --> Output Class Initialized
INFO - 2025-05-04 04:59:52 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:52 --> Input Class Initialized
INFO - 2025-05-04 04:59:52 --> Language Class Initialized
INFO - 2025-05-04 04:59:52 --> Loader Class Initialized
INFO - 2025-05-04 04:59:52 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:52 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:52 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:52 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:52 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:52 --> Controller Class Initialized
INFO - 2025-05-04 12:59:52 --> Model "BankModel" initialized
INFO - 2025-05-04 04:59:52 --> Config Class Initialized
INFO - 2025-05-04 04:59:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:52 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:52 --> URI Class Initialized
INFO - 2025-05-04 04:59:52 --> Router Class Initialized
INFO - 2025-05-04 04:59:52 --> Output Class Initialized
INFO - 2025-05-04 04:59:52 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:52 --> Input Class Initialized
INFO - 2025-05-04 04:59:52 --> Language Class Initialized
INFO - 2025-05-04 04:59:53 --> Loader Class Initialized
INFO - 2025-05-04 04:59:53 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:53 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:53 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:53 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:53 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:53 --> Controller Class Initialized
INFO - 2025-05-04 12:59:53 --> Model "BankModel" initialized
INFO - 2025-05-04 12:59:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 12:59:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 12:59:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-04 12:59:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 12:59:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 12:59:53 --> Final output sent to browser
DEBUG - 2025-05-04 12:59:53 --> Total execution time: 0.1167
INFO - 2025-05-04 04:59:56 --> Config Class Initialized
INFO - 2025-05-04 04:59:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:56 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:56 --> URI Class Initialized
INFO - 2025-05-04 04:59:56 --> Router Class Initialized
INFO - 2025-05-04 04:59:56 --> Output Class Initialized
INFO - 2025-05-04 04:59:56 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:56 --> Input Class Initialized
INFO - 2025-05-04 04:59:56 --> Language Class Initialized
INFO - 2025-05-04 04:59:56 --> Loader Class Initialized
INFO - 2025-05-04 04:59:56 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:56 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:56 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:56 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:56 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:56 --> Controller Class Initialized
INFO - 2025-05-04 04:59:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 04:59:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 04:59:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 04:59:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 04:59:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 04:59:57 --> Final output sent to browser
DEBUG - 2025-05-04 04:59:57 --> Total execution time: 0.5611
INFO - 2025-05-04 04:59:58 --> Config Class Initialized
INFO - 2025-05-04 04:59:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 04:59:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 04:59:58 --> Utf8 Class Initialized
INFO - 2025-05-04 04:59:58 --> URI Class Initialized
INFO - 2025-05-04 04:59:58 --> Router Class Initialized
INFO - 2025-05-04 04:59:58 --> Output Class Initialized
INFO - 2025-05-04 04:59:58 --> Security Class Initialized
DEBUG - 2025-05-04 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 04:59:59 --> Input Class Initialized
INFO - 2025-05-04 04:59:59 --> Language Class Initialized
INFO - 2025-05-04 04:59:59 --> Loader Class Initialized
INFO - 2025-05-04 04:59:59 --> Helper loaded: url_helper
INFO - 2025-05-04 04:59:59 --> Helper loaded: string_helper
INFO - 2025-05-04 04:59:59 --> Helper loaded: form_helper
INFO - 2025-05-04 04:59:59 --> Helper loaded: file_helper
INFO - 2025-05-04 04:59:59 --> Helper loaded: html_helper
INFO - 2025-05-04 04:59:59 --> Database Driver Class Initialized
DEBUG - 2025-05-04 04:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 04:59:59 --> Controller Class Initialized
INFO - 2025-05-04 04:59:59 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 04:59:59 --> Final output sent to browser
DEBUG - 2025-05-04 04:59:59 --> Total execution time: 0.6970
INFO - 2025-05-04 05:00:11 --> Config Class Initialized
INFO - 2025-05-04 05:00:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:11 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:11 --> URI Class Initialized
INFO - 2025-05-04 05:00:11 --> Router Class Initialized
INFO - 2025-05-04 05:00:11 --> Output Class Initialized
INFO - 2025-05-04 05:00:11 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:11 --> Input Class Initialized
INFO - 2025-05-04 05:00:11 --> Language Class Initialized
INFO - 2025-05-04 05:00:11 --> Loader Class Initialized
INFO - 2025-05-04 05:00:11 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:11 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:11 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:11 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:11 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:11 --> Controller Class Initialized
INFO - 2025-05-04 05:00:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:00:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:00:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:00:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:00:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:00:11 --> Final output sent to browser
DEBUG - 2025-05-04 05:00:11 --> Total execution time: 0.1824
INFO - 2025-05-04 05:00:13 --> Config Class Initialized
INFO - 2025-05-04 05:00:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:15 --> Config Class Initialized
INFO - 2025-05-04 05:00:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:15 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:15 --> URI Class Initialized
INFO - 2025-05-04 05:00:15 --> Router Class Initialized
INFO - 2025-05-04 05:00:15 --> Output Class Initialized
INFO - 2025-05-04 05:00:15 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:15 --> Input Class Initialized
INFO - 2025-05-04 05:00:15 --> Language Class Initialized
INFO - 2025-05-04 05:00:15 --> Loader Class Initialized
INFO - 2025-05-04 05:00:15 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:15 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:15 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:15 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:15 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:15 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:15 --> Controller Class Initialized
INFO - 2025-05-04 05:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:00:15 --> Final output sent to browser
DEBUG - 2025-05-04 05:00:15 --> Total execution time: 0.1439
INFO - 2025-05-04 05:00:16 --> Config Class Initialized
INFO - 2025-05-04 05:00:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:16 --> URI Class Initialized
INFO - 2025-05-04 05:00:16 --> Router Class Initialized
INFO - 2025-05-04 05:00:16 --> Output Class Initialized
INFO - 2025-05-04 05:00:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:16 --> Input Class Initialized
INFO - 2025-05-04 05:00:16 --> Language Class Initialized
INFO - 2025-05-04 05:00:16 --> Loader Class Initialized
INFO - 2025-05-04 05:00:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:16 --> Controller Class Initialized
INFO - 2025-05-04 05:00:16 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:00:16 --> Final output sent to browser
DEBUG - 2025-05-04 05:00:16 --> Total execution time: 0.1899
INFO - 2025-05-04 05:00:20 --> Config Class Initialized
INFO - 2025-05-04 05:00:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:20 --> URI Class Initialized
INFO - 2025-05-04 05:00:20 --> Router Class Initialized
INFO - 2025-05-04 05:00:20 --> Output Class Initialized
INFO - 2025-05-04 05:00:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:20 --> Input Class Initialized
INFO - 2025-05-04 05:00:20 --> Language Class Initialized
INFO - 2025-05-04 05:00:20 --> Loader Class Initialized
INFO - 2025-05-04 05:00:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:20 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:20 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:20 --> Controller Class Initialized
INFO - 2025-05-04 05:00:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:00:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:00:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:00:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:00:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:00:20 --> Final output sent to browser
DEBUG - 2025-05-04 05:00:20 --> Total execution time: 0.1271
INFO - 2025-05-04 05:00:32 --> Config Class Initialized
INFO - 2025-05-04 05:00:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:32 --> URI Class Initialized
INFO - 2025-05-04 05:00:32 --> Router Class Initialized
INFO - 2025-05-04 05:00:32 --> Output Class Initialized
INFO - 2025-05-04 05:00:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:32 --> Input Class Initialized
INFO - 2025-05-04 05:00:32 --> Language Class Initialized
INFO - 2025-05-04 05:00:32 --> Loader Class Initialized
INFO - 2025-05-04 05:00:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:33 --> Controller Class Initialized
INFO - 2025-05-04 13:00:33 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:00:33 --> Config Class Initialized
INFO - 2025-05-04 05:00:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:33 --> URI Class Initialized
INFO - 2025-05-04 05:00:33 --> Router Class Initialized
INFO - 2025-05-04 05:00:33 --> Output Class Initialized
INFO - 2025-05-04 05:00:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:33 --> Input Class Initialized
INFO - 2025-05-04 05:00:33 --> Language Class Initialized
INFO - 2025-05-04 05:00:33 --> Loader Class Initialized
INFO - 2025-05-04 05:00:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:33 --> Controller Class Initialized
INFO - 2025-05-04 13:00:33 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:00:33 --> Final output sent to browser
DEBUG - 2025-05-04 13:00:33 --> Total execution time: 0.1293
INFO - 2025-05-04 05:00:34 --> Config Class Initialized
INFO - 2025-05-04 05:00:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:34 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:34 --> URI Class Initialized
INFO - 2025-05-04 05:00:34 --> Router Class Initialized
INFO - 2025-05-04 05:00:34 --> Output Class Initialized
INFO - 2025-05-04 05:00:34 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:34 --> Input Class Initialized
INFO - 2025-05-04 05:00:34 --> Language Class Initialized
INFO - 2025-05-04 05:00:34 --> Loader Class Initialized
INFO - 2025-05-04 05:00:34 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:34 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:34 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:34 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:34 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:34 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:34 --> Controller Class Initialized
INFO - 2025-05-04 05:00:35 --> Model "UserModel" initialized
INFO - 2025-05-04 05:00:40 --> Config Class Initialized
INFO - 2025-05-04 05:00:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:40 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:40 --> URI Class Initialized
INFO - 2025-05-04 05:00:40 --> Router Class Initialized
INFO - 2025-05-04 05:00:40 --> Output Class Initialized
INFO - 2025-05-04 05:00:40 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:40 --> Input Class Initialized
INFO - 2025-05-04 05:00:40 --> Language Class Initialized
INFO - 2025-05-04 05:00:40 --> Loader Class Initialized
INFO - 2025-05-04 05:00:40 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:40 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:40 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:40 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:40 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:40 --> Controller Class Initialized
INFO - 2025-05-04 05:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:00:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:00:40 --> Final output sent to browser
DEBUG - 2025-05-04 05:00:40 --> Total execution time: 0.2246
INFO - 2025-05-04 05:00:46 --> Config Class Initialized
INFO - 2025-05-04 05:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:46 --> URI Class Initialized
INFO - 2025-05-04 05:00:46 --> Router Class Initialized
INFO - 2025-05-04 05:00:46 --> Output Class Initialized
INFO - 2025-05-04 05:00:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:46 --> Input Class Initialized
INFO - 2025-05-04 05:00:46 --> Language Class Initialized
INFO - 2025-05-04 05:00:46 --> Config Class Initialized
INFO - 2025-05-04 05:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:46 --> Loader Class Initialized
INFO - 2025-05-04 05:00:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:46 --> URI Class Initialized
INFO - 2025-05-04 05:00:46 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:46 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:46 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:46 --> Router Class Initialized
INFO - 2025-05-04 05:00:46 --> Output Class Initialized
INFO - 2025-05-04 05:00:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:46 --> Input Class Initialized
INFO - 2025-05-04 05:00:46 --> Language Class Initialized
INFO - 2025-05-04 05:00:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:47 --> Controller Class Initialized
INFO - 2025-05-04 13:00:47 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:00:47 --> Loader Class Initialized
INFO - 2025-05-04 13:00:47 --> Final output sent to browser
DEBUG - 2025-05-04 13:00:47 --> Total execution time: 0.3856
INFO - 2025-05-04 05:00:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:47 --> Controller Class Initialized
INFO - 2025-05-04 13:00:47 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:00:47 --> Config Class Initialized
INFO - 2025-05-04 05:00:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:00:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:00:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:00:47 --> URI Class Initialized
INFO - 2025-05-04 05:00:47 --> Router Class Initialized
INFO - 2025-05-04 05:00:47 --> Output Class Initialized
INFO - 2025-05-04 05:00:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:00:47 --> Input Class Initialized
INFO - 2025-05-04 05:00:47 --> Language Class Initialized
INFO - 2025-05-04 05:00:47 --> Loader Class Initialized
INFO - 2025-05-04 05:00:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:00:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:00:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:00:47 --> Controller Class Initialized
INFO - 2025-05-04 05:00:47 --> Model "UserModel" initialized
INFO - 2025-05-04 05:01:23 --> Config Class Initialized
INFO - 2025-05-04 05:01:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:01:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:01:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:01:23 --> URI Class Initialized
INFO - 2025-05-04 05:01:23 --> Router Class Initialized
INFO - 2025-05-04 05:01:23 --> Output Class Initialized
INFO - 2025-05-04 05:01:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:01:23 --> Input Class Initialized
INFO - 2025-05-04 05:01:23 --> Language Class Initialized
INFO - 2025-05-04 05:01:23 --> Loader Class Initialized
INFO - 2025-05-04 05:01:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:01:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:01:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:01:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:01:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:01:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:01:23 --> Controller Class Initialized
INFO - 2025-05-04 13:01:23 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:01:24 --> Config Class Initialized
INFO - 2025-05-04 05:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:01:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:01:24 --> URI Class Initialized
INFO - 2025-05-04 05:01:24 --> Router Class Initialized
INFO - 2025-05-04 05:01:24 --> Output Class Initialized
INFO - 2025-05-04 05:01:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:01:24 --> Input Class Initialized
INFO - 2025-05-04 05:01:24 --> Language Class Initialized
INFO - 2025-05-04 05:01:24 --> Loader Class Initialized
INFO - 2025-05-04 05:01:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:01:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:01:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:01:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:01:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:01:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:01:24 --> Controller Class Initialized
INFO - 2025-05-04 13:01:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:08 --> Config Class Initialized
INFO - 2025-05-04 05:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:08 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:08 --> URI Class Initialized
INFO - 2025-05-04 05:02:08 --> Router Class Initialized
INFO - 2025-05-04 05:02:08 --> Output Class Initialized
INFO - 2025-05-04 05:02:08 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:08 --> Input Class Initialized
INFO - 2025-05-04 05:02:09 --> Language Class Initialized
INFO - 2025-05-04 05:02:09 --> Loader Class Initialized
INFO - 2025-05-04 05:02:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:09 --> Controller Class Initialized
INFO - 2025-05-04 13:02:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:12 --> Config Class Initialized
INFO - 2025-05-04 05:02:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:12 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:12 --> URI Class Initialized
INFO - 2025-05-04 05:02:12 --> Router Class Initialized
INFO - 2025-05-04 05:02:12 --> Output Class Initialized
INFO - 2025-05-04 05:02:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:12 --> Input Class Initialized
INFO - 2025-05-04 05:02:12 --> Language Class Initialized
INFO - 2025-05-04 05:02:12 --> Loader Class Initialized
INFO - 2025-05-04 05:02:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:12 --> Controller Class Initialized
INFO - 2025-05-04 13:02:12 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:13 --> Config Class Initialized
INFO - 2025-05-04 05:02:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:13 --> URI Class Initialized
INFO - 2025-05-04 05:02:13 --> Router Class Initialized
INFO - 2025-05-04 05:02:13 --> Output Class Initialized
INFO - 2025-05-04 05:02:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:13 --> Input Class Initialized
INFO - 2025-05-04 05:02:13 --> Language Class Initialized
INFO - 2025-05-04 05:02:13 --> Loader Class Initialized
INFO - 2025-05-04 05:02:13 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:13 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:13 --> Controller Class Initialized
INFO - 2025-05-04 13:02:13 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:14 --> Config Class Initialized
INFO - 2025-05-04 05:02:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:14 --> URI Class Initialized
INFO - 2025-05-04 05:02:14 --> Router Class Initialized
INFO - 2025-05-04 05:02:14 --> Output Class Initialized
INFO - 2025-05-04 05:02:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:14 --> Input Class Initialized
INFO - 2025-05-04 05:02:14 --> Language Class Initialized
INFO - 2025-05-04 05:02:14 --> Loader Class Initialized
INFO - 2025-05-04 05:02:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:14 --> Controller Class Initialized
INFO - 2025-05-04 13:02:14 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:35 --> Config Class Initialized
INFO - 2025-05-04 05:02:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:35 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:35 --> URI Class Initialized
INFO - 2025-05-04 05:02:35 --> Router Class Initialized
INFO - 2025-05-04 05:02:35 --> Output Class Initialized
INFO - 2025-05-04 05:02:35 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:35 --> Input Class Initialized
INFO - 2025-05-04 05:02:35 --> Language Class Initialized
INFO - 2025-05-04 05:02:35 --> Loader Class Initialized
INFO - 2025-05-04 05:02:35 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:35 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:35 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:35 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:35 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:35 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:35 --> Controller Class Initialized
INFO - 2025-05-04 13:02:35 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:02:44 --> Config Class Initialized
INFO - 2025-05-04 05:02:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:02:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:02:44 --> Utf8 Class Initialized
INFO - 2025-05-04 05:02:44 --> URI Class Initialized
INFO - 2025-05-04 05:02:44 --> Router Class Initialized
INFO - 2025-05-04 05:02:44 --> Output Class Initialized
INFO - 2025-05-04 05:02:44 --> Security Class Initialized
DEBUG - 2025-05-04 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:02:44 --> Input Class Initialized
INFO - 2025-05-04 05:02:44 --> Language Class Initialized
INFO - 2025-05-04 05:02:44 --> Loader Class Initialized
INFO - 2025-05-04 05:02:44 --> Helper loaded: url_helper
INFO - 2025-05-04 05:02:44 --> Helper loaded: string_helper
INFO - 2025-05-04 05:02:44 --> Helper loaded: form_helper
INFO - 2025-05-04 05:02:44 --> Helper loaded: file_helper
INFO - 2025-05-04 05:02:44 --> Helper loaded: html_helper
INFO - 2025-05-04 05:02:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:02:44 --> Controller Class Initialized
INFO - 2025-05-04 13:02:44 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:03:47 --> Config Class Initialized
INFO - 2025-05-04 05:03:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:03:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:03:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:03:47 --> URI Class Initialized
INFO - 2025-05-04 05:03:47 --> Router Class Initialized
INFO - 2025-05-04 05:03:47 --> Output Class Initialized
INFO - 2025-05-04 05:03:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:03:47 --> Input Class Initialized
INFO - 2025-05-04 05:03:47 --> Language Class Initialized
INFO - 2025-05-04 05:03:47 --> Loader Class Initialized
INFO - 2025-05-04 05:03:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:03:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:03:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:03:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:03:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:03:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:03:47 --> Controller Class Initialized
INFO - 2025-05-04 13:03:47 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:03:52 --> Config Class Initialized
INFO - 2025-05-04 05:03:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:03:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:03:52 --> Utf8 Class Initialized
INFO - 2025-05-04 05:03:52 --> URI Class Initialized
INFO - 2025-05-04 05:03:52 --> Router Class Initialized
INFO - 2025-05-04 05:03:52 --> Output Class Initialized
INFO - 2025-05-04 05:03:52 --> Security Class Initialized
DEBUG - 2025-05-04 05:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:03:52 --> Input Class Initialized
INFO - 2025-05-04 05:03:52 --> Language Class Initialized
INFO - 2025-05-04 05:03:52 --> Loader Class Initialized
INFO - 2025-05-04 05:03:52 --> Helper loaded: url_helper
INFO - 2025-05-04 05:03:52 --> Helper loaded: string_helper
INFO - 2025-05-04 05:03:52 --> Helper loaded: form_helper
INFO - 2025-05-04 05:03:52 --> Helper loaded: file_helper
INFO - 2025-05-04 05:03:52 --> Helper loaded: html_helper
INFO - 2025-05-04 05:03:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:03:52 --> Controller Class Initialized
INFO - 2025-05-04 13:03:52 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:03:53 --> Config Class Initialized
INFO - 2025-05-04 05:03:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:03:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:03:53 --> Utf8 Class Initialized
INFO - 2025-05-04 05:03:53 --> URI Class Initialized
INFO - 2025-05-04 05:03:53 --> Router Class Initialized
INFO - 2025-05-04 05:03:53 --> Output Class Initialized
INFO - 2025-05-04 05:03:53 --> Security Class Initialized
DEBUG - 2025-05-04 05:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:03:53 --> Input Class Initialized
INFO - 2025-05-04 05:03:53 --> Language Class Initialized
INFO - 2025-05-04 05:03:53 --> Loader Class Initialized
INFO - 2025-05-04 05:03:53 --> Helper loaded: url_helper
INFO - 2025-05-04 05:03:53 --> Helper loaded: string_helper
INFO - 2025-05-04 05:03:53 --> Helper loaded: form_helper
INFO - 2025-05-04 05:03:53 --> Helper loaded: file_helper
INFO - 2025-05-04 05:03:53 --> Helper loaded: html_helper
INFO - 2025-05-04 05:03:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:03:53 --> Controller Class Initialized
INFO - 2025-05-04 13:03:53 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:03:54 --> Config Class Initialized
INFO - 2025-05-04 05:03:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:03:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:03:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:03:54 --> URI Class Initialized
INFO - 2025-05-04 05:03:54 --> Router Class Initialized
INFO - 2025-05-04 05:03:54 --> Output Class Initialized
INFO - 2025-05-04 05:03:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:03:54 --> Input Class Initialized
INFO - 2025-05-04 05:03:54 --> Language Class Initialized
INFO - 2025-05-04 05:03:54 --> Loader Class Initialized
INFO - 2025-05-04 05:03:54 --> Helper loaded: url_helper
INFO - 2025-05-04 05:03:54 --> Helper loaded: string_helper
INFO - 2025-05-04 05:03:54 --> Helper loaded: form_helper
INFO - 2025-05-04 05:03:54 --> Helper loaded: file_helper
INFO - 2025-05-04 05:03:54 --> Helper loaded: html_helper
INFO - 2025-05-04 05:03:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:03:54 --> Controller Class Initialized
INFO - 2025-05-04 13:03:54 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:04:12 --> Config Class Initialized
INFO - 2025-05-04 05:04:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:12 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:12 --> URI Class Initialized
INFO - 2025-05-04 05:04:12 --> Router Class Initialized
INFO - 2025-05-04 05:04:12 --> Output Class Initialized
INFO - 2025-05-04 05:04:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:12 --> Input Class Initialized
INFO - 2025-05-04 05:04:12 --> Language Class Initialized
INFO - 2025-05-04 05:04:12 --> Loader Class Initialized
INFO - 2025-05-04 05:04:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:12 --> Controller Class Initialized
INFO - 2025-05-04 05:04:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:04:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:04:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:04:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:04:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:04:12 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:12 --> Total execution time: 0.1269
INFO - 2025-05-04 05:04:14 --> Config Class Initialized
INFO - 2025-05-04 05:04:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:14 --> URI Class Initialized
INFO - 2025-05-04 05:04:14 --> Router Class Initialized
INFO - 2025-05-04 05:04:14 --> Output Class Initialized
INFO - 2025-05-04 05:04:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:14 --> Input Class Initialized
INFO - 2025-05-04 05:04:14 --> Language Class Initialized
INFO - 2025-05-04 05:04:14 --> Loader Class Initialized
INFO - 2025-05-04 05:04:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:14 --> Controller Class Initialized
INFO - 2025-05-04 05:04:14 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:04:14 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:14 --> Total execution time: 0.2052
INFO - 2025-05-04 05:04:25 --> Config Class Initialized
INFO - 2025-05-04 05:04:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:25 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:25 --> URI Class Initialized
INFO - 2025-05-04 05:04:25 --> Router Class Initialized
INFO - 2025-05-04 05:04:25 --> Output Class Initialized
INFO - 2025-05-04 05:04:25 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:25 --> Input Class Initialized
INFO - 2025-05-04 05:04:25 --> Language Class Initialized
INFO - 2025-05-04 05:04:25 --> Loader Class Initialized
INFO - 2025-05-04 05:04:25 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:25 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:25 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:25 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:25 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:25 --> Controller Class Initialized
INFO - 2025-05-04 05:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/add_storage_facility.php
INFO - 2025-05-04 05:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:04:25 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:25 --> Total execution time: 0.2686
INFO - 2025-05-04 05:04:27 --> Config Class Initialized
INFO - 2025-05-04 05:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:27 --> URI Class Initialized
INFO - 2025-05-04 05:04:27 --> Router Class Initialized
INFO - 2025-05-04 05:04:27 --> Output Class Initialized
INFO - 2025-05-04 05:04:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:27 --> Input Class Initialized
INFO - 2025-05-04 05:04:27 --> Language Class Initialized
INFO - 2025-05-04 05:04:27 --> Loader Class Initialized
INFO - 2025-05-04 05:04:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:27 --> Controller Class Initialized
INFO - 2025-05-04 13:04:27 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:04:33 --> Config Class Initialized
INFO - 2025-05-04 05:04:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:33 --> URI Class Initialized
INFO - 2025-05-04 05:04:33 --> Router Class Initialized
INFO - 2025-05-04 05:04:33 --> Output Class Initialized
INFO - 2025-05-04 05:04:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:33 --> Input Class Initialized
INFO - 2025-05-04 05:04:33 --> Language Class Initialized
INFO - 2025-05-04 05:04:33 --> Loader Class Initialized
INFO - 2025-05-04 05:04:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:33 --> Controller Class Initialized
INFO - 2025-05-04 05:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:04:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:04:33 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:33 --> Total execution time: 0.1031
INFO - 2025-05-04 05:04:35 --> Config Class Initialized
INFO - 2025-05-04 05:04:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:35 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:35 --> URI Class Initialized
INFO - 2025-05-04 05:04:35 --> Router Class Initialized
INFO - 2025-05-04 05:04:35 --> Output Class Initialized
INFO - 2025-05-04 05:04:35 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:35 --> Input Class Initialized
INFO - 2025-05-04 05:04:35 --> Language Class Initialized
INFO - 2025-05-04 05:04:35 --> Loader Class Initialized
INFO - 2025-05-04 05:04:35 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:35 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:35 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:35 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:35 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:35 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:35 --> Controller Class Initialized
INFO - 2025-05-04 05:04:35 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:04:35 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:35 --> Total execution time: 0.1892
INFO - 2025-05-04 05:04:37 --> Config Class Initialized
INFO - 2025-05-04 05:04:37 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:37 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:37 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:37 --> URI Class Initialized
INFO - 2025-05-04 05:04:37 --> Router Class Initialized
INFO - 2025-05-04 05:04:37 --> Output Class Initialized
INFO - 2025-05-04 05:04:37 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:37 --> Input Class Initialized
INFO - 2025-05-04 05:04:37 --> Language Class Initialized
INFO - 2025-05-04 05:04:37 --> Loader Class Initialized
INFO - 2025-05-04 05:04:37 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:37 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:37 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:38 --> Controller Class Initialized
INFO - 2025-05-04 05:04:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:04:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:04:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/add_storage_facility.php
INFO - 2025-05-04 05:04:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:04:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:04:38 --> Final output sent to browser
DEBUG - 2025-05-04 05:04:38 --> Total execution time: 0.1844
INFO - 2025-05-04 05:04:39 --> Config Class Initialized
INFO - 2025-05-04 05:04:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:04:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:04:39 --> Utf8 Class Initialized
INFO - 2025-05-04 05:04:39 --> URI Class Initialized
INFO - 2025-05-04 05:04:39 --> Router Class Initialized
INFO - 2025-05-04 05:04:39 --> Output Class Initialized
INFO - 2025-05-04 05:04:39 --> Security Class Initialized
DEBUG - 2025-05-04 05:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:04:39 --> Input Class Initialized
INFO - 2025-05-04 05:04:39 --> Language Class Initialized
INFO - 2025-05-04 05:04:39 --> Loader Class Initialized
INFO - 2025-05-04 05:04:39 --> Helper loaded: url_helper
INFO - 2025-05-04 05:04:39 --> Helper loaded: string_helper
INFO - 2025-05-04 05:04:39 --> Helper loaded: form_helper
INFO - 2025-05-04 05:04:39 --> Helper loaded: file_helper
INFO - 2025-05-04 05:04:39 --> Helper loaded: html_helper
INFO - 2025-05-04 05:04:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:04:39 --> Controller Class Initialized
INFO - 2025-05-04 13:04:39 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:03 --> Config Class Initialized
INFO - 2025-05-04 05:06:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:03 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:03 --> URI Class Initialized
INFO - 2025-05-04 05:06:03 --> Router Class Initialized
INFO - 2025-05-04 05:06:03 --> Output Class Initialized
INFO - 2025-05-04 05:06:03 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:03 --> Input Class Initialized
INFO - 2025-05-04 05:06:03 --> Language Class Initialized
INFO - 2025-05-04 05:06:03 --> Loader Class Initialized
INFO - 2025-05-04 05:06:03 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:03 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:03 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:03 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:03 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:03 --> Controller Class Initialized
INFO - 2025-05-04 05:06:03 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:03 --> Config Class Initialized
INFO - 2025-05-04 05:06:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:03 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:03 --> URI Class Initialized
INFO - 2025-05-04 05:06:04 --> Router Class Initialized
INFO - 2025-05-04 05:06:04 --> Output Class Initialized
INFO - 2025-05-04 05:06:04 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:04 --> Input Class Initialized
INFO - 2025-05-04 05:06:04 --> Language Class Initialized
INFO - 2025-05-04 05:06:04 --> Loader Class Initialized
INFO - 2025-05-04 05:06:04 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:04 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:04 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:04 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:04 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:04 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:04 --> Controller Class Initialized
INFO - 2025-05-04 13:06:04 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:06:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:06:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:06:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:06:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:06:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:06:04 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:04 --> Total execution time: 0.2078
INFO - 2025-05-04 05:06:06 --> Config Class Initialized
INFO - 2025-05-04 05:06:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:06 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:06 --> URI Class Initialized
INFO - 2025-05-04 05:06:06 --> Router Class Initialized
INFO - 2025-05-04 05:06:06 --> Output Class Initialized
INFO - 2025-05-04 05:06:06 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:06 --> Input Class Initialized
INFO - 2025-05-04 05:06:06 --> Language Class Initialized
INFO - 2025-05-04 05:06:06 --> Loader Class Initialized
INFO - 2025-05-04 05:06:06 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:06 --> Controller Class Initialized
INFO - 2025-05-04 05:06:06 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:06 --> Config Class Initialized
INFO - 2025-05-04 05:06:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:06 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:06 --> URI Class Initialized
INFO - 2025-05-04 05:06:06 --> Router Class Initialized
INFO - 2025-05-04 05:06:06 --> Output Class Initialized
INFO - 2025-05-04 05:06:06 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:06 --> Input Class Initialized
INFO - 2025-05-04 05:06:06 --> Language Class Initialized
INFO - 2025-05-04 05:06:06 --> Loader Class Initialized
INFO - 2025-05-04 05:06:06 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:06 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:06 --> Controller Class Initialized
INFO - 2025-05-04 13:06:06 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:06:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:06:06 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:06 --> Total execution time: 0.1987
INFO - 2025-05-04 05:06:09 --> Config Class Initialized
INFO - 2025-05-04 05:06:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:09 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:09 --> URI Class Initialized
INFO - 2025-05-04 05:06:09 --> Router Class Initialized
INFO - 2025-05-04 05:06:09 --> Output Class Initialized
INFO - 2025-05-04 05:06:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:09 --> Input Class Initialized
INFO - 2025-05-04 05:06:09 --> Language Class Initialized
INFO - 2025-05-04 05:06:09 --> Loader Class Initialized
INFO - 2025-05-04 05:06:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:09 --> Controller Class Initialized
INFO - 2025-05-04 05:06:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:09 --> Config Class Initialized
INFO - 2025-05-04 05:06:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:09 --> Controller Class Initialized
INFO - 2025-05-04 13:06:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:06:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:06:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:06:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:06:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:06:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:06:09 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:09 --> Total execution time: 0.1516
INFO - 2025-05-04 05:06:16 --> Config Class Initialized
INFO - 2025-05-04 05:06:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:16 --> URI Class Initialized
INFO - 2025-05-04 05:06:16 --> Router Class Initialized
INFO - 2025-05-04 05:06:16 --> Output Class Initialized
INFO - 2025-05-04 05:06:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:16 --> Input Class Initialized
INFO - 2025-05-04 05:06:16 --> Language Class Initialized
INFO - 2025-05-04 05:06:16 --> Loader Class Initialized
INFO - 2025-05-04 05:06:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:16 --> Controller Class Initialized
INFO - 2025-05-04 05:06:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:06:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:06:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:06:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:06:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:06:16 --> Final output sent to browser
DEBUG - 2025-05-04 05:06:16 --> Total execution time: 0.2369
INFO - 2025-05-04 05:06:17 --> Config Class Initialized
INFO - 2025-05-04 05:06:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:17 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:17 --> URI Class Initialized
INFO - 2025-05-04 05:06:17 --> Router Class Initialized
INFO - 2025-05-04 05:06:17 --> Output Class Initialized
INFO - 2025-05-04 05:06:17 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:17 --> Input Class Initialized
INFO - 2025-05-04 05:06:17 --> Language Class Initialized
INFO - 2025-05-04 05:06:17 --> Loader Class Initialized
INFO - 2025-05-04 05:06:17 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:17 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:17 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:17 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:17 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:17 --> Controller Class Initialized
INFO - 2025-05-04 13:06:17 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:18 --> Config Class Initialized
INFO - 2025-05-04 05:06:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:18 --> URI Class Initialized
INFO - 2025-05-04 05:06:18 --> Router Class Initialized
INFO - 2025-05-04 05:06:18 --> Output Class Initialized
INFO - 2025-05-04 05:06:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:18 --> Input Class Initialized
INFO - 2025-05-04 05:06:18 --> Language Class Initialized
INFO - 2025-05-04 05:06:18 --> Loader Class Initialized
INFO - 2025-05-04 05:06:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:18 --> Controller Class Initialized
INFO - 2025-05-04 13:06:18 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:06:18 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:18 --> Total execution time: 0.2973
INFO - 2025-05-04 05:06:18 --> Config Class Initialized
INFO - 2025-05-04 05:06:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:18 --> URI Class Initialized
INFO - 2025-05-04 05:06:18 --> Router Class Initialized
INFO - 2025-05-04 05:06:18 --> Output Class Initialized
INFO - 2025-05-04 05:06:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:18 --> Input Class Initialized
INFO - 2025-05-04 05:06:18 --> Language Class Initialized
INFO - 2025-05-04 05:06:18 --> Loader Class Initialized
INFO - 2025-05-04 05:06:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:18 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:18 --> Controller Class Initialized
INFO - 2025-05-04 05:06:18 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:19 --> Config Class Initialized
INFO - 2025-05-04 05:06:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:19 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:19 --> URI Class Initialized
INFO - 2025-05-04 05:06:19 --> Router Class Initialized
INFO - 2025-05-04 05:06:19 --> Output Class Initialized
INFO - 2025-05-04 05:06:19 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:19 --> Input Class Initialized
INFO - 2025-05-04 05:06:19 --> Language Class Initialized
INFO - 2025-05-04 05:06:19 --> Loader Class Initialized
INFO - 2025-05-04 05:06:19 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:19 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:19 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:19 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:19 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:19 --> Controller Class Initialized
INFO - 2025-05-04 13:06:19 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:06:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:06:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:06:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:06:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:06:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:06:19 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:19 --> Total execution time: 0.2520
INFO - 2025-05-04 05:06:36 --> Config Class Initialized
INFO - 2025-05-04 05:06:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:36 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:36 --> URI Class Initialized
INFO - 2025-05-04 05:06:36 --> Router Class Initialized
INFO - 2025-05-04 05:06:36 --> Output Class Initialized
INFO - 2025-05-04 05:06:36 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:36 --> Input Class Initialized
INFO - 2025-05-04 05:06:36 --> Language Class Initialized
INFO - 2025-05-04 05:06:36 --> Loader Class Initialized
INFO - 2025-05-04 05:06:36 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:36 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:36 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:36 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:36 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:36 --> Controller Class Initialized
INFO - 2025-05-04 05:06:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:06:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:06:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:06:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:06:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:06:36 --> Final output sent to browser
DEBUG - 2025-05-04 05:06:36 --> Total execution time: 0.1663
INFO - 2025-05-04 05:06:38 --> Config Class Initialized
INFO - 2025-05-04 05:06:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:38 --> URI Class Initialized
INFO - 2025-05-04 05:06:38 --> Router Class Initialized
INFO - 2025-05-04 05:06:38 --> Output Class Initialized
INFO - 2025-05-04 05:06:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:38 --> Input Class Initialized
INFO - 2025-05-04 05:06:38 --> Language Class Initialized
INFO - 2025-05-04 05:06:38 --> Loader Class Initialized
INFO - 2025-05-04 05:06:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:38 --> Controller Class Initialized
INFO - 2025-05-04 13:06:38 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:53 --> Config Class Initialized
INFO - 2025-05-04 05:06:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:53 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:53 --> URI Class Initialized
INFO - 2025-05-04 05:06:53 --> Router Class Initialized
INFO - 2025-05-04 05:06:53 --> Output Class Initialized
INFO - 2025-05-04 05:06:53 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:53 --> Input Class Initialized
INFO - 2025-05-04 05:06:53 --> Language Class Initialized
INFO - 2025-05-04 05:06:53 --> Loader Class Initialized
INFO - 2025-05-04 05:06:53 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:53 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:53 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:53 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:53 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:53 --> Controller Class Initialized
INFO - 2025-05-04 05:06:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:06:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:06:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:06:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:06:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:06:53 --> Final output sent to browser
DEBUG - 2025-05-04 05:06:53 --> Total execution time: 0.1782
INFO - 2025-05-04 05:06:55 --> Config Class Initialized
INFO - 2025-05-04 05:06:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:55 --> URI Class Initialized
INFO - 2025-05-04 05:06:55 --> Router Class Initialized
INFO - 2025-05-04 05:06:55 --> Output Class Initialized
INFO - 2025-05-04 05:06:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:55 --> Input Class Initialized
INFO - 2025-05-04 05:06:55 --> Language Class Initialized
INFO - 2025-05-04 05:06:55 --> Loader Class Initialized
INFO - 2025-05-04 05:06:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:55 --> Controller Class Initialized
INFO - 2025-05-04 13:06:55 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:06:55 --> Config Class Initialized
INFO - 2025-05-04 05:06:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:06:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:06:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:06:55 --> URI Class Initialized
INFO - 2025-05-04 05:06:55 --> Router Class Initialized
INFO - 2025-05-04 05:06:55 --> Output Class Initialized
INFO - 2025-05-04 05:06:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:06:55 --> Input Class Initialized
INFO - 2025-05-04 05:06:55 --> Language Class Initialized
INFO - 2025-05-04 05:06:55 --> Loader Class Initialized
INFO - 2025-05-04 05:06:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:06:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:06:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:06:55 --> Controller Class Initialized
INFO - 2025-05-04 13:06:55 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:06:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:06:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:06:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:06:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:06:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:06:56 --> Final output sent to browser
DEBUG - 2025-05-04 13:06:56 --> Total execution time: 0.3148
INFO - 2025-05-04 05:07:06 --> Config Class Initialized
INFO - 2025-05-04 05:07:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:06 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:06 --> URI Class Initialized
INFO - 2025-05-04 05:07:06 --> Router Class Initialized
INFO - 2025-05-04 05:07:06 --> Output Class Initialized
INFO - 2025-05-04 05:07:06 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:06 --> Input Class Initialized
INFO - 2025-05-04 05:07:06 --> Language Class Initialized
INFO - 2025-05-04 05:07:06 --> Loader Class Initialized
INFO - 2025-05-04 05:07:06 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:07 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:07 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:07 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:07 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:07 --> Controller Class Initialized
INFO - 2025-05-04 05:07:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:07:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:07:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:07:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:07:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:07:07 --> Final output sent to browser
DEBUG - 2025-05-04 05:07:07 --> Total execution time: 0.1661
INFO - 2025-05-04 05:07:08 --> Config Class Initialized
INFO - 2025-05-04 05:07:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:08 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:08 --> URI Class Initialized
INFO - 2025-05-04 05:07:08 --> Router Class Initialized
INFO - 2025-05-04 05:07:08 --> Output Class Initialized
INFO - 2025-05-04 05:07:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:09 --> Input Class Initialized
INFO - 2025-05-04 05:07:09 --> Language Class Initialized
INFO - 2025-05-04 05:07:09 --> Loader Class Initialized
INFO - 2025-05-04 05:07:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:09 --> Controller Class Initialized
INFO - 2025-05-04 13:07:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:07:09 --> Config Class Initialized
INFO - 2025-05-04 05:07:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:09 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:09 --> URI Class Initialized
INFO - 2025-05-04 05:07:09 --> Router Class Initialized
INFO - 2025-05-04 05:07:09 --> Output Class Initialized
INFO - 2025-05-04 05:07:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:09 --> Input Class Initialized
INFO - 2025-05-04 05:07:09 --> Language Class Initialized
INFO - 2025-05-04 05:07:09 --> Loader Class Initialized
INFO - 2025-05-04 05:07:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:09 --> Controller Class Initialized
INFO - 2025-05-04 13:07:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:07:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:07:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:07:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:07:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:07:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:07:09 --> Final output sent to browser
DEBUG - 2025-05-04 13:07:09 --> Total execution time: 0.2621
INFO - 2025-05-04 05:07:10 --> Config Class Initialized
INFO - 2025-05-04 05:07:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:10 --> URI Class Initialized
INFO - 2025-05-04 05:07:10 --> Router Class Initialized
INFO - 2025-05-04 05:07:10 --> Output Class Initialized
INFO - 2025-05-04 05:07:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:10 --> Input Class Initialized
INFO - 2025-05-04 05:07:10 --> Language Class Initialized
INFO - 2025-05-04 05:07:10 --> Loader Class Initialized
INFO - 2025-05-04 05:07:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:10 --> Controller Class Initialized
INFO - 2025-05-04 05:07:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:07:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:07:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:07:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:07:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:07:10 --> Final output sent to browser
DEBUG - 2025-05-04 05:07:10 --> Total execution time: 0.2269
INFO - 2025-05-04 05:07:13 --> Config Class Initialized
INFO - 2025-05-04 05:07:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:13 --> URI Class Initialized
INFO - 2025-05-04 05:07:13 --> Router Class Initialized
INFO - 2025-05-04 05:07:14 --> Output Class Initialized
INFO - 2025-05-04 05:07:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:14 --> Input Class Initialized
INFO - 2025-05-04 05:07:14 --> Language Class Initialized
INFO - 2025-05-04 05:07:14 --> Loader Class Initialized
INFO - 2025-05-04 05:07:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:14 --> Controller Class Initialized
INFO - 2025-05-04 13:07:14 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:07:14 --> Config Class Initialized
INFO - 2025-05-04 05:07:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:14 --> URI Class Initialized
INFO - 2025-05-04 05:07:14 --> Router Class Initialized
INFO - 2025-05-04 05:07:14 --> Output Class Initialized
INFO - 2025-05-04 05:07:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:14 --> Input Class Initialized
INFO - 2025-05-04 05:07:14 --> Language Class Initialized
INFO - 2025-05-04 05:07:14 --> Loader Class Initialized
INFO - 2025-05-04 05:07:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:14 --> Controller Class Initialized
INFO - 2025-05-04 13:07:14 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:07:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:07:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:07:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:07:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:07:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:07:14 --> Final output sent to browser
DEBUG - 2025-05-04 13:07:14 --> Total execution time: 0.1517
INFO - 2025-05-04 05:07:16 --> Config Class Initialized
INFO - 2025-05-04 05:07:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:16 --> URI Class Initialized
INFO - 2025-05-04 05:07:16 --> Router Class Initialized
INFO - 2025-05-04 05:07:16 --> Output Class Initialized
INFO - 2025-05-04 05:07:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:16 --> Input Class Initialized
INFO - 2025-05-04 05:07:16 --> Language Class Initialized
INFO - 2025-05-04 05:07:16 --> Loader Class Initialized
INFO - 2025-05-04 05:07:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:16 --> Controller Class Initialized
INFO - 2025-05-04 13:07:16 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:07:16 --> Config Class Initialized
INFO - 2025-05-04 05:07:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:16 --> URI Class Initialized
INFO - 2025-05-04 05:07:16 --> Router Class Initialized
INFO - 2025-05-04 05:07:16 --> Output Class Initialized
INFO - 2025-05-04 05:07:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:16 --> Input Class Initialized
INFO - 2025-05-04 05:07:16 --> Language Class Initialized
INFO - 2025-05-04 05:07:16 --> Loader Class Initialized
INFO - 2025-05-04 05:07:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:16 --> Controller Class Initialized
INFO - 2025-05-04 13:07:16 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:07:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:07:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:07:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:07:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:07:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:07:16 --> Final output sent to browser
DEBUG - 2025-05-04 13:07:16 --> Total execution time: 0.1716
INFO - 2025-05-04 05:07:48 --> Config Class Initialized
INFO - 2025-05-04 05:07:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:48 --> URI Class Initialized
INFO - 2025-05-04 05:07:48 --> Router Class Initialized
INFO - 2025-05-04 05:07:48 --> Output Class Initialized
INFO - 2025-05-04 05:07:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:48 --> Input Class Initialized
INFO - 2025-05-04 05:07:48 --> Language Class Initialized
INFO - 2025-05-04 05:07:48 --> Loader Class Initialized
INFO - 2025-05-04 05:07:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:48 --> Controller Class Initialized
INFO - 2025-05-04 05:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:07:48 --> Final output sent to browser
DEBUG - 2025-05-04 05:07:48 --> Total execution time: 0.2317
INFO - 2025-05-04 05:07:50 --> Config Class Initialized
INFO - 2025-05-04 05:07:50 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:07:50 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:07:50 --> Utf8 Class Initialized
INFO - 2025-05-04 05:07:50 --> URI Class Initialized
INFO - 2025-05-04 05:07:50 --> Router Class Initialized
INFO - 2025-05-04 05:07:50 --> Output Class Initialized
INFO - 2025-05-04 05:07:50 --> Security Class Initialized
DEBUG - 2025-05-04 05:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:07:50 --> Input Class Initialized
INFO - 2025-05-04 05:07:50 --> Language Class Initialized
INFO - 2025-05-04 05:07:50 --> Loader Class Initialized
INFO - 2025-05-04 05:07:50 --> Helper loaded: url_helper
INFO - 2025-05-04 05:07:50 --> Helper loaded: string_helper
INFO - 2025-05-04 05:07:50 --> Helper loaded: form_helper
INFO - 2025-05-04 05:07:50 --> Helper loaded: file_helper
INFO - 2025-05-04 05:07:50 --> Helper loaded: html_helper
INFO - 2025-05-04 05:07:50 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:07:50 --> Controller Class Initialized
INFO - 2025-05-04 13:07:50 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:08:10 --> Config Class Initialized
INFO - 2025-05-04 05:08:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:10 --> URI Class Initialized
INFO - 2025-05-04 05:08:10 --> Router Class Initialized
INFO - 2025-05-04 05:08:10 --> Output Class Initialized
INFO - 2025-05-04 05:08:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:10 --> Input Class Initialized
INFO - 2025-05-04 05:08:10 --> Language Class Initialized
INFO - 2025-05-04 05:08:10 --> Loader Class Initialized
INFO - 2025-05-04 05:08:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:10 --> Controller Class Initialized
INFO - 2025-05-04 05:08:10 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:08:10 --> Config Class Initialized
INFO - 2025-05-04 05:08:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:10 --> URI Class Initialized
INFO - 2025-05-04 05:08:10 --> Router Class Initialized
INFO - 2025-05-04 05:08:10 --> Output Class Initialized
INFO - 2025-05-04 05:08:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:10 --> Input Class Initialized
INFO - 2025-05-04 05:08:10 --> Language Class Initialized
INFO - 2025-05-04 05:08:10 --> Loader Class Initialized
INFO - 2025-05-04 05:08:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:10 --> Controller Class Initialized
INFO - 2025-05-04 13:08:10 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:08:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:08:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:08:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:08:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:08:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:08:10 --> Final output sent to browser
DEBUG - 2025-05-04 13:08:10 --> Total execution time: 0.1062
INFO - 2025-05-04 05:08:22 --> Config Class Initialized
INFO - 2025-05-04 05:08:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:22 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:22 --> URI Class Initialized
INFO - 2025-05-04 05:08:22 --> Router Class Initialized
INFO - 2025-05-04 05:08:22 --> Output Class Initialized
INFO - 2025-05-04 05:08:22 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:22 --> Input Class Initialized
INFO - 2025-05-04 05:08:22 --> Language Class Initialized
INFO - 2025-05-04 05:08:23 --> Loader Class Initialized
INFO - 2025-05-04 05:08:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:24 --> Controller Class Initialized
INFO - 2025-05-04 05:08:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:08:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:08:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:08:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:08:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:08:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:08:24 --> Final output sent to browser
DEBUG - 2025-05-04 05:08:24 --> Total execution time: 1.7570
INFO - 2025-05-04 05:08:25 --> Config Class Initialized
INFO - 2025-05-04 05:08:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:25 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:25 --> URI Class Initialized
INFO - 2025-05-04 05:08:25 --> Router Class Initialized
INFO - 2025-05-04 05:08:25 --> Output Class Initialized
INFO - 2025-05-04 05:08:25 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:25 --> Input Class Initialized
INFO - 2025-05-04 05:08:25 --> Language Class Initialized
INFO - 2025-05-04 05:08:25 --> Loader Class Initialized
INFO - 2025-05-04 05:08:25 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:25 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:25 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:25 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:25 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:25 --> Controller Class Initialized
INFO - 2025-05-04 05:08:25 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:08:25 --> Final output sent to browser
DEBUG - 2025-05-04 05:08:25 --> Total execution time: 0.3684
INFO - 2025-05-04 05:08:29 --> Config Class Initialized
INFO - 2025-05-04 05:08:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:29 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:29 --> URI Class Initialized
INFO - 2025-05-04 05:08:29 --> Router Class Initialized
INFO - 2025-05-04 05:08:29 --> Output Class Initialized
INFO - 2025-05-04 05:08:29 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:29 --> Input Class Initialized
INFO - 2025-05-04 05:08:29 --> Language Class Initialized
INFO - 2025-05-04 05:08:29 --> Loader Class Initialized
INFO - 2025-05-04 05:08:29 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:29 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:29 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:29 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:29 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:29 --> Controller Class Initialized
INFO - 2025-05-04 13:08:29 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:08:47 --> Config Class Initialized
INFO - 2025-05-04 05:08:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:47 --> URI Class Initialized
INFO - 2025-05-04 05:08:47 --> Router Class Initialized
INFO - 2025-05-04 05:08:47 --> Output Class Initialized
INFO - 2025-05-04 05:08:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:47 --> Input Class Initialized
INFO - 2025-05-04 05:08:47 --> Language Class Initialized
INFO - 2025-05-04 05:08:48 --> Loader Class Initialized
INFO - 2025-05-04 05:08:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:48 --> Controller Class Initialized
INFO - 2025-05-04 05:08:48 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:08:48 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 150
INFO - 2025-05-04 05:08:48 --> Config Class Initialized
INFO - 2025-05-04 05:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:48 --> URI Class Initialized
INFO - 2025-05-04 05:08:48 --> Router Class Initialized
INFO - 2025-05-04 05:08:48 --> Output Class Initialized
INFO - 2025-05-04 05:08:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:48 --> Input Class Initialized
INFO - 2025-05-04 05:08:48 --> Language Class Initialized
INFO - 2025-05-04 05:08:48 --> Loader Class Initialized
INFO - 2025-05-04 05:08:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:48 --> Controller Class Initialized
INFO - 2025-05-04 13:08:48 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:08:48 --> Final output sent to browser
DEBUG - 2025-05-04 13:08:48 --> Total execution time: 0.1536
INFO - 2025-05-04 05:08:56 --> Config Class Initialized
INFO - 2025-05-04 05:08:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:56 --> URI Class Initialized
INFO - 2025-05-04 05:08:56 --> Router Class Initialized
INFO - 2025-05-04 05:08:56 --> Output Class Initialized
INFO - 2025-05-04 05:08:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:56 --> Input Class Initialized
INFO - 2025-05-04 05:08:56 --> Language Class Initialized
INFO - 2025-05-04 05:08:56 --> Loader Class Initialized
INFO - 2025-05-04 05:08:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:56 --> Controller Class Initialized
INFO - 2025-05-04 13:08:56 --> Model "BankModel" initialized
INFO - 2025-05-04 05:08:56 --> Config Class Initialized
INFO - 2025-05-04 05:08:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:08:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:08:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:08:56 --> URI Class Initialized
INFO - 2025-05-04 05:08:56 --> Router Class Initialized
INFO - 2025-05-04 05:08:56 --> Output Class Initialized
INFO - 2025-05-04 05:08:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:08:56 --> Input Class Initialized
INFO - 2025-05-04 05:08:57 --> Language Class Initialized
INFO - 2025-05-04 05:08:57 --> Loader Class Initialized
INFO - 2025-05-04 05:08:57 --> Helper loaded: url_helper
INFO - 2025-05-04 05:08:57 --> Helper loaded: string_helper
INFO - 2025-05-04 05:08:57 --> Helper loaded: form_helper
INFO - 2025-05-04 05:08:57 --> Helper loaded: file_helper
INFO - 2025-05-04 05:08:57 --> Helper loaded: html_helper
INFO - 2025-05-04 05:08:57 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:08:57 --> Controller Class Initialized
INFO - 2025-05-04 13:08:57 --> Model "BankModel" initialized
INFO - 2025-05-04 13:08:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:08:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:08:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-04 13:08:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:08:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:08:57 --> Final output sent to browser
DEBUG - 2025-05-04 13:08:57 --> Total execution time: 0.2872
INFO - 2025-05-04 05:09:00 --> Config Class Initialized
INFO - 2025-05-04 05:09:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:00 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:00 --> URI Class Initialized
INFO - 2025-05-04 05:09:00 --> Router Class Initialized
INFO - 2025-05-04 05:09:00 --> Output Class Initialized
INFO - 2025-05-04 05:09:00 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:00 --> Input Class Initialized
INFO - 2025-05-04 05:09:00 --> Language Class Initialized
INFO - 2025-05-04 05:09:00 --> Loader Class Initialized
INFO - 2025-05-04 05:09:00 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:00 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:00 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:00 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:00 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:00 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:00 --> Controller Class Initialized
INFO - 2025-05-04 05:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:09:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:09:00 --> Final output sent to browser
DEBUG - 2025-05-04 05:09:00 --> Total execution time: 0.1339
INFO - 2025-05-04 05:09:01 --> Config Class Initialized
INFO - 2025-05-04 05:09:01 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:01 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:01 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:01 --> URI Class Initialized
INFO - 2025-05-04 05:09:01 --> Router Class Initialized
INFO - 2025-05-04 05:09:01 --> Output Class Initialized
INFO - 2025-05-04 05:09:01 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:01 --> Input Class Initialized
INFO - 2025-05-04 05:09:01 --> Language Class Initialized
INFO - 2025-05-04 05:09:01 --> Loader Class Initialized
INFO - 2025-05-04 05:09:01 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:01 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:01 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:01 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:01 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:01 --> Controller Class Initialized
INFO - 2025-05-04 13:09:01 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:15 --> Config Class Initialized
INFO - 2025-05-04 05:09:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:15 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:15 --> URI Class Initialized
INFO - 2025-05-04 05:09:15 --> Router Class Initialized
INFO - 2025-05-04 05:09:15 --> Output Class Initialized
INFO - 2025-05-04 05:09:15 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:15 --> Input Class Initialized
INFO - 2025-05-04 05:09:15 --> Language Class Initialized
INFO - 2025-05-04 05:09:15 --> Loader Class Initialized
INFO - 2025-05-04 05:09:15 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:15 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:15 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:15 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:15 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:15 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:15 --> Controller Class Initialized
INFO - 2025-05-04 05:09:15 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:09:15 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:09:16 --> Config Class Initialized
INFO - 2025-05-04 05:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:16 --> URI Class Initialized
INFO - 2025-05-04 05:09:16 --> Router Class Initialized
INFO - 2025-05-04 05:09:16 --> Output Class Initialized
INFO - 2025-05-04 05:09:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:16 --> Input Class Initialized
INFO - 2025-05-04 05:09:16 --> Language Class Initialized
INFO - 2025-05-04 05:09:16 --> Loader Class Initialized
INFO - 2025-05-04 05:09:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:16 --> Controller Class Initialized
INFO - 2025-05-04 13:09:16 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:09:16 --> Final output sent to browser
DEBUG - 2025-05-04 13:09:16 --> Total execution time: 0.1786
INFO - 2025-05-04 05:09:22 --> Config Class Initialized
INFO - 2025-05-04 05:09:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:23 --> URI Class Initialized
INFO - 2025-05-04 05:09:23 --> Router Class Initialized
INFO - 2025-05-04 05:09:23 --> Output Class Initialized
INFO - 2025-05-04 05:09:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:23 --> Input Class Initialized
INFO - 2025-05-04 05:09:23 --> Language Class Initialized
INFO - 2025-05-04 05:09:23 --> Loader Class Initialized
INFO - 2025-05-04 05:09:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:23 --> Controller Class Initialized
INFO - 2025-05-04 05:09:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:09:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:09:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-04 05:09:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:09:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:09:23 --> Final output sent to browser
DEBUG - 2025-05-04 05:09:23 --> Total execution time: 0.1690
INFO - 2025-05-04 05:09:24 --> Config Class Initialized
INFO - 2025-05-04 05:09:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:24 --> URI Class Initialized
INFO - 2025-05-04 05:09:24 --> Router Class Initialized
INFO - 2025-05-04 05:09:24 --> Output Class Initialized
INFO - 2025-05-04 05:09:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:24 --> Input Class Initialized
INFO - 2025-05-04 05:09:24 --> Language Class Initialized
INFO - 2025-05-04 05:09:24 --> Loader Class Initialized
INFO - 2025-05-04 05:09:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:25 --> Controller Class Initialized
INFO - 2025-05-04 13:09:25 --> Model "UserModel" initialized
INFO - 2025-05-04 13:09:25 --> Final output sent to browser
DEBUG - 2025-05-04 13:09:25 --> Total execution time: 0.3164
INFO - 2025-05-04 05:09:26 --> Config Class Initialized
INFO - 2025-05-04 05:09:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:26 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:26 --> URI Class Initialized
INFO - 2025-05-04 05:09:26 --> Router Class Initialized
INFO - 2025-05-04 05:09:26 --> Output Class Initialized
INFO - 2025-05-04 05:09:26 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:26 --> Input Class Initialized
INFO - 2025-05-04 05:09:26 --> Language Class Initialized
INFO - 2025-05-04 05:09:26 --> Loader Class Initialized
INFO - 2025-05-04 05:09:26 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:26 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:26 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:26 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:26 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:26 --> Controller Class Initialized
INFO - 2025-05-04 05:09:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:09:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:09:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:09:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:09:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:09:26 --> Final output sent to browser
DEBUG - 2025-05-04 05:09:26 --> Total execution time: 0.1816
INFO - 2025-05-04 05:09:28 --> Config Class Initialized
INFO - 2025-05-04 05:09:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:28 --> URI Class Initialized
INFO - 2025-05-04 05:09:28 --> Router Class Initialized
INFO - 2025-05-04 05:09:28 --> Output Class Initialized
INFO - 2025-05-04 05:09:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:28 --> Input Class Initialized
INFO - 2025-05-04 05:09:28 --> Language Class Initialized
INFO - 2025-05-04 05:09:28 --> Loader Class Initialized
INFO - 2025-05-04 05:09:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:28 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:28 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:28 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:28 --> Config Class Initialized
INFO - 2025-05-04 05:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:28 --> Hooks Class Initialized
INFO - 2025-05-04 05:09:28 --> Controller Class Initialized
INFO - 2025-05-04 13:09:28 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:09:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:28 --> URI Class Initialized
INFO - 2025-05-04 05:09:28 --> Router Class Initialized
INFO - 2025-05-04 05:09:28 --> Output Class Initialized
INFO - 2025-05-04 05:09:29 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:29 --> Input Class Initialized
INFO - 2025-05-04 05:09:29 --> Language Class Initialized
INFO - 2025-05-04 05:09:29 --> Loader Class Initialized
INFO - 2025-05-04 05:09:29 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:29 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:29 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:29 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:29 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:29 --> Controller Class Initialized
INFO - 2025-05-04 13:09:29 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:09:29 --> Final output sent to browser
DEBUG - 2025-05-04 13:09:29 --> Total execution time: 0.2828
INFO - 2025-05-04 05:09:30 --> Config Class Initialized
INFO - 2025-05-04 05:09:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:30 --> URI Class Initialized
INFO - 2025-05-04 05:09:30 --> Router Class Initialized
INFO - 2025-05-04 05:09:30 --> Output Class Initialized
INFO - 2025-05-04 05:09:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:30 --> Input Class Initialized
INFO - 2025-05-04 05:09:30 --> Language Class Initialized
INFO - 2025-05-04 05:09:30 --> Loader Class Initialized
INFO - 2025-05-04 05:09:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:30 --> Controller Class Initialized
INFO - 2025-05-04 05:09:30 --> Model "UserModel" initialized
INFO - 2025-05-04 05:09:32 --> Config Class Initialized
INFO - 2025-05-04 05:09:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:32 --> URI Class Initialized
INFO - 2025-05-04 05:09:33 --> Router Class Initialized
INFO - 2025-05-04 05:09:33 --> Output Class Initialized
INFO - 2025-05-04 05:09:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:33 --> Input Class Initialized
INFO - 2025-05-04 05:09:33 --> Language Class Initialized
INFO - 2025-05-04 05:09:33 --> Loader Class Initialized
INFO - 2025-05-04 05:09:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:33 --> Controller Class Initialized
INFO - 2025-05-04 13:09:33 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:34 --> Config Class Initialized
INFO - 2025-05-04 05:09:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:34 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:34 --> URI Class Initialized
INFO - 2025-05-04 05:09:34 --> Router Class Initialized
INFO - 2025-05-04 05:09:34 --> Output Class Initialized
INFO - 2025-05-04 05:09:34 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:34 --> Input Class Initialized
INFO - 2025-05-04 05:09:34 --> Language Class Initialized
INFO - 2025-05-04 05:09:34 --> Loader Class Initialized
INFO - 2025-05-04 05:09:34 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:34 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:34 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:34 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:34 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:34 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:34 --> Controller Class Initialized
INFO - 2025-05-04 13:09:34 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:36 --> Config Class Initialized
INFO - 2025-05-04 05:09:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:36 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:36 --> URI Class Initialized
INFO - 2025-05-04 05:09:36 --> Router Class Initialized
INFO - 2025-05-04 05:09:36 --> Output Class Initialized
INFO - 2025-05-04 05:09:36 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:36 --> Input Class Initialized
INFO - 2025-05-04 05:09:36 --> Language Class Initialized
INFO - 2025-05-04 05:09:36 --> Loader Class Initialized
INFO - 2025-05-04 05:09:36 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:36 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:36 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:36 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:36 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:36 --> Controller Class Initialized
INFO - 2025-05-04 13:09:36 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:38 --> Config Class Initialized
INFO - 2025-05-04 05:09:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:38 --> URI Class Initialized
INFO - 2025-05-04 05:09:38 --> Router Class Initialized
INFO - 2025-05-04 05:09:38 --> Output Class Initialized
INFO - 2025-05-04 05:09:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:38 --> Input Class Initialized
INFO - 2025-05-04 05:09:38 --> Language Class Initialized
INFO - 2025-05-04 05:09:38 --> Loader Class Initialized
INFO - 2025-05-04 05:09:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:38 --> Controller Class Initialized
INFO - 2025-05-04 05:09:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:09:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:09:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:09:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:09:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:09:38 --> Final output sent to browser
DEBUG - 2025-05-04 05:09:38 --> Total execution time: 0.4769
INFO - 2025-05-04 05:09:39 --> Config Class Initialized
INFO - 2025-05-04 05:09:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:39 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:39 --> URI Class Initialized
INFO - 2025-05-04 05:09:39 --> Router Class Initialized
INFO - 2025-05-04 05:09:39 --> Output Class Initialized
INFO - 2025-05-04 05:09:39 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:39 --> Input Class Initialized
INFO - 2025-05-04 05:09:39 --> Language Class Initialized
INFO - 2025-05-04 05:09:39 --> Loader Class Initialized
INFO - 2025-05-04 05:09:39 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:39 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:39 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:39 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:39 --> Config Class Initialized
INFO - 2025-05-04 05:09:39 --> Hooks Class Initialized
INFO - 2025-05-04 05:09:39 --> Helper loaded: html_helper
DEBUG - 2025-05-04 05:09:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:39 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:39 --> Database Driver Class Initialized
INFO - 2025-05-04 05:09:39 --> URI Class Initialized
INFO - 2025-05-04 05:09:39 --> Router Class Initialized
INFO - 2025-05-04 05:09:39 --> Output Class Initialized
DEBUG - 2025-05-04 05:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:39 --> Security Class Initialized
INFO - 2025-05-04 05:09:39 --> Controller Class Initialized
INFO - 2025-05-04 13:09:39 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:39 --> Input Class Initialized
INFO - 2025-05-04 05:09:39 --> Language Class Initialized
INFO - 2025-05-04 05:09:39 --> Loader Class Initialized
INFO - 2025-05-04 05:09:39 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:40 --> Controller Class Initialized
INFO - 2025-05-04 13:09:40 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:09:40 --> Final output sent to browser
DEBUG - 2025-05-04 13:09:40 --> Total execution time: 0.2101
INFO - 2025-05-04 05:09:40 --> Config Class Initialized
INFO - 2025-05-04 05:09:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:40 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:40 --> URI Class Initialized
INFO - 2025-05-04 05:09:40 --> Router Class Initialized
INFO - 2025-05-04 05:09:40 --> Output Class Initialized
INFO - 2025-05-04 05:09:40 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:40 --> Input Class Initialized
INFO - 2025-05-04 05:09:40 --> Language Class Initialized
INFO - 2025-05-04 05:09:40 --> Loader Class Initialized
INFO - 2025-05-04 05:09:40 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:40 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:40 --> Controller Class Initialized
INFO - 2025-05-04 05:09:40 --> Model "UserModel" initialized
INFO - 2025-05-04 05:09:44 --> Config Class Initialized
INFO - 2025-05-04 05:09:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:44 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:44 --> URI Class Initialized
INFO - 2025-05-04 05:09:44 --> Router Class Initialized
INFO - 2025-05-04 05:09:44 --> Output Class Initialized
INFO - 2025-05-04 05:09:44 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:44 --> Input Class Initialized
INFO - 2025-05-04 05:09:44 --> Language Class Initialized
INFO - 2025-05-04 05:09:44 --> Loader Class Initialized
INFO - 2025-05-04 05:09:44 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:44 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:44 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:44 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:44 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:44 --> Controller Class Initialized
INFO - 2025-05-04 13:09:44 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:45 --> Config Class Initialized
INFO - 2025-05-04 05:09:45 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:45 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:45 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:45 --> URI Class Initialized
INFO - 2025-05-04 05:09:45 --> Router Class Initialized
INFO - 2025-05-04 05:09:45 --> Output Class Initialized
INFO - 2025-05-04 05:09:45 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:45 --> Input Class Initialized
INFO - 2025-05-04 05:09:45 --> Language Class Initialized
INFO - 2025-05-04 05:09:45 --> Loader Class Initialized
INFO - 2025-05-04 05:09:45 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:45 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:45 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:45 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:45 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:45 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:45 --> Controller Class Initialized
INFO - 2025-05-04 13:09:45 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:46 --> Config Class Initialized
INFO - 2025-05-04 05:09:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:46 --> URI Class Initialized
INFO - 2025-05-04 05:09:46 --> Router Class Initialized
INFO - 2025-05-04 05:09:46 --> Output Class Initialized
INFO - 2025-05-04 05:09:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:46 --> Input Class Initialized
INFO - 2025-05-04 05:09:46 --> Language Class Initialized
INFO - 2025-05-04 05:09:46 --> Loader Class Initialized
INFO - 2025-05-04 05:09:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:46 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:46 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:46 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:46 --> Controller Class Initialized
INFO - 2025-05-04 13:09:46 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:09:54 --> Config Class Initialized
INFO - 2025-05-04 05:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:54 --> URI Class Initialized
INFO - 2025-05-04 05:09:54 --> Router Class Initialized
INFO - 2025-05-04 05:09:54 --> Output Class Initialized
INFO - 2025-05-04 05:09:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:54 --> Input Class Initialized
INFO - 2025-05-04 05:09:54 --> Language Class Initialized
INFO - 2025-05-04 05:09:54 --> Loader Class Initialized
INFO - 2025-05-04 05:09:54 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:54 --> Controller Class Initialized
INFO - 2025-05-04 05:09:54 --> Config Class Initialized
INFO - 2025-05-04 05:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:09:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:09:54 --> URI Class Initialized
DEBUG - 2025-05-04 05:09:54 --> No URI present. Default controller set.
INFO - 2025-05-04 05:09:54 --> Router Class Initialized
INFO - 2025-05-04 05:09:54 --> Output Class Initialized
INFO - 2025-05-04 05:09:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:09:54 --> Input Class Initialized
INFO - 2025-05-04 05:09:54 --> Language Class Initialized
INFO - 2025-05-04 05:09:54 --> Loader Class Initialized
INFO - 2025-05-04 05:09:54 --> Helper loaded: url_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: string_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: form_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: file_helper
INFO - 2025-05-04 05:09:54 --> Helper loaded: html_helper
INFO - 2025-05-04 05:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:09:54 --> Controller Class Initialized
INFO - 2025-05-04 05:09:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:09:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:09:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 05:09:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:09:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:09:54 --> Final output sent to browser
DEBUG - 2025-05-04 05:09:54 --> Total execution time: 0.1647
INFO - 2025-05-04 05:10:05 --> Config Class Initialized
INFO - 2025-05-04 05:10:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:05 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:05 --> URI Class Initialized
INFO - 2025-05-04 05:10:05 --> Router Class Initialized
INFO - 2025-05-04 05:10:06 --> Output Class Initialized
INFO - 2025-05-04 05:10:06 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:06 --> Input Class Initialized
INFO - 2025-05-04 05:10:06 --> Language Class Initialized
INFO - 2025-05-04 05:10:06 --> Loader Class Initialized
INFO - 2025-05-04 05:10:06 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:06 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:06 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:06 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:06 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:06 --> Controller Class Initialized
INFO - 2025-05-04 13:10:06 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:10:17 --> Config Class Initialized
INFO - 2025-05-04 05:10:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:17 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:17 --> URI Class Initialized
INFO - 2025-05-04 05:10:17 --> Router Class Initialized
INFO - 2025-05-04 05:10:17 --> Output Class Initialized
INFO - 2025-05-04 05:10:17 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:17 --> Input Class Initialized
INFO - 2025-05-04 05:10:17 --> Language Class Initialized
INFO - 2025-05-04 05:10:17 --> Loader Class Initialized
INFO - 2025-05-04 05:10:17 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:17 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:17 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:17 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:17 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:17 --> Controller Class Initialized
INFO - 2025-05-04 13:10:17 --> Model "UserModel" initialized
INFO - 2025-05-04 05:10:18 --> Config Class Initialized
INFO - 2025-05-04 05:10:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:18 --> URI Class Initialized
DEBUG - 2025-05-04 05:10:18 --> No URI present. Default controller set.
INFO - 2025-05-04 05:10:18 --> Router Class Initialized
INFO - 2025-05-04 05:10:18 --> Output Class Initialized
INFO - 2025-05-04 05:10:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:18 --> Input Class Initialized
INFO - 2025-05-04 05:10:18 --> Language Class Initialized
INFO - 2025-05-04 05:10:18 --> Loader Class Initialized
INFO - 2025-05-04 05:10:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:18 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:18 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:18 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:18 --> Controller Class Initialized
INFO - 2025-05-04 05:10:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 05:10:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:18 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:18 --> Total execution time: 0.1219
INFO - 2025-05-04 05:10:19 --> Config Class Initialized
INFO - 2025-05-04 05:10:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:19 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:19 --> URI Class Initialized
INFO - 2025-05-04 05:10:19 --> Router Class Initialized
INFO - 2025-05-04 05:10:19 --> Output Class Initialized
INFO - 2025-05-04 05:10:19 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:19 --> Input Class Initialized
INFO - 2025-05-04 05:10:19 --> Language Class Initialized
INFO - 2025-05-04 05:10:19 --> Loader Class Initialized
INFO - 2025-05-04 05:10:19 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:19 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:19 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:19 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:19 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:19 --> Controller Class Initialized
INFO - 2025-05-04 13:10:19 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:10:20 --> Config Class Initialized
INFO - 2025-05-04 05:10:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:20 --> URI Class Initialized
INFO - 2025-05-04 05:10:20 --> Router Class Initialized
INFO - 2025-05-04 05:10:20 --> Output Class Initialized
INFO - 2025-05-04 05:10:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:20 --> Input Class Initialized
INFO - 2025-05-04 05:10:20 --> Language Class Initialized
INFO - 2025-05-04 05:10:20 --> Loader Class Initialized
INFO - 2025-05-04 05:10:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:20 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:20 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:20 --> Controller Class Initialized
INFO - 2025-05-04 05:10:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-04 05:10:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:20 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:20 --> Total execution time: 0.4672
INFO - 2025-05-04 05:10:21 --> Config Class Initialized
INFO - 2025-05-04 05:10:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:21 --> URI Class Initialized
INFO - 2025-05-04 05:10:21 --> Router Class Initialized
INFO - 2025-05-04 05:10:21 --> Output Class Initialized
INFO - 2025-05-04 05:10:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:21 --> Input Class Initialized
INFO - 2025-05-04 05:10:21 --> Language Class Initialized
INFO - 2025-05-04 05:10:21 --> Loader Class Initialized
INFO - 2025-05-04 05:10:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:21 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:21 --> Controller Class Initialized
INFO - 2025-05-04 13:10:21 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:21 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:21 --> Total execution time: 0.1852
INFO - 2025-05-04 05:10:23 --> Config Class Initialized
INFO - 2025-05-04 05:10:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:23 --> URI Class Initialized
INFO - 2025-05-04 05:10:23 --> Router Class Initialized
INFO - 2025-05-04 05:10:23 --> Output Class Initialized
INFO - 2025-05-04 05:10:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:23 --> Input Class Initialized
INFO - 2025-05-04 05:10:23 --> Language Class Initialized
INFO - 2025-05-04 05:10:23 --> Loader Class Initialized
INFO - 2025-05-04 05:10:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:23 --> Controller Class Initialized
INFO - 2025-05-04 05:10:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/account.php
INFO - 2025-05-04 05:10:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:23 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:23 --> Total execution time: 0.2030
INFO - 2025-05-04 05:10:23 --> Config Class Initialized
INFO - 2025-05-04 05:10:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:23 --> URI Class Initialized
INFO - 2025-05-04 05:10:23 --> Router Class Initialized
INFO - 2025-05-04 05:10:23 --> Output Class Initialized
INFO - 2025-05-04 05:10:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:23 --> Input Class Initialized
INFO - 2025-05-04 05:10:23 --> Language Class Initialized
INFO - 2025-05-04 05:10:23 --> Loader Class Initialized
INFO - 2025-05-04 05:10:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:23 --> Controller Class Initialized
INFO - 2025-05-04 13:10:23 --> Model "UserModel" initialized
INFO - 2025-05-04 13:10:23 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:23 --> Total execution time: 0.1398
INFO - 2025-05-04 05:10:24 --> Config Class Initialized
INFO - 2025-05-04 05:10:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:24 --> URI Class Initialized
INFO - 2025-05-04 05:10:24 --> Router Class Initialized
INFO - 2025-05-04 05:10:24 --> Output Class Initialized
INFO - 2025-05-04 05:10:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:24 --> Input Class Initialized
INFO - 2025-05-04 05:10:24 --> Language Class Initialized
INFO - 2025-05-04 05:10:24 --> Loader Class Initialized
INFO - 2025-05-04 05:10:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:24 --> Controller Class Initialized
INFO - 2025-05-04 05:10:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/index.php
INFO - 2025-05-04 05:10:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:24 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:24 --> Total execution time: 0.1397
INFO - 2025-05-04 05:10:24 --> Config Class Initialized
INFO - 2025-05-04 05:10:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:24 --> URI Class Initialized
INFO - 2025-05-04 05:10:24 --> Router Class Initialized
INFO - 2025-05-04 05:10:24 --> Output Class Initialized
INFO - 2025-05-04 05:10:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:24 --> Input Class Initialized
INFO - 2025-05-04 05:10:24 --> Language Class Initialized
INFO - 2025-05-04 05:10:25 --> Loader Class Initialized
INFO - 2025-05-04 05:10:25 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:25 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:25 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:25 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:25 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:25 --> Controller Class Initialized
INFO - 2025-05-04 13:10:25 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:25 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:25 --> Total execution time: 0.2607
INFO - 2025-05-04 05:10:26 --> Config Class Initialized
INFO - 2025-05-04 05:10:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:26 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:26 --> URI Class Initialized
INFO - 2025-05-04 05:10:26 --> Router Class Initialized
INFO - 2025-05-04 05:10:26 --> Output Class Initialized
INFO - 2025-05-04 05:10:26 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:26 --> Input Class Initialized
INFO - 2025-05-04 05:10:26 --> Language Class Initialized
INFO - 2025-05-04 05:10:26 --> Loader Class Initialized
INFO - 2025-05-04 05:10:26 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:26 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:26 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:26 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:26 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:26 --> Controller Class Initialized
INFO - 2025-05-04 13:10:26 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:26 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:26 --> Total execution time: 0.1446
INFO - 2025-05-04 05:10:27 --> Config Class Initialized
INFO - 2025-05-04 05:10:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:27 --> URI Class Initialized
INFO - 2025-05-04 05:10:27 --> Router Class Initialized
INFO - 2025-05-04 05:10:27 --> Output Class Initialized
INFO - 2025-05-04 05:10:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:27 --> Input Class Initialized
INFO - 2025-05-04 05:10:27 --> Language Class Initialized
INFO - 2025-05-04 05:10:27 --> Loader Class Initialized
INFO - 2025-05-04 05:10:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:27 --> Controller Class Initialized
INFO - 2025-05-04 13:10:27 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:27 --> Model "InvoiceModel" initialized
INFO - 2025-05-04 13:10:27 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:27 --> Total execution time: 0.3095
INFO - 2025-05-04 05:10:28 --> Config Class Initialized
INFO - 2025-05-04 05:10:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:28 --> URI Class Initialized
INFO - 2025-05-04 05:10:28 --> Router Class Initialized
INFO - 2025-05-04 05:10:28 --> Output Class Initialized
INFO - 2025-05-04 05:10:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:28 --> Input Class Initialized
INFO - 2025-05-04 05:10:28 --> Language Class Initialized
INFO - 2025-05-04 05:10:28 --> Loader Class Initialized
INFO - 2025-05-04 05:10:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:28 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:28 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:28 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:28 --> Controller Class Initialized
INFO - 2025-05-04 13:10:28 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:28 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:28 --> Total execution time: 0.1621
INFO - 2025-05-04 05:10:28 --> Config Class Initialized
INFO - 2025-05-04 05:10:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:29 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:29 --> URI Class Initialized
INFO - 2025-05-04 05:10:29 --> Router Class Initialized
INFO - 2025-05-04 05:10:29 --> Output Class Initialized
INFO - 2025-05-04 05:10:29 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:29 --> Input Class Initialized
INFO - 2025-05-04 05:10:29 --> Language Class Initialized
INFO - 2025-05-04 05:10:29 --> Loader Class Initialized
INFO - 2025-05-04 05:10:29 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:29 --> Controller Class Initialized
INFO - 2025-05-04 13:10:29 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:29 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:29 --> Total execution time: 0.1332
INFO - 2025-05-04 05:10:29 --> Config Class Initialized
INFO - 2025-05-04 05:10:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:29 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:29 --> URI Class Initialized
INFO - 2025-05-04 05:10:29 --> Router Class Initialized
INFO - 2025-05-04 05:10:29 --> Output Class Initialized
INFO - 2025-05-04 05:10:29 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:29 --> Input Class Initialized
INFO - 2025-05-04 05:10:29 --> Language Class Initialized
INFO - 2025-05-04 05:10:29 --> Loader Class Initialized
INFO - 2025-05-04 05:10:29 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:29 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:29 --> Controller Class Initialized
INFO - 2025-05-04 13:10:29 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:10:29 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:29 --> Total execution time: 0.1844
INFO - 2025-05-04 05:10:30 --> Config Class Initialized
INFO - 2025-05-04 05:10:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:30 --> URI Class Initialized
INFO - 2025-05-04 05:10:30 --> Router Class Initialized
INFO - 2025-05-04 05:10:30 --> Output Class Initialized
INFO - 2025-05-04 05:10:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:30 --> Input Class Initialized
INFO - 2025-05-04 05:10:30 --> Language Class Initialized
INFO - 2025-05-04 05:10:30 --> Loader Class Initialized
INFO - 2025-05-04 05:10:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:31 --> Controller Class Initialized
INFO - 2025-05-04 05:10:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/notifications.php
INFO - 2025-05-04 05:10:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:31 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:31 --> Total execution time: 0.2636
INFO - 2025-05-04 05:10:31 --> Config Class Initialized
INFO - 2025-05-04 05:10:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:31 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:31 --> URI Class Initialized
INFO - 2025-05-04 05:10:31 --> Router Class Initialized
INFO - 2025-05-04 05:10:31 --> Output Class Initialized
INFO - 2025-05-04 05:10:31 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:31 --> Input Class Initialized
INFO - 2025-05-04 05:10:31 --> Language Class Initialized
INFO - 2025-05-04 05:10:31 --> Loader Class Initialized
INFO - 2025-05-04 05:10:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:31 --> Controller Class Initialized
INFO - 2025-05-04 13:10:31 --> Model "NotificationsModel" initialized
INFO - 2025-05-04 13:10:31 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:31 --> Total execution time: 0.3183
INFO - 2025-05-04 05:10:32 --> Config Class Initialized
INFO - 2025-05-04 05:10:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:32 --> URI Class Initialized
INFO - 2025-05-04 05:10:32 --> Router Class Initialized
INFO - 2025-05-04 05:10:32 --> Output Class Initialized
INFO - 2025-05-04 05:10:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:32 --> Input Class Initialized
INFO - 2025-05-04 05:10:32 --> Language Class Initialized
INFO - 2025-05-04 05:10:32 --> Loader Class Initialized
INFO - 2025-05-04 05:10:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:32 --> Controller Class Initialized
INFO - 2025-05-04 05:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/bidder/payment.php
INFO - 2025-05-04 05:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:32 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:32 --> Total execution time: 0.1266
INFO - 2025-05-04 05:10:32 --> Config Class Initialized
INFO - 2025-05-04 05:10:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:32 --> URI Class Initialized
INFO - 2025-05-04 05:10:33 --> Router Class Initialized
INFO - 2025-05-04 05:10:33 --> Output Class Initialized
INFO - 2025-05-04 05:10:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:33 --> Input Class Initialized
INFO - 2025-05-04 05:10:33 --> Language Class Initialized
INFO - 2025-05-04 05:10:33 --> Loader Class Initialized
INFO - 2025-05-04 05:10:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:33 --> Controller Class Initialized
INFO - 2025-05-04 13:10:33 --> Model "UserModel" initialized
INFO - 2025-05-04 13:10:51 --> Final output sent to browser
DEBUG - 2025-05-04 13:10:51 --> Total execution time: 18.6132
INFO - 2025-05-04 05:10:54 --> Config Class Initialized
INFO - 2025-05-04 05:10:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:54 --> URI Class Initialized
INFO - 2025-05-04 05:10:54 --> Router Class Initialized
INFO - 2025-05-04 05:10:54 --> Output Class Initialized
INFO - 2025-05-04 05:10:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:54 --> Input Class Initialized
INFO - 2025-05-04 05:10:54 --> Language Class Initialized
INFO - 2025-05-04 05:10:54 --> Loader Class Initialized
INFO - 2025-05-04 05:10:54 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:54 --> Controller Class Initialized
INFO - 2025-05-04 05:10:54 --> Config Class Initialized
INFO - 2025-05-04 05:10:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:54 --> URI Class Initialized
INFO - 2025-05-04 05:10:54 --> Router Class Initialized
INFO - 2025-05-04 05:10:54 --> Output Class Initialized
INFO - 2025-05-04 05:10:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:54 --> Input Class Initialized
INFO - 2025-05-04 05:10:54 --> Language Class Initialized
INFO - 2025-05-04 05:10:54 --> Loader Class Initialized
INFO - 2025-05-04 05:10:54 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:54 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:54 --> Controller Class Initialized
INFO - 2025-05-04 05:10:55 --> Config Class Initialized
INFO - 2025-05-04 05:10:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:55 --> URI Class Initialized
DEBUG - 2025-05-04 05:10:55 --> No URI present. Default controller set.
INFO - 2025-05-04 05:10:55 --> Router Class Initialized
INFO - 2025-05-04 05:10:55 --> Output Class Initialized
INFO - 2025-05-04 05:10:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:55 --> Input Class Initialized
INFO - 2025-05-04 05:10:55 --> Language Class Initialized
INFO - 2025-05-04 05:10:55 --> Loader Class Initialized
INFO - 2025-05-04 05:10:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:55 --> Controller Class Initialized
INFO - 2025-05-04 05:10:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:10:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:10:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 05:10:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:10:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:10:55 --> Final output sent to browser
DEBUG - 2025-05-04 05:10:55 --> Total execution time: 0.1699
INFO - 2025-05-04 05:10:55 --> Config Class Initialized
INFO - 2025-05-04 05:10:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:10:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:10:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:10:55 --> URI Class Initialized
INFO - 2025-05-04 05:10:55 --> Router Class Initialized
INFO - 2025-05-04 05:10:55 --> Output Class Initialized
INFO - 2025-05-04 05:10:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:10:55 --> Input Class Initialized
INFO - 2025-05-04 05:10:56 --> Language Class Initialized
INFO - 2025-05-04 05:10:56 --> Loader Class Initialized
INFO - 2025-05-04 05:10:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:10:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:10:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:10:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:10:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:10:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:10:56 --> Controller Class Initialized
INFO - 2025-05-04 13:10:56 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:11:11 --> Config Class Initialized
INFO - 2025-05-04 05:11:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:11 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:11 --> URI Class Initialized
INFO - 2025-05-04 05:11:11 --> Router Class Initialized
INFO - 2025-05-04 05:11:11 --> Output Class Initialized
INFO - 2025-05-04 05:11:11 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:11 --> Input Class Initialized
INFO - 2025-05-04 05:11:11 --> Language Class Initialized
INFO - 2025-05-04 05:11:11 --> Loader Class Initialized
INFO - 2025-05-04 05:11:11 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:11 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:11 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:11 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:11 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:11 --> Controller Class Initialized
INFO - 2025-05-04 13:11:11 --> Model "UserModel" initialized
INFO - 2025-05-04 05:11:16 --> Config Class Initialized
INFO - 2025-05-04 05:11:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:16 --> URI Class Initialized
INFO - 2025-05-04 05:11:16 --> Router Class Initialized
INFO - 2025-05-04 05:11:16 --> Output Class Initialized
INFO - 2025-05-04 05:11:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:16 --> Input Class Initialized
INFO - 2025-05-04 05:11:16 --> Language Class Initialized
INFO - 2025-05-04 05:11:16 --> Loader Class Initialized
INFO - 2025-05-04 05:11:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:16 --> Controller Class Initialized
INFO - 2025-05-04 13:11:16 --> Model "UserModel" initialized
INFO - 2025-05-04 05:11:16 --> Config Class Initialized
INFO - 2025-05-04 05:11:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:16 --> URI Class Initialized
DEBUG - 2025-05-04 05:11:16 --> No URI present. Default controller set.
INFO - 2025-05-04 05:11:16 --> Router Class Initialized
INFO - 2025-05-04 05:11:16 --> Output Class Initialized
INFO - 2025-05-04 05:11:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:16 --> Input Class Initialized
INFO - 2025-05-04 05:11:16 --> Language Class Initialized
INFO - 2025-05-04 05:11:16 --> Loader Class Initialized
INFO - 2025-05-04 05:11:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:16 --> Controller Class Initialized
INFO - 2025-05-04 05:11:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:11:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:11:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 05:11:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:11:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:11:16 --> Final output sent to browser
DEBUG - 2025-05-04 05:11:16 --> Total execution time: 0.2221
INFO - 2025-05-04 05:11:17 --> Config Class Initialized
INFO - 2025-05-04 05:11:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:17 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:17 --> URI Class Initialized
INFO - 2025-05-04 05:11:17 --> Router Class Initialized
INFO - 2025-05-04 05:11:17 --> Output Class Initialized
INFO - 2025-05-04 05:11:17 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:17 --> Input Class Initialized
INFO - 2025-05-04 05:11:17 --> Language Class Initialized
INFO - 2025-05-04 05:11:17 --> Loader Class Initialized
INFO - 2025-05-04 05:11:17 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:17 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:17 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:17 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:17 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:17 --> Controller Class Initialized
INFO - 2025-05-04 13:11:17 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:11:23 --> Config Class Initialized
INFO - 2025-05-04 05:11:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:23 --> URI Class Initialized
INFO - 2025-05-04 05:11:23 --> Router Class Initialized
INFO - 2025-05-04 05:11:23 --> Output Class Initialized
INFO - 2025-05-04 05:11:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:23 --> Input Class Initialized
INFO - 2025-05-04 05:11:23 --> Language Class Initialized
INFO - 2025-05-04 05:11:23 --> Loader Class Initialized
INFO - 2025-05-04 05:11:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:23 --> Controller Class Initialized
INFO - 2025-05-04 05:11:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:11:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:11:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:11:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:11:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:11:23 --> Final output sent to browser
DEBUG - 2025-05-04 05:11:23 --> Total execution time: 0.1259
INFO - 2025-05-04 05:11:24 --> Config Class Initialized
INFO - 2025-05-04 05:11:24 --> Hooks Class Initialized
INFO - 2025-05-04 05:11:24 --> Config Class Initialized
INFO - 2025-05-04 05:11:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:24 --> Utf8 Class Initialized
DEBUG - 2025-05-04 05:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:24 --> URI Class Initialized
INFO - 2025-05-04 05:11:24 --> URI Class Initialized
INFO - 2025-05-04 05:11:24 --> Router Class Initialized
INFO - 2025-05-04 05:11:24 --> Output Class Initialized
INFO - 2025-05-04 05:11:24 --> Security Class Initialized
INFO - 2025-05-04 05:11:24 --> Router Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:24 --> Input Class Initialized
INFO - 2025-05-04 05:11:24 --> Output Class Initialized
INFO - 2025-05-04 05:11:24 --> Language Class Initialized
INFO - 2025-05-04 05:11:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:24 --> Input Class Initialized
INFO - 2025-05-04 05:11:24 --> Loader Class Initialized
INFO - 2025-05-04 05:11:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:24 --> Language Class Initialized
INFO - 2025-05-04 05:11:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:24 --> Loader Class Initialized
INFO - 2025-05-04 05:11:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:24 --> Controller Class Initialized
INFO - 2025-05-04 13:11:24 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:11:24 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:24 --> Total execution time: 0.2742
INFO - 2025-05-04 05:11:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:24 --> Config Class Initialized
INFO - 2025-05-04 05:11:24 --> Controller Class Initialized
INFO - 2025-05-04 05:11:24 --> Hooks Class Initialized
INFO - 2025-05-04 13:11:24 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:24 --> URI Class Initialized
INFO - 2025-05-04 05:11:24 --> Router Class Initialized
INFO - 2025-05-04 13:11:24 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:11:24 --> Output Class Initialized
INFO - 2025-05-04 05:11:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 13:11:24 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:11:24 --> Input Class Initialized
INFO - 2025-05-04 05:11:24 --> Language Class Initialized
INFO - 2025-05-04 05:11:24 --> Loader Class Initialized
INFO - 2025-05-04 05:11:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:24 --> Helper loaded: html_helper
INFO - 2025-05-04 13:11:24 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:24 --> Total execution time: 0.4402
INFO - 2025-05-04 05:11:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:24 --> Controller Class Initialized
INFO - 2025-05-04 05:11:24 --> Model "UserModel" initialized
INFO - 2025-05-04 05:11:24 --> Final output sent to browser
DEBUG - 2025-05-04 05:11:24 --> Total execution time: 0.1453
INFO - 2025-05-04 05:11:27 --> Config Class Initialized
INFO - 2025-05-04 05:11:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:27 --> URI Class Initialized
INFO - 2025-05-04 05:11:27 --> Router Class Initialized
INFO - 2025-05-04 05:11:27 --> Output Class Initialized
INFO - 2025-05-04 05:11:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:27 --> Input Class Initialized
INFO - 2025-05-04 05:11:27 --> Language Class Initialized
INFO - 2025-05-04 05:11:27 --> Loader Class Initialized
INFO - 2025-05-04 05:11:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:27 --> Controller Class Initialized
INFO - 2025-05-04 05:11:27 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:11:27 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:11:27 --> Config Class Initialized
INFO - 2025-05-04 05:11:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:27 --> URI Class Initialized
INFO - 2025-05-04 05:11:27 --> Router Class Initialized
INFO - 2025-05-04 05:11:27 --> Output Class Initialized
INFO - 2025-05-04 05:11:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:27 --> Input Class Initialized
INFO - 2025-05-04 05:11:27 --> Language Class Initialized
INFO - 2025-05-04 05:11:27 --> Loader Class Initialized
INFO - 2025-05-04 05:11:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:27 --> Controller Class Initialized
INFO - 2025-05-04 13:11:27 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:11:27 --> Config Class Initialized
INFO - 2025-05-04 05:11:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:27 --> URI Class Initialized
INFO - 2025-05-04 05:11:27 --> Router Class Initialized
INFO - 2025-05-04 05:11:27 --> Output Class Initialized
INFO - 2025-05-04 05:11:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:27 --> Input Class Initialized
INFO - 2025-05-04 05:11:27 --> Language Class Initialized
INFO - 2025-05-04 05:11:27 --> Loader Class Initialized
INFO - 2025-05-04 05:11:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:27 --> Controller Class Initialized
INFO - 2025-05-04 13:11:27 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:11:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:11:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:11:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:11:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:11:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:11:27 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:27 --> Total execution time: 0.1930
INFO - 2025-05-04 05:11:28 --> Config Class Initialized
INFO - 2025-05-04 05:11:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:28 --> URI Class Initialized
INFO - 2025-05-04 05:11:28 --> Router Class Initialized
INFO - 2025-05-04 05:11:28 --> Output Class Initialized
INFO - 2025-05-04 05:11:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:28 --> Input Class Initialized
INFO - 2025-05-04 05:11:28 --> Language Class Initialized
INFO - 2025-05-04 05:11:28 --> Loader Class Initialized
INFO - 2025-05-04 05:11:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:28 --> Controller Class Initialized
INFO - 2025-05-04 05:11:28 --> Config Class Initialized
INFO - 2025-05-04 05:11:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:28 --> URI Class Initialized
INFO - 2025-05-04 05:11:28 --> Router Class Initialized
INFO - 2025-05-04 05:11:28 --> Output Class Initialized
INFO - 2025-05-04 05:11:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:28 --> Input Class Initialized
INFO - 2025-05-04 05:11:28 --> Language Class Initialized
INFO - 2025-05-04 05:11:28 --> Loader Class Initialized
INFO - 2025-05-04 05:11:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:28 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:28 --> Controller Class Initialized
INFO - 2025-05-04 13:11:28 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:11:28 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:28 --> Total execution time: 0.1308
INFO - 2025-05-04 05:11:30 --> Config Class Initialized
INFO - 2025-05-04 05:11:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:30 --> URI Class Initialized
INFO - 2025-05-04 05:11:30 --> Router Class Initialized
INFO - 2025-05-04 05:11:30 --> Output Class Initialized
INFO - 2025-05-04 05:11:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:30 --> Input Class Initialized
INFO - 2025-05-04 05:11:30 --> Language Class Initialized
INFO - 2025-05-04 05:11:30 --> Loader Class Initialized
INFO - 2025-05-04 05:11:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:30 --> Controller Class Initialized
INFO - 2025-05-04 05:11:30 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:11:30 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:11:31 --> Config Class Initialized
INFO - 2025-05-04 05:11:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:31 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:31 --> URI Class Initialized
INFO - 2025-05-04 05:11:31 --> Router Class Initialized
INFO - 2025-05-04 05:11:31 --> Output Class Initialized
INFO - 2025-05-04 05:11:31 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:31 --> Input Class Initialized
INFO - 2025-05-04 05:11:31 --> Language Class Initialized
INFO - 2025-05-04 05:11:31 --> Loader Class Initialized
INFO - 2025-05-04 05:11:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:31 --> Controller Class Initialized
INFO - 2025-05-04 13:11:31 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:11:31 --> Config Class Initialized
INFO - 2025-05-04 05:11:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:31 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:31 --> URI Class Initialized
INFO - 2025-05-04 05:11:31 --> Router Class Initialized
INFO - 2025-05-04 05:11:31 --> Output Class Initialized
INFO - 2025-05-04 05:11:31 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:31 --> Input Class Initialized
INFO - 2025-05-04 05:11:31 --> Language Class Initialized
INFO - 2025-05-04 05:11:31 --> Loader Class Initialized
INFO - 2025-05-04 05:11:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:31 --> Controller Class Initialized
INFO - 2025-05-04 13:11:31 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:11:31 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:31 --> Total execution time: 0.1520
INFO - 2025-05-04 05:11:31 --> Config Class Initialized
INFO - 2025-05-04 05:11:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:31 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:31 --> URI Class Initialized
INFO - 2025-05-04 05:11:31 --> Router Class Initialized
INFO - 2025-05-04 05:11:31 --> Output Class Initialized
INFO - 2025-05-04 05:11:31 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:31 --> Input Class Initialized
INFO - 2025-05-04 05:11:31 --> Language Class Initialized
INFO - 2025-05-04 05:11:31 --> Loader Class Initialized
INFO - 2025-05-04 05:11:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:31 --> Controller Class Initialized
INFO - 2025-05-04 05:11:32 --> Config Class Initialized
INFO - 2025-05-04 05:11:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:11:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:11:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:11:32 --> URI Class Initialized
INFO - 2025-05-04 05:11:32 --> Router Class Initialized
INFO - 2025-05-04 05:11:32 --> Output Class Initialized
INFO - 2025-05-04 05:11:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:11:32 --> Input Class Initialized
INFO - 2025-05-04 05:11:32 --> Language Class Initialized
INFO - 2025-05-04 05:11:32 --> Loader Class Initialized
INFO - 2025-05-04 05:11:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:11:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:11:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:11:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:11:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:11:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:11:32 --> Controller Class Initialized
INFO - 2025-05-04 13:11:32 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:11:32 --> Final output sent to browser
DEBUG - 2025-05-04 13:11:32 --> Total execution time: 0.1477
INFO - 2025-05-04 05:12:20 --> Config Class Initialized
INFO - 2025-05-04 05:12:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:20 --> URI Class Initialized
INFO - 2025-05-04 05:12:20 --> Router Class Initialized
INFO - 2025-05-04 05:12:20 --> Output Class Initialized
INFO - 2025-05-04 05:12:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:20 --> Input Class Initialized
INFO - 2025-05-04 05:12:20 --> Language Class Initialized
INFO - 2025-05-04 05:12:20 --> Loader Class Initialized
INFO - 2025-05-04 05:12:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:20 --> Controller Class Initialized
INFO - 2025-05-04 05:12:20 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:12:20 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:12:20 --> Config Class Initialized
INFO - 2025-05-04 05:12:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:20 --> URI Class Initialized
INFO - 2025-05-04 05:12:20 --> Router Class Initialized
INFO - 2025-05-04 05:12:20 --> Output Class Initialized
INFO - 2025-05-04 05:12:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:20 --> Input Class Initialized
INFO - 2025-05-04 05:12:20 --> Language Class Initialized
INFO - 2025-05-04 05:12:20 --> Loader Class Initialized
INFO - 2025-05-04 05:12:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:20 --> Controller Class Initialized
INFO - 2025-05-04 13:12:20 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:12:20 --> Config Class Initialized
INFO - 2025-05-04 05:12:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:20 --> URI Class Initialized
INFO - 2025-05-04 05:12:20 --> Router Class Initialized
INFO - 2025-05-04 05:12:20 --> Output Class Initialized
INFO - 2025-05-04 05:12:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:20 --> Input Class Initialized
INFO - 2025-05-04 05:12:20 --> Language Class Initialized
INFO - 2025-05-04 05:12:20 --> Loader Class Initialized
INFO - 2025-05-04 05:12:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:20 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:20 --> Controller Class Initialized
INFO - 2025-05-04 13:12:20 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:12:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:12:20 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:20 --> Total execution time: 0.1447
INFO - 2025-05-04 05:12:21 --> Config Class Initialized
INFO - 2025-05-04 05:12:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:21 --> URI Class Initialized
INFO - 2025-05-04 05:12:21 --> Router Class Initialized
INFO - 2025-05-04 05:12:21 --> Output Class Initialized
INFO - 2025-05-04 05:12:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:21 --> Input Class Initialized
INFO - 2025-05-04 05:12:21 --> Language Class Initialized
INFO - 2025-05-04 05:12:21 --> Loader Class Initialized
INFO - 2025-05-04 05:12:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:21 --> Controller Class Initialized
INFO - 2025-05-04 05:12:21 --> Config Class Initialized
INFO - 2025-05-04 05:12:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:21 --> URI Class Initialized
INFO - 2025-05-04 05:12:21 --> Router Class Initialized
INFO - 2025-05-04 05:12:21 --> Output Class Initialized
INFO - 2025-05-04 05:12:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:21 --> Input Class Initialized
INFO - 2025-05-04 05:12:21 --> Language Class Initialized
INFO - 2025-05-04 05:12:21 --> Loader Class Initialized
INFO - 2025-05-04 05:12:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:21 --> Controller Class Initialized
INFO - 2025-05-04 13:12:21 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:21 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:21 --> Total execution time: 0.1197
INFO - 2025-05-04 05:12:24 --> Config Class Initialized
INFO - 2025-05-04 05:12:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:24 --> URI Class Initialized
INFO - 2025-05-04 05:12:24 --> Router Class Initialized
INFO - 2025-05-04 05:12:24 --> Output Class Initialized
INFO - 2025-05-04 05:12:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:24 --> Input Class Initialized
INFO - 2025-05-04 05:12:24 --> Language Class Initialized
INFO - 2025-05-04 05:12:24 --> Loader Class Initialized
INFO - 2025-05-04 05:12:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:24 --> Controller Class Initialized
INFO - 2025-05-04 13:12:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:12:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:12:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:12:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:12:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:12:24 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:24 --> Total execution time: 0.1380
INFO - 2025-05-04 05:12:27 --> Config Class Initialized
INFO - 2025-05-04 05:12:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:27 --> URI Class Initialized
INFO - 2025-05-04 05:12:27 --> Router Class Initialized
INFO - 2025-05-04 05:12:27 --> Output Class Initialized
INFO - 2025-05-04 05:12:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:27 --> Input Class Initialized
INFO - 2025-05-04 05:12:27 --> Language Class Initialized
INFO - 2025-05-04 05:12:27 --> Loader Class Initialized
INFO - 2025-05-04 05:12:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:28 --> Controller Class Initialized
INFO - 2025-05-04 05:12:28 --> Config Class Initialized
INFO - 2025-05-04 05:12:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:28 --> URI Class Initialized
INFO - 2025-05-04 05:12:28 --> Router Class Initialized
INFO - 2025-05-04 05:12:28 --> Output Class Initialized
INFO - 2025-05-04 05:12:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:28 --> Input Class Initialized
INFO - 2025-05-04 05:12:28 --> Language Class Initialized
INFO - 2025-05-04 05:12:28 --> Loader Class Initialized
INFO - 2025-05-04 05:12:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:28 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:28 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:28 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:28 --> Controller Class Initialized
INFO - 2025-05-04 13:12:28 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:28 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:28 --> Total execution time: 0.1960
INFO - 2025-05-04 05:12:46 --> Config Class Initialized
INFO - 2025-05-04 05:12:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:46 --> URI Class Initialized
INFO - 2025-05-04 05:12:46 --> Router Class Initialized
INFO - 2025-05-04 05:12:46 --> Output Class Initialized
INFO - 2025-05-04 05:12:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:46 --> Input Class Initialized
INFO - 2025-05-04 05:12:46 --> Language Class Initialized
INFO - 2025-05-04 05:12:46 --> Loader Class Initialized
INFO - 2025-05-04 05:12:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:46 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:46 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:46 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:46 --> Controller Class Initialized
INFO - 2025-05-04 05:12:46 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:12:46 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:12:46 --> Config Class Initialized
INFO - 2025-05-04 05:12:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:46 --> URI Class Initialized
INFO - 2025-05-04 05:12:46 --> Router Class Initialized
INFO - 2025-05-04 05:12:46 --> Output Class Initialized
INFO - 2025-05-04 05:12:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:46 --> Input Class Initialized
INFO - 2025-05-04 05:12:46 --> Language Class Initialized
INFO - 2025-05-04 05:12:47 --> Loader Class Initialized
INFO - 2025-05-04 05:12:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:47 --> Controller Class Initialized
INFO - 2025-05-04 13:12:47 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:12:47 --> Config Class Initialized
INFO - 2025-05-04 05:12:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:47 --> URI Class Initialized
INFO - 2025-05-04 05:12:47 --> Router Class Initialized
INFO - 2025-05-04 05:12:47 --> Output Class Initialized
INFO - 2025-05-04 05:12:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:47 --> Input Class Initialized
INFO - 2025-05-04 05:12:47 --> Language Class Initialized
INFO - 2025-05-04 05:12:47 --> Loader Class Initialized
INFO - 2025-05-04 05:12:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:47 --> Controller Class Initialized
INFO - 2025-05-04 13:12:47 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:12:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:12:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:12:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:12:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:12:47 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:47 --> Total execution time: 0.1808
INFO - 2025-05-04 05:12:47 --> Config Class Initialized
INFO - 2025-05-04 05:12:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:47 --> URI Class Initialized
INFO - 2025-05-04 05:12:47 --> Router Class Initialized
INFO - 2025-05-04 05:12:47 --> Output Class Initialized
INFO - 2025-05-04 05:12:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:47 --> Input Class Initialized
INFO - 2025-05-04 05:12:47 --> Language Class Initialized
INFO - 2025-05-04 05:12:47 --> Loader Class Initialized
INFO - 2025-05-04 05:12:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:48 --> Controller Class Initialized
INFO - 2025-05-04 05:12:48 --> Config Class Initialized
INFO - 2025-05-04 05:12:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:48 --> URI Class Initialized
INFO - 2025-05-04 05:12:48 --> Router Class Initialized
INFO - 2025-05-04 05:12:48 --> Output Class Initialized
INFO - 2025-05-04 05:12:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:48 --> Input Class Initialized
INFO - 2025-05-04 05:12:48 --> Language Class Initialized
INFO - 2025-05-04 05:12:48 --> Loader Class Initialized
INFO - 2025-05-04 05:12:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:48 --> Controller Class Initialized
INFO - 2025-05-04 13:12:48 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:48 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:48 --> Total execution time: 0.1722
INFO - 2025-05-04 05:12:48 --> Config Class Initialized
INFO - 2025-05-04 05:12:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:48 --> URI Class Initialized
INFO - 2025-05-04 05:12:48 --> Router Class Initialized
INFO - 2025-05-04 05:12:48 --> Output Class Initialized
INFO - 2025-05-04 05:12:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:48 --> Input Class Initialized
INFO - 2025-05-04 05:12:48 --> Language Class Initialized
INFO - 2025-05-04 05:12:48 --> Loader Class Initialized
INFO - 2025-05-04 05:12:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:48 --> Controller Class Initialized
INFO - 2025-05-04 05:12:48 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:12:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:12:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:12:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:12:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:12:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:12:48 --> Final output sent to browser
DEBUG - 2025-05-04 05:12:48 --> Total execution time: 0.1222
INFO - 2025-05-04 05:12:49 --> Config Class Initialized
INFO - 2025-05-04 05:12:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:49 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:49 --> URI Class Initialized
INFO - 2025-05-04 05:12:49 --> Router Class Initialized
INFO - 2025-05-04 05:12:49 --> Output Class Initialized
INFO - 2025-05-04 05:12:49 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:49 --> Input Class Initialized
INFO - 2025-05-04 05:12:49 --> Language Class Initialized
INFO - 2025-05-04 05:12:49 --> Loader Class Initialized
INFO - 2025-05-04 05:12:49 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:49 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:49 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:49 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:49 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:49 --> Controller Class Initialized
INFO - 2025-05-04 05:12:49 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:12:49 --> Final output sent to browser
DEBUG - 2025-05-04 05:12:49 --> Total execution time: 0.3116
INFO - 2025-05-04 05:12:50 --> Config Class Initialized
INFO - 2025-05-04 05:12:50 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:50 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:50 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:50 --> URI Class Initialized
INFO - 2025-05-04 05:12:50 --> Router Class Initialized
INFO - 2025-05-04 05:12:50 --> Output Class Initialized
INFO - 2025-05-04 05:12:50 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:50 --> Input Class Initialized
INFO - 2025-05-04 05:12:50 --> Language Class Initialized
INFO - 2025-05-04 05:12:50 --> Loader Class Initialized
INFO - 2025-05-04 05:12:50 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:50 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:50 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:50 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:50 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:50 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:50 --> Controller Class Initialized
INFO - 2025-05-04 05:12:50 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:12:50 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 87
INFO - 2025-05-04 05:12:51 --> Config Class Initialized
INFO - 2025-05-04 05:12:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:51 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:51 --> URI Class Initialized
INFO - 2025-05-04 05:12:51 --> Router Class Initialized
INFO - 2025-05-04 05:12:51 --> Output Class Initialized
INFO - 2025-05-04 05:12:51 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:51 --> Input Class Initialized
INFO - 2025-05-04 05:12:51 --> Language Class Initialized
INFO - 2025-05-04 05:12:51 --> Loader Class Initialized
INFO - 2025-05-04 05:12:51 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:51 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:51 --> Controller Class Initialized
INFO - 2025-05-04 13:12:51 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:12:51 --> Config Class Initialized
INFO - 2025-05-04 05:12:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:51 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:51 --> URI Class Initialized
INFO - 2025-05-04 05:12:51 --> Router Class Initialized
INFO - 2025-05-04 05:12:51 --> Output Class Initialized
INFO - 2025-05-04 05:12:51 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:51 --> Input Class Initialized
INFO - 2025-05-04 05:12:51 --> Language Class Initialized
INFO - 2025-05-04 05:12:51 --> Loader Class Initialized
INFO - 2025-05-04 13:12:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:12:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:12:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:12:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:12:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:12:51 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:51 --> Total execution time: 0.1400
INFO - 2025-05-04 05:12:51 --> Config Class Initialized
INFO - 2025-05-04 05:12:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:51 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:51 --> URI Class Initialized
INFO - 2025-05-04 05:12:51 --> Router Class Initialized
INFO - 2025-05-04 05:12:51 --> Output Class Initialized
INFO - 2025-05-04 05:12:51 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:51 --> Input Class Initialized
INFO - 2025-05-04 05:12:51 --> Language Class Initialized
INFO - 2025-05-04 05:12:51 --> Loader Class Initialized
INFO - 2025-05-04 05:12:51 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:51 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:51 --> Controller Class Initialized
INFO - 2025-05-04 05:12:51 --> Config Class Initialized
INFO - 2025-05-04 05:12:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:51 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:51 --> URI Class Initialized
INFO - 2025-05-04 05:12:51 --> Router Class Initialized
INFO - 2025-05-04 05:12:51 --> Output Class Initialized
INFO - 2025-05-04 05:12:51 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:51 --> Input Class Initialized
INFO - 2025-05-04 05:12:51 --> Language Class Initialized
INFO - 2025-05-04 05:12:51 --> Loader Class Initialized
INFO - 2025-05-04 05:12:51 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:51 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:51 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:52 --> Controller Class Initialized
INFO - 2025-05-04 13:12:52 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:12:52 --> Final output sent to browser
DEBUG - 2025-05-04 13:12:52 --> Total execution time: 0.1440
INFO - 2025-05-04 05:12:53 --> Config Class Initialized
INFO - 2025-05-04 05:12:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:53 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:53 --> URI Class Initialized
INFO - 2025-05-04 05:12:53 --> Router Class Initialized
INFO - 2025-05-04 05:12:53 --> Output Class Initialized
INFO - 2025-05-04 05:12:53 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:53 --> Input Class Initialized
INFO - 2025-05-04 05:12:53 --> Language Class Initialized
INFO - 2025-05-04 05:12:53 --> Loader Class Initialized
INFO - 2025-05-04 05:12:53 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:53 --> Controller Class Initialized
INFO - 2025-05-04 05:12:53 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:12:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:12:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:12:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:12:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:12:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:12:53 --> Final output sent to browser
DEBUG - 2025-05-04 05:12:53 --> Total execution time: 0.1446
INFO - 2025-05-04 05:12:53 --> Config Class Initialized
INFO - 2025-05-04 05:12:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:12:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:12:53 --> Utf8 Class Initialized
INFO - 2025-05-04 05:12:53 --> URI Class Initialized
INFO - 2025-05-04 05:12:53 --> Router Class Initialized
INFO - 2025-05-04 05:12:53 --> Output Class Initialized
INFO - 2025-05-04 05:12:53 --> Security Class Initialized
DEBUG - 2025-05-04 05:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:12:53 --> Input Class Initialized
INFO - 2025-05-04 05:12:53 --> Language Class Initialized
INFO - 2025-05-04 05:12:53 --> Loader Class Initialized
INFO - 2025-05-04 05:12:53 --> Helper loaded: url_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: string_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: form_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: file_helper
INFO - 2025-05-04 05:12:53 --> Helper loaded: html_helper
INFO - 2025-05-04 05:12:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:12:53 --> Controller Class Initialized
INFO - 2025-05-04 05:12:53 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:12:53 --> Final output sent to browser
DEBUG - 2025-05-04 05:12:53 --> Total execution time: 0.2351
INFO - 2025-05-04 05:13:09 --> Config Class Initialized
INFO - 2025-05-04 05:13:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:13:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:13:09 --> Utf8 Class Initialized
INFO - 2025-05-04 05:13:09 --> URI Class Initialized
INFO - 2025-05-04 05:13:09 --> Router Class Initialized
INFO - 2025-05-04 05:13:09 --> Output Class Initialized
INFO - 2025-05-04 05:13:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:13:09 --> Input Class Initialized
INFO - 2025-05-04 05:13:09 --> Language Class Initialized
INFO - 2025-05-04 05:13:09 --> Loader Class Initialized
INFO - 2025-05-04 05:13:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:13:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:13:09 --> Controller Class Initialized
INFO - 2025-05-04 05:13:09 --> Model "CompanyModel" initialized
ERROR - 2025-05-04 05:13:09 --> Severity: Warning --> Undefined variable $userId C:\xampp\htdocs\storage_auctions\application\controllers\StorageFacilityDashboard.php 160
INFO - 2025-05-04 05:13:09 --> Config Class Initialized
INFO - 2025-05-04 05:13:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:13:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:13:09 --> Utf8 Class Initialized
INFO - 2025-05-04 05:13:09 --> URI Class Initialized
INFO - 2025-05-04 05:13:09 --> Router Class Initialized
INFO - 2025-05-04 05:13:09 --> Output Class Initialized
INFO - 2025-05-04 05:13:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:13:09 --> Input Class Initialized
INFO - 2025-05-04 05:13:09 --> Language Class Initialized
INFO - 2025-05-04 05:13:09 --> Loader Class Initialized
INFO - 2025-05-04 05:13:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: file_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: html_helper
INFO - 2025-05-04 05:13:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:13:09 --> Controller Class Initialized
INFO - 2025-05-04 13:13:09 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:13:09 --> Config Class Initialized
INFO - 2025-05-04 05:13:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:13:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:13:09 --> Utf8 Class Initialized
INFO - 2025-05-04 05:13:09 --> URI Class Initialized
INFO - 2025-05-04 05:13:09 --> Router Class Initialized
INFO - 2025-05-04 05:13:09 --> Output Class Initialized
INFO - 2025-05-04 05:13:09 --> Security Class Initialized
DEBUG - 2025-05-04 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:13:09 --> Input Class Initialized
INFO - 2025-05-04 05:13:09 --> Language Class Initialized
INFO - 2025-05-04 05:13:09 --> Loader Class Initialized
INFO - 2025-05-04 05:13:09 --> Helper loaded: url_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: string_helper
INFO - 2025-05-04 05:13:09 --> Helper loaded: form_helper
INFO - 2025-05-04 05:13:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:13:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:13:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:13:10 --> Controller Class Initialized
INFO - 2025-05-04 13:13:10 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:13:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:13:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:13:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:13:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:13:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:13:10 --> Final output sent to browser
DEBUG - 2025-05-04 13:13:10 --> Total execution time: 0.1905
INFO - 2025-05-04 05:13:12 --> Config Class Initialized
INFO - 2025-05-04 05:13:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:13:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:13:12 --> Utf8 Class Initialized
INFO - 2025-05-04 05:13:12 --> URI Class Initialized
INFO - 2025-05-04 05:13:12 --> Router Class Initialized
INFO - 2025-05-04 05:13:12 --> Output Class Initialized
INFO - 2025-05-04 05:13:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:13:12 --> Input Class Initialized
INFO - 2025-05-04 05:13:12 --> Language Class Initialized
INFO - 2025-05-04 05:13:12 --> Loader Class Initialized
INFO - 2025-05-04 05:13:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:13:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:13:12 --> Controller Class Initialized
INFO - 2025-05-04 05:13:12 --> Config Class Initialized
INFO - 2025-05-04 05:13:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:13:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:13:12 --> Utf8 Class Initialized
INFO - 2025-05-04 05:13:12 --> URI Class Initialized
INFO - 2025-05-04 05:13:12 --> Router Class Initialized
INFO - 2025-05-04 05:13:12 --> Output Class Initialized
INFO - 2025-05-04 05:13:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:13:12 --> Input Class Initialized
INFO - 2025-05-04 05:13:12 --> Language Class Initialized
INFO - 2025-05-04 05:13:12 --> Loader Class Initialized
INFO - 2025-05-04 05:13:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:13:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:13:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:13:12 --> Controller Class Initialized
INFO - 2025-05-04 13:13:12 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:13:12 --> Final output sent to browser
DEBUG - 2025-05-04 13:13:12 --> Total execution time: 0.1710
INFO - 2025-05-04 05:14:00 --> Config Class Initialized
INFO - 2025-05-04 05:14:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:00 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:00 --> URI Class Initialized
INFO - 2025-05-04 05:14:00 --> Router Class Initialized
INFO - 2025-05-04 05:14:00 --> Output Class Initialized
INFO - 2025-05-04 05:14:00 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:00 --> Input Class Initialized
INFO - 2025-05-04 05:14:00 --> Language Class Initialized
INFO - 2025-05-04 05:14:00 --> Loader Class Initialized
INFO - 2025-05-04 05:14:00 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:00 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:00 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:00 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:00 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:00 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:01 --> Controller Class Initialized
INFO - 2025-05-04 05:14:01 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:14:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:14:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:14:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:14:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:14:01 --> Final output sent to browser
DEBUG - 2025-05-04 05:14:01 --> Total execution time: 0.3489
INFO - 2025-05-04 05:14:02 --> Config Class Initialized
INFO - 2025-05-04 05:14:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:02 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:02 --> URI Class Initialized
INFO - 2025-05-04 05:14:02 --> Router Class Initialized
INFO - 2025-05-04 05:14:02 --> Output Class Initialized
INFO - 2025-05-04 05:14:02 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:02 --> Input Class Initialized
INFO - 2025-05-04 05:14:02 --> Language Class Initialized
INFO - 2025-05-04 05:14:02 --> Loader Class Initialized
INFO - 2025-05-04 05:14:02 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:02 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:02 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:02 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:02 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:02 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:02 --> Controller Class Initialized
INFO - 2025-05-04 13:14:02 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:02 --> Model "StaffModel" initialized
INFO - 2025-05-04 13:14:02 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:02 --> Total execution time: 0.4975
INFO - 2025-05-04 05:14:07 --> Config Class Initialized
INFO - 2025-05-04 05:14:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:07 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:07 --> URI Class Initialized
INFO - 2025-05-04 05:14:07 --> Router Class Initialized
INFO - 2025-05-04 05:14:07 --> Output Class Initialized
INFO - 2025-05-04 05:14:07 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:07 --> Input Class Initialized
INFO - 2025-05-04 05:14:07 --> Language Class Initialized
INFO - 2025-05-04 05:14:07 --> Loader Class Initialized
INFO - 2025-05-04 05:14:07 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:07 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:07 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:07 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:07 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:07 --> Controller Class Initialized
INFO - 2025-05-04 05:14:07 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:14:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:14:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:14:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:14:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:14:07 --> Final output sent to browser
DEBUG - 2025-05-04 05:14:07 --> Total execution time: 0.2569
INFO - 2025-05-04 05:14:08 --> Config Class Initialized
INFO - 2025-05-04 05:14:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:08 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:08 --> URI Class Initialized
INFO - 2025-05-04 05:14:08 --> Router Class Initialized
INFO - 2025-05-04 05:14:08 --> Output Class Initialized
INFO - 2025-05-04 05:14:08 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:08 --> Input Class Initialized
INFO - 2025-05-04 05:14:08 --> Language Class Initialized
INFO - 2025-05-04 05:14:08 --> Loader Class Initialized
INFO - 2025-05-04 05:14:08 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:08 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:08 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:08 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:08 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:08 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:08 --> Controller Class Initialized
INFO - 2025-05-04 05:14:08 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:14:08 --> Final output sent to browser
DEBUG - 2025-05-04 05:14:08 --> Total execution time: 0.5840
INFO - 2025-05-04 05:14:10 --> Config Class Initialized
INFO - 2025-05-04 05:14:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:10 --> URI Class Initialized
INFO - 2025-05-04 05:14:10 --> Router Class Initialized
INFO - 2025-05-04 05:14:10 --> Output Class Initialized
INFO - 2025-05-04 05:14:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:10 --> Input Class Initialized
INFO - 2025-05-04 05:14:10 --> Language Class Initialized
INFO - 2025-05-04 05:14:10 --> Loader Class Initialized
INFO - 2025-05-04 05:14:11 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:11 --> Controller Class Initialized
INFO - 2025-05-04 13:14:11 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-04 13:14:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:11 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:11 --> Total execution time: 0.1392
INFO - 2025-05-04 05:14:11 --> Config Class Initialized
INFO - 2025-05-04 05:14:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:11 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:11 --> URI Class Initialized
INFO - 2025-05-04 05:14:11 --> Router Class Initialized
INFO - 2025-05-04 05:14:11 --> Config Class Initialized
INFO - 2025-05-04 05:14:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:11 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:11 --> URI Class Initialized
INFO - 2025-05-04 05:14:11 --> Router Class Initialized
INFO - 2025-05-04 05:14:11 --> Output Class Initialized
INFO - 2025-05-04 05:14:11 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:11 --> Input Class Initialized
INFO - 2025-05-04 05:14:11 --> Language Class Initialized
INFO - 2025-05-04 05:14:11 --> Loader Class Initialized
INFO - 2025-05-04 05:14:11 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:11 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:11 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:11 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:11 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:11 --> Controller Class Initialized
INFO - 2025-05-04 13:14:11 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:11 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:11 --> Total execution time: 0.2288
INFO - 2025-05-04 05:14:17 --> Config Class Initialized
INFO - 2025-05-04 05:14:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:18 --> URI Class Initialized
INFO - 2025-05-04 05:14:18 --> Router Class Initialized
INFO - 2025-05-04 05:14:18 --> Output Class Initialized
INFO - 2025-05-04 05:14:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:18 --> Input Class Initialized
INFO - 2025-05-04 05:14:18 --> Language Class Initialized
INFO - 2025-05-04 05:14:18 --> Loader Class Initialized
INFO - 2025-05-04 05:14:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:18 --> Controller Class Initialized
INFO - 2025-05-04 13:14:18 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:18 --> Config Class Initialized
INFO - 2025-05-04 05:14:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:18 --> URI Class Initialized
INFO - 2025-05-04 05:14:18 --> Router Class Initialized
INFO - 2025-05-04 05:14:18 --> Output Class Initialized
INFO - 2025-05-04 05:14:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:18 --> Input Class Initialized
INFO - 2025-05-04 05:14:18 --> Language Class Initialized
INFO - 2025-05-04 05:14:18 --> Loader Class Initialized
INFO - 2025-05-04 05:14:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:18 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:18 --> Controller Class Initialized
INFO - 2025-05-04 13:14:18 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:14:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:18 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:18 --> Total execution time: 0.1422
INFO - 2025-05-04 05:14:20 --> Config Class Initialized
INFO - 2025-05-04 05:14:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:20 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:20 --> URI Class Initialized
INFO - 2025-05-04 05:14:20 --> Router Class Initialized
INFO - 2025-05-04 05:14:20 --> Output Class Initialized
INFO - 2025-05-04 05:14:20 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:20 --> Input Class Initialized
INFO - 2025-05-04 05:14:20 --> Language Class Initialized
INFO - 2025-05-04 05:14:20 --> Loader Class Initialized
INFO - 2025-05-04 05:14:20 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:20 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:20 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:21 --> Controller Class Initialized
INFO - 2025-05-04 05:14:21 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:21 --> Config Class Initialized
INFO - 2025-05-04 05:14:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:21 --> URI Class Initialized
INFO - 2025-05-04 05:14:21 --> Router Class Initialized
INFO - 2025-05-04 05:14:21 --> Output Class Initialized
INFO - 2025-05-04 05:14:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:21 --> Input Class Initialized
INFO - 2025-05-04 05:14:21 --> Language Class Initialized
INFO - 2025-05-04 05:14:21 --> Loader Class Initialized
INFO - 2025-05-04 05:14:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:21 --> Controller Class Initialized
INFO - 2025-05-04 13:14:21 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:14:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:21 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:21 --> Total execution time: 0.1637
INFO - 2025-05-04 05:14:24 --> Config Class Initialized
INFO - 2025-05-04 05:14:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:24 --> URI Class Initialized
INFO - 2025-05-04 05:14:24 --> Router Class Initialized
INFO - 2025-05-04 05:14:24 --> Output Class Initialized
INFO - 2025-05-04 05:14:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:24 --> Input Class Initialized
INFO - 2025-05-04 05:14:24 --> Language Class Initialized
INFO - 2025-05-04 05:14:24 --> Loader Class Initialized
INFO - 2025-05-04 05:14:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:24 --> Controller Class Initialized
INFO - 2025-05-04 05:14:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:24 --> Config Class Initialized
INFO - 2025-05-04 05:14:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:24 --> URI Class Initialized
INFO - 2025-05-04 05:14:24 --> Router Class Initialized
INFO - 2025-05-04 05:14:24 --> Output Class Initialized
INFO - 2025-05-04 05:14:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:24 --> Input Class Initialized
INFO - 2025-05-04 05:14:24 --> Language Class Initialized
INFO - 2025-05-04 05:14:24 --> Loader Class Initialized
INFO - 2025-05-04 05:14:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:24 --> Controller Class Initialized
INFO - 2025-05-04 13:14:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:14:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:24 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:24 --> Total execution time: 0.1959
INFO - 2025-05-04 05:14:27 --> Config Class Initialized
INFO - 2025-05-04 05:14:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:27 --> URI Class Initialized
INFO - 2025-05-04 05:14:27 --> Router Class Initialized
INFO - 2025-05-04 05:14:27 --> Output Class Initialized
INFO - 2025-05-04 05:14:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:27 --> Input Class Initialized
INFO - 2025-05-04 05:14:27 --> Language Class Initialized
INFO - 2025-05-04 05:14:27 --> Loader Class Initialized
INFO - 2025-05-04 05:14:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:27 --> Controller Class Initialized
INFO - 2025-05-04 13:14:27 --> Model "BankModel" initialized
INFO - 2025-05-04 05:14:27 --> Config Class Initialized
INFO - 2025-05-04 05:14:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:27 --> URI Class Initialized
INFO - 2025-05-04 05:14:27 --> Router Class Initialized
INFO - 2025-05-04 05:14:27 --> Output Class Initialized
INFO - 2025-05-04 05:14:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:27 --> Input Class Initialized
INFO - 2025-05-04 05:14:27 --> Language Class Initialized
INFO - 2025-05-04 05:14:27 --> Loader Class Initialized
INFO - 2025-05-04 05:14:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:27 --> Controller Class Initialized
INFO - 2025-05-04 13:14:27 --> Model "BankModel" initialized
INFO - 2025-05-04 13:14:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-04 13:14:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:27 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:27 --> Total execution time: 0.1567
INFO - 2025-05-04 05:14:30 --> Config Class Initialized
INFO - 2025-05-04 05:14:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:30 --> URI Class Initialized
INFO - 2025-05-04 05:14:30 --> Router Class Initialized
INFO - 2025-05-04 05:14:30 --> Output Class Initialized
INFO - 2025-05-04 05:14:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:30 --> Input Class Initialized
INFO - 2025-05-04 05:14:30 --> Language Class Initialized
INFO - 2025-05-04 05:14:30 --> Loader Class Initialized
INFO - 2025-05-04 05:14:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:30 --> Controller Class Initialized
INFO - 2025-05-04 05:14:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:14:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:14:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:14:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:14:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:14:30 --> Final output sent to browser
DEBUG - 2025-05-04 05:14:30 --> Total execution time: 0.1667
INFO - 2025-05-04 05:14:31 --> Config Class Initialized
INFO - 2025-05-04 05:14:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:31 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:31 --> URI Class Initialized
INFO - 2025-05-04 05:14:31 --> Router Class Initialized
INFO - 2025-05-04 05:14:31 --> Output Class Initialized
INFO - 2025-05-04 05:14:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:32 --> Input Class Initialized
INFO - 2025-05-04 05:14:32 --> Language Class Initialized
INFO - 2025-05-04 05:14:32 --> Loader Class Initialized
INFO - 2025-05-04 05:14:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:32 --> Controller Class Initialized
INFO - 2025-05-04 13:14:32 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:32 --> Config Class Initialized
INFO - 2025-05-04 05:14:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:32 --> URI Class Initialized
INFO - 2025-05-04 05:14:32 --> Router Class Initialized
INFO - 2025-05-04 05:14:32 --> Output Class Initialized
INFO - 2025-05-04 05:14:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:32 --> Input Class Initialized
INFO - 2025-05-04 05:14:32 --> Language Class Initialized
INFO - 2025-05-04 05:14:32 --> Loader Class Initialized
INFO - 2025-05-04 05:14:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:32 --> Controller Class Initialized
INFO - 2025-05-04 13:14:32 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:14:32 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:32 --> Total execution time: 0.1979
INFO - 2025-05-04 05:14:32 --> Config Class Initialized
INFO - 2025-05-04 05:14:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:32 --> URI Class Initialized
INFO - 2025-05-04 05:14:32 --> Router Class Initialized
INFO - 2025-05-04 05:14:32 --> Output Class Initialized
INFO - 2025-05-04 05:14:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:32 --> Input Class Initialized
INFO - 2025-05-04 05:14:32 --> Language Class Initialized
INFO - 2025-05-04 05:14:32 --> Loader Class Initialized
INFO - 2025-05-04 05:14:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:32 --> Controller Class Initialized
INFO - 2025-05-04 05:14:32 --> Model "UserModel" initialized
INFO - 2025-05-04 05:14:34 --> Config Class Initialized
INFO - 2025-05-04 05:14:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:34 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:34 --> URI Class Initialized
INFO - 2025-05-04 05:14:34 --> Router Class Initialized
INFO - 2025-05-04 05:14:34 --> Output Class Initialized
INFO - 2025-05-04 05:14:34 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:34 --> Input Class Initialized
INFO - 2025-05-04 05:14:34 --> Language Class Initialized
INFO - 2025-05-04 05:14:34 --> Loader Class Initialized
INFO - 2025-05-04 05:14:34 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:34 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:34 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:34 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:36 --> Config Class Initialized
INFO - 2025-05-04 05:14:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:36 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:36 --> URI Class Initialized
INFO - 2025-05-04 05:14:36 --> Router Class Initialized
INFO - 2025-05-04 05:14:36 --> Output Class Initialized
INFO - 2025-05-04 05:14:36 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:36 --> Input Class Initialized
INFO - 2025-05-04 05:14:36 --> Language Class Initialized
INFO - 2025-05-04 05:14:36 --> Loader Class Initialized
INFO - 2025-05-04 05:14:36 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:36 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:36 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:36 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:36 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:36 --> Controller Class Initialized
INFO - 2025-05-04 13:14:36 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:38 --> Config Class Initialized
INFO - 2025-05-04 05:14:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:38 --> URI Class Initialized
INFO - 2025-05-04 05:14:39 --> Database Driver Class Initialized
INFO - 2025-05-04 05:14:48 --> Config Class Initialized
INFO - 2025-05-04 05:14:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:48 --> URI Class Initialized
INFO - 2025-05-04 05:14:48 --> Router Class Initialized
INFO - 2025-05-04 05:14:48 --> Output Class Initialized
INFO - 2025-05-04 05:14:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:48 --> Input Class Initialized
INFO - 2025-05-04 05:14:48 --> Language Class Initialized
INFO - 2025-05-04 05:14:48 --> Loader Class Initialized
INFO - 2025-05-04 05:14:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:48 --> Controller Class Initialized
INFO - 2025-05-04 13:14:48 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:14:48 --> Config Class Initialized
INFO - 2025-05-04 05:14:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:49 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:49 --> URI Class Initialized
INFO - 2025-05-04 05:14:49 --> Router Class Initialized
INFO - 2025-05-04 05:14:49 --> Output Class Initialized
INFO - 2025-05-04 05:14:49 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:49 --> Input Class Initialized
INFO - 2025-05-04 05:14:49 --> Language Class Initialized
INFO - 2025-05-04 05:14:49 --> Loader Class Initialized
INFO - 2025-05-04 05:14:49 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:49 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:49 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:49 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:49 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:49 --> Controller Class Initialized
INFO - 2025-05-04 13:14:49 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:14:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:14:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:14:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:14:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:14:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:14:49 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:49 --> Total execution time: 0.3989
INFO - 2025-05-04 05:14:53 --> Config Class Initialized
INFO - 2025-05-04 05:14:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:53 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:53 --> URI Class Initialized
INFO - 2025-05-04 05:14:53 --> Router Class Initialized
INFO - 2025-05-04 05:14:53 --> Output Class Initialized
INFO - 2025-05-04 05:14:53 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:53 --> Input Class Initialized
INFO - 2025-05-04 05:14:53 --> Language Class Initialized
INFO - 2025-05-04 05:14:53 --> Loader Class Initialized
INFO - 2025-05-04 05:14:53 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:53 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:53 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:53 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:53 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:53 --> Controller Class Initialized
INFO - 2025-05-04 05:14:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:14:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:14:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:14:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:14:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:14:53 --> Final output sent to browser
DEBUG - 2025-05-04 05:14:53 --> Total execution time: 0.3360
INFO - 2025-05-04 05:14:54 --> Config Class Initialized
INFO - 2025-05-04 05:14:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:54 --> URI Class Initialized
INFO - 2025-05-04 05:14:55 --> Router Class Initialized
INFO - 2025-05-04 05:14:55 --> Config Class Initialized
INFO - 2025-05-04 05:14:55 --> Hooks Class Initialized
INFO - 2025-05-04 05:14:55 --> Output Class Initialized
INFO - 2025-05-04 05:14:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:55 --> Utf8 Class Initialized
DEBUG - 2025-05-04 05:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:55 --> URI Class Initialized
INFO - 2025-05-04 05:14:55 --> Input Class Initialized
INFO - 2025-05-04 05:14:55 --> Language Class Initialized
INFO - 2025-05-04 05:14:55 --> Router Class Initialized
INFO - 2025-05-04 05:14:55 --> Output Class Initialized
INFO - 2025-05-04 05:14:55 --> Loader Class Initialized
INFO - 2025-05-04 05:14:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:55 --> Input Class Initialized
INFO - 2025-05-04 05:14:55 --> Language Class Initialized
INFO - 2025-05-04 05:14:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:55 --> Loader Class Initialized
INFO - 2025-05-04 05:14:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:55 --> Database Driver Class Initialized
INFO - 2025-05-04 05:14:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: html_helper
DEBUG - 2025-05-04 05:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:55 --> Controller Class Initialized
INFO - 2025-05-04 05:14:55 --> Database Driver Class Initialized
INFO - 2025-05-04 13:14:55 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:55 --> Controller Class Initialized
INFO - 2025-05-04 13:14:55 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:14:55 --> Final output sent to browser
DEBUG - 2025-05-04 13:14:55 --> Total execution time: 0.1641
INFO - 2025-05-04 05:14:55 --> Config Class Initialized
INFO - 2025-05-04 05:14:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:14:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:14:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:14:55 --> URI Class Initialized
INFO - 2025-05-04 05:14:55 --> Router Class Initialized
INFO - 2025-05-04 05:14:55 --> Output Class Initialized
INFO - 2025-05-04 05:14:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:14:55 --> Input Class Initialized
INFO - 2025-05-04 05:14:55 --> Language Class Initialized
INFO - 2025-05-04 05:14:55 --> Loader Class Initialized
INFO - 2025-05-04 05:14:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:14:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:14:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:14:55 --> Controller Class Initialized
INFO - 2025-05-04 05:14:55 --> Model "UserModel" initialized
INFO - 2025-05-04 05:15:00 --> Config Class Initialized
INFO - 2025-05-04 05:15:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:15:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:15:00 --> Utf8 Class Initialized
INFO - 2025-05-04 05:15:00 --> URI Class Initialized
INFO - 2025-05-04 05:15:00 --> Router Class Initialized
INFO - 2025-05-04 05:15:00 --> Output Class Initialized
INFO - 2025-05-04 05:15:00 --> Security Class Initialized
DEBUG - 2025-05-04 05:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:15:00 --> Input Class Initialized
INFO - 2025-05-04 05:15:00 --> Language Class Initialized
INFO - 2025-05-04 05:15:00 --> Loader Class Initialized
INFO - 2025-05-04 05:15:01 --> Helper loaded: url_helper
INFO - 2025-05-04 05:15:01 --> Helper loaded: string_helper
INFO - 2025-05-04 05:15:01 --> Helper loaded: form_helper
INFO - 2025-05-04 05:15:01 --> Helper loaded: file_helper
INFO - 2025-05-04 05:15:01 --> Helper loaded: html_helper
INFO - 2025-05-04 05:15:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:15:01 --> Controller Class Initialized
INFO - 2025-05-04 13:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 13:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:15:01 --> Final output sent to browser
DEBUG - 2025-05-04 13:15:01 --> Total execution time: 0.4003
INFO - 2025-05-04 05:15:03 --> Config Class Initialized
INFO - 2025-05-04 05:15:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:15:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:15:03 --> Utf8 Class Initialized
INFO - 2025-05-04 05:15:03 --> URI Class Initialized
INFO - 2025-05-04 05:15:03 --> Router Class Initialized
INFO - 2025-05-04 05:15:03 --> Output Class Initialized
INFO - 2025-05-04 05:15:03 --> Security Class Initialized
DEBUG - 2025-05-04 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:15:03 --> Input Class Initialized
INFO - 2025-05-04 05:15:03 --> Language Class Initialized
INFO - 2025-05-04 05:15:03 --> Loader Class Initialized
INFO - 2025-05-04 05:15:03 --> Helper loaded: url_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: string_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: form_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: file_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: html_helper
INFO - 2025-05-04 05:15:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:15:03 --> Controller Class Initialized
INFO - 2025-05-04 13:15:03 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:15:03 --> Final output sent to browser
DEBUG - 2025-05-04 13:15:03 --> Total execution time: 0.2292
INFO - 2025-05-04 05:15:03 --> Config Class Initialized
INFO - 2025-05-04 05:15:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:15:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:15:03 --> Utf8 Class Initialized
INFO - 2025-05-04 05:15:03 --> URI Class Initialized
INFO - 2025-05-04 05:15:03 --> Router Class Initialized
INFO - 2025-05-04 05:15:03 --> Output Class Initialized
INFO - 2025-05-04 05:15:03 --> Security Class Initialized
DEBUG - 2025-05-04 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:15:03 --> Input Class Initialized
INFO - 2025-05-04 05:15:03 --> Language Class Initialized
INFO - 2025-05-04 05:15:03 --> Loader Class Initialized
INFO - 2025-05-04 05:15:03 --> Helper loaded: url_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: string_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: form_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: file_helper
INFO - 2025-05-04 05:15:03 --> Helper loaded: html_helper
INFO - 2025-05-04 05:15:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:15:03 --> Controller Class Initialized
INFO - 2025-05-04 05:15:03 --> Model "UserModel" initialized
INFO - 2025-05-04 05:25:30 --> Config Class Initialized
INFO - 2025-05-04 05:25:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:30 --> URI Class Initialized
INFO - 2025-05-04 05:25:30 --> Router Class Initialized
INFO - 2025-05-04 05:25:30 --> Output Class Initialized
INFO - 2025-05-04 05:25:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:30 --> Input Class Initialized
INFO - 2025-05-04 05:25:30 --> Language Class Initialized
INFO - 2025-05-04 05:25:30 --> Loader Class Initialized
INFO - 2025-05-04 05:25:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:31 --> Controller Class Initialized
INFO - 2025-05-04 05:25:31 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:25:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:25:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:25:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-04 05:25:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:25:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:25:31 --> Final output sent to browser
DEBUG - 2025-05-04 05:25:31 --> Total execution time: 0.3846
INFO - 2025-05-04 05:25:32 --> Config Class Initialized
INFO - 2025-05-04 05:25:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:32 --> URI Class Initialized
INFO - 2025-05-04 05:25:32 --> Router Class Initialized
INFO - 2025-05-04 05:25:32 --> Output Class Initialized
INFO - 2025-05-04 05:25:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:32 --> Input Class Initialized
INFO - 2025-05-04 05:25:32 --> Language Class Initialized
INFO - 2025-05-04 05:25:32 --> Loader Class Initialized
INFO - 2025-05-04 05:25:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:32 --> Controller Class Initialized
INFO - 2025-05-04 13:25:32 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:25:32 --> Model "StaffModel" initialized
INFO - 2025-05-04 13:25:32 --> Final output sent to browser
DEBUG - 2025-05-04 13:25:32 --> Total execution time: 0.3368
INFO - 2025-05-04 05:25:33 --> Config Class Initialized
INFO - 2025-05-04 05:25:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:33 --> URI Class Initialized
INFO - 2025-05-04 05:25:33 --> Router Class Initialized
INFO - 2025-05-04 05:25:33 --> Output Class Initialized
INFO - 2025-05-04 05:25:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:33 --> Input Class Initialized
INFO - 2025-05-04 05:25:33 --> Language Class Initialized
INFO - 2025-05-04 05:25:33 --> Loader Class Initialized
INFO - 2025-05-04 05:25:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:33 --> Controller Class Initialized
INFO - 2025-05-04 05:25:33 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:25:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:25:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:25:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:25:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:25:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:25:33 --> Final output sent to browser
DEBUG - 2025-05-04 05:25:33 --> Total execution time: 0.3394
INFO - 2025-05-04 05:25:33 --> Config Class Initialized
INFO - 2025-05-04 05:25:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:33 --> URI Class Initialized
INFO - 2025-05-04 05:25:33 --> Router Class Initialized
INFO - 2025-05-04 05:25:33 --> Output Class Initialized
INFO - 2025-05-04 05:25:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:33 --> Input Class Initialized
INFO - 2025-05-04 05:25:33 --> Language Class Initialized
INFO - 2025-05-04 05:25:33 --> Loader Class Initialized
INFO - 2025-05-04 05:25:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:34 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:34 --> Controller Class Initialized
INFO - 2025-05-04 05:25:34 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:25:34 --> Final output sent to browser
DEBUG - 2025-05-04 05:25:34 --> Total execution time: 0.6439
INFO - 2025-05-04 05:25:36 --> Config Class Initialized
INFO - 2025-05-04 05:25:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:36 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:36 --> URI Class Initialized
INFO - 2025-05-04 05:25:36 --> Router Class Initialized
INFO - 2025-05-04 05:25:36 --> Output Class Initialized
INFO - 2025-05-04 05:25:36 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:36 --> Input Class Initialized
INFO - 2025-05-04 05:25:36 --> Language Class Initialized
INFO - 2025-05-04 05:25:36 --> Loader Class Initialized
INFO - 2025-05-04 05:25:36 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:36 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:36 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:36 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:36 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/details.php
INFO - 2025-05-04 05:25:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:25:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:25:37 --> Final output sent to browser
DEBUG - 2025-05-04 05:25:37 --> Total execution time: 0.2547
INFO - 2025-05-04 05:25:38 --> Config Class Initialized
INFO - 2025-05-04 05:25:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:38 --> URI Class Initialized
INFO - 2025-05-04 05:25:38 --> Router Class Initialized
INFO - 2025-05-04 05:25:38 --> Output Class Initialized
INFO - 2025-05-04 05:25:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:38 --> Input Class Initialized
INFO - 2025-05-04 05:25:38 --> Language Class Initialized
INFO - 2025-05-04 05:25:38 --> Loader Class Initialized
INFO - 2025-05-04 05:25:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:38 --> Controller Class Initialized
INFO - 2025-05-04 13:25:38 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:25:38 --> Final output sent to browser
DEBUG - 2025-05-04 13:25:38 --> Total execution time: 0.4616
INFO - 2025-05-04 05:25:40 --> Config Class Initialized
INFO - 2025-05-04 05:25:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:25:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:25:40 --> Utf8 Class Initialized
INFO - 2025-05-04 05:25:40 --> URI Class Initialized
INFO - 2025-05-04 05:25:40 --> Router Class Initialized
INFO - 2025-05-04 05:25:40 --> Output Class Initialized
INFO - 2025-05-04 05:25:40 --> Security Class Initialized
DEBUG - 2025-05-04 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:25:40 --> Input Class Initialized
INFO - 2025-05-04 05:25:40 --> Language Class Initialized
INFO - 2025-05-04 05:25:40 --> Loader Class Initialized
INFO - 2025-05-04 05:25:40 --> Helper loaded: url_helper
INFO - 2025-05-04 05:25:40 --> Helper loaded: string_helper
INFO - 2025-05-04 05:25:40 --> Helper loaded: form_helper
INFO - 2025-05-04 05:25:40 --> Helper loaded: file_helper
INFO - 2025-05-04 05:25:40 --> Helper loaded: html_helper
INFO - 2025-05-04 05:25:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:25:40 --> Controller Class Initialized
INFO - 2025-05-04 05:25:40 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:25:40 --> Final output sent to browser
DEBUG - 2025-05-04 05:25:40 --> Total execution time: 0.2215
INFO - 2025-05-04 05:26:23 --> Config Class Initialized
INFO - 2025-05-04 05:26:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:23 --> URI Class Initialized
INFO - 2025-05-04 05:26:23 --> Router Class Initialized
INFO - 2025-05-04 05:26:23 --> Output Class Initialized
INFO - 2025-05-04 05:26:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:23 --> Input Class Initialized
INFO - 2025-05-04 05:26:23 --> Language Class Initialized
INFO - 2025-05-04 05:26:23 --> Loader Class Initialized
INFO - 2025-05-04 05:26:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:23 --> Controller Class Initialized
INFO - 2025-05-04 05:26:23 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:26:23 --> Config Class Initialized
INFO - 2025-05-04 05:26:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:23 --> URI Class Initialized
INFO - 2025-05-04 05:26:23 --> Router Class Initialized
INFO - 2025-05-04 05:26:23 --> Output Class Initialized
INFO - 2025-05-04 05:26:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:23 --> Input Class Initialized
INFO - 2025-05-04 05:26:23 --> Language Class Initialized
INFO - 2025-05-04 05:26:23 --> Loader Class Initialized
INFO - 2025-05-04 05:26:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:23 --> Controller Class Initialized
INFO - 2025-05-04 13:26:23 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:26:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:26:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:26:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:26:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:26:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:26:23 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:23 --> Total execution time: 0.0954
INFO - 2025-05-04 05:26:26 --> Config Class Initialized
INFO - 2025-05-04 05:26:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:26 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:26 --> URI Class Initialized
INFO - 2025-05-04 05:26:26 --> Router Class Initialized
INFO - 2025-05-04 05:26:26 --> Output Class Initialized
INFO - 2025-05-04 05:26:26 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:26 --> Input Class Initialized
INFO - 2025-05-04 05:26:26 --> Language Class Initialized
INFO - 2025-05-04 05:26:26 --> Loader Class Initialized
INFO - 2025-05-04 05:26:26 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:26 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:26 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:27 --> Controller Class Initialized
INFO - 2025-05-04 05:26:27 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:26:27 --> Config Class Initialized
INFO - 2025-05-04 05:26:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:27 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:27 --> URI Class Initialized
INFO - 2025-05-04 05:26:27 --> Router Class Initialized
INFO - 2025-05-04 05:26:27 --> Output Class Initialized
INFO - 2025-05-04 05:26:27 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:27 --> Input Class Initialized
INFO - 2025-05-04 05:26:27 --> Language Class Initialized
INFO - 2025-05-04 05:26:27 --> Loader Class Initialized
INFO - 2025-05-04 05:26:27 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:27 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:27 --> Controller Class Initialized
INFO - 2025-05-04 13:26:27 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:26:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:26:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:26:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:26:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:26:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:26:27 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:27 --> Total execution time: 0.1331
INFO - 2025-05-04 05:26:30 --> Config Class Initialized
INFO - 2025-05-04 05:26:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:30 --> URI Class Initialized
INFO - 2025-05-04 05:26:30 --> Router Class Initialized
INFO - 2025-05-04 05:26:30 --> Output Class Initialized
INFO - 2025-05-04 05:26:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:30 --> Input Class Initialized
INFO - 2025-05-04 05:26:30 --> Language Class Initialized
INFO - 2025-05-04 05:26:30 --> Loader Class Initialized
INFO - 2025-05-04 05:26:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:30 --> Controller Class Initialized
INFO - 2025-05-04 05:26:30 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:26:30 --> Config Class Initialized
INFO - 2025-05-04 05:26:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:30 --> URI Class Initialized
INFO - 2025-05-04 05:26:30 --> Router Class Initialized
INFO - 2025-05-04 05:26:30 --> Output Class Initialized
INFO - 2025-05-04 05:26:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:30 --> Input Class Initialized
INFO - 2025-05-04 05:26:30 --> Language Class Initialized
INFO - 2025-05-04 05:26:30 --> Loader Class Initialized
INFO - 2025-05-04 05:26:30 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:30 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:30 --> Controller Class Initialized
INFO - 2025-05-04 13:26:30 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:26:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:26:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:26:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:26:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:26:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:26:30 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:30 --> Total execution time: 0.2971
INFO - 2025-05-04 05:26:36 --> Config Class Initialized
INFO - 2025-05-04 05:26:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:36 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:36 --> URI Class Initialized
INFO - 2025-05-04 05:26:36 --> Router Class Initialized
INFO - 2025-05-04 05:26:36 --> Output Class Initialized
INFO - 2025-05-04 05:26:36 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:36 --> Input Class Initialized
INFO - 2025-05-04 05:26:36 --> Language Class Initialized
INFO - 2025-05-04 05:26:36 --> Loader Class Initialized
INFO - 2025-05-04 05:26:36 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:36 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:36 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:36 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:36 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:37 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:37 --> Controller Class Initialized
INFO - 2025-05-04 05:26:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:26:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:26:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:26:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:26:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:26:37 --> Final output sent to browser
DEBUG - 2025-05-04 05:26:37 --> Total execution time: 0.2343
INFO - 2025-05-04 05:26:42 --> Config Class Initialized
INFO - 2025-05-04 05:26:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:42 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:42 --> URI Class Initialized
INFO - 2025-05-04 05:26:42 --> Router Class Initialized
INFO - 2025-05-04 05:26:42 --> Output Class Initialized
INFO - 2025-05-04 05:26:42 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:42 --> Input Class Initialized
INFO - 2025-05-04 05:26:42 --> Language Class Initialized
INFO - 2025-05-04 05:26:42 --> Loader Class Initialized
INFO - 2025-05-04 05:26:42 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:42 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:42 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:42 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:42 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:42 --> Controller Class Initialized
INFO - 2025-05-04 13:26:42 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:26:43 --> Config Class Initialized
INFO - 2025-05-04 05:26:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:43 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:43 --> URI Class Initialized
INFO - 2025-05-04 05:26:43 --> Router Class Initialized
INFO - 2025-05-04 05:26:43 --> Output Class Initialized
INFO - 2025-05-04 05:26:43 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:43 --> Input Class Initialized
INFO - 2025-05-04 05:26:43 --> Language Class Initialized
INFO - 2025-05-04 05:26:43 --> Loader Class Initialized
INFO - 2025-05-04 05:26:43 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:43 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:43 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:43 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:43 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:43 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:43 --> Controller Class Initialized
INFO - 2025-05-04 13:26:43 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:26:43 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:43 --> Total execution time: 0.1338
INFO - 2025-05-04 05:26:46 --> Config Class Initialized
INFO - 2025-05-04 05:26:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:46 --> URI Class Initialized
INFO - 2025-05-04 05:26:46 --> Router Class Initialized
INFO - 2025-05-04 05:26:46 --> Output Class Initialized
INFO - 2025-05-04 05:26:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:46 --> Input Class Initialized
INFO - 2025-05-04 05:26:46 --> Language Class Initialized
INFO - 2025-05-04 05:26:46 --> Loader Class Initialized
INFO - 2025-05-04 05:26:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:46 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:46 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:46 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:46 --> Controller Class Initialized
INFO - 2025-05-04 05:26:46 --> Model "UserModel" initialized
INFO - 2025-05-04 05:26:47 --> Config Class Initialized
INFO - 2025-05-04 05:26:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:47 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:47 --> URI Class Initialized
INFO - 2025-05-04 05:26:47 --> Router Class Initialized
INFO - 2025-05-04 05:26:47 --> Output Class Initialized
INFO - 2025-05-04 05:26:47 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:47 --> Input Class Initialized
INFO - 2025-05-04 05:26:47 --> Language Class Initialized
INFO - 2025-05-04 05:26:47 --> Loader Class Initialized
INFO - 2025-05-04 05:26:47 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:47 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:47 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:47 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:47 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:47 --> Controller Class Initialized
INFO - 2025-05-04 13:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 13:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:26:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:26:47 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:47 --> Total execution time: 0.3130
INFO - 2025-05-04 05:26:48 --> Config Class Initialized
INFO - 2025-05-04 05:26:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:48 --> URI Class Initialized
INFO - 2025-05-04 05:26:48 --> Router Class Initialized
INFO - 2025-05-04 05:26:48 --> Output Class Initialized
INFO - 2025-05-04 05:26:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:48 --> Input Class Initialized
INFO - 2025-05-04 05:26:48 --> Language Class Initialized
INFO - 2025-05-04 05:26:48 --> Loader Class Initialized
INFO - 2025-05-04 05:26:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:48 --> Controller Class Initialized
INFO - 2025-05-04 13:26:48 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:26:48 --> Final output sent to browser
DEBUG - 2025-05-04 13:26:48 --> Total execution time: 0.1762
INFO - 2025-05-04 05:26:48 --> Config Class Initialized
INFO - 2025-05-04 05:26:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:26:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:26:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:26:48 --> URI Class Initialized
INFO - 2025-05-04 05:26:48 --> Router Class Initialized
INFO - 2025-05-04 05:26:48 --> Output Class Initialized
INFO - 2025-05-04 05:26:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:26:48 --> Input Class Initialized
INFO - 2025-05-04 05:26:48 --> Language Class Initialized
INFO - 2025-05-04 05:26:48 --> Loader Class Initialized
INFO - 2025-05-04 05:26:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:26:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:26:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:26:49 --> Controller Class Initialized
INFO - 2025-05-04 05:26:49 --> Model "UserModel" initialized
INFO - 2025-05-04 05:27:06 --> Config Class Initialized
INFO - 2025-05-04 05:27:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:27:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:27:06 --> Utf8 Class Initialized
INFO - 2025-05-04 05:27:06 --> URI Class Initialized
INFO - 2025-05-04 05:27:06 --> Router Class Initialized
INFO - 2025-05-04 05:27:06 --> Output Class Initialized
INFO - 2025-05-04 05:27:06 --> Security Class Initialized
DEBUG - 2025-05-04 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:27:06 --> Input Class Initialized
INFO - 2025-05-04 05:27:06 --> Language Class Initialized
INFO - 2025-05-04 05:27:06 --> Loader Class Initialized
INFO - 2025-05-04 05:27:06 --> Helper loaded: url_helper
INFO - 2025-05-04 05:27:06 --> Helper loaded: string_helper
INFO - 2025-05-04 05:27:06 --> Helper loaded: form_helper
INFO - 2025-05-04 05:27:06 --> Helper loaded: file_helper
INFO - 2025-05-04 05:27:06 --> Helper loaded: html_helper
INFO - 2025-05-04 05:27:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:27:06 --> Controller Class Initialized
INFO - 2025-05-04 13:27:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:27:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:27:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 13:27:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:27:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:27:06 --> Final output sent to browser
DEBUG - 2025-05-04 13:27:06 --> Total execution time: 0.1621
INFO - 2025-05-04 05:27:06 --> Config Class Initialized
INFO - 2025-05-04 05:27:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:27:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:27:07 --> Utf8 Class Initialized
INFO - 2025-05-04 05:27:07 --> URI Class Initialized
INFO - 2025-05-04 05:27:07 --> Router Class Initialized
INFO - 2025-05-04 05:27:07 --> Output Class Initialized
INFO - 2025-05-04 05:27:07 --> Security Class Initialized
DEBUG - 2025-05-04 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:27:07 --> Input Class Initialized
INFO - 2025-05-04 05:27:07 --> Language Class Initialized
INFO - 2025-05-04 05:27:07 --> Loader Class Initialized
INFO - 2025-05-04 05:27:07 --> Helper loaded: url_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: string_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: form_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: file_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: html_helper
INFO - 2025-05-04 05:27:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:27:07 --> Controller Class Initialized
INFO - 2025-05-04 13:27:07 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:27:07 --> Final output sent to browser
DEBUG - 2025-05-04 13:27:07 --> Total execution time: 0.1821
INFO - 2025-05-04 05:27:07 --> Config Class Initialized
INFO - 2025-05-04 05:27:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:27:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:27:07 --> Utf8 Class Initialized
INFO - 2025-05-04 05:27:07 --> URI Class Initialized
INFO - 2025-05-04 05:27:07 --> Router Class Initialized
INFO - 2025-05-04 05:27:07 --> Output Class Initialized
INFO - 2025-05-04 05:27:07 --> Security Class Initialized
DEBUG - 2025-05-04 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:27:07 --> Input Class Initialized
INFO - 2025-05-04 05:27:07 --> Language Class Initialized
INFO - 2025-05-04 05:27:07 --> Loader Class Initialized
INFO - 2025-05-04 05:27:07 --> Helper loaded: url_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: string_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: form_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: file_helper
INFO - 2025-05-04 05:27:07 --> Helper loaded: html_helper
INFO - 2025-05-04 05:27:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:27:07 --> Controller Class Initialized
INFO - 2025-05-04 05:27:07 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:08 --> Config Class Initialized
INFO - 2025-05-04 05:53:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:08 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:08 --> URI Class Initialized
INFO - 2025-05-04 05:53:08 --> Router Class Initialized
INFO - 2025-05-04 05:53:08 --> Output Class Initialized
INFO - 2025-05-04 05:53:08 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:08 --> Input Class Initialized
INFO - 2025-05-04 05:53:08 --> Language Class Initialized
INFO - 2025-05-04 05:53:08 --> Loader Class Initialized
INFO - 2025-05-04 05:53:08 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:08 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:08 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:08 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:08 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:08 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:08 --> Controller Class Initialized
INFO - 2025-05-04 05:53:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:53:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:53:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:53:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:53:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:53:08 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:08 --> Total execution time: 0.1561
INFO - 2025-05-04 05:53:10 --> Config Class Initialized
INFO - 2025-05-04 05:53:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:10 --> URI Class Initialized
INFO - 2025-05-04 05:53:10 --> Router Class Initialized
INFO - 2025-05-04 05:53:10 --> Output Class Initialized
INFO - 2025-05-04 05:53:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:10 --> Input Class Initialized
INFO - 2025-05-04 05:53:10 --> Language Class Initialized
INFO - 2025-05-04 05:53:10 --> Loader Class Initialized
INFO - 2025-05-04 05:53:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:10 --> Controller Class Initialized
INFO - 2025-05-04 05:53:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:53:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:53:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:53:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:53:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:53:10 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:10 --> Total execution time: 0.1152
INFO - 2025-05-04 05:53:11 --> Config Class Initialized
INFO - 2025-05-04 05:53:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:11 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:11 --> URI Class Initialized
INFO - 2025-05-04 05:53:11 --> Router Class Initialized
INFO - 2025-05-04 05:53:11 --> Config Class Initialized
INFO - 2025-05-04 05:53:11 --> Hooks Class Initialized
INFO - 2025-05-04 05:53:11 --> Output Class Initialized
INFO - 2025-05-04 05:53:11 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:11 --> Utf8 Class Initialized
DEBUG - 2025-05-04 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:11 --> Input Class Initialized
INFO - 2025-05-04 05:53:11 --> Language Class Initialized
INFO - 2025-05-04 05:53:11 --> URI Class Initialized
INFO - 2025-05-04 05:53:12 --> Router Class Initialized
INFO - 2025-05-04 05:53:12 --> Output Class Initialized
INFO - 2025-05-04 05:53:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:12 --> Input Class Initialized
INFO - 2025-05-04 05:53:12 --> Language Class Initialized
INFO - 2025-05-04 05:53:12 --> Loader Class Initialized
INFO - 2025-05-04 05:53:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:12 --> Loader Class Initialized
INFO - 2025-05-04 05:53:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:12 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:12 --> Controller Class Initialized
INFO - 2025-05-04 13:53:12 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 13:53:12 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 13:53:12 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:12 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:12 --> Total execution time: 0.6598
INFO - 2025-05-04 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:12 --> Controller Class Initialized
INFO - 2025-05-04 13:53:12 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:12 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:12 --> Total execution time: 0.6455
INFO - 2025-05-04 05:53:12 --> Config Class Initialized
INFO - 2025-05-04 05:53:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:12 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:12 --> URI Class Initialized
INFO - 2025-05-04 05:53:12 --> Router Class Initialized
INFO - 2025-05-04 05:53:12 --> Output Class Initialized
INFO - 2025-05-04 05:53:12 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:12 --> Input Class Initialized
INFO - 2025-05-04 05:53:12 --> Language Class Initialized
INFO - 2025-05-04 05:53:12 --> Loader Class Initialized
INFO - 2025-05-04 05:53:12 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:12 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:13 --> Controller Class Initialized
INFO - 2025-05-04 13:53:13 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:53:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:53:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:53:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 13:53:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:53:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:53:13 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:13 --> Total execution time: 0.1763
INFO - 2025-05-04 05:53:13 --> Config Class Initialized
INFO - 2025-05-04 05:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:13 --> URI Class Initialized
INFO - 2025-05-04 05:53:13 --> Router Class Initialized
INFO - 2025-05-04 05:53:13 --> Output Class Initialized
INFO - 2025-05-04 05:53:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:13 --> Input Class Initialized
INFO - 2025-05-04 05:53:13 --> Language Class Initialized
INFO - 2025-05-04 05:53:13 --> Loader Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:13 --> Controller Class Initialized
INFO - 2025-05-04 05:53:13 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:13 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:13 --> Total execution time: 0.1416
INFO - 2025-05-04 05:53:13 --> Config Class Initialized
INFO - 2025-05-04 05:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:13 --> URI Class Initialized
INFO - 2025-05-04 05:53:13 --> Router Class Initialized
INFO - 2025-05-04 05:53:13 --> Output Class Initialized
INFO - 2025-05-04 05:53:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:13 --> Input Class Initialized
INFO - 2025-05-04 05:53:13 --> Language Class Initialized
INFO - 2025-05-04 05:53:13 --> Loader Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:13 --> Controller Class Initialized
INFO - 2025-05-04 13:53:13 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:13 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:13 --> Total execution time: 0.1684
INFO - 2025-05-04 05:53:13 --> Config Class Initialized
INFO - 2025-05-04 05:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:13 --> URI Class Initialized
INFO - 2025-05-04 05:53:13 --> Router Class Initialized
INFO - 2025-05-04 05:53:13 --> Output Class Initialized
INFO - 2025-05-04 05:53:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:13 --> Input Class Initialized
INFO - 2025-05-04 05:53:13 --> Language Class Initialized
INFO - 2025-05-04 05:53:13 --> Config Class Initialized
INFO - 2025-05-04 05:53:13 --> Hooks Class Initialized
INFO - 2025-05-04 05:53:13 --> Loader Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: url_helper
DEBUG - 2025-05-04 05:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:13 --> URI Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:13 --> Router Class Initialized
INFO - 2025-05-04 05:53:13 --> Output Class Initialized
INFO - 2025-05-04 05:53:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:13 --> Input Class Initialized
INFO - 2025-05-04 05:53:13 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:13 --> Language Class Initialized
INFO - 2025-05-04 05:53:13 --> Loader Class Initialized
INFO - 2025-05-04 05:53:13 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:13 --> Helper loaded: html_helper
DEBUG - 2025-05-04 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:13 --> Controller Class Initialized
INFO - 2025-05-04 05:53:13 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:13 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:13 --> Total execution time: 0.1233
INFO - 2025-05-04 05:53:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:13 --> Controller Class Initialized
INFO - 2025-05-04 13:53:13 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:53:14 --> Config Class Initialized
INFO - 2025-05-04 05:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:14 --> URI Class Initialized
INFO - 2025-05-04 05:53:14 --> Router Class Initialized
INFO - 2025-05-04 05:53:14 --> Output Class Initialized
INFO - 2025-05-04 05:53:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:14 --> Input Class Initialized
INFO - 2025-05-04 05:53:14 --> Language Class Initialized
INFO - 2025-05-04 05:53:14 --> Loader Class Initialized
INFO - 2025-05-04 05:53:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:14 --> Controller Class Initialized
INFO - 2025-05-04 13:53:14 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:14 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:14 --> Total execution time: 0.1181
INFO - 2025-05-04 05:53:14 --> Config Class Initialized
INFO - 2025-05-04 05:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:14 --> URI Class Initialized
INFO - 2025-05-04 05:53:14 --> Router Class Initialized
INFO - 2025-05-04 05:53:14 --> Output Class Initialized
INFO - 2025-05-04 05:53:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:14 --> Input Class Initialized
INFO - 2025-05-04 05:53:14 --> Language Class Initialized
INFO - 2025-05-04 05:53:14 --> Loader Class Initialized
INFO - 2025-05-04 05:53:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:14 --> Controller Class Initialized
INFO - 2025-05-04 13:53:14 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:14 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:14 --> Total execution time: 0.1269
INFO - 2025-05-04 05:53:16 --> Config Class Initialized
INFO - 2025-05-04 05:53:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:16 --> URI Class Initialized
INFO - 2025-05-04 05:53:16 --> Router Class Initialized
INFO - 2025-05-04 05:53:16 --> Output Class Initialized
INFO - 2025-05-04 05:53:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:16 --> Input Class Initialized
INFO - 2025-05-04 05:53:16 --> Language Class Initialized
INFO - 2025-05-04 05:53:16 --> Loader Class Initialized
INFO - 2025-05-04 05:53:17 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:17 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:17 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:17 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:17 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:17 --> Controller Class Initialized
INFO - 2025-05-04 05:53:17 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:19 --> Config Class Initialized
INFO - 2025-05-04 05:53:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:19 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:19 --> URI Class Initialized
INFO - 2025-05-04 05:53:19 --> Router Class Initialized
INFO - 2025-05-04 05:53:19 --> Output Class Initialized
INFO - 2025-05-04 05:53:19 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:19 --> Input Class Initialized
INFO - 2025-05-04 05:53:19 --> Language Class Initialized
INFO - 2025-05-04 05:53:19 --> Loader Class Initialized
INFO - 2025-05-04 05:53:19 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:19 --> Controller Class Initialized
INFO - 2025-05-04 13:53:19 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:53:19 --> Config Class Initialized
INFO - 2025-05-04 05:53:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:19 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:19 --> URI Class Initialized
INFO - 2025-05-04 05:53:19 --> Router Class Initialized
INFO - 2025-05-04 05:53:19 --> Output Class Initialized
INFO - 2025-05-04 05:53:19 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:19 --> Input Class Initialized
INFO - 2025-05-04 05:53:19 --> Language Class Initialized
INFO - 2025-05-04 05:53:19 --> Loader Class Initialized
INFO - 2025-05-04 05:53:19 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:19 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:19 --> Controller Class Initialized
INFO - 2025-05-04 13:53:19 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:53:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:53:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:53:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:53:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:53:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:53:19 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:19 --> Total execution time: 0.1318
INFO - 2025-05-04 05:53:38 --> Config Class Initialized
INFO - 2025-05-04 05:53:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:38 --> URI Class Initialized
INFO - 2025-05-04 05:53:38 --> Router Class Initialized
INFO - 2025-05-04 05:53:38 --> Output Class Initialized
INFO - 2025-05-04 05:53:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:38 --> Input Class Initialized
INFO - 2025-05-04 05:53:38 --> Language Class Initialized
INFO - 2025-05-04 05:53:38 --> Loader Class Initialized
INFO - 2025-05-04 05:53:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:38 --> Controller Class Initialized
INFO - 2025-05-04 05:53:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:53:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:53:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:53:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:53:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:53:38 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:38 --> Total execution time: 0.3151
INFO - 2025-05-04 05:53:38 --> Config Class Initialized
INFO - 2025-05-04 05:53:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:38 --> Config Class Initialized
INFO - 2025-05-04 05:53:38 --> Hooks Class Initialized
INFO - 2025-05-04 05:53:38 --> URI Class Initialized
DEBUG - 2025-05-04 05:53:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:38 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:38 --> Router Class Initialized
INFO - 2025-05-04 05:53:38 --> URI Class Initialized
INFO - 2025-05-04 05:53:38 --> Router Class Initialized
INFO - 2025-05-04 05:53:38 --> Output Class Initialized
INFO - 2025-05-04 05:53:38 --> Output Class Initialized
INFO - 2025-05-04 05:53:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:38 --> Input Class Initialized
INFO - 2025-05-04 05:53:38 --> Language Class Initialized
INFO - 2025-05-04 05:53:38 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:38 --> Input Class Initialized
INFO - 2025-05-04 05:53:38 --> Language Class Initialized
INFO - 2025-05-04 05:53:38 --> Loader Class Initialized
INFO - 2025-05-04 05:53:38 --> Loader Class Initialized
INFO - 2025-05-04 05:53:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:38 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:38 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:38 --> Controller Class Initialized
INFO - 2025-05-04 13:53:38 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 05:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 13:53:38 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 13:53:39 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:39 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:39 --> Total execution time: 0.3197
INFO - 2025-05-04 05:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:39 --> Controller Class Initialized
INFO - 2025-05-04 13:53:39 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:39 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:39 --> Total execution time: 0.3364
INFO - 2025-05-04 05:53:39 --> Config Class Initialized
INFO - 2025-05-04 05:53:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:39 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:39 --> URI Class Initialized
INFO - 2025-05-04 05:53:39 --> Router Class Initialized
INFO - 2025-05-04 05:53:39 --> Output Class Initialized
INFO - 2025-05-04 05:53:39 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:39 --> Input Class Initialized
INFO - 2025-05-04 05:53:39 --> Language Class Initialized
INFO - 2025-05-04 05:53:39 --> Loader Class Initialized
INFO - 2025-05-04 05:53:39 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:39 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:39 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:39 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:39 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:39 --> Controller Class Initialized
INFO - 2025-05-04 05:53:39 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:39 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:39 --> Total execution time: 0.2971
INFO - 2025-05-04 05:53:42 --> Config Class Initialized
INFO - 2025-05-04 05:53:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:42 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:42 --> URI Class Initialized
INFO - 2025-05-04 05:53:42 --> Router Class Initialized
INFO - 2025-05-04 05:53:42 --> Output Class Initialized
INFO - 2025-05-04 05:53:42 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:42 --> Input Class Initialized
INFO - 2025-05-04 05:53:42 --> Language Class Initialized
INFO - 2025-05-04 05:53:42 --> Loader Class Initialized
INFO - 2025-05-04 05:53:42 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:42 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:42 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:42 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:42 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:42 --> Controller Class Initialized
INFO - 2025-05-04 13:53:42 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:53:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:53:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/details.php
INFO - 2025-05-04 13:53:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:53:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:53:42 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:42 --> Total execution time: 0.3878
INFO - 2025-05-04 05:53:43 --> Config Class Initialized
INFO - 2025-05-04 05:53:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:43 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:43 --> URI Class Initialized
INFO - 2025-05-04 05:53:43 --> Router Class Initialized
INFO - 2025-05-04 05:53:43 --> Output Class Initialized
INFO - 2025-05-04 05:53:43 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:43 --> Input Class Initialized
INFO - 2025-05-04 05:53:43 --> Language Class Initialized
INFO - 2025-05-04 05:53:43 --> Loader Class Initialized
INFO - 2025-05-04 05:53:43 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:43 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:43 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:43 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:43 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:43 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:43 --> Controller Class Initialized
INFO - 2025-05-04 13:53:43 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:43 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:43 --> Total execution time: 0.7029
INFO - 2025-05-04 05:53:44 --> Config Class Initialized
INFO - 2025-05-04 05:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:44 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:44 --> URI Class Initialized
INFO - 2025-05-04 05:53:44 --> Router Class Initialized
INFO - 2025-05-04 05:53:44 --> Output Class Initialized
INFO - 2025-05-04 05:53:44 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:44 --> Input Class Initialized
INFO - 2025-05-04 05:53:44 --> Language Class Initialized
INFO - 2025-05-04 05:53:44 --> Loader Class Initialized
INFO - 2025-05-04 05:53:44 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:44 --> Controller Class Initialized
INFO - 2025-05-04 05:53:44 --> Model "UserModel" initialized
INFO - 2025-05-04 05:53:44 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:44 --> Total execution time: 0.1844
INFO - 2025-05-04 05:53:44 --> Config Class Initialized
INFO - 2025-05-04 05:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:44 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:44 --> URI Class Initialized
INFO - 2025-05-04 05:53:44 --> Router Class Initialized
INFO - 2025-05-04 05:53:44 --> Output Class Initialized
INFO - 2025-05-04 05:53:44 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:44 --> Input Class Initialized
INFO - 2025-05-04 05:53:44 --> Language Class Initialized
INFO - 2025-05-04 05:53:44 --> Loader Class Initialized
INFO - 2025-05-04 05:53:44 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:44 --> Controller Class Initialized
INFO - 2025-05-04 13:53:44 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:53:44 --> Final output sent to browser
DEBUG - 2025-05-04 13:53:44 --> Total execution time: 0.3183
INFO - 2025-05-04 05:53:44 --> Config Class Initialized
INFO - 2025-05-04 05:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:44 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:44 --> URI Class Initialized
INFO - 2025-05-04 05:53:44 --> Router Class Initialized
INFO - 2025-05-04 05:53:44 --> Output Class Initialized
INFO - 2025-05-04 05:53:44 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:44 --> Input Class Initialized
INFO - 2025-05-04 05:53:44 --> Language Class Initialized
INFO - 2025-05-04 05:53:44 --> Loader Class Initialized
INFO - 2025-05-04 05:53:44 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:44 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:44 --> Controller Class Initialized
INFO - 2025-05-04 05:53:44 --> Config Class Initialized
INFO - 2025-05-04 05:53:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:45 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:45 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:45 --> URI Class Initialized
INFO - 2025-05-04 05:53:45 --> Router Class Initialized
INFO - 2025-05-04 05:53:45 --> Output Class Initialized
INFO - 2025-05-04 05:53:45 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:45 --> Input Class Initialized
INFO - 2025-05-04 05:53:45 --> Language Class Initialized
INFO - 2025-05-04 05:53:45 --> Loader Class Initialized
INFO - 2025-05-04 05:53:45 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:45 --> Helper loaded: string_helper
INFO - 2025-05-04 05:53:45 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:45 --> Helper loaded: file_helper
INFO - 2025-05-04 05:53:45 --> Helper loaded: html_helper
INFO - 2025-05-04 05:53:45 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:45 --> Controller Class Initialized
INFO - 2025-05-04 13:53:45 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:54:14 --> Config Class Initialized
INFO - 2025-05-04 05:54:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:14 --> URI Class Initialized
INFO - 2025-05-04 05:54:14 --> Router Class Initialized
INFO - 2025-05-04 05:54:14 --> Output Class Initialized
INFO - 2025-05-04 05:54:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:14 --> Input Class Initialized
INFO - 2025-05-04 05:54:14 --> Language Class Initialized
INFO - 2025-05-04 05:54:14 --> Loader Class Initialized
INFO - 2025-05-04 05:54:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:15 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:15 --> Controller Class Initialized
INFO - 2025-05-04 05:54:15 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:54:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:54:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:54:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:54:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:54:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:54:15 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:15 --> Total execution time: 0.1953
INFO - 2025-05-04 05:54:15 --> Config Class Initialized
INFO - 2025-05-04 05:54:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:15 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:15 --> URI Class Initialized
INFO - 2025-05-04 05:54:15 --> Router Class Initialized
INFO - 2025-05-04 05:54:15 --> Output Class Initialized
INFO - 2025-05-04 05:54:15 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:15 --> Input Class Initialized
INFO - 2025-05-04 05:54:15 --> Language Class Initialized
INFO - 2025-05-04 05:54:15 --> Loader Class Initialized
INFO - 2025-05-04 05:54:15 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:15 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:15 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:15 --> Controller Class Initialized
INFO - 2025-05-04 05:54:15 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:54:16 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:16 --> Total execution time: 0.6047
INFO - 2025-05-04 05:54:16 --> Config Class Initialized
INFO - 2025-05-04 05:54:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:16 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:16 --> URI Class Initialized
INFO - 2025-05-04 05:54:16 --> Router Class Initialized
INFO - 2025-05-04 05:54:16 --> Output Class Initialized
INFO - 2025-05-04 05:54:16 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:16 --> Input Class Initialized
INFO - 2025-05-04 05:54:16 --> Language Class Initialized
INFO - 2025-05-04 05:54:16 --> Loader Class Initialized
INFO - 2025-05-04 05:54:16 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:16 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:16 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:16 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:16 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:16 --> Controller Class Initialized
INFO - 2025-05-04 05:54:16 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:54:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:54:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:54:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/add_storage_facility.php
INFO - 2025-05-04 05:54:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:54:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:54:16 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:16 --> Total execution time: 0.2366
INFO - 2025-05-04 05:54:17 --> Config Class Initialized
INFO - 2025-05-04 05:54:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:17 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:17 --> URI Class Initialized
INFO - 2025-05-04 05:54:17 --> Router Class Initialized
INFO - 2025-05-04 05:54:17 --> Output Class Initialized
INFO - 2025-05-04 05:54:17 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:17 --> Input Class Initialized
INFO - 2025-05-04 05:54:17 --> Language Class Initialized
INFO - 2025-05-04 05:54:17 --> Loader Class Initialized
INFO - 2025-05-04 05:54:17 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:17 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:17 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:17 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:17 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:17 --> Controller Class Initialized
INFO - 2025-05-04 13:54:17 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:54:17 --> Final output sent to browser
DEBUG - 2025-05-04 13:54:17 --> Total execution time: 0.4024
INFO - 2025-05-04 05:54:48 --> Config Class Initialized
INFO - 2025-05-04 05:54:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:48 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:48 --> URI Class Initialized
INFO - 2025-05-04 05:54:48 --> Router Class Initialized
INFO - 2025-05-04 05:54:48 --> Output Class Initialized
INFO - 2025-05-04 05:54:48 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:48 --> Input Class Initialized
INFO - 2025-05-04 05:54:48 --> Language Class Initialized
INFO - 2025-05-04 05:54:48 --> Loader Class Initialized
INFO - 2025-05-04 05:54:48 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:48 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:48 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:48 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:48 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:48 --> Controller Class Initialized
INFO - 2025-05-04 05:54:48 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:54:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:54:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:54:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 05:54:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:54:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:54:48 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:48 --> Total execution time: 0.1104
INFO - 2025-05-04 05:54:49 --> Config Class Initialized
INFO - 2025-05-04 05:54:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:49 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:49 --> URI Class Initialized
INFO - 2025-05-04 05:54:49 --> Router Class Initialized
INFO - 2025-05-04 05:54:49 --> Output Class Initialized
INFO - 2025-05-04 05:54:49 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:49 --> Input Class Initialized
INFO - 2025-05-04 05:54:49 --> Language Class Initialized
INFO - 2025-05-04 05:54:49 --> Loader Class Initialized
INFO - 2025-05-04 05:54:49 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:49 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:49 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:49 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:49 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:49 --> Controller Class Initialized
INFO - 2025-05-04 05:54:49 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:54:49 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:49 --> Total execution time: 0.4616
INFO - 2025-05-04 05:54:51 --> Config Class Initialized
INFO - 2025-05-04 05:54:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:51 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:51 --> URI Class Initialized
INFO - 2025-05-04 05:54:51 --> Router Class Initialized
INFO - 2025-05-04 05:54:51 --> Output Class Initialized
INFO - 2025-05-04 05:54:51 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:51 --> Input Class Initialized
INFO - 2025-05-04 05:54:51 --> Language Class Initialized
INFO - 2025-05-04 05:54:51 --> Loader Class Initialized
INFO - 2025-05-04 05:54:51 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:51 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:51 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:51 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:51 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:51 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:51 --> Controller Class Initialized
INFO - 2025-05-04 05:54:51 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:54:51 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:54:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:54:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:54:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/details.php
INFO - 2025-05-04 05:54:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:54:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:54:51 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:51 --> Total execution time: 0.1471
INFO - 2025-05-04 05:54:52 --> Config Class Initialized
INFO - 2025-05-04 05:54:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:52 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:52 --> URI Class Initialized
INFO - 2025-05-04 05:54:52 --> Router Class Initialized
INFO - 2025-05-04 05:54:52 --> Output Class Initialized
INFO - 2025-05-04 05:54:52 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:52 --> Input Class Initialized
INFO - 2025-05-04 05:54:52 --> Language Class Initialized
INFO - 2025-05-04 05:54:52 --> Loader Class Initialized
INFO - 2025-05-04 05:54:52 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:52 --> Controller Class Initialized
INFO - 2025-05-04 13:54:52 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:54:52 --> Final output sent to browser
DEBUG - 2025-05-04 13:54:52 --> Total execution time: 0.1278
INFO - 2025-05-04 05:54:52 --> Config Class Initialized
INFO - 2025-05-04 05:54:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:52 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:52 --> URI Class Initialized
INFO - 2025-05-04 05:54:52 --> Router Class Initialized
INFO - 2025-05-04 05:54:52 --> Output Class Initialized
INFO - 2025-05-04 05:54:52 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:52 --> Input Class Initialized
INFO - 2025-05-04 05:54:52 --> Language Class Initialized
INFO - 2025-05-04 05:54:52 --> Loader Class Initialized
INFO - 2025-05-04 05:54:52 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: string_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: file_helper
INFO - 2025-05-04 05:54:52 --> Helper loaded: html_helper
INFO - 2025-05-04 05:54:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:52 --> Controller Class Initialized
INFO - 2025-05-04 05:54:52 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-04 05:54:52 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:52 --> Total execution time: 0.1622
INFO - 2025-05-04 05:58:28 --> Config Class Initialized
INFO - 2025-05-04 05:58:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:28 --> URI Class Initialized
INFO - 2025-05-04 05:58:28 --> Router Class Initialized
INFO - 2025-05-04 05:58:28 --> Output Class Initialized
INFO - 2025-05-04 05:58:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:28 --> Input Class Initialized
INFO - 2025-05-04 05:58:28 --> Language Class Initialized
INFO - 2025-05-04 05:58:29 --> Loader Class Initialized
INFO - 2025-05-04 05:58:29 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:29 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:29 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:29 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:29 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:29 --> Controller Class Initialized
INFO - 2025-05-04 05:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:58:29 --> Final output sent to browser
DEBUG - 2025-05-04 05:58:29 --> Total execution time: 0.3717
INFO - 2025-05-04 05:58:30 --> Config Class Initialized
INFO - 2025-05-04 05:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:30 --> URI Class Initialized
INFO - 2025-05-04 05:58:30 --> Router Class Initialized
INFO - 2025-05-04 05:58:30 --> Output Class Initialized
INFO - 2025-05-04 05:58:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:30 --> Input Class Initialized
INFO - 2025-05-04 05:58:30 --> Language Class Initialized
INFO - 2025-05-04 05:58:30 --> Config Class Initialized
INFO - 2025-05-04 05:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:30 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:30 --> URI Class Initialized
INFO - 2025-05-04 05:58:30 --> Router Class Initialized
INFO - 2025-05-04 05:58:30 --> Output Class Initialized
INFO - 2025-05-04 05:58:30 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:30 --> Input Class Initialized
INFO - 2025-05-04 05:58:30 --> Language Class Initialized
INFO - 2025-05-04 05:58:31 --> Loader Class Initialized
INFO - 2025-05-04 05:58:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:31 --> Loader Class Initialized
INFO - 2025-05-04 05:58:31 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:31 --> Database Driver Class Initialized
INFO - 2025-05-04 05:58:31 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:31 --> Helper loaded: html_helper
DEBUG - 2025-05-04 05:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:31 --> Controller Class Initialized
INFO - 2025-05-04 13:58:31 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:58:31 --> Database Driver Class Initialized
INFO - 2025-05-04 05:58:32 --> URI Class Initialized
INFO - 2025-05-04 05:58:32 --> Router Class Initialized
INFO - 2025-05-04 05:58:32 --> Output Class Initialized
INFO - 2025-05-04 05:58:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:32 --> Input Class Initialized
INFO - 2025-05-04 05:58:32 --> Language Class Initialized
INFO - 2025-05-04 05:58:32 --> Loader Class Initialized
INFO - 2025-05-04 05:58:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:32 --> Controller Class Initialized
INFO - 2025-05-04 13:58:32 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:58:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:58:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:58:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 13:58:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:58:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:58:32 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:32 --> Total execution time: 0.3308
INFO - 2025-05-04 05:58:32 --> Config Class Initialized
INFO - 2025-05-04 05:58:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:32 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:32 --> URI Class Initialized
INFO - 2025-05-04 05:58:32 --> Router Class Initialized
INFO - 2025-05-04 05:58:32 --> Output Class Initialized
INFO - 2025-05-04 05:58:32 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:32 --> Input Class Initialized
INFO - 2025-05-04 05:58:32 --> Language Class Initialized
INFO - 2025-05-04 05:58:32 --> Loader Class Initialized
INFO - 2025-05-04 05:58:32 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:32 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:32 --> Controller Class Initialized
INFO - 2025-05-04 13:58:32 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:58:32 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:32 --> Total execution time: 0.1673
INFO - 2025-05-04 05:58:33 --> Config Class Initialized
INFO - 2025-05-04 05:58:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:33 --> URI Class Initialized
INFO - 2025-05-04 05:58:33 --> Router Class Initialized
INFO - 2025-05-04 05:58:33 --> Output Class Initialized
INFO - 2025-05-04 05:58:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:33 --> Input Class Initialized
INFO - 2025-05-04 05:58:33 --> Language Class Initialized
INFO - 2025-05-04 05:58:33 --> Loader Class Initialized
INFO - 2025-05-04 05:58:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:33 --> Controller Class Initialized
INFO - 2025-05-04 05:58:33 --> Model "UserModel" initialized
INFO - 2025-05-04 05:58:33 --> Final output sent to browser
DEBUG - 2025-05-04 05:58:33 --> Total execution time: 0.1590
INFO - 2025-05-04 05:58:33 --> Config Class Initialized
INFO - 2025-05-04 05:58:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:33 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:33 --> URI Class Initialized
INFO - 2025-05-04 05:58:33 --> Router Class Initialized
INFO - 2025-05-04 05:58:33 --> Output Class Initialized
INFO - 2025-05-04 05:58:33 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:33 --> Input Class Initialized
INFO - 2025-05-04 05:58:33 --> Language Class Initialized
INFO - 2025-05-04 05:58:33 --> Loader Class Initialized
INFO - 2025-05-04 05:58:33 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:33 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:33 --> Controller Class Initialized
INFO - 2025-05-04 13:58:33 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:58:33 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:33 --> Total execution time: 0.1428
INFO - 2025-05-04 05:58:35 --> Config Class Initialized
INFO - 2025-05-04 05:58:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:35 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:35 --> URI Class Initialized
INFO - 2025-05-04 05:58:35 --> Router Class Initialized
INFO - 2025-05-04 05:58:35 --> Output Class Initialized
INFO - 2025-05-04 05:58:35 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:35 --> Input Class Initialized
INFO - 2025-05-04 05:58:35 --> Language Class Initialized
INFO - 2025-05-04 05:58:35 --> Loader Class Initialized
INFO - 2025-05-04 05:58:35 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:35 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:35 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:35 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:35 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:35 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:35 --> Controller Class Initialized
ERROR - 2025-05-04 13:58:35 --> Severity: Warning --> Undefined property: Auctions::$CompanyModel C:\xampp\htdocs\storage_auctions\application\controllers\Auctions.php 84
ERROR - 2025-05-04 13:58:35 --> Severity: error --> Exception: Call to a member function getCompanyByUserId() on null C:\xampp\htdocs\storage_auctions\application\controllers\Auctions.php 84
INFO - 2025-05-04 05:58:54 --> Config Class Initialized
INFO - 2025-05-04 05:58:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:54 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:54 --> URI Class Initialized
INFO - 2025-05-04 05:58:54 --> Router Class Initialized
INFO - 2025-05-04 05:58:54 --> Output Class Initialized
INFO - 2025-05-04 05:58:54 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:54 --> Input Class Initialized
INFO - 2025-05-04 05:58:54 --> Language Class Initialized
INFO - 2025-05-04 05:58:55 --> Loader Class Initialized
INFO - 2025-05-04 05:58:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:55 --> Controller Class Initialized
INFO - 2025-05-04 13:58:55 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:58:55 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:58:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:58:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:58:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/details.php
INFO - 2025-05-04 13:58:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:58:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:58:55 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:55 --> Total execution time: 0.3346
INFO - 2025-05-04 05:58:55 --> Config Class Initialized
INFO - 2025-05-04 05:58:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:55 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:55 --> URI Class Initialized
INFO - 2025-05-04 05:58:55 --> Router Class Initialized
INFO - 2025-05-04 05:58:55 --> Output Class Initialized
INFO - 2025-05-04 05:58:55 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:55 --> Input Class Initialized
INFO - 2025-05-04 05:58:55 --> Language Class Initialized
INFO - 2025-05-04 05:58:55 --> Loader Class Initialized
INFO - 2025-05-04 05:58:55 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:55 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:55 --> Controller Class Initialized
INFO - 2025-05-04 13:58:55 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:58:55 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:55 --> Total execution time: 0.4479
INFO - 2025-05-04 05:58:56 --> Config Class Initialized
INFO - 2025-05-04 05:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:56 --> URI Class Initialized
INFO - 2025-05-04 05:58:56 --> Router Class Initialized
INFO - 2025-05-04 05:58:56 --> Output Class Initialized
INFO - 2025-05-04 05:58:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:56 --> Input Class Initialized
INFO - 2025-05-04 05:58:56 --> Language Class Initialized
INFO - 2025-05-04 05:58:56 --> Loader Class Initialized
INFO - 2025-05-04 05:58:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:56 --> Controller Class Initialized
INFO - 2025-05-04 05:58:56 --> Model "UserModel" initialized
INFO - 2025-05-04 05:58:56 --> Final output sent to browser
DEBUG - 2025-05-04 05:58:56 --> Total execution time: 0.1331
INFO - 2025-05-04 05:58:56 --> Config Class Initialized
INFO - 2025-05-04 05:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:56 --> URI Class Initialized
INFO - 2025-05-04 05:58:56 --> Router Class Initialized
INFO - 2025-05-04 05:58:56 --> Output Class Initialized
INFO - 2025-05-04 05:58:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:56 --> Input Class Initialized
INFO - 2025-05-04 05:58:56 --> Language Class Initialized
INFO - 2025-05-04 05:58:56 --> Loader Class Initialized
INFO - 2025-05-04 05:58:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:56 --> Controller Class Initialized
INFO - 2025-05-04 13:58:56 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:58:56 --> Final output sent to browser
DEBUG - 2025-05-04 13:58:56 --> Total execution time: 0.1194
INFO - 2025-05-04 05:58:56 --> Config Class Initialized
INFO - 2025-05-04 05:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:56 --> URI Class Initialized
INFO - 2025-05-04 05:58:56 --> Router Class Initialized
INFO - 2025-05-04 05:58:56 --> Output Class Initialized
INFO - 2025-05-04 05:58:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:56 --> Input Class Initialized
INFO - 2025-05-04 05:58:56 --> Language Class Initialized
INFO - 2025-05-04 05:58:56 --> Loader Class Initialized
INFO - 2025-05-04 05:58:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:56 --> Controller Class Initialized
INFO - 2025-05-04 05:58:56 --> Config Class Initialized
INFO - 2025-05-04 05:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:58:56 --> Utf8 Class Initialized
INFO - 2025-05-04 05:58:56 --> URI Class Initialized
INFO - 2025-05-04 05:58:56 --> Router Class Initialized
INFO - 2025-05-04 05:58:56 --> Output Class Initialized
INFO - 2025-05-04 05:58:56 --> Security Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:58:56 --> Input Class Initialized
INFO - 2025-05-04 05:58:56 --> Language Class Initialized
INFO - 2025-05-04 05:58:56 --> Loader Class Initialized
INFO - 2025-05-04 05:58:56 --> Helper loaded: url_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: string_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: form_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: file_helper
INFO - 2025-05-04 05:58:56 --> Helper loaded: html_helper
INFO - 2025-05-04 05:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:58:56 --> Controller Class Initialized
INFO - 2025-05-04 13:58:56 --> Model "AuctionModel" initialized
INFO - 2025-05-04 05:59:00 --> Config Class Initialized
INFO - 2025-05-04 05:59:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:00 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:00 --> URI Class Initialized
INFO - 2025-05-04 05:59:01 --> Router Class Initialized
INFO - 2025-05-04 05:59:01 --> Output Class Initialized
INFO - 2025-05-04 05:59:01 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:01 --> Input Class Initialized
INFO - 2025-05-04 05:59:01 --> Language Class Initialized
INFO - 2025-05-04 05:59:01 --> Loader Class Initialized
INFO - 2025-05-04 05:59:01 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:01 --> Controller Class Initialized
INFO - 2025-05-04 13:59:01 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:59:01 --> Config Class Initialized
INFO - 2025-05-04 05:59:01 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:01 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:01 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:01 --> URI Class Initialized
INFO - 2025-05-04 05:59:01 --> Router Class Initialized
INFO - 2025-05-04 05:59:01 --> Output Class Initialized
INFO - 2025-05-04 05:59:01 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:01 --> Input Class Initialized
INFO - 2025-05-04 05:59:01 --> Language Class Initialized
INFO - 2025-05-04 05:59:01 --> Loader Class Initialized
INFO - 2025-05-04 05:59:01 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:01 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:01 --> Controller Class Initialized
INFO - 2025-05-04 13:59:01 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:59:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:59:01 --> Final output sent to browser
DEBUG - 2025-05-04 13:59:01 --> Total execution time: 0.1445
INFO - 2025-05-04 05:59:10 --> Config Class Initialized
INFO - 2025-05-04 05:59:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:10 --> URI Class Initialized
INFO - 2025-05-04 05:59:10 --> Router Class Initialized
INFO - 2025-05-04 05:59:10 --> Output Class Initialized
INFO - 2025-05-04 05:59:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:10 --> Input Class Initialized
INFO - 2025-05-04 05:59:10 --> Language Class Initialized
INFO - 2025-05-04 05:59:10 --> Loader Class Initialized
INFO - 2025-05-04 05:59:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:10 --> Controller Class Initialized
INFO - 2025-05-04 05:59:10 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:59:10 --> Config Class Initialized
INFO - 2025-05-04 05:59:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:10 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:10 --> URI Class Initialized
INFO - 2025-05-04 05:59:10 --> Router Class Initialized
INFO - 2025-05-04 05:59:10 --> Output Class Initialized
INFO - 2025-05-04 05:59:10 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:10 --> Input Class Initialized
INFO - 2025-05-04 05:59:10 --> Language Class Initialized
INFO - 2025-05-04 05:59:10 --> Loader Class Initialized
INFO - 2025-05-04 05:59:10 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:10 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:10 --> Controller Class Initialized
INFO - 2025-05-04 13:59:10 --> Model "CompanyModel" initialized
INFO - 2025-05-04 13:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 13:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 13:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/add_company.php
INFO - 2025-05-04 13:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 13:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 13:59:11 --> Final output sent to browser
DEBUG - 2025-05-04 13:59:11 --> Total execution time: 0.1334
INFO - 2025-05-04 05:59:12 --> Config Class Initialized
INFO - 2025-05-04 05:59:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:13 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:13 --> URI Class Initialized
INFO - 2025-05-04 05:59:13 --> Router Class Initialized
INFO - 2025-05-04 05:59:13 --> Output Class Initialized
INFO - 2025-05-04 05:59:13 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:13 --> Input Class Initialized
INFO - 2025-05-04 05:59:13 --> Language Class Initialized
INFO - 2025-05-04 05:59:13 --> Loader Class Initialized
INFO - 2025-05-04 05:59:13 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:13 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:13 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:13 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:13 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:13 --> Controller Class Initialized
INFO - 2025-05-04 05:59:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 05:59:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 05:59:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 05:59:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 05:59:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 05:59:13 --> Final output sent to browser
DEBUG - 2025-05-04 05:59:13 --> Total execution time: 0.1442
INFO - 2025-05-04 05:59:14 --> Config Class Initialized
INFO - 2025-05-04 05:59:14 --> Hooks Class Initialized
INFO - 2025-05-04 05:59:14 --> Config Class Initialized
INFO - 2025-05-04 05:59:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:14 --> Utf8 Class Initialized
DEBUG - 2025-05-04 05:59:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:14 --> URI Class Initialized
INFO - 2025-05-04 05:59:14 --> URI Class Initialized
INFO - 2025-05-04 05:59:14 --> Router Class Initialized
INFO - 2025-05-04 05:59:14 --> Output Class Initialized
INFO - 2025-05-04 05:59:14 --> Router Class Initialized
INFO - 2025-05-04 05:59:14 --> Security Class Initialized
INFO - 2025-05-04 05:59:14 --> Output Class Initialized
DEBUG - 2025-05-04 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:14 --> Input Class Initialized
INFO - 2025-05-04 05:59:14 --> Language Class Initialized
INFO - 2025-05-04 05:59:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:14 --> Input Class Initialized
INFO - 2025-05-04 05:59:14 --> Language Class Initialized
INFO - 2025-05-04 05:59:14 --> Loader Class Initialized
INFO - 2025-05-04 05:59:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:14 --> Loader Class Initialized
INFO - 2025-05-04 05:59:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:14 --> Controller Class Initialized
INFO - 2025-05-04 05:59:14 --> Database Driver Class Initialized
INFO - 2025-05-04 13:59:14 --> Model "AuctionModel" initialized
INFO - 2025-05-04 13:59:14 --> Final output sent to browser
DEBUG - 2025-05-04 13:59:14 --> Total execution time: 0.1682
DEBUG - 2025-05-04 05:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:14 --> Controller Class Initialized
INFO - 2025-05-04 13:59:14 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:59:14 --> Config Class Initialized
INFO - 2025-05-04 05:59:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:14 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:14 --> URI Class Initialized
INFO - 2025-05-04 05:59:14 --> Router Class Initialized
INFO - 2025-05-04 05:59:14 --> Output Class Initialized
INFO - 2025-05-04 05:59:14 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:14 --> Input Class Initialized
INFO - 2025-05-04 05:59:14 --> Language Class Initialized
INFO - 2025-05-04 05:59:14 --> Loader Class Initialized
INFO - 2025-05-04 05:59:14 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:14 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:14 --> Controller Class Initialized
INFO - 2025-05-04 05:59:14 --> Model "UserModel" initialized
INFO - 2025-05-04 05:59:21 --> Config Class Initialized
INFO - 2025-05-04 05:59:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:21 --> URI Class Initialized
INFO - 2025-05-04 05:59:21 --> Router Class Initialized
INFO - 2025-05-04 05:59:21 --> Output Class Initialized
INFO - 2025-05-04 05:59:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:21 --> Input Class Initialized
INFO - 2025-05-04 05:59:21 --> Language Class Initialized
INFO - 2025-05-04 05:59:21 --> Loader Class Initialized
INFO - 2025-05-04 05:59:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:21 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:21 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:21 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:21 --> Controller Class Initialized
INFO - 2025-05-04 13:59:21 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:59:23 --> Config Class Initialized
INFO - 2025-05-04 05:59:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:23 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:23 --> URI Class Initialized
INFO - 2025-05-04 05:59:23 --> Router Class Initialized
INFO - 2025-05-04 05:59:23 --> Output Class Initialized
INFO - 2025-05-04 05:59:23 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:23 --> Input Class Initialized
INFO - 2025-05-04 05:59:23 --> Language Class Initialized
INFO - 2025-05-04 05:59:23 --> Loader Class Initialized
INFO - 2025-05-04 05:59:23 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:23 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:23 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:23 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:23 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:23 --> Controller Class Initialized
INFO - 2025-05-04 13:59:23 --> Model "CompanyModel" initialized
INFO - 2025-05-04 05:59:24 --> Config Class Initialized
INFO - 2025-05-04 05:59:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:24 --> URI Class Initialized
INFO - 2025-05-04 05:59:24 --> Router Class Initialized
INFO - 2025-05-04 05:59:24 --> Output Class Initialized
INFO - 2025-05-04 05:59:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:24 --> Input Class Initialized
INFO - 2025-05-04 05:59:24 --> Language Class Initialized
INFO - 2025-05-04 05:59:24 --> Loader Class Initialized
INFO - 2025-05-04 05:59:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:24 --> Helper loaded: string_helper
INFO - 2025-05-04 05:59:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:24 --> Helper loaded: file_helper
INFO - 2025-05-04 05:59:24 --> Helper loaded: html_helper
INFO - 2025-05-04 05:59:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 05:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:24 --> Controller Class Initialized
INFO - 2025-05-04 13:59:24 --> Model "CompanyModel" initialized
INFO - 2025-05-04 06:00:08 --> Config Class Initialized
INFO - 2025-05-04 06:00:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:08 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:08 --> URI Class Initialized
INFO - 2025-05-04 06:00:08 --> Router Class Initialized
INFO - 2025-05-04 06:00:08 --> Output Class Initialized
INFO - 2025-05-04 06:00:08 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:08 --> Input Class Initialized
INFO - 2025-05-04 06:00:08 --> Language Class Initialized
INFO - 2025-05-04 06:00:08 --> Loader Class Initialized
INFO - 2025-05-04 06:00:08 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:08 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:08 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:08 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:08 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:08 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:08 --> Controller Class Initialized
INFO - 2025-05-04 06:00:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:00:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:00:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 06:00:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:00:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:00:08 --> Final output sent to browser
DEBUG - 2025-05-04 06:00:08 --> Total execution time: 0.1544
INFO - 2025-05-04 06:00:12 --> Config Class Initialized
INFO - 2025-05-04 06:00:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:12 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:12 --> URI Class Initialized
INFO - 2025-05-04 06:00:12 --> Config Class Initialized
INFO - 2025-05-04 06:00:12 --> Router Class Initialized
INFO - 2025-05-04 06:00:12 --> Hooks Class Initialized
INFO - 2025-05-04 06:00:12 --> Output Class Initialized
DEBUG - 2025-05-04 06:00:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:12 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:12 --> URI Class Initialized
INFO - 2025-05-04 06:00:12 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:12 --> Input Class Initialized
INFO - 2025-05-04 06:00:12 --> Router Class Initialized
INFO - 2025-05-04 06:00:12 --> Language Class Initialized
INFO - 2025-05-04 06:00:12 --> Output Class Initialized
INFO - 2025-05-04 06:00:12 --> Security Class Initialized
INFO - 2025-05-04 06:00:12 --> Loader Class Initialized
INFO - 2025-05-04 06:00:12 --> Helper loaded: url_helper
DEBUG - 2025-05-04 06:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:12 --> Input Class Initialized
INFO - 2025-05-04 06:00:12 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:12 --> Language Class Initialized
INFO - 2025-05-04 06:00:12 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:12 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:12 --> Loader Class Initialized
INFO - 2025-05-04 06:00:12 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:12 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:12 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:12 --> Database Driver Class Initialized
INFO - 2025-05-04 06:00:12 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:12 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:12 --> Helper loaded: html_helper
DEBUG - 2025-05-04 06:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:12 --> Database Driver Class Initialized
INFO - 2025-05-04 06:00:12 --> Controller Class Initialized
INFO - 2025-05-04 14:00:12 --> Model "CompanyModel" initialized
DEBUG - 2025-05-04 06:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:12 --> Controller Class Initialized
INFO - 2025-05-04 14:00:12 --> Model "AuctionModel" initialized
INFO - 2025-05-04 14:00:12 --> Final output sent to browser
DEBUG - 2025-05-04 14:00:12 --> Total execution time: 0.2208
INFO - 2025-05-04 06:00:12 --> Config Class Initialized
INFO - 2025-05-04 06:00:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:12 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:12 --> URI Class Initialized
INFO - 2025-05-04 06:00:12 --> Router Class Initialized
INFO - 2025-05-04 06:00:12 --> Output Class Initialized
INFO - 2025-05-04 06:00:12 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:12 --> Input Class Initialized
INFO - 2025-05-04 06:00:12 --> Language Class Initialized
INFO - 2025-05-04 06:00:13 --> Loader Class Initialized
INFO - 2025-05-04 06:00:13 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:13 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:13 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:13 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:13 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:13 --> Controller Class Initialized
INFO - 2025-05-04 06:00:13 --> Model "UserModel" initialized
INFO - 2025-05-04 06:00:15 --> Config Class Initialized
INFO - 2025-05-04 06:00:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:15 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:15 --> URI Class Initialized
INFO - 2025-05-04 06:00:15 --> Router Class Initialized
INFO - 2025-05-04 06:00:15 --> Output Class Initialized
INFO - 2025-05-04 06:00:15 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:15 --> Input Class Initialized
INFO - 2025-05-04 06:00:15 --> Language Class Initialized
INFO - 2025-05-04 06:00:15 --> Loader Class Initialized
INFO - 2025-05-04 06:00:15 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:15 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:15 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:15 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:15 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:15 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:15 --> Controller Class Initialized
INFO - 2025-05-04 06:00:16 --> Config Class Initialized
INFO - 2025-05-04 06:00:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:16 --> URI Class Initialized
INFO - 2025-05-04 06:00:16 --> Router Class Initialized
INFO - 2025-05-04 06:00:16 --> Output Class Initialized
INFO - 2025-05-04 06:00:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:16 --> Input Class Initialized
INFO - 2025-05-04 06:00:16 --> Language Class Initialized
INFO - 2025-05-04 06:00:16 --> Loader Class Initialized
INFO - 2025-05-04 06:00:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:16 --> Controller Class Initialized
INFO - 2025-05-04 06:00:16 --> Config Class Initialized
INFO - 2025-05-04 06:00:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:16 --> URI Class Initialized
DEBUG - 2025-05-04 06:00:16 --> No URI present. Default controller set.
INFO - 2025-05-04 06:00:16 --> Router Class Initialized
INFO - 2025-05-04 06:00:16 --> Output Class Initialized
INFO - 2025-05-04 06:00:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:16 --> Input Class Initialized
INFO - 2025-05-04 06:00:16 --> Language Class Initialized
INFO - 2025-05-04 06:00:16 --> Loader Class Initialized
INFO - 2025-05-04 06:00:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: html_helper
INFO - 2025-05-04 06:00:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:16 --> Controller Class Initialized
INFO - 2025-05-04 06:00:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:00:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:00:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:00:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:00:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:00:16 --> Final output sent to browser
DEBUG - 2025-05-04 06:00:16 --> Total execution time: 0.1245
INFO - 2025-05-04 06:00:19 --> Config Class Initialized
INFO - 2025-05-04 06:00:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:19 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:19 --> URI Class Initialized
INFO - 2025-05-04 06:00:19 --> Router Class Initialized
INFO - 2025-05-04 06:00:19 --> Output Class Initialized
INFO - 2025-05-04 06:00:19 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:19 --> Input Class Initialized
INFO - 2025-05-04 06:00:19 --> Language Class Initialized
INFO - 2025-05-04 06:00:19 --> Loader Class Initialized
INFO - 2025-05-04 06:00:19 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:19 --> Helper loaded: string_helper
INFO - 2025-05-04 06:00:19 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:19 --> Helper loaded: file_helper
INFO - 2025-05-04 06:00:19 --> Helper loaded: html_helper
INFO - 2025-05-04 06:03:26 --> Config Class Initialized
INFO - 2025-05-04 06:03:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:03:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:03:26 --> Utf8 Class Initialized
INFO - 2025-05-04 06:03:26 --> URI Class Initialized
DEBUG - 2025-05-04 06:03:26 --> No URI present. Default controller set.
INFO - 2025-05-04 06:03:26 --> Router Class Initialized
INFO - 2025-05-04 06:03:26 --> Output Class Initialized
INFO - 2025-05-04 06:03:26 --> Security Class Initialized
DEBUG - 2025-05-04 06:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:03:26 --> Input Class Initialized
INFO - 2025-05-04 06:03:26 --> Language Class Initialized
INFO - 2025-05-04 06:03:26 --> Loader Class Initialized
INFO - 2025-05-04 06:03:26 --> Helper loaded: url_helper
INFO - 2025-05-04 06:03:26 --> Helper loaded: string_helper
INFO - 2025-05-04 06:03:26 --> Helper loaded: form_helper
INFO - 2025-05-04 06:03:26 --> Helper loaded: file_helper
INFO - 2025-05-04 06:03:26 --> Helper loaded: html_helper
INFO - 2025-05-04 06:03:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:03:26 --> Controller Class Initialized
INFO - 2025-05-04 06:03:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:03:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:03:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:03:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:03:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:03:26 --> Final output sent to browser
DEBUG - 2025-05-04 06:03:26 --> Total execution time: 0.3632
INFO - 2025-05-04 06:03:28 --> Config Class Initialized
INFO - 2025-05-04 06:03:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:03:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:03:28 --> Utf8 Class Initialized
INFO - 2025-05-04 06:03:29 --> URI Class Initialized
INFO - 2025-05-04 06:03:29 --> Router Class Initialized
INFO - 2025-05-04 06:03:29 --> Output Class Initialized
INFO - 2025-05-04 06:03:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:03:29 --> Input Class Initialized
INFO - 2025-05-04 06:03:29 --> Language Class Initialized
INFO - 2025-05-04 06:03:29 --> Loader Class Initialized
INFO - 2025-05-04 06:03:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:03:29 --> Helper loaded: string_helper
INFO - 2025-05-04 06:03:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:03:29 --> Helper loaded: file_helper
INFO - 2025-05-04 06:03:29 --> Helper loaded: html_helper
INFO - 2025-05-04 06:03:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:03:29 --> Controller Class Initialized
INFO - 2025-05-04 14:03:29 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:10:44 --> Config Class Initialized
INFO - 2025-05-04 06:10:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:44 --> URI Class Initialized
DEBUG - 2025-05-04 06:10:44 --> No URI present. Default controller set.
INFO - 2025-05-04 06:10:44 --> Router Class Initialized
INFO - 2025-05-04 06:10:44 --> Output Class Initialized
INFO - 2025-05-04 06:10:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:44 --> Input Class Initialized
INFO - 2025-05-04 06:10:44 --> Language Class Initialized
INFO - 2025-05-04 06:10:44 --> Loader Class Initialized
INFO - 2025-05-04 06:10:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:44 --> Helper loaded: string_helper
INFO - 2025-05-04 06:10:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:44 --> Helper loaded: file_helper
INFO - 2025-05-04 06:10:44 --> Helper loaded: html_helper
INFO - 2025-05-04 06:10:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:44 --> Controller Class Initialized
INFO - 2025-05-04 06:10:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:10:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:10:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:10:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:10:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:10:44 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:44 --> Total execution time: 0.1821
INFO - 2025-05-04 06:10:48 --> Config Class Initialized
INFO - 2025-05-04 06:10:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:48 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:48 --> URI Class Initialized
INFO - 2025-05-04 06:10:48 --> Router Class Initialized
INFO - 2025-05-04 06:10:48 --> Output Class Initialized
INFO - 2025-05-04 06:10:48 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:48 --> Input Class Initialized
INFO - 2025-05-04 06:10:48 --> Language Class Initialized
INFO - 2025-05-04 06:10:48 --> Loader Class Initialized
INFO - 2025-05-04 06:10:48 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:48 --> Helper loaded: string_helper
INFO - 2025-05-04 06:10:48 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:48 --> Helper loaded: file_helper
INFO - 2025-05-04 06:10:48 --> Helper loaded: html_helper
INFO - 2025-05-04 06:10:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:48 --> Controller Class Initialized
INFO - 2025-05-04 14:10:48 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:13:36 --> Config Class Initialized
INFO - 2025-05-04 06:13:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:36 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:36 --> URI Class Initialized
DEBUG - 2025-05-04 06:13:36 --> No URI present. Default controller set.
INFO - 2025-05-04 06:13:36 --> Router Class Initialized
INFO - 2025-05-04 06:13:36 --> Output Class Initialized
INFO - 2025-05-04 06:13:36 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:36 --> Input Class Initialized
INFO - 2025-05-04 06:13:36 --> Language Class Initialized
INFO - 2025-05-04 06:13:36 --> Loader Class Initialized
INFO - 2025-05-04 06:13:36 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:36 --> Helper loaded: string_helper
INFO - 2025-05-04 06:13:36 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:36 --> Helper loaded: file_helper
INFO - 2025-05-04 06:13:36 --> Helper loaded: html_helper
INFO - 2025-05-04 06:13:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:36 --> Controller Class Initialized
INFO - 2025-05-04 06:13:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:13:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:13:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:13:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:13:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:13:36 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:36 --> Total execution time: 0.2991
INFO - 2025-05-04 06:13:40 --> Config Class Initialized
INFO - 2025-05-04 06:13:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:40 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:40 --> URI Class Initialized
INFO - 2025-05-04 06:13:40 --> Router Class Initialized
INFO - 2025-05-04 06:13:40 --> Output Class Initialized
INFO - 2025-05-04 06:13:40 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:40 --> Input Class Initialized
INFO - 2025-05-04 06:13:40 --> Language Class Initialized
INFO - 2025-05-04 06:13:40 --> Loader Class Initialized
INFO - 2025-05-04 06:13:40 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:40 --> Helper loaded: string_helper
INFO - 2025-05-04 06:13:40 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:40 --> Helper loaded: file_helper
INFO - 2025-05-04 06:13:40 --> Helper loaded: html_helper
INFO - 2025-05-04 06:13:41 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:41 --> Controller Class Initialized
INFO - 2025-05-04 14:13:41 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:14:10 --> Config Class Initialized
INFO - 2025-05-04 06:14:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:14:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:14:10 --> Utf8 Class Initialized
INFO - 2025-05-04 06:14:10 --> URI Class Initialized
DEBUG - 2025-05-04 06:14:10 --> No URI present. Default controller set.
INFO - 2025-05-04 06:14:10 --> Router Class Initialized
INFO - 2025-05-04 06:14:10 --> Output Class Initialized
INFO - 2025-05-04 06:14:10 --> Security Class Initialized
DEBUG - 2025-05-04 06:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:14:10 --> Input Class Initialized
INFO - 2025-05-04 06:14:10 --> Language Class Initialized
INFO - 2025-05-04 06:14:10 --> Loader Class Initialized
INFO - 2025-05-04 06:14:10 --> Helper loaded: url_helper
INFO - 2025-05-04 06:14:10 --> Helper loaded: string_helper
INFO - 2025-05-04 06:14:10 --> Helper loaded: form_helper
INFO - 2025-05-04 06:14:10 --> Helper loaded: file_helper
INFO - 2025-05-04 06:14:10 --> Helper loaded: html_helper
INFO - 2025-05-04 06:14:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:14:10 --> Controller Class Initialized
INFO - 2025-05-04 06:14:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:14:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:14:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:14:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:14:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:14:10 --> Final output sent to browser
DEBUG - 2025-05-04 06:14:10 --> Total execution time: 0.1325
INFO - 2025-05-04 06:14:14 --> Config Class Initialized
INFO - 2025-05-04 06:14:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:14:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:14:14 --> Utf8 Class Initialized
INFO - 2025-05-04 06:14:14 --> URI Class Initialized
INFO - 2025-05-04 06:14:14 --> Router Class Initialized
INFO - 2025-05-04 06:14:14 --> Output Class Initialized
INFO - 2025-05-04 06:14:14 --> Security Class Initialized
DEBUG - 2025-05-04 06:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:14:14 --> Input Class Initialized
INFO - 2025-05-04 06:14:14 --> Language Class Initialized
INFO - 2025-05-04 06:14:14 --> Loader Class Initialized
INFO - 2025-05-04 06:14:14 --> Helper loaded: url_helper
INFO - 2025-05-04 06:14:14 --> Helper loaded: string_helper
INFO - 2025-05-04 06:14:14 --> Helper loaded: form_helper
INFO - 2025-05-04 06:14:14 --> Helper loaded: file_helper
INFO - 2025-05-04 06:14:14 --> Helper loaded: html_helper
INFO - 2025-05-04 06:14:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:14:15 --> Controller Class Initialized
INFO - 2025-05-04 14:14:15 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:14:46 --> Config Class Initialized
INFO - 2025-05-04 06:14:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:14:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:14:46 --> Utf8 Class Initialized
INFO - 2025-05-04 06:14:46 --> URI Class Initialized
DEBUG - 2025-05-04 06:14:46 --> No URI present. Default controller set.
INFO - 2025-05-04 06:14:46 --> Router Class Initialized
INFO - 2025-05-04 06:14:46 --> Output Class Initialized
INFO - 2025-05-04 06:14:46 --> Security Class Initialized
DEBUG - 2025-05-04 06:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:14:46 --> Input Class Initialized
INFO - 2025-05-04 06:14:46 --> Language Class Initialized
INFO - 2025-05-04 06:14:46 --> Loader Class Initialized
INFO - 2025-05-04 06:14:46 --> Helper loaded: url_helper
INFO - 2025-05-04 06:14:46 --> Helper loaded: string_helper
INFO - 2025-05-04 06:14:46 --> Helper loaded: form_helper
INFO - 2025-05-04 06:14:46 --> Helper loaded: file_helper
INFO - 2025-05-04 06:14:46 --> Helper loaded: html_helper
INFO - 2025-05-04 06:14:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:14:46 --> Controller Class Initialized
INFO - 2025-05-04 06:14:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:14:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:14:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:14:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:14:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:14:46 --> Final output sent to browser
DEBUG - 2025-05-04 06:14:46 --> Total execution time: 0.1731
INFO - 2025-05-04 06:14:49 --> Config Class Initialized
INFO - 2025-05-04 06:14:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:14:49 --> Utf8 Class Initialized
INFO - 2025-05-04 06:14:49 --> URI Class Initialized
INFO - 2025-05-04 06:14:49 --> Router Class Initialized
INFO - 2025-05-04 06:14:49 --> Output Class Initialized
INFO - 2025-05-04 06:14:49 --> Security Class Initialized
DEBUG - 2025-05-04 06:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:14:49 --> Input Class Initialized
INFO - 2025-05-04 06:14:49 --> Language Class Initialized
INFO - 2025-05-04 06:14:49 --> Loader Class Initialized
INFO - 2025-05-04 06:14:49 --> Helper loaded: url_helper
INFO - 2025-05-04 06:14:49 --> Helper loaded: string_helper
INFO - 2025-05-04 06:14:49 --> Helper loaded: form_helper
INFO - 2025-05-04 06:14:49 --> Helper loaded: file_helper
INFO - 2025-05-04 06:14:49 --> Helper loaded: html_helper
INFO - 2025-05-04 06:14:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:14:49 --> Controller Class Initialized
INFO - 2025-05-04 14:14:49 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:15:05 --> Config Class Initialized
INFO - 2025-05-04 06:15:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:05 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:05 --> URI Class Initialized
DEBUG - 2025-05-04 06:15:05 --> No URI present. Default controller set.
INFO - 2025-05-04 06:15:05 --> Router Class Initialized
INFO - 2025-05-04 06:15:05 --> Output Class Initialized
INFO - 2025-05-04 06:15:05 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:05 --> Input Class Initialized
INFO - 2025-05-04 06:15:05 --> Language Class Initialized
INFO - 2025-05-04 06:15:05 --> Loader Class Initialized
INFO - 2025-05-04 06:15:05 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:05 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:05 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:05 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:05 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:05 --> Controller Class Initialized
INFO - 2025-05-04 06:15:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:15:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:15:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:15:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:15:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:15:05 --> Final output sent to browser
DEBUG - 2025-05-04 06:15:05 --> Total execution time: 0.1944
INFO - 2025-05-04 06:15:07 --> Config Class Initialized
INFO - 2025-05-04 06:15:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:07 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:07 --> URI Class Initialized
INFO - 2025-05-04 06:15:07 --> Router Class Initialized
INFO - 2025-05-04 06:15:07 --> Output Class Initialized
INFO - 2025-05-04 06:15:07 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:07 --> Input Class Initialized
INFO - 2025-05-04 06:15:07 --> Language Class Initialized
INFO - 2025-05-04 06:15:07 --> Loader Class Initialized
INFO - 2025-05-04 06:15:07 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:07 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:07 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:07 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:07 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:07 --> Controller Class Initialized
INFO - 2025-05-04 14:15:07 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:15:21 --> Config Class Initialized
INFO - 2025-05-04 06:15:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:21 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:21 --> URI Class Initialized
DEBUG - 2025-05-04 06:15:21 --> No URI present. Default controller set.
INFO - 2025-05-04 06:15:21 --> Router Class Initialized
INFO - 2025-05-04 06:15:21 --> Output Class Initialized
INFO - 2025-05-04 06:15:21 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:21 --> Input Class Initialized
INFO - 2025-05-04 06:15:21 --> Language Class Initialized
INFO - 2025-05-04 06:15:21 --> Loader Class Initialized
INFO - 2025-05-04 06:15:21 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:21 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:21 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:21 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:21 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:21 --> Controller Class Initialized
INFO - 2025-05-04 06:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:15:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:15:21 --> Final output sent to browser
DEBUG - 2025-05-04 06:15:21 --> Total execution time: 0.1533
INFO - 2025-05-04 06:15:23 --> Config Class Initialized
INFO - 2025-05-04 06:15:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:23 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:23 --> URI Class Initialized
INFO - 2025-05-04 06:15:23 --> Router Class Initialized
INFO - 2025-05-04 06:15:23 --> Output Class Initialized
INFO - 2025-05-04 06:15:23 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:23 --> Input Class Initialized
INFO - 2025-05-04 06:15:23 --> Language Class Initialized
INFO - 2025-05-04 06:15:23 --> Loader Class Initialized
INFO - 2025-05-04 06:15:23 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:23 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:23 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:23 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:23 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:23 --> Controller Class Initialized
INFO - 2025-05-04 14:15:23 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:15:39 --> Config Class Initialized
INFO - 2025-05-04 06:15:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:39 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:39 --> URI Class Initialized
DEBUG - 2025-05-04 06:15:39 --> No URI present. Default controller set.
INFO - 2025-05-04 06:15:39 --> Router Class Initialized
INFO - 2025-05-04 06:15:39 --> Output Class Initialized
INFO - 2025-05-04 06:15:39 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:39 --> Input Class Initialized
INFO - 2025-05-04 06:15:39 --> Language Class Initialized
INFO - 2025-05-04 06:15:39 --> Loader Class Initialized
INFO - 2025-05-04 06:15:39 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:39 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:39 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:39 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:39 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:39 --> Controller Class Initialized
INFO - 2025-05-04 06:15:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:15:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:15:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:15:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:15:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:15:39 --> Final output sent to browser
DEBUG - 2025-05-04 06:15:39 --> Total execution time: 0.1550
INFO - 2025-05-04 06:15:42 --> Config Class Initialized
INFO - 2025-05-04 06:15:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:15:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:15:42 --> Utf8 Class Initialized
INFO - 2025-05-04 06:15:42 --> URI Class Initialized
INFO - 2025-05-04 06:15:42 --> Router Class Initialized
INFO - 2025-05-04 06:15:42 --> Output Class Initialized
INFO - 2025-05-04 06:15:42 --> Security Class Initialized
DEBUG - 2025-05-04 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:15:42 --> Input Class Initialized
INFO - 2025-05-04 06:15:42 --> Language Class Initialized
INFO - 2025-05-04 06:15:42 --> Loader Class Initialized
INFO - 2025-05-04 06:15:42 --> Helper loaded: url_helper
INFO - 2025-05-04 06:15:42 --> Helper loaded: string_helper
INFO - 2025-05-04 06:15:42 --> Helper loaded: form_helper
INFO - 2025-05-04 06:15:42 --> Helper loaded: file_helper
INFO - 2025-05-04 06:15:42 --> Helper loaded: html_helper
INFO - 2025-05-04 06:15:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:15:42 --> Controller Class Initialized
INFO - 2025-05-04 14:15:42 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:16:32 --> Config Class Initialized
INFO - 2025-05-04 06:16:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:16:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:16:32 --> Utf8 Class Initialized
INFO - 2025-05-04 06:16:32 --> URI Class Initialized
DEBUG - 2025-05-04 06:16:32 --> No URI present. Default controller set.
INFO - 2025-05-04 06:16:32 --> Router Class Initialized
INFO - 2025-05-04 06:16:32 --> Output Class Initialized
INFO - 2025-05-04 06:16:32 --> Security Class Initialized
DEBUG - 2025-05-04 06:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:16:32 --> Input Class Initialized
INFO - 2025-05-04 06:16:32 --> Language Class Initialized
INFO - 2025-05-04 06:16:32 --> Loader Class Initialized
INFO - 2025-05-04 06:16:32 --> Helper loaded: url_helper
INFO - 2025-05-04 06:16:32 --> Helper loaded: string_helper
INFO - 2025-05-04 06:16:32 --> Helper loaded: form_helper
INFO - 2025-05-04 06:16:32 --> Helper loaded: file_helper
INFO - 2025-05-04 06:16:32 --> Helper loaded: html_helper
INFO - 2025-05-04 06:16:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:16:32 --> Controller Class Initialized
INFO - 2025-05-04 06:16:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:16:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:16:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:16:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:16:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:16:32 --> Final output sent to browser
DEBUG - 2025-05-04 06:16:32 --> Total execution time: 0.1528
INFO - 2025-05-04 06:16:36 --> Config Class Initialized
INFO - 2025-05-04 06:16:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:16:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:16:36 --> Utf8 Class Initialized
INFO - 2025-05-04 06:16:36 --> URI Class Initialized
INFO - 2025-05-04 06:16:36 --> Router Class Initialized
INFO - 2025-05-04 06:16:36 --> Output Class Initialized
INFO - 2025-05-04 06:16:36 --> Security Class Initialized
DEBUG - 2025-05-04 06:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:16:36 --> Input Class Initialized
INFO - 2025-05-04 06:16:36 --> Language Class Initialized
INFO - 2025-05-04 06:16:36 --> Loader Class Initialized
INFO - 2025-05-04 06:16:36 --> Helper loaded: url_helper
INFO - 2025-05-04 06:16:36 --> Helper loaded: string_helper
INFO - 2025-05-04 06:16:36 --> Helper loaded: form_helper
INFO - 2025-05-04 06:16:36 --> Helper loaded: file_helper
INFO - 2025-05-04 06:16:36 --> Helper loaded: html_helper
INFO - 2025-05-04 06:16:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:16:36 --> Controller Class Initialized
INFO - 2025-05-04 14:16:36 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:17:49 --> Config Class Initialized
INFO - 2025-05-04 06:17:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:17:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:17:49 --> Utf8 Class Initialized
INFO - 2025-05-04 06:17:49 --> URI Class Initialized
DEBUG - 2025-05-04 06:17:49 --> No URI present. Default controller set.
INFO - 2025-05-04 06:17:49 --> Router Class Initialized
INFO - 2025-05-04 06:17:49 --> Output Class Initialized
INFO - 2025-05-04 06:17:50 --> Security Class Initialized
DEBUG - 2025-05-04 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:17:50 --> Input Class Initialized
INFO - 2025-05-04 06:17:50 --> Language Class Initialized
INFO - 2025-05-04 06:17:50 --> Loader Class Initialized
INFO - 2025-05-04 06:17:50 --> Helper loaded: url_helper
INFO - 2025-05-04 06:17:50 --> Helper loaded: string_helper
INFO - 2025-05-04 06:17:50 --> Helper loaded: form_helper
INFO - 2025-05-04 06:17:50 --> Helper loaded: file_helper
INFO - 2025-05-04 06:17:50 --> Helper loaded: html_helper
INFO - 2025-05-04 06:17:50 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:17:50 --> Controller Class Initialized
INFO - 2025-05-04 06:17:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:17:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:17:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:17:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:17:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:17:50 --> Final output sent to browser
DEBUG - 2025-05-04 06:17:50 --> Total execution time: 0.2801
INFO - 2025-05-04 06:17:54 --> Config Class Initialized
INFO - 2025-05-04 06:17:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:17:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:17:54 --> Utf8 Class Initialized
INFO - 2025-05-04 06:17:54 --> URI Class Initialized
INFO - 2025-05-04 06:17:54 --> Router Class Initialized
INFO - 2025-05-04 06:17:54 --> Output Class Initialized
INFO - 2025-05-04 06:17:54 --> Security Class Initialized
DEBUG - 2025-05-04 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:17:54 --> Input Class Initialized
INFO - 2025-05-04 06:17:54 --> Language Class Initialized
INFO - 2025-05-04 06:17:54 --> Loader Class Initialized
INFO - 2025-05-04 06:17:54 --> Helper loaded: url_helper
INFO - 2025-05-04 06:17:54 --> Helper loaded: string_helper
INFO - 2025-05-04 06:17:54 --> Helper loaded: form_helper
INFO - 2025-05-04 06:17:54 --> Helper loaded: file_helper
INFO - 2025-05-04 06:17:54 --> Helper loaded: html_helper
INFO - 2025-05-04 06:17:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:17:54 --> Controller Class Initialized
INFO - 2025-05-04 14:17:54 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:18:19 --> Config Class Initialized
INFO - 2025-05-04 06:18:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:18:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:18:19 --> Utf8 Class Initialized
INFO - 2025-05-04 06:18:19 --> URI Class Initialized
DEBUG - 2025-05-04 06:18:19 --> No URI present. Default controller set.
INFO - 2025-05-04 06:18:19 --> Router Class Initialized
INFO - 2025-05-04 06:18:19 --> Output Class Initialized
INFO - 2025-05-04 06:18:19 --> Security Class Initialized
DEBUG - 2025-05-04 06:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:18:19 --> Input Class Initialized
INFO - 2025-05-04 06:18:19 --> Language Class Initialized
INFO - 2025-05-04 06:18:19 --> Loader Class Initialized
INFO - 2025-05-04 06:18:19 --> Helper loaded: url_helper
INFO - 2025-05-04 06:18:19 --> Helper loaded: string_helper
INFO - 2025-05-04 06:18:19 --> Helper loaded: form_helper
INFO - 2025-05-04 06:18:19 --> Helper loaded: file_helper
INFO - 2025-05-04 06:18:19 --> Helper loaded: html_helper
INFO - 2025-05-04 06:18:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:18:20 --> Controller Class Initialized
INFO - 2025-05-04 06:18:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:18:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:18:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:18:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:18:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:18:20 --> Final output sent to browser
DEBUG - 2025-05-04 06:18:20 --> Total execution time: 0.1324
INFO - 2025-05-04 06:18:22 --> Config Class Initialized
INFO - 2025-05-04 06:18:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:18:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:18:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:18:22 --> URI Class Initialized
INFO - 2025-05-04 06:18:22 --> Router Class Initialized
INFO - 2025-05-04 06:18:22 --> Output Class Initialized
INFO - 2025-05-04 06:18:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:18:22 --> Input Class Initialized
INFO - 2025-05-04 06:18:22 --> Language Class Initialized
INFO - 2025-05-04 06:18:22 --> Loader Class Initialized
INFO - 2025-05-04 06:18:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:18:22 --> Helper loaded: string_helper
INFO - 2025-05-04 06:18:22 --> Helper loaded: form_helper
INFO - 2025-05-04 06:18:22 --> Helper loaded: file_helper
INFO - 2025-05-04 06:18:22 --> Helper loaded: html_helper
INFO - 2025-05-04 06:18:22 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:18:22 --> Controller Class Initialized
INFO - 2025-05-04 14:18:22 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:18:44 --> Config Class Initialized
INFO - 2025-05-04 06:18:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:18:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:18:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:18:44 --> URI Class Initialized
DEBUG - 2025-05-04 06:18:44 --> No URI present. Default controller set.
INFO - 2025-05-04 06:18:44 --> Router Class Initialized
INFO - 2025-05-04 06:18:44 --> Output Class Initialized
INFO - 2025-05-04 06:18:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:18:44 --> Input Class Initialized
INFO - 2025-05-04 06:18:44 --> Language Class Initialized
INFO - 2025-05-04 06:18:44 --> Loader Class Initialized
INFO - 2025-05-04 06:18:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:18:44 --> Helper loaded: string_helper
INFO - 2025-05-04 06:18:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:18:44 --> Helper loaded: file_helper
INFO - 2025-05-04 06:18:44 --> Helper loaded: html_helper
INFO - 2025-05-04 06:18:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:18:44 --> Controller Class Initialized
INFO - 2025-05-04 06:18:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:18:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:18:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:18:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:18:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:18:44 --> Final output sent to browser
DEBUG - 2025-05-04 06:18:44 --> Total execution time: 0.0983
INFO - 2025-05-04 06:18:46 --> Config Class Initialized
INFO - 2025-05-04 06:18:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:18:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:18:46 --> Utf8 Class Initialized
INFO - 2025-05-04 06:18:46 --> URI Class Initialized
INFO - 2025-05-04 06:18:46 --> Router Class Initialized
INFO - 2025-05-04 06:18:46 --> Output Class Initialized
INFO - 2025-05-04 06:18:46 --> Security Class Initialized
DEBUG - 2025-05-04 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:18:46 --> Input Class Initialized
INFO - 2025-05-04 06:18:46 --> Language Class Initialized
INFO - 2025-05-04 06:18:46 --> Loader Class Initialized
INFO - 2025-05-04 06:18:46 --> Helper loaded: url_helper
INFO - 2025-05-04 06:18:46 --> Helper loaded: string_helper
INFO - 2025-05-04 06:18:46 --> Helper loaded: form_helper
INFO - 2025-05-04 06:18:46 --> Helper loaded: file_helper
INFO - 2025-05-04 06:18:46 --> Helper loaded: html_helper
INFO - 2025-05-04 06:18:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:18:46 --> Controller Class Initialized
INFO - 2025-05-04 14:18:46 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:20:13 --> Config Class Initialized
INFO - 2025-05-04 06:20:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:20:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:20:13 --> Utf8 Class Initialized
INFO - 2025-05-04 06:20:13 --> URI Class Initialized
DEBUG - 2025-05-04 06:20:13 --> No URI present. Default controller set.
INFO - 2025-05-04 06:20:13 --> Router Class Initialized
INFO - 2025-05-04 06:20:13 --> Output Class Initialized
INFO - 2025-05-04 06:20:13 --> Security Class Initialized
DEBUG - 2025-05-04 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:20:13 --> Input Class Initialized
INFO - 2025-05-04 06:20:13 --> Language Class Initialized
INFO - 2025-05-04 06:20:13 --> Loader Class Initialized
INFO - 2025-05-04 06:20:13 --> Helper loaded: url_helper
INFO - 2025-05-04 06:20:13 --> Helper loaded: string_helper
INFO - 2025-05-04 06:20:13 --> Helper loaded: form_helper
INFO - 2025-05-04 06:20:13 --> Helper loaded: file_helper
INFO - 2025-05-04 06:20:13 --> Helper loaded: html_helper
INFO - 2025-05-04 06:20:13 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:20:13 --> Controller Class Initialized
INFO - 2025-05-04 06:20:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:20:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:20:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:20:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:20:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:20:13 --> Final output sent to browser
DEBUG - 2025-05-04 06:20:13 --> Total execution time: 0.2632
INFO - 2025-05-04 06:20:16 --> Config Class Initialized
INFO - 2025-05-04 06:20:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:20:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:20:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:20:16 --> URI Class Initialized
INFO - 2025-05-04 06:20:16 --> Router Class Initialized
INFO - 2025-05-04 06:20:16 --> Output Class Initialized
INFO - 2025-05-04 06:20:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:20:16 --> Input Class Initialized
INFO - 2025-05-04 06:20:16 --> Language Class Initialized
INFO - 2025-05-04 06:20:16 --> Loader Class Initialized
INFO - 2025-05-04 06:20:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:20:16 --> Helper loaded: string_helper
INFO - 2025-05-04 06:20:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:20:16 --> Helper loaded: file_helper
INFO - 2025-05-04 06:20:16 --> Helper loaded: html_helper
INFO - 2025-05-04 06:20:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:20:16 --> Controller Class Initialized
INFO - 2025-05-04 14:20:16 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:21:44 --> Config Class Initialized
INFO - 2025-05-04 06:21:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:21:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:21:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:21:44 --> URI Class Initialized
DEBUG - 2025-05-04 06:21:44 --> No URI present. Default controller set.
INFO - 2025-05-04 06:21:44 --> Router Class Initialized
INFO - 2025-05-04 06:21:44 --> Output Class Initialized
INFO - 2025-05-04 06:21:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:21:44 --> Input Class Initialized
INFO - 2025-05-04 06:21:44 --> Language Class Initialized
INFO - 2025-05-04 06:21:44 --> Loader Class Initialized
INFO - 2025-05-04 06:21:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:21:44 --> Helper loaded: string_helper
INFO - 2025-05-04 06:21:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:21:44 --> Helper loaded: file_helper
INFO - 2025-05-04 06:21:44 --> Helper loaded: html_helper
INFO - 2025-05-04 06:21:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:21:44 --> Controller Class Initialized
INFO - 2025-05-04 06:21:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:21:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:21:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:21:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:21:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:21:44 --> Final output sent to browser
DEBUG - 2025-05-04 06:21:44 --> Total execution time: 0.1426
INFO - 2025-05-04 06:22:26 --> Config Class Initialized
INFO - 2025-05-04 06:22:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:22:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:22:26 --> Utf8 Class Initialized
INFO - 2025-05-04 06:22:26 --> URI Class Initialized
DEBUG - 2025-05-04 06:22:26 --> No URI present. Default controller set.
INFO - 2025-05-04 06:22:26 --> Router Class Initialized
INFO - 2025-05-04 06:22:26 --> Output Class Initialized
INFO - 2025-05-04 06:22:26 --> Security Class Initialized
DEBUG - 2025-05-04 06:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:22:26 --> Input Class Initialized
INFO - 2025-05-04 06:22:26 --> Language Class Initialized
INFO - 2025-05-04 06:22:26 --> Loader Class Initialized
INFO - 2025-05-04 06:22:26 --> Helper loaded: url_helper
INFO - 2025-05-04 06:22:26 --> Helper loaded: string_helper
INFO - 2025-05-04 06:22:26 --> Helper loaded: form_helper
INFO - 2025-05-04 06:22:26 --> Helper loaded: file_helper
INFO - 2025-05-04 06:22:26 --> Helper loaded: html_helper
INFO - 2025-05-04 06:22:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:22:26 --> Controller Class Initialized
INFO - 2025-05-04 06:22:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:22:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:22:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:22:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:22:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:22:26 --> Final output sent to browser
DEBUG - 2025-05-04 06:22:26 --> Total execution time: 0.1851
INFO - 2025-05-04 06:22:35 --> Config Class Initialized
INFO - 2025-05-04 06:22:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:22:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:22:35 --> Utf8 Class Initialized
INFO - 2025-05-04 06:22:35 --> URI Class Initialized
INFO - 2025-05-04 06:22:35 --> Router Class Initialized
INFO - 2025-05-04 06:22:35 --> Output Class Initialized
INFO - 2025-05-04 06:22:35 --> Security Class Initialized
DEBUG - 2025-05-04 06:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:22:35 --> Input Class Initialized
INFO - 2025-05-04 06:22:35 --> Language Class Initialized
INFO - 2025-05-04 06:22:35 --> Loader Class Initialized
INFO - 2025-05-04 06:22:35 --> Helper loaded: url_helper
INFO - 2025-05-04 06:22:35 --> Helper loaded: string_helper
INFO - 2025-05-04 06:22:35 --> Helper loaded: form_helper
INFO - 2025-05-04 06:22:35 --> Helper loaded: file_helper
INFO - 2025-05-04 06:22:35 --> Helper loaded: html_helper
INFO - 2025-05-04 06:22:35 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:22:35 --> Controller Class Initialized
INFO - 2025-05-04 14:22:35 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:23:21 --> Config Class Initialized
INFO - 2025-05-04 06:23:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:21 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:21 --> URI Class Initialized
DEBUG - 2025-05-04 06:23:21 --> No URI present. Default controller set.
INFO - 2025-05-04 06:23:21 --> Router Class Initialized
INFO - 2025-05-04 06:23:21 --> Output Class Initialized
INFO - 2025-05-04 06:23:21 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:21 --> Input Class Initialized
INFO - 2025-05-04 06:23:21 --> Language Class Initialized
INFO - 2025-05-04 06:23:21 --> Loader Class Initialized
INFO - 2025-05-04 06:23:21 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:21 --> Helper loaded: string_helper
INFO - 2025-05-04 06:23:21 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:21 --> Helper loaded: file_helper
INFO - 2025-05-04 06:23:21 --> Helper loaded: html_helper
INFO - 2025-05-04 06:23:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:22 --> Controller Class Initialized
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:23:22 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:22 --> Total execution time: 0.2173
INFO - 2025-05-04 06:23:23 --> Config Class Initialized
INFO - 2025-05-04 06:23:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:23 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:23 --> URI Class Initialized
INFO - 2025-05-04 06:23:23 --> Router Class Initialized
INFO - 2025-05-04 06:23:23 --> Output Class Initialized
INFO - 2025-05-04 06:23:23 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:23 --> Input Class Initialized
INFO - 2025-05-04 06:23:23 --> Language Class Initialized
INFO - 2025-05-04 06:23:23 --> Loader Class Initialized
INFO - 2025-05-04 06:23:23 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:23 --> Helper loaded: string_helper
INFO - 2025-05-04 06:23:23 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:23 --> Helper loaded: file_helper
INFO - 2025-05-04 06:23:23 --> Helper loaded: html_helper
INFO - 2025-05-04 06:23:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:23 --> Controller Class Initialized
INFO - 2025-05-04 14:23:23 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:47:11 --> Config Class Initialized
INFO - 2025-05-04 06:47:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:47:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:47:11 --> Utf8 Class Initialized
INFO - 2025-05-04 06:47:11 --> URI Class Initialized
DEBUG - 2025-05-04 06:47:12 --> No URI present. Default controller set.
INFO - 2025-05-04 06:47:12 --> Router Class Initialized
INFO - 2025-05-04 06:47:12 --> Output Class Initialized
INFO - 2025-05-04 06:47:12 --> Security Class Initialized
DEBUG - 2025-05-04 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:47:12 --> Input Class Initialized
INFO - 2025-05-04 06:47:12 --> Language Class Initialized
INFO - 2025-05-04 06:47:12 --> Loader Class Initialized
INFO - 2025-05-04 06:47:12 --> Helper loaded: url_helper
INFO - 2025-05-04 06:47:12 --> Helper loaded: string_helper
INFO - 2025-05-04 06:47:12 --> Helper loaded: form_helper
INFO - 2025-05-04 06:47:12 --> Helper loaded: file_helper
INFO - 2025-05-04 06:47:12 --> Helper loaded: html_helper
INFO - 2025-05-04 06:47:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:47:12 --> Controller Class Initialized
INFO - 2025-05-04 06:47:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:47:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:47:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:47:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:47:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:47:12 --> Final output sent to browser
DEBUG - 2025-05-04 06:47:12 --> Total execution time: 0.5059
INFO - 2025-05-04 06:47:16 --> Config Class Initialized
INFO - 2025-05-04 06:47:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:47:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:47:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:47:16 --> URI Class Initialized
INFO - 2025-05-04 06:47:16 --> Router Class Initialized
INFO - 2025-05-04 06:47:16 --> Output Class Initialized
INFO - 2025-05-04 06:47:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:47:16 --> Input Class Initialized
INFO - 2025-05-04 06:47:16 --> Language Class Initialized
INFO - 2025-05-04 06:47:17 --> Loader Class Initialized
INFO - 2025-05-04 06:47:17 --> Helper loaded: url_helper
INFO - 2025-05-04 06:47:17 --> Helper loaded: string_helper
INFO - 2025-05-04 06:47:17 --> Helper loaded: form_helper
INFO - 2025-05-04 06:47:17 --> Helper loaded: file_helper
INFO - 2025-05-04 06:47:17 --> Helper loaded: html_helper
INFO - 2025-05-04 06:47:17 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:47:17 --> Controller Class Initialized
INFO - 2025-05-04 14:47:17 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:47:41 --> Config Class Initialized
INFO - 2025-05-04 06:47:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:47:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:47:41 --> Utf8 Class Initialized
INFO - 2025-05-04 06:47:41 --> URI Class Initialized
DEBUG - 2025-05-04 06:47:41 --> No URI present. Default controller set.
INFO - 2025-05-04 06:47:41 --> Router Class Initialized
INFO - 2025-05-04 06:47:41 --> Output Class Initialized
INFO - 2025-05-04 06:47:41 --> Security Class Initialized
DEBUG - 2025-05-04 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:47:41 --> Input Class Initialized
INFO - 2025-05-04 06:47:41 --> Language Class Initialized
INFO - 2025-05-04 06:47:41 --> Loader Class Initialized
INFO - 2025-05-04 06:47:41 --> Helper loaded: url_helper
INFO - 2025-05-04 06:47:41 --> Helper loaded: string_helper
INFO - 2025-05-04 06:47:41 --> Helper loaded: form_helper
INFO - 2025-05-04 06:47:41 --> Helper loaded: file_helper
INFO - 2025-05-04 06:47:41 --> Helper loaded: html_helper
INFO - 2025-05-04 06:47:41 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:47:41 --> Controller Class Initialized
INFO - 2025-05-04 06:47:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:47:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:47:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:47:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:47:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:47:41 --> Final output sent to browser
DEBUG - 2025-05-04 06:47:41 --> Total execution time: 0.1499
INFO - 2025-05-04 06:47:44 --> Config Class Initialized
INFO - 2025-05-04 06:47:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:47:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:47:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:47:44 --> URI Class Initialized
INFO - 2025-05-04 06:47:44 --> Router Class Initialized
INFO - 2025-05-04 06:47:44 --> Output Class Initialized
INFO - 2025-05-04 06:47:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:47:44 --> Input Class Initialized
INFO - 2025-05-04 06:47:44 --> Language Class Initialized
INFO - 2025-05-04 06:47:44 --> Loader Class Initialized
INFO - 2025-05-04 06:47:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:47:44 --> Helper loaded: string_helper
INFO - 2025-05-04 06:47:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:47:44 --> Helper loaded: file_helper
INFO - 2025-05-04 06:47:44 --> Helper loaded: html_helper
INFO - 2025-05-04 06:47:44 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:47:44 --> Controller Class Initialized
INFO - 2025-05-04 14:47:44 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:48:18 --> Config Class Initialized
INFO - 2025-05-04 06:48:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:48:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:48:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:48:18 --> URI Class Initialized
DEBUG - 2025-05-04 06:48:18 --> No URI present. Default controller set.
INFO - 2025-05-04 06:48:18 --> Router Class Initialized
INFO - 2025-05-04 06:48:18 --> Output Class Initialized
INFO - 2025-05-04 06:48:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:48:18 --> Input Class Initialized
INFO - 2025-05-04 06:48:18 --> Language Class Initialized
INFO - 2025-05-04 06:48:18 --> Loader Class Initialized
INFO - 2025-05-04 06:48:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:48:18 --> Helper loaded: string_helper
INFO - 2025-05-04 06:48:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:48:18 --> Helper loaded: file_helper
INFO - 2025-05-04 06:48:18 --> Helper loaded: html_helper
INFO - 2025-05-04 06:48:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:48:18 --> Controller Class Initialized
INFO - 2025-05-04 06:48:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:48:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:48:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:48:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:48:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:48:18 --> Final output sent to browser
DEBUG - 2025-05-04 06:48:18 --> Total execution time: 0.0909
INFO - 2025-05-04 06:48:19 --> Config Class Initialized
INFO - 2025-05-04 06:48:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:48:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:48:19 --> Utf8 Class Initialized
INFO - 2025-05-04 06:48:19 --> URI Class Initialized
INFO - 2025-05-04 06:48:19 --> Router Class Initialized
INFO - 2025-05-04 06:48:19 --> Output Class Initialized
INFO - 2025-05-04 06:48:19 --> Security Class Initialized
DEBUG - 2025-05-04 06:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:48:19 --> Input Class Initialized
INFO - 2025-05-04 06:48:19 --> Language Class Initialized
INFO - 2025-05-04 06:48:19 --> Loader Class Initialized
INFO - 2025-05-04 06:48:19 --> Helper loaded: url_helper
INFO - 2025-05-04 06:48:19 --> Helper loaded: string_helper
INFO - 2025-05-04 06:48:19 --> Helper loaded: form_helper
INFO - 2025-05-04 06:48:19 --> Helper loaded: file_helper
INFO - 2025-05-04 06:48:19 --> Helper loaded: html_helper
INFO - 2025-05-04 06:48:19 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:48:19 --> Controller Class Initialized
INFO - 2025-05-04 14:48:19 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:48:21 --> Config Class Initialized
INFO - 2025-05-04 06:48:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:48:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:48:21 --> Utf8 Class Initialized
INFO - 2025-05-04 06:48:21 --> URI Class Initialized
DEBUG - 2025-05-04 06:48:21 --> No URI present. Default controller set.
INFO - 2025-05-04 06:48:21 --> Router Class Initialized
INFO - 2025-05-04 06:48:21 --> Output Class Initialized
INFO - 2025-05-04 06:48:21 --> Security Class Initialized
DEBUG - 2025-05-04 06:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:48:21 --> Input Class Initialized
INFO - 2025-05-04 06:48:21 --> Language Class Initialized
INFO - 2025-05-04 06:48:21 --> Loader Class Initialized
INFO - 2025-05-04 06:48:21 --> Helper loaded: url_helper
INFO - 2025-05-04 06:48:21 --> Helper loaded: string_helper
INFO - 2025-05-04 06:48:21 --> Helper loaded: form_helper
INFO - 2025-05-04 06:48:21 --> Helper loaded: file_helper
INFO - 2025-05-04 06:48:21 --> Helper loaded: html_helper
INFO - 2025-05-04 06:48:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:48:21 --> Controller Class Initialized
INFO - 2025-05-04 06:48:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:48:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:48:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:48:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:48:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:48:21 --> Final output sent to browser
DEBUG - 2025-05-04 06:48:21 --> Total execution time: 0.1273
INFO - 2025-05-04 06:48:22 --> Config Class Initialized
INFO - 2025-05-04 06:48:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:48:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:48:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:48:22 --> URI Class Initialized
INFO - 2025-05-04 06:48:22 --> Router Class Initialized
INFO - 2025-05-04 06:48:22 --> Output Class Initialized
INFO - 2025-05-04 06:48:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:48:22 --> Input Class Initialized
INFO - 2025-05-04 06:48:22 --> Language Class Initialized
INFO - 2025-05-04 06:48:22 --> Loader Class Initialized
INFO - 2025-05-04 06:48:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:48:22 --> Helper loaded: string_helper
INFO - 2025-05-04 06:48:23 --> Helper loaded: form_helper
INFO - 2025-05-04 06:48:23 --> Helper loaded: file_helper
INFO - 2025-05-04 06:48:23 --> Helper loaded: html_helper
INFO - 2025-05-04 06:48:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:48:23 --> Controller Class Initialized
INFO - 2025-05-04 14:48:23 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:53:37 --> Config Class Initialized
INFO - 2025-05-04 06:53:37 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:53:37 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:53:37 --> Utf8 Class Initialized
INFO - 2025-05-04 06:53:37 --> URI Class Initialized
DEBUG - 2025-05-04 06:53:37 --> No URI present. Default controller set.
INFO - 2025-05-04 06:53:37 --> Router Class Initialized
INFO - 2025-05-04 06:53:37 --> Output Class Initialized
INFO - 2025-05-04 06:53:37 --> Security Class Initialized
DEBUG - 2025-05-04 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:53:37 --> Input Class Initialized
INFO - 2025-05-04 06:53:37 --> Language Class Initialized
INFO - 2025-05-04 06:53:37 --> Loader Class Initialized
INFO - 2025-05-04 06:53:37 --> Helper loaded: url_helper
INFO - 2025-05-04 06:53:37 --> Helper loaded: string_helper
INFO - 2025-05-04 06:53:37 --> Helper loaded: form_helper
INFO - 2025-05-04 06:53:37 --> Helper loaded: file_helper
INFO - 2025-05-04 06:53:37 --> Helper loaded: html_helper
INFO - 2025-05-04 06:53:37 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:53:37 --> Controller Class Initialized
INFO - 2025-05-04 06:53:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:53:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:53:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:53:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:53:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:53:37 --> Final output sent to browser
DEBUG - 2025-05-04 06:53:37 --> Total execution time: 0.3823
INFO - 2025-05-04 06:53:39 --> Config Class Initialized
INFO - 2025-05-04 06:53:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:53:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:53:39 --> Utf8 Class Initialized
INFO - 2025-05-04 06:53:39 --> URI Class Initialized
INFO - 2025-05-04 06:53:39 --> Router Class Initialized
INFO - 2025-05-04 06:53:39 --> Output Class Initialized
INFO - 2025-05-04 06:53:39 --> Security Class Initialized
DEBUG - 2025-05-04 06:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:53:39 --> Input Class Initialized
INFO - 2025-05-04 06:53:39 --> Language Class Initialized
INFO - 2025-05-04 06:53:39 --> Loader Class Initialized
INFO - 2025-05-04 06:53:39 --> Helper loaded: url_helper
INFO - 2025-05-04 06:53:39 --> Helper loaded: string_helper
INFO - 2025-05-04 06:53:39 --> Helper loaded: form_helper
INFO - 2025-05-04 06:53:39 --> Helper loaded: file_helper
INFO - 2025-05-04 06:53:39 --> Helper loaded: html_helper
INFO - 2025-05-04 06:53:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:53:39 --> Controller Class Initialized
INFO - 2025-05-04 14:53:39 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:53:48 --> Config Class Initialized
INFO - 2025-05-04 06:53:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:53:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:53:48 --> Utf8 Class Initialized
INFO - 2025-05-04 06:53:48 --> URI Class Initialized
DEBUG - 2025-05-04 06:53:48 --> No URI present. Default controller set.
INFO - 2025-05-04 06:53:48 --> Router Class Initialized
INFO - 2025-05-04 06:53:48 --> Output Class Initialized
INFO - 2025-05-04 06:53:48 --> Security Class Initialized
DEBUG - 2025-05-04 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:53:48 --> Input Class Initialized
INFO - 2025-05-04 06:53:48 --> Language Class Initialized
INFO - 2025-05-04 06:53:48 --> Loader Class Initialized
INFO - 2025-05-04 06:53:48 --> Helper loaded: url_helper
INFO - 2025-05-04 06:53:48 --> Helper loaded: string_helper
INFO - 2025-05-04 06:53:48 --> Helper loaded: form_helper
INFO - 2025-05-04 06:53:48 --> Helper loaded: file_helper
INFO - 2025-05-04 06:53:48 --> Helper loaded: html_helper
INFO - 2025-05-04 06:53:48 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:53:48 --> Controller Class Initialized
INFO - 2025-05-04 06:53:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:53:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:53:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:53:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:53:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:53:48 --> Final output sent to browser
DEBUG - 2025-05-04 06:53:48 --> Total execution time: 0.1493
INFO - 2025-05-04 06:53:54 --> Config Class Initialized
INFO - 2025-05-04 06:53:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:53:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:53:54 --> Utf8 Class Initialized
INFO - 2025-05-04 06:53:54 --> URI Class Initialized
DEBUG - 2025-05-04 06:53:54 --> No URI present. Default controller set.
INFO - 2025-05-04 06:53:54 --> Router Class Initialized
INFO - 2025-05-04 06:53:54 --> Output Class Initialized
INFO - 2025-05-04 06:53:54 --> Security Class Initialized
DEBUG - 2025-05-04 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:53:54 --> Input Class Initialized
INFO - 2025-05-04 06:53:54 --> Language Class Initialized
INFO - 2025-05-04 06:53:54 --> Loader Class Initialized
INFO - 2025-05-04 06:53:54 --> Helper loaded: url_helper
INFO - 2025-05-04 06:53:54 --> Helper loaded: string_helper
INFO - 2025-05-04 06:53:54 --> Helper loaded: form_helper
INFO - 2025-05-04 06:53:54 --> Helper loaded: file_helper
INFO - 2025-05-04 06:53:54 --> Helper loaded: html_helper
INFO - 2025-05-04 06:53:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:53:54 --> Controller Class Initialized
INFO - 2025-05-04 06:53:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:53:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:53:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:53:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:53:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:53:54 --> Final output sent to browser
DEBUG - 2025-05-04 06:53:54 --> Total execution time: 0.1339
INFO - 2025-05-04 06:53:58 --> Config Class Initialized
INFO - 2025-05-04 06:53:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:53:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:53:58 --> Utf8 Class Initialized
INFO - 2025-05-04 06:53:58 --> URI Class Initialized
INFO - 2025-05-04 06:53:58 --> Router Class Initialized
INFO - 2025-05-04 06:53:58 --> Output Class Initialized
INFO - 2025-05-04 06:53:58 --> Security Class Initialized
DEBUG - 2025-05-04 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:53:58 --> Input Class Initialized
INFO - 2025-05-04 06:53:58 --> Language Class Initialized
INFO - 2025-05-04 06:53:58 --> Loader Class Initialized
INFO - 2025-05-04 06:53:58 --> Helper loaded: url_helper
INFO - 2025-05-04 06:53:58 --> Helper loaded: string_helper
INFO - 2025-05-04 06:53:58 --> Helper loaded: form_helper
INFO - 2025-05-04 06:53:58 --> Helper loaded: file_helper
INFO - 2025-05-04 06:53:58 --> Helper loaded: html_helper
INFO - 2025-05-04 06:53:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:53:58 --> Controller Class Initialized
INFO - 2025-05-04 14:53:58 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:54:53 --> Config Class Initialized
INFO - 2025-05-04 06:54:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:54:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:54:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:54:53 --> URI Class Initialized
DEBUG - 2025-05-04 06:54:53 --> No URI present. Default controller set.
INFO - 2025-05-04 06:54:53 --> Router Class Initialized
INFO - 2025-05-04 06:54:53 --> Output Class Initialized
INFO - 2025-05-04 06:54:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:54:53 --> Input Class Initialized
INFO - 2025-05-04 06:54:53 --> Language Class Initialized
INFO - 2025-05-04 06:54:53 --> Loader Class Initialized
INFO - 2025-05-04 06:54:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:54:53 --> Helper loaded: string_helper
INFO - 2025-05-04 06:54:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:54:53 --> Helper loaded: file_helper
INFO - 2025-05-04 06:54:53 --> Helper loaded: html_helper
INFO - 2025-05-04 06:54:53 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:54:53 --> Controller Class Initialized
INFO - 2025-05-04 06:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:54:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:54:53 --> Final output sent to browser
DEBUG - 2025-05-04 06:54:53 --> Total execution time: 0.1793
INFO - 2025-05-04 06:54:55 --> Config Class Initialized
INFO - 2025-05-04 06:54:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:54:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:54:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:54:55 --> URI Class Initialized
INFO - 2025-05-04 06:54:55 --> Config Class Initialized
INFO - 2025-05-04 06:54:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:54:55 --> No URI present. Default controller set.
INFO - 2025-05-04 06:54:55 --> Router Class Initialized
DEBUG - 2025-05-04 06:54:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:54:55 --> Output Class Initialized
INFO - 2025-05-04 06:54:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:54:55 --> Security Class Initialized
INFO - 2025-05-04 06:54:55 --> URI Class Initialized
DEBUG - 2025-05-04 06:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:54:55 --> Input Class Initialized
INFO - 2025-05-04 06:54:55 --> Router Class Initialized
INFO - 2025-05-04 06:54:55 --> Language Class Initialized
INFO - 2025-05-04 06:54:55 --> Output Class Initialized
INFO - 2025-05-04 06:54:55 --> Security Class Initialized
INFO - 2025-05-04 06:54:55 --> Loader Class Initialized
DEBUG - 2025-05-04 06:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:54:55 --> Input Class Initialized
INFO - 2025-05-04 06:54:55 --> Helper loaded: url_helper
INFO - 2025-05-04 06:54:55 --> Language Class Initialized
INFO - 2025-05-04 06:54:55 --> Helper loaded: string_helper
INFO - 2025-05-04 06:54:55 --> Helper loaded: form_helper
INFO - 2025-05-04 06:54:55 --> Helper loaded: file_helper
INFO - 2025-05-04 06:54:55 --> Loader Class Initialized
INFO - 2025-05-04 06:54:55 --> Helper loaded: html_helper
INFO - 2025-05-04 06:54:56 --> Helper loaded: url_helper
INFO - 2025-05-04 06:54:56 --> Helper loaded: string_helper
INFO - 2025-05-04 06:54:56 --> Helper loaded: form_helper
INFO - 2025-05-04 06:54:56 --> Helper loaded: file_helper
INFO - 2025-05-04 06:54:56 --> Helper loaded: html_helper
INFO - 2025-05-04 06:54:56 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:54:56 --> Controller Class Initialized
INFO - 2025-05-04 06:54:56 --> Database Driver Class Initialized
INFO - 2025-05-04 06:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
DEBUG - 2025-05-04 06:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:54:56 --> Final output sent to browser
DEBUG - 2025-05-04 06:54:56 --> Total execution time: 0.3477
INFO - 2025-05-04 06:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:54:56 --> Controller Class Initialized
INFO - 2025-05-04 14:54:56 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:55:04 --> Config Class Initialized
INFO - 2025-05-04 06:55:04 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:04 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:04 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:04 --> URI Class Initialized
INFO - 2025-05-04 06:55:04 --> Router Class Initialized
INFO - 2025-05-04 06:55:04 --> Output Class Initialized
INFO - 2025-05-04 06:55:04 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:04 --> Input Class Initialized
INFO - 2025-05-04 06:55:04 --> Language Class Initialized
INFO - 2025-05-04 06:55:04 --> Loader Class Initialized
INFO - 2025-05-04 06:55:04 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:04 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:04 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:04 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:04 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:04 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:04 --> Controller Class Initialized
INFO - 2025-05-04 14:55:04 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:55:07 --> Config Class Initialized
INFO - 2025-05-04 06:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:07 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:07 --> URI Class Initialized
DEBUG - 2025-05-04 06:55:07 --> No URI present. Default controller set.
INFO - 2025-05-04 06:55:07 --> Router Class Initialized
INFO - 2025-05-04 06:55:07 --> Output Class Initialized
INFO - 2025-05-04 06:55:07 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:07 --> Input Class Initialized
INFO - 2025-05-04 06:55:07 --> Language Class Initialized
INFO - 2025-05-04 06:55:08 --> Loader Class Initialized
INFO - 2025-05-04 06:55:08 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:08 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:08 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:08 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:08 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:08 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:08 --> Controller Class Initialized
INFO - 2025-05-04 06:55:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:55:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:55:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:55:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:55:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:55:08 --> Final output sent to browser
DEBUG - 2025-05-04 06:55:08 --> Total execution time: 0.2018
INFO - 2025-05-04 06:55:10 --> Config Class Initialized
INFO - 2025-05-04 06:55:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:10 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:10 --> URI Class Initialized
INFO - 2025-05-04 06:55:10 --> Router Class Initialized
INFO - 2025-05-04 06:55:10 --> Output Class Initialized
INFO - 2025-05-04 06:55:10 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:10 --> Input Class Initialized
INFO - 2025-05-04 06:55:10 --> Language Class Initialized
INFO - 2025-05-04 06:55:10 --> Loader Class Initialized
INFO - 2025-05-04 06:55:10 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:10 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:10 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:10 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:10 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:10 --> Controller Class Initialized
INFO - 2025-05-04 14:55:10 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:55:30 --> Config Class Initialized
INFO - 2025-05-04 06:55:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:30 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:30 --> URI Class Initialized
DEBUG - 2025-05-04 06:55:30 --> No URI present. Default controller set.
INFO - 2025-05-04 06:55:30 --> Router Class Initialized
INFO - 2025-05-04 06:55:30 --> Output Class Initialized
INFO - 2025-05-04 06:55:30 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:30 --> Input Class Initialized
INFO - 2025-05-04 06:55:30 --> Language Class Initialized
INFO - 2025-05-04 06:55:30 --> Loader Class Initialized
INFO - 2025-05-04 06:55:30 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:30 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:30 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:30 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:30 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:30 --> Controller Class Initialized
INFO - 2025-05-04 06:55:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:55:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:55:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:55:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:55:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:55:30 --> Final output sent to browser
DEBUG - 2025-05-04 06:55:30 --> Total execution time: 0.1435
INFO - 2025-05-04 06:55:32 --> Config Class Initialized
INFO - 2025-05-04 06:55:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:32 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:32 --> URI Class Initialized
INFO - 2025-05-04 06:55:32 --> Router Class Initialized
INFO - 2025-05-04 06:55:32 --> Output Class Initialized
INFO - 2025-05-04 06:55:32 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:32 --> Input Class Initialized
INFO - 2025-05-04 06:55:32 --> Language Class Initialized
INFO - 2025-05-04 06:55:32 --> Loader Class Initialized
INFO - 2025-05-04 06:55:32 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:32 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:32 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:32 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:32 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:32 --> Controller Class Initialized
INFO - 2025-05-04 14:55:32 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:55:34 --> Config Class Initialized
INFO - 2025-05-04 06:55:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:34 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:34 --> URI Class Initialized
DEBUG - 2025-05-04 06:55:34 --> No URI present. Default controller set.
INFO - 2025-05-04 06:55:34 --> Router Class Initialized
INFO - 2025-05-04 06:55:34 --> Output Class Initialized
INFO - 2025-05-04 06:55:34 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:34 --> Input Class Initialized
INFO - 2025-05-04 06:55:34 --> Language Class Initialized
INFO - 2025-05-04 06:55:34 --> Loader Class Initialized
INFO - 2025-05-04 06:55:34 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:34 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:34 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:34 --> Controller Class Initialized
INFO - 2025-05-04 06:55:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:55:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:55:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:55:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:55:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:55:34 --> Final output sent to browser
DEBUG - 2025-05-04 06:55:34 --> Total execution time: 0.7934
INFO - 2025-05-04 06:55:38 --> Config Class Initialized
INFO - 2025-05-04 06:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:38 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:38 --> URI Class Initialized
INFO - 2025-05-04 06:55:38 --> Router Class Initialized
INFO - 2025-05-04 06:55:38 --> Output Class Initialized
INFO - 2025-05-04 06:55:38 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:38 --> Input Class Initialized
INFO - 2025-05-04 06:55:38 --> Language Class Initialized
INFO - 2025-05-04 06:55:38 --> Loader Class Initialized
INFO - 2025-05-04 06:55:38 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:38 --> Helper loaded: string_helper
INFO - 2025-05-04 06:55:38 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:38 --> Helper loaded: file_helper
INFO - 2025-05-04 06:55:38 --> Helper loaded: html_helper
INFO - 2025-05-04 06:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:38 --> Controller Class Initialized
INFO - 2025-05-04 14:55:38 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:56:01 --> Config Class Initialized
INFO - 2025-05-04 06:56:01 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:56:01 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:56:01 --> Utf8 Class Initialized
INFO - 2025-05-04 06:56:01 --> URI Class Initialized
DEBUG - 2025-05-04 06:56:01 --> No URI present. Default controller set.
INFO - 2025-05-04 06:56:01 --> Router Class Initialized
INFO - 2025-05-04 06:56:01 --> Output Class Initialized
INFO - 2025-05-04 06:56:01 --> Security Class Initialized
DEBUG - 2025-05-04 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:56:01 --> Input Class Initialized
INFO - 2025-05-04 06:56:01 --> Language Class Initialized
INFO - 2025-05-04 06:56:01 --> Loader Class Initialized
INFO - 2025-05-04 06:56:01 --> Helper loaded: url_helper
INFO - 2025-05-04 06:56:01 --> Helper loaded: string_helper
INFO - 2025-05-04 06:56:01 --> Helper loaded: form_helper
INFO - 2025-05-04 06:56:01 --> Helper loaded: file_helper
INFO - 2025-05-04 06:56:01 --> Helper loaded: html_helper
INFO - 2025-05-04 06:56:01 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:56:02 --> Controller Class Initialized
INFO - 2025-05-04 06:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:56:02 --> Final output sent to browser
DEBUG - 2025-05-04 06:56:02 --> Total execution time: 0.1611
INFO - 2025-05-04 06:56:05 --> Config Class Initialized
INFO - 2025-05-04 06:56:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:56:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:56:05 --> Utf8 Class Initialized
INFO - 2025-05-04 06:56:05 --> URI Class Initialized
INFO - 2025-05-04 06:56:05 --> Router Class Initialized
INFO - 2025-05-04 06:56:05 --> Output Class Initialized
INFO - 2025-05-04 06:56:05 --> Security Class Initialized
DEBUG - 2025-05-04 06:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:56:05 --> Input Class Initialized
INFO - 2025-05-04 06:56:05 --> Language Class Initialized
INFO - 2025-05-04 06:56:05 --> Loader Class Initialized
INFO - 2025-05-04 06:56:05 --> Helper loaded: url_helper
INFO - 2025-05-04 06:56:05 --> Helper loaded: string_helper
INFO - 2025-05-04 06:56:05 --> Helper loaded: form_helper
INFO - 2025-05-04 06:56:05 --> Helper loaded: file_helper
INFO - 2025-05-04 06:56:05 --> Helper loaded: html_helper
INFO - 2025-05-04 06:56:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:56:06 --> Controller Class Initialized
INFO - 2025-05-04 14:56:06 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:57:11 --> Config Class Initialized
INFO - 2025-05-04 06:57:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:57:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:57:11 --> Utf8 Class Initialized
INFO - 2025-05-04 06:57:11 --> URI Class Initialized
DEBUG - 2025-05-04 06:57:11 --> No URI present. Default controller set.
INFO - 2025-05-04 06:57:11 --> Router Class Initialized
INFO - 2025-05-04 06:57:11 --> Output Class Initialized
INFO - 2025-05-04 06:57:11 --> Security Class Initialized
DEBUG - 2025-05-04 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:57:11 --> Input Class Initialized
INFO - 2025-05-04 06:57:11 --> Language Class Initialized
INFO - 2025-05-04 06:57:11 --> Loader Class Initialized
INFO - 2025-05-04 06:57:11 --> Helper loaded: url_helper
INFO - 2025-05-04 06:57:11 --> Helper loaded: string_helper
INFO - 2025-05-04 06:57:11 --> Helper loaded: form_helper
INFO - 2025-05-04 06:57:11 --> Helper loaded: file_helper
INFO - 2025-05-04 06:57:12 --> Helper loaded: html_helper
INFO - 2025-05-04 06:57:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:57:12 --> Controller Class Initialized
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:57:12 --> Final output sent to browser
DEBUG - 2025-05-04 06:57:12 --> Total execution time: 0.4443
INFO - 2025-05-04 06:57:18 --> Config Class Initialized
INFO - 2025-05-04 06:57:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:57:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:57:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:57:18 --> URI Class Initialized
INFO - 2025-05-04 06:57:18 --> Router Class Initialized
INFO - 2025-05-04 06:57:18 --> Output Class Initialized
INFO - 2025-05-04 06:57:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:57:18 --> Input Class Initialized
INFO - 2025-05-04 06:57:18 --> Language Class Initialized
INFO - 2025-05-04 06:57:18 --> Loader Class Initialized
INFO - 2025-05-04 06:57:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:57:18 --> Helper loaded: string_helper
INFO - 2025-05-04 06:57:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:57:18 --> Helper loaded: file_helper
INFO - 2025-05-04 06:57:18 --> Helper loaded: html_helper
INFO - 2025-05-04 06:57:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:57:18 --> Controller Class Initialized
INFO - 2025-05-04 14:57:18 --> Model "AuctionModel" initialized
INFO - 2025-05-04 06:58:29 --> Config Class Initialized
INFO - 2025-05-04 06:58:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:58:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:58:29 --> Utf8 Class Initialized
INFO - 2025-05-04 06:58:29 --> URI Class Initialized
DEBUG - 2025-05-04 06:58:29 --> No URI present. Default controller set.
INFO - 2025-05-04 06:58:29 --> Router Class Initialized
INFO - 2025-05-04 06:58:29 --> Output Class Initialized
INFO - 2025-05-04 06:58:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:58:29 --> Input Class Initialized
INFO - 2025-05-04 06:58:29 --> Language Class Initialized
INFO - 2025-05-04 06:58:29 --> Loader Class Initialized
INFO - 2025-05-04 06:58:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:58:29 --> Helper loaded: string_helper
INFO - 2025-05-04 06:58:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:58:29 --> Helper loaded: file_helper
INFO - 2025-05-04 06:58:29 --> Helper loaded: html_helper
INFO - 2025-05-04 06:58:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:58:29 --> Controller Class Initialized
INFO - 2025-05-04 06:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 06:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 06:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 06:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 06:58:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 06:58:29 --> Final output sent to browser
DEBUG - 2025-05-04 06:58:29 --> Total execution time: 0.1389
INFO - 2025-05-04 06:58:39 --> Config Class Initialized
INFO - 2025-05-04 06:58:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:58:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:58:39 --> Utf8 Class Initialized
INFO - 2025-05-04 06:58:39 --> URI Class Initialized
INFO - 2025-05-04 06:58:39 --> Router Class Initialized
INFO - 2025-05-04 06:58:39 --> Output Class Initialized
INFO - 2025-05-04 06:58:39 --> Security Class Initialized
DEBUG - 2025-05-04 06:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:58:39 --> Input Class Initialized
INFO - 2025-05-04 06:58:39 --> Language Class Initialized
INFO - 2025-05-04 06:58:39 --> Loader Class Initialized
INFO - 2025-05-04 06:58:39 --> Helper loaded: url_helper
INFO - 2025-05-04 06:58:39 --> Helper loaded: string_helper
INFO - 2025-05-04 06:58:39 --> Helper loaded: form_helper
INFO - 2025-05-04 06:58:39 --> Helper loaded: file_helper
INFO - 2025-05-04 06:58:39 --> Helper loaded: html_helper
INFO - 2025-05-04 06:58:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 06:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 06:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:58:39 --> Controller Class Initialized
INFO - 2025-05-04 14:58:39 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:00:59 --> Config Class Initialized
INFO - 2025-05-04 07:00:59 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:00:59 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:00:59 --> Utf8 Class Initialized
INFO - 2025-05-04 07:00:59 --> URI Class Initialized
DEBUG - 2025-05-04 07:00:59 --> No URI present. Default controller set.
INFO - 2025-05-04 07:00:59 --> Router Class Initialized
INFO - 2025-05-04 07:00:59 --> Output Class Initialized
INFO - 2025-05-04 07:00:59 --> Security Class Initialized
DEBUG - 2025-05-04 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:00:59 --> Input Class Initialized
INFO - 2025-05-04 07:00:59 --> Language Class Initialized
INFO - 2025-05-04 07:00:59 --> Loader Class Initialized
INFO - 2025-05-04 07:00:59 --> Helper loaded: url_helper
INFO - 2025-05-04 07:00:59 --> Helper loaded: string_helper
INFO - 2025-05-04 07:00:59 --> Helper loaded: form_helper
INFO - 2025-05-04 07:00:59 --> Helper loaded: file_helper
INFO - 2025-05-04 07:00:59 --> Helper loaded: html_helper
INFO - 2025-05-04 07:00:59 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:00:59 --> Controller Class Initialized
INFO - 2025-05-04 07:00:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 07:00:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 07:00:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 07:00:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 07:00:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 07:00:59 --> Final output sent to browser
DEBUG - 2025-05-04 07:00:59 --> Total execution time: 0.1753
INFO - 2025-05-04 07:01:09 --> Config Class Initialized
INFO - 2025-05-04 07:01:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:01:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:01:09 --> Utf8 Class Initialized
INFO - 2025-05-04 07:01:09 --> URI Class Initialized
INFO - 2025-05-04 07:01:09 --> Router Class Initialized
INFO - 2025-05-04 07:01:09 --> Output Class Initialized
INFO - 2025-05-04 07:01:09 --> Security Class Initialized
DEBUG - 2025-05-04 07:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:01:09 --> Input Class Initialized
INFO - 2025-05-04 07:01:09 --> Language Class Initialized
INFO - 2025-05-04 07:01:09 --> Loader Class Initialized
INFO - 2025-05-04 07:01:09 --> Helper loaded: url_helper
INFO - 2025-05-04 07:01:09 --> Helper loaded: string_helper
INFO - 2025-05-04 07:01:09 --> Helper loaded: form_helper
INFO - 2025-05-04 07:01:09 --> Helper loaded: file_helper
INFO - 2025-05-04 07:01:09 --> Helper loaded: html_helper
INFO - 2025-05-04 07:01:10 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:01:10 --> Controller Class Initialized
INFO - 2025-05-04 15:01:10 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:03:25 --> Config Class Initialized
INFO - 2025-05-04 07:03:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:03:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:03:25 --> Utf8 Class Initialized
INFO - 2025-05-04 07:03:25 --> URI Class Initialized
DEBUG - 2025-05-04 07:03:25 --> No URI present. Default controller set.
INFO - 2025-05-04 07:03:25 --> Router Class Initialized
INFO - 2025-05-04 07:03:25 --> Output Class Initialized
INFO - 2025-05-04 07:03:25 --> Security Class Initialized
DEBUG - 2025-05-04 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:03:25 --> Input Class Initialized
INFO - 2025-05-04 07:03:25 --> Language Class Initialized
INFO - 2025-05-04 07:03:25 --> Loader Class Initialized
INFO - 2025-05-04 07:03:25 --> Helper loaded: url_helper
INFO - 2025-05-04 07:03:25 --> Helper loaded: string_helper
INFO - 2025-05-04 07:03:25 --> Helper loaded: form_helper
INFO - 2025-05-04 07:03:25 --> Helper loaded: file_helper
INFO - 2025-05-04 07:03:25 --> Helper loaded: html_helper
INFO - 2025-05-04 07:03:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:03:25 --> Controller Class Initialized
INFO - 2025-05-04 07:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 07:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 07:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 07:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 07:03:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 07:03:25 --> Final output sent to browser
DEBUG - 2025-05-04 07:03:25 --> Total execution time: 0.3617
INFO - 2025-05-04 07:03:41 --> Config Class Initialized
INFO - 2025-05-04 07:03:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:03:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:03:41 --> Utf8 Class Initialized
INFO - 2025-05-04 07:03:41 --> URI Class Initialized
INFO - 2025-05-04 07:03:41 --> Router Class Initialized
INFO - 2025-05-04 07:03:41 --> Output Class Initialized
INFO - 2025-05-04 07:03:41 --> Security Class Initialized
DEBUG - 2025-05-04 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:03:41 --> Input Class Initialized
INFO - 2025-05-04 07:03:41 --> Language Class Initialized
INFO - 2025-05-04 07:03:41 --> Loader Class Initialized
INFO - 2025-05-04 07:03:41 --> Helper loaded: url_helper
INFO - 2025-05-04 07:03:41 --> Helper loaded: string_helper
INFO - 2025-05-04 07:03:41 --> Helper loaded: form_helper
INFO - 2025-05-04 07:03:41 --> Helper loaded: file_helper
INFO - 2025-05-04 07:03:41 --> Helper loaded: html_helper
INFO - 2025-05-04 07:03:41 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:03:41 --> Controller Class Initialized
INFO - 2025-05-04 15:03:41 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:03:45 --> Config Class Initialized
INFO - 2025-05-04 07:03:45 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:03:45 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:03:45 --> Utf8 Class Initialized
INFO - 2025-05-04 07:03:45 --> URI Class Initialized
INFO - 2025-05-04 07:03:45 --> Router Class Initialized
INFO - 2025-05-04 07:03:45 --> Output Class Initialized
INFO - 2025-05-04 07:03:45 --> Security Class Initialized
DEBUG - 2025-05-04 07:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:03:45 --> Input Class Initialized
INFO - 2025-05-04 07:03:45 --> Language Class Initialized
INFO - 2025-05-04 07:03:46 --> Loader Class Initialized
INFO - 2025-05-04 07:03:46 --> Helper loaded: url_helper
INFO - 2025-05-04 07:03:46 --> Helper loaded: string_helper
INFO - 2025-05-04 07:03:46 --> Helper loaded: form_helper
INFO - 2025-05-04 07:03:46 --> Helper loaded: file_helper
INFO - 2025-05-04 07:03:46 --> Helper loaded: html_helper
INFO - 2025-05-04 07:03:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:03:46 --> Controller Class Initialized
INFO - 2025-05-04 15:03:46 --> Model "UserModel" initialized
ERROR - 2025-05-04 15:03:46 --> Severity: Warning --> Undefined array key "toName" C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 595
DEBUG - 2025-05-04 15:03:46 --> PHPMailer class is loaded.
INFO - 2025-05-04 15:03:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 15:03:52 --> Final output sent to browser
DEBUG - 2025-05-04 15:03:52 --> Total execution time: 6.5087
INFO - 2025-05-04 07:27:03 --> Config Class Initialized
INFO - 2025-05-04 07:27:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:27:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:27:03 --> Utf8 Class Initialized
INFO - 2025-05-04 07:27:03 --> URI Class Initialized
INFO - 2025-05-04 07:27:03 --> Router Class Initialized
INFO - 2025-05-04 07:27:03 --> Output Class Initialized
INFO - 2025-05-04 07:27:04 --> Security Class Initialized
DEBUG - 2025-05-04 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:27:04 --> Input Class Initialized
INFO - 2025-05-04 07:27:04 --> Language Class Initialized
INFO - 2025-05-04 07:27:04 --> Loader Class Initialized
INFO - 2025-05-04 07:27:04 --> Helper loaded: url_helper
INFO - 2025-05-04 07:27:05 --> Helper loaded: string_helper
INFO - 2025-05-04 07:27:05 --> Helper loaded: form_helper
INFO - 2025-05-04 07:27:05 --> Helper loaded: file_helper
INFO - 2025-05-04 07:27:05 --> Helper loaded: html_helper
INFO - 2025-05-04 07:27:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:27:06 --> Controller Class Initialized
INFO - 2025-05-04 15:27:07 --> Model "UserModel" initialized
DEBUG - 2025-05-04 15:27:07 --> PHPMailer class is loaded.
INFO - 2025-05-04 15:27:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 15:27:13 --> Final output sent to browser
DEBUG - 2025-05-04 15:27:13 --> Total execution time: 10.7922
INFO - 2025-05-04 07:28:39 --> Config Class Initialized
INFO - 2025-05-04 07:28:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:28:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:28:39 --> Utf8 Class Initialized
INFO - 2025-05-04 07:28:39 --> URI Class Initialized
DEBUG - 2025-05-04 07:28:39 --> No URI present. Default controller set.
INFO - 2025-05-04 07:28:39 --> Router Class Initialized
INFO - 2025-05-04 07:28:39 --> Output Class Initialized
INFO - 2025-05-04 07:28:39 --> Security Class Initialized
DEBUG - 2025-05-04 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:28:39 --> Input Class Initialized
INFO - 2025-05-04 07:28:39 --> Language Class Initialized
INFO - 2025-05-04 07:28:39 --> Loader Class Initialized
INFO - 2025-05-04 07:28:39 --> Helper loaded: url_helper
INFO - 2025-05-04 07:28:39 --> Helper loaded: string_helper
INFO - 2025-05-04 07:28:39 --> Helper loaded: form_helper
INFO - 2025-05-04 07:28:39 --> Helper loaded: file_helper
INFO - 2025-05-04 07:28:39 --> Helper loaded: html_helper
INFO - 2025-05-04 07:28:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:28:39 --> Controller Class Initialized
INFO - 2025-05-04 07:28:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 07:28:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 07:28:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 07:28:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 07:28:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 07:28:39 --> Final output sent to browser
DEBUG - 2025-05-04 07:28:39 --> Total execution time: 0.5809
INFO - 2025-05-04 07:28:47 --> Config Class Initialized
INFO - 2025-05-04 07:28:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:28:47 --> Utf8 Class Initialized
INFO - 2025-05-04 07:28:47 --> URI Class Initialized
INFO - 2025-05-04 07:28:47 --> Router Class Initialized
INFO - 2025-05-04 07:28:47 --> Output Class Initialized
INFO - 2025-05-04 07:28:47 --> Security Class Initialized
DEBUG - 2025-05-04 07:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:28:47 --> Input Class Initialized
INFO - 2025-05-04 07:28:47 --> Language Class Initialized
INFO - 2025-05-04 07:28:47 --> Loader Class Initialized
INFO - 2025-05-04 07:28:47 --> Helper loaded: url_helper
INFO - 2025-05-04 07:28:47 --> Helper loaded: string_helper
INFO - 2025-05-04 07:28:47 --> Helper loaded: form_helper
INFO - 2025-05-04 07:28:47 --> Helper loaded: file_helper
INFO - 2025-05-04 07:28:47 --> Helper loaded: html_helper
INFO - 2025-05-04 07:28:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:28:47 --> Controller Class Initialized
INFO - 2025-05-04 15:28:48 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:28:57 --> Config Class Initialized
INFO - 2025-05-04 07:28:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:28:57 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:28:57 --> Utf8 Class Initialized
INFO - 2025-05-04 07:28:57 --> URI Class Initialized
INFO - 2025-05-04 07:28:57 --> Router Class Initialized
INFO - 2025-05-04 07:28:57 --> Output Class Initialized
INFO - 2025-05-04 07:28:57 --> Security Class Initialized
DEBUG - 2025-05-04 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:28:57 --> Input Class Initialized
INFO - 2025-05-04 07:28:57 --> Language Class Initialized
INFO - 2025-05-04 07:28:57 --> Loader Class Initialized
INFO - 2025-05-04 07:28:57 --> Helper loaded: url_helper
INFO - 2025-05-04 07:28:57 --> Helper loaded: string_helper
INFO - 2025-05-04 07:28:58 --> Helper loaded: form_helper
INFO - 2025-05-04 07:28:58 --> Helper loaded: file_helper
INFO - 2025-05-04 07:28:58 --> Helper loaded: html_helper
INFO - 2025-05-04 07:28:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:28:58 --> Controller Class Initialized
INFO - 2025-05-04 15:28:58 --> Model "UserModel" initialized
DEBUG - 2025-05-04 15:28:58 --> PHPMailer class is loaded.
INFO - 2025-05-04 15:28:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 15:29:07 --> Final output sent to browser
DEBUG - 2025-05-04 15:29:07 --> Total execution time: 9.9456
INFO - 2025-05-04 07:29:40 --> Config Class Initialized
INFO - 2025-05-04 07:29:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:29:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:29:40 --> Utf8 Class Initialized
INFO - 2025-05-04 07:29:40 --> URI Class Initialized
INFO - 2025-05-04 07:29:40 --> Router Class Initialized
INFO - 2025-05-04 07:29:40 --> Output Class Initialized
INFO - 2025-05-04 07:29:40 --> Security Class Initialized
DEBUG - 2025-05-04 07:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:29:40 --> Input Class Initialized
INFO - 2025-05-04 07:29:40 --> Language Class Initialized
INFO - 2025-05-04 07:29:40 --> Loader Class Initialized
INFO - 2025-05-04 07:29:40 --> Helper loaded: url_helper
INFO - 2025-05-04 07:29:40 --> Helper loaded: string_helper
INFO - 2025-05-04 07:29:40 --> Helper loaded: form_helper
INFO - 2025-05-04 07:29:40 --> Helper loaded: file_helper
INFO - 2025-05-04 07:29:40 --> Helper loaded: html_helper
INFO - 2025-05-04 07:29:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:29:40 --> Controller Class Initialized
INFO - 2025-05-04 15:29:40 --> Model "UserModel" initialized
DEBUG - 2025-05-04 15:29:40 --> PHPMailer class is loaded.
INFO - 2025-05-04 15:29:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 15:29:45 --> Final output sent to browser
DEBUG - 2025-05-04 15:29:45 --> Total execution time: 4.9651
INFO - 2025-05-04 07:29:46 --> Config Class Initialized
INFO - 2025-05-04 07:29:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:29:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:29:46 --> Utf8 Class Initialized
INFO - 2025-05-04 07:29:46 --> URI Class Initialized
DEBUG - 2025-05-04 07:29:46 --> No URI present. Default controller set.
INFO - 2025-05-04 07:29:46 --> Router Class Initialized
INFO - 2025-05-04 07:29:46 --> Output Class Initialized
INFO - 2025-05-04 07:29:46 --> Security Class Initialized
DEBUG - 2025-05-04 07:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:29:46 --> Input Class Initialized
INFO - 2025-05-04 07:29:46 --> Language Class Initialized
INFO - 2025-05-04 07:29:46 --> Loader Class Initialized
INFO - 2025-05-04 07:29:46 --> Helper loaded: url_helper
INFO - 2025-05-04 07:29:46 --> Helper loaded: string_helper
INFO - 2025-05-04 07:29:46 --> Helper loaded: form_helper
INFO - 2025-05-04 07:29:46 --> Helper loaded: file_helper
INFO - 2025-05-04 07:29:46 --> Helper loaded: html_helper
INFO - 2025-05-04 07:29:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:29:46 --> Controller Class Initialized
INFO - 2025-05-04 07:29:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 07:29:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 07:29:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 07:29:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 07:29:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 07:29:46 --> Final output sent to browser
DEBUG - 2025-05-04 07:29:46 --> Total execution time: 0.1261
INFO - 2025-05-04 07:29:47 --> Config Class Initialized
INFO - 2025-05-04 07:29:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:29:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:29:47 --> Utf8 Class Initialized
INFO - 2025-05-04 07:29:47 --> URI Class Initialized
INFO - 2025-05-04 07:29:47 --> Router Class Initialized
INFO - 2025-05-04 07:29:47 --> Output Class Initialized
INFO - 2025-05-04 07:29:47 --> Security Class Initialized
DEBUG - 2025-05-04 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:29:47 --> Input Class Initialized
INFO - 2025-05-04 07:29:47 --> Language Class Initialized
INFO - 2025-05-04 07:29:47 --> Loader Class Initialized
INFO - 2025-05-04 07:29:47 --> Helper loaded: url_helper
INFO - 2025-05-04 07:29:47 --> Helper loaded: string_helper
INFO - 2025-05-04 07:29:47 --> Helper loaded: form_helper
INFO - 2025-05-04 07:29:47 --> Helper loaded: file_helper
INFO - 2025-05-04 07:29:47 --> Helper loaded: html_helper
INFO - 2025-05-04 07:29:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:29:47 --> Controller Class Initialized
INFO - 2025-05-04 15:29:47 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:30:00 --> Config Class Initialized
INFO - 2025-05-04 07:30:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:30:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:30:00 --> Utf8 Class Initialized
INFO - 2025-05-04 07:30:00 --> URI Class Initialized
DEBUG - 2025-05-04 07:30:00 --> No URI present. Default controller set.
INFO - 2025-05-04 07:30:00 --> Router Class Initialized
INFO - 2025-05-04 07:30:00 --> Output Class Initialized
INFO - 2025-05-04 07:30:00 --> Security Class Initialized
DEBUG - 2025-05-04 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:30:00 --> Input Class Initialized
INFO - 2025-05-04 07:30:00 --> Language Class Initialized
INFO - 2025-05-04 07:30:00 --> Loader Class Initialized
INFO - 2025-05-04 07:30:00 --> Helper loaded: url_helper
INFO - 2025-05-04 07:30:00 --> Helper loaded: string_helper
INFO - 2025-05-04 07:30:00 --> Helper loaded: form_helper
INFO - 2025-05-04 07:30:00 --> Helper loaded: file_helper
INFO - 2025-05-04 07:30:00 --> Helper loaded: html_helper
INFO - 2025-05-04 07:30:00 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:30:00 --> Controller Class Initialized
INFO - 2025-05-04 07:30:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 07:30:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 07:30:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 07:30:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 07:30:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 07:30:00 --> Final output sent to browser
DEBUG - 2025-05-04 07:30:01 --> Total execution time: 0.1590
INFO - 2025-05-04 07:30:06 --> Config Class Initialized
INFO - 2025-05-04 07:30:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:30:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:30:06 --> Utf8 Class Initialized
INFO - 2025-05-04 07:30:06 --> URI Class Initialized
INFO - 2025-05-04 07:30:06 --> Router Class Initialized
INFO - 2025-05-04 07:30:06 --> Output Class Initialized
INFO - 2025-05-04 07:30:06 --> Security Class Initialized
DEBUG - 2025-05-04 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:30:06 --> Input Class Initialized
INFO - 2025-05-04 07:30:06 --> Language Class Initialized
INFO - 2025-05-04 07:30:06 --> Loader Class Initialized
INFO - 2025-05-04 07:30:06 --> Helper loaded: url_helper
INFO - 2025-05-04 07:30:06 --> Helper loaded: string_helper
INFO - 2025-05-04 07:30:06 --> Helper loaded: form_helper
INFO - 2025-05-04 07:30:06 --> Helper loaded: file_helper
INFO - 2025-05-04 07:30:06 --> Helper loaded: html_helper
INFO - 2025-05-04 07:30:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:30:07 --> Controller Class Initialized
INFO - 2025-05-04 15:30:07 --> Model "AuctionModel" initialized
INFO - 2025-05-04 07:30:14 --> Config Class Initialized
INFO - 2025-05-04 07:30:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:30:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:30:14 --> Utf8 Class Initialized
INFO - 2025-05-04 07:30:14 --> URI Class Initialized
INFO - 2025-05-04 07:30:14 --> Router Class Initialized
INFO - 2025-05-04 07:30:14 --> Output Class Initialized
INFO - 2025-05-04 07:30:14 --> Security Class Initialized
DEBUG - 2025-05-04 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:30:14 --> Input Class Initialized
INFO - 2025-05-04 07:30:14 --> Language Class Initialized
INFO - 2025-05-04 07:30:14 --> Loader Class Initialized
INFO - 2025-05-04 07:30:14 --> Helper loaded: url_helper
INFO - 2025-05-04 07:30:14 --> Helper loaded: string_helper
INFO - 2025-05-04 07:30:14 --> Helper loaded: form_helper
INFO - 2025-05-04 07:30:14 --> Helper loaded: file_helper
INFO - 2025-05-04 07:30:14 --> Helper loaded: html_helper
INFO - 2025-05-04 07:30:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:30:14 --> Controller Class Initialized
INFO - 2025-05-04 15:30:14 --> Model "UserModel" initialized
DEBUG - 2025-05-04 15:30:14 --> PHPMailer class is loaded.
INFO - 2025-05-04 15:30:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 15:30:17 --> Final output sent to browser
DEBUG - 2025-05-04 15:30:17 --> Total execution time: 3.5273
INFO - 2025-05-04 07:30:30 --> Config Class Initialized
INFO - 2025-05-04 07:30:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:30:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:30:30 --> Utf8 Class Initialized
INFO - 2025-05-04 07:30:30 --> URI Class Initialized
INFO - 2025-05-04 07:30:30 --> Router Class Initialized
INFO - 2025-05-04 07:30:30 --> Output Class Initialized
INFO - 2025-05-04 07:30:30 --> Security Class Initialized
DEBUG - 2025-05-04 07:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:30:30 --> Input Class Initialized
INFO - 2025-05-04 07:30:30 --> Language Class Initialized
INFO - 2025-05-04 07:30:30 --> Loader Class Initialized
INFO - 2025-05-04 07:30:30 --> Helper loaded: url_helper
INFO - 2025-05-04 07:30:30 --> Helper loaded: string_helper
INFO - 2025-05-04 07:30:30 --> Helper loaded: form_helper
INFO - 2025-05-04 07:30:30 --> Helper loaded: file_helper
INFO - 2025-05-04 07:30:30 --> Helper loaded: html_helper
INFO - 2025-05-04 07:30:30 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:30:30 --> Controller Class Initialized
INFO - 2025-05-04 15:30:30 --> Model "UserModel" initialized
ERROR - 2025-05-04 15:30:30 --> Query error: Table 'db_storage_auctions.user_activation_token' doesn't exist - Invalid query: SELECT *
FROM `user_activation_token`
WHERE `token` = '71d050b6480344ef9ce77616377750e5c234431c82ee63cb91a2e43ed3fdc93e'
AND `token_activation_type_id` = 2
INFO - 2025-05-04 15:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-04 07:31:58 --> Config Class Initialized
INFO - 2025-05-04 07:31:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:31:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:31:58 --> Utf8 Class Initialized
INFO - 2025-05-04 07:31:58 --> URI Class Initialized
INFO - 2025-05-04 07:31:58 --> Router Class Initialized
INFO - 2025-05-04 07:31:58 --> Output Class Initialized
INFO - 2025-05-04 07:31:58 --> Security Class Initialized
DEBUG - 2025-05-04 07:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:31:58 --> Input Class Initialized
INFO - 2025-05-04 07:31:58 --> Language Class Initialized
INFO - 2025-05-04 07:31:58 --> Loader Class Initialized
INFO - 2025-05-04 07:31:58 --> Helper loaded: url_helper
INFO - 2025-05-04 07:31:58 --> Helper loaded: string_helper
INFO - 2025-05-04 07:31:58 --> Helper loaded: form_helper
INFO - 2025-05-04 07:31:58 --> Helper loaded: file_helper
INFO - 2025-05-04 07:31:58 --> Helper loaded: html_helper
INFO - 2025-05-04 07:31:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:31:58 --> Controller Class Initialized
INFO - 2025-05-04 15:31:58 --> Model "UserModel" initialized
INFO - 2025-05-04 15:31:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-04 15:31:58 --> Final output sent to browser
DEBUG - 2025-05-04 15:31:58 --> Total execution time: 0.2270
INFO - 2025-05-04 07:32:04 --> Config Class Initialized
INFO - 2025-05-04 07:32:04 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:32:04 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:32:04 --> Utf8 Class Initialized
INFO - 2025-05-04 07:32:04 --> URI Class Initialized
INFO - 2025-05-04 07:32:04 --> Router Class Initialized
INFO - 2025-05-04 07:32:04 --> Output Class Initialized
INFO - 2025-05-04 07:32:04 --> Security Class Initialized
DEBUG - 2025-05-04 07:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:32:04 --> Input Class Initialized
INFO - 2025-05-04 07:32:04 --> Language Class Initialized
INFO - 2025-05-04 07:32:04 --> Loader Class Initialized
INFO - 2025-05-04 07:32:04 --> Helper loaded: url_helper
INFO - 2025-05-04 07:32:04 --> Helper loaded: string_helper
INFO - 2025-05-04 07:32:04 --> Helper loaded: form_helper
INFO - 2025-05-04 07:32:04 --> Helper loaded: file_helper
INFO - 2025-05-04 07:32:04 --> Helper loaded: html_helper
INFO - 2025-05-04 07:32:04 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:32:04 --> Controller Class Initialized
INFO - 2025-05-04 15:32:04 --> Model "UserModel" initialized
INFO - 2025-05-04 15:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-04 15:32:04 --> Final output sent to browser
DEBUG - 2025-05-04 15:32:04 --> Total execution time: 0.2204
INFO - 2025-05-04 07:32:32 --> Config Class Initialized
INFO - 2025-05-04 07:32:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:32:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:32:32 --> Utf8 Class Initialized
INFO - 2025-05-04 07:32:32 --> URI Class Initialized
INFO - 2025-05-04 07:32:32 --> Router Class Initialized
INFO - 2025-05-04 07:32:32 --> Output Class Initialized
INFO - 2025-05-04 07:32:32 --> Security Class Initialized
DEBUG - 2025-05-04 07:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:32:32 --> Input Class Initialized
INFO - 2025-05-04 07:32:32 --> Language Class Initialized
INFO - 2025-05-04 07:32:32 --> Loader Class Initialized
INFO - 2025-05-04 07:32:32 --> Helper loaded: url_helper
INFO - 2025-05-04 07:32:32 --> Helper loaded: string_helper
INFO - 2025-05-04 07:32:32 --> Helper loaded: form_helper
INFO - 2025-05-04 07:32:32 --> Helper loaded: file_helper
INFO - 2025-05-04 07:32:32 --> Helper loaded: html_helper
INFO - 2025-05-04 07:32:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:32:32 --> Controller Class Initialized
INFO - 2025-05-04 15:32:32 --> Model "UserModel" initialized
INFO - 2025-05-04 15:32:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-04 15:32:32 --> Final output sent to browser
DEBUG - 2025-05-04 15:32:32 --> Total execution time: 0.4904
INFO - 2025-05-04 07:32:44 --> Config Class Initialized
INFO - 2025-05-04 07:32:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:32:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:32:44 --> Utf8 Class Initialized
INFO - 2025-05-04 07:32:44 --> URI Class Initialized
INFO - 2025-05-04 07:32:44 --> Router Class Initialized
INFO - 2025-05-04 07:32:44 --> Output Class Initialized
INFO - 2025-05-04 07:32:44 --> Security Class Initialized
DEBUG - 2025-05-04 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:32:44 --> Input Class Initialized
INFO - 2025-05-04 07:32:44 --> Language Class Initialized
ERROR - 2025-05-04 07:32:44 --> Severity: error --> Exception: syntax error, unexpected identifier "time" C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1444
INFO - 2025-05-04 07:32:53 --> Config Class Initialized
INFO - 2025-05-04 07:32:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:32:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:32:53 --> Utf8 Class Initialized
INFO - 2025-05-04 07:32:53 --> URI Class Initialized
INFO - 2025-05-04 07:32:53 --> Router Class Initialized
INFO - 2025-05-04 07:32:53 --> Output Class Initialized
INFO - 2025-05-04 07:32:54 --> Security Class Initialized
DEBUG - 2025-05-04 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:32:54 --> Input Class Initialized
INFO - 2025-05-04 07:32:54 --> Language Class Initialized
INFO - 2025-05-04 07:32:54 --> Loader Class Initialized
INFO - 2025-05-04 07:32:54 --> Helper loaded: url_helper
INFO - 2025-05-04 07:32:54 --> Helper loaded: string_helper
INFO - 2025-05-04 07:32:54 --> Helper loaded: form_helper
INFO - 2025-05-04 07:32:54 --> Helper loaded: file_helper
INFO - 2025-05-04 07:32:54 --> Helper loaded: html_helper
INFO - 2025-05-04 07:32:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:32:54 --> Controller Class Initialized
INFO - 2025-05-04 15:32:54 --> Model "UserModel" initialized
INFO - 2025-05-04 15:32:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/expired.php
INFO - 2025-05-04 15:32:54 --> Final output sent to browser
DEBUG - 2025-05-04 15:32:54 --> Total execution time: 0.5720
INFO - 2025-05-04 07:33:06 --> Config Class Initialized
INFO - 2025-05-04 07:33:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:33:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:33:06 --> Utf8 Class Initialized
INFO - 2025-05-04 07:33:06 --> URI Class Initialized
INFO - 2025-05-04 07:33:06 --> Router Class Initialized
INFO - 2025-05-04 07:33:06 --> Output Class Initialized
INFO - 2025-05-04 07:33:06 --> Security Class Initialized
DEBUG - 2025-05-04 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:33:06 --> Input Class Initialized
INFO - 2025-05-04 07:33:06 --> Language Class Initialized
INFO - 2025-05-04 07:33:07 --> Loader Class Initialized
INFO - 2025-05-04 07:33:07 --> Helper loaded: url_helper
INFO - 2025-05-04 07:33:07 --> Helper loaded: string_helper
INFO - 2025-05-04 07:33:07 --> Helper loaded: form_helper
INFO - 2025-05-04 07:33:07 --> Helper loaded: file_helper
INFO - 2025-05-04 07:33:07 --> Helper loaded: html_helper
INFO - 2025-05-04 07:33:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:33:07 --> Controller Class Initialized
INFO - 2025-05-04 15:33:07 --> Model "UserModel" initialized
INFO - 2025-05-04 15:33:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/success.php
INFO - 2025-05-04 15:33:07 --> Final output sent to browser
DEBUG - 2025-05-04 15:33:07 --> Total execution time: 0.3451
INFO - 2025-05-04 07:33:57 --> Config Class Initialized
INFO - 2025-05-04 07:33:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:33:57 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:33:57 --> Utf8 Class Initialized
INFO - 2025-05-04 07:33:57 --> URI Class Initialized
INFO - 2025-05-04 07:33:57 --> Router Class Initialized
INFO - 2025-05-04 07:33:57 --> Output Class Initialized
INFO - 2025-05-04 07:33:57 --> Security Class Initialized
DEBUG - 2025-05-04 07:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:33:57 --> Input Class Initialized
INFO - 2025-05-04 07:33:57 --> Language Class Initialized
INFO - 2025-05-04 07:33:57 --> Loader Class Initialized
INFO - 2025-05-04 07:33:57 --> Helper loaded: url_helper
INFO - 2025-05-04 07:33:57 --> Helper loaded: string_helper
INFO - 2025-05-04 07:33:57 --> Helper loaded: form_helper
INFO - 2025-05-04 07:33:57 --> Helper loaded: file_helper
INFO - 2025-05-04 07:33:57 --> Helper loaded: html_helper
INFO - 2025-05-04 07:33:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:33:58 --> Controller Class Initialized
INFO - 2025-05-04 15:33:58 --> Model "UserModel" initialized
INFO - 2025-05-04 15:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:33:58 --> Final output sent to browser
DEBUG - 2025-05-04 15:33:58 --> Total execution time: 0.3709
INFO - 2025-05-04 07:34:39 --> Config Class Initialized
INFO - 2025-05-04 07:34:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:34:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:34:39 --> Utf8 Class Initialized
INFO - 2025-05-04 07:34:39 --> URI Class Initialized
INFO - 2025-05-04 07:34:39 --> Router Class Initialized
INFO - 2025-05-04 07:34:39 --> Output Class Initialized
INFO - 2025-05-04 07:34:39 --> Security Class Initialized
DEBUG - 2025-05-04 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:34:39 --> Input Class Initialized
INFO - 2025-05-04 07:34:39 --> Language Class Initialized
INFO - 2025-05-04 07:34:40 --> Loader Class Initialized
INFO - 2025-05-04 07:34:40 --> Helper loaded: url_helper
INFO - 2025-05-04 07:34:40 --> Helper loaded: string_helper
INFO - 2025-05-04 07:34:40 --> Helper loaded: form_helper
INFO - 2025-05-04 07:34:40 --> Helper loaded: file_helper
INFO - 2025-05-04 07:34:40 --> Helper loaded: html_helper
INFO - 2025-05-04 07:34:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:34:40 --> Controller Class Initialized
INFO - 2025-05-04 15:34:40 --> Model "UserModel" initialized
INFO - 2025-05-04 15:34:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:34:40 --> Final output sent to browser
DEBUG - 2025-05-04 15:34:40 --> Total execution time: 0.4023
INFO - 2025-05-04 07:36:49 --> Config Class Initialized
INFO - 2025-05-04 07:36:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:36:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:36:49 --> Utf8 Class Initialized
INFO - 2025-05-04 07:36:49 --> URI Class Initialized
INFO - 2025-05-04 07:36:49 --> Router Class Initialized
INFO - 2025-05-04 07:36:49 --> Output Class Initialized
INFO - 2025-05-04 07:36:49 --> Security Class Initialized
DEBUG - 2025-05-04 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:36:49 --> Input Class Initialized
INFO - 2025-05-04 07:36:49 --> Language Class Initialized
INFO - 2025-05-04 07:36:49 --> Loader Class Initialized
INFO - 2025-05-04 07:36:49 --> Helper loaded: url_helper
INFO - 2025-05-04 07:36:49 --> Helper loaded: string_helper
INFO - 2025-05-04 07:36:49 --> Helper loaded: form_helper
INFO - 2025-05-04 07:36:49 --> Helper loaded: file_helper
INFO - 2025-05-04 07:36:49 --> Helper loaded: html_helper
INFO - 2025-05-04 07:36:49 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:36:49 --> Controller Class Initialized
INFO - 2025-05-04 15:36:49 --> Model "UserModel" initialized
INFO - 2025-05-04 15:36:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:36:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:36:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:36:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:36:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:36:49 --> Final output sent to browser
DEBUG - 2025-05-04 15:36:49 --> Total execution time: 0.5137
INFO - 2025-05-04 07:37:12 --> Config Class Initialized
INFO - 2025-05-04 07:37:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:37:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:37:12 --> Utf8 Class Initialized
INFO - 2025-05-04 07:37:12 --> URI Class Initialized
INFO - 2025-05-04 07:37:12 --> Router Class Initialized
INFO - 2025-05-04 07:37:12 --> Output Class Initialized
INFO - 2025-05-04 07:37:12 --> Security Class Initialized
DEBUG - 2025-05-04 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:37:12 --> Input Class Initialized
INFO - 2025-05-04 07:37:12 --> Language Class Initialized
INFO - 2025-05-04 07:37:12 --> Loader Class Initialized
INFO - 2025-05-04 07:37:12 --> Helper loaded: url_helper
INFO - 2025-05-04 07:37:12 --> Helper loaded: string_helper
INFO - 2025-05-04 07:37:12 --> Helper loaded: form_helper
INFO - 2025-05-04 07:37:12 --> Helper loaded: file_helper
INFO - 2025-05-04 07:37:12 --> Helper loaded: html_helper
INFO - 2025-05-04 07:37:12 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:37:12 --> Controller Class Initialized
INFO - 2025-05-04 15:37:12 --> Model "UserModel" initialized
INFO - 2025-05-04 15:37:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:37:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:37:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:37:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:37:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:37:12 --> Final output sent to browser
DEBUG - 2025-05-04 15:37:12 --> Total execution time: 0.2581
INFO - 2025-05-04 07:37:55 --> Config Class Initialized
INFO - 2025-05-04 07:37:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:37:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:37:55 --> Utf8 Class Initialized
INFO - 2025-05-04 07:37:55 --> URI Class Initialized
INFO - 2025-05-04 07:37:55 --> Router Class Initialized
INFO - 2025-05-04 07:37:55 --> Output Class Initialized
INFO - 2025-05-04 07:37:55 --> Security Class Initialized
DEBUG - 2025-05-04 07:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:37:55 --> Input Class Initialized
INFO - 2025-05-04 07:37:55 --> Language Class Initialized
INFO - 2025-05-04 07:37:55 --> Loader Class Initialized
INFO - 2025-05-04 07:37:55 --> Helper loaded: url_helper
INFO - 2025-05-04 07:37:55 --> Helper loaded: string_helper
INFO - 2025-05-04 07:37:55 --> Helper loaded: form_helper
INFO - 2025-05-04 07:37:55 --> Helper loaded: file_helper
INFO - 2025-05-04 07:37:55 --> Helper loaded: html_helper
INFO - 2025-05-04 07:37:55 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:37:55 --> Controller Class Initialized
INFO - 2025-05-04 15:37:55 --> Model "UserModel" initialized
INFO - 2025-05-04 15:37:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:37:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:37:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:37:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:37:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:37:55 --> Final output sent to browser
DEBUG - 2025-05-04 15:37:55 --> Total execution time: 0.3031
INFO - 2025-05-04 07:38:31 --> Config Class Initialized
INFO - 2025-05-04 07:38:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:38:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:38:31 --> Utf8 Class Initialized
INFO - 2025-05-04 07:38:31 --> URI Class Initialized
INFO - 2025-05-04 07:38:31 --> Router Class Initialized
INFO - 2025-05-04 07:38:31 --> Output Class Initialized
INFO - 2025-05-04 07:38:31 --> Security Class Initialized
DEBUG - 2025-05-04 07:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:38:31 --> Input Class Initialized
INFO - 2025-05-04 07:38:31 --> Language Class Initialized
INFO - 2025-05-04 07:38:31 --> Loader Class Initialized
INFO - 2025-05-04 07:38:31 --> Helper loaded: url_helper
INFO - 2025-05-04 07:38:31 --> Helper loaded: string_helper
INFO - 2025-05-04 07:38:31 --> Helper loaded: form_helper
INFO - 2025-05-04 07:38:31 --> Helper loaded: file_helper
INFO - 2025-05-04 07:38:31 --> Helper loaded: html_helper
INFO - 2025-05-04 07:38:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:38:31 --> Controller Class Initialized
INFO - 2025-05-04 15:38:31 --> Model "UserModel" initialized
INFO - 2025-05-04 15:38:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:38:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:38:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:38:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:38:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:38:31 --> Final output sent to browser
DEBUG - 2025-05-04 15:38:31 --> Total execution time: 0.2225
INFO - 2025-05-04 07:38:54 --> Config Class Initialized
INFO - 2025-05-04 07:38:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:38:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:38:54 --> Utf8 Class Initialized
INFO - 2025-05-04 07:38:54 --> URI Class Initialized
INFO - 2025-05-04 07:38:54 --> Router Class Initialized
INFO - 2025-05-04 07:38:54 --> Output Class Initialized
INFO - 2025-05-04 07:38:54 --> Security Class Initialized
DEBUG - 2025-05-04 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:38:54 --> Input Class Initialized
INFO - 2025-05-04 07:38:54 --> Language Class Initialized
INFO - 2025-05-04 07:38:54 --> Loader Class Initialized
INFO - 2025-05-04 07:38:54 --> Helper loaded: url_helper
INFO - 2025-05-04 07:38:54 --> Helper loaded: string_helper
INFO - 2025-05-04 07:38:54 --> Helper loaded: form_helper
INFO - 2025-05-04 07:38:54 --> Helper loaded: file_helper
INFO - 2025-05-04 07:38:54 --> Helper loaded: html_helper
INFO - 2025-05-04 07:38:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:38:54 --> Controller Class Initialized
INFO - 2025-05-04 15:38:54 --> Model "UserModel" initialized
INFO - 2025-05-04 15:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:38:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:38:54 --> Final output sent to browser
DEBUG - 2025-05-04 15:38:54 --> Total execution time: 0.2916
INFO - 2025-05-04 07:39:03 --> Config Class Initialized
INFO - 2025-05-04 07:39:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:39:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:39:03 --> Utf8 Class Initialized
INFO - 2025-05-04 07:39:03 --> URI Class Initialized
INFO - 2025-05-04 07:39:03 --> Router Class Initialized
INFO - 2025-05-04 07:39:03 --> Output Class Initialized
INFO - 2025-05-04 07:39:03 --> Security Class Initialized
DEBUG - 2025-05-04 07:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:39:03 --> Input Class Initialized
INFO - 2025-05-04 07:39:03 --> Language Class Initialized
INFO - 2025-05-04 07:39:03 --> Loader Class Initialized
INFO - 2025-05-04 07:39:03 --> Helper loaded: url_helper
INFO - 2025-05-04 07:39:03 --> Helper loaded: string_helper
INFO - 2025-05-04 07:39:03 --> Helper loaded: form_helper
INFO - 2025-05-04 07:39:03 --> Helper loaded: file_helper
INFO - 2025-05-04 07:39:03 --> Helper loaded: html_helper
INFO - 2025-05-04 07:39:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:39:03 --> Controller Class Initialized
INFO - 2025-05-04 15:39:03 --> Model "UserModel" initialized
INFO - 2025-05-04 15:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:39:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:39:03 --> Final output sent to browser
DEBUG - 2025-05-04 15:39:03 --> Total execution time: 0.2027
INFO - 2025-05-04 07:39:31 --> Config Class Initialized
INFO - 2025-05-04 07:39:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:39:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:39:31 --> Utf8 Class Initialized
INFO - 2025-05-04 07:39:31 --> URI Class Initialized
INFO - 2025-05-04 07:39:31 --> Router Class Initialized
INFO - 2025-05-04 07:39:31 --> Output Class Initialized
INFO - 2025-05-04 07:39:31 --> Security Class Initialized
DEBUG - 2025-05-04 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:39:31 --> Input Class Initialized
INFO - 2025-05-04 07:39:31 --> Language Class Initialized
INFO - 2025-05-04 07:39:31 --> Loader Class Initialized
INFO - 2025-05-04 07:39:31 --> Helper loaded: url_helper
INFO - 2025-05-04 07:39:31 --> Helper loaded: string_helper
INFO - 2025-05-04 07:39:31 --> Helper loaded: form_helper
INFO - 2025-05-04 07:39:31 --> Helper loaded: file_helper
INFO - 2025-05-04 07:39:31 --> Helper loaded: html_helper
INFO - 2025-05-04 07:39:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:39:31 --> Controller Class Initialized
INFO - 2025-05-04 15:39:31 --> Model "UserModel" initialized
INFO - 2025-05-04 15:39:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:39:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:39:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:39:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:39:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:39:31 --> Final output sent to browser
DEBUG - 2025-05-04 15:39:31 --> Total execution time: 0.3387
INFO - 2025-05-04 07:39:52 --> Config Class Initialized
INFO - 2025-05-04 07:39:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:39:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:39:52 --> Utf8 Class Initialized
INFO - 2025-05-04 07:39:52 --> URI Class Initialized
INFO - 2025-05-04 07:39:52 --> Router Class Initialized
INFO - 2025-05-04 07:39:52 --> Output Class Initialized
INFO - 2025-05-04 07:39:52 --> Security Class Initialized
DEBUG - 2025-05-04 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:39:52 --> Input Class Initialized
INFO - 2025-05-04 07:39:52 --> Language Class Initialized
INFO - 2025-05-04 07:39:52 --> Loader Class Initialized
INFO - 2025-05-04 07:39:52 --> Helper loaded: url_helper
INFO - 2025-05-04 07:39:52 --> Helper loaded: string_helper
INFO - 2025-05-04 07:39:52 --> Helper loaded: form_helper
INFO - 2025-05-04 07:39:52 --> Helper loaded: file_helper
INFO - 2025-05-04 07:39:52 --> Helper loaded: html_helper
INFO - 2025-05-04 07:39:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:39:52 --> Controller Class Initialized
INFO - 2025-05-04 15:39:52 --> Model "UserModel" initialized
INFO - 2025-05-04 15:39:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:39:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:39:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:39:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:39:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:39:52 --> Final output sent to browser
DEBUG - 2025-05-04 15:39:52 --> Total execution time: 0.1380
INFO - 2025-05-04 07:40:04 --> Config Class Initialized
INFO - 2025-05-04 07:40:04 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:40:04 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:40:04 --> Utf8 Class Initialized
INFO - 2025-05-04 07:40:04 --> URI Class Initialized
INFO - 2025-05-04 07:40:04 --> Router Class Initialized
INFO - 2025-05-04 07:40:04 --> Output Class Initialized
INFO - 2025-05-04 07:40:04 --> Security Class Initialized
DEBUG - 2025-05-04 07:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:40:04 --> Input Class Initialized
INFO - 2025-05-04 07:40:04 --> Language Class Initialized
INFO - 2025-05-04 07:40:04 --> Loader Class Initialized
INFO - 2025-05-04 07:40:04 --> Helper loaded: url_helper
INFO - 2025-05-04 07:40:04 --> Helper loaded: string_helper
INFO - 2025-05-04 07:40:04 --> Helper loaded: form_helper
INFO - 2025-05-04 07:40:04 --> Helper loaded: file_helper
INFO - 2025-05-04 07:40:04 --> Helper loaded: html_helper
INFO - 2025-05-04 07:40:04 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:40:04 --> Controller Class Initialized
INFO - 2025-05-04 15:40:04 --> Model "UserModel" initialized
INFO - 2025-05-04 15:40:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:40:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:40:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:40:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:40:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:40:04 --> Final output sent to browser
DEBUG - 2025-05-04 15:40:04 --> Total execution time: 0.1158
INFO - 2025-05-04 07:45:14 --> Config Class Initialized
INFO - 2025-05-04 07:45:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:45:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:45:14 --> Utf8 Class Initialized
INFO - 2025-05-04 07:45:14 --> URI Class Initialized
INFO - 2025-05-04 07:45:14 --> Router Class Initialized
INFO - 2025-05-04 07:45:14 --> Output Class Initialized
INFO - 2025-05-04 07:45:14 --> Security Class Initialized
DEBUG - 2025-05-04 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:45:14 --> Input Class Initialized
INFO - 2025-05-04 07:45:14 --> Language Class Initialized
INFO - 2025-05-04 07:45:14 --> Loader Class Initialized
INFO - 2025-05-04 07:45:14 --> Helper loaded: url_helper
INFO - 2025-05-04 07:45:14 --> Helper loaded: string_helper
INFO - 2025-05-04 07:45:14 --> Helper loaded: form_helper
INFO - 2025-05-04 07:45:14 --> Helper loaded: file_helper
INFO - 2025-05-04 07:45:14 --> Helper loaded: html_helper
INFO - 2025-05-04 07:45:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:45:14 --> Controller Class Initialized
INFO - 2025-05-04 15:45:14 --> Model "UserModel" initialized
INFO - 2025-05-04 15:45:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:45:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:45:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:45:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:45:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:45:14 --> Final output sent to browser
DEBUG - 2025-05-04 15:45:14 --> Total execution time: 0.4127
INFO - 2025-05-04 07:51:25 --> Config Class Initialized
INFO - 2025-05-04 07:51:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:51:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:51:25 --> Utf8 Class Initialized
INFO - 2025-05-04 07:51:25 --> URI Class Initialized
INFO - 2025-05-04 07:51:25 --> Router Class Initialized
INFO - 2025-05-04 07:51:25 --> Output Class Initialized
INFO - 2025-05-04 07:51:25 --> Security Class Initialized
DEBUG - 2025-05-04 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:51:25 --> Input Class Initialized
INFO - 2025-05-04 07:51:25 --> Language Class Initialized
INFO - 2025-05-04 07:51:25 --> Loader Class Initialized
INFO - 2025-05-04 07:51:25 --> Helper loaded: url_helper
INFO - 2025-05-04 07:51:25 --> Helper loaded: string_helper
INFO - 2025-05-04 07:51:25 --> Helper loaded: form_helper
INFO - 2025-05-04 07:51:25 --> Helper loaded: file_helper
INFO - 2025-05-04 07:51:25 --> Helper loaded: html_helper
INFO - 2025-05-04 07:51:25 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:51:25 --> Controller Class Initialized
INFO - 2025-05-04 15:51:25 --> Model "UserModel" initialized
INFO - 2025-05-04 15:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:51:25 --> Final output sent to browser
DEBUG - 2025-05-04 15:51:25 --> Total execution time: 0.1612
INFO - 2025-05-04 07:54:13 --> Config Class Initialized
INFO - 2025-05-04 07:54:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:54:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:54:13 --> Utf8 Class Initialized
INFO - 2025-05-04 07:54:13 --> URI Class Initialized
INFO - 2025-05-04 07:54:13 --> Router Class Initialized
INFO - 2025-05-04 07:54:14 --> Output Class Initialized
INFO - 2025-05-04 07:54:14 --> Security Class Initialized
DEBUG - 2025-05-04 07:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:54:14 --> Input Class Initialized
INFO - 2025-05-04 07:54:14 --> Language Class Initialized
INFO - 2025-05-04 07:54:14 --> Loader Class Initialized
INFO - 2025-05-04 07:54:14 --> Helper loaded: url_helper
INFO - 2025-05-04 07:54:14 --> Helper loaded: string_helper
INFO - 2025-05-04 07:54:14 --> Helper loaded: form_helper
INFO - 2025-05-04 07:54:14 --> Helper loaded: file_helper
INFO - 2025-05-04 07:54:14 --> Helper loaded: html_helper
INFO - 2025-05-04 07:54:14 --> Database Driver Class Initialized
DEBUG - 2025-05-04 07:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 07:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:54:14 --> Controller Class Initialized
INFO - 2025-05-04 15:54:14 --> Model "UserModel" initialized
INFO - 2025-05-04 15:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 15:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 15:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 15:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 15:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 15:54:14 --> Final output sent to browser
DEBUG - 2025-05-04 15:54:14 --> Total execution time: 0.7033
INFO - 2025-05-04 08:18:36 --> Config Class Initialized
INFO - 2025-05-04 08:18:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:18:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:18:36 --> Utf8 Class Initialized
INFO - 2025-05-04 08:18:36 --> URI Class Initialized
INFO - 2025-05-04 08:18:36 --> Router Class Initialized
INFO - 2025-05-04 08:18:36 --> Output Class Initialized
INFO - 2025-05-04 08:18:36 --> Security Class Initialized
DEBUG - 2025-05-04 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:18:36 --> Input Class Initialized
INFO - 2025-05-04 08:18:36 --> Language Class Initialized
INFO - 2025-05-04 08:18:36 --> Loader Class Initialized
INFO - 2025-05-04 08:18:36 --> Helper loaded: url_helper
INFO - 2025-05-04 08:18:36 --> Helper loaded: string_helper
INFO - 2025-05-04 08:18:36 --> Helper loaded: form_helper
INFO - 2025-05-04 08:18:36 --> Helper loaded: file_helper
INFO - 2025-05-04 08:18:36 --> Helper loaded: html_helper
INFO - 2025-05-04 08:18:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:18:36 --> Controller Class Initialized
INFO - 2025-05-04 16:18:36 --> Model "UserModel" initialized
INFO - 2025-05-04 16:18:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:18:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:18:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:18:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:18:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:18:36 --> Final output sent to browser
DEBUG - 2025-05-04 16:18:36 --> Total execution time: 0.7128
INFO - 2025-05-04 08:19:18 --> Config Class Initialized
INFO - 2025-05-04 08:19:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:19:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:19:18 --> Utf8 Class Initialized
INFO - 2025-05-04 08:19:18 --> URI Class Initialized
INFO - 2025-05-04 08:19:18 --> Router Class Initialized
INFO - 2025-05-04 08:19:18 --> Output Class Initialized
INFO - 2025-05-04 08:19:18 --> Security Class Initialized
DEBUG - 2025-05-04 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:19:18 --> Input Class Initialized
INFO - 2025-05-04 08:19:18 --> Language Class Initialized
INFO - 2025-05-04 08:19:18 --> Loader Class Initialized
INFO - 2025-05-04 08:19:18 --> Helper loaded: url_helper
INFO - 2025-05-04 08:19:18 --> Helper loaded: string_helper
INFO - 2025-05-04 08:19:18 --> Helper loaded: form_helper
INFO - 2025-05-04 08:19:18 --> Helper loaded: file_helper
INFO - 2025-05-04 08:19:18 --> Helper loaded: html_helper
INFO - 2025-05-04 08:19:18 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:19:18 --> Controller Class Initialized
INFO - 2025-05-04 16:19:18 --> Model "UserModel" initialized
ERROR - 2025-05-04 16:19:18 --> Severity: error --> Exception: Call to undefined method Users::send() C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1593
INFO - 2025-05-04 08:31:05 --> Config Class Initialized
INFO - 2025-05-04 08:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:31:05 --> Utf8 Class Initialized
INFO - 2025-05-04 08:31:05 --> URI Class Initialized
INFO - 2025-05-04 08:31:05 --> Router Class Initialized
INFO - 2025-05-04 08:31:05 --> Output Class Initialized
INFO - 2025-05-04 08:31:05 --> Security Class Initialized
DEBUG - 2025-05-04 08:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:31:05 --> Input Class Initialized
INFO - 2025-05-04 08:31:05 --> Language Class Initialized
INFO - 2025-05-04 08:31:05 --> Loader Class Initialized
INFO - 2025-05-04 08:31:05 --> Helper loaded: url_helper
INFO - 2025-05-04 08:31:05 --> Helper loaded: string_helper
INFO - 2025-05-04 08:31:05 --> Helper loaded: form_helper
INFO - 2025-05-04 08:31:05 --> Helper loaded: file_helper
INFO - 2025-05-04 08:31:05 --> Helper loaded: html_helper
INFO - 2025-05-04 08:31:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:31:06 --> Controller Class Initialized
INFO - 2025-05-04 16:31:06 --> Model "UserModel" initialized
INFO - 2025-05-04 16:31:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:31:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:31:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:31:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:31:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:31:06 --> Final output sent to browser
DEBUG - 2025-05-04 16:31:06 --> Total execution time: 0.7828
INFO - 2025-05-04 08:31:24 --> Config Class Initialized
INFO - 2025-05-04 08:31:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:31:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:31:24 --> Utf8 Class Initialized
INFO - 2025-05-04 08:31:24 --> URI Class Initialized
INFO - 2025-05-04 08:31:24 --> Router Class Initialized
INFO - 2025-05-04 08:31:24 --> Output Class Initialized
INFO - 2025-05-04 08:31:24 --> Security Class Initialized
DEBUG - 2025-05-04 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:31:24 --> Input Class Initialized
INFO - 2025-05-04 08:31:24 --> Language Class Initialized
INFO - 2025-05-04 08:31:24 --> Loader Class Initialized
INFO - 2025-05-04 08:31:24 --> Helper loaded: url_helper
INFO - 2025-05-04 08:31:24 --> Helper loaded: string_helper
INFO - 2025-05-04 08:31:24 --> Helper loaded: form_helper
INFO - 2025-05-04 08:31:24 --> Helper loaded: file_helper
INFO - 2025-05-04 08:31:24 --> Helper loaded: html_helper
INFO - 2025-05-04 08:31:24 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:31:24 --> Controller Class Initialized
INFO - 2025-05-04 16:31:24 --> Model "UserModel" initialized
INFO - 2025-05-04 16:31:24 --> Final output sent to browser
DEBUG - 2025-05-04 16:31:24 --> Total execution time: 0.2405
INFO - 2025-05-04 08:35:28 --> Config Class Initialized
INFO - 2025-05-04 08:35:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:35:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:35:28 --> Utf8 Class Initialized
INFO - 2025-05-04 08:35:28 --> URI Class Initialized
INFO - 2025-05-04 08:35:28 --> Router Class Initialized
INFO - 2025-05-04 08:35:28 --> Output Class Initialized
INFO - 2025-05-04 08:35:28 --> Security Class Initialized
DEBUG - 2025-05-04 08:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:35:28 --> Input Class Initialized
INFO - 2025-05-04 08:35:28 --> Language Class Initialized
INFO - 2025-05-04 08:35:28 --> Loader Class Initialized
INFO - 2025-05-04 08:35:28 --> Helper loaded: url_helper
INFO - 2025-05-04 08:35:28 --> Helper loaded: string_helper
INFO - 2025-05-04 08:35:28 --> Helper loaded: form_helper
INFO - 2025-05-04 08:35:28 --> Helper loaded: file_helper
INFO - 2025-05-04 08:35:28 --> Helper loaded: html_helper
INFO - 2025-05-04 08:35:28 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:35:28 --> Controller Class Initialized
INFO - 2025-05-04 16:35:28 --> Model "UserModel" initialized
INFO - 2025-05-04 16:35:28 --> Final output sent to browser
DEBUG - 2025-05-04 16:35:28 --> Total execution time: 0.4983
INFO - 2025-05-04 08:35:28 --> Config Class Initialized
INFO - 2025-05-04 08:35:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:35:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:35:28 --> Utf8 Class Initialized
INFO - 2025-05-04 08:35:28 --> URI Class Initialized
INFO - 2025-05-04 08:35:28 --> Router Class Initialized
INFO - 2025-05-04 08:35:28 --> Output Class Initialized
INFO - 2025-05-04 08:35:28 --> Security Class Initialized
DEBUG - 2025-05-04 08:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:35:28 --> Input Class Initialized
INFO - 2025-05-04 08:35:28 --> Language Class Initialized
INFO - 2025-05-04 08:35:29 --> Loader Class Initialized
INFO - 2025-05-04 08:35:29 --> Helper loaded: url_helper
INFO - 2025-05-04 08:35:29 --> Helper loaded: string_helper
INFO - 2025-05-04 08:35:29 --> Helper loaded: form_helper
INFO - 2025-05-04 08:35:29 --> Helper loaded: file_helper
INFO - 2025-05-04 08:35:29 --> Helper loaded: html_helper
INFO - 2025-05-04 08:35:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:35:29 --> Controller Class Initialized
INFO - 2025-05-04 16:35:29 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:35:29 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:35:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/reset_password_success_email.php
INFO - 2025-05-04 08:35:31 --> Config Class Initialized
INFO - 2025-05-04 08:35:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:35:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:35:31 --> Utf8 Class Initialized
INFO - 2025-05-04 08:35:31 --> URI Class Initialized
DEBUG - 2025-05-04 08:35:31 --> No URI present. Default controller set.
INFO - 2025-05-04 08:35:31 --> Router Class Initialized
INFO - 2025-05-04 08:35:31 --> Output Class Initialized
INFO - 2025-05-04 08:35:31 --> Security Class Initialized
DEBUG - 2025-05-04 08:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:35:31 --> Input Class Initialized
INFO - 2025-05-04 08:35:31 --> Language Class Initialized
INFO - 2025-05-04 08:35:31 --> Loader Class Initialized
INFO - 2025-05-04 08:35:31 --> Helper loaded: url_helper
INFO - 2025-05-04 08:35:31 --> Helper loaded: string_helper
INFO - 2025-05-04 08:35:31 --> Helper loaded: form_helper
INFO - 2025-05-04 08:35:31 --> Helper loaded: file_helper
INFO - 2025-05-04 08:35:31 --> Helper loaded: html_helper
INFO - 2025-05-04 08:35:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 16:35:39 --> Final output sent to browser
DEBUG - 2025-05-04 16:35:39 --> Total execution time: 10.7181
INFO - 2025-05-04 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:35:39 --> Controller Class Initialized
INFO - 2025-05-04 08:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:35:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:35:39 --> Final output sent to browser
DEBUG - 2025-05-04 08:35:39 --> Total execution time: 8.3614
INFO - 2025-05-04 08:35:42 --> Config Class Initialized
INFO - 2025-05-04 08:35:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:35:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:35:42 --> Utf8 Class Initialized
INFO - 2025-05-04 08:35:42 --> URI Class Initialized
INFO - 2025-05-04 08:35:43 --> Helper loaded: url_helper
INFO - 2025-05-04 08:35:43 --> Helper loaded: string_helper
INFO - 2025-05-04 08:35:43 --> Helper loaded: form_helper
INFO - 2025-05-04 08:35:43 --> Helper loaded: file_helper
INFO - 2025-05-04 08:35:43 --> Helper loaded: html_helper
INFO - 2025-05-04 08:35:43 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:35:43 --> Controller Class Initialized
INFO - 2025-05-04 16:35:43 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:36:36 --> Config Class Initialized
INFO - 2025-05-04 08:36:36 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:36:36 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:36:36 --> Utf8 Class Initialized
INFO - 2025-05-04 08:36:36 --> URI Class Initialized
INFO - 2025-05-04 08:36:36 --> Router Class Initialized
INFO - 2025-05-04 08:36:36 --> Output Class Initialized
INFO - 2025-05-04 08:36:36 --> Security Class Initialized
DEBUG - 2025-05-04 08:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:36:36 --> Input Class Initialized
INFO - 2025-05-04 08:36:36 --> Language Class Initialized
INFO - 2025-05-04 08:36:36 --> Loader Class Initialized
INFO - 2025-05-04 08:36:36 --> Helper loaded: url_helper
INFO - 2025-05-04 08:36:36 --> Helper loaded: string_helper
INFO - 2025-05-04 08:36:36 --> Helper loaded: form_helper
INFO - 2025-05-04 08:36:36 --> Helper loaded: file_helper
INFO - 2025-05-04 08:36:36 --> Helper loaded: html_helper
INFO - 2025-05-04 08:36:36 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:36:36 --> Controller Class Initialized
INFO - 2025-05-04 16:36:36 --> Model "UserModel" initialized
INFO - 2025-05-04 16:36:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:36:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:36:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:36:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:36:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:36:36 --> Final output sent to browser
DEBUG - 2025-05-04 16:36:36 --> Total execution time: 0.1524
INFO - 2025-05-04 08:37:19 --> Config Class Initialized
INFO - 2025-05-04 08:37:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:37:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:37:19 --> Utf8 Class Initialized
INFO - 2025-05-04 08:37:19 --> URI Class Initialized
INFO - 2025-05-04 08:37:19 --> Router Class Initialized
INFO - 2025-05-04 08:37:19 --> Output Class Initialized
INFO - 2025-05-04 08:37:19 --> Security Class Initialized
DEBUG - 2025-05-04 08:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:37:19 --> Input Class Initialized
INFO - 2025-05-04 08:37:19 --> Language Class Initialized
INFO - 2025-05-04 08:37:19 --> Loader Class Initialized
INFO - 2025-05-04 08:37:19 --> Helper loaded: url_helper
INFO - 2025-05-04 08:37:19 --> Helper loaded: string_helper
INFO - 2025-05-04 08:37:19 --> Helper loaded: form_helper
INFO - 2025-05-04 08:37:19 --> Helper loaded: file_helper
INFO - 2025-05-04 08:37:20 --> Helper loaded: html_helper
INFO - 2025-05-04 08:37:20 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:37:20 --> Controller Class Initialized
INFO - 2025-05-04 16:37:20 --> Model "UserModel" initialized
INFO - 2025-05-04 16:37:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:37:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:37:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:37:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:37:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:37:20 --> Final output sent to browser
DEBUG - 2025-05-04 16:37:20 --> Total execution time: 0.3236
INFO - 2025-05-04 08:40:46 --> Config Class Initialized
INFO - 2025-05-04 08:40:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:40:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:40:46 --> Utf8 Class Initialized
INFO - 2025-05-04 08:40:46 --> URI Class Initialized
INFO - 2025-05-04 08:40:46 --> Router Class Initialized
INFO - 2025-05-04 08:40:46 --> Output Class Initialized
INFO - 2025-05-04 08:40:46 --> Security Class Initialized
DEBUG - 2025-05-04 08:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:40:46 --> Input Class Initialized
INFO - 2025-05-04 08:40:46 --> Language Class Initialized
INFO - 2025-05-04 08:40:46 --> Loader Class Initialized
INFO - 2025-05-04 08:40:46 --> Helper loaded: url_helper
INFO - 2025-05-04 08:40:46 --> Helper loaded: string_helper
INFO - 2025-05-04 08:40:46 --> Helper loaded: form_helper
INFO - 2025-05-04 08:40:46 --> Helper loaded: file_helper
INFO - 2025-05-04 08:40:46 --> Helper loaded: html_helper
INFO - 2025-05-04 08:40:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:40:47 --> Controller Class Initialized
INFO - 2025-05-04 16:40:47 --> Model "UserModel" initialized
INFO - 2025-05-04 16:40:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:40:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:40:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:40:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:40:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:40:47 --> Final output sent to browser
DEBUG - 2025-05-04 16:40:47 --> Total execution time: 0.2569
INFO - 2025-05-04 08:41:16 --> Config Class Initialized
INFO - 2025-05-04 08:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:41:16 --> Utf8 Class Initialized
INFO - 2025-05-04 08:41:16 --> URI Class Initialized
INFO - 2025-05-04 08:41:16 --> Router Class Initialized
INFO - 2025-05-04 08:41:16 --> Output Class Initialized
INFO - 2025-05-04 08:41:16 --> Security Class Initialized
DEBUG - 2025-05-04 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:41:16 --> Input Class Initialized
INFO - 2025-05-04 08:41:16 --> Language Class Initialized
INFO - 2025-05-04 08:41:16 --> Loader Class Initialized
INFO - 2025-05-04 08:41:16 --> Helper loaded: url_helper
INFO - 2025-05-04 08:41:16 --> Helper loaded: string_helper
INFO - 2025-05-04 08:41:16 --> Helper loaded: form_helper
INFO - 2025-05-04 08:41:16 --> Helper loaded: file_helper
INFO - 2025-05-04 08:41:16 --> Helper loaded: html_helper
INFO - 2025-05-04 08:41:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:41:16 --> Controller Class Initialized
INFO - 2025-05-04 16:41:16 --> Model "UserModel" initialized
INFO - 2025-05-04 16:41:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:41:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:41:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:41:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:41:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:41:16 --> Final output sent to browser
DEBUG - 2025-05-04 16:41:16 --> Total execution time: 0.1358
INFO - 2025-05-04 08:41:26 --> Config Class Initialized
INFO - 2025-05-04 08:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:41:26 --> Utf8 Class Initialized
INFO - 2025-05-04 08:41:26 --> URI Class Initialized
INFO - 2025-05-04 08:41:26 --> Router Class Initialized
INFO - 2025-05-04 08:41:26 --> Output Class Initialized
INFO - 2025-05-04 08:41:26 --> Security Class Initialized
DEBUG - 2025-05-04 08:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:41:26 --> Input Class Initialized
INFO - 2025-05-04 08:41:26 --> Language Class Initialized
INFO - 2025-05-04 08:41:26 --> Loader Class Initialized
INFO - 2025-05-04 08:41:26 --> Helper loaded: url_helper
INFO - 2025-05-04 08:41:26 --> Helper loaded: string_helper
INFO - 2025-05-04 08:41:26 --> Helper loaded: form_helper
INFO - 2025-05-04 08:41:26 --> Helper loaded: file_helper
INFO - 2025-05-04 08:41:26 --> Helper loaded: html_helper
INFO - 2025-05-04 08:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:41:26 --> Controller Class Initialized
INFO - 2025-05-04 16:41:26 --> Model "UserModel" initialized
INFO - 2025-05-04 16:41:26 --> Final output sent to browser
DEBUG - 2025-05-04 16:41:26 --> Total execution time: 0.1797
INFO - 2025-05-04 08:41:27 --> Config Class Initialized
INFO - 2025-05-04 08:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:41:27 --> Utf8 Class Initialized
INFO - 2025-05-04 08:41:27 --> URI Class Initialized
INFO - 2025-05-04 08:41:27 --> Router Class Initialized
INFO - 2025-05-04 08:41:27 --> Output Class Initialized
INFO - 2025-05-04 08:41:27 --> Security Class Initialized
DEBUG - 2025-05-04 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:41:27 --> Input Class Initialized
INFO - 2025-05-04 08:41:27 --> Language Class Initialized
INFO - 2025-05-04 08:41:27 --> Loader Class Initialized
INFO - 2025-05-04 08:41:27 --> Helper loaded: url_helper
INFO - 2025-05-04 08:41:27 --> Helper loaded: string_helper
INFO - 2025-05-04 08:41:27 --> Helper loaded: form_helper
INFO - 2025-05-04 08:41:27 --> Helper loaded: file_helper
INFO - 2025-05-04 08:41:27 --> Helper loaded: html_helper
INFO - 2025-05-04 08:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:41:27 --> Controller Class Initialized
INFO - 2025-05-04 16:41:27 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:41:27 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:41:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/reset_password_success_email.php
INFO - 2025-05-04 16:41:30 --> Final output sent to browser
DEBUG - 2025-05-04 16:41:30 --> Total execution time: 3.9004
INFO - 2025-05-04 08:43:16 --> Config Class Initialized
INFO - 2025-05-04 08:43:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:43:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:43:16 --> Utf8 Class Initialized
INFO - 2025-05-04 08:43:16 --> URI Class Initialized
INFO - 2025-05-04 08:43:16 --> Router Class Initialized
INFO - 2025-05-04 08:43:16 --> Output Class Initialized
INFO - 2025-05-04 08:43:16 --> Security Class Initialized
DEBUG - 2025-05-04 08:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:43:16 --> Input Class Initialized
INFO - 2025-05-04 08:43:16 --> Language Class Initialized
INFO - 2025-05-04 08:43:16 --> Loader Class Initialized
INFO - 2025-05-04 08:43:16 --> Helper loaded: url_helper
INFO - 2025-05-04 08:43:16 --> Helper loaded: string_helper
INFO - 2025-05-04 08:43:16 --> Helper loaded: form_helper
INFO - 2025-05-04 08:43:16 --> Helper loaded: file_helper
INFO - 2025-05-04 08:43:16 --> Helper loaded: html_helper
INFO - 2025-05-04 08:43:16 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:43:16 --> Controller Class Initialized
INFO - 2025-05-04 16:43:16 --> Model "UserModel" initialized
INFO - 2025-05-04 16:43:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-04 16:43:16 --> Final output sent to browser
DEBUG - 2025-05-04 16:43:16 --> Total execution time: 0.4235
INFO - 2025-05-04 08:43:29 --> Config Class Initialized
INFO - 2025-05-04 08:43:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:43:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:43:29 --> Utf8 Class Initialized
INFO - 2025-05-04 08:43:29 --> URI Class Initialized
DEBUG - 2025-05-04 08:43:29 --> No URI present. Default controller set.
INFO - 2025-05-04 08:43:29 --> Router Class Initialized
INFO - 2025-05-04 08:43:29 --> Output Class Initialized
INFO - 2025-05-04 08:43:29 --> Security Class Initialized
DEBUG - 2025-05-04 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:43:29 --> Input Class Initialized
INFO - 2025-05-04 08:43:29 --> Language Class Initialized
INFO - 2025-05-04 08:43:29 --> Loader Class Initialized
INFO - 2025-05-04 08:43:29 --> Helper loaded: url_helper
INFO - 2025-05-04 08:43:29 --> Helper loaded: string_helper
INFO - 2025-05-04 08:43:29 --> Helper loaded: form_helper
INFO - 2025-05-04 08:43:29 --> Helper loaded: file_helper
INFO - 2025-05-04 08:43:29 --> Helper loaded: html_helper
INFO - 2025-05-04 08:43:29 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:43:29 --> Controller Class Initialized
INFO - 2025-05-04 08:43:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:43:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:43:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:43:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:43:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:43:29 --> Final output sent to browser
DEBUG - 2025-05-04 08:43:29 --> Total execution time: 0.1013
INFO - 2025-05-04 08:43:32 --> Config Class Initialized
INFO - 2025-05-04 08:43:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:43:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:43:32 --> Utf8 Class Initialized
INFO - 2025-05-04 08:43:32 --> URI Class Initialized
INFO - 2025-05-04 08:43:32 --> Router Class Initialized
INFO - 2025-05-04 08:43:32 --> Output Class Initialized
INFO - 2025-05-04 08:43:32 --> Security Class Initialized
DEBUG - 2025-05-04 08:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:43:32 --> Input Class Initialized
INFO - 2025-05-04 08:43:32 --> Language Class Initialized
INFO - 2025-05-04 08:43:32 --> Loader Class Initialized
INFO - 2025-05-04 08:43:32 --> Helper loaded: url_helper
INFO - 2025-05-04 08:43:32 --> Helper loaded: string_helper
INFO - 2025-05-04 08:43:32 --> Helper loaded: form_helper
INFO - 2025-05-04 08:43:32 --> Helper loaded: file_helper
INFO - 2025-05-04 08:43:32 --> Helper loaded: html_helper
INFO - 2025-05-04 08:43:32 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:43:32 --> Controller Class Initialized
INFO - 2025-05-04 16:43:32 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:43:35 --> Config Class Initialized
INFO - 2025-05-04 08:43:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:43:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:43:35 --> Utf8 Class Initialized
INFO - 2025-05-04 08:43:35 --> URI Class Initialized
INFO - 2025-05-04 08:43:35 --> Router Class Initialized
INFO - 2025-05-04 08:43:35 --> Output Class Initialized
INFO - 2025-05-04 08:43:35 --> Security Class Initialized
DEBUG - 2025-05-04 08:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:43:35 --> Input Class Initialized
INFO - 2025-05-04 08:43:35 --> Language Class Initialized
INFO - 2025-05-04 08:43:35 --> Loader Class Initialized
INFO - 2025-05-04 08:43:35 --> Helper loaded: url_helper
INFO - 2025-05-04 08:43:35 --> Helper loaded: string_helper
INFO - 2025-05-04 08:43:35 --> Helper loaded: form_helper
INFO - 2025-05-04 08:43:35 --> Helper loaded: file_helper
INFO - 2025-05-04 08:43:35 --> Helper loaded: html_helper
INFO - 2025-05-04 08:43:35 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:43:35 --> Controller Class Initialized
INFO - 2025-05-04 16:43:36 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:43:36 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:43:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 16:43:43 --> Final output sent to browser
DEBUG - 2025-05-04 16:43:43 --> Total execution time: 7.9853
INFO - 2025-05-04 08:44:02 --> Config Class Initialized
INFO - 2025-05-04 08:44:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:44:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:44:02 --> Utf8 Class Initialized
INFO - 2025-05-04 08:44:02 --> URI Class Initialized
INFO - 2025-05-04 08:44:02 --> Router Class Initialized
INFO - 2025-05-04 08:44:02 --> Output Class Initialized
INFO - 2025-05-04 08:44:02 --> Security Class Initialized
DEBUG - 2025-05-04 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:44:02 --> Input Class Initialized
INFO - 2025-05-04 08:44:02 --> Language Class Initialized
INFO - 2025-05-04 08:44:02 --> Loader Class Initialized
INFO - 2025-05-04 08:44:02 --> Helper loaded: url_helper
INFO - 2025-05-04 08:44:02 --> Helper loaded: string_helper
INFO - 2025-05-04 08:44:02 --> Helper loaded: form_helper
INFO - 2025-05-04 08:44:02 --> Helper loaded: file_helper
INFO - 2025-05-04 08:44:02 --> Helper loaded: html_helper
INFO - 2025-05-04 08:44:02 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:44:02 --> Controller Class Initialized
INFO - 2025-05-04 16:44:02 --> Model "UserModel" initialized
INFO - 2025-05-04 16:44:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:44:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:44:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:44:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:44:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:44:02 --> Final output sent to browser
DEBUG - 2025-05-04 16:44:02 --> Total execution time: 0.3527
INFO - 2025-05-04 08:44:23 --> Config Class Initialized
INFO - 2025-05-04 08:44:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:44:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:44:23 --> Utf8 Class Initialized
INFO - 2025-05-04 08:44:23 --> URI Class Initialized
INFO - 2025-05-04 08:44:23 --> Router Class Initialized
INFO - 2025-05-04 08:44:23 --> Output Class Initialized
INFO - 2025-05-04 08:44:23 --> Security Class Initialized
DEBUG - 2025-05-04 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:44:23 --> Input Class Initialized
INFO - 2025-05-04 08:44:23 --> Language Class Initialized
INFO - 2025-05-04 08:44:23 --> Loader Class Initialized
INFO - 2025-05-04 08:44:23 --> Helper loaded: url_helper
INFO - 2025-05-04 08:44:23 --> Helper loaded: string_helper
INFO - 2025-05-04 08:44:23 --> Helper loaded: form_helper
INFO - 2025-05-04 08:44:23 --> Helper loaded: file_helper
INFO - 2025-05-04 08:44:23 --> Helper loaded: html_helper
INFO - 2025-05-04 08:44:23 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:44:23 --> Controller Class Initialized
INFO - 2025-05-04 08:44:39 --> Config Class Initialized
INFO - 2025-05-04 08:44:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:44:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:44:39 --> Utf8 Class Initialized
INFO - 2025-05-04 08:44:39 --> URI Class Initialized
INFO - 2025-05-04 08:44:39 --> Router Class Initialized
INFO - 2025-05-04 08:44:39 --> Output Class Initialized
INFO - 2025-05-04 08:44:39 --> Security Class Initialized
DEBUG - 2025-05-04 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:44:39 --> Input Class Initialized
INFO - 2025-05-04 08:44:39 --> Language Class Initialized
INFO - 2025-05-04 08:44:39 --> Loader Class Initialized
INFO - 2025-05-04 08:44:39 --> Helper loaded: url_helper
INFO - 2025-05-04 08:44:39 --> Helper loaded: string_helper
INFO - 2025-05-04 08:44:39 --> Helper loaded: form_helper
INFO - 2025-05-04 08:44:39 --> Helper loaded: file_helper
INFO - 2025-05-04 08:44:39 --> Helper loaded: html_helper
INFO - 2025-05-04 08:44:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:44:39 --> Controller Class Initialized
INFO - 2025-05-04 16:44:39 --> Model "UserModel" initialized
INFO - 2025-05-04 16:44:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:44:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:44:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:44:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:44:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:44:39 --> Final output sent to browser
DEBUG - 2025-05-04 16:44:39 --> Total execution time: 0.1959
INFO - 2025-05-04 08:44:57 --> Config Class Initialized
INFO - 2025-05-04 08:44:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:44:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:44:58 --> Utf8 Class Initialized
INFO - 2025-05-04 08:44:58 --> URI Class Initialized
INFO - 2025-05-04 08:44:58 --> Router Class Initialized
INFO - 2025-05-04 08:44:58 --> Output Class Initialized
INFO - 2025-05-04 08:44:58 --> Security Class Initialized
DEBUG - 2025-05-04 08:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:44:58 --> Input Class Initialized
INFO - 2025-05-04 08:44:58 --> Language Class Initialized
INFO - 2025-05-04 08:44:58 --> Loader Class Initialized
INFO - 2025-05-04 08:44:58 --> Helper loaded: url_helper
INFO - 2025-05-04 08:44:58 --> Helper loaded: string_helper
INFO - 2025-05-04 08:44:58 --> Helper loaded: form_helper
INFO - 2025-05-04 08:44:58 --> Helper loaded: file_helper
INFO - 2025-05-04 08:44:58 --> Helper loaded: html_helper
INFO - 2025-05-04 08:44:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:44:58 --> Controller Class Initialized
INFO - 2025-05-04 08:45:41 --> Config Class Initialized
INFO - 2025-05-04 08:45:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:45:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:45:41 --> Utf8 Class Initialized
INFO - 2025-05-04 08:45:41 --> URI Class Initialized
INFO - 2025-05-04 08:45:41 --> Router Class Initialized
INFO - 2025-05-04 08:45:41 --> Output Class Initialized
INFO - 2025-05-04 08:45:41 --> Security Class Initialized
DEBUG - 2025-05-04 08:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:45:41 --> Input Class Initialized
INFO - 2025-05-04 08:45:41 --> Language Class Initialized
INFO - 2025-05-04 08:45:41 --> Loader Class Initialized
INFO - 2025-05-04 08:45:41 --> Helper loaded: url_helper
INFO - 2025-05-04 08:45:41 --> Helper loaded: string_helper
INFO - 2025-05-04 08:45:41 --> Helper loaded: form_helper
INFO - 2025-05-04 08:45:41 --> Helper loaded: file_helper
INFO - 2025-05-04 08:45:41 --> Helper loaded: html_helper
INFO - 2025-05-04 08:45:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:45:42 --> Controller Class Initialized
INFO - 2025-05-04 08:47:41 --> Config Class Initialized
INFO - 2025-05-04 08:47:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:47:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:47:41 --> Utf8 Class Initialized
INFO - 2025-05-04 08:47:41 --> URI Class Initialized
INFO - 2025-05-04 08:47:41 --> Router Class Initialized
INFO - 2025-05-04 08:47:41 --> Output Class Initialized
INFO - 2025-05-04 08:47:41 --> Security Class Initialized
DEBUG - 2025-05-04 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:47:41 --> Input Class Initialized
INFO - 2025-05-04 08:47:41 --> Language Class Initialized
INFO - 2025-05-04 08:47:41 --> Loader Class Initialized
INFO - 2025-05-04 08:47:41 --> Helper loaded: url_helper
INFO - 2025-05-04 08:47:41 --> Helper loaded: string_helper
INFO - 2025-05-04 08:47:41 --> Helper loaded: form_helper
INFO - 2025-05-04 08:47:41 --> Helper loaded: file_helper
INFO - 2025-05-04 08:47:41 --> Helper loaded: html_helper
INFO - 2025-05-04 08:47:41 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:47:41 --> Controller Class Initialized
INFO - 2025-05-04 16:47:41 --> Model "UserModel" initialized
INFO - 2025-05-04 16:47:42 --> Final output sent to browser
DEBUG - 2025-05-04 16:47:42 --> Total execution time: 0.5971
INFO - 2025-05-04 08:47:42 --> Config Class Initialized
INFO - 2025-05-04 08:47:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:47:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:47:42 --> Utf8 Class Initialized
INFO - 2025-05-04 08:47:42 --> URI Class Initialized
INFO - 2025-05-04 08:47:42 --> Router Class Initialized
INFO - 2025-05-04 08:47:42 --> Output Class Initialized
INFO - 2025-05-04 08:47:42 --> Security Class Initialized
DEBUG - 2025-05-04 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:47:42 --> Input Class Initialized
INFO - 2025-05-04 08:47:42 --> Language Class Initialized
INFO - 2025-05-04 08:47:42 --> Loader Class Initialized
INFO - 2025-05-04 08:47:42 --> Helper loaded: url_helper
INFO - 2025-05-04 08:47:42 --> Helper loaded: string_helper
INFO - 2025-05-04 08:47:42 --> Helper loaded: form_helper
INFO - 2025-05-04 08:47:42 --> Helper loaded: file_helper
INFO - 2025-05-04 08:47:42 --> Helper loaded: html_helper
INFO - 2025-05-04 08:47:42 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:47:42 --> Controller Class Initialized
INFO - 2025-05-04 16:47:42 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:47:42 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:47:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/reset_password_success_email.php
INFO - 2025-05-04 16:47:46 --> Final output sent to browser
DEBUG - 2025-05-04 16:47:46 --> Total execution time: 4.7019
INFO - 2025-05-04 08:48:11 --> Config Class Initialized
INFO - 2025-05-04 08:48:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:48:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:48:11 --> Utf8 Class Initialized
INFO - 2025-05-04 08:48:11 --> URI Class Initialized
INFO - 2025-05-04 08:48:11 --> Router Class Initialized
INFO - 2025-05-04 08:48:11 --> Output Class Initialized
INFO - 2025-05-04 08:48:11 --> Security Class Initialized
DEBUG - 2025-05-04 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:48:11 --> Input Class Initialized
INFO - 2025-05-04 08:48:11 --> Language Class Initialized
INFO - 2025-05-04 08:48:11 --> Loader Class Initialized
INFO - 2025-05-04 08:48:11 --> Helper loaded: url_helper
INFO - 2025-05-04 08:48:11 --> Helper loaded: string_helper
INFO - 2025-05-04 08:48:11 --> Helper loaded: form_helper
INFO - 2025-05-04 08:48:11 --> Helper loaded: file_helper
INFO - 2025-05-04 08:48:11 --> Helper loaded: html_helper
INFO - 2025-05-04 08:48:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:48:11 --> Controller Class Initialized
INFO - 2025-05-04 16:48:11 --> Model "UserModel" initialized
INFO - 2025-05-04 16:48:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-04 16:48:11 --> Final output sent to browser
DEBUG - 2025-05-04 16:48:11 --> Total execution time: 0.1354
INFO - 2025-05-04 08:49:39 --> Config Class Initialized
INFO - 2025-05-04 08:49:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:49:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:49:39 --> Utf8 Class Initialized
INFO - 2025-05-04 08:49:39 --> URI Class Initialized
DEBUG - 2025-05-04 08:49:39 --> No URI present. Default controller set.
INFO - 2025-05-04 08:49:39 --> Router Class Initialized
INFO - 2025-05-04 08:49:39 --> Output Class Initialized
INFO - 2025-05-04 08:49:39 --> Security Class Initialized
DEBUG - 2025-05-04 08:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:49:39 --> Input Class Initialized
INFO - 2025-05-04 08:49:39 --> Language Class Initialized
INFO - 2025-05-04 08:49:40 --> Loader Class Initialized
INFO - 2025-05-04 08:49:40 --> Helper loaded: url_helper
INFO - 2025-05-04 08:49:40 --> Helper loaded: string_helper
INFO - 2025-05-04 08:49:40 --> Helper loaded: form_helper
INFO - 2025-05-04 08:49:40 --> Helper loaded: file_helper
INFO - 2025-05-04 08:49:40 --> Helper loaded: html_helper
INFO - 2025-05-04 08:49:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:49:40 --> Controller Class Initialized
INFO - 2025-05-04 08:49:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:49:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:49:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:49:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:49:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:49:40 --> Final output sent to browser
DEBUG - 2025-05-04 08:49:40 --> Total execution time: 0.3018
INFO - 2025-05-04 08:49:43 --> Config Class Initialized
INFO - 2025-05-04 08:49:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:49:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:49:43 --> Utf8 Class Initialized
INFO - 2025-05-04 08:49:43 --> URI Class Initialized
INFO - 2025-05-04 08:49:43 --> Router Class Initialized
INFO - 2025-05-04 08:49:43 --> Output Class Initialized
INFO - 2025-05-04 08:49:43 --> Security Class Initialized
DEBUG - 2025-05-04 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:49:43 --> Input Class Initialized
INFO - 2025-05-04 08:49:43 --> Language Class Initialized
INFO - 2025-05-04 08:49:43 --> Loader Class Initialized
INFO - 2025-05-04 08:49:43 --> Helper loaded: url_helper
INFO - 2025-05-04 08:49:43 --> Helper loaded: string_helper
INFO - 2025-05-04 08:49:43 --> Helper loaded: form_helper
INFO - 2025-05-04 08:49:43 --> Helper loaded: file_helper
INFO - 2025-05-04 08:49:43 --> Helper loaded: html_helper
INFO - 2025-05-04 08:49:43 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:49:43 --> Controller Class Initialized
INFO - 2025-05-04 16:49:43 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:50:45 --> Config Class Initialized
INFO - 2025-05-04 08:50:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:50:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:50:46 --> Utf8 Class Initialized
INFO - 2025-05-04 08:50:46 --> URI Class Initialized
DEBUG - 2025-05-04 08:50:46 --> No URI present. Default controller set.
INFO - 2025-05-04 08:50:46 --> Router Class Initialized
INFO - 2025-05-04 08:50:46 --> Output Class Initialized
INFO - 2025-05-04 08:50:46 --> Security Class Initialized
DEBUG - 2025-05-04 08:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:50:46 --> Input Class Initialized
INFO - 2025-05-04 08:50:46 --> Language Class Initialized
INFO - 2025-05-04 08:50:46 --> Loader Class Initialized
INFO - 2025-05-04 08:50:46 --> Helper loaded: url_helper
INFO - 2025-05-04 08:50:46 --> Helper loaded: string_helper
INFO - 2025-05-04 08:50:46 --> Helper loaded: form_helper
INFO - 2025-05-04 08:50:46 --> Helper loaded: file_helper
INFO - 2025-05-04 08:50:46 --> Helper loaded: html_helper
INFO - 2025-05-04 08:50:46 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:50:46 --> Controller Class Initialized
INFO - 2025-05-04 08:50:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:50:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:50:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:50:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:50:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:50:46 --> Final output sent to browser
DEBUG - 2025-05-04 08:50:46 --> Total execution time: 0.2752
INFO - 2025-05-04 08:50:54 --> Config Class Initialized
INFO - 2025-05-04 08:50:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:50:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:50:54 --> Utf8 Class Initialized
INFO - 2025-05-04 08:50:54 --> URI Class Initialized
INFO - 2025-05-04 08:50:54 --> Router Class Initialized
INFO - 2025-05-04 08:50:54 --> Output Class Initialized
INFO - 2025-05-04 08:50:54 --> Security Class Initialized
DEBUG - 2025-05-04 08:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:50:54 --> Input Class Initialized
INFO - 2025-05-04 08:50:54 --> Language Class Initialized
INFO - 2025-05-04 08:50:54 --> Loader Class Initialized
INFO - 2025-05-04 08:50:54 --> Helper loaded: url_helper
INFO - 2025-05-04 08:50:54 --> Helper loaded: string_helper
INFO - 2025-05-04 08:50:54 --> Helper loaded: form_helper
INFO - 2025-05-04 08:50:54 --> Helper loaded: file_helper
INFO - 2025-05-04 08:50:54 --> Helper loaded: html_helper
INFO - 2025-05-04 08:50:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:50:54 --> Controller Class Initialized
INFO - 2025-05-04 16:50:54 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:51:03 --> Config Class Initialized
INFO - 2025-05-04 08:51:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:51:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:51:03 --> Utf8 Class Initialized
INFO - 2025-05-04 08:51:03 --> URI Class Initialized
INFO - 2025-05-04 08:51:03 --> Router Class Initialized
INFO - 2025-05-04 08:51:03 --> Output Class Initialized
INFO - 2025-05-04 08:51:03 --> Security Class Initialized
DEBUG - 2025-05-04 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:51:03 --> Input Class Initialized
INFO - 2025-05-04 08:51:03 --> Language Class Initialized
INFO - 2025-05-04 08:51:03 --> Loader Class Initialized
INFO - 2025-05-04 08:51:03 --> Helper loaded: url_helper
INFO - 2025-05-04 08:51:03 --> Helper loaded: string_helper
INFO - 2025-05-04 08:51:03 --> Helper loaded: form_helper
INFO - 2025-05-04 08:51:03 --> Helper loaded: file_helper
INFO - 2025-05-04 08:51:03 --> Helper loaded: html_helper
INFO - 2025-05-04 08:51:03 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:51:03 --> Controller Class Initialized
INFO - 2025-05-04 16:51:03 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:51:03 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:51:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 16:51:14 --> Final output sent to browser
DEBUG - 2025-05-04 16:51:14 --> Total execution time: 11.7633
INFO - 2025-05-04 08:51:26 --> Config Class Initialized
INFO - 2025-05-04 08:51:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:51:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:51:26 --> Utf8 Class Initialized
INFO - 2025-05-04 08:51:26 --> URI Class Initialized
INFO - 2025-05-04 08:51:26 --> Router Class Initialized
INFO - 2025-05-04 08:51:26 --> Output Class Initialized
INFO - 2025-05-04 08:51:26 --> Security Class Initialized
DEBUG - 2025-05-04 08:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:51:26 --> Input Class Initialized
INFO - 2025-05-04 08:51:26 --> Language Class Initialized
INFO - 2025-05-04 08:51:26 --> Loader Class Initialized
INFO - 2025-05-04 08:51:26 --> Helper loaded: url_helper
INFO - 2025-05-04 08:51:26 --> Helper loaded: string_helper
INFO - 2025-05-04 08:51:26 --> Helper loaded: form_helper
INFO - 2025-05-04 08:51:26 --> Helper loaded: file_helper
INFO - 2025-05-04 08:51:26 --> Helper loaded: html_helper
INFO - 2025-05-04 08:51:26 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:51:26 --> Controller Class Initialized
INFO - 2025-05-04 16:51:26 --> Model "UserModel" initialized
INFO - 2025-05-04 16:51:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:51:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:51:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:51:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:51:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:51:26 --> Final output sent to browser
DEBUG - 2025-05-04 16:51:26 --> Total execution time: 0.3474
INFO - 2025-05-04 08:51:38 --> Config Class Initialized
INFO - 2025-05-04 08:51:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:51:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:51:38 --> Utf8 Class Initialized
INFO - 2025-05-04 08:51:38 --> URI Class Initialized
INFO - 2025-05-04 08:51:38 --> Router Class Initialized
INFO - 2025-05-04 08:51:38 --> Output Class Initialized
INFO - 2025-05-04 08:51:38 --> Security Class Initialized
DEBUG - 2025-05-04 08:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:51:38 --> Input Class Initialized
INFO - 2025-05-04 08:51:38 --> Language Class Initialized
INFO - 2025-05-04 08:51:38 --> Loader Class Initialized
INFO - 2025-05-04 08:51:38 --> Helper loaded: url_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: string_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: form_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: file_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: html_helper
INFO - 2025-05-04 08:51:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:51:38 --> Controller Class Initialized
INFO - 2025-05-04 16:51:38 --> Model "UserModel" initialized
INFO - 2025-05-04 16:51:38 --> Final output sent to browser
DEBUG - 2025-05-04 16:51:38 --> Total execution time: 0.1581
INFO - 2025-05-04 08:51:38 --> Config Class Initialized
INFO - 2025-05-04 08:51:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:51:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:51:38 --> Utf8 Class Initialized
INFO - 2025-05-04 08:51:38 --> URI Class Initialized
INFO - 2025-05-04 08:51:38 --> Router Class Initialized
INFO - 2025-05-04 08:51:38 --> Output Class Initialized
INFO - 2025-05-04 08:51:38 --> Security Class Initialized
DEBUG - 2025-05-04 08:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:51:38 --> Input Class Initialized
INFO - 2025-05-04 08:51:38 --> Language Class Initialized
INFO - 2025-05-04 08:51:38 --> Loader Class Initialized
INFO - 2025-05-04 08:51:38 --> Helper loaded: url_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: string_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: form_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: file_helper
INFO - 2025-05-04 08:51:38 --> Helper loaded: html_helper
INFO - 2025-05-04 08:51:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:51:38 --> Controller Class Initialized
INFO - 2025-05-04 16:51:38 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:51:38 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:51:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/reset_password_success_email.php
INFO - 2025-05-04 16:51:46 --> Final output sent to browser
DEBUG - 2025-05-04 16:51:46 --> Total execution time: 7.7229
INFO - 2025-05-04 08:52:31 --> Config Class Initialized
INFO - 2025-05-04 08:52:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:52:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:52:31 --> Utf8 Class Initialized
INFO - 2025-05-04 08:52:31 --> URI Class Initialized
INFO - 2025-05-04 08:52:31 --> Router Class Initialized
INFO - 2025-05-04 08:52:31 --> Output Class Initialized
INFO - 2025-05-04 08:52:31 --> Security Class Initialized
DEBUG - 2025-05-04 08:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:52:31 --> Input Class Initialized
INFO - 2025-05-04 08:52:31 --> Language Class Initialized
INFO - 2025-05-04 08:52:31 --> Loader Class Initialized
INFO - 2025-05-04 08:52:31 --> Helper loaded: url_helper
INFO - 2025-05-04 08:52:31 --> Helper loaded: string_helper
INFO - 2025-05-04 08:52:31 --> Helper loaded: form_helper
INFO - 2025-05-04 08:52:31 --> Helper loaded: file_helper
INFO - 2025-05-04 08:52:31 --> Helper loaded: html_helper
INFO - 2025-05-04 08:52:31 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:52:31 --> Controller Class Initialized
INFO - 2025-05-04 16:52:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:52:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:52:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/sign_in.php
INFO - 2025-05-04 16:52:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:52:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:52:31 --> Final output sent to browser
DEBUG - 2025-05-04 16:52:31 --> Total execution time: 0.3923
INFO - 2025-05-04 08:54:11 --> Config Class Initialized
INFO - 2025-05-04 08:54:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:11 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:11 --> URI Class Initialized
INFO - 2025-05-04 08:54:11 --> Router Class Initialized
INFO - 2025-05-04 08:54:11 --> Output Class Initialized
INFO - 2025-05-04 08:54:11 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:11 --> Input Class Initialized
INFO - 2025-05-04 08:54:11 --> Language Class Initialized
INFO - 2025-05-04 08:54:11 --> Loader Class Initialized
INFO - 2025-05-04 08:54:11 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:11 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:11 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:11 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:11 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:11 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:11 --> Controller Class Initialized
INFO - 2025-05-04 16:54:11 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:54:11 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:54:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/forgot_password_email.php
INFO - 2025-05-04 16:54:15 --> Final output sent to browser
DEBUG - 2025-05-04 16:54:15 --> Total execution time: 4.0874
INFO - 2025-05-04 08:54:33 --> Config Class Initialized
INFO - 2025-05-04 08:54:33 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:33 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:33 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:33 --> URI Class Initialized
INFO - 2025-05-04 08:54:33 --> Router Class Initialized
INFO - 2025-05-04 08:54:33 --> Output Class Initialized
INFO - 2025-05-04 08:54:33 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:33 --> Input Class Initialized
INFO - 2025-05-04 08:54:33 --> Language Class Initialized
INFO - 2025-05-04 08:54:33 --> Loader Class Initialized
INFO - 2025-05-04 08:54:33 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:33 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:33 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:33 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:33 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:33 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:33 --> Controller Class Initialized
INFO - 2025-05-04 16:54:33 --> Model "UserModel" initialized
INFO - 2025-05-04 16:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/forgot_password.php
INFO - 2025-05-04 16:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:54:33 --> Final output sent to browser
DEBUG - 2025-05-04 16:54:33 --> Total execution time: 0.2159
INFO - 2025-05-04 08:54:52 --> Config Class Initialized
INFO - 2025-05-04 08:54:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:52 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:52 --> URI Class Initialized
INFO - 2025-05-04 08:54:52 --> Router Class Initialized
INFO - 2025-05-04 08:54:52 --> Output Class Initialized
INFO - 2025-05-04 08:54:52 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:52 --> Input Class Initialized
INFO - 2025-05-04 08:54:52 --> Language Class Initialized
INFO - 2025-05-04 08:54:52 --> Loader Class Initialized
INFO - 2025-05-04 08:54:52 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:52 --> Controller Class Initialized
INFO - 2025-05-04 16:54:52 --> Model "UserModel" initialized
INFO - 2025-05-04 16:54:52 --> Final output sent to browser
DEBUG - 2025-05-04 16:54:52 --> Total execution time: 0.1628
INFO - 2025-05-04 08:54:52 --> Config Class Initialized
INFO - 2025-05-04 08:54:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:52 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:52 --> URI Class Initialized
INFO - 2025-05-04 08:54:52 --> Router Class Initialized
INFO - 2025-05-04 08:54:52 --> Output Class Initialized
INFO - 2025-05-04 08:54:52 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:52 --> Input Class Initialized
INFO - 2025-05-04 08:54:52 --> Language Class Initialized
INFO - 2025-05-04 08:54:52 --> Loader Class Initialized
INFO - 2025-05-04 08:54:52 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:52 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:52 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:52 --> Controller Class Initialized
INFO - 2025-05-04 16:54:52 --> Model "UserModel" initialized
DEBUG - 2025-05-04 16:54:52 --> PHPMailer class is loaded.
INFO - 2025-05-04 16:54:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/reset_password_success_email.php
INFO - 2025-05-04 16:54:56 --> Final output sent to browser
DEBUG - 2025-05-04 16:54:56 --> Total execution time: 3.9596
INFO - 2025-05-04 08:54:58 --> Config Class Initialized
INFO - 2025-05-04 08:54:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:58 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:58 --> URI Class Initialized
DEBUG - 2025-05-04 08:54:58 --> No URI present. Default controller set.
INFO - 2025-05-04 08:54:58 --> Router Class Initialized
INFO - 2025-05-04 08:54:58 --> Output Class Initialized
INFO - 2025-05-04 08:54:58 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:58 --> Input Class Initialized
INFO - 2025-05-04 08:54:58 --> Language Class Initialized
INFO - 2025-05-04 08:54:58 --> Loader Class Initialized
INFO - 2025-05-04 08:54:58 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:58 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:58 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:58 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:58 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:58 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:58 --> Controller Class Initialized
INFO - 2025-05-04 08:54:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:54:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:54:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:54:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:54:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:54:58 --> Final output sent to browser
DEBUG - 2025-05-04 08:54:58 --> Total execution time: 0.0989
INFO - 2025-05-04 08:54:59 --> Config Class Initialized
INFO - 2025-05-04 08:54:59 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:54:59 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:54:59 --> Utf8 Class Initialized
INFO - 2025-05-04 08:54:59 --> URI Class Initialized
INFO - 2025-05-04 08:54:59 --> Router Class Initialized
INFO - 2025-05-04 08:54:59 --> Output Class Initialized
INFO - 2025-05-04 08:54:59 --> Security Class Initialized
DEBUG - 2025-05-04 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:54:59 --> Input Class Initialized
INFO - 2025-05-04 08:54:59 --> Language Class Initialized
INFO - 2025-05-04 08:54:59 --> Loader Class Initialized
INFO - 2025-05-04 08:54:59 --> Helper loaded: url_helper
INFO - 2025-05-04 08:54:59 --> Helper loaded: string_helper
INFO - 2025-05-04 08:54:59 --> Helper loaded: form_helper
INFO - 2025-05-04 08:54:59 --> Helper loaded: file_helper
INFO - 2025-05-04 08:54:59 --> Helper loaded: html_helper
INFO - 2025-05-04 08:54:59 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:54:59 --> Controller Class Initialized
INFO - 2025-05-04 16:54:59 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:55:37 --> Config Class Initialized
INFO - 2025-05-04 08:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:37 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:37 --> URI Class Initialized
INFO - 2025-05-04 08:55:37 --> Router Class Initialized
INFO - 2025-05-04 08:55:37 --> Output Class Initialized
INFO - 2025-05-04 08:55:37 --> Security Class Initialized
DEBUG - 2025-05-04 08:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:37 --> Input Class Initialized
INFO - 2025-05-04 08:55:37 --> Language Class Initialized
INFO - 2025-05-04 08:55:37 --> Loader Class Initialized
INFO - 2025-05-04 08:55:37 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:37 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:37 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:37 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:37 --> Helper loaded: html_helper
INFO - 2025-05-04 08:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:37 --> Controller Class Initialized
INFO - 2025-05-04 08:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:55:38 --> Config Class Initialized
INFO - 2025-05-04 08:55:38 --> Hooks Class Initialized
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:55:38 --> Final output sent to browser
DEBUG - 2025-05-04 08:55:38 --> Total execution time: 0.4823
DEBUG - 2025-05-04 08:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:38 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:38 --> URI Class Initialized
INFO - 2025-05-04 08:55:38 --> Router Class Initialized
INFO - 2025-05-04 08:55:38 --> Output Class Initialized
INFO - 2025-05-04 08:55:38 --> Security Class Initialized
DEBUG - 2025-05-04 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:38 --> Input Class Initialized
INFO - 2025-05-04 08:55:38 --> Language Class Initialized
INFO - 2025-05-04 08:55:38 --> Loader Class Initialized
INFO - 2025-05-04 08:55:38 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: html_helper
INFO - 2025-05-04 08:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:38 --> Controller Class Initialized
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:55:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:55:38 --> Final output sent to browser
DEBUG - 2025-05-04 08:55:38 --> Total execution time: 0.6762
INFO - 2025-05-04 08:55:38 --> Config Class Initialized
INFO - 2025-05-04 08:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:38 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:38 --> URI Class Initialized
INFO - 2025-05-04 08:55:38 --> Config Class Initialized
INFO - 2025-05-04 08:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:38 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:38 --> URI Class Initialized
INFO - 2025-05-04 08:55:38 --> Router Class Initialized
INFO - 2025-05-04 08:55:38 --> Output Class Initialized
INFO - 2025-05-04 08:55:38 --> Router Class Initialized
INFO - 2025-05-04 08:55:38 --> Security Class Initialized
INFO - 2025-05-04 08:55:38 --> Output Class Initialized
DEBUG - 2025-05-04 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:38 --> Input Class Initialized
INFO - 2025-05-04 08:55:38 --> Language Class Initialized
INFO - 2025-05-04 08:55:38 --> Security Class Initialized
INFO - 2025-05-04 08:55:38 --> Loader Class Initialized
INFO - 2025-05-04 08:55:38 --> Helper loaded: url_helper
DEBUG - 2025-05-04 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:38 --> Input Class Initialized
INFO - 2025-05-04 08:55:38 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:38 --> Language Class Initialized
INFO - 2025-05-04 08:55:38 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:38 --> Helper loaded: html_helper
INFO - 2025-05-04 08:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:38 --> Controller Class Initialized
INFO - 2025-05-04 08:55:38 --> Loader Class Initialized
INFO - 2025-05-04 08:55:39 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: html_helper
INFO - 2025-05-04 16:55:39 --> Model "CompanyModel" initialized
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:55:39 --> Final output sent to browser
DEBUG - 2025-05-04 16:55:39 --> Total execution time: 0.4175
INFO - 2025-05-04 08:55:39 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:39 --> Controller Class Initialized
INFO - 2025-05-04 16:55:39 --> Model "CompanyModel" initialized
INFO - 2025-05-04 08:55:39 --> Config Class Initialized
INFO - 2025-05-04 08:55:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:39 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:39 --> URI Class Initialized
INFO - 2025-05-04 08:55:39 --> Router Class Initialized
INFO - 2025-05-04 08:55:39 --> Output Class Initialized
INFO - 2025-05-04 08:55:39 --> Security Class Initialized
DEBUG - 2025-05-04 08:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:39 --> Input Class Initialized
INFO - 2025-05-04 08:55:39 --> Language Class Initialized
INFO - 2025-05-04 08:55:39 --> Loader Class Initialized
INFO - 2025-05-04 08:55:39 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:39 --> Helper loaded: html_helper
INFO - 2025-05-04 16:55:39 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:55:39 --> Database Driver Class Initialized
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
DEBUG - 2025-05-04 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/details.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:55:39 --> Final output sent to browser
DEBUG - 2025-05-04 16:55:39 --> Total execution time: 0.7960
INFO - 2025-05-04 08:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:39 --> Controller Class Initialized
INFO - 2025-05-04 08:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-04 08:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:55:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:55:39 --> Final output sent to browser
DEBUG - 2025-05-04 08:55:39 --> Total execution time: 0.1956
INFO - 2025-05-04 08:55:40 --> Config Class Initialized
INFO - 2025-05-04 08:55:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:40 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:40 --> URI Class Initialized
INFO - 2025-05-04 08:55:40 --> Router Class Initialized
INFO - 2025-05-04 08:55:40 --> Output Class Initialized
INFO - 2025-05-04 08:55:40 --> Security Class Initialized
DEBUG - 2025-05-04 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:40 --> Input Class Initialized
INFO - 2025-05-04 08:55:40 --> Language Class Initialized
INFO - 2025-05-04 08:55:40 --> Loader Class Initialized
INFO - 2025-05-04 08:55:40 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:40 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:40 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:40 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:40 --> Helper loaded: html_helper
INFO - 2025-05-04 08:55:40 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:40 --> Controller Class Initialized
INFO - 2025-05-04 08:55:40 --> Model "CompanyModel" initialized
INFO - 2025-05-04 08:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-04 08:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:55:40 --> Final output sent to browser
DEBUG - 2025-05-04 08:55:40 --> Total execution time: 0.1810
INFO - 2025-05-04 08:55:54 --> Config Class Initialized
INFO - 2025-05-04 08:55:54 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:55:54 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:55:54 --> Utf8 Class Initialized
INFO - 2025-05-04 08:55:54 --> URI Class Initialized
DEBUG - 2025-05-04 08:55:54 --> No URI present. Default controller set.
INFO - 2025-05-04 08:55:54 --> Router Class Initialized
INFO - 2025-05-04 08:55:54 --> Output Class Initialized
INFO - 2025-05-04 08:55:54 --> Security Class Initialized
DEBUG - 2025-05-04 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:55:54 --> Input Class Initialized
INFO - 2025-05-04 08:55:54 --> Language Class Initialized
INFO - 2025-05-04 08:55:54 --> Loader Class Initialized
INFO - 2025-05-04 08:55:54 --> Helper loaded: url_helper
INFO - 2025-05-04 08:55:54 --> Helper loaded: string_helper
INFO - 2025-05-04 08:55:54 --> Helper loaded: form_helper
INFO - 2025-05-04 08:55:54 --> Helper loaded: file_helper
INFO - 2025-05-04 08:55:54 --> Helper loaded: html_helper
INFO - 2025-05-04 08:55:54 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:55:54 --> Controller Class Initialized
INFO - 2025-05-04 08:55:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 08:55:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 08:55:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 08:55:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 08:55:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 08:55:54 --> Final output sent to browser
DEBUG - 2025-05-04 08:55:54 --> Total execution time: 0.1741
INFO - 2025-05-04 08:56:07 --> Config Class Initialized
INFO - 2025-05-04 08:56:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:56:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:56:07 --> Utf8 Class Initialized
INFO - 2025-05-04 08:56:07 --> URI Class Initialized
INFO - 2025-05-04 08:56:07 --> Router Class Initialized
INFO - 2025-05-04 08:56:07 --> Output Class Initialized
INFO - 2025-05-04 08:56:07 --> Security Class Initialized
DEBUG - 2025-05-04 08:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:56:07 --> Input Class Initialized
INFO - 2025-05-04 08:56:07 --> Language Class Initialized
INFO - 2025-05-04 08:56:07 --> Loader Class Initialized
INFO - 2025-05-04 08:56:07 --> Helper loaded: url_helper
INFO - 2025-05-04 08:56:07 --> Helper loaded: string_helper
INFO - 2025-05-04 08:56:07 --> Helper loaded: form_helper
INFO - 2025-05-04 08:56:07 --> Helper loaded: file_helper
INFO - 2025-05-04 08:56:07 --> Helper loaded: html_helper
INFO - 2025-05-04 08:56:07 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:56:07 --> Controller Class Initialized
INFO - 2025-05-04 16:56:07 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:56:08 --> Config Class Initialized
INFO - 2025-05-04 08:56:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:56:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:56:09 --> Utf8 Class Initialized
INFO - 2025-05-04 08:56:09 --> URI Class Initialized
INFO - 2025-05-04 08:56:09 --> Router Class Initialized
INFO - 2025-05-04 08:56:09 --> Output Class Initialized
INFO - 2025-05-04 08:56:09 --> Security Class Initialized
DEBUG - 2025-05-04 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:56:09 --> Input Class Initialized
INFO - 2025-05-04 08:56:09 --> Language Class Initialized
INFO - 2025-05-04 08:56:09 --> Loader Class Initialized
INFO - 2025-05-04 08:56:09 --> Helper loaded: url_helper
INFO - 2025-05-04 08:56:09 --> Helper loaded: string_helper
INFO - 2025-05-04 08:56:09 --> Helper loaded: form_helper
INFO - 2025-05-04 08:56:09 --> Helper loaded: file_helper
INFO - 2025-05-04 08:56:09 --> Helper loaded: html_helper
INFO - 2025-05-04 08:56:09 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:56:09 --> Controller Class Initialized
INFO - 2025-05-04 16:56:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:56:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:56:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-04 16:56:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:56:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:56:09 --> Final output sent to browser
DEBUG - 2025-05-04 16:56:09 --> Total execution time: 0.4489
INFO - 2025-05-04 08:57:02 --> Config Class Initialized
INFO - 2025-05-04 08:57:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:57:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:57:02 --> Utf8 Class Initialized
INFO - 2025-05-04 08:57:02 --> URI Class Initialized
INFO - 2025-05-04 08:57:02 --> Router Class Initialized
INFO - 2025-05-04 08:57:02 --> Output Class Initialized
INFO - 2025-05-04 08:57:02 --> Security Class Initialized
DEBUG - 2025-05-04 08:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:57:02 --> Input Class Initialized
INFO - 2025-05-04 08:57:02 --> Language Class Initialized
INFO - 2025-05-04 08:57:02 --> Loader Class Initialized
INFO - 2025-05-04 08:57:02 --> Helper loaded: url_helper
INFO - 2025-05-04 08:57:02 --> Helper loaded: string_helper
INFO - 2025-05-04 08:57:02 --> Helper loaded: form_helper
INFO - 2025-05-04 08:57:02 --> Helper loaded: file_helper
INFO - 2025-05-04 08:57:02 --> Helper loaded: html_helper
INFO - 2025-05-04 08:57:02 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:57:02 --> Controller Class Initialized
INFO - 2025-05-04 16:57:02 --> Model "AuctionModel" initialized
INFO - 2025-05-04 16:57:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:57:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:57:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-04 16:57:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:57:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:57:02 --> Final output sent to browser
DEBUG - 2025-05-04 16:57:02 --> Total execution time: 0.2151
INFO - 2025-05-04 08:57:05 --> Config Class Initialized
INFO - 2025-05-04 08:57:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:57:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:57:05 --> Utf8 Class Initialized
INFO - 2025-05-04 08:57:05 --> URI Class Initialized
INFO - 2025-05-04 08:57:05 --> Router Class Initialized
INFO - 2025-05-04 08:57:05 --> Output Class Initialized
INFO - 2025-05-04 08:57:05 --> Security Class Initialized
DEBUG - 2025-05-04 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:57:05 --> Input Class Initialized
INFO - 2025-05-04 08:57:05 --> Language Class Initialized
INFO - 2025-05-04 08:57:05 --> Loader Class Initialized
INFO - 2025-05-04 08:57:05 --> Helper loaded: url_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: string_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: form_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: file_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: html_helper
INFO - 2025-05-04 08:57:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:57:05 --> Controller Class Initialized
INFO - 2025-05-04 08:57:05 --> Config Class Initialized
INFO - 2025-05-04 08:57:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:57:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:57:05 --> Utf8 Class Initialized
INFO - 2025-05-04 08:57:05 --> URI Class Initialized
INFO - 2025-05-04 08:57:05 --> Router Class Initialized
INFO - 2025-05-04 08:57:05 --> Output Class Initialized
INFO - 2025-05-04 08:57:05 --> Security Class Initialized
DEBUG - 2025-05-04 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:57:05 --> Input Class Initialized
INFO - 2025-05-04 08:57:05 --> Language Class Initialized
INFO - 2025-05-04 08:57:05 --> Loader Class Initialized
INFO - 2025-05-04 08:57:05 --> Helper loaded: url_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: string_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: form_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: file_helper
INFO - 2025-05-04 08:57:05 --> Helper loaded: html_helper
INFO - 2025-05-04 08:57:05 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:57:05 --> Controller Class Initialized
INFO - 2025-05-04 16:57:05 --> Model "AuctionModel" initialized
INFO - 2025-05-04 08:58:21 --> Config Class Initialized
INFO - 2025-05-04 08:58:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 08:58:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 08:58:21 --> Utf8 Class Initialized
INFO - 2025-05-04 08:58:21 --> URI Class Initialized
INFO - 2025-05-04 08:58:21 --> Router Class Initialized
INFO - 2025-05-04 08:58:21 --> Output Class Initialized
INFO - 2025-05-04 08:58:21 --> Security Class Initialized
DEBUG - 2025-05-04 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 08:58:21 --> Input Class Initialized
INFO - 2025-05-04 08:58:21 --> Language Class Initialized
INFO - 2025-05-04 08:58:21 --> Loader Class Initialized
INFO - 2025-05-04 08:58:21 --> Helper loaded: url_helper
INFO - 2025-05-04 08:58:21 --> Helper loaded: string_helper
INFO - 2025-05-04 08:58:21 --> Helper loaded: form_helper
INFO - 2025-05-04 08:58:21 --> Helper loaded: file_helper
INFO - 2025-05-04 08:58:21 --> Helper loaded: html_helper
INFO - 2025-05-04 08:58:21 --> Database Driver Class Initialized
DEBUG - 2025-05-04 08:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 08:58:21 --> Controller Class Initialized
INFO - 2025-05-04 16:58:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 16:58:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 16:58:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-04 16:58:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 16:58:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 16:58:21 --> Final output sent to browser
DEBUG - 2025-05-04 16:58:21 --> Total execution time: 0.1506
INFO - 2025-05-04 18:07:47 --> Config Class Initialized
INFO - 2025-05-04 18:07:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 18:07:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 18:07:47 --> Utf8 Class Initialized
INFO - 2025-05-04 18:07:47 --> URI Class Initialized
DEBUG - 2025-05-04 18:07:47 --> No URI present. Default controller set.
INFO - 2025-05-04 18:07:47 --> Router Class Initialized
INFO - 2025-05-04 18:07:47 --> Output Class Initialized
INFO - 2025-05-04 18:07:47 --> Security Class Initialized
DEBUG - 2025-05-04 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 18:07:47 --> Input Class Initialized
INFO - 2025-05-04 18:07:47 --> Language Class Initialized
INFO - 2025-05-04 18:07:47 --> Loader Class Initialized
INFO - 2025-05-04 18:07:47 --> Helper loaded: url_helper
INFO - 2025-05-04 18:07:47 --> Helper loaded: string_helper
INFO - 2025-05-04 18:07:47 --> Helper loaded: form_helper
INFO - 2025-05-04 18:07:47 --> Helper loaded: file_helper
INFO - 2025-05-04 18:07:47 --> Helper loaded: html_helper
INFO - 2025-05-04 18:07:47 --> Database Driver Class Initialized
DEBUG - 2025-05-04 18:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 18:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 18:07:47 --> Controller Class Initialized
INFO - 2025-05-04 18:07:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-04 18:07:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-04 18:07:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-04 18:07:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-04 18:07:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-04 18:07:47 --> Final output sent to browser
DEBUG - 2025-05-04 18:07:47 --> Total execution time: 0.3418
INFO - 2025-05-04 18:08:06 --> Config Class Initialized
INFO - 2025-05-04 18:08:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 18:08:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 18:08:06 --> Utf8 Class Initialized
INFO - 2025-05-04 18:08:06 --> URI Class Initialized
INFO - 2025-05-04 18:08:06 --> Router Class Initialized
INFO - 2025-05-04 18:08:06 --> Output Class Initialized
INFO - 2025-05-04 18:08:06 --> Security Class Initialized
DEBUG - 2025-05-04 18:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 18:08:06 --> Input Class Initialized
INFO - 2025-05-04 18:08:06 --> Language Class Initialized
INFO - 2025-05-04 18:08:06 --> Loader Class Initialized
INFO - 2025-05-04 18:08:06 --> Helper loaded: url_helper
INFO - 2025-05-04 18:08:06 --> Helper loaded: string_helper
INFO - 2025-05-04 18:08:06 --> Helper loaded: form_helper
INFO - 2025-05-04 18:08:06 --> Helper loaded: file_helper
INFO - 2025-05-04 18:08:06 --> Helper loaded: html_helper
INFO - 2025-05-04 18:08:06 --> Database Driver Class Initialized
DEBUG - 2025-05-04 18:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-04 18:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 18:08:06 --> Controller Class Initialized
