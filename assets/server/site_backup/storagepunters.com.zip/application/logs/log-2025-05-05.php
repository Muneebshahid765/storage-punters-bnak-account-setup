<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-05 02:08:06 --> Model "AuctionModel" initialized
INFO - 2025-05-05 03:56:02 --> Config Class Initialized
INFO - 2025-05-05 03:56:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:02 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:02 --> URI Class Initialized
INFO - 2025-05-05 03:56:02 --> Router Class Initialized
INFO - 2025-05-05 03:56:03 --> Output Class Initialized
INFO - 2025-05-05 03:56:03 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:03 --> Input Class Initialized
INFO - 2025-05-05 03:56:03 --> Language Class Initialized
INFO - 2025-05-05 03:56:03 --> Loader Class Initialized
INFO - 2025-05-05 03:56:03 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:03 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:03 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:03 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:03 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:04 --> Controller Class Initialized
INFO - 2025-05-05 11:56:04 --> Model "UserModel" initialized
INFO - 2025-05-05 03:56:05 --> Config Class Initialized
INFO - 2025-05-05 03:56:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:05 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:05 --> URI Class Initialized
DEBUG - 2025-05-05 03:56:05 --> No URI present. Default controller set.
INFO - 2025-05-05 03:56:05 --> Router Class Initialized
INFO - 2025-05-05 03:56:05 --> Output Class Initialized
INFO - 2025-05-05 03:56:05 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:05 --> Input Class Initialized
INFO - 2025-05-05 03:56:05 --> Language Class Initialized
INFO - 2025-05-05 03:56:05 --> Loader Class Initialized
INFO - 2025-05-05 03:56:05 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:05 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:05 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:05 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:05 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:05 --> Controller Class Initialized
INFO - 2025-05-05 03:56:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 03:56:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 03:56:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 03:56:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 03:56:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 03:56:06 --> Final output sent to browser
DEBUG - 2025-05-05 03:56:06 --> Total execution time: 0.8264
INFO - 2025-05-05 03:56:10 --> Config Class Initialized
INFO - 2025-05-05 03:56:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:10 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:10 --> URI Class Initialized
INFO - 2025-05-05 03:56:10 --> Router Class Initialized
INFO - 2025-05-05 03:56:10 --> Output Class Initialized
INFO - 2025-05-05 03:56:10 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:10 --> Input Class Initialized
INFO - 2025-05-05 03:56:10 --> Language Class Initialized
INFO - 2025-05-05 03:56:10 --> Loader Class Initialized
INFO - 2025-05-05 03:56:10 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:10 --> Controller Class Initialized
INFO - 2025-05-05 11:56:10 --> Model "AuctionModel" initialized
INFO - 2025-05-05 03:56:10 --> Config Class Initialized
INFO - 2025-05-05 03:56:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:10 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:10 --> URI Class Initialized
INFO - 2025-05-05 03:56:10 --> Router Class Initialized
INFO - 2025-05-05 03:56:10 --> Output Class Initialized
INFO - 2025-05-05 03:56:10 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:10 --> Input Class Initialized
INFO - 2025-05-05 03:56:10 --> Language Class Initialized
INFO - 2025-05-05 03:56:10 --> Loader Class Initialized
INFO - 2025-05-05 03:56:10 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:10 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:10 --> Controller Class Initialized
INFO - 2025-05-05 03:56:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 03:56:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 03:56:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 03:56:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 03:56:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 03:56:11 --> Final output sent to browser
DEBUG - 2025-05-05 03:56:11 --> Total execution time: 0.2590
INFO - 2025-05-05 03:56:12 --> Config Class Initialized
INFO - 2025-05-05 03:56:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:12 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:12 --> URI Class Initialized
INFO - 2025-05-05 03:56:12 --> Config Class Initialized
INFO - 2025-05-05 03:56:12 --> Hooks Class Initialized
INFO - 2025-05-05 03:56:12 --> Router Class Initialized
INFO - 2025-05-05 03:56:12 --> Output Class Initialized
DEBUG - 2025-05-05 03:56:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:12 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:12 --> URI Class Initialized
INFO - 2025-05-05 03:56:12 --> Router Class Initialized
INFO - 2025-05-05 03:56:12 --> Security Class Initialized
INFO - 2025-05-05 03:56:12 --> Output Class Initialized
DEBUG - 2025-05-05 03:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:12 --> Input Class Initialized
INFO - 2025-05-05 03:56:12 --> Security Class Initialized
INFO - 2025-05-05 03:56:12 --> Language Class Initialized
DEBUG - 2025-05-05 03:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:12 --> Input Class Initialized
INFO - 2025-05-05 03:56:12 --> Language Class Initialized
INFO - 2025-05-05 03:56:12 --> Loader Class Initialized
INFO - 2025-05-05 03:56:12 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:12 --> Loader Class Initialized
INFO - 2025-05-05 03:56:12 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:12 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:12 --> Controller Class Initialized
INFO - 2025-05-05 03:56:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 11:56:12 --> Model "CompanyModel" initialized
INFO - 2025-05-05 11:56:12 --> Model "AuctionModel" initialized
INFO - 2025-05-05 11:56:12 --> Final output sent to browser
DEBUG - 2025-05-05 11:56:12 --> Total execution time: 0.7228
INFO - 2025-05-05 03:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:12 --> Controller Class Initialized
INFO - 2025-05-05 11:56:12 --> Model "AuctionModel" initialized
INFO - 2025-05-05 11:56:12 --> Final output sent to browser
DEBUG - 2025-05-05 11:56:12 --> Total execution time: 0.7478
INFO - 2025-05-05 03:56:13 --> Config Class Initialized
INFO - 2025-05-05 03:56:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:13 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:13 --> URI Class Initialized
INFO - 2025-05-05 03:56:13 --> Router Class Initialized
INFO - 2025-05-05 03:56:13 --> Output Class Initialized
INFO - 2025-05-05 03:56:13 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:13 --> Input Class Initialized
INFO - 2025-05-05 03:56:13 --> Language Class Initialized
INFO - 2025-05-05 03:56:13 --> Loader Class Initialized
INFO - 2025-05-05 03:56:13 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:13 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:13 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:13 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:13 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:13 --> Controller Class Initialized
INFO - 2025-05-05 03:56:13 --> Model "CompanyModel" initialized
INFO - 2025-05-05 03:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 03:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 03:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 03:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 03:56:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 03:56:13 --> Final output sent to browser
DEBUG - 2025-05-05 03:56:13 --> Total execution time: 0.1606
INFO - 2025-05-05 03:56:13 --> Config Class Initialized
INFO - 2025-05-05 03:56:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 03:56:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 03:56:13 --> Utf8 Class Initialized
INFO - 2025-05-05 03:56:13 --> URI Class Initialized
INFO - 2025-05-05 03:56:13 --> Router Class Initialized
INFO - 2025-05-05 03:56:13 --> Output Class Initialized
INFO - 2025-05-05 03:56:14 --> Security Class Initialized
DEBUG - 2025-05-05 03:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 03:56:14 --> Input Class Initialized
INFO - 2025-05-05 03:56:14 --> Language Class Initialized
INFO - 2025-05-05 03:56:14 --> Loader Class Initialized
INFO - 2025-05-05 03:56:14 --> Helper loaded: url_helper
INFO - 2025-05-05 03:56:14 --> Helper loaded: string_helper
INFO - 2025-05-05 03:56:14 --> Helper loaded: form_helper
INFO - 2025-05-05 03:56:14 --> Helper loaded: file_helper
INFO - 2025-05-05 03:56:14 --> Helper loaded: html_helper
INFO - 2025-05-05 03:56:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 03:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 03:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 03:56:14 --> Controller Class Initialized
INFO - 2025-05-05 11:56:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 11:56:14 --> Model "StaffModel" initialized
INFO - 2025-05-05 11:56:14 --> Final output sent to browser
DEBUG - 2025-05-05 11:56:14 --> Total execution time: 0.3770
INFO - 2025-05-05 04:08:05 --> Config Class Initialized
INFO - 2025-05-05 04:08:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 04:08:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 04:08:05 --> Utf8 Class Initialized
INFO - 2025-05-05 04:08:05 --> URI Class Initialized
INFO - 2025-05-05 04:08:05 --> Router Class Initialized
INFO - 2025-05-05 04:08:05 --> Output Class Initialized
INFO - 2025-05-05 04:08:05 --> Security Class Initialized
DEBUG - 2025-05-05 04:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 04:08:05 --> Input Class Initialized
INFO - 2025-05-05 04:08:05 --> Language Class Initialized
INFO - 2025-05-05 04:08:05 --> Loader Class Initialized
INFO - 2025-05-05 04:08:05 --> Helper loaded: url_helper
INFO - 2025-05-05 04:08:05 --> Helper loaded: string_helper
INFO - 2025-05-05 04:08:05 --> Helper loaded: form_helper
INFO - 2025-05-05 04:08:05 --> Helper loaded: file_helper
INFO - 2025-05-05 04:08:05 --> Helper loaded: html_helper
INFO - 2025-05-05 04:08:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 04:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 04:08:05 --> Controller Class Initialized
INFO - 2025-05-05 04:08:05 --> Model "CompanyModel" initialized
INFO - 2025-05-05 04:08:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 04:08:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 04:08:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 04:08:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 04:08:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 04:08:05 --> Final output sent to browser
DEBUG - 2025-05-05 04:08:05 --> Total execution time: 0.1411
INFO - 2025-05-05 04:08:06 --> Config Class Initialized
INFO - 2025-05-05 04:08:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 04:08:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 04:08:06 --> Utf8 Class Initialized
INFO - 2025-05-05 04:08:06 --> URI Class Initialized
INFO - 2025-05-05 04:08:06 --> Router Class Initialized
INFO - 2025-05-05 04:08:06 --> Output Class Initialized
INFO - 2025-05-05 04:08:06 --> Security Class Initialized
DEBUG - 2025-05-05 04:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 04:08:06 --> Input Class Initialized
INFO - 2025-05-05 04:08:06 --> Language Class Initialized
INFO - 2025-05-05 04:08:06 --> Loader Class Initialized
INFO - 2025-05-05 04:08:06 --> Helper loaded: url_helper
INFO - 2025-05-05 04:08:06 --> Helper loaded: string_helper
INFO - 2025-05-05 04:08:06 --> Helper loaded: form_helper
INFO - 2025-05-05 04:08:06 --> Helper loaded: file_helper
INFO - 2025-05-05 04:08:06 --> Helper loaded: html_helper
INFO - 2025-05-05 04:08:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 04:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 04:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 04:08:06 --> Controller Class Initialized
INFO - 2025-05-05 12:08:06 --> Model "CompanyModel" initialized
INFO - 2025-05-05 12:08:06 --> Model "StaffModel" initialized
INFO - 2025-05-05 12:08:06 --> Final output sent to browser
DEBUG - 2025-05-05 12:08:06 --> Total execution time: 0.2525
INFO - 2025-05-05 05:54:10 --> Config Class Initialized
INFO - 2025-05-05 05:54:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:54:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:54:10 --> Utf8 Class Initialized
INFO - 2025-05-05 05:54:10 --> URI Class Initialized
INFO - 2025-05-05 05:54:10 --> Router Class Initialized
INFO - 2025-05-05 05:54:10 --> Output Class Initialized
INFO - 2025-05-05 05:54:10 --> Security Class Initialized
DEBUG - 2025-05-05 05:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:54:10 --> Input Class Initialized
INFO - 2025-05-05 05:54:10 --> Language Class Initialized
INFO - 2025-05-05 05:54:10 --> Loader Class Initialized
INFO - 2025-05-05 05:54:10 --> Helper loaded: url_helper
INFO - 2025-05-05 05:54:10 --> Helper loaded: string_helper
INFO - 2025-05-05 05:54:10 --> Helper loaded: form_helper
INFO - 2025-05-05 05:54:10 --> Helper loaded: file_helper
INFO - 2025-05-05 05:54:10 --> Helper loaded: html_helper
INFO - 2025-05-05 05:54:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 05:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 05:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:54:10 --> Controller Class Initialized
INFO - 2025-05-05 05:54:10 --> Model "CompanyModel" initialized
INFO - 2025-05-05 05:54:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 05:54:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 05:54:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 05:54:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 05:54:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 05:54:10 --> Final output sent to browser
DEBUG - 2025-05-05 05:54:10 --> Total execution time: 0.1539
INFO - 2025-05-05 05:54:13 --> Config Class Initialized
INFO - 2025-05-05 05:54:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:54:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:54:13 --> Utf8 Class Initialized
INFO - 2025-05-05 05:54:13 --> URI Class Initialized
INFO - 2025-05-05 05:54:13 --> Router Class Initialized
INFO - 2025-05-05 05:54:13 --> Output Class Initialized
INFO - 2025-05-05 05:54:13 --> Security Class Initialized
DEBUG - 2025-05-05 05:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:54:13 --> Input Class Initialized
INFO - 2025-05-05 05:54:13 --> Language Class Initialized
INFO - 2025-05-05 05:54:13 --> Loader Class Initialized
INFO - 2025-05-05 05:54:13 --> Helper loaded: url_helper
INFO - 2025-05-05 05:54:13 --> Helper loaded: string_helper
INFO - 2025-05-05 05:54:13 --> Helper loaded: form_helper
INFO - 2025-05-05 05:54:13 --> Helper loaded: file_helper
INFO - 2025-05-05 05:54:13 --> Helper loaded: html_helper
INFO - 2025-05-05 05:54:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 05:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 05:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:54:13 --> Controller Class Initialized
INFO - 2025-05-05 13:54:13 --> Model "CompanyModel" initialized
INFO - 2025-05-05 13:54:13 --> Model "StaffModel" initialized
INFO - 2025-05-05 13:54:13 --> Final output sent to browser
DEBUG - 2025-05-05 13:54:13 --> Total execution time: 0.3275
INFO - 2025-05-05 05:55:02 --> Config Class Initialized
INFO - 2025-05-05 05:55:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:55:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:55:02 --> Utf8 Class Initialized
INFO - 2025-05-05 05:55:02 --> URI Class Initialized
INFO - 2025-05-05 05:55:02 --> Router Class Initialized
INFO - 2025-05-05 05:55:02 --> Output Class Initialized
INFO - 2025-05-05 05:55:02 --> Security Class Initialized
DEBUG - 2025-05-05 05:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:55:02 --> Input Class Initialized
INFO - 2025-05-05 05:55:02 --> Language Class Initialized
INFO - 2025-05-05 05:55:02 --> Loader Class Initialized
INFO - 2025-05-05 05:55:02 --> Helper loaded: url_helper
INFO - 2025-05-05 05:55:02 --> Helper loaded: string_helper
INFO - 2025-05-05 05:55:02 --> Helper loaded: form_helper
INFO - 2025-05-05 05:55:02 --> Helper loaded: file_helper
INFO - 2025-05-05 05:55:02 --> Helper loaded: html_helper
INFO - 2025-05-05 05:55:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 05:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 05:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:55:02 --> Controller Class Initialized
INFO - 2025-05-05 05:55:02 --> Model "CompanyModel" initialized
INFO - 2025-05-05 05:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 05:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 05:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 05:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 05:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 05:55:02 --> Final output sent to browser
DEBUG - 2025-05-05 05:55:02 --> Total execution time: 0.0862
INFO - 2025-05-05 05:55:03 --> Config Class Initialized
INFO - 2025-05-05 05:55:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:55:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:55:03 --> Utf8 Class Initialized
INFO - 2025-05-05 05:55:03 --> URI Class Initialized
INFO - 2025-05-05 05:55:03 --> Router Class Initialized
INFO - 2025-05-05 05:55:03 --> Output Class Initialized
INFO - 2025-05-05 05:55:03 --> Security Class Initialized
DEBUG - 2025-05-05 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:55:03 --> Input Class Initialized
INFO - 2025-05-05 05:55:03 --> Language Class Initialized
INFO - 2025-05-05 05:55:03 --> Loader Class Initialized
INFO - 2025-05-05 05:55:03 --> Helper loaded: url_helper
INFO - 2025-05-05 05:55:04 --> Helper loaded: string_helper
INFO - 2025-05-05 05:55:04 --> Helper loaded: form_helper
INFO - 2025-05-05 05:55:04 --> Helper loaded: file_helper
INFO - 2025-05-05 05:55:04 --> Helper loaded: html_helper
INFO - 2025-05-05 05:55:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 05:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 05:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:55:04 --> Controller Class Initialized
INFO - 2025-05-05 13:55:04 --> Model "CompanyModel" initialized
INFO - 2025-05-05 13:55:04 --> Model "StaffModel" initialized
INFO - 2025-05-05 13:55:04 --> Final output sent to browser
DEBUG - 2025-05-05 13:55:04 --> Total execution time: 0.1967
INFO - 2025-05-05 06:08:08 --> Config Class Initialized
INFO - 2025-05-05 06:08:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:08 --> URI Class Initialized
INFO - 2025-05-05 06:08:08 --> Router Class Initialized
INFO - 2025-05-05 06:08:08 --> Output Class Initialized
INFO - 2025-05-05 06:08:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:08 --> Input Class Initialized
INFO - 2025-05-05 06:08:08 --> Language Class Initialized
INFO - 2025-05-05 06:08:08 --> Loader Class Initialized
INFO - 2025-05-05 06:08:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:08 --> Controller Class Initialized
INFO - 2025-05-05 14:08:08 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:08:08 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:08:08 --> Config Class Initialized
INFO - 2025-05-05 06:08:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:08 --> URI Class Initialized
INFO - 2025-05-05 06:08:08 --> Router Class Initialized
INFO - 2025-05-05 06:08:08 --> Output Class Initialized
INFO - 2025-05-05 06:08:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:08 --> Input Class Initialized
INFO - 2025-05-05 06:08:08 --> Language Class Initialized
INFO - 2025-05-05 06:08:08 --> Loader Class Initialized
INFO - 2025-05-05 06:08:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:08 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:08 --> Controller Class Initialized
INFO - 2025-05-05 14:08:08 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:08:08 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:08:08 --> Final output sent to browser
DEBUG - 2025-05-05 14:08:08 --> Total execution time: 0.2087
INFO - 2025-05-05 06:08:31 --> Config Class Initialized
INFO - 2025-05-05 06:08:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:31 --> URI Class Initialized
INFO - 2025-05-05 06:08:31 --> Router Class Initialized
INFO - 2025-05-05 06:08:31 --> Output Class Initialized
INFO - 2025-05-05 06:08:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:31 --> Input Class Initialized
INFO - 2025-05-05 06:08:31 --> Language Class Initialized
INFO - 2025-05-05 06:08:31 --> Loader Class Initialized
INFO - 2025-05-05 06:08:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:31 --> Controller Class Initialized
INFO - 2025-05-05 06:08:31 --> Config Class Initialized
INFO - 2025-05-05 06:08:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:31 --> URI Class Initialized
DEBUG - 2025-05-05 06:08:31 --> No URI present. Default controller set.
INFO - 2025-05-05 06:08:31 --> Router Class Initialized
INFO - 2025-05-05 06:08:31 --> Output Class Initialized
INFO - 2025-05-05 06:08:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:31 --> Input Class Initialized
INFO - 2025-05-05 06:08:31 --> Language Class Initialized
INFO - 2025-05-05 06:08:31 --> Loader Class Initialized
INFO - 2025-05-05 06:08:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:31 --> Controller Class Initialized
INFO - 2025-05-05 06:08:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:08:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:08:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:08:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:08:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:08:31 --> Final output sent to browser
DEBUG - 2025-05-05 06:08:31 --> Total execution time: 0.1164
INFO - 2025-05-05 06:08:35 --> Config Class Initialized
INFO - 2025-05-05 06:08:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:35 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:35 --> URI Class Initialized
INFO - 2025-05-05 06:08:35 --> Router Class Initialized
INFO - 2025-05-05 06:08:35 --> Output Class Initialized
INFO - 2025-05-05 06:08:35 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:35 --> Input Class Initialized
INFO - 2025-05-05 06:08:35 --> Language Class Initialized
INFO - 2025-05-05 06:08:35 --> Loader Class Initialized
INFO - 2025-05-05 06:08:35 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:35 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:35 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:35 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:35 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:35 --> Controller Class Initialized
INFO - 2025-05-05 14:08:35 --> Model "AuctionModel" initialized
INFO - 2025-05-05 06:08:40 --> Config Class Initialized
INFO - 2025-05-05 06:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:40 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:40 --> URI Class Initialized
INFO - 2025-05-05 06:08:40 --> Router Class Initialized
INFO - 2025-05-05 06:08:40 --> Output Class Initialized
INFO - 2025-05-05 06:08:40 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:40 --> Input Class Initialized
INFO - 2025-05-05 06:08:40 --> Language Class Initialized
INFO - 2025-05-05 06:08:40 --> Loader Class Initialized
INFO - 2025-05-05 06:08:40 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:40 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:40 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:40 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:40 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:40 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:40 --> Controller Class Initialized
INFO - 2025-05-05 14:08:40 --> Model "UserModel" initialized
INFO - 2025-05-05 06:08:43 --> Config Class Initialized
INFO - 2025-05-05 06:08:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:43 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:43 --> URI Class Initialized
INFO - 2025-05-05 06:08:43 --> Router Class Initialized
INFO - 2025-05-05 06:08:43 --> Output Class Initialized
INFO - 2025-05-05 06:08:43 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:43 --> Input Class Initialized
INFO - 2025-05-05 06:08:43 --> Language Class Initialized
INFO - 2025-05-05 06:08:43 --> Loader Class Initialized
INFO - 2025-05-05 06:08:43 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:43 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:43 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:43 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:43 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:43 --> Controller Class Initialized
INFO - 2025-05-05 14:08:43 --> Model "UserModel" initialized
INFO - 2025-05-05 06:08:48 --> Config Class Initialized
INFO - 2025-05-05 06:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:48 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:48 --> URI Class Initialized
INFO - 2025-05-05 06:08:48 --> Router Class Initialized
INFO - 2025-05-05 06:08:48 --> Output Class Initialized
INFO - 2025-05-05 06:08:48 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:48 --> Input Class Initialized
INFO - 2025-05-05 06:08:48 --> Language Class Initialized
INFO - 2025-05-05 06:08:48 --> Loader Class Initialized
INFO - 2025-05-05 06:08:48 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:48 --> Controller Class Initialized
INFO - 2025-05-05 14:08:48 --> Model "UserModel" initialized
INFO - 2025-05-05 06:08:48 --> Config Class Initialized
INFO - 2025-05-05 06:08:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:48 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:48 --> URI Class Initialized
DEBUG - 2025-05-05 06:08:48 --> No URI present. Default controller set.
INFO - 2025-05-05 06:08:48 --> Router Class Initialized
INFO - 2025-05-05 06:08:48 --> Output Class Initialized
INFO - 2025-05-05 06:08:48 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:48 --> Input Class Initialized
INFO - 2025-05-05 06:08:48 --> Language Class Initialized
INFO - 2025-05-05 06:08:48 --> Loader Class Initialized
INFO - 2025-05-05 06:08:48 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:48 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:48 --> Controller Class Initialized
INFO - 2025-05-05 06:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:08:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:08:48 --> Final output sent to browser
DEBUG - 2025-05-05 06:08:48 --> Total execution time: 0.1559
INFO - 2025-05-05 06:08:50 --> Config Class Initialized
INFO - 2025-05-05 06:08:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:50 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:50 --> URI Class Initialized
INFO - 2025-05-05 06:08:50 --> Router Class Initialized
INFO - 2025-05-05 06:08:50 --> Output Class Initialized
INFO - 2025-05-05 06:08:50 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:50 --> Input Class Initialized
INFO - 2025-05-05 06:08:50 --> Language Class Initialized
INFO - 2025-05-05 06:08:50 --> Loader Class Initialized
INFO - 2025-05-05 06:08:50 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:50 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:50 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:50 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:50 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:50 --> Controller Class Initialized
INFO - 2025-05-05 14:08:50 --> Model "AuctionModel" initialized
INFO - 2025-05-05 06:08:51 --> Config Class Initialized
INFO - 2025-05-05 06:08:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:51 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:51 --> URI Class Initialized
INFO - 2025-05-05 06:08:51 --> Router Class Initialized
INFO - 2025-05-05 06:08:51 --> Output Class Initialized
INFO - 2025-05-05 06:08:51 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:51 --> Input Class Initialized
INFO - 2025-05-05 06:08:51 --> Language Class Initialized
INFO - 2025-05-05 06:08:51 --> Loader Class Initialized
INFO - 2025-05-05 06:08:51 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:51 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:51 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:51 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:51 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:51 --> Controller Class Initialized
INFO - 2025-05-05 06:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 06:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:08:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:08:51 --> Final output sent to browser
DEBUG - 2025-05-05 06:08:51 --> Total execution time: 0.1400
INFO - 2025-05-05 06:08:52 --> Config Class Initialized
INFO - 2025-05-05 06:08:52 --> Config Class Initialized
INFO - 2025-05-05 06:08:52 --> Hooks Class Initialized
INFO - 2025-05-05 06:08:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:52 --> Utf8 Class Initialized
DEBUG - 2025-05-05 06:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:52 --> URI Class Initialized
INFO - 2025-05-05 06:08:52 --> URI Class Initialized
INFO - 2025-05-05 06:08:52 --> Router Class Initialized
INFO - 2025-05-05 06:08:52 --> Router Class Initialized
INFO - 2025-05-05 06:08:52 --> Output Class Initialized
INFO - 2025-05-05 06:08:52 --> Output Class Initialized
INFO - 2025-05-05 06:08:52 --> Security Class Initialized
INFO - 2025-05-05 06:08:52 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:52 --> Input Class Initialized
DEBUG - 2025-05-05 06:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:52 --> Input Class Initialized
INFO - 2025-05-05 06:08:52 --> Language Class Initialized
INFO - 2025-05-05 06:08:52 --> Language Class Initialized
INFO - 2025-05-05 06:08:52 --> Loader Class Initialized
INFO - 2025-05-05 06:08:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:52 --> Loader Class Initialized
INFO - 2025-05-05 06:08:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:52 --> Database Driver Class Initialized
INFO - 2025-05-05 06:08:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:52 --> Controller Class Initialized
INFO - 2025-05-05 14:08:52 --> Model "CompanyModel" initialized
DEBUG - 2025-05-05 06:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:52 --> Controller Class Initialized
INFO - 2025-05-05 14:08:52 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:08:52 --> Final output sent to browser
DEBUG - 2025-05-05 14:08:52 --> Total execution time: 0.1427
INFO - 2025-05-05 06:08:52 --> Config Class Initialized
INFO - 2025-05-05 06:08:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:52 --> URI Class Initialized
INFO - 2025-05-05 06:08:52 --> Router Class Initialized
INFO - 2025-05-05 06:08:52 --> Output Class Initialized
INFO - 2025-05-05 06:08:52 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:52 --> Input Class Initialized
INFO - 2025-05-05 06:08:52 --> Language Class Initialized
INFO - 2025-05-05 06:08:52 --> Loader Class Initialized
INFO - 2025-05-05 06:08:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:52 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:52 --> Controller Class Initialized
INFO - 2025-05-05 06:08:52 --> Model "UserModel" initialized
INFO - 2025-05-05 06:08:53 --> Config Class Initialized
INFO - 2025-05-05 06:08:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:53 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:53 --> URI Class Initialized
INFO - 2025-05-05 06:08:53 --> Router Class Initialized
INFO - 2025-05-05 06:08:53 --> Output Class Initialized
INFO - 2025-05-05 06:08:53 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:53 --> Input Class Initialized
INFO - 2025-05-05 06:08:53 --> Language Class Initialized
INFO - 2025-05-05 06:08:53 --> Loader Class Initialized
INFO - 2025-05-05 06:08:53 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:53 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:53 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:53 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:53 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:53 --> Controller Class Initialized
INFO - 2025-05-05 14:08:53 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:08:54 --> Config Class Initialized
INFO - 2025-05-05 06:08:54 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:54 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:54 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:54 --> URI Class Initialized
INFO - 2025-05-05 06:08:54 --> Router Class Initialized
INFO - 2025-05-05 06:08:54 --> Output Class Initialized
INFO - 2025-05-05 06:08:54 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:54 --> Input Class Initialized
INFO - 2025-05-05 06:08:54 --> Language Class Initialized
INFO - 2025-05-05 06:08:54 --> Loader Class Initialized
INFO - 2025-05-05 06:08:54 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:54 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:54 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:54 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:54 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:54 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:54 --> Controller Class Initialized
INFO - 2025-05-05 14:08:54 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:08:56 --> Config Class Initialized
INFO - 2025-05-05 06:08:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:56 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:56 --> URI Class Initialized
INFO - 2025-05-05 06:08:56 --> Router Class Initialized
INFO - 2025-05-05 06:08:56 --> Output Class Initialized
INFO - 2025-05-05 06:08:56 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:56 --> Input Class Initialized
INFO - 2025-05-05 06:08:56 --> Language Class Initialized
INFO - 2025-05-05 06:08:56 --> Loader Class Initialized
INFO - 2025-05-05 06:08:56 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:56 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:56 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:56 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:56 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:56 --> Controller Class Initialized
INFO - 2025-05-05 14:08:56 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:08:57 --> Config Class Initialized
INFO - 2025-05-05 06:08:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:57 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:57 --> URI Class Initialized
INFO - 2025-05-05 06:08:57 --> Router Class Initialized
INFO - 2025-05-05 06:08:57 --> Output Class Initialized
INFO - 2025-05-05 06:08:57 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:57 --> Input Class Initialized
INFO - 2025-05-05 06:08:57 --> Language Class Initialized
INFO - 2025-05-05 06:08:57 --> Loader Class Initialized
INFO - 2025-05-05 06:08:57 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:57 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:57 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:57 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:57 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:57 --> Controller Class Initialized
INFO - 2025-05-05 14:08:57 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:08:58 --> Config Class Initialized
INFO - 2025-05-05 06:08:58 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:08:58 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:08:58 --> Utf8 Class Initialized
INFO - 2025-05-05 06:08:58 --> URI Class Initialized
INFO - 2025-05-05 06:08:58 --> Router Class Initialized
INFO - 2025-05-05 06:08:58 --> Output Class Initialized
INFO - 2025-05-05 06:08:58 --> Security Class Initialized
DEBUG - 2025-05-05 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:08:58 --> Input Class Initialized
INFO - 2025-05-05 06:08:58 --> Language Class Initialized
INFO - 2025-05-05 06:08:58 --> Loader Class Initialized
INFO - 2025-05-05 06:08:58 --> Helper loaded: url_helper
INFO - 2025-05-05 06:08:58 --> Helper loaded: string_helper
INFO - 2025-05-05 06:08:58 --> Helper loaded: form_helper
INFO - 2025-05-05 06:08:58 --> Helper loaded: file_helper
INFO - 2025-05-05 06:08:58 --> Helper loaded: html_helper
INFO - 2025-05-05 06:08:58 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:08:58 --> Controller Class Initialized
INFO - 2025-05-05 14:08:58 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:11:06 --> Config Class Initialized
INFO - 2025-05-05 06:11:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:06 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:06 --> URI Class Initialized
INFO - 2025-05-05 06:11:06 --> Router Class Initialized
INFO - 2025-05-05 06:11:06 --> Output Class Initialized
INFO - 2025-05-05 06:11:06 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:06 --> Input Class Initialized
INFO - 2025-05-05 06:11:06 --> Language Class Initialized
INFO - 2025-05-05 06:11:06 --> Loader Class Initialized
INFO - 2025-05-05 06:11:06 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:06 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:06 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:06 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:06 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:06 --> Controller Class Initialized
INFO - 2025-05-05 06:11:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:11:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:11:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-05 06:11:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:11:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:11:06 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:06 --> Total execution time: 0.1032
INFO - 2025-05-05 06:11:07 --> Config Class Initialized
INFO - 2025-05-05 06:11:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:07 --> URI Class Initialized
INFO - 2025-05-05 06:11:07 --> Router Class Initialized
INFO - 2025-05-05 06:11:07 --> Output Class Initialized
INFO - 2025-05-05 06:11:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:07 --> Input Class Initialized
INFO - 2025-05-05 06:11:07 --> Language Class Initialized
INFO - 2025-05-05 06:11:07 --> Loader Class Initialized
INFO - 2025-05-05 06:11:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:07 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:07 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:07 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:07 --> Controller Class Initialized
INFO - 2025-05-05 14:11:07 --> Model "UserModel" initialized
INFO - 2025-05-05 14:11:07 --> Final output sent to browser
DEBUG - 2025-05-05 14:11:07 --> Total execution time: 0.1618
INFO - 2025-05-05 06:11:19 --> Config Class Initialized
INFO - 2025-05-05 06:11:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:19 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:19 --> URI Class Initialized
INFO - 2025-05-05 06:11:19 --> Router Class Initialized
INFO - 2025-05-05 06:11:19 --> Output Class Initialized
INFO - 2025-05-05 06:11:19 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:19 --> Input Class Initialized
INFO - 2025-05-05 06:11:19 --> Language Class Initialized
INFO - 2025-05-05 06:11:19 --> Loader Class Initialized
INFO - 2025-05-05 06:11:19 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:19 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:19 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:19 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:19 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:19 --> Controller Class Initialized
INFO - 2025-05-05 06:11:20 --> Config Class Initialized
INFO - 2025-05-05 06:11:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:20 --> URI Class Initialized
DEBUG - 2025-05-05 06:11:20 --> No URI present. Default controller set.
INFO - 2025-05-05 06:11:20 --> Router Class Initialized
INFO - 2025-05-05 06:11:20 --> Output Class Initialized
INFO - 2025-05-05 06:11:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:20 --> Input Class Initialized
INFO - 2025-05-05 06:11:20 --> Language Class Initialized
INFO - 2025-05-05 06:11:20 --> Loader Class Initialized
INFO - 2025-05-05 06:11:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:20 --> Controller Class Initialized
INFO - 2025-05-05 06:11:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:11:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:11:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:11:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:11:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:11:20 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:20 --> Total execution time: 0.1396
INFO - 2025-05-05 06:11:20 --> Config Class Initialized
INFO - 2025-05-05 06:11:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:20 --> URI Class Initialized
INFO - 2025-05-05 06:11:20 --> Router Class Initialized
INFO - 2025-05-05 06:11:20 --> Output Class Initialized
INFO - 2025-05-05 06:11:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:20 --> Input Class Initialized
INFO - 2025-05-05 06:11:20 --> Language Class Initialized
INFO - 2025-05-05 06:11:20 --> Loader Class Initialized
INFO - 2025-05-05 06:11:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:21 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:21 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:21 --> Controller Class Initialized
INFO - 2025-05-05 14:11:21 --> Model "AuctionModel" initialized
INFO - 2025-05-05 06:11:22 --> Config Class Initialized
INFO - 2025-05-05 06:11:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:22 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:22 --> URI Class Initialized
INFO - 2025-05-05 06:11:22 --> Router Class Initialized
INFO - 2025-05-05 06:11:22 --> Output Class Initialized
INFO - 2025-05-05 06:11:22 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:22 --> Input Class Initialized
INFO - 2025-05-05 06:11:22 --> Language Class Initialized
INFO - 2025-05-05 06:11:22 --> Loader Class Initialized
INFO - 2025-05-05 06:11:22 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:22 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:22 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:22 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:22 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:22 --> Controller Class Initialized
INFO - 2025-05-05 06:11:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:11:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:11:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 06:11:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:11:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:11:22 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:22 --> Total execution time: 0.1469
INFO - 2025-05-05 06:11:23 --> Config Class Initialized
INFO - 2025-05-05 06:11:23 --> Hooks Class Initialized
INFO - 2025-05-05 06:11:23 --> Config Class Initialized
INFO - 2025-05-05 06:11:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:23 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:23 --> URI Class Initialized
DEBUG - 2025-05-05 06:11:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:23 --> Router Class Initialized
INFO - 2025-05-05 06:11:23 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:23 --> URI Class Initialized
INFO - 2025-05-05 06:11:23 --> Output Class Initialized
INFO - 2025-05-05 06:11:23 --> Router Class Initialized
INFO - 2025-05-05 06:11:23 --> Security Class Initialized
INFO - 2025-05-05 06:11:23 --> Output Class Initialized
INFO - 2025-05-05 06:11:23 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-05 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:23 --> Input Class Initialized
INFO - 2025-05-05 06:11:23 --> Input Class Initialized
INFO - 2025-05-05 06:11:23 --> Language Class Initialized
INFO - 2025-05-05 06:11:23 --> Language Class Initialized
INFO - 2025-05-05 06:11:23 --> Loader Class Initialized
INFO - 2025-05-05 06:11:23 --> Loader Class Initialized
INFO - 2025-05-05 06:11:23 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:23 --> Database Driver Class Initialized
INFO - 2025-05-05 06:11:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-05 06:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:23 --> Controller Class Initialized
INFO - 2025-05-05 14:11:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:23 --> Controller Class Initialized
INFO - 2025-05-05 14:11:23 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:11:23 --> Final output sent to browser
DEBUG - 2025-05-05 14:11:23 --> Total execution time: 0.1319
INFO - 2025-05-05 06:11:23 --> Config Class Initialized
INFO - 2025-05-05 06:11:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:23 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:23 --> URI Class Initialized
INFO - 2025-05-05 06:11:23 --> Router Class Initialized
INFO - 2025-05-05 06:11:23 --> Output Class Initialized
INFO - 2025-05-05 06:11:23 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:23 --> Input Class Initialized
INFO - 2025-05-05 06:11:23 --> Language Class Initialized
INFO - 2025-05-05 06:11:23 --> Loader Class Initialized
INFO - 2025-05-05 06:11:23 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:23 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:23 --> Controller Class Initialized
INFO - 2025-05-05 06:11:23 --> Model "UserModel" initialized
INFO - 2025-05-05 06:11:26 --> Config Class Initialized
INFO - 2025-05-05 06:11:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:26 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:26 --> URI Class Initialized
INFO - 2025-05-05 06:11:26 --> Router Class Initialized
INFO - 2025-05-05 06:11:26 --> Output Class Initialized
INFO - 2025-05-05 06:11:26 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:26 --> Input Class Initialized
INFO - 2025-05-05 06:11:26 --> Language Class Initialized
INFO - 2025-05-05 06:11:26 --> Loader Class Initialized
INFO - 2025-05-05 06:11:26 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:26 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:26 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:26 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:26 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:26 --> Controller Class Initialized
INFO - 2025-05-05 14:11:26 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:11:27 --> Config Class Initialized
INFO - 2025-05-05 06:11:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:27 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:27 --> URI Class Initialized
INFO - 2025-05-05 06:11:27 --> Router Class Initialized
INFO - 2025-05-05 06:11:27 --> Output Class Initialized
INFO - 2025-05-05 06:11:27 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:27 --> Input Class Initialized
INFO - 2025-05-05 06:11:27 --> Language Class Initialized
INFO - 2025-05-05 06:11:27 --> Loader Class Initialized
INFO - 2025-05-05 06:11:27 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:27 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:27 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:27 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:27 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:27 --> Controller Class Initialized
INFO - 2025-05-05 14:11:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:11:36 --> Config Class Initialized
INFO - 2025-05-05 06:11:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:36 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:36 --> URI Class Initialized
INFO - 2025-05-05 06:11:36 --> Router Class Initialized
INFO - 2025-05-05 06:11:36 --> Output Class Initialized
INFO - 2025-05-05 06:11:36 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:36 --> Input Class Initialized
INFO - 2025-05-05 06:11:36 --> Language Class Initialized
INFO - 2025-05-05 06:11:36 --> Loader Class Initialized
INFO - 2025-05-05 06:11:36 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:36 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:36 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:36 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:36 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:36 --> Controller Class Initialized
INFO - 2025-05-05 06:11:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:11:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:11:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 06:11:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:11:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:11:36 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:36 --> Total execution time: 0.1444
INFO - 2025-05-05 06:11:39 --> Config Class Initialized
INFO - 2025-05-05 06:11:39 --> Hooks Class Initialized
INFO - 2025-05-05 06:11:39 --> Config Class Initialized
DEBUG - 2025-05-05 06:11:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:39 --> Hooks Class Initialized
INFO - 2025-05-05 06:11:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:39 --> URI Class Initialized
DEBUG - 2025-05-05 06:11:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:39 --> Router Class Initialized
INFO - 2025-05-05 06:11:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:39 --> Output Class Initialized
INFO - 2025-05-05 06:11:39 --> URI Class Initialized
INFO - 2025-05-05 06:11:39 --> Router Class Initialized
INFO - 2025-05-05 06:11:39 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:39 --> Output Class Initialized
INFO - 2025-05-05 06:11:39 --> Input Class Initialized
INFO - 2025-05-05 06:11:39 --> Security Class Initialized
INFO - 2025-05-05 06:11:39 --> Language Class Initialized
DEBUG - 2025-05-05 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:39 --> Input Class Initialized
INFO - 2025-05-05 06:11:39 --> Loader Class Initialized
INFO - 2025-05-05 06:11:39 --> Language Class Initialized
INFO - 2025-05-05 06:11:39 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:39 --> Loader Class Initialized
INFO - 2025-05-05 06:11:39 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:39 --> Database Driver Class Initialized
INFO - 2025-05-05 06:11:39 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:39 --> Controller Class Initialized
INFO - 2025-05-05 14:11:39 --> Model "CompanyModel" initialized
DEBUG - 2025-05-05 06:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 14:11:39 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 14:11:39 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:11:39 --> Final output sent to browser
DEBUG - 2025-05-05 14:11:39 --> Total execution time: 0.1921
INFO - 2025-05-05 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:39 --> Controller Class Initialized
INFO - 2025-05-05 14:11:39 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:11:39 --> Final output sent to browser
DEBUG - 2025-05-05 14:11:39 --> Total execution time: 0.1967
INFO - 2025-05-05 06:11:39 --> Config Class Initialized
INFO - 2025-05-05 06:11:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:39 --> URI Class Initialized
INFO - 2025-05-05 06:11:39 --> Router Class Initialized
INFO - 2025-05-05 06:11:39 --> Output Class Initialized
INFO - 2025-05-05 06:11:39 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:39 --> Input Class Initialized
INFO - 2025-05-05 06:11:39 --> Language Class Initialized
INFO - 2025-05-05 06:11:39 --> Loader Class Initialized
INFO - 2025-05-05 06:11:39 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:39 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:39 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:39 --> Controller Class Initialized
INFO - 2025-05-05 06:11:39 --> Model "UserModel" initialized
INFO - 2025-05-05 06:11:39 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:39 --> Total execution time: 0.0692
INFO - 2025-05-05 06:11:42 --> Config Class Initialized
INFO - 2025-05-05 06:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:42 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:42 --> URI Class Initialized
INFO - 2025-05-05 06:11:42 --> Router Class Initialized
INFO - 2025-05-05 06:11:42 --> Output Class Initialized
INFO - 2025-05-05 06:11:42 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:42 --> Input Class Initialized
INFO - 2025-05-05 06:11:42 --> Language Class Initialized
INFO - 2025-05-05 06:11:42 --> Loader Class Initialized
INFO - 2025-05-05 06:11:42 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:42 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:42 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:42 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:42 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:42 --> Controller Class Initialized
INFO - 2025-05-05 06:11:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:11:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:11:42 --> Final output sent to browser
DEBUG - 2025-05-05 06:11:42 --> Total execution time: 0.1004
INFO - 2025-05-05 06:11:44 --> Config Class Initialized
INFO - 2025-05-05 06:11:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:11:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:11:44 --> Utf8 Class Initialized
INFO - 2025-05-05 06:11:44 --> URI Class Initialized
INFO - 2025-05-05 06:11:44 --> Router Class Initialized
INFO - 2025-05-05 06:11:44 --> Output Class Initialized
INFO - 2025-05-05 06:11:44 --> Security Class Initialized
DEBUG - 2025-05-05 06:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:11:44 --> Input Class Initialized
INFO - 2025-05-05 06:11:44 --> Language Class Initialized
INFO - 2025-05-05 06:11:44 --> Loader Class Initialized
INFO - 2025-05-05 06:11:44 --> Helper loaded: url_helper
INFO - 2025-05-05 06:11:44 --> Helper loaded: string_helper
INFO - 2025-05-05 06:11:44 --> Helper loaded: form_helper
INFO - 2025-05-05 06:11:44 --> Helper loaded: file_helper
INFO - 2025-05-05 06:11:44 --> Helper loaded: html_helper
INFO - 2025-05-05 06:11:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:11:44 --> Controller Class Initialized
INFO - 2025-05-05 14:11:44 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:11:44 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:11:44 --> Final output sent to browser
DEBUG - 2025-05-05 14:11:44 --> Total execution time: 0.1206
INFO - 2025-05-05 06:15:45 --> Config Class Initialized
INFO - 2025-05-05 06:15:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:15:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:15:45 --> Utf8 Class Initialized
INFO - 2025-05-05 06:15:45 --> URI Class Initialized
INFO - 2025-05-05 06:15:45 --> Router Class Initialized
INFO - 2025-05-05 06:15:45 --> Output Class Initialized
INFO - 2025-05-05 06:15:45 --> Security Class Initialized
DEBUG - 2025-05-05 06:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:15:45 --> Input Class Initialized
INFO - 2025-05-05 06:15:45 --> Language Class Initialized
INFO - 2025-05-05 06:15:45 --> Loader Class Initialized
INFO - 2025-05-05 06:15:45 --> Helper loaded: url_helper
INFO - 2025-05-05 06:15:45 --> Helper loaded: string_helper
INFO - 2025-05-05 06:15:45 --> Helper loaded: form_helper
INFO - 2025-05-05 06:15:45 --> Helper loaded: file_helper
INFO - 2025-05-05 06:15:45 --> Helper loaded: html_helper
INFO - 2025-05-05 06:15:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:15:45 --> Controller Class Initialized
INFO - 2025-05-05 06:15:45 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:15:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:15:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:15:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:15:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:15:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:15:45 --> Final output sent to browser
DEBUG - 2025-05-05 06:15:45 --> Total execution time: 0.1976
INFO - 2025-05-05 06:15:49 --> Config Class Initialized
INFO - 2025-05-05 06:15:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:15:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:15:49 --> Utf8 Class Initialized
INFO - 2025-05-05 06:15:49 --> URI Class Initialized
INFO - 2025-05-05 06:15:49 --> Router Class Initialized
INFO - 2025-05-05 06:15:49 --> Output Class Initialized
INFO - 2025-05-05 06:15:49 --> Security Class Initialized
DEBUG - 2025-05-05 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:15:49 --> Input Class Initialized
INFO - 2025-05-05 06:15:49 --> Language Class Initialized
INFO - 2025-05-05 06:15:49 --> Loader Class Initialized
INFO - 2025-05-05 06:15:50 --> Helper loaded: url_helper
INFO - 2025-05-05 06:15:50 --> Helper loaded: string_helper
INFO - 2025-05-05 06:15:50 --> Helper loaded: form_helper
INFO - 2025-05-05 06:15:50 --> Helper loaded: file_helper
INFO - 2025-05-05 06:15:50 --> Helper loaded: html_helper
INFO - 2025-05-05 06:15:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:15:50 --> Controller Class Initialized
INFO - 2025-05-05 14:15:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:15:50 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:15:50 --> Final output sent to browser
DEBUG - 2025-05-05 14:15:50 --> Total execution time: 0.1774
INFO - 2025-05-05 06:16:17 --> Config Class Initialized
INFO - 2025-05-05 06:16:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:16:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:16:17 --> Utf8 Class Initialized
INFO - 2025-05-05 06:16:17 --> URI Class Initialized
INFO - 2025-05-05 06:16:17 --> Router Class Initialized
INFO - 2025-05-05 06:16:17 --> Output Class Initialized
INFO - 2025-05-05 06:16:17 --> Security Class Initialized
DEBUG - 2025-05-05 06:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:16:17 --> Input Class Initialized
INFO - 2025-05-05 06:16:17 --> Language Class Initialized
INFO - 2025-05-05 06:16:17 --> Loader Class Initialized
INFO - 2025-05-05 06:16:17 --> Helper loaded: url_helper
INFO - 2025-05-05 06:16:17 --> Helper loaded: string_helper
INFO - 2025-05-05 06:16:17 --> Helper loaded: form_helper
INFO - 2025-05-05 06:16:17 --> Helper loaded: file_helper
INFO - 2025-05-05 06:16:17 --> Helper loaded: html_helper
INFO - 2025-05-05 06:16:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:16:17 --> Controller Class Initialized
INFO - 2025-05-05 06:16:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:16:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:16:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:16:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:16:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:16:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:16:17 --> Final output sent to browser
DEBUG - 2025-05-05 06:16:17 --> Total execution time: 0.0961
INFO - 2025-05-05 06:16:18 --> Config Class Initialized
INFO - 2025-05-05 06:16:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:16:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:16:18 --> Utf8 Class Initialized
INFO - 2025-05-05 06:16:18 --> URI Class Initialized
INFO - 2025-05-05 06:16:18 --> Router Class Initialized
INFO - 2025-05-05 06:16:18 --> Output Class Initialized
INFO - 2025-05-05 06:16:18 --> Security Class Initialized
DEBUG - 2025-05-05 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:16:18 --> Input Class Initialized
INFO - 2025-05-05 06:16:18 --> Language Class Initialized
INFO - 2025-05-05 06:16:18 --> Loader Class Initialized
INFO - 2025-05-05 06:16:18 --> Helper loaded: url_helper
INFO - 2025-05-05 06:16:18 --> Helper loaded: string_helper
INFO - 2025-05-05 06:16:18 --> Helper loaded: form_helper
INFO - 2025-05-05 06:16:18 --> Helper loaded: file_helper
INFO - 2025-05-05 06:16:18 --> Helper loaded: html_helper
INFO - 2025-05-05 06:16:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:16:18 --> Controller Class Initialized
INFO - 2025-05-05 14:16:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:16:18 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:16:18 --> Final output sent to browser
DEBUG - 2025-05-05 14:16:18 --> Total execution time: 0.2694
INFO - 2025-05-05 06:18:14 --> Config Class Initialized
INFO - 2025-05-05 06:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:18:14 --> Utf8 Class Initialized
INFO - 2025-05-05 06:18:14 --> URI Class Initialized
INFO - 2025-05-05 06:18:14 --> Router Class Initialized
INFO - 2025-05-05 06:18:14 --> Output Class Initialized
INFO - 2025-05-05 06:18:14 --> Security Class Initialized
DEBUG - 2025-05-05 06:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:18:14 --> Input Class Initialized
INFO - 2025-05-05 06:18:14 --> Language Class Initialized
INFO - 2025-05-05 06:18:14 --> Loader Class Initialized
INFO - 2025-05-05 06:18:14 --> Helper loaded: url_helper
INFO - 2025-05-05 06:18:14 --> Helper loaded: string_helper
INFO - 2025-05-05 06:18:14 --> Helper loaded: form_helper
INFO - 2025-05-05 06:18:14 --> Helper loaded: file_helper
INFO - 2025-05-05 06:18:14 --> Helper loaded: html_helper
INFO - 2025-05-05 06:18:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:18:14 --> Controller Class Initialized
INFO - 2025-05-05 06:18:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:18:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:18:14 --> Final output sent to browser
DEBUG - 2025-05-05 06:18:14 --> Total execution time: 0.1030
INFO - 2025-05-05 06:18:17 --> Config Class Initialized
INFO - 2025-05-05 06:18:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:18:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:18:17 --> Utf8 Class Initialized
INFO - 2025-05-05 06:18:17 --> URI Class Initialized
INFO - 2025-05-05 06:18:17 --> Router Class Initialized
INFO - 2025-05-05 06:18:17 --> Output Class Initialized
INFO - 2025-05-05 06:18:17 --> Security Class Initialized
DEBUG - 2025-05-05 06:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:18:17 --> Input Class Initialized
INFO - 2025-05-05 06:18:17 --> Language Class Initialized
INFO - 2025-05-05 06:18:17 --> Loader Class Initialized
INFO - 2025-05-05 06:18:17 --> Helper loaded: url_helper
INFO - 2025-05-05 06:18:17 --> Helper loaded: string_helper
INFO - 2025-05-05 06:18:17 --> Helper loaded: form_helper
INFO - 2025-05-05 06:18:17 --> Helper loaded: file_helper
INFO - 2025-05-05 06:18:17 --> Helper loaded: html_helper
INFO - 2025-05-05 06:18:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:18:17 --> Controller Class Initialized
INFO - 2025-05-05 14:18:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:18:17 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:18:17 --> Final output sent to browser
DEBUG - 2025-05-05 14:18:17 --> Total execution time: 0.1485
INFO - 2025-05-05 06:20:33 --> Config Class Initialized
INFO - 2025-05-05 06:20:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:20:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:20:33 --> Utf8 Class Initialized
INFO - 2025-05-05 06:20:33 --> URI Class Initialized
INFO - 2025-05-05 06:20:33 --> Router Class Initialized
INFO - 2025-05-05 06:20:33 --> Output Class Initialized
INFO - 2025-05-05 06:20:33 --> Security Class Initialized
DEBUG - 2025-05-05 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:20:33 --> Input Class Initialized
INFO - 2025-05-05 06:20:33 --> Language Class Initialized
INFO - 2025-05-05 06:20:33 --> Loader Class Initialized
INFO - 2025-05-05 06:20:33 --> Helper loaded: url_helper
INFO - 2025-05-05 06:20:33 --> Helper loaded: string_helper
INFO - 2025-05-05 06:20:33 --> Helper loaded: form_helper
INFO - 2025-05-05 06:20:33 --> Helper loaded: file_helper
INFO - 2025-05-05 06:20:33 --> Helper loaded: html_helper
INFO - 2025-05-05 06:20:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:20:33 --> Controller Class Initialized
INFO - 2025-05-05 06:20:33 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:20:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:20:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:20:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:20:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:20:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:20:33 --> Final output sent to browser
DEBUG - 2025-05-05 06:20:33 --> Total execution time: 0.0686
INFO - 2025-05-05 06:20:36 --> Config Class Initialized
INFO - 2025-05-05 06:20:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:20:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:20:36 --> Utf8 Class Initialized
INFO - 2025-05-05 06:20:36 --> URI Class Initialized
INFO - 2025-05-05 06:20:36 --> Router Class Initialized
INFO - 2025-05-05 06:20:36 --> Output Class Initialized
INFO - 2025-05-05 06:20:36 --> Security Class Initialized
DEBUG - 2025-05-05 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:20:36 --> Input Class Initialized
INFO - 2025-05-05 06:20:36 --> Language Class Initialized
INFO - 2025-05-05 06:20:36 --> Loader Class Initialized
INFO - 2025-05-05 06:20:36 --> Helper loaded: url_helper
INFO - 2025-05-05 06:20:36 --> Helper loaded: string_helper
INFO - 2025-05-05 06:20:36 --> Helper loaded: form_helper
INFO - 2025-05-05 06:20:36 --> Helper loaded: file_helper
INFO - 2025-05-05 06:20:36 --> Helper loaded: html_helper
INFO - 2025-05-05 06:20:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:20:36 --> Controller Class Initialized
INFO - 2025-05-05 14:20:36 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:20:36 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:20:36 --> Final output sent to browser
DEBUG - 2025-05-05 14:20:36 --> Total execution time: 0.0957
INFO - 2025-05-05 06:20:53 --> Config Class Initialized
INFO - 2025-05-05 06:20:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:20:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:20:53 --> Utf8 Class Initialized
INFO - 2025-05-05 06:20:53 --> URI Class Initialized
INFO - 2025-05-05 06:20:53 --> Router Class Initialized
INFO - 2025-05-05 06:20:53 --> Output Class Initialized
INFO - 2025-05-05 06:20:53 --> Security Class Initialized
DEBUG - 2025-05-05 06:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:20:53 --> Input Class Initialized
INFO - 2025-05-05 06:20:53 --> Language Class Initialized
INFO - 2025-05-05 06:20:53 --> Loader Class Initialized
INFO - 2025-05-05 06:20:53 --> Helper loaded: url_helper
INFO - 2025-05-05 06:20:53 --> Helper loaded: string_helper
INFO - 2025-05-05 06:20:53 --> Helper loaded: form_helper
INFO - 2025-05-05 06:20:53 --> Helper loaded: file_helper
INFO - 2025-05-05 06:20:53 --> Helper loaded: html_helper
INFO - 2025-05-05 06:20:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:20:53 --> Controller Class Initialized
INFO - 2025-05-05 14:20:53 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:20:53 --> Model "UserModel" initialized
INFO - 2025-05-05 06:23:18 --> Config Class Initialized
INFO - 2025-05-05 06:23:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:23:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:23:18 --> Utf8 Class Initialized
INFO - 2025-05-05 06:23:18 --> URI Class Initialized
INFO - 2025-05-05 06:23:18 --> Router Class Initialized
INFO - 2025-05-05 06:23:18 --> Output Class Initialized
INFO - 2025-05-05 06:23:18 --> Security Class Initialized
DEBUG - 2025-05-05 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:23:18 --> Input Class Initialized
INFO - 2025-05-05 06:23:18 --> Language Class Initialized
INFO - 2025-05-05 06:23:18 --> Loader Class Initialized
INFO - 2025-05-05 06:23:18 --> Helper loaded: url_helper
INFO - 2025-05-05 06:23:18 --> Helper loaded: string_helper
INFO - 2025-05-05 06:23:18 --> Helper loaded: form_helper
INFO - 2025-05-05 06:23:18 --> Helper loaded: file_helper
INFO - 2025-05-05 06:23:18 --> Helper loaded: html_helper
INFO - 2025-05-05 06:23:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:23:18 --> Controller Class Initialized
INFO - 2025-05-05 14:23:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:23:18 --> Model "UserModel" initialized
INFO - 2025-05-05 06:23:25 --> Config Class Initialized
INFO - 2025-05-05 06:23:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:23:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:23:25 --> Utf8 Class Initialized
INFO - 2025-05-05 06:23:25 --> URI Class Initialized
INFO - 2025-05-05 06:23:25 --> Router Class Initialized
INFO - 2025-05-05 06:23:25 --> Output Class Initialized
INFO - 2025-05-05 06:23:25 --> Security Class Initialized
DEBUG - 2025-05-05 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:23:25 --> Input Class Initialized
INFO - 2025-05-05 06:23:25 --> Language Class Initialized
INFO - 2025-05-05 06:23:25 --> Loader Class Initialized
INFO - 2025-05-05 06:23:25 --> Helper loaded: url_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: string_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: form_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: file_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: html_helper
INFO - 2025-05-05 06:23:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:23:25 --> Controller Class Initialized
INFO - 2025-05-05 14:23:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:23:25 --> Model "UserModel" initialized
INFO - 2025-05-05 06:23:25 --> Config Class Initialized
INFO - 2025-05-05 06:23:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:23:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:23:25 --> Utf8 Class Initialized
INFO - 2025-05-05 06:23:25 --> URI Class Initialized
INFO - 2025-05-05 06:23:25 --> Router Class Initialized
INFO - 2025-05-05 06:23:25 --> Output Class Initialized
INFO - 2025-05-05 06:23:25 --> Security Class Initialized
DEBUG - 2025-05-05 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:23:25 --> Input Class Initialized
INFO - 2025-05-05 06:23:25 --> Language Class Initialized
INFO - 2025-05-05 06:23:25 --> Loader Class Initialized
INFO - 2025-05-05 06:23:25 --> Helper loaded: url_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: string_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: form_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: file_helper
INFO - 2025-05-05 06:23:25 --> Helper loaded: html_helper
INFO - 2025-05-05 06:23:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:23:25 --> Controller Class Initialized
INFO - 2025-05-05 14:23:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:23:25 --> Model "UserModel" initialized
INFO - 2025-05-05 06:23:26 --> Config Class Initialized
INFO - 2025-05-05 06:23:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:23:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:23:26 --> Utf8 Class Initialized
INFO - 2025-05-05 06:23:26 --> URI Class Initialized
INFO - 2025-05-05 06:23:26 --> Router Class Initialized
INFO - 2025-05-05 06:23:26 --> Output Class Initialized
INFO - 2025-05-05 06:23:26 --> Security Class Initialized
DEBUG - 2025-05-05 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:23:26 --> Input Class Initialized
INFO - 2025-05-05 06:23:26 --> Language Class Initialized
INFO - 2025-05-05 06:23:26 --> Loader Class Initialized
INFO - 2025-05-05 06:23:26 --> Helper loaded: url_helper
INFO - 2025-05-05 06:23:26 --> Helper loaded: string_helper
INFO - 2025-05-05 06:23:26 --> Helper loaded: form_helper
INFO - 2025-05-05 06:23:26 --> Helper loaded: file_helper
INFO - 2025-05-05 06:23:26 --> Helper loaded: html_helper
INFO - 2025-05-05 06:23:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:23:26 --> Controller Class Initialized
INFO - 2025-05-05 14:23:26 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:23:26 --> Model "UserModel" initialized
INFO - 2025-05-05 06:24:57 --> Config Class Initialized
INFO - 2025-05-05 06:24:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:24:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:24:57 --> Utf8 Class Initialized
INFO - 2025-05-05 06:24:57 --> URI Class Initialized
INFO - 2025-05-05 06:24:57 --> Router Class Initialized
INFO - 2025-05-05 06:24:57 --> Output Class Initialized
INFO - 2025-05-05 06:24:57 --> Security Class Initialized
DEBUG - 2025-05-05 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:24:57 --> Input Class Initialized
INFO - 2025-05-05 06:24:57 --> Language Class Initialized
ERROR - 2025-05-05 06:24:58 --> Severity: error --> Exception: syntax error, unexpected variable "$existingUserRole" C:\xampp\htdocs\storage_auctions\application\controllers\Staff.php 267
INFO - 2025-05-05 06:25:14 --> Config Class Initialized
INFO - 2025-05-05 06:25:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:25:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:25:14 --> Utf8 Class Initialized
INFO - 2025-05-05 06:25:14 --> URI Class Initialized
INFO - 2025-05-05 06:25:14 --> Router Class Initialized
INFO - 2025-05-05 06:25:14 --> Output Class Initialized
INFO - 2025-05-05 06:25:14 --> Security Class Initialized
DEBUG - 2025-05-05 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:25:14 --> Input Class Initialized
INFO - 2025-05-05 06:25:14 --> Language Class Initialized
INFO - 2025-05-05 06:25:14 --> Loader Class Initialized
INFO - 2025-05-05 06:25:14 --> Helper loaded: url_helper
INFO - 2025-05-05 06:25:14 --> Helper loaded: string_helper
INFO - 2025-05-05 06:25:14 --> Helper loaded: form_helper
INFO - 2025-05-05 06:25:14 --> Helper loaded: file_helper
INFO - 2025-05-05 06:25:14 --> Helper loaded: html_helper
INFO - 2025-05-05 06:25:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:25:14 --> Controller Class Initialized
INFO - 2025-05-05 14:25:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:25:14 --> Model "UserModel" initialized
INFO - 2025-05-05 06:25:28 --> Config Class Initialized
INFO - 2025-05-05 06:25:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:25:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:25:28 --> Utf8 Class Initialized
INFO - 2025-05-05 06:25:28 --> URI Class Initialized
INFO - 2025-05-05 06:25:28 --> Router Class Initialized
INFO - 2025-05-05 06:25:28 --> Output Class Initialized
INFO - 2025-05-05 06:25:28 --> Security Class Initialized
DEBUG - 2025-05-05 06:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:25:28 --> Input Class Initialized
INFO - 2025-05-05 06:25:28 --> Language Class Initialized
INFO - 2025-05-05 06:25:29 --> Loader Class Initialized
INFO - 2025-05-05 06:25:29 --> Helper loaded: url_helper
INFO - 2025-05-05 06:25:29 --> Helper loaded: string_helper
INFO - 2025-05-05 06:25:29 --> Helper loaded: form_helper
INFO - 2025-05-05 06:25:29 --> Helper loaded: file_helper
INFO - 2025-05-05 06:25:29 --> Helper loaded: html_helper
INFO - 2025-05-05 06:25:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:25:29 --> Controller Class Initialized
INFO - 2025-05-05 14:25:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:25:29 --> Model "UserModel" initialized
INFO - 2025-05-05 06:25:50 --> Config Class Initialized
INFO - 2025-05-05 06:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:25:50 --> Utf8 Class Initialized
INFO - 2025-05-05 06:25:50 --> URI Class Initialized
INFO - 2025-05-05 06:25:50 --> Router Class Initialized
INFO - 2025-05-05 06:25:50 --> Output Class Initialized
INFO - 2025-05-05 06:25:50 --> Security Class Initialized
DEBUG - 2025-05-05 06:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:25:50 --> Input Class Initialized
INFO - 2025-05-05 06:25:50 --> Language Class Initialized
INFO - 2025-05-05 06:25:50 --> Loader Class Initialized
INFO - 2025-05-05 06:25:50 --> Helper loaded: url_helper
INFO - 2025-05-05 06:25:50 --> Helper loaded: string_helper
INFO - 2025-05-05 06:25:50 --> Helper loaded: form_helper
INFO - 2025-05-05 06:25:50 --> Helper loaded: file_helper
INFO - 2025-05-05 06:25:50 --> Helper loaded: html_helper
INFO - 2025-05-05 06:25:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:25:50 --> Controller Class Initialized
INFO - 2025-05-05 14:25:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:25:50 --> Model "UserModel" initialized
INFO - 2025-05-05 06:25:54 --> Config Class Initialized
INFO - 2025-05-05 06:25:54 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:25:54 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:25:54 --> Utf8 Class Initialized
INFO - 2025-05-05 06:25:54 --> URI Class Initialized
INFO - 2025-05-05 06:25:54 --> Router Class Initialized
INFO - 2025-05-05 06:25:54 --> Output Class Initialized
INFO - 2025-05-05 06:25:54 --> Security Class Initialized
DEBUG - 2025-05-05 06:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:25:54 --> Input Class Initialized
INFO - 2025-05-05 06:25:54 --> Language Class Initialized
INFO - 2025-05-05 06:25:54 --> Loader Class Initialized
INFO - 2025-05-05 06:25:54 --> Helper loaded: url_helper
INFO - 2025-05-05 06:25:54 --> Helper loaded: string_helper
INFO - 2025-05-05 06:25:54 --> Helper loaded: form_helper
INFO - 2025-05-05 06:25:54 --> Helper loaded: file_helper
INFO - 2025-05-05 06:25:54 --> Helper loaded: html_helper
INFO - 2025-05-05 06:25:54 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:25:54 --> Controller Class Initialized
INFO - 2025-05-05 14:25:54 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:25:54 --> Model "UserModel" initialized
INFO - 2025-05-05 06:26:01 --> Config Class Initialized
INFO - 2025-05-05 06:26:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:26:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:26:01 --> Utf8 Class Initialized
INFO - 2025-05-05 06:26:01 --> URI Class Initialized
INFO - 2025-05-05 06:26:01 --> Router Class Initialized
INFO - 2025-05-05 06:26:01 --> Output Class Initialized
INFO - 2025-05-05 06:26:01 --> Security Class Initialized
DEBUG - 2025-05-05 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:26:01 --> Input Class Initialized
INFO - 2025-05-05 06:26:01 --> Language Class Initialized
INFO - 2025-05-05 06:26:01 --> Loader Class Initialized
INFO - 2025-05-05 06:26:01 --> Helper loaded: url_helper
INFO - 2025-05-05 06:26:01 --> Helper loaded: string_helper
INFO - 2025-05-05 06:26:01 --> Helper loaded: form_helper
INFO - 2025-05-05 06:26:01 --> Helper loaded: file_helper
INFO - 2025-05-05 06:26:01 --> Helper loaded: html_helper
INFO - 2025-05-05 06:26:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:26:01 --> Controller Class Initialized
INFO - 2025-05-05 14:26:01 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:26:01 --> Model "UserModel" initialized
INFO - 2025-05-05 06:26:18 --> Config Class Initialized
INFO - 2025-05-05 06:26:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:26:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:26:18 --> Utf8 Class Initialized
INFO - 2025-05-05 06:26:18 --> URI Class Initialized
INFO - 2025-05-05 06:26:18 --> Router Class Initialized
INFO - 2025-05-05 06:26:18 --> Output Class Initialized
INFO - 2025-05-05 06:26:18 --> Security Class Initialized
DEBUG - 2025-05-05 06:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:26:18 --> Input Class Initialized
INFO - 2025-05-05 06:26:18 --> Language Class Initialized
INFO - 2025-05-05 06:26:18 --> Loader Class Initialized
INFO - 2025-05-05 06:26:18 --> Helper loaded: url_helper
INFO - 2025-05-05 06:26:18 --> Helper loaded: string_helper
INFO - 2025-05-05 06:26:18 --> Helper loaded: form_helper
INFO - 2025-05-05 06:26:18 --> Helper loaded: file_helper
INFO - 2025-05-05 06:26:18 --> Helper loaded: html_helper
INFO - 2025-05-05 06:26:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:26:18 --> Controller Class Initialized
INFO - 2025-05-05 14:26:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:26:18 --> Model "UserModel" initialized
INFO - 2025-05-05 06:26:56 --> Config Class Initialized
INFO - 2025-05-05 06:26:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:26:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:26:56 --> Utf8 Class Initialized
INFO - 2025-05-05 06:26:56 --> URI Class Initialized
INFO - 2025-05-05 06:26:56 --> Router Class Initialized
INFO - 2025-05-05 06:26:56 --> Output Class Initialized
INFO - 2025-05-05 06:26:56 --> Security Class Initialized
DEBUG - 2025-05-05 06:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:26:56 --> Input Class Initialized
INFO - 2025-05-05 06:26:56 --> Language Class Initialized
INFO - 2025-05-05 06:26:56 --> Loader Class Initialized
INFO - 2025-05-05 06:26:56 --> Helper loaded: url_helper
INFO - 2025-05-05 06:26:56 --> Helper loaded: string_helper
INFO - 2025-05-05 06:26:56 --> Helper loaded: form_helper
INFO - 2025-05-05 06:26:56 --> Helper loaded: file_helper
INFO - 2025-05-05 06:26:56 --> Helper loaded: html_helper
INFO - 2025-05-05 06:26:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:26:56 --> Controller Class Initialized
INFO - 2025-05-05 14:26:56 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:26:56 --> Model "UserModel" initialized
INFO - 2025-05-05 06:27:15 --> Config Class Initialized
INFO - 2025-05-05 06:27:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:27:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:27:15 --> Utf8 Class Initialized
INFO - 2025-05-05 06:27:15 --> URI Class Initialized
INFO - 2025-05-05 06:27:15 --> Router Class Initialized
INFO - 2025-05-05 06:27:15 --> Output Class Initialized
INFO - 2025-05-05 06:27:15 --> Security Class Initialized
DEBUG - 2025-05-05 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:27:15 --> Input Class Initialized
INFO - 2025-05-05 06:27:15 --> Language Class Initialized
INFO - 2025-05-05 06:27:15 --> Loader Class Initialized
INFO - 2025-05-05 06:27:15 --> Helper loaded: url_helper
INFO - 2025-05-05 06:27:15 --> Helper loaded: string_helper
INFO - 2025-05-05 06:27:15 --> Helper loaded: form_helper
INFO - 2025-05-05 06:27:15 --> Helper loaded: file_helper
INFO - 2025-05-05 06:27:15 --> Helper loaded: html_helper
INFO - 2025-05-05 06:27:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:27:16 --> Controller Class Initialized
INFO - 2025-05-05 14:27:16 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:27:16 --> Model "UserModel" initialized
INFO - 2025-05-05 06:27:22 --> Config Class Initialized
INFO - 2025-05-05 06:27:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:27:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:27:22 --> Utf8 Class Initialized
INFO - 2025-05-05 06:27:22 --> URI Class Initialized
INFO - 2025-05-05 06:27:22 --> Router Class Initialized
INFO - 2025-05-05 06:27:22 --> Output Class Initialized
INFO - 2025-05-05 06:27:22 --> Security Class Initialized
DEBUG - 2025-05-05 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:27:22 --> Input Class Initialized
INFO - 2025-05-05 06:27:22 --> Language Class Initialized
INFO - 2025-05-05 06:27:22 --> Loader Class Initialized
INFO - 2025-05-05 06:27:22 --> Helper loaded: url_helper
INFO - 2025-05-05 06:27:22 --> Helper loaded: string_helper
INFO - 2025-05-05 06:27:22 --> Helper loaded: form_helper
INFO - 2025-05-05 06:27:22 --> Helper loaded: file_helper
INFO - 2025-05-05 06:27:22 --> Helper loaded: html_helper
INFO - 2025-05-05 06:27:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:27:22 --> Controller Class Initialized
INFO - 2025-05-05 14:27:22 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:27:22 --> Model "UserModel" initialized
INFO - 2025-05-05 14:27:22 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:27:32 --> Config Class Initialized
INFO - 2025-05-05 06:27:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:27:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:27:32 --> Utf8 Class Initialized
INFO - 2025-05-05 06:27:32 --> URI Class Initialized
INFO - 2025-05-05 06:27:32 --> Router Class Initialized
INFO - 2025-05-05 06:27:32 --> Output Class Initialized
INFO - 2025-05-05 06:27:32 --> Security Class Initialized
DEBUG - 2025-05-05 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:27:32 --> Input Class Initialized
INFO - 2025-05-05 06:27:32 --> Language Class Initialized
INFO - 2025-05-05 06:27:32 --> Loader Class Initialized
INFO - 2025-05-05 06:27:32 --> Helper loaded: url_helper
INFO - 2025-05-05 06:27:32 --> Helper loaded: string_helper
INFO - 2025-05-05 06:27:32 --> Helper loaded: form_helper
INFO - 2025-05-05 06:27:32 --> Helper loaded: file_helper
INFO - 2025-05-05 06:27:32 --> Helper loaded: html_helper
INFO - 2025-05-05 06:27:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:27:32 --> Controller Class Initialized
INFO - 2025-05-05 06:27:32 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:27:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:27:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:27:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:27:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:27:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:27:32 --> Final output sent to browser
DEBUG - 2025-05-05 06:27:32 --> Total execution time: 0.1600
INFO - 2025-05-05 06:27:33 --> Config Class Initialized
INFO - 2025-05-05 06:27:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:27:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:27:33 --> Utf8 Class Initialized
INFO - 2025-05-05 06:27:33 --> URI Class Initialized
INFO - 2025-05-05 06:27:33 --> Router Class Initialized
INFO - 2025-05-05 06:27:33 --> Output Class Initialized
INFO - 2025-05-05 06:27:33 --> Security Class Initialized
DEBUG - 2025-05-05 06:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:27:33 --> Input Class Initialized
INFO - 2025-05-05 06:27:33 --> Language Class Initialized
INFO - 2025-05-05 06:27:33 --> Loader Class Initialized
INFO - 2025-05-05 06:27:33 --> Helper loaded: url_helper
INFO - 2025-05-05 06:27:33 --> Helper loaded: string_helper
INFO - 2025-05-05 06:27:33 --> Helper loaded: form_helper
INFO - 2025-05-05 06:27:33 --> Helper loaded: file_helper
INFO - 2025-05-05 06:27:33 --> Helper loaded: html_helper
INFO - 2025-05-05 06:27:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:27:33 --> Controller Class Initialized
INFO - 2025-05-05 14:27:33 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:27:33 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:27:33 --> Final output sent to browser
DEBUG - 2025-05-05 14:27:33 --> Total execution time: 0.2097
INFO - 2025-05-05 06:29:52 --> Config Class Initialized
INFO - 2025-05-05 06:29:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:29:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:29:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:29:52 --> URI Class Initialized
INFO - 2025-05-05 06:29:52 --> Router Class Initialized
INFO - 2025-05-05 06:29:53 --> Output Class Initialized
INFO - 2025-05-05 06:29:53 --> Security Class Initialized
DEBUG - 2025-05-05 06:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:29:53 --> Input Class Initialized
INFO - 2025-05-05 06:29:53 --> Language Class Initialized
INFO - 2025-05-05 06:29:53 --> Loader Class Initialized
INFO - 2025-05-05 06:29:53 --> Helper loaded: url_helper
INFO - 2025-05-05 06:29:53 --> Helper loaded: string_helper
INFO - 2025-05-05 06:29:53 --> Helper loaded: form_helper
INFO - 2025-05-05 06:29:53 --> Helper loaded: file_helper
INFO - 2025-05-05 06:29:53 --> Helper loaded: html_helper
INFO - 2025-05-05 06:29:54 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:29:54 --> Controller Class Initialized
INFO - 2025-05-05 06:29:54 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:29:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:29:55 --> Final output sent to browser
DEBUG - 2025-05-05 06:29:55 --> Total execution time: 3.7081
INFO - 2025-05-05 06:30:07 --> Config Class Initialized
INFO - 2025-05-05 06:30:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:07 --> URI Class Initialized
INFO - 2025-05-05 06:30:07 --> Router Class Initialized
INFO - 2025-05-05 06:30:07 --> Output Class Initialized
INFO - 2025-05-05 06:30:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:07 --> Input Class Initialized
INFO - 2025-05-05 06:30:07 --> Language Class Initialized
INFO - 2025-05-05 06:30:07 --> Loader Class Initialized
INFO - 2025-05-05 06:30:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:07 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:07 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:07 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:07 --> Controller Class Initialized
INFO - 2025-05-05 06:30:07 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:30:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:30:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:30:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:30:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:30:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:30:07 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:07 --> Total execution time: 0.1568
INFO - 2025-05-05 06:30:08 --> Config Class Initialized
INFO - 2025-05-05 06:30:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:08 --> URI Class Initialized
INFO - 2025-05-05 06:30:08 --> Router Class Initialized
INFO - 2025-05-05 06:30:08 --> Output Class Initialized
INFO - 2025-05-05 06:30:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:08 --> Input Class Initialized
INFO - 2025-05-05 06:30:08 --> Language Class Initialized
INFO - 2025-05-05 06:30:09 --> Loader Class Initialized
INFO - 2025-05-05 06:30:09 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:09 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:09 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:09 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:09 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:09 --> Controller Class Initialized
INFO - 2025-05-05 14:30:09 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:09 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:30:09 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:09 --> Total execution time: 0.3303
INFO - 2025-05-05 06:30:19 --> Config Class Initialized
INFO - 2025-05-05 06:30:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:19 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:19 --> URI Class Initialized
INFO - 2025-05-05 06:30:19 --> Router Class Initialized
INFO - 2025-05-05 06:30:19 --> Output Class Initialized
INFO - 2025-05-05 06:30:19 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:19 --> Input Class Initialized
INFO - 2025-05-05 06:30:19 --> Language Class Initialized
INFO - 2025-05-05 06:30:19 --> Loader Class Initialized
INFO - 2025-05-05 06:30:19 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:19 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:19 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:19 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:19 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:19 --> Controller Class Initialized
INFO - 2025-05-05 06:30:20 --> Config Class Initialized
INFO - 2025-05-05 06:30:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:20 --> URI Class Initialized
INFO - 2025-05-05 06:30:20 --> Router Class Initialized
INFO - 2025-05-05 06:30:20 --> Output Class Initialized
INFO - 2025-05-05 06:30:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:20 --> Input Class Initialized
INFO - 2025-05-05 06:30:20 --> Language Class Initialized
INFO - 2025-05-05 06:30:20 --> Loader Class Initialized
INFO - 2025-05-05 06:30:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:20 --> Controller Class Initialized
INFO - 2025-05-05 06:30:20 --> Config Class Initialized
INFO - 2025-05-05 06:30:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:20 --> URI Class Initialized
DEBUG - 2025-05-05 06:30:20 --> No URI present. Default controller set.
INFO - 2025-05-05 06:30:20 --> Router Class Initialized
INFO - 2025-05-05 06:30:20 --> Output Class Initialized
INFO - 2025-05-05 06:30:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:20 --> Input Class Initialized
INFO - 2025-05-05 06:30:20 --> Language Class Initialized
INFO - 2025-05-05 06:30:20 --> Loader Class Initialized
INFO - 2025-05-05 06:30:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:20 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:20 --> Controller Class Initialized
INFO - 2025-05-05 06:30:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:30:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:30:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:30:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:30:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:30:20 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:20 --> Total execution time: 0.1708
INFO - 2025-05-05 06:30:22 --> Config Class Initialized
INFO - 2025-05-05 06:30:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:22 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:22 --> URI Class Initialized
INFO - 2025-05-05 06:30:22 --> Router Class Initialized
INFO - 2025-05-05 06:30:22 --> Output Class Initialized
INFO - 2025-05-05 06:30:22 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:22 --> Input Class Initialized
INFO - 2025-05-05 06:30:22 --> Language Class Initialized
INFO - 2025-05-05 06:30:22 --> Loader Class Initialized
INFO - 2025-05-05 06:30:22 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:22 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:22 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:22 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:22 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:22 --> Controller Class Initialized
INFO - 2025-05-05 06:30:25 --> Config Class Initialized
INFO - 2025-05-05 06:30:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:25 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:25 --> URI Class Initialized
INFO - 2025-05-05 06:30:25 --> Router Class Initialized
INFO - 2025-05-05 06:30:25 --> Output Class Initialized
INFO - 2025-05-05 06:30:25 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:25 --> Input Class Initialized
INFO - 2025-05-05 06:30:25 --> Language Class Initialized
INFO - 2025-05-05 06:30:25 --> Loader Class Initialized
INFO - 2025-05-05 06:30:25 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:25 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:25 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:25 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:25 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:25 --> Controller Class Initialized
INFO - 2025-05-05 14:30:25 --> Model "UserModel" initialized
INFO - 2025-05-05 06:30:28 --> Config Class Initialized
INFO - 2025-05-05 06:30:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:28 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:28 --> URI Class Initialized
INFO - 2025-05-05 06:30:28 --> Router Class Initialized
INFO - 2025-05-05 06:30:28 --> Output Class Initialized
INFO - 2025-05-05 06:30:28 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:28 --> Input Class Initialized
INFO - 2025-05-05 06:30:28 --> Language Class Initialized
INFO - 2025-05-05 06:30:28 --> Loader Class Initialized
INFO - 2025-05-05 06:30:28 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:28 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:28 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:28 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:28 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:28 --> Controller Class Initialized
INFO - 2025-05-05 14:30:28 --> Model "UserModel" initialized
INFO - 2025-05-05 06:30:28 --> Config Class Initialized
INFO - 2025-05-05 06:30:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:28 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:28 --> URI Class Initialized
DEBUG - 2025-05-05 06:30:28 --> No URI present. Default controller set.
INFO - 2025-05-05 06:30:28 --> Router Class Initialized
INFO - 2025-05-05 06:30:28 --> Output Class Initialized
INFO - 2025-05-05 06:30:28 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:28 --> Input Class Initialized
INFO - 2025-05-05 06:30:28 --> Language Class Initialized
INFO - 2025-05-05 06:30:28 --> Loader Class Initialized
INFO - 2025-05-05 06:30:29 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:29 --> Controller Class Initialized
INFO - 2025-05-05 06:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:30:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:30:29 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:29 --> Total execution time: 0.0961
INFO - 2025-05-05 06:30:29 --> Config Class Initialized
INFO - 2025-05-05 06:30:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:29 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:29 --> URI Class Initialized
INFO - 2025-05-05 06:30:29 --> Router Class Initialized
INFO - 2025-05-05 06:30:29 --> Output Class Initialized
INFO - 2025-05-05 06:30:29 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:29 --> Input Class Initialized
INFO - 2025-05-05 06:30:29 --> Language Class Initialized
INFO - 2025-05-05 06:30:29 --> Loader Class Initialized
INFO - 2025-05-05 06:30:29 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:29 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:29 --> Controller Class Initialized
INFO - 2025-05-05 14:30:29 --> Model "AuctionModel" initialized
INFO - 2025-05-05 06:30:31 --> Config Class Initialized
INFO - 2025-05-05 06:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:31 --> URI Class Initialized
INFO - 2025-05-05 06:30:31 --> Router Class Initialized
INFO - 2025-05-05 06:30:31 --> Output Class Initialized
INFO - 2025-05-05 06:30:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:31 --> Input Class Initialized
INFO - 2025-05-05 06:30:31 --> Language Class Initialized
INFO - 2025-05-05 06:30:31 --> Loader Class Initialized
INFO - 2025-05-05 06:30:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:31 --> Config Class Initialized
INFO - 2025-05-05 06:30:31 --> Hooks Class Initialized
INFO - 2025-05-05 06:30:31 --> Config Class Initialized
INFO - 2025-05-05 06:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:31 --> Utf8 Class Initialized
DEBUG - 2025-05-05 06:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:31 --> URI Class Initialized
INFO - 2025-05-05 06:30:31 --> URI Class Initialized
INFO - 2025-05-05 06:30:31 --> Router Class Initialized
INFO - 2025-05-05 06:30:31 --> Router Class Initialized
INFO - 2025-05-05 06:30:31 --> Output Class Initialized
INFO - 2025-05-05 06:30:31 --> Output Class Initialized
INFO - 2025-05-05 06:30:31 --> Security Class Initialized
INFO - 2025-05-05 06:30:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:31 --> Input Class Initialized
DEBUG - 2025-05-05 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:31 --> Input Class Initialized
INFO - 2025-05-05 06:30:31 --> Language Class Initialized
INFO - 2025-05-05 06:30:31 --> Language Class Initialized
INFO - 2025-05-05 06:30:31 --> Loader Class Initialized
INFO - 2025-05-05 06:30:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:31 --> Loader Class Initialized
INFO - 2025-05-05 06:30:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:31 --> Controller Class Initialized
INFO - 2025-05-05 06:30:31 --> Database Driver Class Initialized
INFO - 2025-05-05 14:30:31 --> Model "CompanyModel" initialized
DEBUG - 2025-05-05 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 14:30:32 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 14:30:32 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:30:32 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:32 --> Total execution time: 0.2656
INFO - 2025-05-05 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:32 --> Controller Class Initialized
INFO - 2025-05-05 14:30:32 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:30:32 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:32 --> Total execution time: 0.2854
INFO - 2025-05-05 06:30:32 --> Config Class Initialized
INFO - 2025-05-05 06:30:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:32 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:32 --> URI Class Initialized
INFO - 2025-05-05 06:30:32 --> Router Class Initialized
INFO - 2025-05-05 06:30:32 --> Output Class Initialized
INFO - 2025-05-05 06:30:32 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:32 --> Input Class Initialized
INFO - 2025-05-05 06:30:32 --> Language Class Initialized
INFO - 2025-05-05 06:30:32 --> Loader Class Initialized
INFO - 2025-05-05 06:30:32 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:32 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:32 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:32 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:32 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:32 --> Controller Class Initialized
INFO - 2025-05-05 06:30:32 --> Model "UserModel" initialized
INFO - 2025-05-05 06:30:32 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:32 --> Total execution time: 0.1424
INFO - 2025-05-05 06:30:34 --> Config Class Initialized
INFO - 2025-05-05 06:30:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:34 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:34 --> URI Class Initialized
INFO - 2025-05-05 06:30:34 --> Router Class Initialized
INFO - 2025-05-05 06:30:34 --> Output Class Initialized
INFO - 2025-05-05 06:30:34 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:34 --> Input Class Initialized
INFO - 2025-05-05 06:30:34 --> Language Class Initialized
INFO - 2025-05-05 06:30:34 --> Loader Class Initialized
INFO - 2025-05-05 06:30:34 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:34 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:34 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:34 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:34 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:34 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:34 --> Controller Class Initialized
INFO - 2025-05-05 14:30:34 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:34 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:34 --> Total execution time: 0.1588
INFO - 2025-05-05 06:30:35 --> Config Class Initialized
INFO - 2025-05-05 06:30:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:35 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:35 --> URI Class Initialized
INFO - 2025-05-05 06:30:35 --> Router Class Initialized
INFO - 2025-05-05 06:30:35 --> Output Class Initialized
INFO - 2025-05-05 06:30:35 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:35 --> Input Class Initialized
INFO - 2025-05-05 06:30:35 --> Language Class Initialized
INFO - 2025-05-05 06:30:35 --> Loader Class Initialized
INFO - 2025-05-05 06:30:35 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:35 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:35 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:35 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:35 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:35 --> Controller Class Initialized
INFO - 2025-05-05 14:30:35 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:35 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 14:30:35 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:30:35 --> Model "InvoiceModel" initialized
INFO - 2025-05-05 14:30:35 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:35 --> Total execution time: 0.3248
INFO - 2025-05-05 06:30:41 --> Config Class Initialized
INFO - 2025-05-05 06:30:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:41 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:41 --> URI Class Initialized
INFO - 2025-05-05 06:30:41 --> Router Class Initialized
INFO - 2025-05-05 06:30:41 --> Output Class Initialized
INFO - 2025-05-05 06:30:41 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:41 --> Input Class Initialized
INFO - 2025-05-05 06:30:41 --> Language Class Initialized
INFO - 2025-05-05 06:30:41 --> Loader Class Initialized
INFO - 2025-05-05 06:30:41 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:41 --> Controller Class Initialized
INFO - 2025-05-05 14:30:41 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:41 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:30:41 --> Config Class Initialized
INFO - 2025-05-05 06:30:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:41 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:41 --> URI Class Initialized
INFO - 2025-05-05 06:30:41 --> Router Class Initialized
INFO - 2025-05-05 06:30:41 --> Output Class Initialized
INFO - 2025-05-05 06:30:41 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:41 --> Input Class Initialized
INFO - 2025-05-05 06:30:41 --> Language Class Initialized
INFO - 2025-05-05 06:30:41 --> Loader Class Initialized
INFO - 2025-05-05 06:30:41 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:41 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:41 --> Controller Class Initialized
INFO - 2025-05-05 14:30:41 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:41 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:30:41 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:41 --> Total execution time: 0.1211
INFO - 2025-05-05 06:30:43 --> Config Class Initialized
INFO - 2025-05-05 06:30:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:43 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:43 --> URI Class Initialized
INFO - 2025-05-05 06:30:43 --> Router Class Initialized
INFO - 2025-05-05 06:30:43 --> Output Class Initialized
INFO - 2025-05-05 06:30:43 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:43 --> Input Class Initialized
INFO - 2025-05-05 06:30:43 --> Language Class Initialized
INFO - 2025-05-05 06:30:43 --> Loader Class Initialized
INFO - 2025-05-05 06:30:43 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:43 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:43 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:43 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:43 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:44 --> Controller Class Initialized
INFO - 2025-05-05 06:30:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:30:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:30:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 06:30:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:30:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:30:44 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:44 --> Total execution time: 0.1286
INFO - 2025-05-05 06:30:44 --> Config Class Initialized
INFO - 2025-05-05 06:30:44 --> Hooks Class Initialized
INFO - 2025-05-05 06:30:44 --> Config Class Initialized
INFO - 2025-05-05 06:30:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:44 --> Utf8 Class Initialized
DEBUG - 2025-05-05 06:30:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:44 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:44 --> URI Class Initialized
INFO - 2025-05-05 06:30:44 --> URI Class Initialized
INFO - 2025-05-05 06:30:44 --> Router Class Initialized
INFO - 2025-05-05 06:30:44 --> Router Class Initialized
INFO - 2025-05-05 06:30:44 --> Output Class Initialized
INFO - 2025-05-05 06:30:44 --> Output Class Initialized
INFO - 2025-05-05 06:30:44 --> Security Class Initialized
INFO - 2025-05-05 06:30:44 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:44 --> Input Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:44 --> Input Class Initialized
INFO - 2025-05-05 06:30:44 --> Language Class Initialized
INFO - 2025-05-05 06:30:44 --> Language Class Initialized
INFO - 2025-05-05 06:30:44 --> Loader Class Initialized
INFO - 2025-05-05 06:30:44 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:44 --> Loader Class Initialized
INFO - 2025-05-05 06:30:44 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:44 --> Database Driver Class Initialized
INFO - 2025-05-05 06:30:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:44 --> Controller Class Initialized
INFO - 2025-05-05 14:30:44 --> Model "CompanyModel" initialized
DEBUG - 2025-05-05 06:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:44 --> Controller Class Initialized
INFO - 2025-05-05 14:30:44 --> Model "AuctionModel" initialized
INFO - 2025-05-05 14:30:44 --> Final output sent to browser
DEBUG - 2025-05-05 14:30:44 --> Total execution time: 0.1938
INFO - 2025-05-05 06:30:44 --> Config Class Initialized
INFO - 2025-05-05 06:30:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:44 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:44 --> URI Class Initialized
INFO - 2025-05-05 06:30:44 --> Router Class Initialized
INFO - 2025-05-05 06:30:44 --> Output Class Initialized
INFO - 2025-05-05 06:30:44 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:44 --> Input Class Initialized
INFO - 2025-05-05 06:30:44 --> Language Class Initialized
INFO - 2025-05-05 06:30:44 --> Loader Class Initialized
INFO - 2025-05-05 06:30:44 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:44 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:44 --> Controller Class Initialized
INFO - 2025-05-05 06:30:44 --> Model "UserModel" initialized
INFO - 2025-05-05 06:30:46 --> Config Class Initialized
INFO - 2025-05-05 06:30:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:46 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:46 --> URI Class Initialized
INFO - 2025-05-05 06:30:46 --> Router Class Initialized
INFO - 2025-05-05 06:30:46 --> Output Class Initialized
INFO - 2025-05-05 06:30:46 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:46 --> Input Class Initialized
INFO - 2025-05-05 06:30:46 --> Language Class Initialized
INFO - 2025-05-05 06:30:46 --> Loader Class Initialized
INFO - 2025-05-05 06:30:46 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:46 --> Controller Class Initialized
INFO - 2025-05-05 14:30:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:30:46 --> Config Class Initialized
INFO - 2025-05-05 06:30:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:46 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:46 --> URI Class Initialized
INFO - 2025-05-05 06:30:46 --> Router Class Initialized
INFO - 2025-05-05 06:30:46 --> Output Class Initialized
INFO - 2025-05-05 06:30:46 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:46 --> Input Class Initialized
INFO - 2025-05-05 06:30:46 --> Language Class Initialized
INFO - 2025-05-05 06:30:46 --> Loader Class Initialized
INFO - 2025-05-05 06:30:46 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:46 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:46 --> Controller Class Initialized
INFO - 2025-05-05 14:30:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:30:48 --> Config Class Initialized
INFO - 2025-05-05 06:30:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:48 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:48 --> URI Class Initialized
INFO - 2025-05-05 06:30:48 --> Router Class Initialized
INFO - 2025-05-05 06:30:48 --> Output Class Initialized
INFO - 2025-05-05 06:30:48 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:48 --> Input Class Initialized
INFO - 2025-05-05 06:30:48 --> Language Class Initialized
INFO - 2025-05-05 06:30:48 --> Loader Class Initialized
INFO - 2025-05-05 06:30:48 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:48 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:48 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:48 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:48 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:48 --> Controller Class Initialized
INFO - 2025-05-05 06:30:49 --> Config Class Initialized
INFO - 2025-05-05 06:30:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:49 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:49 --> URI Class Initialized
INFO - 2025-05-05 06:30:49 --> Router Class Initialized
INFO - 2025-05-05 06:30:49 --> Output Class Initialized
INFO - 2025-05-05 06:30:49 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:49 --> Input Class Initialized
INFO - 2025-05-05 06:30:49 --> Language Class Initialized
INFO - 2025-05-05 06:30:49 --> Loader Class Initialized
INFO - 2025-05-05 06:30:49 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:49 --> Controller Class Initialized
INFO - 2025-05-05 06:30:49 --> Config Class Initialized
INFO - 2025-05-05 06:30:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:49 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:49 --> URI Class Initialized
DEBUG - 2025-05-05 06:30:49 --> No URI present. Default controller set.
INFO - 2025-05-05 06:30:49 --> Router Class Initialized
INFO - 2025-05-05 06:30:49 --> Output Class Initialized
INFO - 2025-05-05 06:30:49 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:49 --> Input Class Initialized
INFO - 2025-05-05 06:30:49 --> Language Class Initialized
INFO - 2025-05-05 06:30:49 --> Loader Class Initialized
INFO - 2025-05-05 06:30:49 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:49 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:49 --> Controller Class Initialized
INFO - 2025-05-05 06:30:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:30:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:30:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 06:30:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:30:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:30:49 --> Final output sent to browser
DEBUG - 2025-05-05 06:30:49 --> Total execution time: 0.1128
INFO - 2025-05-05 06:30:51 --> Config Class Initialized
INFO - 2025-05-05 06:30:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:51 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:51 --> URI Class Initialized
INFO - 2025-05-05 06:30:51 --> Router Class Initialized
INFO - 2025-05-05 06:30:51 --> Output Class Initialized
INFO - 2025-05-05 06:30:51 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:51 --> Input Class Initialized
INFO - 2025-05-05 06:30:51 --> Language Class Initialized
INFO - 2025-05-05 06:30:51 --> Loader Class Initialized
INFO - 2025-05-05 06:30:51 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:51 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:51 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:51 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:51 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:51 --> Controller Class Initialized
INFO - 2025-05-05 14:30:51 --> Model "AuctionModel" initialized
INFO - 2025-05-05 06:30:57 --> Config Class Initialized
INFO - 2025-05-05 06:30:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:30:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:30:57 --> Utf8 Class Initialized
INFO - 2025-05-05 06:30:57 --> URI Class Initialized
INFO - 2025-05-05 06:30:57 --> Router Class Initialized
INFO - 2025-05-05 06:30:57 --> Output Class Initialized
INFO - 2025-05-05 06:30:57 --> Security Class Initialized
DEBUG - 2025-05-05 06:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:30:57 --> Input Class Initialized
INFO - 2025-05-05 06:30:57 --> Language Class Initialized
INFO - 2025-05-05 06:30:57 --> Loader Class Initialized
INFO - 2025-05-05 06:30:57 --> Helper loaded: url_helper
INFO - 2025-05-05 06:30:57 --> Helper loaded: string_helper
INFO - 2025-05-05 06:30:57 --> Helper loaded: form_helper
INFO - 2025-05-05 06:30:57 --> Helper loaded: file_helper
INFO - 2025-05-05 06:30:57 --> Helper loaded: html_helper
INFO - 2025-05-05 06:30:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:30:57 --> Controller Class Initialized
INFO - 2025-05-05 14:30:57 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:30:57 --> Model "UserModel" initialized
INFO - 2025-05-05 06:31:02 --> Config Class Initialized
INFO - 2025-05-05 06:31:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:02 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:02 --> URI Class Initialized
INFO - 2025-05-05 06:31:02 --> Router Class Initialized
INFO - 2025-05-05 06:31:02 --> Output Class Initialized
INFO - 2025-05-05 06:31:02 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:02 --> Input Class Initialized
INFO - 2025-05-05 06:31:02 --> Language Class Initialized
INFO - 2025-05-05 06:31:02 --> Loader Class Initialized
INFO - 2025-05-05 06:31:02 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:02 --> Helper loaded: string_helper
INFO - 2025-05-05 06:31:02 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:02 --> Helper loaded: file_helper
INFO - 2025-05-05 06:31:02 --> Helper loaded: html_helper
INFO - 2025-05-05 06:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:03 --> Controller Class Initialized
INFO - 2025-05-05 14:31:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:31:03 --> Model "UserModel" initialized
INFO - 2025-05-05 14:31:03 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:31:07 --> Config Class Initialized
INFO - 2025-05-05 06:31:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:07 --> URI Class Initialized
INFO - 2025-05-05 06:31:07 --> Router Class Initialized
INFO - 2025-05-05 06:31:07 --> Output Class Initialized
INFO - 2025-05-05 06:31:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:07 --> Input Class Initialized
INFO - 2025-05-05 06:31:07 --> Language Class Initialized
INFO - 2025-05-05 06:31:07 --> Loader Class Initialized
INFO - 2025-05-05 06:31:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:07 --> Helper loaded: string_helper
INFO - 2025-05-05 06:31:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:07 --> Helper loaded: file_helper
INFO - 2025-05-05 06:31:07 --> Helper loaded: html_helper
INFO - 2025-05-05 06:31:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:07 --> Controller Class Initialized
INFO - 2025-05-05 06:31:07 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:31:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:31:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:31:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:31:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:31:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:31:07 --> Final output sent to browser
DEBUG - 2025-05-05 06:31:07 --> Total execution time: 0.1239
INFO - 2025-05-05 06:31:08 --> Config Class Initialized
INFO - 2025-05-05 06:31:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:08 --> URI Class Initialized
INFO - 2025-05-05 06:31:08 --> Router Class Initialized
INFO - 2025-05-05 06:31:08 --> Output Class Initialized
INFO - 2025-05-05 06:31:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:08 --> Input Class Initialized
INFO - 2025-05-05 06:31:08 --> Language Class Initialized
INFO - 2025-05-05 06:31:08 --> Loader Class Initialized
INFO - 2025-05-05 06:31:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:08 --> Helper loaded: string_helper
INFO - 2025-05-05 06:31:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:08 --> Helper loaded: file_helper
INFO - 2025-05-05 06:31:08 --> Helper loaded: html_helper
INFO - 2025-05-05 06:31:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:08 --> Controller Class Initialized
INFO - 2025-05-05 14:31:08 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:31:08 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:31:08 --> Final output sent to browser
DEBUG - 2025-05-05 14:31:08 --> Total execution time: 0.1949
INFO - 2025-05-05 06:31:55 --> Config Class Initialized
INFO - 2025-05-05 06:31:55 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:55 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:55 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:55 --> URI Class Initialized
INFO - 2025-05-05 06:31:55 --> Router Class Initialized
INFO - 2025-05-05 06:31:55 --> Output Class Initialized
INFO - 2025-05-05 06:31:55 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:55 --> Input Class Initialized
INFO - 2025-05-05 06:31:55 --> Language Class Initialized
INFO - 2025-05-05 06:31:55 --> Loader Class Initialized
INFO - 2025-05-05 06:31:55 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:55 --> Helper loaded: string_helper
INFO - 2025-05-05 06:31:55 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:55 --> Helper loaded: file_helper
INFO - 2025-05-05 06:31:55 --> Helper loaded: html_helper
INFO - 2025-05-05 06:31:55 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:55 --> Controller Class Initialized
INFO - 2025-05-05 06:31:55 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:31:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:31:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:31:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:31:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:31:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:31:55 --> Final output sent to browser
DEBUG - 2025-05-05 06:31:55 --> Total execution time: 0.1343
INFO - 2025-05-05 06:31:56 --> Config Class Initialized
INFO - 2025-05-05 06:31:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:56 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:56 --> URI Class Initialized
INFO - 2025-05-05 06:31:56 --> Router Class Initialized
INFO - 2025-05-05 06:31:56 --> Output Class Initialized
INFO - 2025-05-05 06:31:56 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:56 --> Input Class Initialized
INFO - 2025-05-05 06:31:56 --> Language Class Initialized
INFO - 2025-05-05 06:31:56 --> Loader Class Initialized
INFO - 2025-05-05 06:31:56 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:56 --> Helper loaded: string_helper
INFO - 2025-05-05 06:31:56 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:56 --> Helper loaded: file_helper
INFO - 2025-05-05 06:31:56 --> Helper loaded: html_helper
INFO - 2025-05-05 06:31:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:56 --> Controller Class Initialized
INFO - 2025-05-05 14:31:56 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:31:56 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:31:56 --> Final output sent to browser
DEBUG - 2025-05-05 14:31:56 --> Total execution time: 0.1370
INFO - 2025-05-05 06:32:56 --> Config Class Initialized
INFO - 2025-05-05 06:32:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:32:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:32:56 --> Utf8 Class Initialized
INFO - 2025-05-05 06:32:56 --> URI Class Initialized
INFO - 2025-05-05 06:32:56 --> Router Class Initialized
INFO - 2025-05-05 06:32:56 --> Output Class Initialized
INFO - 2025-05-05 06:32:56 --> Security Class Initialized
DEBUG - 2025-05-05 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:32:56 --> Input Class Initialized
INFO - 2025-05-05 06:32:56 --> Language Class Initialized
INFO - 2025-05-05 06:32:56 --> Loader Class Initialized
INFO - 2025-05-05 06:32:56 --> Helper loaded: url_helper
INFO - 2025-05-05 06:32:56 --> Helper loaded: string_helper
INFO - 2025-05-05 06:32:56 --> Helper loaded: form_helper
INFO - 2025-05-05 06:32:56 --> Helper loaded: file_helper
INFO - 2025-05-05 06:32:56 --> Helper loaded: html_helper
INFO - 2025-05-05 06:32:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:32:56 --> Controller Class Initialized
INFO - 2025-05-05 06:32:56 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:32:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:32:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:32:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:32:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:32:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:32:56 --> Final output sent to browser
DEBUG - 2025-05-05 06:32:56 --> Total execution time: 0.1224
INFO - 2025-05-05 06:32:58 --> Config Class Initialized
INFO - 2025-05-05 06:32:58 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:32:58 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:32:58 --> Utf8 Class Initialized
INFO - 2025-05-05 06:32:58 --> URI Class Initialized
INFO - 2025-05-05 06:32:58 --> Router Class Initialized
INFO - 2025-05-05 06:32:58 --> Output Class Initialized
INFO - 2025-05-05 06:32:58 --> Security Class Initialized
DEBUG - 2025-05-05 06:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:32:58 --> Input Class Initialized
INFO - 2025-05-05 06:32:58 --> Language Class Initialized
INFO - 2025-05-05 06:32:58 --> Loader Class Initialized
INFO - 2025-05-05 06:32:58 --> Helper loaded: url_helper
INFO - 2025-05-05 06:32:58 --> Helper loaded: string_helper
INFO - 2025-05-05 06:32:58 --> Helper loaded: form_helper
INFO - 2025-05-05 06:32:58 --> Helper loaded: file_helper
INFO - 2025-05-05 06:32:58 --> Helper loaded: html_helper
INFO - 2025-05-05 06:32:58 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:32:58 --> Controller Class Initialized
INFO - 2025-05-05 14:32:58 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:32:58 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:32:58 --> Final output sent to browser
DEBUG - 2025-05-05 14:32:58 --> Total execution time: 0.1976
INFO - 2025-05-05 06:41:50 --> Config Class Initialized
INFO - 2025-05-05 06:41:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:50 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:50 --> URI Class Initialized
INFO - 2025-05-05 06:41:50 --> Router Class Initialized
INFO - 2025-05-05 06:41:50 --> Output Class Initialized
INFO - 2025-05-05 06:41:50 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:50 --> Input Class Initialized
INFO - 2025-05-05 06:41:50 --> Language Class Initialized
INFO - 2025-05-05 06:41:50 --> Loader Class Initialized
INFO - 2025-05-05 06:41:50 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:50 --> Helper loaded: string_helper
INFO - 2025-05-05 06:41:50 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:50 --> Helper loaded: file_helper
INFO - 2025-05-05 06:41:50 --> Helper loaded: html_helper
INFO - 2025-05-05 06:41:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:50 --> Controller Class Initialized
INFO - 2025-05-05 14:41:50 --> Model "UserModel" initialized
INFO - 2025-05-05 06:41:51 --> Config Class Initialized
INFO - 2025-05-05 06:41:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:51 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:51 --> URI Class Initialized
INFO - 2025-05-05 06:41:51 --> Router Class Initialized
INFO - 2025-05-05 06:41:51 --> Output Class Initialized
INFO - 2025-05-05 06:41:51 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:51 --> Input Class Initialized
INFO - 2025-05-05 06:41:51 --> Language Class Initialized
INFO - 2025-05-05 06:41:51 --> Loader Class Initialized
INFO - 2025-05-05 06:41:51 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:51 --> Helper loaded: string_helper
INFO - 2025-05-05 06:41:51 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:51 --> Helper loaded: file_helper
INFO - 2025-05-05 06:41:51 --> Helper loaded: html_helper
INFO - 2025-05-05 06:41:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:51 --> Controller Class Initialized
INFO - 2025-05-05 14:41:51 --> Model "UserModel" initialized
INFO - 2025-05-05 06:41:53 --> Config Class Initialized
INFO - 2025-05-05 06:41:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:53 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:53 --> URI Class Initialized
INFO - 2025-05-05 06:41:53 --> Router Class Initialized
INFO - 2025-05-05 06:41:53 --> Output Class Initialized
INFO - 2025-05-05 06:41:53 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:53 --> Input Class Initialized
INFO - 2025-05-05 06:41:53 --> Language Class Initialized
INFO - 2025-05-05 06:41:53 --> Loader Class Initialized
INFO - 2025-05-05 06:41:53 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:53 --> Helper loaded: string_helper
INFO - 2025-05-05 06:41:53 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:53 --> Helper loaded: file_helper
INFO - 2025-05-05 06:41:53 --> Helper loaded: html_helper
INFO - 2025-05-05 06:41:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:53 --> Controller Class Initialized
INFO - 2025-05-05 14:41:53 --> Model "UserModel" initialized
INFO - 2025-05-05 06:41:55 --> Config Class Initialized
INFO - 2025-05-05 06:41:55 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:55 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:55 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:55 --> URI Class Initialized
INFO - 2025-05-05 06:41:55 --> Router Class Initialized
INFO - 2025-05-05 06:41:55 --> Output Class Initialized
INFO - 2025-05-05 06:41:55 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:55 --> Input Class Initialized
INFO - 2025-05-05 06:41:55 --> Language Class Initialized
INFO - 2025-05-05 06:41:55 --> Loader Class Initialized
INFO - 2025-05-05 06:41:55 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:55 --> Helper loaded: string_helper
INFO - 2025-05-05 06:41:55 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:55 --> Helper loaded: file_helper
INFO - 2025-05-05 06:41:55 --> Helper loaded: html_helper
INFO - 2025-05-05 06:41:55 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:55 --> Controller Class Initialized
INFO - 2025-05-05 14:41:55 --> Model "UserModel" initialized
INFO - 2025-05-05 06:41:56 --> Config Class Initialized
INFO - 2025-05-05 06:41:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:56 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:56 --> URI Class Initialized
INFO - 2025-05-05 06:41:56 --> Router Class Initialized
INFO - 2025-05-05 06:41:56 --> Output Class Initialized
INFO - 2025-05-05 06:41:56 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:56 --> Input Class Initialized
INFO - 2025-05-05 06:41:56 --> Language Class Initialized
INFO - 2025-05-05 06:41:56 --> Loader Class Initialized
INFO - 2025-05-05 06:41:56 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:56 --> Helper loaded: string_helper
INFO - 2025-05-05 06:41:56 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:56 --> Helper loaded: file_helper
INFO - 2025-05-05 06:41:56 --> Helper loaded: html_helper
INFO - 2025-05-05 06:41:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:56 --> Controller Class Initialized
INFO - 2025-05-05 14:41:56 --> Model "UserModel" initialized
INFO - 2025-05-05 06:42:20 --> Config Class Initialized
INFO - 2025-05-05 06:42:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:42:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:42:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:42:20 --> URI Class Initialized
INFO - 2025-05-05 06:42:21 --> Router Class Initialized
INFO - 2025-05-05 06:42:21 --> Output Class Initialized
INFO - 2025-05-05 06:42:21 --> Security Class Initialized
DEBUG - 2025-05-05 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:42:21 --> Input Class Initialized
INFO - 2025-05-05 06:42:21 --> Language Class Initialized
INFO - 2025-05-05 06:42:21 --> Loader Class Initialized
INFO - 2025-05-05 06:42:21 --> Helper loaded: url_helper
INFO - 2025-05-05 06:42:21 --> Helper loaded: string_helper
INFO - 2025-05-05 06:42:21 --> Helper loaded: form_helper
INFO - 2025-05-05 06:42:21 --> Helper loaded: file_helper
INFO - 2025-05-05 06:42:21 --> Helper loaded: html_helper
INFO - 2025-05-05 06:42:21 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:42:21 --> Controller Class Initialized
INFO - 2025-05-05 14:42:21 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:42:21 --> Model "UserModel" initialized
INFO - 2025-05-05 06:42:27 --> Config Class Initialized
INFO - 2025-05-05 06:42:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:42:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:42:27 --> Utf8 Class Initialized
INFO - 2025-05-05 06:42:27 --> URI Class Initialized
INFO - 2025-05-05 06:42:27 --> Router Class Initialized
INFO - 2025-05-05 06:42:27 --> Output Class Initialized
INFO - 2025-05-05 06:42:27 --> Security Class Initialized
DEBUG - 2025-05-05 06:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:42:27 --> Input Class Initialized
INFO - 2025-05-05 06:42:27 --> Language Class Initialized
INFO - 2025-05-05 06:42:27 --> Loader Class Initialized
INFO - 2025-05-05 06:42:27 --> Helper loaded: url_helper
INFO - 2025-05-05 06:42:27 --> Helper loaded: string_helper
INFO - 2025-05-05 06:42:27 --> Helper loaded: form_helper
INFO - 2025-05-05 06:42:27 --> Helper loaded: file_helper
INFO - 2025-05-05 06:42:27 --> Helper loaded: html_helper
INFO - 2025-05-05 06:42:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:42:27 --> Controller Class Initialized
INFO - 2025-05-05 14:42:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:42:27 --> Model "UserModel" initialized
INFO - 2025-05-05 06:42:30 --> Config Class Initialized
INFO - 2025-05-05 06:42:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:42:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:42:30 --> Utf8 Class Initialized
INFO - 2025-05-05 06:42:30 --> URI Class Initialized
INFO - 2025-05-05 06:42:30 --> Router Class Initialized
INFO - 2025-05-05 06:42:30 --> Output Class Initialized
INFO - 2025-05-05 06:42:30 --> Security Class Initialized
DEBUG - 2025-05-05 06:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:42:30 --> Input Class Initialized
INFO - 2025-05-05 06:42:30 --> Language Class Initialized
INFO - 2025-05-05 06:42:30 --> Loader Class Initialized
INFO - 2025-05-05 06:42:30 --> Helper loaded: url_helper
INFO - 2025-05-05 06:42:30 --> Helper loaded: string_helper
INFO - 2025-05-05 06:42:30 --> Helper loaded: form_helper
INFO - 2025-05-05 06:42:30 --> Helper loaded: file_helper
INFO - 2025-05-05 06:42:30 --> Helper loaded: html_helper
INFO - 2025-05-05 06:42:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:42:30 --> Controller Class Initialized
INFO - 2025-05-05 14:42:30 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:42:30 --> Model "UserModel" initialized
INFO - 2025-05-05 06:42:33 --> Config Class Initialized
INFO - 2025-05-05 06:42:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:42:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:42:33 --> Utf8 Class Initialized
INFO - 2025-05-05 06:42:33 --> URI Class Initialized
INFO - 2025-05-05 06:42:33 --> Router Class Initialized
INFO - 2025-05-05 06:42:33 --> Output Class Initialized
INFO - 2025-05-05 06:42:33 --> Security Class Initialized
DEBUG - 2025-05-05 06:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:42:33 --> Input Class Initialized
INFO - 2025-05-05 06:42:33 --> Language Class Initialized
INFO - 2025-05-05 06:42:33 --> Loader Class Initialized
INFO - 2025-05-05 06:42:33 --> Helper loaded: url_helper
INFO - 2025-05-05 06:42:33 --> Helper loaded: string_helper
INFO - 2025-05-05 06:42:33 --> Helper loaded: form_helper
INFO - 2025-05-05 06:42:33 --> Helper loaded: file_helper
INFO - 2025-05-05 06:42:33 --> Helper loaded: html_helper
INFO - 2025-05-05 06:42:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:42:33 --> Controller Class Initialized
INFO - 2025-05-05 14:42:33 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:42:33 --> Model "UserModel" initialized
INFO - 2025-05-05 06:44:06 --> Config Class Initialized
INFO - 2025-05-05 06:44:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:44:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:44:06 --> Utf8 Class Initialized
INFO - 2025-05-05 06:44:06 --> URI Class Initialized
INFO - 2025-05-05 06:44:06 --> Router Class Initialized
INFO - 2025-05-05 06:44:06 --> Output Class Initialized
INFO - 2025-05-05 06:44:06 --> Security Class Initialized
DEBUG - 2025-05-05 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:44:06 --> Input Class Initialized
INFO - 2025-05-05 06:44:06 --> Language Class Initialized
INFO - 2025-05-05 06:44:06 --> Loader Class Initialized
INFO - 2025-05-05 06:44:06 --> Helper loaded: url_helper
INFO - 2025-05-05 06:44:06 --> Helper loaded: string_helper
INFO - 2025-05-05 06:44:06 --> Helper loaded: form_helper
INFO - 2025-05-05 06:44:06 --> Helper loaded: file_helper
INFO - 2025-05-05 06:44:06 --> Helper loaded: html_helper
INFO - 2025-05-05 06:44:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:44:06 --> Controller Class Initialized
INFO - 2025-05-05 14:44:06 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:44:06 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:44:07 --> Config Class Initialized
INFO - 2025-05-05 06:44:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:44:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:44:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:44:07 --> URI Class Initialized
INFO - 2025-05-05 06:44:07 --> Router Class Initialized
INFO - 2025-05-05 06:44:07 --> Output Class Initialized
INFO - 2025-05-05 06:44:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:44:07 --> Input Class Initialized
INFO - 2025-05-05 06:44:07 --> Language Class Initialized
INFO - 2025-05-05 06:44:07 --> Loader Class Initialized
INFO - 2025-05-05 06:44:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:44:07 --> Helper loaded: string_helper
INFO - 2025-05-05 06:44:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:44:07 --> Helper loaded: file_helper
INFO - 2025-05-05 06:44:07 --> Helper loaded: html_helper
INFO - 2025-05-05 06:44:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:44:07 --> Controller Class Initialized
INFO - 2025-05-05 14:44:07 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:44:07 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:44:07 --> Final output sent to browser
DEBUG - 2025-05-05 14:44:07 --> Total execution time: 0.1109
INFO - 2025-05-05 06:46:34 --> Config Class Initialized
INFO - 2025-05-05 06:46:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:46:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:46:34 --> Utf8 Class Initialized
INFO - 2025-05-05 06:46:34 --> URI Class Initialized
INFO - 2025-05-05 06:46:34 --> Router Class Initialized
INFO - 2025-05-05 06:46:34 --> Output Class Initialized
INFO - 2025-05-05 06:46:34 --> Security Class Initialized
DEBUG - 2025-05-05 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:46:34 --> Input Class Initialized
INFO - 2025-05-05 06:46:34 --> Language Class Initialized
INFO - 2025-05-05 06:46:34 --> Loader Class Initialized
INFO - 2025-05-05 06:46:34 --> Helper loaded: url_helper
INFO - 2025-05-05 06:46:34 --> Helper loaded: string_helper
INFO - 2025-05-05 06:46:34 --> Helper loaded: form_helper
INFO - 2025-05-05 06:46:34 --> Helper loaded: file_helper
INFO - 2025-05-05 06:46:34 --> Helper loaded: html_helper
INFO - 2025-05-05 06:46:34 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:46:34 --> Controller Class Initialized
INFO - 2025-05-05 14:46:34 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:46:34 --> Model "UserModel" initialized
INFO - 2025-05-05 06:46:51 --> Config Class Initialized
INFO - 2025-05-05 06:46:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:46:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:46:51 --> Utf8 Class Initialized
INFO - 2025-05-05 06:46:51 --> URI Class Initialized
INFO - 2025-05-05 06:46:51 --> Router Class Initialized
INFO - 2025-05-05 06:46:51 --> Output Class Initialized
INFO - 2025-05-05 06:46:51 --> Security Class Initialized
DEBUG - 2025-05-05 06:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:46:51 --> Input Class Initialized
INFO - 2025-05-05 06:46:51 --> Language Class Initialized
INFO - 2025-05-05 06:46:52 --> Loader Class Initialized
INFO - 2025-05-05 06:46:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:46:52 --> Helper loaded: string_helper
INFO - 2025-05-05 06:46:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:46:52 --> Helper loaded: file_helper
INFO - 2025-05-05 06:46:52 --> Helper loaded: html_helper
INFO - 2025-05-05 06:46:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:46:52 --> Controller Class Initialized
INFO - 2025-05-05 14:46:52 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:46:52 --> Model "UserModel" initialized
INFO - 2025-05-05 14:46:52 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:47:02 --> Config Class Initialized
INFO - 2025-05-05 06:47:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:02 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:02 --> URI Class Initialized
INFO - 2025-05-05 06:47:02 --> Router Class Initialized
INFO - 2025-05-05 06:47:02 --> Output Class Initialized
INFO - 2025-05-05 06:47:02 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:02 --> Input Class Initialized
INFO - 2025-05-05 06:47:02 --> Language Class Initialized
INFO - 2025-05-05 06:47:02 --> Loader Class Initialized
INFO - 2025-05-05 06:47:02 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:02 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:02 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:02 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:02 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:03 --> Controller Class Initialized
INFO - 2025-05-05 06:47:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:47:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:47:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:47:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:47:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:47:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:47:03 --> Final output sent to browser
DEBUG - 2025-05-05 06:47:03 --> Total execution time: 0.1643
INFO - 2025-05-05 06:47:04 --> Config Class Initialized
INFO - 2025-05-05 06:47:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:04 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:04 --> URI Class Initialized
INFO - 2025-05-05 06:47:04 --> Router Class Initialized
INFO - 2025-05-05 06:47:04 --> Output Class Initialized
INFO - 2025-05-05 06:47:04 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:04 --> Input Class Initialized
INFO - 2025-05-05 06:47:04 --> Language Class Initialized
INFO - 2025-05-05 06:47:04 --> Loader Class Initialized
INFO - 2025-05-05 06:47:04 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:04 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:04 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:04 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:04 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:04 --> Controller Class Initialized
INFO - 2025-05-05 14:47:04 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:47:04 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:47:04 --> Final output sent to browser
DEBUG - 2025-05-05 14:47:04 --> Total execution time: 0.2618
INFO - 2025-05-05 06:47:21 --> Config Class Initialized
INFO - 2025-05-05 06:47:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:21 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:21 --> URI Class Initialized
INFO - 2025-05-05 06:47:21 --> Router Class Initialized
INFO - 2025-05-05 06:47:21 --> Output Class Initialized
INFO - 2025-05-05 06:47:21 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:21 --> Input Class Initialized
INFO - 2025-05-05 06:47:21 --> Language Class Initialized
INFO - 2025-05-05 06:47:21 --> Loader Class Initialized
INFO - 2025-05-05 06:47:21 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:21 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:21 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:21 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:21 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:21 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:21 --> Controller Class Initialized
INFO - 2025-05-05 14:47:21 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:47:21 --> Model "UserModel" initialized
INFO - 2025-05-05 14:47:21 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:47:23 --> Config Class Initialized
INFO - 2025-05-05 06:47:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:23 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:23 --> URI Class Initialized
INFO - 2025-05-05 06:47:23 --> Router Class Initialized
INFO - 2025-05-05 06:47:23 --> Output Class Initialized
INFO - 2025-05-05 06:47:23 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:23 --> Input Class Initialized
INFO - 2025-05-05 06:47:23 --> Language Class Initialized
INFO - 2025-05-05 06:47:23 --> Loader Class Initialized
INFO - 2025-05-05 06:47:23 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:23 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:23 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:23 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:23 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:23 --> Controller Class Initialized
INFO - 2025-05-05 06:47:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:47:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:47:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:47:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:47:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:47:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:47:23 --> Final output sent to browser
DEBUG - 2025-05-05 06:47:23 --> Total execution time: 0.1779
INFO - 2025-05-05 06:47:24 --> Config Class Initialized
INFO - 2025-05-05 06:47:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:24 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:24 --> URI Class Initialized
INFO - 2025-05-05 06:47:24 --> Router Class Initialized
INFO - 2025-05-05 06:47:24 --> Output Class Initialized
INFO - 2025-05-05 06:47:24 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:24 --> Input Class Initialized
INFO - 2025-05-05 06:47:24 --> Language Class Initialized
INFO - 2025-05-05 06:47:24 --> Loader Class Initialized
INFO - 2025-05-05 06:47:24 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:24 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:24 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:24 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:24 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:24 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:24 --> Controller Class Initialized
INFO - 2025-05-05 14:47:24 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:47:24 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:47:24 --> Final output sent to browser
DEBUG - 2025-05-05 14:47:24 --> Total execution time: 0.1979
INFO - 2025-05-05 06:47:50 --> Config Class Initialized
INFO - 2025-05-05 06:47:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:47:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:47:50 --> Utf8 Class Initialized
INFO - 2025-05-05 06:47:50 --> URI Class Initialized
INFO - 2025-05-05 06:47:50 --> Router Class Initialized
INFO - 2025-05-05 06:47:50 --> Output Class Initialized
INFO - 2025-05-05 06:47:50 --> Security Class Initialized
DEBUG - 2025-05-05 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:47:50 --> Input Class Initialized
INFO - 2025-05-05 06:47:50 --> Language Class Initialized
INFO - 2025-05-05 06:47:50 --> Loader Class Initialized
INFO - 2025-05-05 06:47:50 --> Helper loaded: url_helper
INFO - 2025-05-05 06:47:50 --> Helper loaded: string_helper
INFO - 2025-05-05 06:47:50 --> Helper loaded: form_helper
INFO - 2025-05-05 06:47:50 --> Helper loaded: file_helper
INFO - 2025-05-05 06:47:50 --> Helper loaded: html_helper
INFO - 2025-05-05 06:47:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:47:50 --> Controller Class Initialized
INFO - 2025-05-05 14:47:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:47:50 --> Model "StaffModel" initialized
ERROR - 2025-05-05 14:47:51 --> Severity: Warning --> Undefined property: Staff::$UserModel C:\xampp\htdocs\storage_auctions\application\controllers\Staff.php 551
ERROR - 2025-05-05 14:47:51 --> Severity: error --> Exception: Call to a member function get_user_by_company_id() on null C:\xampp\htdocs\storage_auctions\application\controllers\Staff.php 551
INFO - 2025-05-05 06:48:11 --> Config Class Initialized
INFO - 2025-05-05 06:48:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:48:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:48:11 --> Utf8 Class Initialized
INFO - 2025-05-05 06:48:11 --> URI Class Initialized
INFO - 2025-05-05 06:48:11 --> Router Class Initialized
INFO - 2025-05-05 06:48:11 --> Output Class Initialized
INFO - 2025-05-05 06:48:11 --> Security Class Initialized
DEBUG - 2025-05-05 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:48:11 --> Input Class Initialized
INFO - 2025-05-05 06:48:11 --> Language Class Initialized
INFO - 2025-05-05 06:48:11 --> Loader Class Initialized
INFO - 2025-05-05 06:48:11 --> Helper loaded: url_helper
INFO - 2025-05-05 06:48:11 --> Helper loaded: string_helper
INFO - 2025-05-05 06:48:11 --> Helper loaded: form_helper
INFO - 2025-05-05 06:48:11 --> Helper loaded: file_helper
INFO - 2025-05-05 06:48:11 --> Helper loaded: html_helper
INFO - 2025-05-05 06:48:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:48:11 --> Controller Class Initialized
INFO - 2025-05-05 14:48:11 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:48:11 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:48:11 --> Model "UserModel" initialized
INFO - 2025-05-05 06:57:15 --> Config Class Initialized
INFO - 2025-05-05 06:57:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:57:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:57:15 --> Utf8 Class Initialized
INFO - 2025-05-05 06:57:15 --> URI Class Initialized
INFO - 2025-05-05 06:57:15 --> Router Class Initialized
INFO - 2025-05-05 06:57:15 --> Output Class Initialized
INFO - 2025-05-05 06:57:15 --> Security Class Initialized
DEBUG - 2025-05-05 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:57:15 --> Input Class Initialized
INFO - 2025-05-05 06:57:15 --> Language Class Initialized
INFO - 2025-05-05 06:57:15 --> Loader Class Initialized
INFO - 2025-05-05 06:57:15 --> Helper loaded: url_helper
INFO - 2025-05-05 06:57:15 --> Helper loaded: string_helper
INFO - 2025-05-05 06:57:15 --> Helper loaded: form_helper
INFO - 2025-05-05 06:57:15 --> Helper loaded: file_helper
INFO - 2025-05-05 06:57:15 --> Helper loaded: html_helper
INFO - 2025-05-05 06:57:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:57:15 --> Controller Class Initialized
INFO - 2025-05-05 06:57:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:57:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:57:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:57:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:57:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:57:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:57:15 --> Final output sent to browser
DEBUG - 2025-05-05 06:57:15 --> Total execution time: 0.1178
INFO - 2025-05-05 06:57:16 --> Config Class Initialized
INFO - 2025-05-05 06:57:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:57:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:57:16 --> Utf8 Class Initialized
INFO - 2025-05-05 06:57:16 --> URI Class Initialized
INFO - 2025-05-05 06:57:16 --> Router Class Initialized
INFO - 2025-05-05 06:57:16 --> Output Class Initialized
INFO - 2025-05-05 06:57:16 --> Security Class Initialized
DEBUG - 2025-05-05 06:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:57:16 --> Input Class Initialized
INFO - 2025-05-05 06:57:16 --> Language Class Initialized
INFO - 2025-05-05 06:57:16 --> Loader Class Initialized
INFO - 2025-05-05 06:57:16 --> Helper loaded: url_helper
INFO - 2025-05-05 06:57:16 --> Helper loaded: string_helper
INFO - 2025-05-05 06:57:16 --> Helper loaded: form_helper
INFO - 2025-05-05 06:57:16 --> Helper loaded: file_helper
INFO - 2025-05-05 06:57:16 --> Helper loaded: html_helper
INFO - 2025-05-05 06:57:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:57:16 --> Controller Class Initialized
INFO - 2025-05-05 14:57:16 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:57:16 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:57:16 --> Final output sent to browser
DEBUG - 2025-05-05 14:57:16 --> Total execution time: 0.3075
INFO - 2025-05-05 06:58:01 --> Config Class Initialized
INFO - 2025-05-05 06:58:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:58:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:58:01 --> Utf8 Class Initialized
INFO - 2025-05-05 06:58:01 --> URI Class Initialized
INFO - 2025-05-05 06:58:01 --> Router Class Initialized
INFO - 2025-05-05 06:58:01 --> Output Class Initialized
INFO - 2025-05-05 06:58:01 --> Security Class Initialized
DEBUG - 2025-05-05 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:58:01 --> Input Class Initialized
INFO - 2025-05-05 06:58:01 --> Language Class Initialized
INFO - 2025-05-05 06:58:01 --> Loader Class Initialized
INFO - 2025-05-05 06:58:01 --> Helper loaded: url_helper
INFO - 2025-05-05 06:58:01 --> Helper loaded: string_helper
INFO - 2025-05-05 06:58:01 --> Helper loaded: form_helper
INFO - 2025-05-05 06:58:01 --> Helper loaded: file_helper
INFO - 2025-05-05 06:58:01 --> Helper loaded: html_helper
INFO - 2025-05-05 06:58:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:58:01 --> Controller Class Initialized
INFO - 2025-05-05 14:58:01 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:58:01 --> Model "UserModel" initialized
INFO - 2025-05-05 06:58:08 --> Config Class Initialized
INFO - 2025-05-05 06:58:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:58:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:58:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:58:08 --> URI Class Initialized
INFO - 2025-05-05 06:58:08 --> Router Class Initialized
INFO - 2025-05-05 06:58:08 --> Output Class Initialized
INFO - 2025-05-05 06:58:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:58:08 --> Input Class Initialized
INFO - 2025-05-05 06:58:08 --> Language Class Initialized
INFO - 2025-05-05 06:58:08 --> Loader Class Initialized
INFO - 2025-05-05 06:58:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:58:08 --> Helper loaded: string_helper
INFO - 2025-05-05 06:58:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:58:08 --> Helper loaded: file_helper
INFO - 2025-05-05 06:58:08 --> Helper loaded: html_helper
INFO - 2025-05-05 06:58:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:58:09 --> Controller Class Initialized
INFO - 2025-05-05 14:58:09 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:58:09 --> Model "UserModel" initialized
INFO - 2025-05-05 14:58:09 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:58:18 --> Config Class Initialized
INFO - 2025-05-05 06:58:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:58:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:58:18 --> Utf8 Class Initialized
INFO - 2025-05-05 06:58:18 --> URI Class Initialized
INFO - 2025-05-05 06:58:18 --> Router Class Initialized
INFO - 2025-05-05 06:58:18 --> Output Class Initialized
INFO - 2025-05-05 06:58:18 --> Security Class Initialized
DEBUG - 2025-05-05 06:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:58:18 --> Input Class Initialized
INFO - 2025-05-05 06:58:18 --> Language Class Initialized
INFO - 2025-05-05 06:58:18 --> Loader Class Initialized
INFO - 2025-05-05 06:58:18 --> Helper loaded: url_helper
INFO - 2025-05-05 06:58:18 --> Helper loaded: string_helper
INFO - 2025-05-05 06:58:18 --> Helper loaded: form_helper
INFO - 2025-05-05 06:58:18 --> Helper loaded: file_helper
INFO - 2025-05-05 06:58:18 --> Helper loaded: html_helper
INFO - 2025-05-05 06:58:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:58:18 --> Controller Class Initialized
INFO - 2025-05-05 06:58:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:58:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:58:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:58:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:58:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:58:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:58:18 --> Final output sent to browser
DEBUG - 2025-05-05 06:58:18 --> Total execution time: 0.0864
INFO - 2025-05-05 06:58:19 --> Config Class Initialized
INFO - 2025-05-05 06:58:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:58:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:58:19 --> Utf8 Class Initialized
INFO - 2025-05-05 06:58:19 --> URI Class Initialized
INFO - 2025-05-05 06:58:19 --> Router Class Initialized
INFO - 2025-05-05 06:58:19 --> Output Class Initialized
INFO - 2025-05-05 06:58:19 --> Security Class Initialized
DEBUG - 2025-05-05 06:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:58:19 --> Input Class Initialized
INFO - 2025-05-05 06:58:19 --> Language Class Initialized
INFO - 2025-05-05 06:58:19 --> Loader Class Initialized
INFO - 2025-05-05 06:58:19 --> Helper loaded: url_helper
INFO - 2025-05-05 06:58:19 --> Helper loaded: string_helper
INFO - 2025-05-05 06:58:19 --> Helper loaded: form_helper
INFO - 2025-05-05 06:58:19 --> Helper loaded: file_helper
INFO - 2025-05-05 06:58:19 --> Helper loaded: html_helper
INFO - 2025-05-05 06:58:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:58:19 --> Controller Class Initialized
INFO - 2025-05-05 14:58:19 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:58:19 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:58:19 --> Final output sent to browser
DEBUG - 2025-05-05 14:58:19 --> Total execution time: 0.1793
INFO - 2025-05-05 06:59:10 --> Config Class Initialized
INFO - 2025-05-05 06:59:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:10 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:10 --> URI Class Initialized
INFO - 2025-05-05 06:59:10 --> Router Class Initialized
INFO - 2025-05-05 06:59:10 --> Output Class Initialized
INFO - 2025-05-05 06:59:10 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:10 --> Input Class Initialized
INFO - 2025-05-05 06:59:10 --> Language Class Initialized
INFO - 2025-05-05 06:59:10 --> Loader Class Initialized
INFO - 2025-05-05 06:59:10 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:10 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:10 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:10 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:10 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:10 --> Controller Class Initialized
INFO - 2025-05-05 06:59:10 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:59:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:59:10 --> Final output sent to browser
DEBUG - 2025-05-05 06:59:10 --> Total execution time: 0.0867
INFO - 2025-05-05 06:59:12 --> Config Class Initialized
INFO - 2025-05-05 06:59:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:12 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:12 --> URI Class Initialized
INFO - 2025-05-05 06:59:12 --> Router Class Initialized
INFO - 2025-05-05 06:59:12 --> Output Class Initialized
INFO - 2025-05-05 06:59:12 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:12 --> Input Class Initialized
INFO - 2025-05-05 06:59:12 --> Language Class Initialized
INFO - 2025-05-05 06:59:12 --> Loader Class Initialized
INFO - 2025-05-05 06:59:12 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:12 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:12 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:12 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:12 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:12 --> Controller Class Initialized
INFO - 2025-05-05 14:59:12 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:12 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:59:12 --> Final output sent to browser
DEBUG - 2025-05-05 14:59:12 --> Total execution time: 0.2033
INFO - 2025-05-05 06:59:20 --> Config Class Initialized
INFO - 2025-05-05 06:59:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:20 --> URI Class Initialized
INFO - 2025-05-05 06:59:20 --> Router Class Initialized
INFO - 2025-05-05 06:59:20 --> Output Class Initialized
INFO - 2025-05-05 06:59:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:20 --> Input Class Initialized
INFO - 2025-05-05 06:59:20 --> Language Class Initialized
INFO - 2025-05-05 06:59:20 --> Loader Class Initialized
INFO - 2025-05-05 06:59:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:20 --> Controller Class Initialized
INFO - 2025-05-05 14:59:20 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:20 --> Model "StaffModel" initialized
INFO - 2025-05-05 06:59:20 --> Config Class Initialized
INFO - 2025-05-05 06:59:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:20 --> URI Class Initialized
INFO - 2025-05-05 06:59:20 --> Router Class Initialized
INFO - 2025-05-05 06:59:20 --> Output Class Initialized
INFO - 2025-05-05 06:59:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:20 --> Input Class Initialized
INFO - 2025-05-05 06:59:20 --> Language Class Initialized
INFO - 2025-05-05 06:59:20 --> Loader Class Initialized
INFO - 2025-05-05 06:59:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:20 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:20 --> Controller Class Initialized
INFO - 2025-05-05 14:59:20 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:20 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:59:20 --> Final output sent to browser
DEBUG - 2025-05-05 14:59:20 --> Total execution time: 0.1321
INFO - 2025-05-05 06:59:28 --> Config Class Initialized
INFO - 2025-05-05 06:59:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:28 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:28 --> URI Class Initialized
INFO - 2025-05-05 06:59:28 --> Router Class Initialized
INFO - 2025-05-05 06:59:28 --> Output Class Initialized
INFO - 2025-05-05 06:59:28 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:28 --> Input Class Initialized
INFO - 2025-05-05 06:59:28 --> Language Class Initialized
INFO - 2025-05-05 06:59:28 --> Loader Class Initialized
INFO - 2025-05-05 06:59:28 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:28 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:28 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:28 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:28 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:28 --> Controller Class Initialized
INFO - 2025-05-05 06:59:28 --> Model "CompanyModel" initialized
INFO - 2025-05-05 06:59:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 06:59:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 06:59:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 06:59:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 06:59:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 06:59:28 --> Final output sent to browser
DEBUG - 2025-05-05 06:59:28 --> Total execution time: 0.1209
INFO - 2025-05-05 06:59:29 --> Config Class Initialized
INFO - 2025-05-05 06:59:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:29 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:29 --> URI Class Initialized
INFO - 2025-05-05 06:59:29 --> Router Class Initialized
INFO - 2025-05-05 06:59:29 --> Output Class Initialized
INFO - 2025-05-05 06:59:29 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:29 --> Input Class Initialized
INFO - 2025-05-05 06:59:29 --> Language Class Initialized
INFO - 2025-05-05 06:59:29 --> Loader Class Initialized
INFO - 2025-05-05 06:59:29 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:29 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:29 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:29 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:29 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:29 --> Controller Class Initialized
INFO - 2025-05-05 14:59:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:29 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:59:29 --> Final output sent to browser
DEBUG - 2025-05-05 14:59:29 --> Total execution time: 0.1924
INFO - 2025-05-05 06:59:31 --> Config Class Initialized
INFO - 2025-05-05 06:59:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:31 --> URI Class Initialized
INFO - 2025-05-05 06:59:31 --> Router Class Initialized
INFO - 2025-05-05 06:59:31 --> Output Class Initialized
INFO - 2025-05-05 06:59:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:31 --> Input Class Initialized
INFO - 2025-05-05 06:59:31 --> Language Class Initialized
INFO - 2025-05-05 06:59:31 --> Loader Class Initialized
INFO - 2025-05-05 06:59:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:31 --> Controller Class Initialized
INFO - 2025-05-05 14:59:31 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:31 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:59:31 --> Model "UserModel" initialized
INFO - 2025-05-05 06:59:31 --> Config Class Initialized
INFO - 2025-05-05 06:59:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:31 --> URI Class Initialized
INFO - 2025-05-05 06:59:31 --> Router Class Initialized
INFO - 2025-05-05 06:59:31 --> Output Class Initialized
INFO - 2025-05-05 06:59:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:31 --> Input Class Initialized
INFO - 2025-05-05 06:59:31 --> Language Class Initialized
INFO - 2025-05-05 06:59:31 --> Loader Class Initialized
INFO - 2025-05-05 06:59:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: string_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: file_helper
INFO - 2025-05-05 06:59:31 --> Helper loaded: html_helper
INFO - 2025-05-05 06:59:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 06:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 06:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:31 --> Controller Class Initialized
INFO - 2025-05-05 14:59:31 --> Model "CompanyModel" initialized
INFO - 2025-05-05 14:59:31 --> Model "StaffModel" initialized
INFO - 2025-05-05 14:59:31 --> Final output sent to browser
DEBUG - 2025-05-05 14:59:31 --> Total execution time: 0.1313
INFO - 2025-05-05 07:00:49 --> Config Class Initialized
INFO - 2025-05-05 07:00:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:49 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:49 --> URI Class Initialized
INFO - 2025-05-05 07:00:49 --> Router Class Initialized
INFO - 2025-05-05 07:00:49 --> Output Class Initialized
INFO - 2025-05-05 07:00:49 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:49 --> Input Class Initialized
INFO - 2025-05-05 07:00:49 --> Language Class Initialized
INFO - 2025-05-05 07:00:49 --> Loader Class Initialized
INFO - 2025-05-05 07:00:49 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:49 --> Helper loaded: string_helper
INFO - 2025-05-05 07:00:49 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:49 --> Helper loaded: file_helper
INFO - 2025-05-05 07:00:49 --> Helper loaded: html_helper
INFO - 2025-05-05 07:00:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:49 --> Controller Class Initialized
INFO - 2025-05-05 07:00:49 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:00:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:00:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:00:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:00:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:00:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:00:49 --> Final output sent to browser
DEBUG - 2025-05-05 07:00:49 --> Total execution time: 0.1290
INFO - 2025-05-05 07:00:50 --> Config Class Initialized
INFO - 2025-05-05 07:00:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:50 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:50 --> URI Class Initialized
INFO - 2025-05-05 07:00:50 --> Router Class Initialized
INFO - 2025-05-05 07:00:50 --> Output Class Initialized
INFO - 2025-05-05 07:00:50 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:50 --> Input Class Initialized
INFO - 2025-05-05 07:00:50 --> Language Class Initialized
INFO - 2025-05-05 07:00:50 --> Loader Class Initialized
INFO - 2025-05-05 07:00:50 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:50 --> Helper loaded: string_helper
INFO - 2025-05-05 07:00:50 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:50 --> Helper loaded: file_helper
INFO - 2025-05-05 07:00:50 --> Helper loaded: html_helper
INFO - 2025-05-05 07:00:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:50 --> Controller Class Initialized
INFO - 2025-05-05 15:00:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:00:50 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:00:50 --> Final output sent to browser
DEBUG - 2025-05-05 15:00:50 --> Total execution time: 0.1999
INFO - 2025-05-05 07:00:52 --> Config Class Initialized
INFO - 2025-05-05 07:00:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:52 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:52 --> URI Class Initialized
INFO - 2025-05-05 07:00:52 --> Router Class Initialized
INFO - 2025-05-05 07:00:52 --> Output Class Initialized
INFO - 2025-05-05 07:00:52 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:52 --> Input Class Initialized
INFO - 2025-05-05 07:00:52 --> Language Class Initialized
INFO - 2025-05-05 07:00:52 --> Loader Class Initialized
INFO - 2025-05-05 07:00:52 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:52 --> Helper loaded: string_helper
INFO - 2025-05-05 07:00:52 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:52 --> Helper loaded: file_helper
INFO - 2025-05-05 07:00:52 --> Helper loaded: html_helper
INFO - 2025-05-05 07:00:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:52 --> Controller Class Initialized
INFO - 2025-05-05 15:00:52 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:00:52 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:00:52 --> Model "UserModel" initialized
INFO - 2025-05-05 07:01:24 --> Config Class Initialized
INFO - 2025-05-05 07:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:24 --> URI Class Initialized
INFO - 2025-05-05 07:01:24 --> Router Class Initialized
INFO - 2025-05-05 07:01:24 --> Output Class Initialized
INFO - 2025-05-05 07:01:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:24 --> Input Class Initialized
INFO - 2025-05-05 07:01:24 --> Language Class Initialized
INFO - 2025-05-05 07:01:24 --> Loader Class Initialized
INFO - 2025-05-05 07:01:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:24 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:24 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:24 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:24 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:24 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:24 --> Controller Class Initialized
INFO - 2025-05-05 15:01:24 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:24 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:01:24 --> Model "UserModel" initialized
INFO - 2025-05-05 07:01:25 --> Config Class Initialized
INFO - 2025-05-05 07:01:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:25 --> URI Class Initialized
INFO - 2025-05-05 07:01:25 --> Router Class Initialized
INFO - 2025-05-05 07:01:25 --> Output Class Initialized
INFO - 2025-05-05 07:01:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:25 --> Input Class Initialized
INFO - 2025-05-05 07:01:25 --> Language Class Initialized
INFO - 2025-05-05 07:01:25 --> Loader Class Initialized
INFO - 2025-05-05 07:01:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:25 --> Controller Class Initialized
INFO - 2025-05-05 15:01:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:25 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:01:25 --> Final output sent to browser
DEBUG - 2025-05-05 15:01:25 --> Total execution time: 0.1278
INFO - 2025-05-05 07:01:31 --> Config Class Initialized
INFO - 2025-05-05 07:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:31 --> URI Class Initialized
INFO - 2025-05-05 07:01:31 --> Router Class Initialized
INFO - 2025-05-05 07:01:31 --> Output Class Initialized
INFO - 2025-05-05 07:01:31 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:31 --> Input Class Initialized
INFO - 2025-05-05 07:01:31 --> Language Class Initialized
INFO - 2025-05-05 07:01:31 --> Loader Class Initialized
INFO - 2025-05-05 07:01:31 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:31 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:31 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:31 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:31 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:31 --> Controller Class Initialized
INFO - 2025-05-05 15:01:31 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:31 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:01:31 --> Config Class Initialized
INFO - 2025-05-05 07:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:31 --> URI Class Initialized
INFO - 2025-05-05 07:01:31 --> Router Class Initialized
INFO - 2025-05-05 07:01:31 --> Output Class Initialized
INFO - 2025-05-05 07:01:31 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:31 --> Input Class Initialized
INFO - 2025-05-05 07:01:31 --> Language Class Initialized
INFO - 2025-05-05 07:01:31 --> Loader Class Initialized
INFO - 2025-05-05 07:01:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:32 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:32 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:32 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:32 --> Controller Class Initialized
INFO - 2025-05-05 15:01:32 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:32 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:01:32 --> Final output sent to browser
DEBUG - 2025-05-05 15:01:32 --> Total execution time: 0.1452
INFO - 2025-05-05 07:01:42 --> Config Class Initialized
INFO - 2025-05-05 07:01:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:42 --> URI Class Initialized
INFO - 2025-05-05 07:01:42 --> Router Class Initialized
INFO - 2025-05-05 07:01:42 --> Output Class Initialized
INFO - 2025-05-05 07:01:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:42 --> Input Class Initialized
INFO - 2025-05-05 07:01:42 --> Language Class Initialized
INFO - 2025-05-05 07:01:42 --> Loader Class Initialized
INFO - 2025-05-05 07:01:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:42 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:42 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:42 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:42 --> Controller Class Initialized
INFO - 2025-05-05 15:01:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:42 --> Model "UserModel" initialized
INFO - 2025-05-05 07:01:45 --> Config Class Initialized
INFO - 2025-05-05 07:01:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:45 --> URI Class Initialized
INFO - 2025-05-05 07:01:45 --> Router Class Initialized
INFO - 2025-05-05 07:01:45 --> Output Class Initialized
INFO - 2025-05-05 07:01:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:45 --> Input Class Initialized
INFO - 2025-05-05 07:01:45 --> Language Class Initialized
INFO - 2025-05-05 07:01:45 --> Loader Class Initialized
INFO - 2025-05-05 07:01:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:45 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:45 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:45 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:45 --> Controller Class Initialized
INFO - 2025-05-05 15:01:45 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:45 --> Model "UserModel" initialized
INFO - 2025-05-05 07:01:49 --> Config Class Initialized
INFO - 2025-05-05 07:01:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:49 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:49 --> URI Class Initialized
INFO - 2025-05-05 07:01:49 --> Router Class Initialized
INFO - 2025-05-05 07:01:49 --> Output Class Initialized
INFO - 2025-05-05 07:01:49 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:49 --> Input Class Initialized
INFO - 2025-05-05 07:01:49 --> Language Class Initialized
INFO - 2025-05-05 07:01:49 --> Loader Class Initialized
INFO - 2025-05-05 07:01:49 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:49 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:49 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:49 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:49 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:49 --> Controller Class Initialized
INFO - 2025-05-05 15:01:49 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:49 --> Model "UserModel" initialized
INFO - 2025-05-05 07:01:52 --> Config Class Initialized
INFO - 2025-05-05 07:01:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:52 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:52 --> URI Class Initialized
INFO - 2025-05-05 07:01:52 --> Router Class Initialized
INFO - 2025-05-05 07:01:52 --> Output Class Initialized
INFO - 2025-05-05 07:01:52 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:52 --> Input Class Initialized
INFO - 2025-05-05 07:01:52 --> Language Class Initialized
INFO - 2025-05-05 07:01:52 --> Loader Class Initialized
INFO - 2025-05-05 07:01:52 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:52 --> Helper loaded: string_helper
INFO - 2025-05-05 07:01:52 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:52 --> Helper loaded: file_helper
INFO - 2025-05-05 07:01:52 --> Helper loaded: html_helper
INFO - 2025-05-05 07:01:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:52 --> Controller Class Initialized
INFO - 2025-05-05 15:01:52 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:01:52 --> Model "UserModel" initialized
INFO - 2025-05-05 07:02:03 --> Config Class Initialized
INFO - 2025-05-05 07:02:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:03 --> URI Class Initialized
INFO - 2025-05-05 07:02:03 --> Router Class Initialized
INFO - 2025-05-05 07:02:03 --> Output Class Initialized
INFO - 2025-05-05 07:02:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:03 --> Input Class Initialized
INFO - 2025-05-05 07:02:03 --> Language Class Initialized
INFO - 2025-05-05 07:02:03 --> Loader Class Initialized
INFO - 2025-05-05 07:02:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:03 --> Helper loaded: string_helper
INFO - 2025-05-05 07:02:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:03 --> Helper loaded: file_helper
INFO - 2025-05-05 07:02:03 --> Helper loaded: html_helper
INFO - 2025-05-05 07:02:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:03 --> Controller Class Initialized
INFO - 2025-05-05 15:02:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:02:03 --> Model "UserModel" initialized
INFO - 2025-05-05 07:02:17 --> Config Class Initialized
INFO - 2025-05-05 07:02:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:17 --> URI Class Initialized
INFO - 2025-05-05 07:02:17 --> Router Class Initialized
INFO - 2025-05-05 07:02:17 --> Output Class Initialized
INFO - 2025-05-05 07:02:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:17 --> Input Class Initialized
INFO - 2025-05-05 07:02:17 --> Language Class Initialized
INFO - 2025-05-05 07:02:17 --> Loader Class Initialized
INFO - 2025-05-05 07:02:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:02:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:02:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:02:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:17 --> Controller Class Initialized
INFO - 2025-05-05 15:02:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:02:17 --> Model "UserModel" initialized
INFO - 2025-05-05 07:02:25 --> Config Class Initialized
INFO - 2025-05-05 07:02:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:25 --> URI Class Initialized
INFO - 2025-05-05 07:02:25 --> Router Class Initialized
INFO - 2025-05-05 07:02:25 --> Output Class Initialized
INFO - 2025-05-05 07:02:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:25 --> Input Class Initialized
INFO - 2025-05-05 07:02:25 --> Language Class Initialized
INFO - 2025-05-05 07:02:25 --> Loader Class Initialized
INFO - 2025-05-05 07:02:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:02:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:02:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:02:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:25 --> Controller Class Initialized
INFO - 2025-05-05 15:02:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:02:25 --> Model "UserModel" initialized
INFO - 2025-05-05 07:03:05 --> Config Class Initialized
INFO - 2025-05-05 07:03:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:05 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:05 --> URI Class Initialized
INFO - 2025-05-05 07:03:05 --> Router Class Initialized
INFO - 2025-05-05 07:03:05 --> Output Class Initialized
INFO - 2025-05-05 07:03:05 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:05 --> Input Class Initialized
INFO - 2025-05-05 07:03:05 --> Language Class Initialized
INFO - 2025-05-05 07:03:05 --> Loader Class Initialized
INFO - 2025-05-05 07:03:05 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:05 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:06 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:06 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:06 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:06 --> Controller Class Initialized
INFO - 2025-05-05 15:03:06 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:06 --> Model "UserModel" initialized
INFO - 2025-05-05 07:03:14 --> Config Class Initialized
INFO - 2025-05-05 07:03:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:14 --> URI Class Initialized
INFO - 2025-05-05 07:03:14 --> Router Class Initialized
INFO - 2025-05-05 07:03:14 --> Output Class Initialized
INFO - 2025-05-05 07:03:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:14 --> Input Class Initialized
INFO - 2025-05-05 07:03:14 --> Language Class Initialized
INFO - 2025-05-05 07:03:14 --> Loader Class Initialized
INFO - 2025-05-05 07:03:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:14 --> Controller Class Initialized
INFO - 2025-05-05 15:03:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:14 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:03:14 --> Model "UserModel" initialized
INFO - 2025-05-05 07:03:14 --> Config Class Initialized
INFO - 2025-05-05 07:03:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:14 --> URI Class Initialized
INFO - 2025-05-05 07:03:14 --> Router Class Initialized
INFO - 2025-05-05 07:03:14 --> Output Class Initialized
INFO - 2025-05-05 07:03:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:14 --> Input Class Initialized
INFO - 2025-05-05 07:03:14 --> Language Class Initialized
INFO - 2025-05-05 07:03:14 --> Loader Class Initialized
INFO - 2025-05-05 07:03:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:14 --> Controller Class Initialized
INFO - 2025-05-05 15:03:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:14 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:03:14 --> Final output sent to browser
DEBUG - 2025-05-05 15:03:14 --> Total execution time: 0.1250
INFO - 2025-05-05 07:03:15 --> Config Class Initialized
INFO - 2025-05-05 07:03:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:15 --> URI Class Initialized
INFO - 2025-05-05 07:03:15 --> Router Class Initialized
INFO - 2025-05-05 07:03:15 --> Output Class Initialized
INFO - 2025-05-05 07:03:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:15 --> Input Class Initialized
INFO - 2025-05-05 07:03:15 --> Language Class Initialized
INFO - 2025-05-05 07:03:15 --> Loader Class Initialized
INFO - 2025-05-05 07:03:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:15 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:15 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:15 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:15 --> Controller Class Initialized
INFO - 2025-05-05 15:03:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:15 --> Model "UserModel" initialized
INFO - 2025-05-05 07:03:23 --> Config Class Initialized
INFO - 2025-05-05 07:03:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:23 --> URI Class Initialized
INFO - 2025-05-05 07:03:23 --> Router Class Initialized
INFO - 2025-05-05 07:03:23 --> Output Class Initialized
INFO - 2025-05-05 07:03:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:23 --> Input Class Initialized
INFO - 2025-05-05 07:03:23 --> Language Class Initialized
INFO - 2025-05-05 07:03:23 --> Loader Class Initialized
INFO - 2025-05-05 07:03:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:23 --> Controller Class Initialized
INFO - 2025-05-05 15:03:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:23 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:03:23 --> Config Class Initialized
INFO - 2025-05-05 07:03:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:23 --> URI Class Initialized
INFO - 2025-05-05 07:03:23 --> Router Class Initialized
INFO - 2025-05-05 07:03:23 --> Output Class Initialized
INFO - 2025-05-05 07:03:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:23 --> Input Class Initialized
INFO - 2025-05-05 07:03:23 --> Language Class Initialized
INFO - 2025-05-05 07:03:23 --> Loader Class Initialized
INFO - 2025-05-05 07:03:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:23 --> Controller Class Initialized
INFO - 2025-05-05 15:03:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:23 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:03:23 --> Final output sent to browser
DEBUG - 2025-05-05 15:03:23 --> Total execution time: 0.1406
INFO - 2025-05-05 07:03:29 --> Config Class Initialized
INFO - 2025-05-05 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:29 --> URI Class Initialized
INFO - 2025-05-05 07:03:29 --> Router Class Initialized
INFO - 2025-05-05 07:03:29 --> Output Class Initialized
INFO - 2025-05-05 07:03:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:29 --> Input Class Initialized
INFO - 2025-05-05 07:03:29 --> Language Class Initialized
INFO - 2025-05-05 07:03:29 --> Loader Class Initialized
INFO - 2025-05-05 07:03:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:29 --> Controller Class Initialized
INFO - 2025-05-05 15:03:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:29 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:03:29 --> Model "UserModel" initialized
INFO - 2025-05-05 07:03:29 --> Config Class Initialized
INFO - 2025-05-05 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:29 --> URI Class Initialized
INFO - 2025-05-05 07:03:29 --> Router Class Initialized
INFO - 2025-05-05 07:03:29 --> Output Class Initialized
INFO - 2025-05-05 07:03:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:29 --> Input Class Initialized
INFO - 2025-05-05 07:03:29 --> Language Class Initialized
INFO - 2025-05-05 07:03:29 --> Loader Class Initialized
INFO - 2025-05-05 07:03:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:03:30 --> Helper loaded: html_helper
INFO - 2025-05-05 07:03:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:30 --> Controller Class Initialized
INFO - 2025-05-05 15:03:30 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:03:30 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:03:30 --> Final output sent to browser
DEBUG - 2025-05-05 15:03:30 --> Total execution time: 0.1091
INFO - 2025-05-05 07:04:06 --> Config Class Initialized
INFO - 2025-05-05 07:04:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:04:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:04:06 --> Utf8 Class Initialized
INFO - 2025-05-05 07:04:06 --> URI Class Initialized
INFO - 2025-05-05 07:04:06 --> Router Class Initialized
INFO - 2025-05-05 07:04:06 --> Output Class Initialized
INFO - 2025-05-05 07:04:06 --> Security Class Initialized
DEBUG - 2025-05-05 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:04:06 --> Input Class Initialized
INFO - 2025-05-05 07:04:06 --> Language Class Initialized
INFO - 2025-05-05 07:04:06 --> Loader Class Initialized
INFO - 2025-05-05 07:04:06 --> Helper loaded: url_helper
INFO - 2025-05-05 07:04:06 --> Helper loaded: string_helper
INFO - 2025-05-05 07:04:06 --> Helper loaded: form_helper
INFO - 2025-05-05 07:04:06 --> Helper loaded: file_helper
INFO - 2025-05-05 07:04:06 --> Helper loaded: html_helper
INFO - 2025-05-05 07:04:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:04:06 --> Controller Class Initialized
INFO - 2025-05-05 15:04:06 --> Model "UserModel" initialized
INFO - 2025-05-05 07:04:34 --> Config Class Initialized
INFO - 2025-05-05 07:04:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:04:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:04:34 --> Utf8 Class Initialized
INFO - 2025-05-05 07:04:34 --> URI Class Initialized
INFO - 2025-05-05 07:04:34 --> Router Class Initialized
INFO - 2025-05-05 07:04:34 --> Output Class Initialized
INFO - 2025-05-05 07:04:34 --> Security Class Initialized
DEBUG - 2025-05-05 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:04:34 --> Input Class Initialized
INFO - 2025-05-05 07:04:34 --> Language Class Initialized
INFO - 2025-05-05 07:04:34 --> Loader Class Initialized
INFO - 2025-05-05 07:04:34 --> Helper loaded: url_helper
INFO - 2025-05-05 07:04:34 --> Helper loaded: string_helper
INFO - 2025-05-05 07:04:34 --> Helper loaded: form_helper
INFO - 2025-05-05 07:04:34 --> Helper loaded: file_helper
INFO - 2025-05-05 07:04:34 --> Helper loaded: html_helper
INFO - 2025-05-05 07:04:34 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:04:35 --> Controller Class Initialized
INFO - 2025-05-05 15:04:35 --> Model "UserModel" initialized
INFO - 2025-05-05 07:05:15 --> Config Class Initialized
INFO - 2025-05-05 07:05:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:15 --> URI Class Initialized
INFO - 2025-05-05 07:05:15 --> Router Class Initialized
INFO - 2025-05-05 07:05:15 --> Output Class Initialized
INFO - 2025-05-05 07:05:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:15 --> Input Class Initialized
INFO - 2025-05-05 07:05:15 --> Language Class Initialized
INFO - 2025-05-05 07:05:15 --> Loader Class Initialized
INFO - 2025-05-05 07:05:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:15 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:15 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:15 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:15 --> Controller Class Initialized
INFO - 2025-05-05 15:05:15 --> Model "UserModel" initialized
INFO - 2025-05-05 07:05:19 --> Config Class Initialized
INFO - 2025-05-05 07:05:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:19 --> URI Class Initialized
INFO - 2025-05-05 07:05:19 --> Router Class Initialized
INFO - 2025-05-05 07:05:19 --> Output Class Initialized
INFO - 2025-05-05 07:05:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:19 --> Input Class Initialized
INFO - 2025-05-05 07:05:19 --> Language Class Initialized
INFO - 2025-05-05 07:05:19 --> Loader Class Initialized
INFO - 2025-05-05 07:05:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:19 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:19 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:19 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:19 --> Controller Class Initialized
INFO - 2025-05-05 15:05:19 --> Model "UserModel" initialized
INFO - 2025-05-05 07:05:20 --> Config Class Initialized
INFO - 2025-05-05 07:05:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:20 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:20 --> URI Class Initialized
DEBUG - 2025-05-05 07:05:20 --> No URI present. Default controller set.
INFO - 2025-05-05 07:05:20 --> Router Class Initialized
INFO - 2025-05-05 07:05:20 --> Output Class Initialized
INFO - 2025-05-05 07:05:20 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:20 --> Input Class Initialized
INFO - 2025-05-05 07:05:20 --> Language Class Initialized
INFO - 2025-05-05 07:05:20 --> Loader Class Initialized
INFO - 2025-05-05 07:05:20 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:20 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:20 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:20 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:20 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:20 --> Controller Class Initialized
INFO - 2025-05-05 07:05:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:05:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:05:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:05:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:05:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:05:20 --> Final output sent to browser
DEBUG - 2025-05-05 07:05:20 --> Total execution time: 0.1156
INFO - 2025-05-05 07:05:21 --> Config Class Initialized
INFO - 2025-05-05 07:05:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:22 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:22 --> URI Class Initialized
INFO - 2025-05-05 07:05:22 --> Router Class Initialized
INFO - 2025-05-05 07:05:22 --> Output Class Initialized
INFO - 2025-05-05 07:05:22 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:22 --> Input Class Initialized
INFO - 2025-05-05 07:05:22 --> Language Class Initialized
INFO - 2025-05-05 07:05:22 --> Loader Class Initialized
INFO - 2025-05-05 07:05:22 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:22 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:22 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:22 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:22 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:22 --> Controller Class Initialized
INFO - 2025-05-05 15:05:22 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:05:24 --> Config Class Initialized
INFO - 2025-05-05 07:05:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:24 --> URI Class Initialized
INFO - 2025-05-05 07:05:24 --> Router Class Initialized
INFO - 2025-05-05 07:05:24 --> Output Class Initialized
INFO - 2025-05-05 07:05:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:24 --> Input Class Initialized
INFO - 2025-05-05 07:05:24 --> Language Class Initialized
INFO - 2025-05-05 07:05:24 --> Loader Class Initialized
INFO - 2025-05-05 07:05:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:25 --> Controller Class Initialized
INFO - 2025-05-05 07:05:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:05:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:05:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:05:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:05:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:05:25 --> Final output sent to browser
DEBUG - 2025-05-05 07:05:25 --> Total execution time: 0.1037
INFO - 2025-05-05 07:05:25 --> Config Class Initialized
INFO - 2025-05-05 07:05:25 --> Config Class Initialized
INFO - 2025-05-05 07:05:25 --> Hooks Class Initialized
INFO - 2025-05-05 07:05:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2025-05-05 07:05:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:25 --> URI Class Initialized
INFO - 2025-05-05 07:05:25 --> URI Class Initialized
INFO - 2025-05-05 07:05:25 --> Router Class Initialized
INFO - 2025-05-05 07:05:25 --> Router Class Initialized
INFO - 2025-05-05 07:05:25 --> Output Class Initialized
INFO - 2025-05-05 07:05:25 --> Output Class Initialized
INFO - 2025-05-05 07:05:25 --> Security Class Initialized
INFO - 2025-05-05 07:05:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-05 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:25 --> Input Class Initialized
INFO - 2025-05-05 07:05:25 --> Input Class Initialized
INFO - 2025-05-05 07:05:25 --> Language Class Initialized
INFO - 2025-05-05 07:05:25 --> Language Class Initialized
INFO - 2025-05-05 07:05:25 --> Loader Class Initialized
INFO - 2025-05-05 07:05:25 --> Loader Class Initialized
INFO - 2025-05-05 07:05:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:25 --> Database Driver Class Initialized
INFO - 2025-05-05 07:05:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-05 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:25 --> Controller Class Initialized
INFO - 2025-05-05 15:05:25 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:05:25 --> Final output sent to browser
DEBUG - 2025-05-05 15:05:25 --> Total execution time: 0.1162
INFO - 2025-05-05 07:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:25 --> Controller Class Initialized
INFO - 2025-05-05 15:05:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:05:25 --> Config Class Initialized
INFO - 2025-05-05 07:05:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:25 --> URI Class Initialized
INFO - 2025-05-05 07:05:25 --> Router Class Initialized
INFO - 2025-05-05 07:05:25 --> Output Class Initialized
INFO - 2025-05-05 07:05:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:25 --> Input Class Initialized
INFO - 2025-05-05 07:05:25 --> Language Class Initialized
INFO - 2025-05-05 07:05:25 --> Loader Class Initialized
INFO - 2025-05-05 07:05:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:25 --> Controller Class Initialized
INFO - 2025-05-05 07:05:25 --> Model "UserModel" initialized
INFO - 2025-05-05 07:05:26 --> Config Class Initialized
INFO - 2025-05-05 07:05:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:26 --> URI Class Initialized
INFO - 2025-05-05 07:05:26 --> Router Class Initialized
INFO - 2025-05-05 07:05:26 --> Output Class Initialized
INFO - 2025-05-05 07:05:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:26 --> Input Class Initialized
INFO - 2025-05-05 07:05:27 --> Language Class Initialized
INFO - 2025-05-05 07:05:27 --> Loader Class Initialized
INFO - 2025-05-05 07:05:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:27 --> Controller Class Initialized
INFO - 2025-05-05 15:05:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:05:27 --> Config Class Initialized
INFO - 2025-05-05 07:05:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:27 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:27 --> URI Class Initialized
INFO - 2025-05-05 07:05:27 --> Router Class Initialized
INFO - 2025-05-05 07:05:27 --> Output Class Initialized
INFO - 2025-05-05 07:05:27 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:27 --> Input Class Initialized
INFO - 2025-05-05 07:05:27 --> Language Class Initialized
INFO - 2025-05-05 07:05:27 --> Loader Class Initialized
INFO - 2025-05-05 07:05:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:27 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:27 --> Controller Class Initialized
INFO - 2025-05-05 15:05:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:05:28 --> Config Class Initialized
INFO - 2025-05-05 07:05:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:28 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:28 --> URI Class Initialized
INFO - 2025-05-05 07:05:28 --> Router Class Initialized
INFO - 2025-05-05 07:05:28 --> Output Class Initialized
INFO - 2025-05-05 07:05:28 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:28 --> Input Class Initialized
INFO - 2025-05-05 07:05:28 --> Language Class Initialized
INFO - 2025-05-05 07:05:28 --> Loader Class Initialized
INFO - 2025-05-05 07:05:28 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:28 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:28 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:28 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:28 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:28 --> Controller Class Initialized
INFO - 2025-05-05 15:05:28 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:05:43 --> Config Class Initialized
INFO - 2025-05-05 07:05:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:43 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:43 --> URI Class Initialized
INFO - 2025-05-05 07:05:43 --> Router Class Initialized
INFO - 2025-05-05 07:05:43 --> Output Class Initialized
INFO - 2025-05-05 07:05:43 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:43 --> Input Class Initialized
INFO - 2025-05-05 07:05:43 --> Language Class Initialized
INFO - 2025-05-05 07:05:43 --> Loader Class Initialized
INFO - 2025-05-05 07:05:43 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:43 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:43 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:43 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:43 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:44 --> Controller Class Initialized
INFO - 2025-05-05 15:05:44 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:05:44 --> Config Class Initialized
INFO - 2025-05-05 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:44 --> URI Class Initialized
INFO - 2025-05-05 07:05:44 --> Router Class Initialized
INFO - 2025-05-05 07:05:44 --> Output Class Initialized
INFO - 2025-05-05 07:05:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:44 --> Input Class Initialized
INFO - 2025-05-05 07:05:44 --> Language Class Initialized
INFO - 2025-05-05 07:05:44 --> Loader Class Initialized
INFO - 2025-05-05 07:05:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:44 --> Controller Class Initialized
INFO - 2025-05-05 07:05:44 --> Config Class Initialized
INFO - 2025-05-05 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:44 --> URI Class Initialized
DEBUG - 2025-05-05 07:05:44 --> No URI present. Default controller set.
INFO - 2025-05-05 07:05:44 --> Router Class Initialized
INFO - 2025-05-05 07:05:44 --> Output Class Initialized
INFO - 2025-05-05 07:05:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:44 --> Input Class Initialized
INFO - 2025-05-05 07:05:44 --> Language Class Initialized
INFO - 2025-05-05 07:05:44 --> Loader Class Initialized
INFO - 2025-05-05 07:05:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:44 --> Controller Class Initialized
INFO - 2025-05-05 07:05:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:05:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:05:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:05:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:05:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:05:44 --> Final output sent to browser
DEBUG - 2025-05-05 07:05:44 --> Total execution time: 0.1245
INFO - 2025-05-05 07:05:45 --> Config Class Initialized
INFO - 2025-05-05 07:05:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:45 --> URI Class Initialized
INFO - 2025-05-05 07:05:45 --> Router Class Initialized
INFO - 2025-05-05 07:05:45 --> Output Class Initialized
INFO - 2025-05-05 07:05:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:45 --> Input Class Initialized
INFO - 2025-05-05 07:05:45 --> Language Class Initialized
INFO - 2025-05-05 07:05:45 --> Loader Class Initialized
INFO - 2025-05-05 07:05:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:45 --> Helper loaded: string_helper
INFO - 2025-05-05 07:05:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:45 --> Helper loaded: file_helper
INFO - 2025-05-05 07:05:45 --> Helper loaded: html_helper
INFO - 2025-05-05 07:05:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:45 --> Controller Class Initialized
INFO - 2025-05-05 15:05:45 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:06:23 --> Config Class Initialized
INFO - 2025-05-05 07:06:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:23 --> URI Class Initialized
INFO - 2025-05-05 07:06:23 --> Router Class Initialized
INFO - 2025-05-05 07:06:23 --> Output Class Initialized
INFO - 2025-05-05 07:06:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:23 --> Input Class Initialized
INFO - 2025-05-05 07:06:23 --> Language Class Initialized
INFO - 2025-05-05 07:06:23 --> Loader Class Initialized
INFO - 2025-05-05 07:06:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:06:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:06:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:06:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:23 --> Controller Class Initialized
INFO - 2025-05-05 07:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:06:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:06:23 --> Final output sent to browser
DEBUG - 2025-05-05 07:06:23 --> Total execution time: 0.1381
INFO - 2025-05-05 07:06:24 --> Config Class Initialized
INFO - 2025-05-05 07:06:24 --> Hooks Class Initialized
INFO - 2025-05-05 07:06:24 --> Config Class Initialized
INFO - 2025-05-05 07:06:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:24 --> URI Class Initialized
DEBUG - 2025-05-05 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:24 --> URI Class Initialized
INFO - 2025-05-05 07:06:24 --> Router Class Initialized
INFO - 2025-05-05 07:06:24 --> Router Class Initialized
INFO - 2025-05-05 07:06:24 --> Output Class Initialized
INFO - 2025-05-05 07:06:24 --> Output Class Initialized
INFO - 2025-05-05 07:06:24 --> Security Class Initialized
INFO - 2025-05-05 07:06:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:24 --> Input Class Initialized
INFO - 2025-05-05 07:06:24 --> Language Class Initialized
DEBUG - 2025-05-05 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:24 --> Input Class Initialized
INFO - 2025-05-05 07:06:24 --> Language Class Initialized
INFO - 2025-05-05 07:06:24 --> Loader Class Initialized
INFO - 2025-05-05 07:06:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:24 --> Loader Class Initialized
INFO - 2025-05-05 07:06:24 --> Helper loaded: string_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: string_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: file_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: html_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: file_helper
INFO - 2025-05-05 07:06:24 --> Helper loaded: html_helper
INFO - 2025-05-05 07:06:24 --> Database Driver Class Initialized
INFO - 2025-05-05 07:06:24 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:24 --> Controller Class Initialized
INFO - 2025-05-05 15:06:24 --> Model "AuctionModel" initialized
DEBUG - 2025-05-05 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 15:06:24 --> Final output sent to browser
DEBUG - 2025-05-05 15:06:24 --> Total execution time: 0.1156
INFO - 2025-05-05 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:24 --> Controller Class Initialized
INFO - 2025-05-05 15:06:24 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:06:25 --> Config Class Initialized
INFO - 2025-05-05 07:06:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:25 --> URI Class Initialized
INFO - 2025-05-05 07:06:25 --> Router Class Initialized
INFO - 2025-05-05 07:06:25 --> Output Class Initialized
INFO - 2025-05-05 07:06:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:25 --> Input Class Initialized
INFO - 2025-05-05 07:06:25 --> Language Class Initialized
INFO - 2025-05-05 07:06:25 --> Loader Class Initialized
INFO - 2025-05-05 07:06:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:06:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:06:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:06:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:25 --> Controller Class Initialized
INFO - 2025-05-05 07:06:25 --> Model "UserModel" initialized
INFO - 2025-05-05 07:17:21 --> Config Class Initialized
INFO - 2025-05-05 07:17:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:22 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:22 --> URI Class Initialized
INFO - 2025-05-05 07:17:22 --> Router Class Initialized
INFO - 2025-05-05 07:17:22 --> Output Class Initialized
INFO - 2025-05-05 07:17:22 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:22 --> Input Class Initialized
INFO - 2025-05-05 07:17:22 --> Language Class Initialized
INFO - 2025-05-05 07:17:22 --> Loader Class Initialized
INFO - 2025-05-05 07:17:22 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:22 --> Helper loaded: string_helper
INFO - 2025-05-05 07:17:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:17:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:17:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:24 --> Controller Class Initialized
INFO - 2025-05-05 15:17:24 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:17:24 --> Model "UserModel" initialized
INFO - 2025-05-05 07:17:29 --> Config Class Initialized
INFO - 2025-05-05 07:17:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:29 --> URI Class Initialized
INFO - 2025-05-05 07:17:29 --> Router Class Initialized
INFO - 2025-05-05 07:17:29 --> Output Class Initialized
INFO - 2025-05-05 07:17:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:29 --> Input Class Initialized
INFO - 2025-05-05 07:17:29 --> Language Class Initialized
INFO - 2025-05-05 07:17:29 --> Loader Class Initialized
INFO - 2025-05-05 07:17:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:17:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:17:29 --> Helper loaded: html_helper
INFO - 2025-05-05 07:17:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:29 --> Controller Class Initialized
INFO - 2025-05-05 15:17:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:17:29 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:17:46 --> Config Class Initialized
INFO - 2025-05-05 07:17:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:46 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:46 --> URI Class Initialized
INFO - 2025-05-05 07:17:46 --> Router Class Initialized
INFO - 2025-05-05 07:17:46 --> Output Class Initialized
INFO - 2025-05-05 07:17:46 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:46 --> Input Class Initialized
INFO - 2025-05-05 07:17:46 --> Language Class Initialized
INFO - 2025-05-05 07:17:46 --> Loader Class Initialized
INFO - 2025-05-05 07:17:46 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:46 --> Helper loaded: string_helper
INFO - 2025-05-05 07:17:46 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:46 --> Helper loaded: file_helper
INFO - 2025-05-05 07:17:46 --> Helper loaded: html_helper
INFO - 2025-05-05 07:17:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:46 --> Controller Class Initialized
INFO - 2025-05-05 15:17:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:17:46 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:17:51 --> Config Class Initialized
INFO - 2025-05-05 07:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:51 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:51 --> URI Class Initialized
INFO - 2025-05-05 07:17:51 --> Router Class Initialized
INFO - 2025-05-05 07:17:51 --> Output Class Initialized
INFO - 2025-05-05 07:17:51 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:51 --> Input Class Initialized
INFO - 2025-05-05 07:17:51 --> Language Class Initialized
INFO - 2025-05-05 07:17:51 --> Loader Class Initialized
INFO - 2025-05-05 07:17:51 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:51 --> Helper loaded: string_helper
INFO - 2025-05-05 07:17:51 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:51 --> Helper loaded: file_helper
INFO - 2025-05-05 07:17:51 --> Helper loaded: html_helper
INFO - 2025-05-05 07:17:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:52 --> Controller Class Initialized
INFO - 2025-05-05 07:17:52 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:17:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:17:52 --> Final output sent to browser
DEBUG - 2025-05-05 07:17:52 --> Total execution time: 0.6114
INFO - 2025-05-05 07:17:53 --> Config Class Initialized
INFO - 2025-05-05 07:17:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:53 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:53 --> URI Class Initialized
INFO - 2025-05-05 07:17:53 --> Router Class Initialized
INFO - 2025-05-05 07:17:53 --> Output Class Initialized
INFO - 2025-05-05 07:17:53 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:53 --> Input Class Initialized
INFO - 2025-05-05 07:17:53 --> Language Class Initialized
INFO - 2025-05-05 07:17:53 --> Loader Class Initialized
INFO - 2025-05-05 07:17:53 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:53 --> Helper loaded: string_helper
INFO - 2025-05-05 07:17:53 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:53 --> Helper loaded: file_helper
INFO - 2025-05-05 07:17:53 --> Helper loaded: html_helper
INFO - 2025-05-05 07:17:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:53 --> Controller Class Initialized
INFO - 2025-05-05 15:17:53 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:17:53 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:17:53 --> Final output sent to browser
DEBUG - 2025-05-05 15:17:53 --> Total execution time: 0.2193
INFO - 2025-05-05 07:18:01 --> Config Class Initialized
INFO - 2025-05-05 07:18:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:01 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:01 --> URI Class Initialized
INFO - 2025-05-05 07:18:01 --> Router Class Initialized
INFO - 2025-05-05 07:18:01 --> Output Class Initialized
INFO - 2025-05-05 07:18:01 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:01 --> Input Class Initialized
INFO - 2025-05-05 07:18:01 --> Language Class Initialized
INFO - 2025-05-05 07:18:01 --> Loader Class Initialized
INFO - 2025-05-05 07:18:01 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:01 --> Helper loaded: string_helper
INFO - 2025-05-05 07:18:01 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:01 --> Helper loaded: file_helper
INFO - 2025-05-05 07:18:01 --> Helper loaded: html_helper
INFO - 2025-05-05 07:18:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:01 --> Controller Class Initialized
INFO - 2025-05-05 15:18:01 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:18:01 --> Model "UserModel" initialized
INFO - 2025-05-05 07:18:04 --> Config Class Initialized
INFO - 2025-05-05 07:18:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:04 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:04 --> URI Class Initialized
INFO - 2025-05-05 07:18:04 --> Router Class Initialized
INFO - 2025-05-05 07:18:04 --> Output Class Initialized
INFO - 2025-05-05 07:18:04 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:04 --> Input Class Initialized
INFO - 2025-05-05 07:18:04 --> Language Class Initialized
INFO - 2025-05-05 07:18:04 --> Loader Class Initialized
INFO - 2025-05-05 07:18:04 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:04 --> Helper loaded: string_helper
INFO - 2025-05-05 07:18:04 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:04 --> Helper loaded: file_helper
INFO - 2025-05-05 07:18:04 --> Helper loaded: html_helper
INFO - 2025-05-05 07:18:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:05 --> Controller Class Initialized
INFO - 2025-05-05 15:18:05 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:18:05 --> Model "UserModel" initialized
INFO - 2025-05-05 07:18:36 --> Config Class Initialized
INFO - 2025-05-05 07:18:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:36 --> URI Class Initialized
INFO - 2025-05-05 07:18:36 --> Router Class Initialized
INFO - 2025-05-05 07:18:36 --> Output Class Initialized
INFO - 2025-05-05 07:18:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:36 --> Input Class Initialized
INFO - 2025-05-05 07:18:36 --> Language Class Initialized
INFO - 2025-05-05 07:18:36 --> Loader Class Initialized
INFO - 2025-05-05 07:18:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:36 --> Helper loaded: string_helper
INFO - 2025-05-05 07:18:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:36 --> Helper loaded: file_helper
INFO - 2025-05-05 07:18:36 --> Helper loaded: html_helper
INFO - 2025-05-05 07:18:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:36 --> Controller Class Initialized
INFO - 2025-05-05 15:18:36 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:18:36 --> Model "UserModel" initialized
INFO - 2025-05-05 07:19:25 --> Config Class Initialized
INFO - 2025-05-05 07:19:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:25 --> URI Class Initialized
INFO - 2025-05-05 07:19:25 --> Router Class Initialized
INFO - 2025-05-05 07:19:25 --> Output Class Initialized
INFO - 2025-05-05 07:19:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:25 --> Input Class Initialized
INFO - 2025-05-05 07:19:25 --> Language Class Initialized
INFO - 2025-05-05 07:19:25 --> Loader Class Initialized
INFO - 2025-05-05 07:19:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:25 --> Controller Class Initialized
INFO - 2025-05-05 15:19:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:25 --> Model "UserModel" initialized
INFO - 2025-05-05 15:19:25 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:19:27 --> Config Class Initialized
INFO - 2025-05-05 07:19:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:27 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:27 --> URI Class Initialized
INFO - 2025-05-05 07:19:27 --> Router Class Initialized
INFO - 2025-05-05 07:19:27 --> Output Class Initialized
INFO - 2025-05-05 07:19:27 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:27 --> Input Class Initialized
INFO - 2025-05-05 07:19:27 --> Language Class Initialized
INFO - 2025-05-05 07:19:27 --> Loader Class Initialized
INFO - 2025-05-05 07:19:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:27 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:28 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:28 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:29 --> Config Class Initialized
INFO - 2025-05-05 07:19:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:29 --> URI Class Initialized
INFO - 2025-05-05 07:19:29 --> Router Class Initialized
INFO - 2025-05-05 07:19:29 --> Output Class Initialized
INFO - 2025-05-05 07:19:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:29 --> Input Class Initialized
INFO - 2025-05-05 07:19:29 --> Language Class Initialized
INFO - 2025-05-05 07:19:29 --> Loader Class Initialized
INFO - 2025-05-05 07:19:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:29 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:29 --> Controller Class Initialized
INFO - 2025-05-05 15:19:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:29 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:19:29 --> Final output sent to browser
DEBUG - 2025-05-05 15:19:29 --> Total execution time: 0.3185
INFO - 2025-05-05 07:19:36 --> Config Class Initialized
INFO - 2025-05-05 07:19:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:36 --> URI Class Initialized
INFO - 2025-05-05 07:19:36 --> Router Class Initialized
INFO - 2025-05-05 07:19:36 --> Output Class Initialized
INFO - 2025-05-05 07:19:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:36 --> Input Class Initialized
INFO - 2025-05-05 07:19:36 --> Language Class Initialized
INFO - 2025-05-05 07:19:36 --> Loader Class Initialized
INFO - 2025-05-05 07:19:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:36 --> Controller Class Initialized
INFO - 2025-05-05 15:19:36 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:36 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:19:36 --> Config Class Initialized
INFO - 2025-05-05 07:19:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:36 --> URI Class Initialized
INFO - 2025-05-05 07:19:36 --> Router Class Initialized
INFO - 2025-05-05 07:19:36 --> Output Class Initialized
INFO - 2025-05-05 07:19:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:36 --> Input Class Initialized
INFO - 2025-05-05 07:19:36 --> Language Class Initialized
INFO - 2025-05-05 07:19:36 --> Loader Class Initialized
INFO - 2025-05-05 07:19:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:36 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:36 --> Controller Class Initialized
INFO - 2025-05-05 15:19:36 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:36 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:19:36 --> Final output sent to browser
DEBUG - 2025-05-05 15:19:36 --> Total execution time: 0.2326
INFO - 2025-05-05 07:19:42 --> Config Class Initialized
INFO - 2025-05-05 07:19:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:42 --> URI Class Initialized
INFO - 2025-05-05 07:19:42 --> Router Class Initialized
INFO - 2025-05-05 07:19:42 --> Output Class Initialized
INFO - 2025-05-05 07:19:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:42 --> Input Class Initialized
INFO - 2025-05-05 07:19:42 --> Language Class Initialized
INFO - 2025-05-05 07:19:42 --> Loader Class Initialized
INFO - 2025-05-05 07:19:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:42 --> Controller Class Initialized
INFO - 2025-05-05 15:19:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:42 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:19:42 --> Model "UserModel" initialized
INFO - 2025-05-05 07:19:42 --> Config Class Initialized
INFO - 2025-05-05 07:19:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:19:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:19:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:19:42 --> URI Class Initialized
INFO - 2025-05-05 07:19:42 --> Router Class Initialized
INFO - 2025-05-05 07:19:42 --> Output Class Initialized
INFO - 2025-05-05 07:19:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:19:42 --> Input Class Initialized
INFO - 2025-05-05 07:19:42 --> Language Class Initialized
INFO - 2025-05-05 07:19:42 --> Loader Class Initialized
INFO - 2025-05-05 07:19:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: string_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: file_helper
INFO - 2025-05-05 07:19:42 --> Helper loaded: html_helper
INFO - 2025-05-05 07:19:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:19:42 --> Controller Class Initialized
INFO - 2025-05-05 15:19:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:19:42 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:19:42 --> Final output sent to browser
DEBUG - 2025-05-05 15:19:42 --> Total execution time: 0.1389
INFO - 2025-05-05 07:20:06 --> Config Class Initialized
INFO - 2025-05-05 07:20:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:06 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:06 --> URI Class Initialized
INFO - 2025-05-05 07:20:06 --> Router Class Initialized
INFO - 2025-05-05 07:20:06 --> Output Class Initialized
INFO - 2025-05-05 07:20:06 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:06 --> Input Class Initialized
INFO - 2025-05-05 07:20:06 --> Language Class Initialized
INFO - 2025-05-05 07:20:06 --> Loader Class Initialized
INFO - 2025-05-05 07:20:06 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:06 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:06 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:06 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:06 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:06 --> Controller Class Initialized
INFO - 2025-05-05 15:20:06 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:20:06 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:20:06 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:20:07 --> Final output sent to browser
DEBUG - 2025-05-05 15:20:07 --> Total execution time: 0.4877
INFO - 2025-05-05 07:20:14 --> Config Class Initialized
INFO - 2025-05-05 07:20:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:14 --> URI Class Initialized
INFO - 2025-05-05 07:20:14 --> Router Class Initialized
INFO - 2025-05-05 07:20:14 --> Output Class Initialized
INFO - 2025-05-05 07:20:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:14 --> Input Class Initialized
INFO - 2025-05-05 07:20:14 --> Language Class Initialized
INFO - 2025-05-05 07:20:14 --> Loader Class Initialized
INFO - 2025-05-05 07:20:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:14 --> Controller Class Initialized
INFO - 2025-05-05 15:20:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:20:14 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:20:14 --> Config Class Initialized
INFO - 2025-05-05 07:20:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:14 --> URI Class Initialized
INFO - 2025-05-05 07:20:14 --> Router Class Initialized
INFO - 2025-05-05 07:20:14 --> Output Class Initialized
INFO - 2025-05-05 07:20:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:14 --> Input Class Initialized
INFO - 2025-05-05 07:20:14 --> Language Class Initialized
INFO - 2025-05-05 07:20:14 --> Loader Class Initialized
INFO - 2025-05-05 07:20:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:14 --> Controller Class Initialized
INFO - 2025-05-05 15:20:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:20:14 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:20:14 --> Final output sent to browser
DEBUG - 2025-05-05 15:20:14 --> Total execution time: 0.1543
INFO - 2025-05-05 07:20:17 --> Config Class Initialized
INFO - 2025-05-05 07:20:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:17 --> URI Class Initialized
INFO - 2025-05-05 07:20:17 --> Router Class Initialized
INFO - 2025-05-05 07:20:17 --> Output Class Initialized
INFO - 2025-05-05 07:20:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:17 --> Input Class Initialized
INFO - 2025-05-05 07:20:17 --> Language Class Initialized
INFO - 2025-05-05 07:20:17 --> Loader Class Initialized
INFO - 2025-05-05 07:20:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:17 --> Controller Class Initialized
INFO - 2025-05-05 15:20:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:20:17 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:20:17 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:20:17 --> Final output sent to browser
DEBUG - 2025-05-05 15:20:17 --> Total execution time: 0.2441
INFO - 2025-05-05 07:20:20 --> Config Class Initialized
INFO - 2025-05-05 07:20:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:20 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:20 --> URI Class Initialized
INFO - 2025-05-05 07:20:20 --> Router Class Initialized
INFO - 2025-05-05 07:20:20 --> Output Class Initialized
INFO - 2025-05-05 07:20:20 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:20 --> Input Class Initialized
INFO - 2025-05-05 07:20:20 --> Language Class Initialized
INFO - 2025-05-05 07:20:20 --> Loader Class Initialized
INFO - 2025-05-05 07:20:20 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:20 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:20 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:20 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:20 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:20 --> Controller Class Initialized
INFO - 2025-05-05 07:20:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:20:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:20:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:20:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:20:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:20:20 --> Final output sent to browser
DEBUG - 2025-05-05 07:20:20 --> Total execution time: 0.1678
INFO - 2025-05-05 07:20:23 --> Config Class Initialized
INFO - 2025-05-05 07:20:23 --> Config Class Initialized
INFO - 2025-05-05 07:20:23 --> Hooks Class Initialized
INFO - 2025-05-05 07:20:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:23 --> Utf8 Class Initialized
DEBUG - 2025-05-05 07:20:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:23 --> URI Class Initialized
INFO - 2025-05-05 07:20:23 --> URI Class Initialized
INFO - 2025-05-05 07:20:23 --> Router Class Initialized
INFO - 2025-05-05 07:20:23 --> Router Class Initialized
INFO - 2025-05-05 07:20:23 --> Output Class Initialized
INFO - 2025-05-05 07:20:23 --> Security Class Initialized
INFO - 2025-05-05 07:20:23 --> Output Class Initialized
DEBUG - 2025-05-05 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:23 --> Input Class Initialized
INFO - 2025-05-05 07:20:23 --> Security Class Initialized
INFO - 2025-05-05 07:20:23 --> Language Class Initialized
DEBUG - 2025-05-05 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:23 --> Input Class Initialized
INFO - 2025-05-05 07:20:23 --> Language Class Initialized
INFO - 2025-05-05 07:20:23 --> Loader Class Initialized
INFO - 2025-05-05 07:20:23 --> Loader Class Initialized
INFO - 2025-05-05 07:20:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:23 --> Database Driver Class Initialized
INFO - 2025-05-05 07:20:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-05 07:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:23 --> Controller Class Initialized
INFO - 2025-05-05 15:20:23 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:20:23 --> Final output sent to browser
DEBUG - 2025-05-05 15:20:23 --> Total execution time: 0.1074
INFO - 2025-05-05 07:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:23 --> Controller Class Initialized
INFO - 2025-05-05 15:20:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:20:23 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:20:23 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:20:23 --> Final output sent to browser
DEBUG - 2025-05-05 15:20:23 --> Total execution time: 0.1674
INFO - 2025-05-05 07:20:26 --> Config Class Initialized
INFO - 2025-05-05 07:20:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:26 --> URI Class Initialized
INFO - 2025-05-05 07:20:26 --> Router Class Initialized
INFO - 2025-05-05 07:20:26 --> Output Class Initialized
INFO - 2025-05-05 07:20:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:26 --> Input Class Initialized
INFO - 2025-05-05 07:20:26 --> Language Class Initialized
INFO - 2025-05-05 07:20:26 --> Loader Class Initialized
INFO - 2025-05-05 07:20:26 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:26 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:26 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:26 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:26 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:26 --> Controller Class Initialized
INFO - 2025-05-05 07:20:26 --> Model "UserModel" initialized
INFO - 2025-05-05 07:20:26 --> Final output sent to browser
DEBUG - 2025-05-05 07:20:26 --> Total execution time: 0.1967
INFO - 2025-05-05 07:20:49 --> Config Class Initialized
INFO - 2025-05-05 07:20:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:49 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:49 --> URI Class Initialized
INFO - 2025-05-05 07:20:49 --> Router Class Initialized
INFO - 2025-05-05 07:20:49 --> Output Class Initialized
INFO - 2025-05-05 07:20:49 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:49 --> Input Class Initialized
INFO - 2025-05-05 07:20:49 --> Language Class Initialized
INFO - 2025-05-05 07:20:49 --> Loader Class Initialized
INFO - 2025-05-05 07:20:49 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:49 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:49 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:49 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:49 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:49 --> Controller Class Initialized
INFO - 2025-05-05 15:20:49 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:20:51 --> Config Class Initialized
INFO - 2025-05-05 07:20:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:51 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:51 --> URI Class Initialized
INFO - 2025-05-05 07:20:51 --> Router Class Initialized
INFO - 2025-05-05 07:20:51 --> Output Class Initialized
INFO - 2025-05-05 07:20:51 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:51 --> Config Class Initialized
INFO - 2025-05-05 07:20:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:51 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:51 --> URI Class Initialized
INFO - 2025-05-05 07:20:51 --> Router Class Initialized
INFO - 2025-05-05 07:20:51 --> Output Class Initialized
INFO - 2025-05-05 07:20:51 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:51 --> Input Class Initialized
INFO - 2025-05-05 07:20:51 --> Language Class Initialized
INFO - 2025-05-05 07:20:52 --> Loader Class Initialized
INFO - 2025-05-05 07:20:52 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:52 --> Helper loaded: string_helper
INFO - 2025-05-05 07:20:52 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:52 --> Helper loaded: file_helper
INFO - 2025-05-05 07:20:52 --> Helper loaded: html_helper
INFO - 2025-05-05 07:20:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:52 --> Controller Class Initialized
INFO - 2025-05-05 15:20:52 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:21:14 --> Config Class Initialized
INFO - 2025-05-05 07:21:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:14 --> URI Class Initialized
INFO - 2025-05-05 07:21:14 --> Router Class Initialized
INFO - 2025-05-05 07:21:14 --> Output Class Initialized
INFO - 2025-05-05 07:21:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:14 --> Input Class Initialized
INFO - 2025-05-05 07:21:14 --> Language Class Initialized
INFO - 2025-05-05 07:21:14 --> Loader Class Initialized
INFO - 2025-05-05 07:21:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:14 --> Controller Class Initialized
INFO - 2025-05-05 07:21:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:21:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:21:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:21:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:21:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:21:14 --> Final output sent to browser
DEBUG - 2025-05-05 07:21:14 --> Total execution time: 0.1624
INFO - 2025-05-05 07:21:16 --> Config Class Initialized
INFO - 2025-05-05 07:21:16 --> Hooks Class Initialized
INFO - 2025-05-05 07:21:16 --> Config Class Initialized
DEBUG - 2025-05-05 07:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:16 --> Hooks Class Initialized
INFO - 2025-05-05 07:21:16 --> URI Class Initialized
DEBUG - 2025-05-05 07:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:16 --> Router Class Initialized
INFO - 2025-05-05 07:21:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:16 --> URI Class Initialized
INFO - 2025-05-05 07:21:16 --> Output Class Initialized
INFO - 2025-05-05 07:21:16 --> Security Class Initialized
INFO - 2025-05-05 07:21:16 --> Router Class Initialized
DEBUG - 2025-05-05 07:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:16 --> Input Class Initialized
INFO - 2025-05-05 07:21:16 --> Language Class Initialized
INFO - 2025-05-05 07:21:16 --> Output Class Initialized
INFO - 2025-05-05 07:21:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:16 --> Input Class Initialized
INFO - 2025-05-05 07:21:16 --> Loader Class Initialized
INFO - 2025-05-05 07:21:16 --> Language Class Initialized
INFO - 2025-05-05 07:21:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:16 --> Loader Class Initialized
INFO - 2025-05-05 07:21:16 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:16 --> Database Driver Class Initialized
INFO - 2025-05-05 07:21:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-05 07:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:16 --> Controller Class Initialized
INFO - 2025-05-05 15:21:16 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:16 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:16 --> Total execution time: 0.1488
INFO - 2025-05-05 07:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:16 --> Controller Class Initialized
INFO - 2025-05-05 15:21:16 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:16 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:21:16 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:16 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:16 --> Total execution time: 0.2292
INFO - 2025-05-05 07:21:16 --> Config Class Initialized
INFO - 2025-05-05 07:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:16 --> URI Class Initialized
INFO - 2025-05-05 07:21:16 --> Router Class Initialized
INFO - 2025-05-05 07:21:16 --> Output Class Initialized
INFO - 2025-05-05 07:21:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:16 --> Input Class Initialized
INFO - 2025-05-05 07:21:16 --> Language Class Initialized
INFO - 2025-05-05 07:21:16 --> Loader Class Initialized
INFO - 2025-05-05 07:21:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:16 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:16 --> Controller Class Initialized
INFO - 2025-05-05 07:21:16 --> Model "UserModel" initialized
INFO - 2025-05-05 07:21:16 --> Final output sent to browser
DEBUG - 2025-05-05 07:21:16 --> Total execution time: 0.1014
INFO - 2025-05-05 07:21:20 --> Config Class Initialized
INFO - 2025-05-05 07:21:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:20 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:20 --> URI Class Initialized
INFO - 2025-05-05 07:21:20 --> Router Class Initialized
INFO - 2025-05-05 07:21:20 --> Output Class Initialized
INFO - 2025-05-05 07:21:20 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:20 --> Input Class Initialized
INFO - 2025-05-05 07:21:20 --> Language Class Initialized
INFO - 2025-05-05 07:21:20 --> Loader Class Initialized
INFO - 2025-05-05 07:21:20 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:20 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:20 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:20 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:20 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:20 --> Controller Class Initialized
INFO - 2025-05-05 07:21:20 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:21:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:21:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:21:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:21:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:21:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:21:20 --> Final output sent to browser
DEBUG - 2025-05-05 07:21:20 --> Total execution time: 0.1081
INFO - 2025-05-05 07:21:21 --> Config Class Initialized
INFO - 2025-05-05 07:21:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:21 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:21 --> URI Class Initialized
INFO - 2025-05-05 07:21:21 --> Router Class Initialized
INFO - 2025-05-05 07:21:21 --> Output Class Initialized
INFO - 2025-05-05 07:21:21 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:21 --> Input Class Initialized
INFO - 2025-05-05 07:21:21 --> Language Class Initialized
INFO - 2025-05-05 07:21:21 --> Loader Class Initialized
INFO - 2025-05-05 07:21:21 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:21 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:21 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:21 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:21 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:21 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:21 --> Controller Class Initialized
INFO - 2025-05-05 15:21:21 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:21 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:21:21 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:21 --> Total execution time: 0.2344
INFO - 2025-05-05 07:21:23 --> Config Class Initialized
INFO - 2025-05-05 07:21:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:23 --> URI Class Initialized
INFO - 2025-05-05 07:21:23 --> Router Class Initialized
INFO - 2025-05-05 07:21:23 --> Output Class Initialized
INFO - 2025-05-05 07:21:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:23 --> Input Class Initialized
INFO - 2025-05-05 07:21:23 --> Language Class Initialized
INFO - 2025-05-05 07:21:23 --> Loader Class Initialized
INFO - 2025-05-05 07:21:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:23 --> Controller Class Initialized
INFO - 2025-05-05 15:21:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:23 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:21:23 --> Model "UserModel" initialized
INFO - 2025-05-05 07:21:23 --> Config Class Initialized
INFO - 2025-05-05 07:21:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:23 --> URI Class Initialized
INFO - 2025-05-05 07:21:23 --> Router Class Initialized
INFO - 2025-05-05 07:21:23 --> Output Class Initialized
INFO - 2025-05-05 07:21:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:23 --> Input Class Initialized
INFO - 2025-05-05 07:21:23 --> Language Class Initialized
INFO - 2025-05-05 07:21:23 --> Loader Class Initialized
INFO - 2025-05-05 07:21:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:23 --> Controller Class Initialized
INFO - 2025-05-05 15:21:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:23 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:21:24 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:24 --> Total execution time: 0.1378
INFO - 2025-05-05 07:21:25 --> Config Class Initialized
INFO - 2025-05-05 07:21:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:25 --> URI Class Initialized
INFO - 2025-05-05 07:21:25 --> Router Class Initialized
INFO - 2025-05-05 07:21:25 --> Output Class Initialized
INFO - 2025-05-05 07:21:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:25 --> Input Class Initialized
INFO - 2025-05-05 07:21:25 --> Language Class Initialized
INFO - 2025-05-05 07:21:25 --> Loader Class Initialized
INFO - 2025-05-05 07:21:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:25 --> Controller Class Initialized
INFO - 2025-05-05 15:21:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:25 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:21:25 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:25 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:25 --> Total execution time: 0.1856
INFO - 2025-05-05 07:21:25 --> Config Class Initialized
INFO - 2025-05-05 07:21:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:25 --> URI Class Initialized
INFO - 2025-05-05 07:21:25 --> Router Class Initialized
INFO - 2025-05-05 07:21:25 --> Output Class Initialized
INFO - 2025-05-05 07:21:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:25 --> Input Class Initialized
INFO - 2025-05-05 07:21:25 --> Language Class Initialized
INFO - 2025-05-05 07:21:25 --> Loader Class Initialized
INFO - 2025-05-05 07:21:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:25 --> Controller Class Initialized
INFO - 2025-05-05 15:21:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:25 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:21:25 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:26 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:26 --> Total execution time: 0.1917
INFO - 2025-05-05 07:21:26 --> Config Class Initialized
INFO - 2025-05-05 07:21:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:26 --> URI Class Initialized
INFO - 2025-05-05 07:21:26 --> Router Class Initialized
INFO - 2025-05-05 07:21:26 --> Output Class Initialized
INFO - 2025-05-05 07:21:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:26 --> Input Class Initialized
INFO - 2025-05-05 07:21:26 --> Language Class Initialized
INFO - 2025-05-05 07:21:26 --> Loader Class Initialized
INFO - 2025-05-05 07:21:26 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:26 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:26 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:26 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:26 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:26 --> Controller Class Initialized
INFO - 2025-05-05 15:21:26 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:26 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:21:26 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:26 --> Model "InvoiceModel" initialized
INFO - 2025-05-05 15:21:26 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:26 --> Total execution time: 0.2463
INFO - 2025-05-05 07:21:34 --> Config Class Initialized
INFO - 2025-05-05 07:21:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:34 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:34 --> URI Class Initialized
INFO - 2025-05-05 07:21:34 --> Router Class Initialized
INFO - 2025-05-05 07:21:34 --> Output Class Initialized
INFO - 2025-05-05 07:21:34 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:34 --> Input Class Initialized
INFO - 2025-05-05 07:21:34 --> Language Class Initialized
INFO - 2025-05-05 07:21:34 --> Loader Class Initialized
INFO - 2025-05-05 07:21:34 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:34 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:34 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:34 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:34 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:34 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:34 --> Controller Class Initialized
INFO - 2025-05-05 15:21:34 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:21:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:21:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-05 15:21:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:21:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:21:34 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:34 --> Total execution time: 0.2323
INFO - 2025-05-05 07:21:35 --> Config Class Initialized
INFO - 2025-05-05 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:35 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:35 --> URI Class Initialized
INFO - 2025-05-05 07:21:35 --> Router Class Initialized
INFO - 2025-05-05 07:21:35 --> Output Class Initialized
INFO - 2025-05-05 07:21:35 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:35 --> Input Class Initialized
INFO - 2025-05-05 07:21:35 --> Language Class Initialized
INFO - 2025-05-05 07:21:35 --> Loader Class Initialized
INFO - 2025-05-05 07:21:35 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:35 --> Controller Class Initialized
INFO - 2025-05-05 15:21:35 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:35 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:35 --> Total execution time: 0.1902
INFO - 2025-05-05 07:21:35 --> Config Class Initialized
INFO - 2025-05-05 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:35 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:35 --> URI Class Initialized
INFO - 2025-05-05 07:21:35 --> Router Class Initialized
INFO - 2025-05-05 07:21:35 --> Output Class Initialized
INFO - 2025-05-05 07:21:35 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:35 --> Input Class Initialized
INFO - 2025-05-05 07:21:35 --> Language Class Initialized
INFO - 2025-05-05 07:21:35 --> Loader Class Initialized
INFO - 2025-05-05 07:21:35 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:35 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:35 --> Controller Class Initialized
INFO - 2025-05-05 07:21:35 --> Model "UserModel" initialized
INFO - 2025-05-05 07:21:35 --> Final output sent to browser
DEBUG - 2025-05-05 07:21:35 --> Total execution time: 0.1136
INFO - 2025-05-05 07:21:36 --> Config Class Initialized
INFO - 2025-05-05 07:21:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:36 --> URI Class Initialized
INFO - 2025-05-05 07:21:36 --> Router Class Initialized
INFO - 2025-05-05 07:21:36 --> Output Class Initialized
INFO - 2025-05-05 07:21:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:36 --> Input Class Initialized
INFO - 2025-05-05 07:21:36 --> Language Class Initialized
INFO - 2025-05-05 07:21:36 --> Loader Class Initialized
INFO - 2025-05-05 07:21:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:36 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:36 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:36 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:36 --> Controller Class Initialized
INFO - 2025-05-05 15:21:36 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:36 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:36 --> Total execution time: 0.1199
INFO - 2025-05-05 07:21:44 --> Config Class Initialized
INFO - 2025-05-05 07:21:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:44 --> URI Class Initialized
INFO - 2025-05-05 07:21:44 --> Router Class Initialized
INFO - 2025-05-05 07:21:44 --> Output Class Initialized
INFO - 2025-05-05 07:21:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:44 --> Input Class Initialized
INFO - 2025-05-05 07:21:44 --> Language Class Initialized
INFO - 2025-05-05 07:21:44 --> Loader Class Initialized
INFO - 2025-05-05 07:21:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:44 --> Controller Class Initialized
INFO - 2025-05-05 15:21:44 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:44 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:21:44 --> Config Class Initialized
INFO - 2025-05-05 07:21:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:44 --> URI Class Initialized
INFO - 2025-05-05 07:21:45 --> Router Class Initialized
INFO - 2025-05-05 07:21:45 --> Output Class Initialized
INFO - 2025-05-05 07:21:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:45 --> Input Class Initialized
INFO - 2025-05-05 07:21:45 --> Language Class Initialized
INFO - 2025-05-05 07:21:45 --> Loader Class Initialized
INFO - 2025-05-05 07:21:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:45 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:45 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:45 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:45 --> Controller Class Initialized
INFO - 2025-05-05 15:21:45 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:45 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:21:45 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:45 --> Total execution time: 0.3069
INFO - 2025-05-05 07:21:46 --> Config Class Initialized
INFO - 2025-05-05 07:21:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:46 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:46 --> URI Class Initialized
INFO - 2025-05-05 07:21:46 --> Router Class Initialized
INFO - 2025-05-05 07:21:46 --> Output Class Initialized
INFO - 2025-05-05 07:21:46 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:46 --> Input Class Initialized
INFO - 2025-05-05 07:21:46 --> Language Class Initialized
INFO - 2025-05-05 07:21:46 --> Loader Class Initialized
INFO - 2025-05-05 07:21:46 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:46 --> Controller Class Initialized
INFO - 2025-05-05 15:21:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/add_auction.php
INFO - 2025-05-05 15:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:21:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:21:46 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:46 --> Total execution time: 0.1770
INFO - 2025-05-05 07:21:46 --> Config Class Initialized
INFO - 2025-05-05 07:21:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:46 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:46 --> URI Class Initialized
INFO - 2025-05-05 07:21:46 --> Router Class Initialized
INFO - 2025-05-05 07:21:46 --> Output Class Initialized
INFO - 2025-05-05 07:21:46 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:46 --> Input Class Initialized
INFO - 2025-05-05 07:21:46 --> Language Class Initialized
INFO - 2025-05-05 07:21:46 --> Loader Class Initialized
INFO - 2025-05-05 07:21:46 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:46 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:46 --> Controller Class Initialized
INFO - 2025-05-05 15:21:46 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:46 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:46 --> Total execution time: 0.1596
INFO - 2025-05-05 07:21:47 --> Config Class Initialized
INFO - 2025-05-05 07:21:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:47 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:47 --> URI Class Initialized
INFO - 2025-05-05 07:21:47 --> Router Class Initialized
INFO - 2025-05-05 07:21:47 --> Output Class Initialized
INFO - 2025-05-05 07:21:47 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:47 --> Input Class Initialized
INFO - 2025-05-05 07:21:47 --> Language Class Initialized
INFO - 2025-05-05 07:21:47 --> Loader Class Initialized
INFO - 2025-05-05 07:21:47 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:47 --> Controller Class Initialized
INFO - 2025-05-05 07:21:47 --> Model "UserModel" initialized
INFO - 2025-05-05 07:21:47 --> Final output sent to browser
DEBUG - 2025-05-05 07:21:47 --> Total execution time: 0.1384
INFO - 2025-05-05 07:21:47 --> Config Class Initialized
INFO - 2025-05-05 07:21:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:21:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:21:47 --> Utf8 Class Initialized
INFO - 2025-05-05 07:21:47 --> URI Class Initialized
INFO - 2025-05-05 07:21:47 --> Router Class Initialized
INFO - 2025-05-05 07:21:47 --> Output Class Initialized
INFO - 2025-05-05 07:21:47 --> Security Class Initialized
DEBUG - 2025-05-05 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:21:47 --> Input Class Initialized
INFO - 2025-05-05 07:21:47 --> Language Class Initialized
INFO - 2025-05-05 07:21:47 --> Loader Class Initialized
INFO - 2025-05-05 07:21:47 --> Helper loaded: url_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: string_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: form_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: file_helper
INFO - 2025-05-05 07:21:47 --> Helper loaded: html_helper
INFO - 2025-05-05 07:21:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:21:47 --> Controller Class Initialized
INFO - 2025-05-05 15:21:47 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:21:47 --> Final output sent to browser
DEBUG - 2025-05-05 15:21:47 --> Total execution time: 0.1106
INFO - 2025-05-05 07:23:28 --> Config Class Initialized
INFO - 2025-05-05 07:23:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:28 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:28 --> URI Class Initialized
INFO - 2025-05-05 07:23:28 --> Router Class Initialized
INFO - 2025-05-05 07:23:28 --> Output Class Initialized
INFO - 2025-05-05 07:23:28 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:28 --> Input Class Initialized
INFO - 2025-05-05 07:23:28 --> Language Class Initialized
INFO - 2025-05-05 07:23:28 --> Loader Class Initialized
INFO - 2025-05-05 07:23:28 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:28 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:28 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:28 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:28 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:28 --> Controller Class Initialized
INFO - 2025-05-05 15:23:28 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:23:29 --> Config Class Initialized
INFO - 2025-05-05 07:23:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:29 --> URI Class Initialized
INFO - 2025-05-05 07:23:29 --> Router Class Initialized
INFO - 2025-05-05 07:23:29 --> Output Class Initialized
INFO - 2025-05-05 07:23:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:29 --> Input Class Initialized
INFO - 2025-05-05 07:23:29 --> Language Class Initialized
INFO - 2025-05-05 07:23:29 --> Loader Class Initialized
INFO - 2025-05-05 07:23:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:29 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:29 --> Controller Class Initialized
INFO - 2025-05-05 15:23:29 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:23:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:23:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:23:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-05 15:23:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:23:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:23:29 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:29 --> Total execution time: 0.1781
INFO - 2025-05-05 07:23:30 --> Config Class Initialized
INFO - 2025-05-05 07:23:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:30 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:30 --> URI Class Initialized
INFO - 2025-05-05 07:23:30 --> Router Class Initialized
INFO - 2025-05-05 07:23:30 --> Output Class Initialized
INFO - 2025-05-05 07:23:30 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:30 --> Input Class Initialized
INFO - 2025-05-05 07:23:30 --> Language Class Initialized
INFO - 2025-05-05 07:23:30 --> Loader Class Initialized
INFO - 2025-05-05 07:23:30 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:30 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:30 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:30 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:30 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:30 --> Controller Class Initialized
INFO - 2025-05-05 07:23:31 --> Config Class Initialized
INFO - 2025-05-05 07:23:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:31 --> URI Class Initialized
INFO - 2025-05-05 07:23:31 --> Router Class Initialized
INFO - 2025-05-05 07:23:31 --> Output Class Initialized
INFO - 2025-05-05 07:23:31 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:31 --> Input Class Initialized
INFO - 2025-05-05 07:23:31 --> Language Class Initialized
INFO - 2025-05-05 07:23:31 --> Loader Class Initialized
INFO - 2025-05-05 07:23:31 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:31 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:31 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:31 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:31 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:31 --> Controller Class Initialized
INFO - 2025-05-05 15:23:31 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:23:31 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:31 --> Total execution time: 0.1757
INFO - 2025-05-05 07:23:32 --> Config Class Initialized
INFO - 2025-05-05 07:23:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:32 --> URI Class Initialized
INFO - 2025-05-05 07:23:32 --> Router Class Initialized
INFO - 2025-05-05 07:23:32 --> Output Class Initialized
INFO - 2025-05-05 07:23:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:32 --> Input Class Initialized
INFO - 2025-05-05 07:23:32 --> Language Class Initialized
INFO - 2025-05-05 07:23:32 --> Loader Class Initialized
INFO - 2025-05-05 07:23:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:32 --> Controller Class Initialized
INFO - 2025-05-05 15:23:32 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:23:32 --> Config Class Initialized
INFO - 2025-05-05 07:23:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:32 --> URI Class Initialized
INFO - 2025-05-05 07:23:32 --> Router Class Initialized
INFO - 2025-05-05 07:23:32 --> Output Class Initialized
INFO - 2025-05-05 07:23:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:32 --> Input Class Initialized
INFO - 2025-05-05 07:23:32 --> Language Class Initialized
INFO - 2025-05-05 07:23:32 --> Loader Class Initialized
INFO - 2025-05-05 07:23:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:32 --> Controller Class Initialized
INFO - 2025-05-05 07:23:32 --> Config Class Initialized
INFO - 2025-05-05 07:23:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:32 --> URI Class Initialized
DEBUG - 2025-05-05 07:23:32 --> No URI present. Default controller set.
INFO - 2025-05-05 07:23:32 --> Router Class Initialized
INFO - 2025-05-05 07:23:32 --> Output Class Initialized
INFO - 2025-05-05 07:23:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:32 --> Input Class Initialized
INFO - 2025-05-05 07:23:32 --> Language Class Initialized
INFO - 2025-05-05 07:23:32 --> Loader Class Initialized
INFO - 2025-05-05 07:23:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:32 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:32 --> Controller Class Initialized
INFO - 2025-05-05 07:23:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:23:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:23:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:23:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:23:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:23:32 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:32 --> Total execution time: 0.1772
INFO - 2025-05-05 07:23:33 --> Config Class Initialized
INFO - 2025-05-05 07:23:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:33 --> URI Class Initialized
INFO - 2025-05-05 07:23:33 --> Router Class Initialized
INFO - 2025-05-05 07:23:33 --> Output Class Initialized
INFO - 2025-05-05 07:23:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:33 --> Input Class Initialized
INFO - 2025-05-05 07:23:33 --> Language Class Initialized
INFO - 2025-05-05 07:23:33 --> Loader Class Initialized
INFO - 2025-05-05 07:23:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:33 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:33 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:33 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:33 --> Controller Class Initialized
INFO - 2025-05-05 15:23:33 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:23:40 --> Config Class Initialized
INFO - 2025-05-05 07:23:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:40 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:40 --> URI Class Initialized
INFO - 2025-05-05 07:23:40 --> Router Class Initialized
INFO - 2025-05-05 07:23:40 --> Output Class Initialized
INFO - 2025-05-05 07:23:40 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:40 --> Input Class Initialized
INFO - 2025-05-05 07:23:40 --> Language Class Initialized
INFO - 2025-05-05 07:23:40 --> Loader Class Initialized
INFO - 2025-05-05 07:23:40 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:40 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:40 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:40 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:40 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:40 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:40 --> Controller Class Initialized
INFO - 2025-05-05 07:23:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:23:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:23:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:23:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:23:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:23:40 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:40 --> Total execution time: 0.1151
INFO - 2025-05-05 07:23:41 --> Config Class Initialized
INFO - 2025-05-05 07:23:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:41 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:41 --> URI Class Initialized
INFO - 2025-05-05 07:23:41 --> Router Class Initialized
INFO - 2025-05-05 07:23:41 --> Output Class Initialized
INFO - 2025-05-05 07:23:41 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:41 --> Input Class Initialized
INFO - 2025-05-05 07:23:41 --> Language Class Initialized
INFO - 2025-05-05 07:23:41 --> Loader Class Initialized
INFO - 2025-05-05 07:23:41 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:41 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:41 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:41 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:41 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:42 --> Controller Class Initialized
INFO - 2025-05-05 15:23:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:23:42 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:23:42 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:23:42 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:42 --> Total execution time: 0.3008
INFO - 2025-05-05 07:23:42 --> Config Class Initialized
INFO - 2025-05-05 07:23:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:42 --> URI Class Initialized
INFO - 2025-05-05 07:23:42 --> Router Class Initialized
INFO - 2025-05-05 07:23:42 --> Output Class Initialized
INFO - 2025-05-05 07:23:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:42 --> Input Class Initialized
INFO - 2025-05-05 07:23:42 --> Language Class Initialized
INFO - 2025-05-05 07:23:42 --> Loader Class Initialized
INFO - 2025-05-05 07:23:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:42 --> Controller Class Initialized
INFO - 2025-05-05 15:23:42 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:23:42 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:42 --> Total execution time: 0.2342
INFO - 2025-05-05 07:23:42 --> Config Class Initialized
INFO - 2025-05-05 07:23:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:42 --> URI Class Initialized
INFO - 2025-05-05 07:23:42 --> Router Class Initialized
INFO - 2025-05-05 07:23:42 --> Output Class Initialized
INFO - 2025-05-05 07:23:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:42 --> Input Class Initialized
INFO - 2025-05-05 07:23:42 --> Language Class Initialized
INFO - 2025-05-05 07:23:42 --> Loader Class Initialized
INFO - 2025-05-05 07:23:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:42 --> Controller Class Initialized
INFO - 2025-05-05 07:23:42 --> Model "UserModel" initialized
INFO - 2025-05-05 07:23:42 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:42 --> Total execution time: 0.1467
INFO - 2025-05-05 07:23:43 --> Config Class Initialized
INFO - 2025-05-05 07:23:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:43 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:43 --> URI Class Initialized
INFO - 2025-05-05 07:23:43 --> Router Class Initialized
INFO - 2025-05-05 07:23:43 --> Output Class Initialized
INFO - 2025-05-05 07:23:43 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:43 --> Input Class Initialized
INFO - 2025-05-05 07:23:43 --> Language Class Initialized
INFO - 2025-05-05 07:23:43 --> Loader Class Initialized
INFO - 2025-05-05 07:23:43 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:43 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:43 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:43 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:43 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:43 --> Controller Class Initialized
INFO - 2025-05-05 07:23:43 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:23:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:23:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:23:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-05 07:23:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:23:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:23:43 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:43 --> Total execution time: 0.1752
INFO - 2025-05-05 07:23:44 --> Config Class Initialized
INFO - 2025-05-05 07:23:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:44 --> URI Class Initialized
INFO - 2025-05-05 07:23:44 --> Router Class Initialized
INFO - 2025-05-05 07:23:44 --> Output Class Initialized
INFO - 2025-05-05 07:23:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:44 --> Input Class Initialized
INFO - 2025-05-05 07:23:44 --> Language Class Initialized
INFO - 2025-05-05 07:23:44 --> Loader Class Initialized
INFO - 2025-05-05 07:23:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:44 --> Controller Class Initialized
INFO - 2025-05-05 07:23:44 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 07:23:44 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:44 --> Total execution time: 0.1584
INFO - 2025-05-05 07:23:45 --> Config Class Initialized
INFO - 2025-05-05 07:23:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:45 --> URI Class Initialized
INFO - 2025-05-05 07:23:45 --> Router Class Initialized
INFO - 2025-05-05 07:23:45 --> Output Class Initialized
INFO - 2025-05-05 07:23:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:45 --> Input Class Initialized
INFO - 2025-05-05 07:23:45 --> Language Class Initialized
INFO - 2025-05-05 07:23:45 --> Loader Class Initialized
INFO - 2025-05-05 07:23:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:45 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:45 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:45 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:45 --> Controller Class Initialized
INFO - 2025-05-05 07:23:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:23:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:23:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:23:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:23:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:23:45 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:45 --> Total execution time: 0.1373
INFO - 2025-05-05 07:23:50 --> Config Class Initialized
INFO - 2025-05-05 07:23:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:50 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:50 --> URI Class Initialized
INFO - 2025-05-05 07:23:50 --> Router Class Initialized
INFO - 2025-05-05 07:23:50 --> Output Class Initialized
INFO - 2025-05-05 07:23:50 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:50 --> Input Class Initialized
INFO - 2025-05-05 07:23:50 --> Language Class Initialized
INFO - 2025-05-05 07:23:50 --> Loader Class Initialized
INFO - 2025-05-05 07:23:50 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:50 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:50 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:50 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:50 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:50 --> Controller Class Initialized
INFO - 2025-05-05 15:23:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:23:50 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:23:50 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:23:50 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:50 --> Total execution time: 0.1712
INFO - 2025-05-05 07:23:51 --> Config Class Initialized
INFO - 2025-05-05 07:23:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:51 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:51 --> URI Class Initialized
INFO - 2025-05-05 07:23:51 --> Router Class Initialized
INFO - 2025-05-05 07:23:51 --> Output Class Initialized
INFO - 2025-05-05 07:23:51 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:51 --> Input Class Initialized
INFO - 2025-05-05 07:23:51 --> Language Class Initialized
INFO - 2025-05-05 07:23:51 --> Loader Class Initialized
INFO - 2025-05-05 07:23:51 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:51 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:51 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:51 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:51 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:51 --> Controller Class Initialized
INFO - 2025-05-05 15:23:51 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:23:51 --> Final output sent to browser
DEBUG - 2025-05-05 15:23:51 --> Total execution time: 0.1591
INFO - 2025-05-05 07:23:53 --> Config Class Initialized
INFO - 2025-05-05 07:23:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:53 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:53 --> Config Class Initialized
INFO - 2025-05-05 07:23:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:53 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:53 --> URI Class Initialized
INFO - 2025-05-05 07:23:53 --> Router Class Initialized
INFO - 2025-05-05 07:23:53 --> Output Class Initialized
INFO - 2025-05-05 07:23:53 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:53 --> Input Class Initialized
INFO - 2025-05-05 07:23:53 --> Language Class Initialized
INFO - 2025-05-05 07:23:53 --> Loader Class Initialized
INFO - 2025-05-05 07:23:53 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:53 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:53 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:53 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:53 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:53 --> Controller Class Initialized
INFO - 2025-05-05 07:23:53 --> Model "UserModel" initialized
INFO - 2025-05-05 07:23:53 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:53 --> Total execution time: 0.1232
INFO - 2025-05-05 07:23:59 --> Config Class Initialized
INFO - 2025-05-05 07:23:59 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:59 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:59 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:59 --> URI Class Initialized
INFO - 2025-05-05 07:23:59 --> Router Class Initialized
INFO - 2025-05-05 07:23:59 --> Output Class Initialized
INFO - 2025-05-05 07:23:59 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:59 --> Input Class Initialized
INFO - 2025-05-05 07:23:59 --> Language Class Initialized
INFO - 2025-05-05 07:23:59 --> Loader Class Initialized
INFO - 2025-05-05 07:23:59 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:59 --> Helper loaded: string_helper
INFO - 2025-05-05 07:23:59 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:59 --> Helper loaded: file_helper
INFO - 2025-05-05 07:23:59 --> Helper loaded: html_helper
INFO - 2025-05-05 07:23:59 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:59 --> Controller Class Initialized
INFO - 2025-05-05 07:23:59 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:23:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:23:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:23:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:23:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:23:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:23:59 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:59 --> Total execution time: 0.1015
INFO - 2025-05-05 07:24:00 --> Config Class Initialized
INFO - 2025-05-05 07:24:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:00 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:00 --> URI Class Initialized
INFO - 2025-05-05 07:24:00 --> Router Class Initialized
INFO - 2025-05-05 07:24:00 --> Output Class Initialized
INFO - 2025-05-05 07:24:00 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:00 --> Input Class Initialized
INFO - 2025-05-05 07:24:00 --> Language Class Initialized
INFO - 2025-05-05 07:24:00 --> Loader Class Initialized
INFO - 2025-05-05 07:24:00 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:00 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:00 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:00 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:00 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:00 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:00 --> Controller Class Initialized
INFO - 2025-05-05 15:24:00 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:00 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:24:00 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:00 --> Total execution time: 0.2039
INFO - 2025-05-05 07:24:03 --> Config Class Initialized
INFO - 2025-05-05 07:24:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:03 --> URI Class Initialized
INFO - 2025-05-05 07:24:03 --> Router Class Initialized
INFO - 2025-05-05 07:24:03 --> Output Class Initialized
INFO - 2025-05-05 07:24:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:03 --> Input Class Initialized
INFO - 2025-05-05 07:24:03 --> Language Class Initialized
INFO - 2025-05-05 07:24:03 --> Loader Class Initialized
INFO - 2025-05-05 07:24:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:03 --> Controller Class Initialized
INFO - 2025-05-05 15:24:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:03 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:24:03 --> Model "UserModel" initialized
INFO - 2025-05-05 07:24:03 --> Config Class Initialized
INFO - 2025-05-05 07:24:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:03 --> URI Class Initialized
INFO - 2025-05-05 07:24:03 --> Router Class Initialized
INFO - 2025-05-05 07:24:03 --> Output Class Initialized
INFO - 2025-05-05 07:24:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:03 --> Input Class Initialized
INFO - 2025-05-05 07:24:03 --> Language Class Initialized
INFO - 2025-05-05 07:24:03 --> Loader Class Initialized
INFO - 2025-05-05 07:24:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:03 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:03 --> Controller Class Initialized
INFO - 2025-05-05 15:24:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:03 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:24:04 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:04 --> Total execution time: 0.1276
INFO - 2025-05-05 07:24:05 --> Config Class Initialized
INFO - 2025-05-05 07:24:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:05 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:05 --> URI Class Initialized
INFO - 2025-05-05 07:24:05 --> Router Class Initialized
INFO - 2025-05-05 07:24:05 --> Output Class Initialized
INFO - 2025-05-05 07:24:05 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:05 --> Input Class Initialized
INFO - 2025-05-05 07:24:05 --> Language Class Initialized
INFO - 2025-05-05 07:24:05 --> Loader Class Initialized
INFO - 2025-05-05 07:24:05 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:05 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:05 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:05 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:05 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:05 --> Controller Class Initialized
INFO - 2025-05-05 15:24:05 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:05 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:24:05 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:05 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:05 --> Total execution time: 0.2334
INFO - 2025-05-05 07:24:07 --> Config Class Initialized
INFO - 2025-05-05 07:24:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:07 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:07 --> URI Class Initialized
INFO - 2025-05-05 07:24:07 --> Router Class Initialized
INFO - 2025-05-05 07:24:07 --> Output Class Initialized
INFO - 2025-05-05 07:24:07 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:07 --> Input Class Initialized
INFO - 2025-05-05 07:24:07 --> Language Class Initialized
INFO - 2025-05-05 07:24:07 --> Loader Class Initialized
INFO - 2025-05-05 07:24:07 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:07 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:07 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:07 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:07 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:07 --> Controller Class Initialized
INFO - 2025-05-05 15:24:07 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:24:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:24:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-05 15:24:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:24:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:24:07 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:07 --> Total execution time: 0.2338
INFO - 2025-05-05 07:24:08 --> Config Class Initialized
INFO - 2025-05-05 07:24:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:08 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:08 --> URI Class Initialized
INFO - 2025-05-05 07:24:08 --> Router Class Initialized
INFO - 2025-05-05 07:24:08 --> Output Class Initialized
INFO - 2025-05-05 07:24:08 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:08 --> Input Class Initialized
INFO - 2025-05-05 07:24:08 --> Language Class Initialized
INFO - 2025-05-05 07:24:08 --> Loader Class Initialized
INFO - 2025-05-05 07:24:08 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:08 --> Controller Class Initialized
INFO - 2025-05-05 07:24:08 --> Config Class Initialized
INFO - 2025-05-05 07:24:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:08 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:08 --> URI Class Initialized
INFO - 2025-05-05 07:24:08 --> Router Class Initialized
INFO - 2025-05-05 07:24:08 --> Output Class Initialized
INFO - 2025-05-05 07:24:08 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:08 --> Input Class Initialized
INFO - 2025-05-05 07:24:08 --> Language Class Initialized
INFO - 2025-05-05 07:24:08 --> Loader Class Initialized
INFO - 2025-05-05 07:24:08 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:08 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:08 --> Controller Class Initialized
INFO - 2025-05-05 15:24:08 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:24:11 --> Config Class Initialized
INFO - 2025-05-05 07:24:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:11 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:11 --> URI Class Initialized
INFO - 2025-05-05 07:24:11 --> Router Class Initialized
INFO - 2025-05-05 07:24:11 --> Output Class Initialized
INFO - 2025-05-05 07:24:11 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:11 --> Input Class Initialized
INFO - 2025-05-05 07:24:11 --> Language Class Initialized
INFO - 2025-05-05 07:24:12 --> Loader Class Initialized
INFO - 2025-05-05 07:24:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:12 --> Controller Class Initialized
INFO - 2025-05-05 15:24:12 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:12 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:24:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:24:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/auctions/details.php
INFO - 2025-05-05 15:24:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:24:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:24:12 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:12 --> Total execution time: 0.2219
INFO - 2025-05-05 07:24:12 --> Config Class Initialized
INFO - 2025-05-05 07:24:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:12 --> URI Class Initialized
INFO - 2025-05-05 07:24:12 --> Router Class Initialized
INFO - 2025-05-05 07:24:12 --> Output Class Initialized
INFO - 2025-05-05 07:24:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:12 --> Input Class Initialized
INFO - 2025-05-05 07:24:12 --> Language Class Initialized
INFO - 2025-05-05 07:24:12 --> Loader Class Initialized
INFO - 2025-05-05 07:24:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:12 --> Controller Class Initialized
INFO - 2025-05-05 15:24:12 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:12 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:12 --> Total execution time: 0.1130
INFO - 2025-05-05 07:24:12 --> Config Class Initialized
INFO - 2025-05-05 07:24:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:12 --> URI Class Initialized
INFO - 2025-05-05 07:24:12 --> Router Class Initialized
INFO - 2025-05-05 07:24:12 --> Output Class Initialized
INFO - 2025-05-05 07:24:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:12 --> Input Class Initialized
INFO - 2025-05-05 07:24:12 --> Language Class Initialized
INFO - 2025-05-05 07:24:12 --> Loader Class Initialized
INFO - 2025-05-05 07:24:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:12 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:12 --> Controller Class Initialized
INFO - 2025-05-05 07:24:12 --> Model "UserModel" initialized
INFO - 2025-05-05 07:24:12 --> Final output sent to browser
DEBUG - 2025-05-05 07:24:12 --> Total execution time: 0.2104
INFO - 2025-05-05 07:24:12 --> Config Class Initialized
INFO - 2025-05-05 07:24:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:12 --> URI Class Initialized
INFO - 2025-05-05 07:24:12 --> Router Class Initialized
INFO - 2025-05-05 07:24:12 --> Output Class Initialized
INFO - 2025-05-05 07:24:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:12 --> Input Class Initialized
INFO - 2025-05-05 07:24:12 --> Language Class Initialized
INFO - 2025-05-05 07:24:13 --> Loader Class Initialized
INFO - 2025-05-05 07:24:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:13 --> Controller Class Initialized
INFO - 2025-05-05 15:24:13 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:13 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:13 --> Total execution time: 0.1504
INFO - 2025-05-05 07:24:13 --> Config Class Initialized
INFO - 2025-05-05 07:24:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:13 --> URI Class Initialized
INFO - 2025-05-05 07:24:13 --> Router Class Initialized
INFO - 2025-05-05 07:24:13 --> Output Class Initialized
INFO - 2025-05-05 07:24:13 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:13 --> Input Class Initialized
INFO - 2025-05-05 07:24:13 --> Language Class Initialized
INFO - 2025-05-05 07:24:13 --> Loader Class Initialized
INFO - 2025-05-05 07:24:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:13 --> Controller Class Initialized
INFO - 2025-05-05 07:24:13 --> Config Class Initialized
INFO - 2025-05-05 07:24:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:13 --> URI Class Initialized
INFO - 2025-05-05 07:24:13 --> Router Class Initialized
INFO - 2025-05-05 07:24:13 --> Output Class Initialized
INFO - 2025-05-05 07:24:13 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:13 --> Input Class Initialized
INFO - 2025-05-05 07:24:13 --> Language Class Initialized
INFO - 2025-05-05 07:24:13 --> Loader Class Initialized
INFO - 2025-05-05 07:24:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:13 --> Controller Class Initialized
INFO - 2025-05-05 15:24:13 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:24:15 --> Config Class Initialized
INFO - 2025-05-05 07:24:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:15 --> URI Class Initialized
INFO - 2025-05-05 07:24:15 --> Router Class Initialized
INFO - 2025-05-05 07:24:15 --> Output Class Initialized
INFO - 2025-05-05 07:24:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:15 --> Input Class Initialized
INFO - 2025-05-05 07:24:15 --> Language Class Initialized
INFO - 2025-05-05 07:24:15 --> Loader Class Initialized
INFO - 2025-05-05 07:24:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:15 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:15 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:15 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:15 --> Controller Class Initialized
INFO - 2025-05-05 15:24:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:15 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:24:15 --> Config Class Initialized
INFO - 2025-05-05 07:24:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:15 --> URI Class Initialized
INFO - 2025-05-05 07:24:15 --> Router Class Initialized
INFO - 2025-05-05 07:24:15 --> Output Class Initialized
INFO - 2025-05-05 07:24:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:16 --> Input Class Initialized
INFO - 2025-05-05 07:24:16 --> Language Class Initialized
INFO - 2025-05-05 07:24:16 --> Loader Class Initialized
INFO - 2025-05-05 07:24:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:16 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:16 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:16 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:16 --> Controller Class Initialized
INFO - 2025-05-05 15:24:16 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:24:16 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:24:16 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:16 --> Total execution time: 0.1663
INFO - 2025-05-05 07:24:17 --> Config Class Initialized
INFO - 2025-05-05 07:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:17 --> URI Class Initialized
INFO - 2025-05-05 07:24:17 --> Router Class Initialized
INFO - 2025-05-05 07:24:17 --> Output Class Initialized
INFO - 2025-05-05 07:24:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:17 --> Input Class Initialized
INFO - 2025-05-05 07:24:17 --> Language Class Initialized
INFO - 2025-05-05 07:24:17 --> Loader Class Initialized
INFO - 2025-05-05 07:24:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:17 --> Controller Class Initialized
INFO - 2025-05-05 15:24:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:17 --> Config Class Initialized
INFO - 2025-05-05 07:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:17 --> URI Class Initialized
INFO - 2025-05-05 07:24:17 --> Router Class Initialized
INFO - 2025-05-05 07:24:17 --> Output Class Initialized
INFO - 2025-05-05 07:24:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:17 --> Input Class Initialized
INFO - 2025-05-05 07:24:17 --> Language Class Initialized
INFO - 2025-05-05 07:24:17 --> Loader Class Initialized
INFO - 2025-05-05 07:24:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:17 --> Controller Class Initialized
INFO - 2025-05-05 07:24:17 --> Config Class Initialized
INFO - 2025-05-05 07:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:17 --> URI Class Initialized
DEBUG - 2025-05-05 07:24:17 --> No URI present. Default controller set.
INFO - 2025-05-05 07:24:17 --> Router Class Initialized
INFO - 2025-05-05 07:24:17 --> Output Class Initialized
INFO - 2025-05-05 07:24:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:17 --> Input Class Initialized
INFO - 2025-05-05 07:24:17 --> Language Class Initialized
INFO - 2025-05-05 07:24:17 --> Loader Class Initialized
INFO - 2025-05-05 07:24:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:17 --> Controller Class Initialized
INFO - 2025-05-05 07:24:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:24:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:24:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:24:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:24:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:24:17 --> Final output sent to browser
DEBUG - 2025-05-05 07:24:17 --> Total execution time: 0.1004
INFO - 2025-05-05 07:24:18 --> Config Class Initialized
INFO - 2025-05-05 07:24:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:18 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:18 --> URI Class Initialized
INFO - 2025-05-05 07:24:18 --> Router Class Initialized
INFO - 2025-05-05 07:24:18 --> Output Class Initialized
INFO - 2025-05-05 07:24:18 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:18 --> Input Class Initialized
INFO - 2025-05-05 07:24:18 --> Language Class Initialized
INFO - 2025-05-05 07:24:18 --> Loader Class Initialized
INFO - 2025-05-05 07:24:18 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:18 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:18 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:18 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:18 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:18 --> Controller Class Initialized
INFO - 2025-05-05 15:24:18 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:24:19 --> Config Class Initialized
INFO - 2025-05-05 07:24:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:19 --> URI Class Initialized
INFO - 2025-05-05 07:24:19 --> Router Class Initialized
INFO - 2025-05-05 07:24:19 --> Output Class Initialized
INFO - 2025-05-05 07:24:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:19 --> Input Class Initialized
INFO - 2025-05-05 07:24:19 --> Language Class Initialized
INFO - 2025-05-05 07:24:19 --> Loader Class Initialized
INFO - 2025-05-05 07:24:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:19 --> Controller Class Initialized
INFO - 2025-05-05 15:24:19 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:19 --> Config Class Initialized
INFO - 2025-05-05 07:24:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:19 --> URI Class Initialized
INFO - 2025-05-05 07:24:19 --> Router Class Initialized
INFO - 2025-05-05 07:24:19 --> Output Class Initialized
INFO - 2025-05-05 07:24:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:19 --> Input Class Initialized
INFO - 2025-05-05 07:24:19 --> Language Class Initialized
INFO - 2025-05-05 07:24:19 --> Loader Class Initialized
INFO - 2025-05-05 07:24:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:19 --> Controller Class Initialized
INFO - 2025-05-05 07:24:19 --> Config Class Initialized
INFO - 2025-05-05 07:24:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:19 --> URI Class Initialized
DEBUG - 2025-05-05 07:24:19 --> No URI present. Default controller set.
INFO - 2025-05-05 07:24:19 --> Router Class Initialized
INFO - 2025-05-05 07:24:19 --> Output Class Initialized
INFO - 2025-05-05 07:24:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:19 --> Input Class Initialized
INFO - 2025-05-05 07:24:19 --> Language Class Initialized
INFO - 2025-05-05 07:24:19 --> Loader Class Initialized
INFO - 2025-05-05 07:24:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:19 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:20 --> Controller Class Initialized
INFO - 2025-05-05 07:24:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:24:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:24:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:24:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:24:20 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:24:20 --> Final output sent to browser
DEBUG - 2025-05-05 07:24:20 --> Total execution time: 0.0940
INFO - 2025-05-05 07:24:20 --> Config Class Initialized
INFO - 2025-05-05 07:24:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:20 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:20 --> URI Class Initialized
INFO - 2025-05-05 07:24:20 --> Router Class Initialized
INFO - 2025-05-05 07:24:20 --> Output Class Initialized
INFO - 2025-05-05 07:24:20 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:20 --> Input Class Initialized
INFO - 2025-05-05 07:24:20 --> Language Class Initialized
INFO - 2025-05-05 07:24:20 --> Loader Class Initialized
INFO - 2025-05-05 07:24:20 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:20 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:20 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:20 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:20 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:20 --> Controller Class Initialized
INFO - 2025-05-05 15:24:20 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:24:23 --> Config Class Initialized
INFO - 2025-05-05 07:24:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:23 --> URI Class Initialized
INFO - 2025-05-05 07:24:23 --> Router Class Initialized
INFO - 2025-05-05 07:24:23 --> Output Class Initialized
INFO - 2025-05-05 07:24:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:23 --> Input Class Initialized
INFO - 2025-05-05 07:24:23 --> Language Class Initialized
INFO - 2025-05-05 07:24:23 --> Loader Class Initialized
INFO - 2025-05-05 07:24:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:23 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:23 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:23 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:23 --> Controller Class Initialized
INFO - 2025-05-05 15:24:23 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:24 --> Config Class Initialized
INFO - 2025-05-05 07:24:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:24 --> URI Class Initialized
INFO - 2025-05-05 07:24:24 --> Router Class Initialized
INFO - 2025-05-05 07:24:24 --> Output Class Initialized
INFO - 2025-05-05 07:24:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:24 --> Input Class Initialized
INFO - 2025-05-05 07:24:24 --> Language Class Initialized
INFO - 2025-05-05 07:24:24 --> Loader Class Initialized
INFO - 2025-05-05 07:24:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:24 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:25 --> Controller Class Initialized
INFO - 2025-05-05 15:24:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:25 --> Config Class Initialized
INFO - 2025-05-05 07:24:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:25 --> URI Class Initialized
INFO - 2025-05-05 07:24:25 --> Router Class Initialized
INFO - 2025-05-05 07:24:25 --> Output Class Initialized
INFO - 2025-05-05 07:24:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:25 --> Input Class Initialized
INFO - 2025-05-05 07:24:25 --> Language Class Initialized
INFO - 2025-05-05 07:24:25 --> Loader Class Initialized
INFO - 2025-05-05 07:24:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:25 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:25 --> Controller Class Initialized
INFO - 2025-05-05 15:24:25 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:28 --> Config Class Initialized
INFO - 2025-05-05 07:24:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:28 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:28 --> URI Class Initialized
INFO - 2025-05-05 07:24:28 --> Router Class Initialized
INFO - 2025-05-05 07:24:28 --> Output Class Initialized
INFO - 2025-05-05 07:24:28 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:28 --> Input Class Initialized
INFO - 2025-05-05 07:24:28 --> Language Class Initialized
INFO - 2025-05-05 07:24:28 --> Loader Class Initialized
INFO - 2025-05-05 07:24:28 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:28 --> Controller Class Initialized
INFO - 2025-05-05 07:24:28 --> Config Class Initialized
INFO - 2025-05-05 07:24:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:28 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:28 --> URI Class Initialized
DEBUG - 2025-05-05 07:24:28 --> No URI present. Default controller set.
INFO - 2025-05-05 07:24:28 --> Router Class Initialized
INFO - 2025-05-05 07:24:28 --> Output Class Initialized
INFO - 2025-05-05 07:24:28 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:28 --> Input Class Initialized
INFO - 2025-05-05 07:24:28 --> Language Class Initialized
INFO - 2025-05-05 07:24:28 --> Loader Class Initialized
INFO - 2025-05-05 07:24:28 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:28 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:28 --> Controller Class Initialized
INFO - 2025-05-05 07:24:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:24:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:24:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 07:24:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:24:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:24:28 --> Final output sent to browser
DEBUG - 2025-05-05 07:24:28 --> Total execution time: 0.0884
INFO - 2025-05-05 07:24:29 --> Config Class Initialized
INFO - 2025-05-05 07:24:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:29 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:29 --> URI Class Initialized
INFO - 2025-05-05 07:24:29 --> Router Class Initialized
INFO - 2025-05-05 07:24:29 --> Output Class Initialized
INFO - 2025-05-05 07:24:29 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:29 --> Input Class Initialized
INFO - 2025-05-05 07:24:29 --> Language Class Initialized
INFO - 2025-05-05 07:24:29 --> Loader Class Initialized
INFO - 2025-05-05 07:24:29 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:29 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:29 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:29 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:29 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:29 --> Controller Class Initialized
INFO - 2025-05-05 15:24:29 --> Model "AuctionModel" initialized
INFO - 2025-05-05 07:24:31 --> Config Class Initialized
INFO - 2025-05-05 07:24:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:31 --> URI Class Initialized
INFO - 2025-05-05 07:24:31 --> Router Class Initialized
INFO - 2025-05-05 07:24:31 --> Config Class Initialized
INFO - 2025-05-05 07:24:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:31 --> Config Class Initialized
INFO - 2025-05-05 07:24:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:31 --> Hooks Class Initialized
INFO - 2025-05-05 07:24:31 --> URI Class Initialized
DEBUG - 2025-05-05 07:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:31 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:31 --> Router Class Initialized
INFO - 2025-05-05 07:24:31 --> URI Class Initialized
INFO - 2025-05-05 07:24:31 --> Output Class Initialized
INFO - 2025-05-05 07:24:31 --> Security Class Initialized
INFO - 2025-05-05 07:24:31 --> Router Class Initialized
DEBUG - 2025-05-05 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:31 --> Input Class Initialized
INFO - 2025-05-05 07:24:31 --> Output Class Initialized
INFO - 2025-05-05 07:24:31 --> Language Class Initialized
INFO - 2025-05-05 07:24:31 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:31 --> Input Class Initialized
INFO - 2025-05-05 07:24:31 --> Language Class Initialized
INFO - 2025-05-05 07:24:31 --> Loader Class Initialized
INFO - 2025-05-05 07:24:31 --> Loader Class Initialized
INFO - 2025-05-05 07:24:31 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:31 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:31 --> Database Driver Class Initialized
INFO - 2025-05-05 07:24:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:31 --> Controller Class Initialized
DEBUG - 2025-05-05 07:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 15:24:31 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:24:31 --> Final output sent to browser
DEBUG - 2025-05-05 15:24:31 --> Total execution time: 0.1175
INFO - 2025-05-05 07:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:31 --> Controller Class Initialized
INFO - 2025-05-05 15:24:31 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:24:32 --> Config Class Initialized
INFO - 2025-05-05 07:24:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:24:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:24:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:24:32 --> URI Class Initialized
INFO - 2025-05-05 07:24:32 --> Router Class Initialized
INFO - 2025-05-05 07:24:32 --> Output Class Initialized
INFO - 2025-05-05 07:24:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:24:32 --> Input Class Initialized
INFO - 2025-05-05 07:24:32 --> Language Class Initialized
INFO - 2025-05-05 07:24:32 --> Loader Class Initialized
INFO - 2025-05-05 07:24:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:24:32 --> Helper loaded: string_helper
INFO - 2025-05-05 07:24:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:24:32 --> Helper loaded: file_helper
INFO - 2025-05-05 07:24:32 --> Helper loaded: html_helper
INFO - 2025-05-05 07:24:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:24:32 --> Controller Class Initialized
INFO - 2025-05-05 07:24:32 --> Model "UserModel" initialized
INFO - 2025-05-05 07:24:32 --> Final output sent to browser
DEBUG - 2025-05-05 07:24:32 --> Total execution time: 0.1691
INFO - 2025-05-05 07:40:03 --> Config Class Initialized
INFO - 2025-05-05 07:40:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:03 --> URI Class Initialized
INFO - 2025-05-05 07:40:03 --> Router Class Initialized
INFO - 2025-05-05 07:40:03 --> Output Class Initialized
INFO - 2025-05-05 07:40:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:03 --> Input Class Initialized
INFO - 2025-05-05 07:40:03 --> Language Class Initialized
INFO - 2025-05-05 07:40:03 --> Loader Class Initialized
INFO - 2025-05-05 07:40:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:03 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:03 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:03 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:04 --> Controller Class Initialized
INFO - 2025-05-05 15:40:04 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:40:07 --> Config Class Initialized
INFO - 2025-05-05 07:40:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:07 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:07 --> URI Class Initialized
INFO - 2025-05-05 07:40:07 --> Router Class Initialized
INFO - 2025-05-05 07:40:07 --> Output Class Initialized
INFO - 2025-05-05 07:40:07 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:07 --> Input Class Initialized
INFO - 2025-05-05 07:40:07 --> Language Class Initialized
INFO - 2025-05-05 07:40:07 --> Loader Class Initialized
INFO - 2025-05-05 07:40:07 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:07 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:07 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:07 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:07 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:07 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:07 --> Controller Class Initialized
INFO - 2025-05-05 07:40:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:40:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:40:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-05 07:40:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:40:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:40:07 --> Final output sent to browser
DEBUG - 2025-05-05 07:40:07 --> Total execution time: 0.2939
INFO - 2025-05-05 07:40:09 --> Config Class Initialized
INFO - 2025-05-05 07:40:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:09 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:09 --> URI Class Initialized
INFO - 2025-05-05 07:40:09 --> Router Class Initialized
INFO - 2025-05-05 07:40:09 --> Output Class Initialized
INFO - 2025-05-05 07:40:09 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:09 --> Input Class Initialized
INFO - 2025-05-05 07:40:09 --> Language Class Initialized
INFO - 2025-05-05 07:40:09 --> Config Class Initialized
INFO - 2025-05-05 07:40:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:09 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:09 --> URI Class Initialized
INFO - 2025-05-05 07:40:09 --> Router Class Initialized
INFO - 2025-05-05 07:40:09 --> Output Class Initialized
INFO - 2025-05-05 07:40:09 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:09 --> Input Class Initialized
INFO - 2025-05-05 07:40:09 --> Language Class Initialized
INFO - 2025-05-05 07:40:09 --> Loader Class Initialized
INFO - 2025-05-05 07:40:09 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:09 --> Controller Class Initialized
INFO - 2025-05-05 15:40:09 --> Model "UserModel" initialized
INFO - 2025-05-05 07:40:09 --> Loader Class Initialized
INFO - 2025-05-05 07:40:09 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: string_helper
INFO - 2025-05-05 15:40:09 --> Final output sent to browser
DEBUG - 2025-05-05 15:40:09 --> Total execution time: 0.3497
INFO - 2025-05-05 07:40:09 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:09 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:09 --> Controller Class Initialized
INFO - 2025-05-05 15:40:09 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:40:10 --> Config Class Initialized
INFO - 2025-05-05 07:40:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:10 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:10 --> URI Class Initialized
INFO - 2025-05-05 07:40:10 --> Router Class Initialized
INFO - 2025-05-05 07:40:10 --> Output Class Initialized
INFO - 2025-05-05 07:40:10 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:10 --> Input Class Initialized
INFO - 2025-05-05 07:40:10 --> Language Class Initialized
INFO - 2025-05-05 07:40:10 --> Loader Class Initialized
INFO - 2025-05-05 07:40:10 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:10 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:10 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:10 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:10 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:10 --> Controller Class Initialized
INFO - 2025-05-05 15:40:10 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:40:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:40:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:40:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-05 15:40:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:40:10 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:40:10 --> Final output sent to browser
DEBUG - 2025-05-05 15:40:10 --> Total execution time: 0.1870
INFO - 2025-05-05 07:40:11 --> Config Class Initialized
INFO - 2025-05-05 07:40:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:11 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:11 --> URI Class Initialized
INFO - 2025-05-05 07:40:11 --> Router Class Initialized
INFO - 2025-05-05 07:40:11 --> Output Class Initialized
INFO - 2025-05-05 07:40:11 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:11 --> Input Class Initialized
INFO - 2025-05-05 07:40:11 --> Language Class Initialized
INFO - 2025-05-05 07:40:11 --> Loader Class Initialized
INFO - 2025-05-05 07:40:11 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:11 --> Controller Class Initialized
INFO - 2025-05-05 07:40:11 --> Config Class Initialized
INFO - 2025-05-05 07:40:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:11 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:11 --> URI Class Initialized
INFO - 2025-05-05 07:40:11 --> Router Class Initialized
INFO - 2025-05-05 07:40:11 --> Output Class Initialized
INFO - 2025-05-05 07:40:11 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:11 --> Input Class Initialized
INFO - 2025-05-05 07:40:11 --> Language Class Initialized
INFO - 2025-05-05 07:40:11 --> Loader Class Initialized
INFO - 2025-05-05 07:40:11 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:11 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:11 --> Controller Class Initialized
INFO - 2025-05-05 15:40:11 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:40:11 --> Final output sent to browser
DEBUG - 2025-05-05 15:40:11 --> Total execution time: 0.1207
INFO - 2025-05-05 07:40:12 --> Config Class Initialized
INFO - 2025-05-05 07:40:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:12 --> URI Class Initialized
INFO - 2025-05-05 07:40:12 --> Router Class Initialized
INFO - 2025-05-05 07:40:12 --> Output Class Initialized
INFO - 2025-05-05 07:40:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:12 --> Input Class Initialized
INFO - 2025-05-05 07:40:12 --> Language Class Initialized
INFO - 2025-05-05 07:40:12 --> Loader Class Initialized
INFO - 2025-05-05 07:40:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:12 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:12 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:12 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:12 --> Controller Class Initialized
INFO - 2025-05-05 15:40:12 --> Model "BankModel" initialized
INFO - 2025-05-05 07:40:13 --> Config Class Initialized
INFO - 2025-05-05 07:40:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:13 --> URI Class Initialized
INFO - 2025-05-05 07:40:13 --> Router Class Initialized
INFO - 2025-05-05 07:40:13 --> Output Class Initialized
INFO - 2025-05-05 07:40:13 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:13 --> Input Class Initialized
INFO - 2025-05-05 07:40:13 --> Language Class Initialized
INFO - 2025-05-05 07:40:13 --> Loader Class Initialized
INFO - 2025-05-05 07:40:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:13 --> Controller Class Initialized
INFO - 2025-05-05 15:40:13 --> Model "BankModel" initialized
INFO - 2025-05-05 15:40:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 15:40:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 15:40:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-05 15:40:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 15:40:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 15:40:13 --> Final output sent to browser
DEBUG - 2025-05-05 15:40:13 --> Total execution time: 0.1841
INFO - 2025-05-05 07:40:14 --> Config Class Initialized
INFO - 2025-05-05 07:40:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:14 --> URI Class Initialized
INFO - 2025-05-05 07:40:14 --> Router Class Initialized
INFO - 2025-05-05 07:40:14 --> Output Class Initialized
INFO - 2025-05-05 07:40:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:14 --> Input Class Initialized
INFO - 2025-05-05 07:40:14 --> Language Class Initialized
INFO - 2025-05-05 07:40:14 --> Loader Class Initialized
INFO - 2025-05-05 07:40:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:14 --> Controller Class Initialized
INFO - 2025-05-05 07:40:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:40:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:40:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:40:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:40:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:40:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:40:14 --> Final output sent to browser
DEBUG - 2025-05-05 07:40:14 --> Total execution time: 0.1343
INFO - 2025-05-05 07:40:15 --> Config Class Initialized
INFO - 2025-05-05 07:40:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:15 --> URI Class Initialized
INFO - 2025-05-05 07:40:15 --> Router Class Initialized
INFO - 2025-05-05 07:40:15 --> Output Class Initialized
INFO - 2025-05-05 07:40:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:15 --> Input Class Initialized
INFO - 2025-05-05 07:40:15 --> Language Class Initialized
INFO - 2025-05-05 07:40:15 --> Loader Class Initialized
INFO - 2025-05-05 07:40:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:15 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:15 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:15 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:15 --> Controller Class Initialized
INFO - 2025-05-05 15:40:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:40:15 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:40:15 --> Final output sent to browser
DEBUG - 2025-05-05 15:40:15 --> Total execution time: 0.2814
INFO - 2025-05-05 07:40:17 --> Config Class Initialized
INFO - 2025-05-05 07:40:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:17 --> URI Class Initialized
INFO - 2025-05-05 07:40:17 --> Router Class Initialized
INFO - 2025-05-05 07:40:17 --> Output Class Initialized
INFO - 2025-05-05 07:40:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:17 --> Input Class Initialized
INFO - 2025-05-05 07:40:17 --> Language Class Initialized
INFO - 2025-05-05 07:40:17 --> Loader Class Initialized
INFO - 2025-05-05 07:40:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:17 --> Controller Class Initialized
INFO - 2025-05-05 07:40:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:40:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:40:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:40:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-05 07:40:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:40:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:40:17 --> Final output sent to browser
DEBUG - 2025-05-05 07:40:17 --> Total execution time: 0.1274
INFO - 2025-05-05 07:40:18 --> Config Class Initialized
INFO - 2025-05-05 07:40:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:40:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:40:18 --> Utf8 Class Initialized
INFO - 2025-05-05 07:40:18 --> URI Class Initialized
INFO - 2025-05-05 07:40:18 --> Router Class Initialized
INFO - 2025-05-05 07:40:18 --> Output Class Initialized
INFO - 2025-05-05 07:40:18 --> Security Class Initialized
DEBUG - 2025-05-05 07:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:40:18 --> Input Class Initialized
INFO - 2025-05-05 07:40:18 --> Language Class Initialized
INFO - 2025-05-05 07:40:18 --> Loader Class Initialized
INFO - 2025-05-05 07:40:18 --> Helper loaded: url_helper
INFO - 2025-05-05 07:40:18 --> Helper loaded: string_helper
INFO - 2025-05-05 07:40:18 --> Helper loaded: form_helper
INFO - 2025-05-05 07:40:18 --> Helper loaded: file_helper
INFO - 2025-05-05 07:40:18 --> Helper loaded: html_helper
INFO - 2025-05-05 07:40:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:40:18 --> Controller Class Initialized
INFO - 2025-05-05 07:40:18 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 07:40:18 --> Final output sent to browser
DEBUG - 2025-05-05 07:40:18 --> Total execution time: 0.1875
INFO - 2025-05-05 07:41:26 --> Config Class Initialized
INFO - 2025-05-05 07:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:41:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:41:26 --> URI Class Initialized
INFO - 2025-05-05 07:41:26 --> Router Class Initialized
INFO - 2025-05-05 07:41:26 --> Output Class Initialized
INFO - 2025-05-05 07:41:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:41:26 --> Input Class Initialized
INFO - 2025-05-05 07:41:26 --> Language Class Initialized
INFO - 2025-05-05 07:41:26 --> Loader Class Initialized
INFO - 2025-05-05 07:41:26 --> Helper loaded: url_helper
INFO - 2025-05-05 07:41:26 --> Helper loaded: string_helper
INFO - 2025-05-05 07:41:26 --> Helper loaded: form_helper
INFO - 2025-05-05 07:41:26 --> Helper loaded: file_helper
INFO - 2025-05-05 07:41:26 --> Helper loaded: html_helper
INFO - 2025-05-05 07:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:41:26 --> Controller Class Initialized
INFO - 2025-05-05 07:41:26 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 07:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:41:26 --> Final output sent to browser
DEBUG - 2025-05-05 07:41:26 --> Total execution time: 0.1281
INFO - 2025-05-05 07:41:27 --> Config Class Initialized
INFO - 2025-05-05 07:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:41:27 --> Utf8 Class Initialized
INFO - 2025-05-05 07:41:27 --> URI Class Initialized
INFO - 2025-05-05 07:41:27 --> Router Class Initialized
INFO - 2025-05-05 07:41:27 --> Output Class Initialized
INFO - 2025-05-05 07:41:27 --> Security Class Initialized
DEBUG - 2025-05-05 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:41:27 --> Input Class Initialized
INFO - 2025-05-05 07:41:27 --> Language Class Initialized
INFO - 2025-05-05 07:41:27 --> Loader Class Initialized
INFO - 2025-05-05 07:41:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:41:27 --> Helper loaded: string_helper
INFO - 2025-05-05 07:41:27 --> Helper loaded: form_helper
INFO - 2025-05-05 07:41:27 --> Helper loaded: file_helper
INFO - 2025-05-05 07:41:27 --> Helper loaded: html_helper
INFO - 2025-05-05 07:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:41:27 --> Controller Class Initialized
INFO - 2025-05-05 15:41:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:41:27 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:41:27 --> Final output sent to browser
DEBUG - 2025-05-05 15:41:27 --> Total execution time: 0.2162
INFO - 2025-05-05 07:43:48 --> Config Class Initialized
INFO - 2025-05-05 07:43:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:48 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:48 --> URI Class Initialized
INFO - 2025-05-05 07:43:48 --> Router Class Initialized
INFO - 2025-05-05 07:43:48 --> Output Class Initialized
INFO - 2025-05-05 07:43:48 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:48 --> Input Class Initialized
INFO - 2025-05-05 07:43:48 --> Language Class Initialized
INFO - 2025-05-05 07:43:48 --> Loader Class Initialized
INFO - 2025-05-05 07:43:48 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:48 --> Controller Class Initialized
INFO - 2025-05-05 15:43:48 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:43:48 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:43:48 --> Model "UserModel" initialized
INFO - 2025-05-05 07:43:48 --> Config Class Initialized
INFO - 2025-05-05 07:43:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:48 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:48 --> URI Class Initialized
INFO - 2025-05-05 07:43:48 --> Router Class Initialized
INFO - 2025-05-05 07:43:48 --> Output Class Initialized
INFO - 2025-05-05 07:43:48 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:48 --> Input Class Initialized
INFO - 2025-05-05 07:43:48 --> Language Class Initialized
INFO - 2025-05-05 07:43:48 --> Loader Class Initialized
INFO - 2025-05-05 07:43:48 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:48 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:48 --> Controller Class Initialized
INFO - 2025-05-05 15:43:48 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:43:48 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:43:48 --> Final output sent to browser
DEBUG - 2025-05-05 15:43:48 --> Total execution time: 0.1373
INFO - 2025-05-05 07:43:50 --> Config Class Initialized
INFO - 2025-05-05 07:43:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:50 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:50 --> URI Class Initialized
INFO - 2025-05-05 07:43:50 --> Router Class Initialized
INFO - 2025-05-05 07:43:50 --> Output Class Initialized
INFO - 2025-05-05 07:43:50 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:50 --> Input Class Initialized
INFO - 2025-05-05 07:43:50 --> Language Class Initialized
INFO - 2025-05-05 07:43:50 --> Loader Class Initialized
INFO - 2025-05-05 07:43:50 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:50 --> Controller Class Initialized
INFO - 2025-05-05 15:43:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:43:50 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:43:50 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:43:50 --> Final output sent to browser
DEBUG - 2025-05-05 15:43:50 --> Total execution time: 0.1868
INFO - 2025-05-05 07:43:50 --> Config Class Initialized
INFO - 2025-05-05 07:43:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:50 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:50 --> URI Class Initialized
INFO - 2025-05-05 07:43:50 --> Router Class Initialized
INFO - 2025-05-05 07:43:50 --> Output Class Initialized
INFO - 2025-05-05 07:43:50 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:50 --> Input Class Initialized
INFO - 2025-05-05 07:43:50 --> Language Class Initialized
INFO - 2025-05-05 07:43:50 --> Loader Class Initialized
INFO - 2025-05-05 07:43:50 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:50 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:50 --> Controller Class Initialized
INFO - 2025-05-05 15:43:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:43:50 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:43:50 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:43:50 --> Model "InvoiceModel" initialized
INFO - 2025-05-05 15:43:50 --> Final output sent to browser
DEBUG - 2025-05-05 15:43:50 --> Total execution time: 0.1182
INFO - 2025-05-05 07:43:53 --> Config Class Initialized
INFO - 2025-05-05 07:43:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:53 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:53 --> URI Class Initialized
INFO - 2025-05-05 07:43:53 --> Router Class Initialized
INFO - 2025-05-05 07:43:53 --> Output Class Initialized
INFO - 2025-05-05 07:43:53 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:53 --> Input Class Initialized
INFO - 2025-05-05 07:43:53 --> Language Class Initialized
INFO - 2025-05-05 07:43:53 --> Loader Class Initialized
INFO - 2025-05-05 07:43:53 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:53 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:53 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:53 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:53 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:53 --> Database Driver Class Initialized
INFO - 2025-05-05 07:43:54 --> Config Class Initialized
INFO - 2025-05-05 07:43:54 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:54 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:54 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:54 --> URI Class Initialized
INFO - 2025-05-05 07:43:54 --> Router Class Initialized
INFO - 2025-05-05 07:43:54 --> Output Class Initialized
INFO - 2025-05-05 07:43:54 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:54 --> Input Class Initialized
INFO - 2025-05-05 07:43:54 --> Language Class Initialized
INFO - 2025-05-05 07:43:54 --> Loader Class Initialized
INFO - 2025-05-05 07:43:54 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:54 --> Helper loaded: string_helper
INFO - 2025-05-05 07:43:54 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:54 --> Helper loaded: file_helper
INFO - 2025-05-05 07:43:54 --> Helper loaded: html_helper
INFO - 2025-05-05 07:43:54 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:54 --> Controller Class Initialized
INFO - 2025-05-05 15:43:54 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:43:54 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-05 15:43:54 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:43:54 --> Model "InvoiceModel" initialized
INFO - 2025-05-05 15:43:54 --> Final output sent to browser
DEBUG - 2025-05-05 15:43:54 --> Total execution time: 0.1253
INFO - 2025-05-05 07:43:56 --> Config Class Initialized
INFO - 2025-05-05 07:43:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:56 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:56 --> URI Class Initialized
INFO - 2025-05-05 07:43:56 --> Router Class Initialized
INFO - 2025-05-05 15:43:56 --> Final output sent to browser
DEBUG - 2025-05-05 15:43:56 --> Total execution time: 0.1507
INFO - 2025-05-05 07:44:01 --> Config Class Initialized
INFO - 2025-05-05 07:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:01 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:01 --> URI Class Initialized
INFO - 2025-05-05 07:44:01 --> Router Class Initialized
INFO - 2025-05-05 07:44:01 --> Output Class Initialized
INFO - 2025-05-05 07:44:01 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:01 --> Input Class Initialized
INFO - 2025-05-05 07:44:01 --> Language Class Initialized
INFO - 2025-05-05 07:44:01 --> Loader Class Initialized
INFO - 2025-05-05 07:44:01 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:01 --> Controller Class Initialized
INFO - 2025-05-05 15:44:01 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:44:01 --> Model "StaffModel" initialized
INFO - 2025-05-05 07:44:01 --> Config Class Initialized
INFO - 2025-05-05 07:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:01 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:01 --> URI Class Initialized
INFO - 2025-05-05 07:44:01 --> Router Class Initialized
INFO - 2025-05-05 07:44:01 --> Output Class Initialized
INFO - 2025-05-05 07:44:01 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:01 --> Input Class Initialized
INFO - 2025-05-05 07:44:01 --> Language Class Initialized
INFO - 2025-05-05 07:44:01 --> Loader Class Initialized
INFO - 2025-05-05 07:44:01 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:01 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:02 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:02 --> Controller Class Initialized
INFO - 2025-05-05 15:44:02 --> Model "CompanyModel" initialized
INFO - 2025-05-05 15:44:02 --> Model "StaffModel" initialized
INFO - 2025-05-05 15:44:02 --> Final output sent to browser
DEBUG - 2025-05-05 15:44:02 --> Total execution time: 0.3968
INFO - 2025-05-05 07:44:03 --> Config Class Initialized
INFO - 2025-05-05 07:44:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:03 --> URI Class Initialized
INFO - 2025-05-05 07:44:03 --> Router Class Initialized
INFO - 2025-05-05 07:44:03 --> Output Class Initialized
INFO - 2025-05-05 07:44:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:03 --> Input Class Initialized
INFO - 2025-05-05 07:44:03 --> Language Class Initialized
INFO - 2025-05-05 07:44:03 --> Loader Class Initialized
INFO - 2025-05-05 07:44:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:03 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:03 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:03 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:03 --> Controller Class Initialized
INFO - 2025-05-05 15:44:03 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:41 --> Config Class Initialized
INFO - 2025-05-05 07:44:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:41 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:41 --> URI Class Initialized
INFO - 2025-05-05 07:44:41 --> Router Class Initialized
INFO - 2025-05-05 07:44:41 --> Output Class Initialized
INFO - 2025-05-05 07:44:41 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:41 --> Input Class Initialized
INFO - 2025-05-05 07:44:41 --> Language Class Initialized
INFO - 2025-05-05 07:44:41 --> Loader Class Initialized
INFO - 2025-05-05 07:44:41 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:41 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:41 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:41 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:41 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:41 --> Controller Class Initialized
INFO - 2025-05-05 15:44:41 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:43 --> Config Class Initialized
INFO - 2025-05-05 07:44:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:43 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:43 --> URI Class Initialized
INFO - 2025-05-05 07:44:43 --> Router Class Initialized
INFO - 2025-05-05 07:44:43 --> Output Class Initialized
INFO - 2025-05-05 07:44:43 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:43 --> Input Class Initialized
INFO - 2025-05-05 07:44:43 --> Language Class Initialized
INFO - 2025-05-05 07:44:43 --> Loader Class Initialized
INFO - 2025-05-05 07:44:43 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:44 --> Config Class Initialized
INFO - 2025-05-05 07:44:44 --> Config Class Initialized
INFO - 2025-05-05 07:44:44 --> Hooks Class Initialized
INFO - 2025-05-05 07:44:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:44 --> UTF-8 Support Enabled
DEBUG - 2025-05-05 07:44:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:44 --> URI Class Initialized
INFO - 2025-05-05 07:44:44 --> URI Class Initialized
INFO - 2025-05-05 07:44:44 --> Router Class Initialized
INFO - 2025-05-05 07:44:44 --> Router Class Initialized
INFO - 2025-05-05 07:44:44 --> Output Class Initialized
INFO - 2025-05-05 07:44:44 --> Security Class Initialized
INFO - 2025-05-05 07:44:44 --> Output Class Initialized
DEBUG - 2025-05-05 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:44 --> Security Class Initialized
INFO - 2025-05-05 07:44:44 --> Input Class Initialized
INFO - 2025-05-05 07:44:44 --> Language Class Initialized
DEBUG - 2025-05-05 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:44 --> Input Class Initialized
INFO - 2025-05-05 07:44:44 --> Language Class Initialized
INFO - 2025-05-05 07:44:44 --> Loader Class Initialized
INFO - 2025-05-05 07:44:44 --> Loader Class Initialized
INFO - 2025-05-05 07:44:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:44 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:44 --> Database Driver Class Initialized
INFO - 2025-05-05 07:44:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-05 07:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:44 --> Controller Class Initialized
INFO - 2025-05-05 15:44:44 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:44 --> Controller Class Initialized
INFO - 2025-05-05 15:44:44 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:44:44 --> Final output sent to browser
DEBUG - 2025-05-05 15:44:44 --> Total execution time: 0.1437
INFO - 2025-05-05 07:44:45 --> Config Class Initialized
INFO - 2025-05-05 07:44:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:45 --> URI Class Initialized
INFO - 2025-05-05 07:44:45 --> Router Class Initialized
INFO - 2025-05-05 07:44:45 --> Output Class Initialized
INFO - 2025-05-05 07:44:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:45 --> Input Class Initialized
INFO - 2025-05-05 07:44:45 --> Language Class Initialized
INFO - 2025-05-05 07:44:45 --> Loader Class Initialized
INFO - 2025-05-05 07:44:45 --> Config Class Initialized
INFO - 2025-05-05 07:44:45 --> Hooks Class Initialized
INFO - 2025-05-05 07:44:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:45 --> Helper loaded: string_helper
DEBUG - 2025-05-05 07:44:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:45 --> URI Class Initialized
INFO - 2025-05-05 07:44:45 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:45 --> Router Class Initialized
INFO - 2025-05-05 07:44:45 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:45 --> Output Class Initialized
INFO - 2025-05-05 07:44:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:45 --> Input Class Initialized
INFO - 2025-05-05 07:44:45 --> Language Class Initialized
INFO - 2025-05-05 07:44:45 --> Database Driver Class Initialized
INFO - 2025-05-05 07:44:46 --> Loader Class Initialized
DEBUG - 2025-05-05 07:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:46 --> Controller Class Initialized
INFO - 2025-05-05 07:44:46 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:46 --> Model "UserModel" initialized
INFO - 2025-05-05 07:44:46 --> Final output sent to browser
DEBUG - 2025-05-05 07:44:46 --> Total execution time: 0.2321
INFO - 2025-05-05 07:44:46 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:46 --> Controller Class Initialized
INFO - 2025-05-05 15:44:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:46 --> Config Class Initialized
INFO - 2025-05-05 07:44:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:46 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:46 --> URI Class Initialized
INFO - 2025-05-05 07:44:46 --> Router Class Initialized
INFO - 2025-05-05 07:44:46 --> Output Class Initialized
INFO - 2025-05-05 07:44:46 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:46 --> Input Class Initialized
INFO - 2025-05-05 07:44:46 --> Language Class Initialized
INFO - 2025-05-05 07:44:46 --> Loader Class Initialized
INFO - 2025-05-05 07:44:46 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:46 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:46 --> Controller Class Initialized
INFO - 2025-05-05 15:44:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:47 --> Config Class Initialized
INFO - 2025-05-05 07:44:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:47 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:47 --> URI Class Initialized
INFO - 2025-05-05 07:44:47 --> Router Class Initialized
INFO - 2025-05-05 07:44:47 --> Output Class Initialized
INFO - 2025-05-05 07:44:47 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:47 --> Input Class Initialized
INFO - 2025-05-05 07:44:47 --> Language Class Initialized
INFO - 2025-05-05 07:44:47 --> Loader Class Initialized
INFO - 2025-05-05 07:44:47 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:47 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:47 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:47 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:47 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:47 --> Controller Class Initialized
INFO - 2025-05-05 15:44:47 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:56 --> Config Class Initialized
INFO - 2025-05-05 07:44:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:56 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:56 --> URI Class Initialized
INFO - 2025-05-05 07:44:56 --> Router Class Initialized
INFO - 2025-05-05 07:44:56 --> Output Class Initialized
INFO - 2025-05-05 07:44:56 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:56 --> Input Class Initialized
INFO - 2025-05-05 07:44:56 --> Language Class Initialized
INFO - 2025-05-05 07:44:56 --> Loader Class Initialized
INFO - 2025-05-05 07:44:56 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:56 --> Controller Class Initialized
INFO - 2025-05-05 07:44:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:44:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:44:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:44:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:44:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:44:56 --> Final output sent to browser
DEBUG - 2025-05-05 07:44:56 --> Total execution time: 0.0742
INFO - 2025-05-05 07:44:56 --> Config Class Initialized
INFO - 2025-05-05 07:44:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:56 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:56 --> URI Class Initialized
INFO - 2025-05-05 07:44:56 --> Router Class Initialized
INFO - 2025-05-05 07:44:56 --> Output Class Initialized
INFO - 2025-05-05 07:44:56 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:56 --> Input Class Initialized
INFO - 2025-05-05 07:44:56 --> Language Class Initialized
INFO - 2025-05-05 07:44:56 --> Config Class Initialized
INFO - 2025-05-05 07:44:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:56 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:56 --> Loader Class Initialized
INFO - 2025-05-05 07:44:56 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:56 --> URI Class Initialized
INFO - 2025-05-05 07:44:56 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:56 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:57 --> Router Class Initialized
INFO - 2025-05-05 07:44:57 --> Output Class Initialized
INFO - 2025-05-05 07:44:57 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:57 --> Input Class Initialized
INFO - 2025-05-05 07:44:57 --> Language Class Initialized
INFO - 2025-05-05 07:44:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:57 --> Controller Class Initialized
INFO - 2025-05-05 07:44:57 --> Loader Class Initialized
INFO - 2025-05-05 15:44:57 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:44:57 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:57 --> Controller Class Initialized
INFO - 2025-05-05 15:44:57 --> Model "AuctionModel" initialized
INFO - 2025-05-05 15:44:57 --> Final output sent to browser
DEBUG - 2025-05-05 15:44:57 --> Total execution time: 0.2333
INFO - 2025-05-05 07:44:57 --> Config Class Initialized
INFO - 2025-05-05 07:44:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:44:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:44:57 --> Utf8 Class Initialized
INFO - 2025-05-05 07:44:57 --> URI Class Initialized
INFO - 2025-05-05 07:44:57 --> Router Class Initialized
INFO - 2025-05-05 07:44:57 --> Output Class Initialized
INFO - 2025-05-05 07:44:57 --> Security Class Initialized
DEBUG - 2025-05-05 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:44:57 --> Input Class Initialized
INFO - 2025-05-05 07:44:57 --> Language Class Initialized
INFO - 2025-05-05 07:44:57 --> Loader Class Initialized
INFO - 2025-05-05 07:44:57 --> Helper loaded: url_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: string_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: form_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: file_helper
INFO - 2025-05-05 07:44:57 --> Helper loaded: html_helper
INFO - 2025-05-05 07:44:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:44:57 --> Controller Class Initialized
INFO - 2025-05-05 07:44:57 --> Model "UserModel" initialized
INFO - 2025-05-05 07:44:57 --> Final output sent to browser
DEBUG - 2025-05-05 07:44:57 --> Total execution time: 0.1074
INFO - 2025-05-05 07:46:10 --> Config Class Initialized
INFO - 2025-05-05 07:46:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:10 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:10 --> URI Class Initialized
INFO - 2025-05-05 07:46:10 --> Router Class Initialized
INFO - 2025-05-05 07:46:10 --> Output Class Initialized
INFO - 2025-05-05 07:46:10 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:10 --> Input Class Initialized
INFO - 2025-05-05 07:46:10 --> Language Class Initialized
INFO - 2025-05-05 07:46:11 --> Loader Class Initialized
INFO - 2025-05-05 07:46:11 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:11 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:11 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:11 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:11 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:11 --> Controller Class Initialized
INFO - 2025-05-05 15:46:11 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:46:13 --> Config Class Initialized
INFO - 2025-05-05 07:46:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:13 --> URI Class Initialized
INFO - 2025-05-05 07:46:13 --> Router Class Initialized
INFO - 2025-05-05 07:46:13 --> Output Class Initialized
INFO - 2025-05-05 07:46:13 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:13 --> Input Class Initialized
INFO - 2025-05-05 07:46:13 --> Language Class Initialized
INFO - 2025-05-05 07:46:13 --> Loader Class Initialized
INFO - 2025-05-05 07:46:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:13 --> Controller Class Initialized
INFO - 2025-05-05 07:46:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 07:46:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 07:46:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 07:46:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 07:46:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 07:46:13 --> Final output sent to browser
DEBUG - 2025-05-05 07:46:13 --> Total execution time: 0.2484
INFO - 2025-05-05 07:46:13 --> Config Class Initialized
INFO - 2025-05-05 07:46:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:13 --> Config Class Initialized
INFO - 2025-05-05 07:46:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:13 --> Hooks Class Initialized
INFO - 2025-05-05 07:46:13 --> URI Class Initialized
DEBUG - 2025-05-05 07:46:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:13 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:13 --> URI Class Initialized
INFO - 2025-05-05 07:46:13 --> Router Class Initialized
INFO - 2025-05-05 07:46:13 --> Router Class Initialized
INFO - 2025-05-05 07:46:13 --> Output Class Initialized
INFO - 2025-05-05 07:46:13 --> Security Class Initialized
INFO - 2025-05-05 07:46:13 --> Output Class Initialized
DEBUG - 2025-05-05 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:13 --> Input Class Initialized
INFO - 2025-05-05 07:46:13 --> Security Class Initialized
INFO - 2025-05-05 07:46:13 --> Language Class Initialized
DEBUG - 2025-05-05 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:13 --> Input Class Initialized
INFO - 2025-05-05 07:46:13 --> Language Class Initialized
INFO - 2025-05-05 07:46:13 --> Loader Class Initialized
INFO - 2025-05-05 07:46:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:13 --> Database Driver Class Initialized
INFO - 2025-05-05 07:46:13 --> Loader Class Initialized
INFO - 2025-05-05 07:46:13 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:13 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:14 --> Controller Class Initialized
INFO - 2025-05-05 15:46:14 --> Model "AuctionModel" initialized
DEBUG - 2025-05-05 07:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 15:46:14 --> Final output sent to browser
DEBUG - 2025-05-05 15:46:14 --> Total execution time: 0.3513
INFO - 2025-05-05 07:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:14 --> Controller Class Initialized
INFO - 2025-05-05 15:46:14 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:46:14 --> Config Class Initialized
INFO - 2025-05-05 07:46:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:14 --> URI Class Initialized
INFO - 2025-05-05 07:46:14 --> Router Class Initialized
INFO - 2025-05-05 07:46:14 --> Output Class Initialized
INFO - 2025-05-05 07:46:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:14 --> Input Class Initialized
INFO - 2025-05-05 07:46:14 --> Language Class Initialized
INFO - 2025-05-05 07:46:14 --> Loader Class Initialized
INFO - 2025-05-05 07:46:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:14 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:14 --> Controller Class Initialized
INFO - 2025-05-05 07:46:14 --> Model "UserModel" initialized
INFO - 2025-05-05 07:46:17 --> Config Class Initialized
INFO - 2025-05-05 07:46:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:17 --> URI Class Initialized
INFO - 2025-05-05 07:46:17 --> Router Class Initialized
INFO - 2025-05-05 07:46:17 --> Output Class Initialized
INFO - 2025-05-05 07:46:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:17 --> Input Class Initialized
INFO - 2025-05-05 07:46:17 --> Language Class Initialized
INFO - 2025-05-05 07:46:17 --> Loader Class Initialized
INFO - 2025-05-05 07:46:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:17 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:17 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:17 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:17 --> Controller Class Initialized
INFO - 2025-05-05 15:46:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:46:17 --> Config Class Initialized
INFO - 2025-05-05 07:46:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:17 --> URI Class Initialized
INFO - 2025-05-05 07:46:17 --> Router Class Initialized
INFO - 2025-05-05 07:46:17 --> Output Class Initialized
INFO - 2025-05-05 07:46:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:17 --> Input Class Initialized
INFO - 2025-05-05 07:46:18 --> Language Class Initialized
INFO - 2025-05-05 07:46:18 --> Loader Class Initialized
INFO - 2025-05-05 07:46:18 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:18 --> Controller Class Initialized
INFO - 2025-05-05 15:46:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 07:46:18 --> Config Class Initialized
INFO - 2025-05-05 07:46:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:46:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:46:18 --> Utf8 Class Initialized
INFO - 2025-05-05 07:46:18 --> URI Class Initialized
INFO - 2025-05-05 07:46:18 --> Router Class Initialized
INFO - 2025-05-05 07:46:18 --> Output Class Initialized
INFO - 2025-05-05 07:46:18 --> Security Class Initialized
DEBUG - 2025-05-05 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:46:18 --> Input Class Initialized
INFO - 2025-05-05 07:46:18 --> Language Class Initialized
INFO - 2025-05-05 07:46:18 --> Loader Class Initialized
INFO - 2025-05-05 07:46:18 --> Helper loaded: url_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: string_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: form_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: file_helper
INFO - 2025-05-05 07:46:18 --> Helper loaded: html_helper
INFO - 2025-05-05 07:46:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:46:18 --> Controller Class Initialized
INFO - 2025-05-05 15:46:18 --> Model "CompanyModel" initialized
INFO - 2025-05-05 08:18:14 --> Config Class Initialized
INFO - 2025-05-05 08:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 08:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 08:18:14 --> Utf8 Class Initialized
INFO - 2025-05-05 08:18:15 --> URI Class Initialized
INFO - 2025-05-05 08:18:15 --> Router Class Initialized
INFO - 2025-05-05 08:18:15 --> Output Class Initialized
INFO - 2025-05-05 08:18:15 --> Security Class Initialized
DEBUG - 2025-05-05 08:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 08:18:15 --> Input Class Initialized
INFO - 2025-05-05 08:18:15 --> Language Class Initialized
INFO - 2025-05-05 08:18:15 --> Loader Class Initialized
INFO - 2025-05-05 08:18:15 --> Helper loaded: url_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: string_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: form_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: file_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: html_helper
INFO - 2025-05-05 08:18:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 08:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 08:18:15 --> Controller Class Initialized
INFO - 2025-05-05 16:18:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 08:18:15 --> Config Class Initialized
INFO - 2025-05-05 08:18:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 08:18:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 08:18:15 --> Utf8 Class Initialized
INFO - 2025-05-05 08:18:15 --> URI Class Initialized
INFO - 2025-05-05 08:18:15 --> Router Class Initialized
INFO - 2025-05-05 08:18:15 --> Output Class Initialized
INFO - 2025-05-05 08:18:15 --> Security Class Initialized
DEBUG - 2025-05-05 08:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 08:18:15 --> Input Class Initialized
INFO - 2025-05-05 08:18:15 --> Language Class Initialized
INFO - 2025-05-05 08:18:15 --> Loader Class Initialized
INFO - 2025-05-05 08:18:15 --> Helper loaded: url_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: string_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: form_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: file_helper
INFO - 2025-05-05 08:18:15 --> Helper loaded: html_helper
INFO - 2025-05-05 08:18:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 08:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 08:18:15 --> Controller Class Initialized
INFO - 2025-05-05 16:18:15 --> Model "CompanyModel" initialized
INFO - 2025-05-05 16:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 16:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 16:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-05 16:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 16:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 16:18:15 --> Final output sent to browser
DEBUG - 2025-05-05 16:18:15 --> Total execution time: 0.1173
INFO - 2025-05-05 08:18:16 --> Config Class Initialized
INFO - 2025-05-05 08:18:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 08:18:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 08:18:16 --> Utf8 Class Initialized
INFO - 2025-05-05 08:18:16 --> URI Class Initialized
INFO - 2025-05-05 08:18:16 --> Router Class Initialized
INFO - 2025-05-05 08:18:16 --> Output Class Initialized
INFO - 2025-05-05 08:18:16 --> Security Class Initialized
DEBUG - 2025-05-05 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 08:18:16 --> Input Class Initialized
INFO - 2025-05-05 08:18:16 --> Language Class Initialized
INFO - 2025-05-05 08:18:16 --> Loader Class Initialized
INFO - 2025-05-05 08:18:16 --> Helper loaded: url_helper
INFO - 2025-05-05 08:18:16 --> Helper loaded: string_helper
INFO - 2025-05-05 08:18:16 --> Helper loaded: form_helper
INFO - 2025-05-05 08:18:16 --> Helper loaded: file_helper
INFO - 2025-05-05 08:18:16 --> Helper loaded: html_helper
INFO - 2025-05-05 08:18:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 08:18:16 --> Controller Class Initialized
INFO - 2025-05-05 08:18:17 --> Config Class Initialized
INFO - 2025-05-05 08:18:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 08:18:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 08:18:17 --> Utf8 Class Initialized
INFO - 2025-05-05 08:18:17 --> URI Class Initialized
INFO - 2025-05-05 08:18:17 --> Router Class Initialized
INFO - 2025-05-05 08:18:17 --> Output Class Initialized
INFO - 2025-05-05 08:18:17 --> Security Class Initialized
DEBUG - 2025-05-05 08:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 08:18:17 --> Input Class Initialized
INFO - 2025-05-05 08:18:17 --> Language Class Initialized
INFO - 2025-05-05 08:18:17 --> Loader Class Initialized
INFO - 2025-05-05 08:18:17 --> Helper loaded: url_helper
INFO - 2025-05-05 08:18:17 --> Helper loaded: string_helper
INFO - 2025-05-05 08:18:17 --> Helper loaded: form_helper
INFO - 2025-05-05 08:18:17 --> Helper loaded: file_helper
INFO - 2025-05-05 08:18:17 --> Helper loaded: html_helper
INFO - 2025-05-05 08:18:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 08:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 08:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 08:18:17 --> Controller Class Initialized
INFO - 2025-05-05 16:18:17 --> Model "CompanyModel" initialized
INFO - 2025-05-05 16:18:17 --> Final output sent to browser
DEBUG - 2025-05-05 16:18:17 --> Total execution time: 0.1137
INFO - 2025-05-05 21:32:07 --> Config Class Initialized
INFO - 2025-05-05 21:32:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:07 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:07 --> URI Class Initialized
INFO - 2025-05-05 21:32:07 --> Router Class Initialized
INFO - 2025-05-05 21:32:07 --> Output Class Initialized
INFO - 2025-05-05 21:32:07 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:07 --> Input Class Initialized
INFO - 2025-05-05 21:32:07 --> Language Class Initialized
INFO - 2025-05-05 21:32:07 --> Loader Class Initialized
INFO - 2025-05-05 21:32:07 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:08 --> Controller Class Initialized
INFO - 2025-05-05 21:32:08 --> Config Class Initialized
INFO - 2025-05-05 21:32:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:08 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:08 --> URI Class Initialized
DEBUG - 2025-05-05 21:32:08 --> No URI present. Default controller set.
INFO - 2025-05-05 21:32:08 --> Router Class Initialized
INFO - 2025-05-05 21:32:08 --> Output Class Initialized
INFO - 2025-05-05 21:32:08 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:08 --> Input Class Initialized
INFO - 2025-05-05 21:32:08 --> Language Class Initialized
INFO - 2025-05-05 21:32:08 --> Loader Class Initialized
INFO - 2025-05-05 21:32:08 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:08 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:08 --> Controller Class Initialized
INFO - 2025-05-05 21:32:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:32:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:32:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 21:32:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:32:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:32:09 --> Final output sent to browser
DEBUG - 2025-05-05 21:32:09 --> Total execution time: 0.7315
INFO - 2025-05-05 21:32:11 --> Config Class Initialized
INFO - 2025-05-05 21:32:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:11 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:11 --> URI Class Initialized
INFO - 2025-05-05 21:32:11 --> Router Class Initialized
INFO - 2025-05-05 21:32:11 --> Output Class Initialized
INFO - 2025-05-05 21:32:11 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:11 --> Input Class Initialized
INFO - 2025-05-05 21:32:11 --> Language Class Initialized
INFO - 2025-05-05 21:32:11 --> Loader Class Initialized
INFO - 2025-05-05 21:32:11 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:11 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:11 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:11 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:11 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:12 --> Controller Class Initialized
INFO - 2025-05-05 21:32:22 --> Config Class Initialized
INFO - 2025-05-05 21:32:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:22 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:22 --> URI Class Initialized
INFO - 2025-05-05 21:32:22 --> Router Class Initialized
INFO - 2025-05-05 21:32:22 --> Output Class Initialized
INFO - 2025-05-05 21:32:22 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:22 --> Input Class Initialized
INFO - 2025-05-05 21:32:22 --> Language Class Initialized
INFO - 2025-05-05 21:32:22 --> Loader Class Initialized
INFO - 2025-05-05 21:32:22 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:22 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:22 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:22 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:22 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:23 --> Controller Class Initialized
INFO - 2025-05-05 21:32:23 --> Config Class Initialized
INFO - 2025-05-05 21:32:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:23 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:23 --> URI Class Initialized
DEBUG - 2025-05-05 21:32:23 --> No URI present. Default controller set.
INFO - 2025-05-05 21:32:23 --> Router Class Initialized
INFO - 2025-05-05 21:32:23 --> Output Class Initialized
INFO - 2025-05-05 21:32:23 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:23 --> Input Class Initialized
INFO - 2025-05-05 21:32:23 --> Language Class Initialized
INFO - 2025-05-05 21:32:23 --> Loader Class Initialized
INFO - 2025-05-05 21:32:23 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:23 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:23 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:23 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:23 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:23 --> Controller Class Initialized
INFO - 2025-05-05 21:32:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:32:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:32:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 21:32:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:32:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:32:23 --> Final output sent to browser
DEBUG - 2025-05-05 21:32:23 --> Total execution time: 0.1561
INFO - 2025-05-05 21:32:25 --> Config Class Initialized
INFO - 2025-05-05 21:32:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:25 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:25 --> URI Class Initialized
INFO - 2025-05-05 21:32:25 --> Router Class Initialized
INFO - 2025-05-05 21:32:25 --> Output Class Initialized
INFO - 2025-05-05 21:32:25 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:25 --> Input Class Initialized
INFO - 2025-05-05 21:32:25 --> Language Class Initialized
INFO - 2025-05-05 21:32:25 --> Loader Class Initialized
INFO - 2025-05-05 21:32:25 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:25 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:25 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:25 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:25 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:25 --> Controller Class Initialized
INFO - 2025-05-05 21:32:36 --> Config Class Initialized
INFO - 2025-05-05 21:32:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:36 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:36 --> URI Class Initialized
INFO - 2025-05-05 21:32:37 --> Router Class Initialized
INFO - 2025-05-05 21:32:37 --> Output Class Initialized
INFO - 2025-05-05 21:32:37 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:37 --> Input Class Initialized
INFO - 2025-05-05 21:32:37 --> Language Class Initialized
INFO - 2025-05-05 21:32:37 --> Loader Class Initialized
INFO - 2025-05-05 21:32:37 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:37 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:37 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:37 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:37 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:37 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:37 --> Controller Class Initialized
INFO - 2025-05-05 21:32:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:32:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:32:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-05 21:32:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:32:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:32:38 --> Final output sent to browser
DEBUG - 2025-05-05 21:32:38 --> Total execution time: 1.1357
INFO - 2025-05-05 21:32:48 --> Config Class Initialized
INFO - 2025-05-05 21:32:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:48 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:48 --> Config Class Initialized
INFO - 2025-05-05 21:32:48 --> Hooks Class Initialized
INFO - 2025-05-05 21:32:48 --> URI Class Initialized
DEBUG - 2025-05-05 21:32:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:48 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:48 --> URI Class Initialized
INFO - 2025-05-05 21:32:48 --> Router Class Initialized
INFO - 2025-05-05 21:32:48 --> Router Class Initialized
INFO - 2025-05-05 21:32:48 --> Output Class Initialized
INFO - 2025-05-05 21:32:48 --> Output Class Initialized
INFO - 2025-05-05 21:32:48 --> Security Class Initialized
INFO - 2025-05-05 21:32:48 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:48 --> Input Class Initialized
DEBUG - 2025-05-05 21:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:48 --> Input Class Initialized
INFO - 2025-05-05 21:32:48 --> Language Class Initialized
INFO - 2025-05-05 21:32:48 --> Language Class Initialized
INFO - 2025-05-05 21:32:48 --> Loader Class Initialized
INFO - 2025-05-05 21:32:48 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:48 --> Loader Class Initialized
INFO - 2025-05-05 21:32:48 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:48 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:48 --> Controller Class Initialized
INFO - 2025-05-05 21:32:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:48 --> Controller Class Initialized
INFO - 2025-05-05 21:32:49 --> Config Class Initialized
INFO - 2025-05-05 21:32:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:49 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:49 --> URI Class Initialized
INFO - 2025-05-05 21:32:49 --> Router Class Initialized
INFO - 2025-05-05 21:32:49 --> Output Class Initialized
INFO - 2025-05-05 21:32:49 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:49 --> Input Class Initialized
INFO - 2025-05-05 21:32:49 --> Language Class Initialized
INFO - 2025-05-05 21:32:49 --> Loader Class Initialized
INFO - 2025-05-05 21:32:49 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:49 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:49 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:49 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:49 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:49 --> Controller Class Initialized
INFO - 2025-05-05 21:32:49 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:32:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:32:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:32:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:32:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:32:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:32:49 --> Final output sent to browser
DEBUG - 2025-05-05 21:32:49 --> Total execution time: 0.1929
INFO - 2025-05-05 21:32:50 --> Config Class Initialized
INFO - 2025-05-05 21:32:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:32:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:32:50 --> Utf8 Class Initialized
INFO - 2025-05-05 21:32:50 --> URI Class Initialized
INFO - 2025-05-05 21:32:50 --> Router Class Initialized
INFO - 2025-05-05 21:32:50 --> Output Class Initialized
INFO - 2025-05-05 21:32:50 --> Security Class Initialized
DEBUG - 2025-05-05 21:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:32:50 --> Input Class Initialized
INFO - 2025-05-05 21:32:50 --> Language Class Initialized
INFO - 2025-05-05 21:32:50 --> Loader Class Initialized
INFO - 2025-05-05 21:32:50 --> Helper loaded: url_helper
INFO - 2025-05-05 21:32:50 --> Helper loaded: string_helper
INFO - 2025-05-05 21:32:50 --> Helper loaded: form_helper
INFO - 2025-05-05 21:32:50 --> Helper loaded: file_helper
INFO - 2025-05-05 21:32:50 --> Helper loaded: html_helper
INFO - 2025-05-05 21:32:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:32:50 --> Controller Class Initialized
INFO - 2025-05-05 21:46:46 --> Config Class Initialized
INFO - 2025-05-05 21:46:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:46:46 --> Utf8 Class Initialized
INFO - 2025-05-05 21:46:46 --> URI Class Initialized
INFO - 2025-05-05 21:46:46 --> Router Class Initialized
INFO - 2025-05-05 21:46:46 --> Output Class Initialized
INFO - 2025-05-05 21:46:46 --> Security Class Initialized
DEBUG - 2025-05-05 21:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:46:46 --> Input Class Initialized
INFO - 2025-05-05 21:46:46 --> Language Class Initialized
INFO - 2025-05-05 21:46:46 --> Loader Class Initialized
INFO - 2025-05-05 21:46:46 --> Helper loaded: url_helper
INFO - 2025-05-05 21:46:46 --> Helper loaded: string_helper
INFO - 2025-05-05 21:46:46 --> Helper loaded: form_helper
INFO - 2025-05-05 21:46:46 --> Helper loaded: file_helper
INFO - 2025-05-05 21:46:46 --> Helper loaded: html_helper
INFO - 2025-05-05 21:46:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:46:46 --> Controller Class Initialized
INFO - 2025-05-05 21:46:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:46:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:46:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:46:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:46:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:46:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:46:46 --> Final output sent to browser
DEBUG - 2025-05-05 21:46:46 --> Total execution time: 0.1619
INFO - 2025-05-05 21:46:47 --> Config Class Initialized
INFO - 2025-05-05 21:46:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:46:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:46:47 --> Utf8 Class Initialized
INFO - 2025-05-05 21:46:47 --> URI Class Initialized
INFO - 2025-05-05 21:46:47 --> Router Class Initialized
INFO - 2025-05-05 21:46:47 --> Output Class Initialized
INFO - 2025-05-05 21:46:47 --> Security Class Initialized
DEBUG - 2025-05-05 21:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:46:47 --> Input Class Initialized
INFO - 2025-05-05 21:46:47 --> Language Class Initialized
INFO - 2025-05-05 21:46:47 --> Loader Class Initialized
INFO - 2025-05-05 21:46:47 --> Helper loaded: url_helper
INFO - 2025-05-05 21:46:47 --> Helper loaded: string_helper
INFO - 2025-05-05 21:46:47 --> Helper loaded: form_helper
INFO - 2025-05-05 21:46:47 --> Helper loaded: file_helper
INFO - 2025-05-05 21:46:47 --> Helper loaded: html_helper
INFO - 2025-05-05 21:46:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:46:47 --> Controller Class Initialized
INFO - 2025-05-05 21:50:27 --> Config Class Initialized
INFO - 2025-05-05 21:50:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:50:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:50:27 --> Utf8 Class Initialized
INFO - 2025-05-05 21:50:27 --> URI Class Initialized
INFO - 2025-05-05 21:50:27 --> Router Class Initialized
INFO - 2025-05-05 21:50:27 --> Output Class Initialized
INFO - 2025-05-05 21:50:27 --> Security Class Initialized
DEBUG - 2025-05-05 21:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:50:27 --> Input Class Initialized
INFO - 2025-05-05 21:50:27 --> Language Class Initialized
INFO - 2025-05-05 21:50:27 --> Loader Class Initialized
INFO - 2025-05-05 21:50:27 --> Helper loaded: url_helper
INFO - 2025-05-05 21:50:27 --> Helper loaded: string_helper
INFO - 2025-05-05 21:50:27 --> Helper loaded: form_helper
INFO - 2025-05-05 21:50:27 --> Helper loaded: file_helper
INFO - 2025-05-05 21:50:27 --> Helper loaded: html_helper
INFO - 2025-05-05 21:50:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:50:27 --> Controller Class Initialized
INFO - 2025-05-05 21:50:27 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:50:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:50:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:50:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:50:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:50:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:50:27 --> Final output sent to browser
DEBUG - 2025-05-05 21:50:27 --> Total execution time: 0.0651
INFO - 2025-05-05 21:50:32 --> Config Class Initialized
INFO - 2025-05-05 21:50:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:50:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:50:32 --> Utf8 Class Initialized
INFO - 2025-05-05 21:50:32 --> URI Class Initialized
INFO - 2025-05-05 21:50:32 --> Router Class Initialized
INFO - 2025-05-05 21:50:32 --> Output Class Initialized
INFO - 2025-05-05 21:50:32 --> Security Class Initialized
DEBUG - 2025-05-05 21:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:50:32 --> Input Class Initialized
INFO - 2025-05-05 21:50:32 --> Language Class Initialized
INFO - 2025-05-05 21:50:32 --> Loader Class Initialized
INFO - 2025-05-05 21:50:32 --> Helper loaded: url_helper
INFO - 2025-05-05 21:50:32 --> Helper loaded: string_helper
INFO - 2025-05-05 21:50:32 --> Helper loaded: form_helper
INFO - 2025-05-05 21:50:32 --> Helper loaded: file_helper
INFO - 2025-05-05 21:50:32 --> Helper loaded: html_helper
INFO - 2025-05-05 21:50:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:50:32 --> Controller Class Initialized
INFO - 2025-05-05 21:50:59 --> Config Class Initialized
INFO - 2025-05-05 21:50:59 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:50:59 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:50:59 --> Utf8 Class Initialized
INFO - 2025-05-05 21:50:59 --> URI Class Initialized
INFO - 2025-05-05 21:50:59 --> Router Class Initialized
INFO - 2025-05-05 21:50:59 --> Output Class Initialized
INFO - 2025-05-05 21:50:59 --> Security Class Initialized
DEBUG - 2025-05-05 21:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:50:59 --> Input Class Initialized
INFO - 2025-05-05 21:50:59 --> Language Class Initialized
INFO - 2025-05-05 21:50:59 --> Loader Class Initialized
INFO - 2025-05-05 21:50:59 --> Helper loaded: url_helper
INFO - 2025-05-05 21:50:59 --> Helper loaded: string_helper
INFO - 2025-05-05 21:50:59 --> Helper loaded: form_helper
INFO - 2025-05-05 21:50:59 --> Helper loaded: file_helper
INFO - 2025-05-05 21:50:59 --> Helper loaded: html_helper
INFO - 2025-05-05 21:50:59 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:50:59 --> Controller Class Initialized
INFO - 2025-05-05 21:51:01 --> Config Class Initialized
INFO - 2025-05-05 21:51:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:51:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:51:01 --> Utf8 Class Initialized
INFO - 2025-05-05 21:51:01 --> URI Class Initialized
INFO - 2025-05-05 21:51:01 --> Router Class Initialized
INFO - 2025-05-05 21:51:01 --> Output Class Initialized
INFO - 2025-05-05 21:51:01 --> Security Class Initialized
DEBUG - 2025-05-05 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:51:01 --> Input Class Initialized
INFO - 2025-05-05 21:51:01 --> Language Class Initialized
INFO - 2025-05-05 21:51:01 --> Loader Class Initialized
INFO - 2025-05-05 21:51:01 --> Helper loaded: url_helper
INFO - 2025-05-05 21:51:01 --> Helper loaded: string_helper
INFO - 2025-05-05 21:51:01 --> Helper loaded: form_helper
INFO - 2025-05-05 21:51:01 --> Helper loaded: file_helper
INFO - 2025-05-05 21:51:01 --> Helper loaded: html_helper
INFO - 2025-05-05 21:51:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:51:01 --> Controller Class Initialized
INFO - 2025-05-05 21:51:04 --> Config Class Initialized
INFO - 2025-05-05 21:51:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:51:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:51:04 --> Utf8 Class Initialized
INFO - 2025-05-05 21:51:04 --> URI Class Initialized
INFO - 2025-05-05 21:51:04 --> Router Class Initialized
INFO - 2025-05-05 21:51:04 --> Output Class Initialized
INFO - 2025-05-05 21:51:04 --> Security Class Initialized
DEBUG - 2025-05-05 21:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:51:04 --> Input Class Initialized
INFO - 2025-05-05 21:51:04 --> Language Class Initialized
INFO - 2025-05-05 21:51:04 --> Loader Class Initialized
INFO - 2025-05-05 21:51:04 --> Helper loaded: url_helper
INFO - 2025-05-05 21:51:04 --> Helper loaded: string_helper
INFO - 2025-05-05 21:51:04 --> Helper loaded: form_helper
INFO - 2025-05-05 21:51:04 --> Helper loaded: file_helper
INFO - 2025-05-05 21:51:04 --> Helper loaded: html_helper
INFO - 2025-05-05 21:51:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:51:04 --> Controller Class Initialized
INFO - 2025-05-05 21:51:53 --> Config Class Initialized
INFO - 2025-05-05 21:51:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:51:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:51:53 --> Utf8 Class Initialized
INFO - 2025-05-05 21:51:53 --> URI Class Initialized
INFO - 2025-05-05 21:51:53 --> Router Class Initialized
INFO - 2025-05-05 21:51:53 --> Output Class Initialized
INFO - 2025-05-05 21:51:53 --> Security Class Initialized
DEBUG - 2025-05-05 21:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:51:53 --> Input Class Initialized
INFO - 2025-05-05 21:51:53 --> Language Class Initialized
INFO - 2025-05-05 21:51:53 --> Loader Class Initialized
INFO - 2025-05-05 21:51:53 --> Helper loaded: url_helper
INFO - 2025-05-05 21:51:53 --> Helper loaded: string_helper
INFO - 2025-05-05 21:51:53 --> Helper loaded: form_helper
INFO - 2025-05-05 21:51:53 --> Helper loaded: file_helper
INFO - 2025-05-05 21:51:53 --> Helper loaded: html_helper
INFO - 2025-05-05 21:51:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:51:53 --> Controller Class Initialized
INFO - 2025-05-05 21:51:53 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:51:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:51:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:51:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:51:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:51:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:51:53 --> Final output sent to browser
DEBUG - 2025-05-05 21:51:53 --> Total execution time: 0.1590
INFO - 2025-05-05 21:51:56 --> Config Class Initialized
INFO - 2025-05-05 21:51:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:51:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:51:56 --> Utf8 Class Initialized
INFO - 2025-05-05 21:51:56 --> URI Class Initialized
INFO - 2025-05-05 21:51:56 --> Router Class Initialized
INFO - 2025-05-05 21:51:56 --> Output Class Initialized
INFO - 2025-05-05 21:51:56 --> Security Class Initialized
DEBUG - 2025-05-05 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:51:56 --> Input Class Initialized
INFO - 2025-05-05 21:51:56 --> Language Class Initialized
INFO - 2025-05-05 21:51:56 --> Loader Class Initialized
INFO - 2025-05-05 21:51:56 --> Helper loaded: url_helper
INFO - 2025-05-05 21:51:56 --> Helper loaded: string_helper
INFO - 2025-05-05 21:51:56 --> Helper loaded: form_helper
INFO - 2025-05-05 21:51:56 --> Helper loaded: file_helper
INFO - 2025-05-05 21:51:56 --> Helper loaded: html_helper
INFO - 2025-05-05 21:51:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:51:56 --> Controller Class Initialized
INFO - 2025-05-05 21:52:03 --> Config Class Initialized
INFO - 2025-05-05 21:52:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:52:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:52:03 --> Utf8 Class Initialized
INFO - 2025-05-05 21:52:03 --> URI Class Initialized
INFO - 2025-05-05 21:52:03 --> Router Class Initialized
INFO - 2025-05-05 21:52:03 --> Output Class Initialized
INFO - 2025-05-05 21:52:03 --> Security Class Initialized
DEBUG - 2025-05-05 21:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:52:03 --> Input Class Initialized
INFO - 2025-05-05 21:52:03 --> Language Class Initialized
INFO - 2025-05-05 21:52:03 --> Loader Class Initialized
INFO - 2025-05-05 21:52:03 --> Helper loaded: url_helper
INFO - 2025-05-05 21:52:03 --> Helper loaded: string_helper
INFO - 2025-05-05 21:52:03 --> Helper loaded: form_helper
INFO - 2025-05-05 21:52:03 --> Helper loaded: file_helper
INFO - 2025-05-05 21:52:03 --> Helper loaded: html_helper
INFO - 2025-05-05 21:52:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:52:03 --> Controller Class Initialized
INFO - 2025-05-05 21:52:05 --> Config Class Initialized
INFO - 2025-05-05 21:52:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:52:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:52:05 --> Utf8 Class Initialized
INFO - 2025-05-05 21:52:05 --> URI Class Initialized
INFO - 2025-05-05 21:52:05 --> Router Class Initialized
INFO - 2025-05-05 21:52:05 --> Output Class Initialized
INFO - 2025-05-05 21:52:05 --> Security Class Initialized
DEBUG - 2025-05-05 21:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:52:05 --> Input Class Initialized
INFO - 2025-05-05 21:52:05 --> Language Class Initialized
INFO - 2025-05-05 21:52:05 --> Loader Class Initialized
INFO - 2025-05-05 21:52:05 --> Helper loaded: url_helper
INFO - 2025-05-05 21:52:05 --> Helper loaded: string_helper
INFO - 2025-05-05 21:52:05 --> Helper loaded: form_helper
INFO - 2025-05-05 21:52:05 --> Helper loaded: file_helper
INFO - 2025-05-05 21:52:05 --> Helper loaded: html_helper
INFO - 2025-05-05 21:52:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:52:05 --> Controller Class Initialized
INFO - 2025-05-05 21:52:13 --> Config Class Initialized
INFO - 2025-05-05 21:52:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:52:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:52:13 --> Utf8 Class Initialized
INFO - 2025-05-05 21:52:13 --> URI Class Initialized
INFO - 2025-05-05 21:52:14 --> Router Class Initialized
INFO - 2025-05-05 21:52:14 --> Output Class Initialized
INFO - 2025-05-05 21:52:14 --> Security Class Initialized
DEBUG - 2025-05-05 21:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:52:14 --> Input Class Initialized
INFO - 2025-05-05 21:52:14 --> Language Class Initialized
INFO - 2025-05-05 21:52:14 --> Loader Class Initialized
INFO - 2025-05-05 21:52:14 --> Helper loaded: url_helper
INFO - 2025-05-05 21:52:14 --> Helper loaded: string_helper
INFO - 2025-05-05 21:52:14 --> Helper loaded: form_helper
INFO - 2025-05-05 21:52:14 --> Helper loaded: file_helper
INFO - 2025-05-05 21:52:14 --> Helper loaded: html_helper
INFO - 2025-05-05 21:52:14 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:52:14 --> Controller Class Initialized
INFO - 2025-05-05 21:52:40 --> Config Class Initialized
INFO - 2025-05-05 21:52:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:52:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:52:40 --> Utf8 Class Initialized
INFO - 2025-05-05 21:52:40 --> URI Class Initialized
INFO - 2025-05-05 21:52:40 --> Router Class Initialized
INFO - 2025-05-05 21:52:40 --> Output Class Initialized
INFO - 2025-05-05 21:52:40 --> Security Class Initialized
DEBUG - 2025-05-05 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:52:40 --> Input Class Initialized
INFO - 2025-05-05 21:52:40 --> Language Class Initialized
INFO - 2025-05-05 21:52:40 --> Loader Class Initialized
INFO - 2025-05-05 21:52:40 --> Helper loaded: url_helper
INFO - 2025-05-05 21:52:40 --> Helper loaded: string_helper
INFO - 2025-05-05 21:52:40 --> Helper loaded: form_helper
INFO - 2025-05-05 21:52:40 --> Helper loaded: file_helper
INFO - 2025-05-05 21:52:40 --> Helper loaded: html_helper
INFO - 2025-05-05 21:52:40 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:52:40 --> Controller Class Initialized
INFO - 2025-05-05 21:54:08 --> Config Class Initialized
INFO - 2025-05-05 21:54:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:54:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:54:08 --> Utf8 Class Initialized
INFO - 2025-05-05 21:54:08 --> URI Class Initialized
INFO - 2025-05-05 21:54:08 --> Router Class Initialized
INFO - 2025-05-05 21:54:08 --> Output Class Initialized
INFO - 2025-05-05 21:54:08 --> Security Class Initialized
DEBUG - 2025-05-05 21:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:54:08 --> Input Class Initialized
INFO - 2025-05-05 21:54:08 --> Language Class Initialized
INFO - 2025-05-05 21:54:08 --> Loader Class Initialized
INFO - 2025-05-05 21:54:08 --> Helper loaded: url_helper
INFO - 2025-05-05 21:54:08 --> Helper loaded: string_helper
INFO - 2025-05-05 21:54:08 --> Helper loaded: form_helper
INFO - 2025-05-05 21:54:08 --> Helper loaded: file_helper
INFO - 2025-05-05 21:54:08 --> Helper loaded: html_helper
INFO - 2025-05-05 21:54:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:54:08 --> Controller Class Initialized
INFO - 2025-05-05 21:54:08 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:54:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:54:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:54:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:54:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:54:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:54:08 --> Final output sent to browser
DEBUG - 2025-05-05 21:54:08 --> Total execution time: 0.1328
INFO - 2025-05-05 21:54:10 --> Config Class Initialized
INFO - 2025-05-05 21:54:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:54:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:54:10 --> Utf8 Class Initialized
INFO - 2025-05-05 21:54:10 --> URI Class Initialized
INFO - 2025-05-05 21:54:10 --> Router Class Initialized
INFO - 2025-05-05 21:54:10 --> Output Class Initialized
INFO - 2025-05-05 21:54:10 --> Security Class Initialized
DEBUG - 2025-05-05 21:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:54:10 --> Input Class Initialized
INFO - 2025-05-05 21:54:10 --> Language Class Initialized
INFO - 2025-05-05 21:54:10 --> Loader Class Initialized
INFO - 2025-05-05 21:54:10 --> Helper loaded: url_helper
INFO - 2025-05-05 21:54:10 --> Helper loaded: string_helper
INFO - 2025-05-05 21:54:10 --> Helper loaded: form_helper
INFO - 2025-05-05 21:54:10 --> Helper loaded: file_helper
INFO - 2025-05-05 21:54:10 --> Helper loaded: html_helper
INFO - 2025-05-05 21:54:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:54:10 --> Controller Class Initialized
INFO - 2025-05-05 21:55:37 --> Config Class Initialized
INFO - 2025-05-05 21:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:55:37 --> Utf8 Class Initialized
INFO - 2025-05-05 21:55:37 --> URI Class Initialized
INFO - 2025-05-05 21:55:37 --> Router Class Initialized
INFO - 2025-05-05 21:55:37 --> Output Class Initialized
INFO - 2025-05-05 21:55:37 --> Security Class Initialized
DEBUG - 2025-05-05 21:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:55:37 --> Input Class Initialized
INFO - 2025-05-05 21:55:37 --> Language Class Initialized
INFO - 2025-05-05 21:55:37 --> Loader Class Initialized
INFO - 2025-05-05 21:55:37 --> Helper loaded: url_helper
INFO - 2025-05-05 21:55:37 --> Helper loaded: string_helper
INFO - 2025-05-05 21:55:37 --> Helper loaded: form_helper
INFO - 2025-05-05 21:55:37 --> Helper loaded: file_helper
INFO - 2025-05-05 21:55:37 --> Helper loaded: html_helper
INFO - 2025-05-05 21:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:55:37 --> Controller Class Initialized
INFO - 2025-05-05 21:55:37 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:55:37 --> Final output sent to browser
DEBUG - 2025-05-05 21:55:37 --> Total execution time: 0.1311
INFO - 2025-05-05 21:55:40 --> Config Class Initialized
INFO - 2025-05-05 21:55:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:55:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:55:41 --> Utf8 Class Initialized
INFO - 2025-05-05 21:55:41 --> URI Class Initialized
INFO - 2025-05-05 21:55:41 --> Router Class Initialized
INFO - 2025-05-05 21:55:41 --> Output Class Initialized
INFO - 2025-05-05 21:55:41 --> Security Class Initialized
DEBUG - 2025-05-05 21:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:55:41 --> Input Class Initialized
INFO - 2025-05-05 21:55:41 --> Language Class Initialized
INFO - 2025-05-05 21:55:41 --> Loader Class Initialized
INFO - 2025-05-05 21:55:41 --> Helper loaded: url_helper
INFO - 2025-05-05 21:55:41 --> Helper loaded: string_helper
INFO - 2025-05-05 21:55:41 --> Helper loaded: form_helper
INFO - 2025-05-05 21:55:41 --> Helper loaded: file_helper
INFO - 2025-05-05 21:55:41 --> Helper loaded: html_helper
INFO - 2025-05-05 21:55:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:55:41 --> Controller Class Initialized
INFO - 2025-05-05 21:55:50 --> Config Class Initialized
INFO - 2025-05-05 21:55:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:55:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:55:50 --> Utf8 Class Initialized
INFO - 2025-05-05 21:55:50 --> URI Class Initialized
INFO - 2025-05-05 21:55:50 --> Router Class Initialized
INFO - 2025-05-05 21:55:50 --> Output Class Initialized
INFO - 2025-05-05 21:55:50 --> Security Class Initialized
DEBUG - 2025-05-05 21:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:55:50 --> Input Class Initialized
INFO - 2025-05-05 21:55:50 --> Language Class Initialized
INFO - 2025-05-05 21:55:50 --> Loader Class Initialized
INFO - 2025-05-05 21:55:50 --> Helper loaded: url_helper
INFO - 2025-05-05 21:55:50 --> Helper loaded: string_helper
INFO - 2025-05-05 21:55:50 --> Helper loaded: form_helper
INFO - 2025-05-05 21:55:50 --> Helper loaded: file_helper
INFO - 2025-05-05 21:55:50 --> Helper loaded: html_helper
INFO - 2025-05-05 21:55:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:55:50 --> Controller Class Initialized
INFO - 2025-05-05 21:57:44 --> Config Class Initialized
INFO - 2025-05-05 21:57:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:57:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:57:44 --> Utf8 Class Initialized
INFO - 2025-05-05 21:57:44 --> URI Class Initialized
INFO - 2025-05-05 21:57:44 --> Router Class Initialized
INFO - 2025-05-05 21:57:44 --> Output Class Initialized
INFO - 2025-05-05 21:57:44 --> Security Class Initialized
DEBUG - 2025-05-05 21:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:57:44 --> Input Class Initialized
INFO - 2025-05-05 21:57:44 --> Language Class Initialized
INFO - 2025-05-05 21:57:44 --> Loader Class Initialized
INFO - 2025-05-05 21:57:44 --> Helper loaded: url_helper
INFO - 2025-05-05 21:57:44 --> Helper loaded: string_helper
INFO - 2025-05-05 21:57:44 --> Helper loaded: form_helper
INFO - 2025-05-05 21:57:44 --> Helper loaded: file_helper
INFO - 2025-05-05 21:57:44 --> Helper loaded: html_helper
INFO - 2025-05-05 21:57:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:57:44 --> Controller Class Initialized
INFO - 2025-05-05 21:57:48 --> Config Class Initialized
INFO - 2025-05-05 21:57:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:57:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:57:48 --> Utf8 Class Initialized
INFO - 2025-05-05 21:57:48 --> URI Class Initialized
INFO - 2025-05-05 21:57:48 --> Router Class Initialized
INFO - 2025-05-05 21:57:48 --> Output Class Initialized
INFO - 2025-05-05 21:57:48 --> Security Class Initialized
DEBUG - 2025-05-05 21:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:57:48 --> Input Class Initialized
INFO - 2025-05-05 21:57:48 --> Language Class Initialized
INFO - 2025-05-05 21:57:48 --> Loader Class Initialized
INFO - 2025-05-05 21:57:48 --> Helper loaded: url_helper
INFO - 2025-05-05 21:57:48 --> Helper loaded: string_helper
INFO - 2025-05-05 21:57:48 --> Helper loaded: form_helper
INFO - 2025-05-05 21:57:48 --> Helper loaded: file_helper
INFO - 2025-05-05 21:57:48 --> Helper loaded: html_helper
INFO - 2025-05-05 21:57:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:57:48 --> Controller Class Initialized
INFO - 2025-05-05 21:57:52 --> Config Class Initialized
INFO - 2025-05-05 21:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:57:52 --> Utf8 Class Initialized
INFO - 2025-05-05 21:57:52 --> URI Class Initialized
INFO - 2025-05-05 21:57:52 --> Router Class Initialized
INFO - 2025-05-05 21:57:52 --> Output Class Initialized
INFO - 2025-05-05 21:57:52 --> Security Class Initialized
DEBUG - 2025-05-05 21:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:57:52 --> Input Class Initialized
INFO - 2025-05-05 21:57:52 --> Language Class Initialized
INFO - 2025-05-05 21:57:52 --> Loader Class Initialized
INFO - 2025-05-05 21:57:52 --> Helper loaded: url_helper
INFO - 2025-05-05 21:57:52 --> Helper loaded: string_helper
INFO - 2025-05-05 21:57:52 --> Helper loaded: form_helper
INFO - 2025-05-05 21:57:52 --> Helper loaded: file_helper
INFO - 2025-05-05 21:57:52 --> Helper loaded: html_helper
INFO - 2025-05-05 21:57:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:57:52 --> Controller Class Initialized
INFO - 2025-05-05 21:57:52 --> Config Class Initialized
INFO - 2025-05-05 21:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:57:52 --> Utf8 Class Initialized
INFO - 2025-05-05 21:57:52 --> URI Class Initialized
INFO - 2025-05-05 21:57:53 --> Router Class Initialized
INFO - 2025-05-05 21:57:53 --> Output Class Initialized
INFO - 2025-05-05 21:57:53 --> Security Class Initialized
DEBUG - 2025-05-05 21:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:57:53 --> Input Class Initialized
INFO - 2025-05-05 21:57:53 --> Language Class Initialized
INFO - 2025-05-05 21:57:53 --> Loader Class Initialized
INFO - 2025-05-05 21:57:53 --> Helper loaded: url_helper
INFO - 2025-05-05 21:57:53 --> Helper loaded: string_helper
INFO - 2025-05-05 21:57:53 --> Helper loaded: form_helper
INFO - 2025-05-05 21:57:53 --> Helper loaded: file_helper
INFO - 2025-05-05 21:57:53 --> Helper loaded: html_helper
INFO - 2025-05-05 21:57:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:57:53 --> Controller Class Initialized
INFO - 2025-05-05 21:58:35 --> Config Class Initialized
INFO - 2025-05-05 21:58:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:58:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:58:35 --> Utf8 Class Initialized
INFO - 2025-05-05 21:58:35 --> URI Class Initialized
INFO - 2025-05-05 21:58:35 --> Router Class Initialized
INFO - 2025-05-05 21:58:35 --> Output Class Initialized
INFO - 2025-05-05 21:58:35 --> Security Class Initialized
DEBUG - 2025-05-05 21:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:58:35 --> Input Class Initialized
INFO - 2025-05-05 21:58:35 --> Language Class Initialized
INFO - 2025-05-05 21:58:35 --> Loader Class Initialized
INFO - 2025-05-05 21:58:35 --> Helper loaded: url_helper
INFO - 2025-05-05 21:58:35 --> Helper loaded: string_helper
INFO - 2025-05-05 21:58:35 --> Helper loaded: form_helper
INFO - 2025-05-05 21:58:35 --> Helper loaded: file_helper
INFO - 2025-05-05 21:58:35 --> Helper loaded: html_helper
INFO - 2025-05-05 21:58:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:58:35 --> Controller Class Initialized
INFO - 2025-05-05 21:58:35 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:58:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:58:35 --> Final output sent to browser
DEBUG - 2025-05-05 21:58:35 --> Total execution time: 0.1230
INFO - 2025-05-05 21:58:36 --> Config Class Initialized
INFO - 2025-05-05 21:58:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:58:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:58:36 --> Utf8 Class Initialized
INFO - 2025-05-05 21:58:36 --> URI Class Initialized
INFO - 2025-05-05 21:58:36 --> Router Class Initialized
INFO - 2025-05-05 21:58:36 --> Output Class Initialized
INFO - 2025-05-05 21:58:36 --> Security Class Initialized
DEBUG - 2025-05-05 21:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:58:36 --> Input Class Initialized
INFO - 2025-05-05 21:58:36 --> Language Class Initialized
INFO - 2025-05-05 21:58:36 --> Loader Class Initialized
INFO - 2025-05-05 21:58:36 --> Helper loaded: url_helper
INFO - 2025-05-05 21:58:36 --> Helper loaded: string_helper
INFO - 2025-05-05 21:58:36 --> Helper loaded: form_helper
INFO - 2025-05-05 21:58:36 --> Helper loaded: file_helper
INFO - 2025-05-05 21:58:36 --> Helper loaded: html_helper
INFO - 2025-05-05 21:58:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:58:36 --> Controller Class Initialized
INFO - 2025-05-05 21:58:52 --> Config Class Initialized
INFO - 2025-05-05 21:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:58:52 --> Utf8 Class Initialized
INFO - 2025-05-05 21:58:52 --> URI Class Initialized
INFO - 2025-05-05 21:58:52 --> Router Class Initialized
INFO - 2025-05-05 21:58:52 --> Output Class Initialized
INFO - 2025-05-05 21:58:52 --> Security Class Initialized
DEBUG - 2025-05-05 21:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:58:52 --> Input Class Initialized
INFO - 2025-05-05 21:58:52 --> Language Class Initialized
INFO - 2025-05-05 21:58:52 --> Loader Class Initialized
INFO - 2025-05-05 21:58:52 --> Helper loaded: url_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: string_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: form_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: file_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: html_helper
INFO - 2025-05-05 21:58:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:58:52 --> Controller Class Initialized
INFO - 2025-05-05 21:58:52 --> Config Class Initialized
INFO - 2025-05-05 21:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:58:52 --> Utf8 Class Initialized
INFO - 2025-05-05 21:58:52 --> URI Class Initialized
INFO - 2025-05-05 21:58:52 --> Router Class Initialized
INFO - 2025-05-05 21:58:52 --> Output Class Initialized
INFO - 2025-05-05 21:58:52 --> Security Class Initialized
DEBUG - 2025-05-05 21:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:58:52 --> Input Class Initialized
INFO - 2025-05-05 21:58:52 --> Language Class Initialized
INFO - 2025-05-05 21:58:52 --> Loader Class Initialized
INFO - 2025-05-05 21:58:52 --> Helper loaded: url_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: string_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: form_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: file_helper
INFO - 2025-05-05 21:58:52 --> Helper loaded: html_helper
INFO - 2025-05-05 21:58:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:58:52 --> Controller Class Initialized
INFO - 2025-05-05 21:59:47 --> Config Class Initialized
INFO - 2025-05-05 21:59:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:59:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:59:47 --> Utf8 Class Initialized
INFO - 2025-05-05 21:59:47 --> URI Class Initialized
INFO - 2025-05-05 21:59:47 --> Router Class Initialized
INFO - 2025-05-05 21:59:47 --> Output Class Initialized
INFO - 2025-05-05 21:59:47 --> Security Class Initialized
DEBUG - 2025-05-05 21:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:59:47 --> Input Class Initialized
INFO - 2025-05-05 21:59:47 --> Language Class Initialized
INFO - 2025-05-05 21:59:47 --> Loader Class Initialized
INFO - 2025-05-05 21:59:47 --> Helper loaded: url_helper
INFO - 2025-05-05 21:59:47 --> Helper loaded: string_helper
INFO - 2025-05-05 21:59:47 --> Helper loaded: form_helper
INFO - 2025-05-05 21:59:47 --> Helper loaded: file_helper
INFO - 2025-05-05 21:59:47 --> Helper loaded: html_helper
INFO - 2025-05-05 21:59:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:59:47 --> Controller Class Initialized
INFO - 2025-05-05 21:59:47 --> Model "CompanyModel" initialized
INFO - 2025-05-05 21:59:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 21:59:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 21:59:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 21:59:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 21:59:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 21:59:47 --> Final output sent to browser
DEBUG - 2025-05-05 21:59:47 --> Total execution time: 0.1310
INFO - 2025-05-05 21:59:49 --> Config Class Initialized
INFO - 2025-05-05 21:59:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:59:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:59:49 --> Utf8 Class Initialized
INFO - 2025-05-05 21:59:49 --> URI Class Initialized
INFO - 2025-05-05 21:59:49 --> Router Class Initialized
INFO - 2025-05-05 21:59:49 --> Output Class Initialized
INFO - 2025-05-05 21:59:49 --> Security Class Initialized
DEBUG - 2025-05-05 21:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:59:49 --> Input Class Initialized
INFO - 2025-05-05 21:59:49 --> Language Class Initialized
INFO - 2025-05-05 21:59:49 --> Loader Class Initialized
INFO - 2025-05-05 21:59:49 --> Helper loaded: url_helper
INFO - 2025-05-05 21:59:49 --> Helper loaded: string_helper
INFO - 2025-05-05 21:59:49 --> Helper loaded: form_helper
INFO - 2025-05-05 21:59:49 --> Helper loaded: file_helper
INFO - 2025-05-05 21:59:49 --> Helper loaded: html_helper
INFO - 2025-05-05 21:59:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:59:49 --> Controller Class Initialized
INFO - 2025-05-05 21:59:57 --> Config Class Initialized
INFO - 2025-05-05 21:59:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:59:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:59:57 --> Utf8 Class Initialized
INFO - 2025-05-05 21:59:57 --> URI Class Initialized
INFO - 2025-05-05 21:59:57 --> Router Class Initialized
INFO - 2025-05-05 21:59:57 --> Output Class Initialized
INFO - 2025-05-05 21:59:57 --> Security Class Initialized
DEBUG - 2025-05-05 21:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:59:57 --> Input Class Initialized
INFO - 2025-05-05 21:59:57 --> Language Class Initialized
INFO - 2025-05-05 21:59:57 --> Loader Class Initialized
INFO - 2025-05-05 21:59:57 --> Helper loaded: url_helper
INFO - 2025-05-05 21:59:57 --> Helper loaded: string_helper
INFO - 2025-05-05 21:59:57 --> Helper loaded: form_helper
INFO - 2025-05-05 21:59:57 --> Helper loaded: file_helper
INFO - 2025-05-05 21:59:57 --> Helper loaded: html_helper
INFO - 2025-05-05 21:59:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:59:57 --> Controller Class Initialized
INFO - 2025-05-05 21:59:58 --> Config Class Initialized
INFO - 2025-05-05 21:59:58 --> Hooks Class Initialized
DEBUG - 2025-05-05 21:59:58 --> UTF-8 Support Enabled
INFO - 2025-05-05 21:59:58 --> Utf8 Class Initialized
INFO - 2025-05-05 21:59:58 --> URI Class Initialized
INFO - 2025-05-05 21:59:58 --> Router Class Initialized
INFO - 2025-05-05 21:59:58 --> Output Class Initialized
INFO - 2025-05-05 21:59:58 --> Security Class Initialized
DEBUG - 2025-05-05 21:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 21:59:58 --> Input Class Initialized
INFO - 2025-05-05 21:59:58 --> Language Class Initialized
INFO - 2025-05-05 21:59:58 --> Loader Class Initialized
INFO - 2025-05-05 21:59:58 --> Helper loaded: url_helper
INFO - 2025-05-05 21:59:58 --> Helper loaded: string_helper
INFO - 2025-05-05 21:59:58 --> Helper loaded: form_helper
INFO - 2025-05-05 21:59:58 --> Helper loaded: file_helper
INFO - 2025-05-05 21:59:58 --> Helper loaded: html_helper
INFO - 2025-05-05 21:59:58 --> Database Driver Class Initialized
DEBUG - 2025-05-05 21:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 21:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 21:59:58 --> Controller Class Initialized
INFO - 2025-05-05 22:00:34 --> Config Class Initialized
INFO - 2025-05-05 22:00:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:00:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:00:34 --> Utf8 Class Initialized
INFO - 2025-05-05 22:00:34 --> URI Class Initialized
INFO - 2025-05-05 22:00:34 --> Router Class Initialized
INFO - 2025-05-05 22:00:34 --> Output Class Initialized
INFO - 2025-05-05 22:00:34 --> Security Class Initialized
DEBUG - 2025-05-05 22:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:00:34 --> Input Class Initialized
INFO - 2025-05-05 22:00:34 --> Language Class Initialized
INFO - 2025-05-05 22:00:34 --> Loader Class Initialized
INFO - 2025-05-05 22:00:34 --> Helper loaded: url_helper
INFO - 2025-05-05 22:00:34 --> Helper loaded: string_helper
INFO - 2025-05-05 22:00:34 --> Helper loaded: form_helper
INFO - 2025-05-05 22:00:34 --> Helper loaded: file_helper
INFO - 2025-05-05 22:00:34 --> Helper loaded: html_helper
INFO - 2025-05-05 22:00:34 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:00:34 --> Controller Class Initialized
INFO - 2025-05-05 22:00:34 --> Model "CompanyModel" initialized
INFO - 2025-05-05 22:00:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:00:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:00:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 22:00:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:00:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:00:34 --> Final output sent to browser
DEBUG - 2025-05-05 22:00:34 --> Total execution time: 0.1510
INFO - 2025-05-05 22:00:35 --> Config Class Initialized
INFO - 2025-05-05 22:00:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:00:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:00:35 --> Utf8 Class Initialized
INFO - 2025-05-05 22:00:35 --> URI Class Initialized
INFO - 2025-05-05 22:00:35 --> Router Class Initialized
INFO - 2025-05-05 22:00:35 --> Output Class Initialized
INFO - 2025-05-05 22:00:35 --> Security Class Initialized
DEBUG - 2025-05-05 22:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:00:35 --> Input Class Initialized
INFO - 2025-05-05 22:00:35 --> Language Class Initialized
INFO - 2025-05-05 22:00:35 --> Loader Class Initialized
INFO - 2025-05-05 22:00:35 --> Helper loaded: url_helper
INFO - 2025-05-05 22:00:35 --> Helper loaded: string_helper
INFO - 2025-05-05 22:00:35 --> Helper loaded: form_helper
INFO - 2025-05-05 22:00:35 --> Helper loaded: file_helper
INFO - 2025-05-05 22:00:35 --> Helper loaded: html_helper
INFO - 2025-05-05 22:00:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:00:36 --> Controller Class Initialized
INFO - 2025-05-05 22:00:43 --> Config Class Initialized
INFO - 2025-05-05 22:00:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:00:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:00:43 --> Utf8 Class Initialized
INFO - 2025-05-05 22:00:43 --> URI Class Initialized
INFO - 2025-05-05 22:00:43 --> Router Class Initialized
INFO - 2025-05-05 22:00:43 --> Output Class Initialized
INFO - 2025-05-05 22:00:43 --> Security Class Initialized
DEBUG - 2025-05-05 22:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:00:43 --> Input Class Initialized
INFO - 2025-05-05 22:00:43 --> Language Class Initialized
INFO - 2025-05-05 22:00:43 --> Loader Class Initialized
INFO - 2025-05-05 22:00:43 --> Helper loaded: url_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: string_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: form_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: file_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: html_helper
INFO - 2025-05-05 22:00:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:00:43 --> Controller Class Initialized
INFO - 2025-05-05 22:00:43 --> Config Class Initialized
INFO - 2025-05-05 22:00:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:00:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:00:43 --> Utf8 Class Initialized
INFO - 2025-05-05 22:00:43 --> URI Class Initialized
INFO - 2025-05-05 22:00:43 --> Router Class Initialized
INFO - 2025-05-05 22:00:43 --> Output Class Initialized
INFO - 2025-05-05 22:00:43 --> Security Class Initialized
DEBUG - 2025-05-05 22:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:00:43 --> Input Class Initialized
INFO - 2025-05-05 22:00:43 --> Language Class Initialized
INFO - 2025-05-05 22:00:43 --> Loader Class Initialized
INFO - 2025-05-05 22:00:43 --> Helper loaded: url_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: string_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: form_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: file_helper
INFO - 2025-05-05 22:00:43 --> Helper loaded: html_helper
INFO - 2025-05-05 22:00:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:00:43 --> Controller Class Initialized
INFO - 2025-05-05 22:01:50 --> Config Class Initialized
INFO - 2025-05-05 22:01:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:01:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:01:50 --> Utf8 Class Initialized
INFO - 2025-05-05 22:01:50 --> URI Class Initialized
INFO - 2025-05-05 22:01:50 --> Router Class Initialized
INFO - 2025-05-05 22:01:50 --> Output Class Initialized
INFO - 2025-05-05 22:01:50 --> Security Class Initialized
DEBUG - 2025-05-05 22:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:01:50 --> Input Class Initialized
INFO - 2025-05-05 22:01:50 --> Language Class Initialized
INFO - 2025-05-05 22:01:50 --> Loader Class Initialized
INFO - 2025-05-05 22:01:50 --> Helper loaded: url_helper
INFO - 2025-05-05 22:01:50 --> Helper loaded: string_helper
INFO - 2025-05-05 22:01:50 --> Helper loaded: form_helper
INFO - 2025-05-05 22:01:50 --> Helper loaded: file_helper
INFO - 2025-05-05 22:01:50 --> Helper loaded: html_helper
INFO - 2025-05-05 22:01:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:01:50 --> Controller Class Initialized
INFO - 2025-05-05 22:01:50 --> Model "CompanyModel" initialized
INFO - 2025-05-05 22:01:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:01:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:01:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 22:01:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:01:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:01:50 --> Final output sent to browser
DEBUG - 2025-05-05 22:01:50 --> Total execution time: 0.2499
INFO - 2025-05-05 22:01:57 --> Config Class Initialized
INFO - 2025-05-05 22:01:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:01:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:01:57 --> Utf8 Class Initialized
INFO - 2025-05-05 22:01:57 --> URI Class Initialized
INFO - 2025-05-05 22:01:57 --> Router Class Initialized
INFO - 2025-05-05 22:01:57 --> Output Class Initialized
INFO - 2025-05-05 22:01:57 --> Security Class Initialized
DEBUG - 2025-05-05 22:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:01:57 --> Input Class Initialized
INFO - 2025-05-05 22:01:57 --> Language Class Initialized
INFO - 2025-05-05 22:01:57 --> Loader Class Initialized
INFO - 2025-05-05 22:01:57 --> Helper loaded: url_helper
INFO - 2025-05-05 22:01:57 --> Helper loaded: string_helper
INFO - 2025-05-05 22:01:57 --> Helper loaded: form_helper
INFO - 2025-05-05 22:01:57 --> Helper loaded: file_helper
INFO - 2025-05-05 22:01:57 --> Helper loaded: html_helper
INFO - 2025-05-05 22:01:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:01:57 --> Controller Class Initialized
INFO - 2025-05-05 22:09:16 --> Config Class Initialized
INFO - 2025-05-05 22:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:09:16 --> Utf8 Class Initialized
INFO - 2025-05-05 22:09:16 --> URI Class Initialized
INFO - 2025-05-05 22:09:16 --> Router Class Initialized
INFO - 2025-05-05 22:09:16 --> Output Class Initialized
INFO - 2025-05-05 22:09:16 --> Security Class Initialized
DEBUG - 2025-05-05 22:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:09:16 --> Input Class Initialized
INFO - 2025-05-05 22:09:16 --> Language Class Initialized
INFO - 2025-05-05 22:09:16 --> Loader Class Initialized
INFO - 2025-05-05 22:09:16 --> Helper loaded: url_helper
INFO - 2025-05-05 22:09:16 --> Helper loaded: string_helper
INFO - 2025-05-05 22:09:16 --> Helper loaded: form_helper
INFO - 2025-05-05 22:09:16 --> Helper loaded: file_helper
INFO - 2025-05-05 22:09:16 --> Helper loaded: html_helper
INFO - 2025-05-05 22:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:09:16 --> Controller Class Initialized
INFO - 2025-05-05 22:09:16 --> Model "CompanyModel" initialized
INFO - 2025-05-05 22:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 22:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:09:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:09:16 --> Final output sent to browser
DEBUG - 2025-05-05 22:09:16 --> Total execution time: 0.1829
INFO - 2025-05-05 22:09:19 --> Config Class Initialized
INFO - 2025-05-05 22:09:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:09:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:09:19 --> Utf8 Class Initialized
INFO - 2025-05-05 22:09:19 --> URI Class Initialized
INFO - 2025-05-05 22:09:19 --> Router Class Initialized
INFO - 2025-05-05 22:09:19 --> Output Class Initialized
INFO - 2025-05-05 22:09:19 --> Security Class Initialized
DEBUG - 2025-05-05 22:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:09:19 --> Input Class Initialized
INFO - 2025-05-05 22:09:19 --> Language Class Initialized
INFO - 2025-05-05 22:09:19 --> Loader Class Initialized
INFO - 2025-05-05 22:09:19 --> Helper loaded: url_helper
INFO - 2025-05-05 22:09:19 --> Helper loaded: string_helper
INFO - 2025-05-05 22:09:19 --> Helper loaded: form_helper
INFO - 2025-05-05 22:09:19 --> Helper loaded: file_helper
INFO - 2025-05-05 22:09:19 --> Helper loaded: html_helper
INFO - 2025-05-05 22:09:19 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:09:19 --> Controller Class Initialized
INFO - 2025-05-05 22:09:35 --> Config Class Initialized
INFO - 2025-05-05 22:09:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:09:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:09:35 --> Utf8 Class Initialized
INFO - 2025-05-05 22:09:35 --> URI Class Initialized
INFO - 2025-05-05 22:09:35 --> Router Class Initialized
INFO - 2025-05-05 22:09:35 --> Output Class Initialized
INFO - 2025-05-05 22:09:35 --> Security Class Initialized
DEBUG - 2025-05-05 22:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:09:35 --> Input Class Initialized
INFO - 2025-05-05 22:09:35 --> Language Class Initialized
INFO - 2025-05-05 22:09:35 --> Loader Class Initialized
INFO - 2025-05-05 22:09:35 --> Helper loaded: url_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: string_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: form_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: file_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: html_helper
INFO - 2025-05-05 22:09:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:09:35 --> Controller Class Initialized
INFO - 2025-05-05 22:09:35 --> Config Class Initialized
INFO - 2025-05-05 22:09:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:09:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:09:35 --> Utf8 Class Initialized
INFO - 2025-05-05 22:09:35 --> URI Class Initialized
INFO - 2025-05-05 22:09:35 --> Router Class Initialized
INFO - 2025-05-05 22:09:35 --> Output Class Initialized
INFO - 2025-05-05 22:09:35 --> Security Class Initialized
DEBUG - 2025-05-05 22:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:09:35 --> Input Class Initialized
INFO - 2025-05-05 22:09:35 --> Language Class Initialized
INFO - 2025-05-05 22:09:35 --> Loader Class Initialized
INFO - 2025-05-05 22:09:35 --> Helper loaded: url_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: string_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: form_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: file_helper
INFO - 2025-05-05 22:09:35 --> Helper loaded: html_helper
INFO - 2025-05-05 22:09:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:09:35 --> Controller Class Initialized
INFO - 2025-05-05 22:10:06 --> Config Class Initialized
INFO - 2025-05-05 22:10:06 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:06 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:06 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:06 --> URI Class Initialized
INFO - 2025-05-05 22:10:06 --> Router Class Initialized
INFO - 2025-05-05 22:10:06 --> Output Class Initialized
INFO - 2025-05-05 22:10:06 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:06 --> Input Class Initialized
INFO - 2025-05-05 22:10:06 --> Language Class Initialized
INFO - 2025-05-05 22:10:06 --> Loader Class Initialized
INFO - 2025-05-05 22:10:06 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:06 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:06 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:06 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:06 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:06 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:06 --> Controller Class Initialized
INFO - 2025-05-05 22:10:06 --> Model "CompanyModel" initialized
INFO - 2025-05-05 22:10:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:10:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:10:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 22:10:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:10:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:10:06 --> Final output sent to browser
DEBUG - 2025-05-05 22:10:06 --> Total execution time: 0.1717
INFO - 2025-05-05 22:10:08 --> Config Class Initialized
INFO - 2025-05-05 22:10:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:08 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:08 --> URI Class Initialized
INFO - 2025-05-05 22:10:08 --> Router Class Initialized
INFO - 2025-05-05 22:10:08 --> Output Class Initialized
INFO - 2025-05-05 22:10:08 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:08 --> Input Class Initialized
INFO - 2025-05-05 22:10:08 --> Language Class Initialized
INFO - 2025-05-05 22:10:08 --> Loader Class Initialized
INFO - 2025-05-05 22:10:08 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:08 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:08 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:08 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:08 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:08 --> Controller Class Initialized
INFO - 2025-05-05 22:10:28 --> Config Class Initialized
INFO - 2025-05-05 22:10:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:28 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:28 --> URI Class Initialized
INFO - 2025-05-05 22:10:29 --> Router Class Initialized
INFO - 2025-05-05 22:10:29 --> Output Class Initialized
INFO - 2025-05-05 22:10:29 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:29 --> Input Class Initialized
INFO - 2025-05-05 22:10:29 --> Language Class Initialized
INFO - 2025-05-05 22:10:29 --> Loader Class Initialized
INFO - 2025-05-05 22:10:29 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:29 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:29 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:29 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:29 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:29 --> Controller Class Initialized
INFO - 2025-05-05 22:10:37 --> Config Class Initialized
INFO - 2025-05-05 22:10:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:37 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:37 --> URI Class Initialized
INFO - 2025-05-05 22:10:37 --> Router Class Initialized
INFO - 2025-05-05 22:10:37 --> Output Class Initialized
INFO - 2025-05-05 22:10:37 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:37 --> Input Class Initialized
INFO - 2025-05-05 22:10:37 --> Language Class Initialized
INFO - 2025-05-05 22:10:37 --> Loader Class Initialized
INFO - 2025-05-05 22:10:38 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:38 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:38 --> Controller Class Initialized
INFO - 2025-05-05 22:10:38 --> Config Class Initialized
INFO - 2025-05-05 22:10:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:38 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:38 --> URI Class Initialized
INFO - 2025-05-05 22:10:38 --> Router Class Initialized
INFO - 2025-05-05 22:10:38 --> Output Class Initialized
INFO - 2025-05-05 22:10:38 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:38 --> Input Class Initialized
INFO - 2025-05-05 22:10:38 --> Language Class Initialized
INFO - 2025-05-05 22:10:38 --> Loader Class Initialized
INFO - 2025-05-05 22:10:38 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:38 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:38 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:38 --> Controller Class Initialized
INFO - 2025-05-05 22:10:43 --> Config Class Initialized
INFO - 2025-05-05 22:10:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:43 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:43 --> URI Class Initialized
INFO - 2025-05-05 22:10:43 --> Router Class Initialized
INFO - 2025-05-05 22:10:43 --> Output Class Initialized
INFO - 2025-05-05 22:10:43 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:43 --> Input Class Initialized
INFO - 2025-05-05 22:10:43 --> Language Class Initialized
INFO - 2025-05-05 22:10:43 --> Loader Class Initialized
INFO - 2025-05-05 22:10:43 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:43 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:43 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:43 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:43 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:43 --> Controller Class Initialized
INFO - 2025-05-05 22:10:49 --> Config Class Initialized
INFO - 2025-05-05 22:10:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:10:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:10:49 --> Utf8 Class Initialized
INFO - 2025-05-05 22:10:49 --> URI Class Initialized
INFO - 2025-05-05 22:10:49 --> Router Class Initialized
INFO - 2025-05-05 22:10:49 --> Output Class Initialized
INFO - 2025-05-05 22:10:49 --> Security Class Initialized
DEBUG - 2025-05-05 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:10:49 --> Input Class Initialized
INFO - 2025-05-05 22:10:49 --> Language Class Initialized
INFO - 2025-05-05 22:10:49 --> Loader Class Initialized
INFO - 2025-05-05 22:10:49 --> Helper loaded: url_helper
INFO - 2025-05-05 22:10:49 --> Helper loaded: string_helper
INFO - 2025-05-05 22:10:49 --> Helper loaded: form_helper
INFO - 2025-05-05 22:10:49 --> Helper loaded: file_helper
INFO - 2025-05-05 22:10:49 --> Helper loaded: html_helper
INFO - 2025-05-05 22:10:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:10:49 --> Controller Class Initialized
INFO - 2025-05-05 22:14:00 --> Config Class Initialized
INFO - 2025-05-05 22:14:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:00 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:00 --> URI Class Initialized
INFO - 2025-05-05 22:14:00 --> Router Class Initialized
INFO - 2025-05-05 22:14:00 --> Output Class Initialized
INFO - 2025-05-05 22:14:00 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:00 --> Input Class Initialized
INFO - 2025-05-05 22:14:00 --> Language Class Initialized
INFO - 2025-05-05 22:14:00 --> Loader Class Initialized
INFO - 2025-05-05 22:14:00 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:00 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:00 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:00 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:00 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:00 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:00 --> Controller Class Initialized
INFO - 2025-05-05 22:14:00 --> Model "CompanyModel" initialized
INFO - 2025-05-05 22:14:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:14:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:14:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 22:14:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:14:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:14:00 --> Final output sent to browser
DEBUG - 2025-05-05 22:14:00 --> Total execution time: 0.0890
INFO - 2025-05-05 22:14:02 --> Config Class Initialized
INFO - 2025-05-05 22:14:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:02 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:02 --> URI Class Initialized
INFO - 2025-05-05 22:14:02 --> Router Class Initialized
INFO - 2025-05-05 22:14:02 --> Output Class Initialized
INFO - 2025-05-05 22:14:02 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:02 --> Input Class Initialized
INFO - 2025-05-05 22:14:02 --> Language Class Initialized
INFO - 2025-05-05 22:14:02 --> Loader Class Initialized
INFO - 2025-05-05 22:14:02 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:02 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:02 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:02 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:02 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:02 --> Controller Class Initialized
INFO - 2025-05-05 22:14:28 --> Config Class Initialized
INFO - 2025-05-05 22:14:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:28 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:28 --> URI Class Initialized
INFO - 2025-05-05 22:14:28 --> Router Class Initialized
INFO - 2025-05-05 22:14:28 --> Output Class Initialized
INFO - 2025-05-05 22:14:28 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:28 --> Input Class Initialized
INFO - 2025-05-05 22:14:28 --> Language Class Initialized
INFO - 2025-05-05 22:14:28 --> Loader Class Initialized
INFO - 2025-05-05 22:14:28 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:28 --> Controller Class Initialized
INFO - 2025-05-05 22:14:28 --> Config Class Initialized
INFO - 2025-05-05 22:14:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:28 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:28 --> URI Class Initialized
INFO - 2025-05-05 22:14:28 --> Router Class Initialized
INFO - 2025-05-05 22:14:28 --> Output Class Initialized
INFO - 2025-05-05 22:14:28 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:28 --> Input Class Initialized
INFO - 2025-05-05 22:14:28 --> Language Class Initialized
INFO - 2025-05-05 22:14:28 --> Loader Class Initialized
INFO - 2025-05-05 22:14:28 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:28 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:28 --> Controller Class Initialized
INFO - 2025-05-05 22:14:33 --> Config Class Initialized
INFO - 2025-05-05 22:14:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:33 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:33 --> URI Class Initialized
INFO - 2025-05-05 22:14:33 --> Router Class Initialized
INFO - 2025-05-05 22:14:33 --> Output Class Initialized
INFO - 2025-05-05 22:14:33 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:33 --> Input Class Initialized
INFO - 2025-05-05 22:14:33 --> Language Class Initialized
INFO - 2025-05-05 22:14:33 --> Loader Class Initialized
INFO - 2025-05-05 22:14:33 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:33 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:33 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:33 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:33 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:33 --> Controller Class Initialized
INFO - 2025-05-05 22:14:50 --> Config Class Initialized
INFO - 2025-05-05 22:14:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:14:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:14:50 --> Utf8 Class Initialized
INFO - 2025-05-05 22:14:50 --> URI Class Initialized
INFO - 2025-05-05 22:14:50 --> Router Class Initialized
INFO - 2025-05-05 22:14:50 --> Output Class Initialized
INFO - 2025-05-05 22:14:50 --> Security Class Initialized
DEBUG - 2025-05-05 22:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:14:50 --> Input Class Initialized
INFO - 2025-05-05 22:14:50 --> Language Class Initialized
INFO - 2025-05-05 22:14:50 --> Loader Class Initialized
INFO - 2025-05-05 22:14:50 --> Helper loaded: url_helper
INFO - 2025-05-05 22:14:50 --> Helper loaded: string_helper
INFO - 2025-05-05 22:14:50 --> Helper loaded: form_helper
INFO - 2025-05-05 22:14:50 --> Helper loaded: file_helper
INFO - 2025-05-05 22:14:50 --> Helper loaded: html_helper
INFO - 2025-05-05 22:14:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:14:50 --> Controller Class Initialized
INFO - 2025-05-05 22:16:31 --> Config Class Initialized
INFO - 2025-05-05 22:16:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:16:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:16:31 --> Utf8 Class Initialized
INFO - 2025-05-05 22:16:31 --> URI Class Initialized
INFO - 2025-05-05 22:16:31 --> Router Class Initialized
INFO - 2025-05-05 22:16:31 --> Output Class Initialized
INFO - 2025-05-05 22:16:31 --> Security Class Initialized
DEBUG - 2025-05-05 22:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:16:31 --> Input Class Initialized
INFO - 2025-05-05 22:16:31 --> Language Class Initialized
INFO - 2025-05-05 22:16:31 --> Loader Class Initialized
INFO - 2025-05-05 22:16:31 --> Helper loaded: url_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: string_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: form_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: file_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: html_helper
INFO - 2025-05-05 22:16:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:16:31 --> Controller Class Initialized
INFO - 2025-05-05 22:16:31 --> Config Class Initialized
INFO - 2025-05-05 22:16:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:16:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:16:31 --> Utf8 Class Initialized
INFO - 2025-05-05 22:16:31 --> URI Class Initialized
INFO - 2025-05-05 22:16:31 --> Router Class Initialized
INFO - 2025-05-05 22:16:31 --> Output Class Initialized
INFO - 2025-05-05 22:16:31 --> Security Class Initialized
DEBUG - 2025-05-05 22:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:16:31 --> Input Class Initialized
INFO - 2025-05-05 22:16:31 --> Language Class Initialized
INFO - 2025-05-05 22:16:31 --> Loader Class Initialized
INFO - 2025-05-05 22:16:31 --> Helper loaded: url_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: string_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: form_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: file_helper
INFO - 2025-05-05 22:16:31 --> Helper loaded: html_helper
INFO - 2025-05-05 22:16:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:16:32 --> Controller Class Initialized
INFO - 2025-05-05 22:16:35 --> Config Class Initialized
INFO - 2025-05-05 22:16:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:16:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:16:35 --> Utf8 Class Initialized
INFO - 2025-05-05 22:16:35 --> URI Class Initialized
INFO - 2025-05-05 22:16:35 --> Router Class Initialized
INFO - 2025-05-05 22:16:35 --> Output Class Initialized
INFO - 2025-05-05 22:16:35 --> Security Class Initialized
DEBUG - 2025-05-05 22:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:16:35 --> Input Class Initialized
INFO - 2025-05-05 22:16:35 --> Language Class Initialized
INFO - 2025-05-05 22:16:35 --> Loader Class Initialized
INFO - 2025-05-05 22:16:35 --> Helper loaded: url_helper
INFO - 2025-05-05 22:16:35 --> Helper loaded: string_helper
INFO - 2025-05-05 22:16:35 --> Helper loaded: form_helper
INFO - 2025-05-05 22:16:35 --> Helper loaded: file_helper
INFO - 2025-05-05 22:16:35 --> Helper loaded: html_helper
INFO - 2025-05-05 22:16:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:16:36 --> Controller Class Initialized
INFO - 2025-05-05 22:16:36 --> Config Class Initialized
INFO - 2025-05-05 22:16:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:16:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:16:36 --> Utf8 Class Initialized
INFO - 2025-05-05 22:16:36 --> URI Class Initialized
INFO - 2025-05-05 22:16:36 --> Router Class Initialized
INFO - 2025-05-05 22:16:36 --> Output Class Initialized
INFO - 2025-05-05 22:16:36 --> Security Class Initialized
DEBUG - 2025-05-05 22:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:16:36 --> Input Class Initialized
INFO - 2025-05-05 22:16:36 --> Language Class Initialized
INFO - 2025-05-05 22:16:36 --> Loader Class Initialized
INFO - 2025-05-05 22:16:36 --> Helper loaded: url_helper
INFO - 2025-05-05 22:16:36 --> Helper loaded: string_helper
INFO - 2025-05-05 22:16:36 --> Helper loaded: form_helper
INFO - 2025-05-05 22:16:36 --> Helper loaded: file_helper
INFO - 2025-05-05 22:16:36 --> Helper loaded: html_helper
INFO - 2025-05-05 22:16:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:16:36 --> Controller Class Initialized
INFO - 2025-05-05 22:17:00 --> Config Class Initialized
INFO - 2025-05-05 22:17:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:17:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:17:00 --> Utf8 Class Initialized
INFO - 2025-05-05 22:17:00 --> URI Class Initialized
INFO - 2025-05-05 22:17:00 --> Router Class Initialized
INFO - 2025-05-05 22:17:00 --> Output Class Initialized
INFO - 2025-05-05 22:17:00 --> Security Class Initialized
DEBUG - 2025-05-05 22:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:17:00 --> Input Class Initialized
INFO - 2025-05-05 22:17:00 --> Language Class Initialized
INFO - 2025-05-05 22:17:00 --> Loader Class Initialized
INFO - 2025-05-05 22:17:00 --> Helper loaded: url_helper
INFO - 2025-05-05 22:17:00 --> Helper loaded: string_helper
INFO - 2025-05-05 22:17:00 --> Helper loaded: form_helper
INFO - 2025-05-05 22:17:00 --> Helper loaded: file_helper
INFO - 2025-05-05 22:17:00 --> Helper loaded: html_helper
INFO - 2025-05-05 22:17:00 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:17:00 --> Controller Class Initialized
INFO - 2025-05-05 22:17:02 --> Config Class Initialized
INFO - 2025-05-05 22:17:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:17:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:17:02 --> Utf8 Class Initialized
INFO - 2025-05-05 22:17:02 --> URI Class Initialized
INFO - 2025-05-05 22:17:02 --> Router Class Initialized
INFO - 2025-05-05 22:17:02 --> Output Class Initialized
INFO - 2025-05-05 22:17:02 --> Security Class Initialized
DEBUG - 2025-05-05 22:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:17:02 --> Input Class Initialized
INFO - 2025-05-05 22:17:02 --> Language Class Initialized
INFO - 2025-05-05 22:17:02 --> Loader Class Initialized
INFO - 2025-05-05 22:17:02 --> Helper loaded: url_helper
INFO - 2025-05-05 22:17:02 --> Helper loaded: string_helper
INFO - 2025-05-05 22:17:02 --> Helper loaded: form_helper
INFO - 2025-05-05 22:17:02 --> Helper loaded: file_helper
INFO - 2025-05-05 22:17:02 --> Helper loaded: html_helper
INFO - 2025-05-05 22:17:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:17:02 --> Controller Class Initialized
INFO - 2025-05-05 22:17:05 --> Config Class Initialized
INFO - 2025-05-05 22:17:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:17:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:17:05 --> Utf8 Class Initialized
INFO - 2025-05-05 22:17:05 --> URI Class Initialized
INFO - 2025-05-05 22:17:05 --> Router Class Initialized
INFO - 2025-05-05 22:17:05 --> Output Class Initialized
INFO - 2025-05-05 22:17:05 --> Security Class Initialized
DEBUG - 2025-05-05 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:17:05 --> Input Class Initialized
INFO - 2025-05-05 22:17:05 --> Language Class Initialized
INFO - 2025-05-05 22:17:05 --> Loader Class Initialized
INFO - 2025-05-05 22:17:05 --> Helper loaded: url_helper
INFO - 2025-05-05 22:17:05 --> Helper loaded: string_helper
INFO - 2025-05-05 22:17:05 --> Helper loaded: form_helper
INFO - 2025-05-05 22:17:05 --> Helper loaded: file_helper
INFO - 2025-05-05 22:17:05 --> Helper loaded: html_helper
INFO - 2025-05-05 22:17:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:17:05 --> Controller Class Initialized
INFO - 2025-05-05 22:17:08 --> Config Class Initialized
INFO - 2025-05-05 22:17:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:17:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:17:08 --> Utf8 Class Initialized
INFO - 2025-05-05 22:17:08 --> URI Class Initialized
INFO - 2025-05-05 22:17:08 --> Router Class Initialized
INFO - 2025-05-05 22:17:08 --> Output Class Initialized
INFO - 2025-05-05 22:17:08 --> Security Class Initialized
DEBUG - 2025-05-05 22:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:17:08 --> Input Class Initialized
INFO - 2025-05-05 22:17:08 --> Language Class Initialized
INFO - 2025-05-05 22:17:08 --> Loader Class Initialized
INFO - 2025-05-05 22:17:08 --> Helper loaded: url_helper
INFO - 2025-05-05 22:17:08 --> Helper loaded: string_helper
INFO - 2025-05-05 22:17:08 --> Helper loaded: form_helper
INFO - 2025-05-05 22:17:08 --> Helper loaded: file_helper
INFO - 2025-05-05 22:17:08 --> Helper loaded: html_helper
INFO - 2025-05-05 22:17:08 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:17:08 --> Controller Class Initialized
INFO - 2025-05-05 22:18:15 --> Config Class Initialized
INFO - 2025-05-05 22:18:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:18:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:18:15 --> Utf8 Class Initialized
INFO - 2025-05-05 22:18:15 --> URI Class Initialized
INFO - 2025-05-05 22:18:15 --> Router Class Initialized
INFO - 2025-05-05 22:18:15 --> Output Class Initialized
INFO - 2025-05-05 22:18:15 --> Security Class Initialized
DEBUG - 2025-05-05 22:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:18:15 --> Input Class Initialized
INFO - 2025-05-05 22:18:15 --> Language Class Initialized
INFO - 2025-05-05 22:18:15 --> Loader Class Initialized
INFO - 2025-05-05 22:18:15 --> Helper loaded: url_helper
INFO - 2025-05-05 22:18:15 --> Helper loaded: string_helper
INFO - 2025-05-05 22:18:15 --> Helper loaded: form_helper
INFO - 2025-05-05 22:18:15 --> Helper loaded: file_helper
INFO - 2025-05-05 22:18:15 --> Helper loaded: html_helper
INFO - 2025-05-05 22:18:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:18:15 --> Controller Class Initialized
INFO - 2025-05-05 22:51:25 --> Config Class Initialized
INFO - 2025-05-05 22:51:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:51:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:51:25 --> Utf8 Class Initialized
INFO - 2025-05-05 22:51:25 --> URI Class Initialized
INFO - 2025-05-05 22:51:25 --> Router Class Initialized
INFO - 2025-05-05 22:51:25 --> Output Class Initialized
INFO - 2025-05-05 22:51:25 --> Security Class Initialized
DEBUG - 2025-05-05 22:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:51:25 --> Input Class Initialized
INFO - 2025-05-05 22:51:25 --> Language Class Initialized
INFO - 2025-05-05 22:51:25 --> Loader Class Initialized
INFO - 2025-05-05 22:51:25 --> Helper loaded: url_helper
INFO - 2025-05-05 22:51:25 --> Helper loaded: string_helper
INFO - 2025-05-05 22:51:25 --> Helper loaded: form_helper
INFO - 2025-05-05 22:51:25 --> Helper loaded: file_helper
INFO - 2025-05-05 22:51:25 --> Helper loaded: html_helper
INFO - 2025-05-05 22:51:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:51:25 --> Controller Class Initialized
INFO - 2025-05-05 22:51:41 --> Config Class Initialized
INFO - 2025-05-05 22:51:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:51:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:51:41 --> Utf8 Class Initialized
INFO - 2025-05-05 22:51:41 --> URI Class Initialized
INFO - 2025-05-05 22:51:41 --> Router Class Initialized
INFO - 2025-05-05 22:51:41 --> Output Class Initialized
INFO - 2025-05-05 22:51:41 --> Security Class Initialized
DEBUG - 2025-05-05 22:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:51:41 --> Input Class Initialized
INFO - 2025-05-05 22:51:41 --> Language Class Initialized
INFO - 2025-05-05 22:51:41 --> Loader Class Initialized
INFO - 2025-05-05 22:51:41 --> Helper loaded: url_helper
INFO - 2025-05-05 22:51:41 --> Helper loaded: string_helper
INFO - 2025-05-05 22:51:41 --> Helper loaded: form_helper
INFO - 2025-05-05 22:51:41 --> Helper loaded: file_helper
INFO - 2025-05-05 22:51:41 --> Helper loaded: html_helper
INFO - 2025-05-05 22:51:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:51:41 --> Controller Class Initialized
INFO - 2025-05-05 22:53:01 --> Config Class Initialized
INFO - 2025-05-05 22:53:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:53:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:53:01 --> Utf8 Class Initialized
INFO - 2025-05-05 22:53:01 --> URI Class Initialized
INFO - 2025-05-05 22:53:01 --> Router Class Initialized
INFO - 2025-05-05 22:53:01 --> Output Class Initialized
INFO - 2025-05-05 22:53:01 --> Security Class Initialized
DEBUG - 2025-05-05 22:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:53:01 --> Input Class Initialized
INFO - 2025-05-05 22:53:01 --> Language Class Initialized
INFO - 2025-05-05 22:53:01 --> Loader Class Initialized
INFO - 2025-05-05 22:53:01 --> Helper loaded: url_helper
INFO - 2025-05-05 22:53:01 --> Helper loaded: string_helper
INFO - 2025-05-05 22:53:01 --> Helper loaded: form_helper
INFO - 2025-05-05 22:53:01 --> Helper loaded: file_helper
INFO - 2025-05-05 22:53:01 --> Helper loaded: html_helper
INFO - 2025-05-05 22:53:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:53:01 --> Controller Class Initialized
INFO - 2025-05-05 22:53:03 --> Config Class Initialized
INFO - 2025-05-05 22:53:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:53:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:53:03 --> Utf8 Class Initialized
INFO - 2025-05-05 22:53:03 --> URI Class Initialized
INFO - 2025-05-05 22:53:03 --> Router Class Initialized
INFO - 2025-05-05 22:53:03 --> Output Class Initialized
INFO - 2025-05-05 22:53:03 --> Security Class Initialized
DEBUG - 2025-05-05 22:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:53:03 --> Input Class Initialized
INFO - 2025-05-05 22:53:03 --> Language Class Initialized
INFO - 2025-05-05 22:53:03 --> Loader Class Initialized
INFO - 2025-05-05 22:53:03 --> Helper loaded: url_helper
INFO - 2025-05-05 22:53:03 --> Helper loaded: string_helper
INFO - 2025-05-05 22:53:03 --> Helper loaded: form_helper
INFO - 2025-05-05 22:53:03 --> Helper loaded: file_helper
INFO - 2025-05-05 22:53:03 --> Helper loaded: html_helper
INFO - 2025-05-05 22:53:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:53:04 --> Controller Class Initialized
INFO - 2025-05-05 22:53:40 --> Config Class Initialized
INFO - 2025-05-05 22:53:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:53:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:53:40 --> Utf8 Class Initialized
INFO - 2025-05-05 22:53:40 --> URI Class Initialized
INFO - 2025-05-05 22:53:40 --> Router Class Initialized
INFO - 2025-05-05 22:53:40 --> Output Class Initialized
INFO - 2025-05-05 22:53:40 --> Security Class Initialized
DEBUG - 2025-05-05 22:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:53:40 --> Input Class Initialized
INFO - 2025-05-05 22:53:40 --> Language Class Initialized
INFO - 2025-05-05 22:53:40 --> Loader Class Initialized
INFO - 2025-05-05 22:53:40 --> Helper loaded: url_helper
INFO - 2025-05-05 22:53:40 --> Helper loaded: string_helper
INFO - 2025-05-05 22:53:40 --> Helper loaded: form_helper
INFO - 2025-05-05 22:53:40 --> Helper loaded: file_helper
INFO - 2025-05-05 22:53:40 --> Helper loaded: html_helper
INFO - 2025-05-05 22:53:40 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:53:40 --> Controller Class Initialized
INFO - 2025-05-05 22:53:45 --> Config Class Initialized
INFO - 2025-05-05 22:53:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:53:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:53:45 --> Utf8 Class Initialized
INFO - 2025-05-05 22:53:45 --> URI Class Initialized
INFO - 2025-05-05 22:53:45 --> Router Class Initialized
INFO - 2025-05-05 22:53:45 --> Output Class Initialized
INFO - 2025-05-05 22:53:45 --> Security Class Initialized
INFO - 2025-05-05 22:53:45 --> Loader Class Initialized
INFO - 2025-05-05 22:53:45 --> Helper loaded: url_helper
INFO - 2025-05-05 22:53:45 --> Helper loaded: string_helper
INFO - 2025-05-05 22:53:45 --> Helper loaded: form_helper
INFO - 2025-05-05 22:53:45 --> Helper loaded: file_helper
INFO - 2025-05-05 22:53:45 --> Helper loaded: html_helper
INFO - 2025-05-05 22:53:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:53:45 --> Controller Class Initialized
INFO - 2025-05-05 22:54:02 --> Config Class Initialized
INFO - 2025-05-05 22:54:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:54:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:54:02 --> Utf8 Class Initialized
INFO - 2025-05-05 22:54:02 --> URI Class Initialized
INFO - 2025-05-05 22:54:02 --> Router Class Initialized
INFO - 2025-05-05 22:54:02 --> Output Class Initialized
INFO - 2025-05-05 22:54:02 --> Security Class Initialized
DEBUG - 2025-05-05 22:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:54:02 --> Input Class Initialized
INFO - 2025-05-05 22:54:02 --> Language Class Initialized
INFO - 2025-05-05 22:54:02 --> Loader Class Initialized
INFO - 2025-05-05 22:54:02 --> Helper loaded: url_helper
INFO - 2025-05-05 22:54:02 --> Helper loaded: string_helper
INFO - 2025-05-05 22:54:02 --> Helper loaded: form_helper
INFO - 2025-05-05 22:54:02 --> Helper loaded: file_helper
INFO - 2025-05-05 22:54:02 --> Helper loaded: html_helper
INFO - 2025-05-05 22:54:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:54:02 --> Controller Class Initialized
INFO - 2025-05-05 22:54:21 --> Config Class Initialized
INFO - 2025-05-05 22:54:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:54:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:54:21 --> Utf8 Class Initialized
INFO - 2025-05-05 22:54:21 --> URI Class Initialized
INFO - 2025-05-05 22:54:21 --> Router Class Initialized
INFO - 2025-05-05 22:54:21 --> Output Class Initialized
INFO - 2025-05-05 22:54:21 --> Security Class Initialized
DEBUG - 2025-05-05 22:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:54:21 --> Input Class Initialized
INFO - 2025-05-05 22:54:21 --> Language Class Initialized
INFO - 2025-05-05 22:54:22 --> Loader Class Initialized
INFO - 2025-05-05 22:54:22 --> Helper loaded: url_helper
INFO - 2025-05-05 22:54:22 --> Helper loaded: string_helper
INFO - 2025-05-05 22:54:22 --> Helper loaded: form_helper
INFO - 2025-05-05 22:54:22 --> Helper loaded: file_helper
INFO - 2025-05-05 22:54:22 --> Helper loaded: html_helper
INFO - 2025-05-05 22:54:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:54:22 --> Controller Class Initialized
INFO - 2025-05-05 22:54:36 --> Config Class Initialized
INFO - 2025-05-05 22:54:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:54:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:54:36 --> Utf8 Class Initialized
INFO - 2025-05-05 22:54:36 --> URI Class Initialized
INFO - 2025-05-05 22:54:36 --> Router Class Initialized
INFO - 2025-05-05 22:54:36 --> Output Class Initialized
INFO - 2025-05-05 22:54:36 --> Security Class Initialized
DEBUG - 2025-05-05 22:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:54:36 --> Input Class Initialized
INFO - 2025-05-05 22:54:36 --> Language Class Initialized
INFO - 2025-05-05 22:54:36 --> Loader Class Initialized
INFO - 2025-05-05 22:54:36 --> Helper loaded: url_helper
INFO - 2025-05-05 22:54:36 --> Helper loaded: string_helper
INFO - 2025-05-05 22:54:36 --> Helper loaded: form_helper
INFO - 2025-05-05 22:54:36 --> Helper loaded: file_helper
INFO - 2025-05-05 22:54:36 --> Helper loaded: html_helper
INFO - 2025-05-05 22:54:36 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:54:36 --> Controller Class Initialized
INFO - 2025-05-05 22:54:46 --> Config Class Initialized
INFO - 2025-05-05 22:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:54:46 --> Utf8 Class Initialized
INFO - 2025-05-05 22:54:46 --> URI Class Initialized
INFO - 2025-05-05 22:54:46 --> Router Class Initialized
INFO - 2025-05-05 22:54:46 --> Output Class Initialized
INFO - 2025-05-05 22:54:46 --> Security Class Initialized
DEBUG - 2025-05-05 22:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:54:46 --> Input Class Initialized
INFO - 2025-05-05 22:54:46 --> Language Class Initialized
INFO - 2025-05-05 22:54:46 --> Loader Class Initialized
INFO - 2025-05-05 22:54:46 --> Helper loaded: url_helper
INFO - 2025-05-05 22:54:46 --> Helper loaded: string_helper
INFO - 2025-05-05 22:54:46 --> Helper loaded: form_helper
INFO - 2025-05-05 22:54:46 --> Helper loaded: file_helper
INFO - 2025-05-05 22:54:46 --> Helper loaded: html_helper
INFO - 2025-05-05 22:54:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:54:46 --> Controller Class Initialized
INFO - 2025-05-05 22:55:02 --> Config Class Initialized
INFO - 2025-05-05 22:55:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:02 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:02 --> URI Class Initialized
INFO - 2025-05-05 22:55:02 --> Router Class Initialized
INFO - 2025-05-05 22:55:02 --> Output Class Initialized
INFO - 2025-05-05 22:55:02 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:02 --> Input Class Initialized
INFO - 2025-05-05 22:55:02 --> Language Class Initialized
INFO - 2025-05-05 22:55:02 --> Loader Class Initialized
INFO - 2025-05-05 22:55:02 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:02 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:02 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:02 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:02 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:02 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:02 --> Controller Class Initialized
INFO - 2025-05-05 22:55:04 --> Config Class Initialized
INFO - 2025-05-05 22:55:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:04 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:04 --> URI Class Initialized
INFO - 2025-05-05 22:55:04 --> Router Class Initialized
INFO - 2025-05-05 22:55:04 --> Output Class Initialized
INFO - 2025-05-05 22:55:04 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:04 --> Input Class Initialized
INFO - 2025-05-05 22:55:04 --> Language Class Initialized
INFO - 2025-05-05 22:55:04 --> Loader Class Initialized
INFO - 2025-05-05 22:55:04 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:04 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:04 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:04 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:04 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:04 --> Controller Class Initialized
INFO - 2025-05-05 22:55:23 --> Config Class Initialized
INFO - 2025-05-05 22:55:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:23 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:23 --> URI Class Initialized
INFO - 2025-05-05 22:55:23 --> Router Class Initialized
INFO - 2025-05-05 22:55:23 --> Output Class Initialized
INFO - 2025-05-05 22:55:23 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:23 --> Input Class Initialized
INFO - 2025-05-05 22:55:23 --> Language Class Initialized
INFO - 2025-05-05 22:55:23 --> Loader Class Initialized
INFO - 2025-05-05 22:55:23 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:23 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:23 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:23 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:23 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:23 --> Controller Class Initialized
INFO - 2025-05-05 22:55:24 --> Config Class Initialized
INFO - 2025-05-05 22:55:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:24 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:24 --> URI Class Initialized
INFO - 2025-05-05 22:55:24 --> Router Class Initialized
INFO - 2025-05-05 22:55:24 --> Output Class Initialized
INFO - 2025-05-05 22:55:24 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:24 --> Input Class Initialized
INFO - 2025-05-05 22:55:24 --> Language Class Initialized
INFO - 2025-05-05 22:55:24 --> Loader Class Initialized
INFO - 2025-05-05 22:55:24 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:24 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:24 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:24 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:24 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:24 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:24 --> Controller Class Initialized
INFO - 2025-05-05 22:55:37 --> Config Class Initialized
INFO - 2025-05-05 22:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:37 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:37 --> URI Class Initialized
INFO - 2025-05-05 22:55:37 --> Router Class Initialized
INFO - 2025-05-05 22:55:37 --> Output Class Initialized
INFO - 2025-05-05 22:55:37 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:37 --> Input Class Initialized
INFO - 2025-05-05 22:55:37 --> Language Class Initialized
INFO - 2025-05-05 22:55:37 --> Loader Class Initialized
INFO - 2025-05-05 22:55:37 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:37 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:37 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:37 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:37 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:37 --> Controller Class Initialized
INFO - 2025-05-05 22:55:39 --> Config Class Initialized
INFO - 2025-05-05 22:55:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:55:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:55:39 --> Utf8 Class Initialized
INFO - 2025-05-05 22:55:39 --> URI Class Initialized
INFO - 2025-05-05 22:55:39 --> Router Class Initialized
INFO - 2025-05-05 22:55:39 --> Output Class Initialized
INFO - 2025-05-05 22:55:39 --> Security Class Initialized
DEBUG - 2025-05-05 22:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:55:39 --> Input Class Initialized
INFO - 2025-05-05 22:55:39 --> Language Class Initialized
INFO - 2025-05-05 22:55:39 --> Loader Class Initialized
INFO - 2025-05-05 22:55:39 --> Helper loaded: url_helper
INFO - 2025-05-05 22:55:39 --> Helper loaded: string_helper
INFO - 2025-05-05 22:55:39 --> Helper loaded: form_helper
INFO - 2025-05-05 22:55:39 --> Helper loaded: file_helper
INFO - 2025-05-05 22:55:39 --> Helper loaded: html_helper
INFO - 2025-05-05 22:55:39 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:55:39 --> Controller Class Initialized
INFO - 2025-05-05 22:56:31 --> Config Class Initialized
INFO - 2025-05-05 22:56:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:56:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:56:31 --> Utf8 Class Initialized
INFO - 2025-05-05 22:56:31 --> URI Class Initialized
INFO - 2025-05-05 22:56:31 --> Router Class Initialized
INFO - 2025-05-05 22:56:31 --> Output Class Initialized
INFO - 2025-05-05 22:56:31 --> Security Class Initialized
DEBUG - 2025-05-05 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:56:31 --> Input Class Initialized
INFO - 2025-05-05 22:56:31 --> Language Class Initialized
INFO - 2025-05-05 22:56:31 --> Loader Class Initialized
INFO - 2025-05-05 22:56:31 --> Helper loaded: url_helper
INFO - 2025-05-05 22:56:31 --> Helper loaded: string_helper
INFO - 2025-05-05 22:56:31 --> Helper loaded: form_helper
INFO - 2025-05-05 22:56:31 --> Helper loaded: file_helper
INFO - 2025-05-05 22:56:31 --> Helper loaded: html_helper
INFO - 2025-05-05 22:56:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:32 --> Controller Class Initialized
INFO - 2025-05-05 22:56:33 --> Config Class Initialized
INFO - 2025-05-05 22:56:33 --> Hooks Class Initialized
INFO - 2025-05-05 22:56:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:33 --> Controller Class Initialized
INFO - 2025-05-05 22:56:41 --> Config Class Initialized
INFO - 2025-05-05 22:56:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:56:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:56:41 --> Utf8 Class Initialized
INFO - 2025-05-05 22:56:41 --> URI Class Initialized
DEBUG - 2025-05-05 22:56:41 --> No URI present. Default controller set.
INFO - 2025-05-05 22:56:41 --> Router Class Initialized
INFO - 2025-05-05 22:56:41 --> Output Class Initialized
INFO - 2025-05-05 22:56:41 --> Security Class Initialized
DEBUG - 2025-05-05 22:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:56:41 --> Input Class Initialized
INFO - 2025-05-05 22:56:41 --> Language Class Initialized
INFO - 2025-05-05 22:56:41 --> Loader Class Initialized
INFO - 2025-05-05 22:56:41 --> Helper loaded: url_helper
INFO - 2025-05-05 22:56:41 --> Helper loaded: string_helper
INFO - 2025-05-05 22:56:41 --> Helper loaded: form_helper
INFO - 2025-05-05 22:56:41 --> Helper loaded: file_helper
INFO - 2025-05-05 22:56:41 --> Helper loaded: html_helper
INFO - 2025-05-05 22:56:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:41 --> Controller Class Initialized
INFO - 2025-05-05 22:56:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 22:56:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 22:56:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 22:56:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 22:56:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 22:56:41 --> Final output sent to browser
DEBUG - 2025-05-05 22:56:41 --> Total execution time: 0.1160
INFO - 2025-05-05 22:56:43 --> Config Class Initialized
INFO - 2025-05-05 22:56:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:56:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:56:43 --> Utf8 Class Initialized
INFO - 2025-05-05 22:56:43 --> URI Class Initialized
INFO - 2025-05-05 22:56:43 --> Router Class Initialized
INFO - 2025-05-05 22:56:43 --> Output Class Initialized
INFO - 2025-05-05 22:56:43 --> Security Class Initialized
DEBUG - 2025-05-05 22:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:56:43 --> Input Class Initialized
INFO - 2025-05-05 22:56:43 --> Language Class Initialized
INFO - 2025-05-05 22:56:43 --> Loader Class Initialized
INFO - 2025-05-05 22:56:43 --> Helper loaded: url_helper
INFO - 2025-05-05 22:56:43 --> Helper loaded: string_helper
INFO - 2025-05-05 22:56:43 --> Helper loaded: form_helper
INFO - 2025-05-05 22:56:43 --> Helper loaded: file_helper
INFO - 2025-05-05 22:56:43 --> Helper loaded: html_helper
INFO - 2025-05-05 22:56:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:43 --> Controller Class Initialized
INFO - 2025-05-05 22:56:44 --> Config Class Initialized
INFO - 2025-05-05 22:56:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:56:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:56:44 --> Utf8 Class Initialized
INFO - 2025-05-05 22:56:44 --> URI Class Initialized
INFO - 2025-05-05 22:56:44 --> Router Class Initialized
INFO - 2025-05-05 22:56:44 --> Output Class Initialized
INFO - 2025-05-05 22:56:44 --> Security Class Initialized
DEBUG - 2025-05-05 22:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:56:44 --> Input Class Initialized
INFO - 2025-05-05 22:56:44 --> Language Class Initialized
INFO - 2025-05-05 22:56:44 --> Loader Class Initialized
INFO - 2025-05-05 22:56:44 --> Helper loaded: url_helper
INFO - 2025-05-05 22:56:44 --> Helper loaded: string_helper
INFO - 2025-05-05 22:56:44 --> Helper loaded: form_helper
INFO - 2025-05-05 22:56:44 --> Helper loaded: file_helper
INFO - 2025-05-05 22:56:44 --> Helper loaded: html_helper
INFO - 2025-05-05 22:56:44 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:44 --> Controller Class Initialized
INFO - 2025-05-05 22:56:46 --> Config Class Initialized
INFO - 2025-05-05 22:56:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 22:56:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 22:56:46 --> Utf8 Class Initialized
INFO - 2025-05-05 22:56:46 --> URI Class Initialized
INFO - 2025-05-05 22:56:46 --> Router Class Initialized
INFO - 2025-05-05 22:56:46 --> Output Class Initialized
INFO - 2025-05-05 22:56:46 --> Security Class Initialized
DEBUG - 2025-05-05 22:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 22:56:46 --> Input Class Initialized
INFO - 2025-05-05 22:56:46 --> Language Class Initialized
INFO - 2025-05-05 22:56:46 --> Loader Class Initialized
INFO - 2025-05-05 22:56:46 --> Helper loaded: url_helper
INFO - 2025-05-05 22:56:46 --> Helper loaded: string_helper
INFO - 2025-05-05 22:56:46 --> Helper loaded: form_helper
INFO - 2025-05-05 22:56:46 --> Helper loaded: file_helper
INFO - 2025-05-05 22:56:46 --> Helper loaded: html_helper
INFO - 2025-05-05 22:56:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 22:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 22:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 22:56:46 --> Controller Class Initialized
INFO - 2025-05-05 23:04:27 --> Config Class Initialized
INFO - 2025-05-05 23:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:04:27 --> Utf8 Class Initialized
INFO - 2025-05-05 23:04:27 --> URI Class Initialized
INFO - 2025-05-05 23:04:27 --> Router Class Initialized
INFO - 2025-05-05 23:04:27 --> Output Class Initialized
INFO - 2025-05-05 23:04:27 --> Security Class Initialized
DEBUG - 2025-05-05 23:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:04:27 --> Input Class Initialized
INFO - 2025-05-05 23:04:27 --> Language Class Initialized
INFO - 2025-05-05 23:04:28 --> Loader Class Initialized
INFO - 2025-05-05 23:04:28 --> Helper loaded: url_helper
INFO - 2025-05-05 23:04:28 --> Helper loaded: string_helper
INFO - 2025-05-05 23:04:28 --> Helper loaded: form_helper
INFO - 2025-05-05 23:04:28 --> Helper loaded: file_helper
INFO - 2025-05-05 23:04:28 --> Helper loaded: html_helper
INFO - 2025-05-05 23:04:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:04:28 --> Controller Class Initialized
INFO - 2025-05-05 23:04:29 --> Config Class Initialized
INFO - 2025-05-05 23:04:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:04:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:04:29 --> Utf8 Class Initialized
INFO - 2025-05-05 23:04:30 --> URI Class Initialized
INFO - 2025-05-05 23:04:30 --> Router Class Initialized
INFO - 2025-05-05 23:04:30 --> Output Class Initialized
INFO - 2025-05-05 23:04:30 --> Security Class Initialized
DEBUG - 2025-05-05 23:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:04:30 --> Input Class Initialized
INFO - 2025-05-05 23:04:30 --> Language Class Initialized
INFO - 2025-05-05 23:04:30 --> Loader Class Initialized
INFO - 2025-05-05 23:04:30 --> Helper loaded: url_helper
INFO - 2025-05-05 23:04:30 --> Helper loaded: string_helper
INFO - 2025-05-05 23:04:30 --> Helper loaded: form_helper
INFO - 2025-05-05 23:04:30 --> Helper loaded: file_helper
INFO - 2025-05-05 23:04:32 --> Config Class Initialized
INFO - 2025-05-05 23:04:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:04:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:04:32 --> Utf8 Class Initialized
INFO - 2025-05-05 23:04:32 --> URI Class Initialized
INFO - 2025-05-05 23:04:32 --> Router Class Initialized
INFO - 2025-05-05 23:04:32 --> Output Class Initialized
INFO - 2025-05-05 23:04:32 --> Security Class Initialized
DEBUG - 2025-05-05 23:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:04:32 --> Input Class Initialized
INFO - 2025-05-05 23:04:32 --> Language Class Initialized
INFO - 2025-05-05 23:04:32 --> Loader Class Initialized
INFO - 2025-05-05 23:04:32 --> Helper loaded: url_helper
INFO - 2025-05-05 23:04:32 --> Helper loaded: string_helper
INFO - 2025-05-05 23:04:32 --> Helper loaded: form_helper
INFO - 2025-05-05 23:04:32 --> Helper loaded: file_helper
INFO - 2025-05-05 23:04:32 --> Helper loaded: html_helper
INFO - 2025-05-05 23:04:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:04:32 --> Controller Class Initialized
INFO - 2025-05-05 23:04:33 --> Config Class Initialized
INFO - 2025-05-05 23:04:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:04:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:04:33 --> Utf8 Class Initialized
INFO - 2025-05-05 23:04:33 --> URI Class Initialized
INFO - 2025-05-05 23:04:33 --> Router Class Initialized
INFO - 2025-05-05 23:04:33 --> Output Class Initialized
INFO - 2025-05-05 23:04:33 --> Security Class Initialized
DEBUG - 2025-05-05 23:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:04:33 --> Input Class Initialized
INFO - 2025-05-05 23:04:33 --> Language Class Initialized
INFO - 2025-05-05 23:04:33 --> Loader Class Initialized
INFO - 2025-05-05 23:04:33 --> Helper loaded: url_helper
INFO - 2025-05-05 23:04:33 --> Helper loaded: string_helper
INFO - 2025-05-05 23:04:33 --> Helper loaded: form_helper
INFO - 2025-05-05 23:04:33 --> Helper loaded: file_helper
INFO - 2025-05-05 23:04:33 --> Helper loaded: html_helper
INFO - 2025-05-05 23:04:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:04:33 --> Controller Class Initialized
INFO - 2025-05-05 23:06:27 --> Config Class Initialized
INFO - 2025-05-05 23:06:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:06:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:06:27 --> Utf8 Class Initialized
INFO - 2025-05-05 23:06:27 --> URI Class Initialized
INFO - 2025-05-05 23:06:27 --> Router Class Initialized
INFO - 2025-05-05 23:06:27 --> Output Class Initialized
INFO - 2025-05-05 23:06:27 --> Security Class Initialized
DEBUG - 2025-05-05 23:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:06:27 --> Input Class Initialized
INFO - 2025-05-05 23:06:27 --> Language Class Initialized
INFO - 2025-05-05 23:06:27 --> Loader Class Initialized
INFO - 2025-05-05 23:06:27 --> Helper loaded: url_helper
INFO - 2025-05-05 23:06:27 --> Helper loaded: string_helper
INFO - 2025-05-05 23:06:27 --> Helper loaded: form_helper
INFO - 2025-05-05 23:06:27 --> Helper loaded: file_helper
INFO - 2025-05-05 23:06:27 --> Helper loaded: html_helper
INFO - 2025-05-05 23:06:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:06:27 --> Controller Class Initialized
INFO - 2025-05-05 23:06:28 --> Config Class Initialized
INFO - 2025-05-05 23:06:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:06:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:06:28 --> Utf8 Class Initialized
INFO - 2025-05-05 23:06:28 --> URI Class Initialized
INFO - 2025-05-05 23:06:28 --> Router Class Initialized
INFO - 2025-05-05 23:06:28 --> Output Class Initialized
INFO - 2025-05-05 23:06:28 --> Security Class Initialized
DEBUG - 2025-05-05 23:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:06:28 --> Input Class Initialized
INFO - 2025-05-05 23:06:28 --> Language Class Initialized
INFO - 2025-05-05 23:06:28 --> Loader Class Initialized
INFO - 2025-05-05 23:06:28 --> Helper loaded: url_helper
INFO - 2025-05-05 23:06:28 --> Helper loaded: string_helper
INFO - 2025-05-05 23:06:28 --> Helper loaded: form_helper
INFO - 2025-05-05 23:06:28 --> Helper loaded: file_helper
INFO - 2025-05-05 23:06:28 --> Helper loaded: html_helper
INFO - 2025-05-05 23:06:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:06:29 --> Controller Class Initialized
INFO - 2025-05-05 23:07:13 --> Config Class Initialized
INFO - 2025-05-05 23:07:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:13 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:13 --> URI Class Initialized
INFO - 2025-05-05 23:07:13 --> Router Class Initialized
INFO - 2025-05-05 23:07:13 --> Output Class Initialized
INFO - 2025-05-05 23:07:13 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:13 --> Input Class Initialized
INFO - 2025-05-05 23:07:13 --> Language Class Initialized
INFO - 2025-05-05 23:07:13 --> Loader Class Initialized
INFO - 2025-05-05 23:07:13 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:13 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:13 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:13 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:13 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:13 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:13 --> Controller Class Initialized
INFO - 2025-05-05 23:07:15 --> Config Class Initialized
INFO - 2025-05-05 23:07:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:15 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:15 --> URI Class Initialized
INFO - 2025-05-05 23:07:15 --> Router Class Initialized
INFO - 2025-05-05 23:07:15 --> Output Class Initialized
INFO - 2025-05-05 23:07:15 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:15 --> Input Class Initialized
INFO - 2025-05-05 23:07:15 --> Language Class Initialized
INFO - 2025-05-05 23:07:15 --> Loader Class Initialized
INFO - 2025-05-05 23:07:15 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:15 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:15 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:15 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:15 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:15 --> Controller Class Initialized
INFO - 2025-05-05 23:07:24 --> Config Class Initialized
INFO - 2025-05-05 23:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:24 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:24 --> URI Class Initialized
INFO - 2025-05-05 23:07:24 --> Router Class Initialized
INFO - 2025-05-05 23:07:24 --> Output Class Initialized
INFO - 2025-05-05 23:07:24 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:24 --> Input Class Initialized
INFO - 2025-05-05 23:07:24 --> Language Class Initialized
INFO - 2025-05-05 23:07:24 --> Loader Class Initialized
INFO - 2025-05-05 23:07:24 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:24 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:24 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:24 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:24 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:24 --> Controller Class Initialized
INFO - 2025-05-05 23:07:41 --> Config Class Initialized
INFO - 2025-05-05 23:07:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:41 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:41 --> URI Class Initialized
INFO - 2025-05-05 23:07:41 --> Router Class Initialized
INFO - 2025-05-05 23:07:41 --> Output Class Initialized
INFO - 2025-05-05 23:07:41 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:41 --> Input Class Initialized
INFO - 2025-05-05 23:07:41 --> Language Class Initialized
INFO - 2025-05-05 23:07:41 --> Loader Class Initialized
INFO - 2025-05-05 23:07:41 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:41 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:41 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:41 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:41 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:41 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:41 --> Controller Class Initialized
INFO - 2025-05-05 23:07:43 --> Config Class Initialized
INFO - 2025-05-05 23:07:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:43 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:43 --> URI Class Initialized
INFO - 2025-05-05 23:07:43 --> Router Class Initialized
INFO - 2025-05-05 23:07:43 --> Output Class Initialized
INFO - 2025-05-05 23:07:43 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:43 --> Input Class Initialized
INFO - 2025-05-05 23:07:43 --> Language Class Initialized
INFO - 2025-05-05 23:07:43 --> Loader Class Initialized
INFO - 2025-05-05 23:07:43 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:43 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:43 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:43 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:43 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:43 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:43 --> Controller Class Initialized
INFO - 2025-05-05 23:07:44 --> Config Class Initialized
INFO - 2025-05-05 23:07:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:07:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:07:44 --> Utf8 Class Initialized
INFO - 2025-05-05 23:07:44 --> URI Class Initialized
INFO - 2025-05-05 23:07:44 --> Router Class Initialized
INFO - 2025-05-05 23:07:44 --> Output Class Initialized
INFO - 2025-05-05 23:07:44 --> Security Class Initialized
DEBUG - 2025-05-05 23:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:07:44 --> Input Class Initialized
INFO - 2025-05-05 23:07:44 --> Language Class Initialized
INFO - 2025-05-05 23:07:44 --> Loader Class Initialized
INFO - 2025-05-05 23:07:44 --> Helper loaded: url_helper
INFO - 2025-05-05 23:07:44 --> Helper loaded: string_helper
INFO - 2025-05-05 23:07:44 --> Helper loaded: form_helper
INFO - 2025-05-05 23:07:44 --> Helper loaded: file_helper
INFO - 2025-05-05 23:07:44 --> Helper loaded: html_helper
INFO - 2025-05-05 23:07:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:07:45 --> Controller Class Initialized
INFO - 2025-05-05 23:08:08 --> Config Class Initialized
INFO - 2025-05-05 23:08:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:08:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:08:08 --> Utf8 Class Initialized
INFO - 2025-05-05 23:08:08 --> URI Class Initialized
INFO - 2025-05-05 23:08:08 --> Router Class Initialized
INFO - 2025-05-05 23:08:08 --> Output Class Initialized
INFO - 2025-05-05 23:08:08 --> Security Class Initialized
DEBUG - 2025-05-05 23:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:08:08 --> Input Class Initialized
INFO - 2025-05-05 23:08:08 --> Language Class Initialized
INFO - 2025-05-05 23:08:09 --> Loader Class Initialized
INFO - 2025-05-05 23:08:09 --> Helper loaded: url_helper
INFO - 2025-05-05 23:08:09 --> Helper loaded: string_helper
INFO - 2025-05-05 23:08:09 --> Helper loaded: form_helper
INFO - 2025-05-05 23:08:09 --> Helper loaded: file_helper
INFO - 2025-05-05 23:08:09 --> Helper loaded: html_helper
INFO - 2025-05-05 23:08:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:08:09 --> Controller Class Initialized
INFO - 2025-05-05 23:08:10 --> Config Class Initialized
INFO - 2025-05-05 23:08:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:08:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:08:11 --> Utf8 Class Initialized
INFO - 2025-05-05 23:08:11 --> URI Class Initialized
INFO - 2025-05-05 23:08:11 --> Router Class Initialized
INFO - 2025-05-05 23:08:11 --> Config Class Initialized
INFO - 2025-05-05 23:08:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:08:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:08:11 --> Utf8 Class Initialized
INFO - 2025-05-05 23:08:11 --> URI Class Initialized
INFO - 2025-05-05 23:08:11 --> Router Class Initialized
INFO - 2025-05-05 23:08:11 --> Output Class Initialized
INFO - 2025-05-05 23:08:11 --> Security Class Initialized
DEBUG - 2025-05-05 23:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:08:11 --> Input Class Initialized
INFO - 2025-05-05 23:08:11 --> Language Class Initialized
INFO - 2025-05-05 23:08:11 --> Loader Class Initialized
INFO - 2025-05-05 23:08:11 --> Helper loaded: url_helper
INFO - 2025-05-05 23:08:11 --> Helper loaded: string_helper
INFO - 2025-05-05 23:08:11 --> Helper loaded: form_helper
INFO - 2025-05-05 23:08:11 --> Helper loaded: file_helper
INFO - 2025-05-05 23:08:11 --> Helper loaded: html_helper
INFO - 2025-05-05 23:08:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:08:11 --> Controller Class Initialized
INFO - 2025-05-05 23:09:03 --> Config Class Initialized
INFO - 2025-05-05 23:09:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:09:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:09:03 --> Utf8 Class Initialized
INFO - 2025-05-05 23:09:03 --> URI Class Initialized
INFO - 2025-05-05 23:09:03 --> Router Class Initialized
INFO - 2025-05-05 23:09:03 --> Output Class Initialized
INFO - 2025-05-05 23:09:03 --> Security Class Initialized
DEBUG - 2025-05-05 23:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:09:03 --> Input Class Initialized
INFO - 2025-05-05 23:09:03 --> Language Class Initialized
INFO - 2025-05-05 23:09:03 --> Loader Class Initialized
INFO - 2025-05-05 23:09:03 --> Helper loaded: url_helper
INFO - 2025-05-05 23:09:03 --> Helper loaded: string_helper
INFO - 2025-05-05 23:09:03 --> Helper loaded: form_helper
INFO - 2025-05-05 23:09:03 --> Helper loaded: file_helper
INFO - 2025-05-05 23:09:03 --> Helper loaded: html_helper
INFO - 2025-05-05 23:09:03 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:09:03 --> Controller Class Initialized
INFO - 2025-05-05 23:09:04 --> Config Class Initialized
INFO - 2025-05-05 23:09:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:09:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:09:04 --> Utf8 Class Initialized
INFO - 2025-05-05 23:09:04 --> URI Class Initialized
INFO - 2025-05-05 23:09:04 --> Router Class Initialized
INFO - 2025-05-05 23:09:04 --> Output Class Initialized
INFO - 2025-05-05 23:09:04 --> Security Class Initialized
DEBUG - 2025-05-05 23:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:09:04 --> Input Class Initialized
INFO - 2025-05-05 23:09:04 --> Language Class Initialized
INFO - 2025-05-05 23:09:04 --> Loader Class Initialized
INFO - 2025-05-05 23:09:04 --> Helper loaded: url_helper
INFO - 2025-05-05 23:09:04 --> Helper loaded: string_helper
INFO - 2025-05-05 23:09:04 --> Helper loaded: form_helper
INFO - 2025-05-05 23:09:04 --> Helper loaded: file_helper
INFO - 2025-05-05 23:09:04 --> Helper loaded: html_helper
INFO - 2025-05-05 23:09:04 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:09:04 --> Controller Class Initialized
INFO - 2025-05-05 23:09:05 --> Config Class Initialized
INFO - 2025-05-05 23:09:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:09:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:09:05 --> Utf8 Class Initialized
INFO - 2025-05-05 23:09:05 --> URI Class Initialized
INFO - 2025-05-05 23:09:05 --> Router Class Initialized
INFO - 2025-05-05 23:09:05 --> Output Class Initialized
INFO - 2025-05-05 23:09:05 --> Security Class Initialized
DEBUG - 2025-05-05 23:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:09:05 --> Input Class Initialized
INFO - 2025-05-05 23:09:05 --> Language Class Initialized
INFO - 2025-05-05 23:09:05 --> Loader Class Initialized
INFO - 2025-05-05 23:09:05 --> Helper loaded: url_helper
INFO - 2025-05-05 23:09:05 --> Helper loaded: string_helper
INFO - 2025-05-05 23:09:05 --> Helper loaded: form_helper
INFO - 2025-05-05 23:09:05 --> Helper loaded: file_helper
INFO - 2025-05-05 23:09:05 --> Helper loaded: html_helper
INFO - 2025-05-05 23:09:05 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:09:05 --> Controller Class Initialized
INFO - 2025-05-05 23:10:15 --> Config Class Initialized
INFO - 2025-05-05 23:10:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:10:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:10:15 --> Utf8 Class Initialized
INFO - 2025-05-05 23:10:15 --> URI Class Initialized
INFO - 2025-05-05 23:10:15 --> Router Class Initialized
INFO - 2025-05-05 23:10:15 --> Output Class Initialized
INFO - 2025-05-05 23:10:15 --> Security Class Initialized
DEBUG - 2025-05-05 23:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:10:15 --> Input Class Initialized
INFO - 2025-05-05 23:10:15 --> Language Class Initialized
INFO - 2025-05-05 23:10:15 --> Loader Class Initialized
INFO - 2025-05-05 23:10:15 --> Helper loaded: url_helper
INFO - 2025-05-05 23:10:15 --> Helper loaded: string_helper
INFO - 2025-05-05 23:10:15 --> Helper loaded: form_helper
INFO - 2025-05-05 23:10:15 --> Helper loaded: file_helper
INFO - 2025-05-05 23:10:15 --> Helper loaded: html_helper
INFO - 2025-05-05 23:10:15 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:10:15 --> Controller Class Initialized
INFO - 2025-05-05 23:10:31 --> Config Class Initialized
INFO - 2025-05-05 23:10:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:10:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:10:32 --> Utf8 Class Initialized
INFO - 2025-05-05 23:10:32 --> URI Class Initialized
INFO - 2025-05-05 23:10:32 --> Router Class Initialized
INFO - 2025-05-05 23:10:32 --> Output Class Initialized
INFO - 2025-05-05 23:10:32 --> Security Class Initialized
DEBUG - 2025-05-05 23:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:10:32 --> Input Class Initialized
INFO - 2025-05-05 23:10:32 --> Language Class Initialized
INFO - 2025-05-05 23:10:32 --> Loader Class Initialized
INFO - 2025-05-05 23:10:32 --> Helper loaded: url_helper
INFO - 2025-05-05 23:10:32 --> Helper loaded: string_helper
INFO - 2025-05-05 23:10:32 --> Helper loaded: form_helper
INFO - 2025-05-05 23:10:32 --> Helper loaded: file_helper
INFO - 2025-05-05 23:10:32 --> Helper loaded: html_helper
INFO - 2025-05-05 23:10:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:10:32 --> Controller Class Initialized
INFO - 2025-05-05 23:10:33 --> Config Class Initialized
INFO - 2025-05-05 23:10:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:10:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:10:33 --> Utf8 Class Initialized
INFO - 2025-05-05 23:10:33 --> URI Class Initialized
INFO - 2025-05-05 23:10:33 --> Router Class Initialized
INFO - 2025-05-05 23:10:33 --> Output Class Initialized
INFO - 2025-05-05 23:10:33 --> Security Class Initialized
DEBUG - 2025-05-05 23:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:10:33 --> Input Class Initialized
INFO - 2025-05-05 23:10:33 --> Language Class Initialized
INFO - 2025-05-05 23:10:33 --> Loader Class Initialized
INFO - 2025-05-05 23:10:33 --> Helper loaded: url_helper
INFO - 2025-05-05 23:10:33 --> Helper loaded: string_helper
INFO - 2025-05-05 23:10:33 --> Helper loaded: form_helper
INFO - 2025-05-05 23:10:33 --> Helper loaded: file_helper
INFO - 2025-05-05 23:10:33 --> Helper loaded: html_helper
INFO - 2025-05-05 23:10:33 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:10:33 --> Controller Class Initialized
INFO - 2025-05-05 23:11:01 --> Config Class Initialized
INFO - 2025-05-05 23:11:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:11:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:11:01 --> Utf8 Class Initialized
INFO - 2025-05-05 23:11:01 --> URI Class Initialized
INFO - 2025-05-05 23:11:01 --> Router Class Initialized
INFO - 2025-05-05 23:11:01 --> Output Class Initialized
INFO - 2025-05-05 23:11:01 --> Security Class Initialized
DEBUG - 2025-05-05 23:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:11:01 --> Input Class Initialized
INFO - 2025-05-05 23:11:01 --> Language Class Initialized
INFO - 2025-05-05 23:11:01 --> Loader Class Initialized
INFO - 2025-05-05 23:11:01 --> Helper loaded: url_helper
INFO - 2025-05-05 23:11:01 --> Helper loaded: string_helper
INFO - 2025-05-05 23:11:01 --> Helper loaded: form_helper
INFO - 2025-05-05 23:11:01 --> Helper loaded: file_helper
INFO - 2025-05-05 23:11:01 --> Helper loaded: html_helper
INFO - 2025-05-05 23:11:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:11:01 --> Controller Class Initialized
INFO - 2025-05-05 23:11:30 --> Config Class Initialized
INFO - 2025-05-05 23:11:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:11:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:11:30 --> Utf8 Class Initialized
INFO - 2025-05-05 23:11:30 --> URI Class Initialized
INFO - 2025-05-05 23:11:30 --> Router Class Initialized
INFO - 2025-05-05 23:11:30 --> Output Class Initialized
INFO - 2025-05-05 23:11:30 --> Security Class Initialized
DEBUG - 2025-05-05 23:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:11:30 --> Input Class Initialized
INFO - 2025-05-05 23:11:30 --> Language Class Initialized
INFO - 2025-05-05 23:11:30 --> Loader Class Initialized
INFO - 2025-05-05 23:11:30 --> Helper loaded: url_helper
INFO - 2025-05-05 23:11:30 --> Helper loaded: string_helper
INFO - 2025-05-05 23:11:30 --> Helper loaded: form_helper
INFO - 2025-05-05 23:11:30 --> Helper loaded: file_helper
INFO - 2025-05-05 23:11:30 --> Helper loaded: html_helper
INFO - 2025-05-05 23:11:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:11:30 --> Controller Class Initialized
INFO - 2025-05-05 23:11:42 --> Config Class Initialized
INFO - 2025-05-05 23:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:11:42 --> Utf8 Class Initialized
INFO - 2025-05-05 23:11:42 --> URI Class Initialized
INFO - 2025-05-05 23:11:42 --> Router Class Initialized
INFO - 2025-05-05 23:11:42 --> Output Class Initialized
INFO - 2025-05-05 23:11:42 --> Security Class Initialized
DEBUG - 2025-05-05 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:11:42 --> Input Class Initialized
INFO - 2025-05-05 23:11:42 --> Language Class Initialized
INFO - 2025-05-05 23:11:42 --> Loader Class Initialized
INFO - 2025-05-05 23:11:42 --> Helper loaded: url_helper
INFO - 2025-05-05 23:11:42 --> Helper loaded: string_helper
INFO - 2025-05-05 23:11:42 --> Helper loaded: form_helper
INFO - 2025-05-05 23:11:42 --> Helper loaded: file_helper
INFO - 2025-05-05 23:11:42 --> Helper loaded: html_helper
INFO - 2025-05-05 23:11:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:11:42 --> Controller Class Initialized
INFO - 2025-05-05 23:12:16 --> Config Class Initialized
INFO - 2025-05-05 23:12:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:12:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:12:17 --> Utf8 Class Initialized
INFO - 2025-05-05 23:12:17 --> URI Class Initialized
INFO - 2025-05-05 23:12:17 --> Router Class Initialized
INFO - 2025-05-05 23:12:17 --> Output Class Initialized
INFO - 2025-05-05 23:12:17 --> Security Class Initialized
DEBUG - 2025-05-05 23:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:12:17 --> Input Class Initialized
INFO - 2025-05-05 23:12:17 --> Language Class Initialized
INFO - 2025-05-05 23:12:17 --> Loader Class Initialized
INFO - 2025-05-05 23:12:17 --> Helper loaded: url_helper
INFO - 2025-05-05 23:12:17 --> Helper loaded: string_helper
INFO - 2025-05-05 23:12:17 --> Helper loaded: form_helper
INFO - 2025-05-05 23:12:17 --> Helper loaded: file_helper
INFO - 2025-05-05 23:12:17 --> Helper loaded: html_helper
INFO - 2025-05-05 23:12:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:12:17 --> Controller Class Initialized
INFO - 2025-05-05 23:12:20 --> Config Class Initialized
INFO - 2025-05-05 23:12:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:12:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:12:20 --> Utf8 Class Initialized
INFO - 2025-05-05 23:12:20 --> URI Class Initialized
INFO - 2025-05-05 23:12:20 --> Router Class Initialized
INFO - 2025-05-05 23:12:20 --> Output Class Initialized
INFO - 2025-05-05 23:12:20 --> Security Class Initialized
DEBUG - 2025-05-05 23:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:12:20 --> Input Class Initialized
INFO - 2025-05-05 23:12:20 --> Language Class Initialized
INFO - 2025-05-05 23:12:20 --> Loader Class Initialized
INFO - 2025-05-05 23:12:20 --> Helper loaded: url_helper
INFO - 2025-05-05 23:12:20 --> Helper loaded: string_helper
INFO - 2025-05-05 23:12:20 --> Helper loaded: form_helper
INFO - 2025-05-05 23:12:20 --> Helper loaded: file_helper
INFO - 2025-05-05 23:12:20 --> Helper loaded: html_helper
INFO - 2025-05-05 23:12:20 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:12:20 --> Controller Class Initialized
INFO - 2025-05-05 23:13:28 --> Config Class Initialized
INFO - 2025-05-05 23:13:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:13:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:13:28 --> Utf8 Class Initialized
INFO - 2025-05-05 23:13:28 --> URI Class Initialized
INFO - 2025-05-05 23:13:28 --> Router Class Initialized
INFO - 2025-05-05 23:13:28 --> Output Class Initialized
INFO - 2025-05-05 23:13:28 --> Security Class Initialized
DEBUG - 2025-05-05 23:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:13:28 --> Input Class Initialized
INFO - 2025-05-05 23:13:28 --> Language Class Initialized
INFO - 2025-05-05 23:13:28 --> Loader Class Initialized
INFO - 2025-05-05 23:13:28 --> Helper loaded: url_helper
INFO - 2025-05-05 23:13:28 --> Helper loaded: string_helper
INFO - 2025-05-05 23:13:28 --> Helper loaded: form_helper
INFO - 2025-05-05 23:13:28 --> Helper loaded: file_helper
INFO - 2025-05-05 23:13:28 --> Helper loaded: html_helper
INFO - 2025-05-05 23:13:28 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:13:28 --> Controller Class Initialized
INFO - 2025-05-05 23:14:21 --> Config Class Initialized
INFO - 2025-05-05 23:14:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:21 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:21 --> URI Class Initialized
INFO - 2025-05-05 23:14:21 --> Router Class Initialized
INFO - 2025-05-05 23:14:21 --> Output Class Initialized
INFO - 2025-05-05 23:14:21 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:21 --> Input Class Initialized
INFO - 2025-05-05 23:14:21 --> Language Class Initialized
INFO - 2025-05-05 23:14:21 --> Loader Class Initialized
INFO - 2025-05-05 23:14:21 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:21 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:21 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:21 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:21 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:21 --> Controller Class Initialized
INFO - 2025-05-05 23:14:22 --> Config Class Initialized
INFO - 2025-05-05 23:14:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:22 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:22 --> URI Class Initialized
INFO - 2025-05-05 23:14:22 --> Router Class Initialized
INFO - 2025-05-05 23:14:22 --> Output Class Initialized
INFO - 2025-05-05 23:14:22 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:22 --> Input Class Initialized
INFO - 2025-05-05 23:14:22 --> Language Class Initialized
INFO - 2025-05-05 23:14:22 --> Loader Class Initialized
INFO - 2025-05-05 23:14:22 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:22 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:22 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:22 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:22 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:22 --> Controller Class Initialized
INFO - 2025-05-05 23:14:27 --> Config Class Initialized
INFO - 2025-05-05 23:14:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:27 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:27 --> URI Class Initialized
INFO - 2025-05-05 23:14:27 --> Router Class Initialized
INFO - 2025-05-05 23:14:27 --> Output Class Initialized
INFO - 2025-05-05 23:14:27 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:27 --> Input Class Initialized
INFO - 2025-05-05 23:14:27 --> Language Class Initialized
INFO - 2025-05-05 23:14:27 --> Loader Class Initialized
INFO - 2025-05-05 23:14:27 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:27 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:27 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:27 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:27 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:27 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:27 --> Controller Class Initialized
INFO - 2025-05-05 23:14:35 --> Config Class Initialized
INFO - 2025-05-05 23:14:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:35 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:35 --> URI Class Initialized
INFO - 2025-05-05 23:14:35 --> Router Class Initialized
INFO - 2025-05-05 23:14:35 --> Output Class Initialized
INFO - 2025-05-05 23:14:35 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:35 --> Input Class Initialized
INFO - 2025-05-05 23:14:35 --> Language Class Initialized
INFO - 2025-05-05 23:14:35 --> Loader Class Initialized
INFO - 2025-05-05 23:14:35 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:35 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:35 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:35 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:35 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:35 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:35 --> Controller Class Initialized
INFO - 2025-05-05 23:14:45 --> Config Class Initialized
INFO - 2025-05-05 23:14:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:45 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:45 --> URI Class Initialized
INFO - 2025-05-05 23:14:45 --> Router Class Initialized
INFO - 2025-05-05 23:14:45 --> Output Class Initialized
INFO - 2025-05-05 23:14:45 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:45 --> Input Class Initialized
INFO - 2025-05-05 23:14:45 --> Language Class Initialized
INFO - 2025-05-05 23:14:45 --> Loader Class Initialized
INFO - 2025-05-05 23:14:45 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:45 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:45 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:45 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:45 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:45 --> Controller Class Initialized
INFO - 2025-05-05 23:14:47 --> Config Class Initialized
INFO - 2025-05-05 23:14:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:47 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:47 --> URI Class Initialized
INFO - 2025-05-05 23:14:47 --> Router Class Initialized
INFO - 2025-05-05 23:14:47 --> Output Class Initialized
INFO - 2025-05-05 23:14:47 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:47 --> Input Class Initialized
INFO - 2025-05-05 23:14:47 --> Language Class Initialized
INFO - 2025-05-05 23:14:47 --> Loader Class Initialized
INFO - 2025-05-05 23:14:47 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:47 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:47 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:47 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:47 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:47 --> Controller Class Initialized
INFO - 2025-05-05 23:14:48 --> Config Class Initialized
INFO - 2025-05-05 23:14:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:48 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:48 --> URI Class Initialized
INFO - 2025-05-05 23:14:48 --> Router Class Initialized
INFO - 2025-05-05 23:14:48 --> Output Class Initialized
INFO - 2025-05-05 23:14:48 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:48 --> Input Class Initialized
INFO - 2025-05-05 23:14:48 --> Language Class Initialized
INFO - 2025-05-05 23:14:48 --> Loader Class Initialized
INFO - 2025-05-05 23:14:48 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:48 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:48 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:48 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:48 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:48 --> Controller Class Initialized
INFO - 2025-05-05 23:14:50 --> Config Class Initialized
INFO - 2025-05-05 23:14:50 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:50 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:50 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:50 --> URI Class Initialized
DEBUG - 2025-05-05 23:14:50 --> No URI present. Default controller set.
INFO - 2025-05-05 23:14:50 --> Router Class Initialized
INFO - 2025-05-05 23:14:50 --> Output Class Initialized
INFO - 2025-05-05 23:14:50 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:50 --> Input Class Initialized
INFO - 2025-05-05 23:14:50 --> Language Class Initialized
INFO - 2025-05-05 23:14:50 --> Loader Class Initialized
INFO - 2025-05-05 23:14:50 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:50 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:50 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:50 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:50 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:50 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:50 --> Controller Class Initialized
INFO - 2025-05-05 23:14:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:14:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:14:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 23:14:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:14:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:14:51 --> Final output sent to browser
DEBUG - 2025-05-05 23:14:51 --> Total execution time: 0.0947
INFO - 2025-05-05 23:14:52 --> Config Class Initialized
INFO - 2025-05-05 23:14:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:52 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:52 --> URI Class Initialized
INFO - 2025-05-05 23:14:52 --> Router Class Initialized
INFO - 2025-05-05 23:14:52 --> Output Class Initialized
INFO - 2025-05-05 23:14:52 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:52 --> Input Class Initialized
INFO - 2025-05-05 23:14:52 --> Language Class Initialized
INFO - 2025-05-05 23:14:52 --> Loader Class Initialized
INFO - 2025-05-05 23:14:52 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:52 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:52 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:52 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:52 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:52 --> Controller Class Initialized
INFO - 2025-05-05 23:14:56 --> Config Class Initialized
INFO - 2025-05-05 23:14:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:14:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:14:56 --> Utf8 Class Initialized
INFO - 2025-05-05 23:14:56 --> URI Class Initialized
INFO - 2025-05-05 23:14:56 --> Router Class Initialized
INFO - 2025-05-05 23:14:56 --> Output Class Initialized
INFO - 2025-05-05 23:14:56 --> Security Class Initialized
DEBUG - 2025-05-05 23:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:14:56 --> Input Class Initialized
INFO - 2025-05-05 23:14:56 --> Language Class Initialized
INFO - 2025-05-05 23:14:56 --> Loader Class Initialized
INFO - 2025-05-05 23:14:56 --> Helper loaded: url_helper
INFO - 2025-05-05 23:14:56 --> Helper loaded: string_helper
INFO - 2025-05-05 23:14:57 --> Helper loaded: form_helper
INFO - 2025-05-05 23:14:57 --> Helper loaded: file_helper
INFO - 2025-05-05 23:14:57 --> Helper loaded: html_helper
INFO - 2025-05-05 23:14:57 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:14:57 --> Controller Class Initialized
INFO - 2025-05-05 23:15:29 --> Config Class Initialized
INFO - 2025-05-05 23:15:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:15:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:15:29 --> Utf8 Class Initialized
INFO - 2025-05-05 23:15:29 --> URI Class Initialized
INFO - 2025-05-05 23:15:29 --> Router Class Initialized
INFO - 2025-05-05 23:15:29 --> Output Class Initialized
INFO - 2025-05-05 23:15:29 --> Security Class Initialized
DEBUG - 2025-05-05 23:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:15:29 --> Input Class Initialized
INFO - 2025-05-05 23:15:29 --> Language Class Initialized
INFO - 2025-05-05 23:15:29 --> Loader Class Initialized
INFO - 2025-05-05 23:15:29 --> Helper loaded: url_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: string_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: form_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: file_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: html_helper
INFO - 2025-05-05 23:15:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:15:29 --> Controller Class Initialized
INFO - 2025-05-05 23:15:29 --> Config Class Initialized
INFO - 2025-05-05 23:15:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:15:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:15:29 --> Utf8 Class Initialized
INFO - 2025-05-05 23:15:29 --> URI Class Initialized
INFO - 2025-05-05 23:15:29 --> Router Class Initialized
INFO - 2025-05-05 23:15:29 --> Output Class Initialized
INFO - 2025-05-05 23:15:29 --> Security Class Initialized
DEBUG - 2025-05-05 23:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:15:29 --> Input Class Initialized
INFO - 2025-05-05 23:15:29 --> Language Class Initialized
INFO - 2025-05-05 23:15:29 --> Loader Class Initialized
INFO - 2025-05-05 23:15:29 --> Helper loaded: url_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: string_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: form_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: file_helper
INFO - 2025-05-05 23:15:29 --> Helper loaded: html_helper
INFO - 2025-05-05 23:15:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:15:29 --> Controller Class Initialized
INFO - 2025-05-05 23:15:37 --> Config Class Initialized
INFO - 2025-05-05 23:15:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:15:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:15:37 --> Utf8 Class Initialized
INFO - 2025-05-05 23:15:37 --> URI Class Initialized
INFO - 2025-05-05 23:15:37 --> Router Class Initialized
INFO - 2025-05-05 23:15:37 --> Output Class Initialized
INFO - 2025-05-05 23:15:37 --> Security Class Initialized
DEBUG - 2025-05-05 23:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:15:37 --> Input Class Initialized
INFO - 2025-05-05 23:15:37 --> Language Class Initialized
INFO - 2025-05-05 23:15:37 --> Loader Class Initialized
INFO - 2025-05-05 23:15:37 --> Helper loaded: url_helper
INFO - 2025-05-05 23:15:37 --> Helper loaded: string_helper
INFO - 2025-05-05 23:15:37 --> Helper loaded: form_helper
INFO - 2025-05-05 23:15:37 --> Helper loaded: file_helper
INFO - 2025-05-05 23:15:37 --> Helper loaded: html_helper
INFO - 2025-05-05 23:15:37 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:15:37 --> Controller Class Initialized
INFO - 2025-05-05 23:15:49 --> Config Class Initialized
INFO - 2025-05-05 23:15:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:15:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:15:49 --> Utf8 Class Initialized
INFO - 2025-05-05 23:15:49 --> URI Class Initialized
INFO - 2025-05-05 23:15:49 --> Router Class Initialized
INFO - 2025-05-05 23:15:49 --> Output Class Initialized
INFO - 2025-05-05 23:15:49 --> Security Class Initialized
DEBUG - 2025-05-05 23:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:15:49 --> Input Class Initialized
INFO - 2025-05-05 23:15:49 --> Language Class Initialized
INFO - 2025-05-05 23:15:49 --> Loader Class Initialized
INFO - 2025-05-05 23:15:49 --> Helper loaded: url_helper
INFO - 2025-05-05 23:15:49 --> Helper loaded: string_helper
INFO - 2025-05-05 23:15:49 --> Helper loaded: form_helper
INFO - 2025-05-05 23:15:49 --> Helper loaded: file_helper
INFO - 2025-05-05 23:15:49 --> Helper loaded: html_helper
INFO - 2025-05-05 23:15:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:15:49 --> Controller Class Initialized
INFO - 2025-05-05 23:15:51 --> Config Class Initialized
INFO - 2025-05-05 23:15:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:15:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:15:51 --> Utf8 Class Initialized
INFO - 2025-05-05 23:15:51 --> URI Class Initialized
INFO - 2025-05-05 23:15:51 --> Router Class Initialized
INFO - 2025-05-05 23:15:51 --> Output Class Initialized
INFO - 2025-05-05 23:15:51 --> Security Class Initialized
DEBUG - 2025-05-05 23:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:15:51 --> Input Class Initialized
INFO - 2025-05-05 23:15:51 --> Language Class Initialized
INFO - 2025-05-05 23:15:51 --> Loader Class Initialized
INFO - 2025-05-05 23:15:51 --> Helper loaded: url_helper
INFO - 2025-05-05 23:15:51 --> Helper loaded: string_helper
INFO - 2025-05-05 23:15:51 --> Helper loaded: form_helper
INFO - 2025-05-05 23:15:51 --> Helper loaded: file_helper
INFO - 2025-05-05 23:15:51 --> Helper loaded: html_helper
INFO - 2025-05-05 23:15:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:15:51 --> Controller Class Initialized
INFO - 2025-05-05 23:16:00 --> Config Class Initialized
INFO - 2025-05-05 23:16:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:00 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:00 --> URI Class Initialized
INFO - 2025-05-05 23:16:00 --> Router Class Initialized
INFO - 2025-05-05 23:16:00 --> Output Class Initialized
INFO - 2025-05-05 23:16:00 --> Security Class Initialized
DEBUG - 2025-05-05 23:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:00 --> Input Class Initialized
INFO - 2025-05-05 23:16:00 --> Language Class Initialized
INFO - 2025-05-05 23:16:00 --> Loader Class Initialized
INFO - 2025-05-05 23:16:00 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:00 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:00 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:00 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:00 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:00 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:00 --> Controller Class Initialized
INFO - 2025-05-05 23:16:01 --> Config Class Initialized
INFO - 2025-05-05 23:16:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:01 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:01 --> URI Class Initialized
INFO - 2025-05-05 23:16:01 --> Router Class Initialized
INFO - 2025-05-05 23:16:01 --> Output Class Initialized
INFO - 2025-05-05 23:16:01 --> Security Class Initialized
DEBUG - 2025-05-05 23:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:01 --> Input Class Initialized
INFO - 2025-05-05 23:16:01 --> Language Class Initialized
INFO - 2025-05-05 23:16:01 --> Loader Class Initialized
INFO - 2025-05-05 23:16:01 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:01 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:01 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:01 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:01 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:01 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:01 --> Controller Class Initialized
INFO - 2025-05-05 23:16:09 --> Config Class Initialized
INFO - 2025-05-05 23:16:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:09 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:09 --> URI Class Initialized
INFO - 2025-05-05 23:16:09 --> Router Class Initialized
INFO - 2025-05-05 23:16:09 --> Output Class Initialized
INFO - 2025-05-05 23:16:09 --> Security Class Initialized
DEBUG - 2025-05-05 23:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:09 --> Input Class Initialized
INFO - 2025-05-05 23:16:09 --> Language Class Initialized
INFO - 2025-05-05 23:16:09 --> Loader Class Initialized
INFO - 2025-05-05 23:16:09 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:09 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:09 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:09 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:09 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:09 --> Controller Class Initialized
INFO - 2025-05-05 23:16:12 --> Config Class Initialized
INFO - 2025-05-05 23:16:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:12 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:12 --> URI Class Initialized
DEBUG - 2025-05-05 23:16:12 --> No URI present. Default controller set.
INFO - 2025-05-05 23:16:12 --> Router Class Initialized
INFO - 2025-05-05 23:16:12 --> Output Class Initialized
INFO - 2025-05-05 23:16:12 --> Security Class Initialized
DEBUG - 2025-05-05 23:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:12 --> Input Class Initialized
INFO - 2025-05-05 23:16:12 --> Language Class Initialized
INFO - 2025-05-05 23:16:12 --> Loader Class Initialized
INFO - 2025-05-05 23:16:12 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:12 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:12 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:12 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:12 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:12 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:12 --> Controller Class Initialized
INFO - 2025-05-05 23:16:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:16:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:16:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 23:16:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:16:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:16:12 --> Final output sent to browser
DEBUG - 2025-05-05 23:16:12 --> Total execution time: 0.1093
INFO - 2025-05-05 23:16:16 --> Config Class Initialized
INFO - 2025-05-05 23:16:16 --> Hooks Class Initialized
INFO - 2025-05-05 23:16:16 --> Config Class Initialized
INFO - 2025-05-05 23:16:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:16 --> Utf8 Class Initialized
DEBUG - 2025-05-05 23:16:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:16 --> URI Class Initialized
INFO - 2025-05-05 23:16:16 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:16 --> URI Class Initialized
INFO - 2025-05-05 23:16:16 --> Router Class Initialized
INFO - 2025-05-05 23:16:16 --> Router Class Initialized
INFO - 2025-05-05 23:16:16 --> Output Class Initialized
INFO - 2025-05-05 23:16:16 --> Security Class Initialized
INFO - 2025-05-05 23:16:16 --> Output Class Initialized
DEBUG - 2025-05-05 23:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:16 --> Security Class Initialized
INFO - 2025-05-05 23:16:16 --> Input Class Initialized
INFO - 2025-05-05 23:16:16 --> Language Class Initialized
DEBUG - 2025-05-05 23:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:16 --> Input Class Initialized
INFO - 2025-05-05 23:16:16 --> Language Class Initialized
INFO - 2025-05-05 23:16:16 --> Loader Class Initialized
INFO - 2025-05-05 23:16:16 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:16 --> Loader Class Initialized
INFO - 2025-05-05 23:16:16 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:16 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:16 --> Database Driver Class Initialized
INFO - 2025-05-05 23:16:16 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:16 --> Controller Class Initialized
INFO - 2025-05-05 23:16:16 --> Model "CompanyModel" initialized
DEBUG - 2025-05-05 23:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:16:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:16:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:16:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:16:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:16:16 --> Final output sent to browser
DEBUG - 2025-05-05 23:16:16 --> Total execution time: 0.1207
INFO - 2025-05-05 23:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:16 --> Controller Class Initialized
INFO - 2025-05-05 23:16:17 --> Config Class Initialized
INFO - 2025-05-05 23:16:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:16:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:16:17 --> Utf8 Class Initialized
INFO - 2025-05-05 23:16:17 --> URI Class Initialized
INFO - 2025-05-05 23:16:17 --> Router Class Initialized
INFO - 2025-05-05 23:16:17 --> Output Class Initialized
INFO - 2025-05-05 23:16:17 --> Security Class Initialized
DEBUG - 2025-05-05 23:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:16:17 --> Input Class Initialized
INFO - 2025-05-05 23:16:17 --> Language Class Initialized
INFO - 2025-05-05 23:16:17 --> Loader Class Initialized
INFO - 2025-05-05 23:16:17 --> Helper loaded: url_helper
INFO - 2025-05-05 23:16:17 --> Helper loaded: string_helper
INFO - 2025-05-05 23:16:17 --> Helper loaded: form_helper
INFO - 2025-05-05 23:16:17 --> Helper loaded: file_helper
INFO - 2025-05-05 23:16:17 --> Helper loaded: html_helper
INFO - 2025-05-05 23:16:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:16:17 --> Controller Class Initialized
INFO - 2025-05-05 23:32:56 --> Config Class Initialized
INFO - 2025-05-05 23:32:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:32:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:32:56 --> Utf8 Class Initialized
INFO - 2025-05-05 23:32:56 --> URI Class Initialized
INFO - 2025-05-05 23:32:56 --> Router Class Initialized
INFO - 2025-05-05 23:32:56 --> Output Class Initialized
INFO - 2025-05-05 23:32:56 --> Security Class Initialized
DEBUG - 2025-05-05 23:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:32:56 --> Input Class Initialized
INFO - 2025-05-05 23:32:56 --> Language Class Initialized
INFO - 2025-05-05 23:32:56 --> Loader Class Initialized
INFO - 2025-05-05 23:32:56 --> Helper loaded: url_helper
INFO - 2025-05-05 23:32:56 --> Helper loaded: string_helper
INFO - 2025-05-05 23:32:56 --> Helper loaded: form_helper
INFO - 2025-05-05 23:32:56 --> Helper loaded: file_helper
INFO - 2025-05-05 23:32:56 --> Helper loaded: html_helper
INFO - 2025-05-05 23:32:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:32:57 --> Controller Class Initialized
INFO - 2025-05-05 23:32:59 --> Config Class Initialized
INFO - 2025-05-05 23:32:59 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:32:59 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:32:59 --> Utf8 Class Initialized
INFO - 2025-05-05 23:32:59 --> URI Class Initialized
INFO - 2025-05-05 23:32:59 --> Router Class Initialized
INFO - 2025-05-05 23:32:59 --> Output Class Initialized
INFO - 2025-05-05 23:32:59 --> Security Class Initialized
DEBUG - 2025-05-05 23:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:32:59 --> Input Class Initialized
INFO - 2025-05-05 23:32:59 --> Language Class Initialized
INFO - 2025-05-05 23:32:59 --> Loader Class Initialized
INFO - 2025-05-05 23:32:59 --> Helper loaded: url_helper
INFO - 2025-05-05 23:32:59 --> Helper loaded: string_helper
INFO - 2025-05-05 23:32:59 --> Helper loaded: form_helper
INFO - 2025-05-05 23:32:59 --> Helper loaded: file_helper
INFO - 2025-05-05 23:32:59 --> Helper loaded: html_helper
INFO - 2025-05-05 23:32:59 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:32:59 --> Controller Class Initialized
INFO - 2025-05-05 23:33:10 --> Config Class Initialized
INFO - 2025-05-05 23:33:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:11 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:11 --> URI Class Initialized
INFO - 2025-05-05 23:33:11 --> Router Class Initialized
INFO - 2025-05-05 23:33:11 --> Output Class Initialized
INFO - 2025-05-05 23:33:11 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:11 --> Input Class Initialized
INFO - 2025-05-05 23:33:11 --> Language Class Initialized
INFO - 2025-05-05 23:33:11 --> Loader Class Initialized
INFO - 2025-05-05 23:33:11 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:11 --> Controller Class Initialized
INFO - 2025-05-05 23:33:11 --> Config Class Initialized
INFO - 2025-05-05 23:33:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:11 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:11 --> URI Class Initialized
INFO - 2025-05-05 23:33:11 --> Router Class Initialized
INFO - 2025-05-05 23:33:11 --> Output Class Initialized
INFO - 2025-05-05 23:33:11 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:11 --> Input Class Initialized
INFO - 2025-05-05 23:33:11 --> Language Class Initialized
INFO - 2025-05-05 23:33:11 --> Loader Class Initialized
INFO - 2025-05-05 23:33:11 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:11 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:11 --> Controller Class Initialized
INFO - 2025-05-05 23:33:23 --> Config Class Initialized
INFO - 2025-05-05 23:33:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:23 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:23 --> URI Class Initialized
INFO - 2025-05-05 23:33:23 --> Router Class Initialized
INFO - 2025-05-05 23:33:23 --> Output Class Initialized
INFO - 2025-05-05 23:33:23 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:23 --> Input Class Initialized
INFO - 2025-05-05 23:33:23 --> Language Class Initialized
INFO - 2025-05-05 23:33:23 --> Loader Class Initialized
INFO - 2025-05-05 23:33:23 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:23 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:23 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:23 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:23 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:23 --> Controller Class Initialized
INFO - 2025-05-05 23:33:48 --> Config Class Initialized
INFO - 2025-05-05 23:33:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:48 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:48 --> URI Class Initialized
INFO - 2025-05-05 23:33:48 --> Router Class Initialized
INFO - 2025-05-05 23:33:48 --> Output Class Initialized
INFO - 2025-05-05 23:33:48 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:48 --> Input Class Initialized
INFO - 2025-05-05 23:33:48 --> Language Class Initialized
INFO - 2025-05-05 23:33:48 --> Loader Class Initialized
INFO - 2025-05-05 23:33:48 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:48 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:48 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:48 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:48 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:48 --> Controller Class Initialized
INFO - 2025-05-05 23:33:49 --> Config Class Initialized
INFO - 2025-05-05 23:33:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:49 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:49 --> URI Class Initialized
INFO - 2025-05-05 23:33:49 --> Router Class Initialized
INFO - 2025-05-05 23:33:49 --> Output Class Initialized
INFO - 2025-05-05 23:33:49 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:49 --> Input Class Initialized
INFO - 2025-05-05 23:33:49 --> Language Class Initialized
INFO - 2025-05-05 23:33:49 --> Loader Class Initialized
INFO - 2025-05-05 23:33:49 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:49 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:49 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:49 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:49 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:49 --> Controller Class Initialized
INFO - 2025-05-05 23:33:51 --> Config Class Initialized
INFO - 2025-05-05 23:33:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:51 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:51 --> URI Class Initialized
INFO - 2025-05-05 23:33:51 --> Router Class Initialized
INFO - 2025-05-05 23:33:51 --> Output Class Initialized
INFO - 2025-05-05 23:33:51 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:51 --> Input Class Initialized
INFO - 2025-05-05 23:33:51 --> Language Class Initialized
INFO - 2025-05-05 23:33:51 --> Loader Class Initialized
INFO - 2025-05-05 23:33:51 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:51 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:51 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:51 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:51 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:51 --> Controller Class Initialized
INFO - 2025-05-05 23:33:53 --> Config Class Initialized
INFO - 2025-05-05 23:33:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:53 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:53 --> URI Class Initialized
DEBUG - 2025-05-05 23:33:53 --> No URI present. Default controller set.
INFO - 2025-05-05 23:33:53 --> Router Class Initialized
INFO - 2025-05-05 23:33:53 --> Output Class Initialized
INFO - 2025-05-05 23:33:53 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:53 --> Input Class Initialized
INFO - 2025-05-05 23:33:53 --> Language Class Initialized
INFO - 2025-05-05 23:33:53 --> Loader Class Initialized
INFO - 2025-05-05 23:33:53 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:53 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:53 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:53 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:53 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:53 --> Controller Class Initialized
INFO - 2025-05-05 23:33:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:33:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:33:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 23:33:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:33:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:33:53 --> Final output sent to browser
DEBUG - 2025-05-05 23:33:53 --> Total execution time: 0.0748
INFO - 2025-05-05 23:33:54 --> Config Class Initialized
INFO - 2025-05-05 23:33:54 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:54 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:54 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:54 --> URI Class Initialized
INFO - 2025-05-05 23:33:54 --> Router Class Initialized
INFO - 2025-05-05 23:33:54 --> Output Class Initialized
INFO - 2025-05-05 23:33:54 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:54 --> Input Class Initialized
INFO - 2025-05-05 23:33:54 --> Language Class Initialized
INFO - 2025-05-05 23:33:54 --> Loader Class Initialized
INFO - 2025-05-05 23:33:54 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:54 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:54 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:54 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:54 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:54 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:54 --> Controller Class Initialized
INFO - 2025-05-05 23:33:56 --> Config Class Initialized
INFO - 2025-05-05 23:33:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:56 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:56 --> URI Class Initialized
INFO - 2025-05-05 23:33:56 --> Router Class Initialized
INFO - 2025-05-05 23:33:56 --> Output Class Initialized
INFO - 2025-05-05 23:33:56 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:56 --> Input Class Initialized
INFO - 2025-05-05 23:33:56 --> Language Class Initialized
INFO - 2025-05-05 23:33:56 --> Loader Class Initialized
INFO - 2025-05-05 23:33:56 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:56 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:56 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:56 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:56 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:56 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:56 --> Controller Class Initialized
INFO - 2025-05-05 23:33:56 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:33:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:33:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:33:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:33:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:33:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:33:57 --> Final output sent to browser
DEBUG - 2025-05-05 23:33:57 --> Total execution time: 0.1569
INFO - 2025-05-05 23:33:58 --> Config Class Initialized
INFO - 2025-05-05 23:33:58 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:33:58 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:33:58 --> Utf8 Class Initialized
INFO - 2025-05-05 23:33:58 --> URI Class Initialized
INFO - 2025-05-05 23:33:58 --> Router Class Initialized
INFO - 2025-05-05 23:33:58 --> Output Class Initialized
INFO - 2025-05-05 23:33:58 --> Security Class Initialized
DEBUG - 2025-05-05 23:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:33:58 --> Input Class Initialized
INFO - 2025-05-05 23:33:58 --> Language Class Initialized
INFO - 2025-05-05 23:33:58 --> Loader Class Initialized
INFO - 2025-05-05 23:33:58 --> Helper loaded: url_helper
INFO - 2025-05-05 23:33:58 --> Helper loaded: string_helper
INFO - 2025-05-05 23:33:58 --> Helper loaded: form_helper
INFO - 2025-05-05 23:33:58 --> Helper loaded: file_helper
INFO - 2025-05-05 23:33:58 --> Helper loaded: html_helper
INFO - 2025-05-05 23:33:58 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:33:58 --> Controller Class Initialized
INFO - 2025-05-05 23:35:18 --> Config Class Initialized
INFO - 2025-05-05 23:35:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:35:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:35:18 --> Utf8 Class Initialized
INFO - 2025-05-05 23:35:18 --> URI Class Initialized
INFO - 2025-05-05 23:35:18 --> Router Class Initialized
INFO - 2025-05-05 23:35:18 --> Output Class Initialized
INFO - 2025-05-05 23:35:18 --> Security Class Initialized
DEBUG - 2025-05-05 23:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:35:18 --> Input Class Initialized
INFO - 2025-05-05 23:35:18 --> Language Class Initialized
INFO - 2025-05-05 23:35:18 --> Loader Class Initialized
INFO - 2025-05-05 23:35:18 --> Helper loaded: url_helper
INFO - 2025-05-05 23:35:18 --> Helper loaded: string_helper
INFO - 2025-05-05 23:35:18 --> Helper loaded: form_helper
INFO - 2025-05-05 23:35:18 --> Helper loaded: file_helper
INFO - 2025-05-05 23:35:18 --> Helper loaded: html_helper
INFO - 2025-05-05 23:35:18 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:35:18 --> Controller Class Initialized
INFO - 2025-05-05 23:35:26 --> Config Class Initialized
INFO - 2025-05-05 23:35:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:35:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:35:26 --> Utf8 Class Initialized
INFO - 2025-05-05 23:35:26 --> URI Class Initialized
INFO - 2025-05-05 23:35:26 --> Router Class Initialized
INFO - 2025-05-05 23:35:26 --> Output Class Initialized
INFO - 2025-05-05 23:35:26 --> Security Class Initialized
DEBUG - 2025-05-05 23:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:35:26 --> Input Class Initialized
INFO - 2025-05-05 23:35:26 --> Language Class Initialized
INFO - 2025-05-05 23:35:26 --> Loader Class Initialized
INFO - 2025-05-05 23:35:26 --> Helper loaded: url_helper
INFO - 2025-05-05 23:35:26 --> Helper loaded: string_helper
INFO - 2025-05-05 23:35:26 --> Helper loaded: form_helper
INFO - 2025-05-05 23:35:26 --> Helper loaded: file_helper
INFO - 2025-05-05 23:35:26 --> Helper loaded: html_helper
INFO - 2025-05-05 23:35:26 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:35:26 --> Controller Class Initialized
INFO - 2025-05-05 23:36:09 --> Config Class Initialized
INFO - 2025-05-05 23:36:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:36:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:36:09 --> Utf8 Class Initialized
INFO - 2025-05-05 23:36:09 --> URI Class Initialized
INFO - 2025-05-05 23:36:09 --> Router Class Initialized
INFO - 2025-05-05 23:36:09 --> Output Class Initialized
INFO - 2025-05-05 23:36:09 --> Security Class Initialized
DEBUG - 2025-05-05 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:36:09 --> Input Class Initialized
INFO - 2025-05-05 23:36:09 --> Language Class Initialized
INFO - 2025-05-05 23:36:09 --> Loader Class Initialized
INFO - 2025-05-05 23:36:09 --> Helper loaded: url_helper
INFO - 2025-05-05 23:36:09 --> Helper loaded: string_helper
INFO - 2025-05-05 23:36:09 --> Helper loaded: form_helper
INFO - 2025-05-05 23:36:09 --> Helper loaded: file_helper
INFO - 2025-05-05 23:36:09 --> Helper loaded: html_helper
INFO - 2025-05-05 23:36:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:36:09 --> Controller Class Initialized
INFO - 2025-05-05 23:36:17 --> Config Class Initialized
INFO - 2025-05-05 23:36:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:36:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:36:17 --> Utf8 Class Initialized
INFO - 2025-05-05 23:36:17 --> URI Class Initialized
INFO - 2025-05-05 23:36:17 --> Router Class Initialized
INFO - 2025-05-05 23:36:17 --> Output Class Initialized
INFO - 2025-05-05 23:36:17 --> Security Class Initialized
DEBUG - 2025-05-05 23:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:36:17 --> Input Class Initialized
INFO - 2025-05-05 23:36:17 --> Language Class Initialized
INFO - 2025-05-05 23:36:17 --> Loader Class Initialized
INFO - 2025-05-05 23:36:17 --> Helper loaded: url_helper
INFO - 2025-05-05 23:36:17 --> Helper loaded: string_helper
INFO - 2025-05-05 23:36:17 --> Helper loaded: form_helper
INFO - 2025-05-05 23:36:17 --> Helper loaded: file_helper
INFO - 2025-05-05 23:36:17 --> Helper loaded: html_helper
INFO - 2025-05-05 23:36:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:36:17 --> Controller Class Initialized
INFO - 2025-05-05 23:36:29 --> Config Class Initialized
INFO - 2025-05-05 23:36:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:36:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:36:29 --> Utf8 Class Initialized
INFO - 2025-05-05 23:36:29 --> URI Class Initialized
INFO - 2025-05-05 23:36:29 --> Router Class Initialized
INFO - 2025-05-05 23:36:29 --> Output Class Initialized
INFO - 2025-05-05 23:36:29 --> Security Class Initialized
DEBUG - 2025-05-05 23:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:36:29 --> Input Class Initialized
INFO - 2025-05-05 23:36:29 --> Language Class Initialized
INFO - 2025-05-05 23:36:29 --> Loader Class Initialized
INFO - 2025-05-05 23:36:29 --> Helper loaded: url_helper
INFO - 2025-05-05 23:36:29 --> Helper loaded: string_helper
INFO - 2025-05-05 23:36:29 --> Helper loaded: form_helper
INFO - 2025-05-05 23:36:29 --> Helper loaded: file_helper
INFO - 2025-05-05 23:36:29 --> Helper loaded: html_helper
INFO - 2025-05-05 23:36:29 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:36:29 --> Controller Class Initialized
INFO - 2025-05-05 23:36:30 --> Config Class Initialized
INFO - 2025-05-05 23:36:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:36:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:36:30 --> Utf8 Class Initialized
INFO - 2025-05-05 23:36:30 --> URI Class Initialized
INFO - 2025-05-05 23:36:30 --> Router Class Initialized
INFO - 2025-05-05 23:36:30 --> Output Class Initialized
INFO - 2025-05-05 23:36:30 --> Security Class Initialized
DEBUG - 2025-05-05 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:36:30 --> Input Class Initialized
INFO - 2025-05-05 23:36:30 --> Language Class Initialized
INFO - 2025-05-05 23:36:30 --> Loader Class Initialized
INFO - 2025-05-05 23:36:30 --> Helper loaded: url_helper
INFO - 2025-05-05 23:36:30 --> Helper loaded: string_helper
INFO - 2025-05-05 23:36:30 --> Helper loaded: form_helper
INFO - 2025-05-05 23:36:30 --> Helper loaded: file_helper
INFO - 2025-05-05 23:36:30 --> Helper loaded: html_helper
INFO - 2025-05-05 23:36:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:36:30 --> Controller Class Initialized
INFO - 2025-05-05 23:37:30 --> Config Class Initialized
INFO - 2025-05-05 23:37:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:37:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:37:30 --> Utf8 Class Initialized
INFO - 2025-05-05 23:37:30 --> URI Class Initialized
INFO - 2025-05-05 23:37:30 --> Router Class Initialized
INFO - 2025-05-05 23:37:30 --> Output Class Initialized
INFO - 2025-05-05 23:37:30 --> Security Class Initialized
DEBUG - 2025-05-05 23:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:37:30 --> Input Class Initialized
INFO - 2025-05-05 23:37:30 --> Language Class Initialized
INFO - 2025-05-05 23:37:30 --> Loader Class Initialized
INFO - 2025-05-05 23:37:30 --> Helper loaded: url_helper
INFO - 2025-05-05 23:37:30 --> Helper loaded: string_helper
INFO - 2025-05-05 23:37:30 --> Helper loaded: form_helper
INFO - 2025-05-05 23:37:30 --> Helper loaded: file_helper
INFO - 2025-05-05 23:37:30 --> Helper loaded: html_helper
INFO - 2025-05-05 23:37:30 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:37:30 --> Controller Class Initialized
INFO - 2025-05-05 23:37:30 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:37:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:37:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:37:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:37:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:37:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:37:30 --> Final output sent to browser
DEBUG - 2025-05-05 23:37:30 --> Total execution time: 0.1386
INFO - 2025-05-05 23:37:31 --> Config Class Initialized
INFO - 2025-05-05 23:37:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:37:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:37:31 --> Utf8 Class Initialized
INFO - 2025-05-05 23:37:31 --> URI Class Initialized
INFO - 2025-05-05 23:37:31 --> Router Class Initialized
INFO - 2025-05-05 23:37:31 --> Output Class Initialized
INFO - 2025-05-05 23:37:31 --> Security Class Initialized
DEBUG - 2025-05-05 23:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:37:31 --> Input Class Initialized
INFO - 2025-05-05 23:37:31 --> Language Class Initialized
INFO - 2025-05-05 23:37:31 --> Loader Class Initialized
INFO - 2025-05-05 23:37:31 --> Helper loaded: url_helper
INFO - 2025-05-05 23:37:31 --> Helper loaded: string_helper
INFO - 2025-05-05 23:37:31 --> Helper loaded: form_helper
INFO - 2025-05-05 23:37:31 --> Helper loaded: file_helper
INFO - 2025-05-05 23:37:31 --> Helper loaded: html_helper
INFO - 2025-05-05 23:37:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:37:31 --> Controller Class Initialized
INFO - 2025-05-05 23:38:23 --> Config Class Initialized
INFO - 2025-05-05 23:38:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:23 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:23 --> URI Class Initialized
INFO - 2025-05-05 23:38:23 --> Router Class Initialized
INFO - 2025-05-05 23:38:23 --> Output Class Initialized
INFO - 2025-05-05 23:38:23 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:23 --> Input Class Initialized
INFO - 2025-05-05 23:38:23 --> Language Class Initialized
INFO - 2025-05-05 23:38:23 --> Loader Class Initialized
INFO - 2025-05-05 23:38:23 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:23 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:23 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:23 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:23 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:23 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:38:23 --> Controller Class Initialized
INFO - 2025-05-05 23:38:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:38:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:38:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-05 23:38:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:38:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:38:23 --> Final output sent to browser
DEBUG - 2025-05-05 23:38:23 --> Total execution time: 0.2155
INFO - 2025-05-05 23:38:25 --> Config Class Initialized
INFO - 2025-05-05 23:38:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:25 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:25 --> URI Class Initialized
INFO - 2025-05-05 23:38:25 --> Router Class Initialized
INFO - 2025-05-05 23:38:25 --> Output Class Initialized
INFO - 2025-05-05 23:38:25 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:25 --> Input Class Initialized
INFO - 2025-05-05 23:38:25 --> Language Class Initialized
INFO - 2025-05-05 23:38:25 --> Loader Class Initialized
INFO - 2025-05-05 23:38:25 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:25 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:25 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:25 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:25 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:25 --> Database Driver Class Initialized
INFO - 2025-05-05 23:38:40 --> Config Class Initialized
INFO - 2025-05-05 23:38:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:40 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:40 --> URI Class Initialized
INFO - 2025-05-05 23:38:40 --> Router Class Initialized
INFO - 2025-05-05 23:38:40 --> Output Class Initialized
INFO - 2025-05-05 23:38:40 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:40 --> Input Class Initialized
INFO - 2025-05-05 23:38:40 --> Language Class Initialized
INFO - 2025-05-05 23:38:40 --> Loader Class Initialized
INFO - 2025-05-05 23:38:40 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:40 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:40 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:40 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:40 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:40 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:38:40 --> Controller Class Initialized
INFO - 2025-05-05 23:38:40 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:38:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:38:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:38:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:38:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:38:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:38:40 --> Final output sent to browser
DEBUG - 2025-05-05 23:38:40 --> Total execution time: 0.1437
INFO - 2025-05-05 23:38:46 --> Config Class Initialized
INFO - 2025-05-05 23:38:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:46 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:46 --> URI Class Initialized
INFO - 2025-05-05 23:38:46 --> Router Class Initialized
INFO - 2025-05-05 23:38:46 --> Output Class Initialized
INFO - 2025-05-05 23:38:46 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:46 --> Input Class Initialized
INFO - 2025-05-05 23:38:46 --> Language Class Initialized
INFO - 2025-05-05 23:38:46 --> Loader Class Initialized
INFO - 2025-05-05 23:38:46 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:46 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:46 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:46 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:46 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:38:46 --> Controller Class Initialized
INFO - 2025-05-05 23:38:49 --> Config Class Initialized
INFO - 2025-05-05 23:38:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:49 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:49 --> URI Class Initialized
INFO - 2025-05-05 23:38:49 --> Router Class Initialized
INFO - 2025-05-05 23:38:49 --> Output Class Initialized
INFO - 2025-05-05 23:38:49 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:49 --> Input Class Initialized
INFO - 2025-05-05 23:38:49 --> Language Class Initialized
INFO - 2025-05-05 23:38:49 --> Loader Class Initialized
INFO - 2025-05-05 23:38:49 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:49 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:49 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:49 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:49 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:49 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:38:49 --> Controller Class Initialized
INFO - 2025-05-05 23:38:49 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:38:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:38:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:38:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:38:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:38:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:38:49 --> Final output sent to browser
DEBUG - 2025-05-05 23:38:49 --> Total execution time: 0.1714
INFO - 2025-05-05 23:38:52 --> Config Class Initialized
INFO - 2025-05-05 23:38:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:38:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:38:52 --> Utf8 Class Initialized
INFO - 2025-05-05 23:38:52 --> URI Class Initialized
INFO - 2025-05-05 23:38:52 --> Router Class Initialized
INFO - 2025-05-05 23:38:52 --> Output Class Initialized
INFO - 2025-05-05 23:38:52 --> Security Class Initialized
DEBUG - 2025-05-05 23:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:38:52 --> Input Class Initialized
INFO - 2025-05-05 23:38:52 --> Language Class Initialized
INFO - 2025-05-05 23:38:52 --> Loader Class Initialized
INFO - 2025-05-05 23:38:52 --> Helper loaded: url_helper
INFO - 2025-05-05 23:38:52 --> Helper loaded: string_helper
INFO - 2025-05-05 23:38:52 --> Helper loaded: form_helper
INFO - 2025-05-05 23:38:52 --> Helper loaded: file_helper
INFO - 2025-05-05 23:38:52 --> Helper loaded: html_helper
INFO - 2025-05-05 23:38:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:38:52 --> Controller Class Initialized
INFO - 2025-05-05 23:39:22 --> Config Class Initialized
INFO - 2025-05-05 23:39:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:39:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:39:22 --> Utf8 Class Initialized
INFO - 2025-05-05 23:39:22 --> URI Class Initialized
INFO - 2025-05-05 23:39:22 --> Router Class Initialized
INFO - 2025-05-05 23:39:22 --> Output Class Initialized
INFO - 2025-05-05 23:39:22 --> Security Class Initialized
DEBUG - 2025-05-05 23:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:39:22 --> Input Class Initialized
INFO - 2025-05-05 23:39:22 --> Language Class Initialized
INFO - 2025-05-05 23:39:22 --> Loader Class Initialized
INFO - 2025-05-05 23:39:22 --> Helper loaded: url_helper
INFO - 2025-05-05 23:39:22 --> Helper loaded: string_helper
INFO - 2025-05-05 23:39:22 --> Helper loaded: form_helper
INFO - 2025-05-05 23:39:22 --> Helper loaded: file_helper
INFO - 2025-05-05 23:39:22 --> Helper loaded: html_helper
INFO - 2025-05-05 23:39:22 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:39:22 --> Controller Class Initialized
INFO - 2025-05-05 23:39:22 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:39:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:39:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:39:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:39:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:39:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:39:22 --> Final output sent to browser
DEBUG - 2025-05-05 23:39:22 --> Total execution time: 0.0981
INFO - 2025-05-05 23:39:25 --> Config Class Initialized
INFO - 2025-05-05 23:39:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:39:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:39:25 --> Utf8 Class Initialized
INFO - 2025-05-05 23:39:25 --> URI Class Initialized
INFO - 2025-05-05 23:39:25 --> Router Class Initialized
INFO - 2025-05-05 23:39:25 --> Output Class Initialized
INFO - 2025-05-05 23:39:25 --> Security Class Initialized
DEBUG - 2025-05-05 23:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:39:25 --> Input Class Initialized
INFO - 2025-05-05 23:39:25 --> Language Class Initialized
INFO - 2025-05-05 23:39:25 --> Loader Class Initialized
INFO - 2025-05-05 23:39:25 --> Helper loaded: url_helper
INFO - 2025-05-05 23:39:25 --> Helper loaded: string_helper
INFO - 2025-05-05 23:39:25 --> Helper loaded: form_helper
INFO - 2025-05-05 23:39:25 --> Helper loaded: file_helper
INFO - 2025-05-05 23:39:25 --> Helper loaded: html_helper
INFO - 2025-05-05 23:39:25 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:39:25 --> Controller Class Initialized
INFO - 2025-05-05 23:39:46 --> Config Class Initialized
INFO - 2025-05-05 23:39:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:39:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:39:46 --> Utf8 Class Initialized
INFO - 2025-05-05 23:39:46 --> URI Class Initialized
INFO - 2025-05-05 23:39:46 --> Router Class Initialized
INFO - 2025-05-05 23:39:46 --> Output Class Initialized
INFO - 2025-05-05 23:39:46 --> Security Class Initialized
DEBUG - 2025-05-05 23:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:39:46 --> Input Class Initialized
INFO - 2025-05-05 23:39:46 --> Language Class Initialized
INFO - 2025-05-05 23:39:46 --> Loader Class Initialized
INFO - 2025-05-05 23:39:46 --> Helper loaded: url_helper
INFO - 2025-05-05 23:39:46 --> Helper loaded: string_helper
INFO - 2025-05-05 23:39:46 --> Helper loaded: form_helper
INFO - 2025-05-05 23:39:46 --> Helper loaded: file_helper
INFO - 2025-05-05 23:39:46 --> Helper loaded: html_helper
INFO - 2025-05-05 23:39:46 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:39:46 --> Controller Class Initialized
INFO - 2025-05-05 23:39:46 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:39:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:39:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:39:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:39:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:39:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:39:46 --> Final output sent to browser
DEBUG - 2025-05-05 23:39:46 --> Total execution time: 0.1096
INFO - 2025-05-05 23:39:48 --> Config Class Initialized
INFO - 2025-05-05 23:39:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:39:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:39:48 --> Utf8 Class Initialized
INFO - 2025-05-05 23:39:48 --> URI Class Initialized
INFO - 2025-05-05 23:39:48 --> Router Class Initialized
INFO - 2025-05-05 23:39:48 --> Output Class Initialized
INFO - 2025-05-05 23:39:48 --> Security Class Initialized
DEBUG - 2025-05-05 23:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:39:48 --> Input Class Initialized
INFO - 2025-05-05 23:39:48 --> Language Class Initialized
INFO - 2025-05-05 23:39:48 --> Loader Class Initialized
INFO - 2025-05-05 23:39:48 --> Helper loaded: url_helper
INFO - 2025-05-05 23:39:48 --> Helper loaded: string_helper
INFO - 2025-05-05 23:39:48 --> Helper loaded: form_helper
INFO - 2025-05-05 23:39:48 --> Helper loaded: file_helper
INFO - 2025-05-05 23:39:48 --> Helper loaded: html_helper
INFO - 2025-05-05 23:39:48 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:39:48 --> Controller Class Initialized
INFO - 2025-05-05 23:46:42 --> Config Class Initialized
INFO - 2025-05-05 23:46:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:46:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:46:42 --> Utf8 Class Initialized
INFO - 2025-05-05 23:46:42 --> URI Class Initialized
INFO - 2025-05-05 23:46:42 --> Router Class Initialized
INFO - 2025-05-05 23:46:42 --> Output Class Initialized
INFO - 2025-05-05 23:46:42 --> Security Class Initialized
DEBUG - 2025-05-05 23:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:46:42 --> Input Class Initialized
INFO - 2025-05-05 23:46:42 --> Language Class Initialized
INFO - 2025-05-05 23:46:42 --> Loader Class Initialized
INFO - 2025-05-05 23:46:42 --> Helper loaded: url_helper
INFO - 2025-05-05 23:46:42 --> Helper loaded: string_helper
INFO - 2025-05-05 23:46:42 --> Helper loaded: form_helper
INFO - 2025-05-05 23:46:42 --> Helper loaded: file_helper
INFO - 2025-05-05 23:46:42 --> Helper loaded: html_helper
INFO - 2025-05-05 23:46:42 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:46:42 --> Controller Class Initialized
INFO - 2025-05-05 23:46:42 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:46:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:46:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:46:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:46:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:46:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:46:42 --> Final output sent to browser
DEBUG - 2025-05-05 23:46:42 --> Total execution time: 0.2067
INFO - 2025-05-05 23:46:45 --> Config Class Initialized
INFO - 2025-05-05 23:46:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:46:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:46:45 --> Utf8 Class Initialized
INFO - 2025-05-05 23:46:45 --> URI Class Initialized
INFO - 2025-05-05 23:46:45 --> Router Class Initialized
INFO - 2025-05-05 23:46:45 --> Output Class Initialized
INFO - 2025-05-05 23:46:45 --> Security Class Initialized
DEBUG - 2025-05-05 23:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:46:45 --> Input Class Initialized
INFO - 2025-05-05 23:46:45 --> Language Class Initialized
INFO - 2025-05-05 23:46:45 --> Loader Class Initialized
INFO - 2025-05-05 23:46:45 --> Helper loaded: url_helper
INFO - 2025-05-05 23:46:45 --> Helper loaded: string_helper
INFO - 2025-05-05 23:46:45 --> Helper loaded: form_helper
INFO - 2025-05-05 23:46:45 --> Helper loaded: file_helper
INFO - 2025-05-05 23:46:45 --> Helper loaded: html_helper
INFO - 2025-05-05 23:46:45 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:46:45 --> Controller Class Initialized
INFO - 2025-05-05 23:46:47 --> Config Class Initialized
INFO - 2025-05-05 23:46:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:46:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:46:47 --> Utf8 Class Initialized
INFO - 2025-05-05 23:46:47 --> URI Class Initialized
INFO - 2025-05-05 23:46:47 --> Router Class Initialized
INFO - 2025-05-05 23:46:47 --> Output Class Initialized
INFO - 2025-05-05 23:46:47 --> Security Class Initialized
DEBUG - 2025-05-05 23:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:46:47 --> Input Class Initialized
INFO - 2025-05-05 23:46:47 --> Language Class Initialized
INFO - 2025-05-05 23:46:47 --> Loader Class Initialized
INFO - 2025-05-05 23:46:47 --> Helper loaded: url_helper
INFO - 2025-05-05 23:46:47 --> Helper loaded: string_helper
INFO - 2025-05-05 23:46:47 --> Helper loaded: form_helper
INFO - 2025-05-05 23:46:47 --> Helper loaded: file_helper
INFO - 2025-05-05 23:46:47 --> Helper loaded: html_helper
INFO - 2025-05-05 23:46:47 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:46:47 --> Controller Class Initialized
INFO - 2025-05-05 23:47:09 --> Config Class Initialized
INFO - 2025-05-05 23:47:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:47:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:47:09 --> Utf8 Class Initialized
INFO - 2025-05-05 23:47:09 --> URI Class Initialized
INFO - 2025-05-05 23:47:09 --> Router Class Initialized
INFO - 2025-05-05 23:47:09 --> Output Class Initialized
INFO - 2025-05-05 23:47:09 --> Security Class Initialized
DEBUG - 2025-05-05 23:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:47:09 --> Input Class Initialized
INFO - 2025-05-05 23:47:09 --> Language Class Initialized
INFO - 2025-05-05 23:47:09 --> Loader Class Initialized
INFO - 2025-05-05 23:47:09 --> Helper loaded: url_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: string_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: form_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: file_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: html_helper
INFO - 2025-05-05 23:47:09 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:47:09 --> Controller Class Initialized
INFO - 2025-05-05 23:47:09 --> Config Class Initialized
INFO - 2025-05-05 23:47:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:47:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:47:09 --> Utf8 Class Initialized
INFO - 2025-05-05 23:47:09 --> URI Class Initialized
INFO - 2025-05-05 23:47:09 --> Router Class Initialized
INFO - 2025-05-05 23:47:09 --> Output Class Initialized
INFO - 2025-05-05 23:47:09 --> Security Class Initialized
DEBUG - 2025-05-05 23:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:47:09 --> Input Class Initialized
INFO - 2025-05-05 23:47:09 --> Language Class Initialized
INFO - 2025-05-05 23:47:09 --> Loader Class Initialized
INFO - 2025-05-05 23:47:09 --> Helper loaded: url_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: string_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: form_helper
INFO - 2025-05-05 23:47:09 --> Helper loaded: file_helper
INFO - 2025-05-05 23:47:10 --> Helper loaded: html_helper
INFO - 2025-05-05 23:47:10 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:47:10 --> Controller Class Initialized
INFO - 2025-05-05 23:47:31 --> Config Class Initialized
INFO - 2025-05-05 23:47:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:47:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:47:31 --> Utf8 Class Initialized
INFO - 2025-05-05 23:47:31 --> URI Class Initialized
INFO - 2025-05-05 23:47:31 --> Router Class Initialized
INFO - 2025-05-05 23:47:31 --> Output Class Initialized
INFO - 2025-05-05 23:47:31 --> Security Class Initialized
DEBUG - 2025-05-05 23:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:47:31 --> Input Class Initialized
INFO - 2025-05-05 23:47:31 --> Language Class Initialized
INFO - 2025-05-05 23:47:31 --> Loader Class Initialized
INFO - 2025-05-05 23:47:31 --> Helper loaded: url_helper
INFO - 2025-05-05 23:47:31 --> Helper loaded: string_helper
INFO - 2025-05-05 23:47:31 --> Helper loaded: form_helper
INFO - 2025-05-05 23:47:31 --> Helper loaded: file_helper
INFO - 2025-05-05 23:47:31 --> Helper loaded: html_helper
INFO - 2025-05-05 23:47:31 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:47:31 --> Controller Class Initialized
INFO - 2025-05-05 23:47:32 --> Config Class Initialized
INFO - 2025-05-05 23:47:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:47:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:47:32 --> Utf8 Class Initialized
INFO - 2025-05-05 23:47:32 --> URI Class Initialized
INFO - 2025-05-05 23:47:32 --> Router Class Initialized
INFO - 2025-05-05 23:47:32 --> Output Class Initialized
INFO - 2025-05-05 23:47:32 --> Security Class Initialized
DEBUG - 2025-05-05 23:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:47:32 --> Input Class Initialized
INFO - 2025-05-05 23:47:32 --> Language Class Initialized
INFO - 2025-05-05 23:47:32 --> Loader Class Initialized
INFO - 2025-05-05 23:47:32 --> Helper loaded: url_helper
INFO - 2025-05-05 23:47:32 --> Helper loaded: string_helper
INFO - 2025-05-05 23:47:32 --> Helper loaded: form_helper
INFO - 2025-05-05 23:47:32 --> Helper loaded: file_helper
INFO - 2025-05-05 23:47:32 --> Helper loaded: html_helper
INFO - 2025-05-05 23:47:32 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:47:32 --> Controller Class Initialized
INFO - 2025-05-05 23:48:51 --> Config Class Initialized
INFO - 2025-05-05 23:48:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:48:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:48:51 --> Utf8 Class Initialized
INFO - 2025-05-05 23:48:51 --> URI Class Initialized
INFO - 2025-05-05 23:48:51 --> Router Class Initialized
INFO - 2025-05-05 23:48:51 --> Output Class Initialized
INFO - 2025-05-05 23:48:51 --> Security Class Initialized
DEBUG - 2025-05-05 23:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:48:51 --> Input Class Initialized
INFO - 2025-05-05 23:48:51 --> Language Class Initialized
INFO - 2025-05-05 23:48:51 --> Loader Class Initialized
INFO - 2025-05-05 23:48:51 --> Helper loaded: url_helper
INFO - 2025-05-05 23:48:51 --> Helper loaded: string_helper
INFO - 2025-05-05 23:48:51 --> Helper loaded: form_helper
INFO - 2025-05-05 23:48:51 --> Helper loaded: file_helper
INFO - 2025-05-05 23:48:51 --> Helper loaded: html_helper
INFO - 2025-05-05 23:48:51 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:48:51 --> Controller Class Initialized
INFO - 2025-05-05 23:48:51 --> Model "CompanyModel" initialized
INFO - 2025-05-05 23:48:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:48:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:48:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-05 23:48:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:48:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:48:51 --> Final output sent to browser
DEBUG - 2025-05-05 23:48:51 --> Total execution time: 0.1681
INFO - 2025-05-05 23:48:52 --> Config Class Initialized
INFO - 2025-05-05 23:48:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:48:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:48:52 --> Utf8 Class Initialized
INFO - 2025-05-05 23:48:52 --> URI Class Initialized
INFO - 2025-05-05 23:48:52 --> Router Class Initialized
INFO - 2025-05-05 23:48:52 --> Output Class Initialized
INFO - 2025-05-05 23:48:52 --> Security Class Initialized
DEBUG - 2025-05-05 23:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:48:52 --> Input Class Initialized
INFO - 2025-05-05 23:48:52 --> Language Class Initialized
INFO - 2025-05-05 23:48:52 --> Loader Class Initialized
INFO - 2025-05-05 23:48:52 --> Helper loaded: url_helper
INFO - 2025-05-05 23:48:52 --> Helper loaded: string_helper
INFO - 2025-05-05 23:48:52 --> Helper loaded: form_helper
INFO - 2025-05-05 23:48:52 --> Helper loaded: file_helper
INFO - 2025-05-05 23:48:52 --> Helper loaded: html_helper
INFO - 2025-05-05 23:48:52 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:48:52 --> Controller Class Initialized
INFO - 2025-05-05 23:49:53 --> Config Class Initialized
INFO - 2025-05-05 23:49:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:49:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:49:53 --> Utf8 Class Initialized
INFO - 2025-05-05 23:49:53 --> URI Class Initialized
INFO - 2025-05-05 23:49:53 --> Router Class Initialized
INFO - 2025-05-05 23:49:53 --> Output Class Initialized
INFO - 2025-05-05 23:49:53 --> Security Class Initialized
DEBUG - 2025-05-05 23:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:49:53 --> Input Class Initialized
INFO - 2025-05-05 23:49:53 --> Language Class Initialized
INFO - 2025-05-05 23:49:53 --> Loader Class Initialized
INFO - 2025-05-05 23:49:53 --> Helper loaded: url_helper
INFO - 2025-05-05 23:49:53 --> Helper loaded: string_helper
INFO - 2025-05-05 23:49:53 --> Helper loaded: form_helper
INFO - 2025-05-05 23:49:53 --> Helper loaded: file_helper
INFO - 2025-05-05 23:49:53 --> Helper loaded: html_helper
INFO - 2025-05-05 23:49:53 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:49:53 --> Controller Class Initialized
INFO - 2025-05-05 23:50:11 --> Config Class Initialized
INFO - 2025-05-05 23:50:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:50:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:50:11 --> Utf8 Class Initialized
INFO - 2025-05-05 23:50:11 --> URI Class Initialized
DEBUG - 2025-05-05 23:50:11 --> No URI present. Default controller set.
INFO - 2025-05-05 23:50:11 --> Router Class Initialized
INFO - 2025-05-05 23:50:11 --> Output Class Initialized
INFO - 2025-05-05 23:50:11 --> Security Class Initialized
DEBUG - 2025-05-05 23:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:50:11 --> Input Class Initialized
INFO - 2025-05-05 23:50:11 --> Language Class Initialized
INFO - 2025-05-05 23:50:11 --> Loader Class Initialized
INFO - 2025-05-05 23:50:11 --> Helper loaded: url_helper
INFO - 2025-05-05 23:50:11 --> Helper loaded: string_helper
INFO - 2025-05-05 23:50:11 --> Helper loaded: form_helper
INFO - 2025-05-05 23:50:11 --> Helper loaded: file_helper
INFO - 2025-05-05 23:50:11 --> Helper loaded: html_helper
INFO - 2025-05-05 23:50:11 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:50:11 --> Controller Class Initialized
INFO - 2025-05-05 23:50:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-05 23:50:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-05 23:50:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-05 23:50:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-05 23:50:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-05 23:50:11 --> Final output sent to browser
DEBUG - 2025-05-05 23:50:11 --> Total execution time: 0.2389
INFO - 2025-05-05 23:50:17 --> Config Class Initialized
INFO - 2025-05-05 23:50:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:50:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:50:17 --> Utf8 Class Initialized
INFO - 2025-05-05 23:50:17 --> URI Class Initialized
INFO - 2025-05-05 23:50:17 --> Router Class Initialized
INFO - 2025-05-05 23:50:17 --> Output Class Initialized
INFO - 2025-05-05 23:50:17 --> Security Class Initialized
DEBUG - 2025-05-05 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:50:17 --> Input Class Initialized
INFO - 2025-05-05 23:50:17 --> Language Class Initialized
INFO - 2025-05-05 23:50:17 --> Loader Class Initialized
INFO - 2025-05-05 23:50:17 --> Helper loaded: url_helper
INFO - 2025-05-05 23:50:17 --> Helper loaded: string_helper
INFO - 2025-05-05 23:50:17 --> Helper loaded: form_helper
INFO - 2025-05-05 23:50:17 --> Helper loaded: file_helper
INFO - 2025-05-05 23:50:17 --> Helper loaded: html_helper
INFO - 2025-05-05 23:50:17 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:50:17 --> Controller Class Initialized
INFO - 2025-05-05 23:50:55 --> Config Class Initialized
INFO - 2025-05-05 23:50:55 --> Hooks Class Initialized
DEBUG - 2025-05-05 23:50:55 --> UTF-8 Support Enabled
INFO - 2025-05-05 23:50:55 --> Utf8 Class Initialized
INFO - 2025-05-05 23:50:55 --> URI Class Initialized
INFO - 2025-05-05 23:50:55 --> Router Class Initialized
INFO - 2025-05-05 23:50:55 --> Output Class Initialized
INFO - 2025-05-05 23:50:55 --> Security Class Initialized
DEBUG - 2025-05-05 23:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 23:50:55 --> Input Class Initialized
INFO - 2025-05-05 23:50:55 --> Language Class Initialized
INFO - 2025-05-05 23:50:55 --> Loader Class Initialized
INFO - 2025-05-05 23:50:55 --> Helper loaded: url_helper
INFO - 2025-05-05 23:50:55 --> Helper loaded: string_helper
INFO - 2025-05-05 23:50:55 --> Helper loaded: form_helper
INFO - 2025-05-05 23:50:55 --> Helper loaded: file_helper
INFO - 2025-05-05 23:50:55 --> Helper loaded: html_helper
INFO - 2025-05-05 23:50:55 --> Database Driver Class Initialized
DEBUG - 2025-05-05 23:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-05 23:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 23:50:55 --> Controller Class Initialized
