<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-10 02:07:02 --> Config Class Initialized
INFO - 2025-05-10 02:07:02 --> Hooks Class Initialized
DEBUG - 2025-05-10 02:07:02 --> UTF-8 Support Enabled
INFO - 2025-05-10 02:07:02 --> Utf8 Class Initialized
INFO - 2025-05-10 02:07:02 --> URI Class Initialized
DEBUG - 2025-05-10 02:07:02 --> No URI present. Default controller set.
INFO - 2025-05-10 02:07:02 --> Router Class Initialized
INFO - 2025-05-10 02:07:02 --> Output Class Initialized
INFO - 2025-05-10 02:07:02 --> Security Class Initialized
DEBUG - 2025-05-10 02:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 02:07:02 --> Input Class Initialized
INFO - 2025-05-10 02:07:02 --> Language Class Initialized
INFO - 2025-05-10 02:07:02 --> Loader Class Initialized
INFO - 2025-05-10 02:07:02 --> Helper loaded: url_helper
INFO - 2025-05-10 02:07:02 --> Helper loaded: string_helper
INFO - 2025-05-10 02:07:02 --> Helper loaded: form_helper
INFO - 2025-05-10 02:07:02 --> Helper loaded: file_helper
INFO - 2025-05-10 02:07:02 --> Helper loaded: html_helper
INFO - 2025-05-10 02:07:02 --> Database Driver Class Initialized
DEBUG - 2025-05-10 02:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 02:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 02:07:02 --> Controller Class Initialized
INFO - 2025-05-10 02:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 02:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 02:07:02 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 02:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 02:07:02 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 02:07:02 --> Final output sent to browser
DEBUG - 2025-05-10 02:07:02 --> Total execution time: 0.0849
INFO - 2025-05-10 02:28:54 --> Config Class Initialized
INFO - 2025-05-10 02:28:54 --> Hooks Class Initialized
DEBUG - 2025-05-10 02:28:54 --> UTF-8 Support Enabled
INFO - 2025-05-10 02:28:54 --> Utf8 Class Initialized
INFO - 2025-05-10 02:28:54 --> URI Class Initialized
DEBUG - 2025-05-10 02:28:54 --> No URI present. Default controller set.
INFO - 2025-05-10 02:28:54 --> Router Class Initialized
INFO - 2025-05-10 02:28:54 --> Output Class Initialized
INFO - 2025-05-10 02:28:54 --> Security Class Initialized
DEBUG - 2025-05-10 02:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 02:28:54 --> Input Class Initialized
INFO - 2025-05-10 02:28:54 --> Language Class Initialized
INFO - 2025-05-10 02:28:54 --> Loader Class Initialized
INFO - 2025-05-10 02:28:54 --> Helper loaded: url_helper
INFO - 2025-05-10 02:28:54 --> Helper loaded: string_helper
INFO - 2025-05-10 02:28:54 --> Helper loaded: form_helper
INFO - 2025-05-10 02:28:54 --> Helper loaded: file_helper
INFO - 2025-05-10 02:28:54 --> Helper loaded: html_helper
INFO - 2025-05-10 02:28:54 --> Database Driver Class Initialized
DEBUG - 2025-05-10 02:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 02:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 02:28:54 --> Controller Class Initialized
INFO - 2025-05-10 02:28:54 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 02:28:54 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 02:28:54 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 02:28:54 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 02:28:54 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 02:28:54 --> Final output sent to browser
DEBUG - 2025-05-10 02:28:54 --> Total execution time: 0.0297
INFO - 2025-05-10 02:42:19 --> Config Class Initialized
INFO - 2025-05-10 02:42:19 --> Hooks Class Initialized
DEBUG - 2025-05-10 02:42:19 --> UTF-8 Support Enabled
INFO - 2025-05-10 02:42:19 --> Utf8 Class Initialized
INFO - 2025-05-10 02:42:19 --> URI Class Initialized
DEBUG - 2025-05-10 02:42:19 --> No URI present. Default controller set.
INFO - 2025-05-10 02:42:19 --> Router Class Initialized
INFO - 2025-05-10 02:42:19 --> Output Class Initialized
INFO - 2025-05-10 02:42:19 --> Security Class Initialized
DEBUG - 2025-05-10 02:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 02:42:19 --> Input Class Initialized
INFO - 2025-05-10 02:42:19 --> Language Class Initialized
INFO - 2025-05-10 02:42:19 --> Loader Class Initialized
INFO - 2025-05-10 02:42:19 --> Helper loaded: url_helper
INFO - 2025-05-10 02:42:19 --> Helper loaded: string_helper
INFO - 2025-05-10 02:42:19 --> Helper loaded: form_helper
INFO - 2025-05-10 02:42:19 --> Helper loaded: file_helper
INFO - 2025-05-10 02:42:19 --> Helper loaded: html_helper
INFO - 2025-05-10 02:42:19 --> Database Driver Class Initialized
DEBUG - 2025-05-10 02:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 02:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 02:42:19 --> Controller Class Initialized
INFO - 2025-05-10 02:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 02:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 02:42:19 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 02:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 02:42:19 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 02:42:19 --> Final output sent to browser
DEBUG - 2025-05-10 02:42:19 --> Total execution time: 0.0288
INFO - 2025-05-10 04:04:19 --> Config Class Initialized
INFO - 2025-05-10 04:04:19 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:19 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:19 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:19 --> URI Class Initialized
INFO - 2025-05-10 04:04:19 --> Router Class Initialized
INFO - 2025-05-10 04:04:19 --> Output Class Initialized
INFO - 2025-05-10 04:04:19 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:19 --> Input Class Initialized
INFO - 2025-05-10 04:04:19 --> Language Class Initialized
ERROR - 2025-05-10 04:04:19 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:20 --> Config Class Initialized
INFO - 2025-05-10 04:04:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:20 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:20 --> URI Class Initialized
INFO - 2025-05-10 04:04:20 --> Router Class Initialized
INFO - 2025-05-10 04:04:20 --> Output Class Initialized
INFO - 2025-05-10 04:04:20 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:20 --> Input Class Initialized
INFO - 2025-05-10 04:04:20 --> Language Class Initialized
ERROR - 2025-05-10 04:04:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:21 --> Config Class Initialized
INFO - 2025-05-10 04:04:21 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:21 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:21 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:21 --> URI Class Initialized
INFO - 2025-05-10 04:04:21 --> Router Class Initialized
INFO - 2025-05-10 04:04:21 --> Output Class Initialized
INFO - 2025-05-10 04:04:21 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:21 --> Input Class Initialized
INFO - 2025-05-10 04:04:21 --> Language Class Initialized
ERROR - 2025-05-10 04:04:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:22 --> Config Class Initialized
INFO - 2025-05-10 04:04:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:22 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:22 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:22 --> URI Class Initialized
INFO - 2025-05-10 04:04:22 --> Router Class Initialized
INFO - 2025-05-10 04:04:22 --> Output Class Initialized
INFO - 2025-05-10 04:04:22 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:22 --> Input Class Initialized
INFO - 2025-05-10 04:04:22 --> Language Class Initialized
ERROR - 2025-05-10 04:04:22 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:23 --> Config Class Initialized
INFO - 2025-05-10 04:04:23 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:23 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:23 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:23 --> URI Class Initialized
INFO - 2025-05-10 04:04:23 --> Router Class Initialized
INFO - 2025-05-10 04:04:23 --> Output Class Initialized
INFO - 2025-05-10 04:04:23 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:23 --> Input Class Initialized
INFO - 2025-05-10 04:04:23 --> Language Class Initialized
ERROR - 2025-05-10 04:04:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:24 --> Config Class Initialized
INFO - 2025-05-10 04:04:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:24 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:24 --> URI Class Initialized
INFO - 2025-05-10 04:04:24 --> Router Class Initialized
INFO - 2025-05-10 04:04:24 --> Output Class Initialized
INFO - 2025-05-10 04:04:24 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:24 --> Input Class Initialized
INFO - 2025-05-10 04:04:24 --> Language Class Initialized
ERROR - 2025-05-10 04:04:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:25 --> Config Class Initialized
INFO - 2025-05-10 04:04:25 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:25 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:25 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:25 --> URI Class Initialized
INFO - 2025-05-10 04:04:25 --> Router Class Initialized
INFO - 2025-05-10 04:04:25 --> Output Class Initialized
INFO - 2025-05-10 04:04:25 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:25 --> Input Class Initialized
INFO - 2025-05-10 04:04:25 --> Language Class Initialized
ERROR - 2025-05-10 04:04:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:26 --> Config Class Initialized
INFO - 2025-05-10 04:04:26 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:26 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:26 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:26 --> URI Class Initialized
INFO - 2025-05-10 04:04:26 --> Router Class Initialized
INFO - 2025-05-10 04:04:26 --> Output Class Initialized
INFO - 2025-05-10 04:04:26 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:26 --> Input Class Initialized
INFO - 2025-05-10 04:04:26 --> Language Class Initialized
ERROR - 2025-05-10 04:04:26 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:27 --> Config Class Initialized
INFO - 2025-05-10 04:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:27 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:27 --> URI Class Initialized
INFO - 2025-05-10 04:04:27 --> Router Class Initialized
INFO - 2025-05-10 04:04:27 --> Output Class Initialized
INFO - 2025-05-10 04:04:27 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:27 --> Input Class Initialized
INFO - 2025-05-10 04:04:27 --> Language Class Initialized
ERROR - 2025-05-10 04:04:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 04:04:28 --> Config Class Initialized
INFO - 2025-05-10 04:04:28 --> Hooks Class Initialized
DEBUG - 2025-05-10 04:04:28 --> UTF-8 Support Enabled
INFO - 2025-05-10 04:04:28 --> Utf8 Class Initialized
INFO - 2025-05-10 04:04:28 --> URI Class Initialized
INFO - 2025-05-10 04:04:28 --> Router Class Initialized
INFO - 2025-05-10 04:04:28 --> Output Class Initialized
INFO - 2025-05-10 04:04:28 --> Security Class Initialized
DEBUG - 2025-05-10 04:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 04:04:28 --> Input Class Initialized
INFO - 2025-05-10 04:04:28 --> Language Class Initialized
ERROR - 2025-05-10 04:04:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 05:33:10 --> Config Class Initialized
INFO - 2025-05-10 05:33:10 --> Hooks Class Initialized
DEBUG - 2025-05-10 05:33:10 --> UTF-8 Support Enabled
INFO - 2025-05-10 05:33:10 --> Utf8 Class Initialized
INFO - 2025-05-10 05:33:10 --> URI Class Initialized
INFO - 2025-05-10 05:33:10 --> Router Class Initialized
INFO - 2025-05-10 05:33:10 --> Output Class Initialized
INFO - 2025-05-10 05:33:10 --> Security Class Initialized
DEBUG - 2025-05-10 05:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 05:33:10 --> Input Class Initialized
INFO - 2025-05-10 05:33:10 --> Language Class Initialized
ERROR - 2025-05-10 05:33:10 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 05:51:03 --> Config Class Initialized
INFO - 2025-05-10 05:51:03 --> Hooks Class Initialized
DEBUG - 2025-05-10 05:51:03 --> UTF-8 Support Enabled
INFO - 2025-05-10 05:51:03 --> Utf8 Class Initialized
INFO - 2025-05-10 05:51:03 --> URI Class Initialized
DEBUG - 2025-05-10 05:51:03 --> No URI present. Default controller set.
INFO - 2025-05-10 05:51:03 --> Router Class Initialized
INFO - 2025-05-10 05:51:03 --> Output Class Initialized
INFO - 2025-05-10 05:51:03 --> Security Class Initialized
DEBUG - 2025-05-10 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 05:51:03 --> Input Class Initialized
INFO - 2025-05-10 05:51:03 --> Language Class Initialized
INFO - 2025-05-10 05:51:03 --> Loader Class Initialized
INFO - 2025-05-10 05:51:03 --> Helper loaded: url_helper
INFO - 2025-05-10 05:51:03 --> Helper loaded: string_helper
INFO - 2025-05-10 05:51:03 --> Helper loaded: form_helper
INFO - 2025-05-10 05:51:03 --> Helper loaded: file_helper
INFO - 2025-05-10 05:51:03 --> Helper loaded: html_helper
INFO - 2025-05-10 05:51:03 --> Database Driver Class Initialized
DEBUG - 2025-05-10 05:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 05:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 05:51:03 --> Controller Class Initialized
INFO - 2025-05-10 05:51:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 05:51:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 05:51:03 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 05:51:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 05:51:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 05:51:03 --> Final output sent to browser
DEBUG - 2025-05-10 05:51:03 --> Total execution time: 0.0493
INFO - 2025-05-10 05:57:56 --> Config Class Initialized
INFO - 2025-05-10 05:57:56 --> Hooks Class Initialized
DEBUG - 2025-05-10 05:57:56 --> UTF-8 Support Enabled
INFO - 2025-05-10 05:57:56 --> Utf8 Class Initialized
INFO - 2025-05-10 05:57:56 --> URI Class Initialized
DEBUG - 2025-05-10 05:57:56 --> No URI present. Default controller set.
INFO - 2025-05-10 05:57:56 --> Router Class Initialized
INFO - 2025-05-10 05:57:56 --> Output Class Initialized
INFO - 2025-05-10 05:57:56 --> Security Class Initialized
DEBUG - 2025-05-10 05:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 05:57:56 --> Input Class Initialized
INFO - 2025-05-10 05:57:56 --> Language Class Initialized
INFO - 2025-05-10 05:57:56 --> Loader Class Initialized
INFO - 2025-05-10 05:57:56 --> Helper loaded: url_helper
INFO - 2025-05-10 05:57:56 --> Helper loaded: string_helper
INFO - 2025-05-10 05:57:56 --> Helper loaded: form_helper
INFO - 2025-05-10 05:57:56 --> Helper loaded: file_helper
INFO - 2025-05-10 05:57:56 --> Helper loaded: html_helper
INFO - 2025-05-10 05:57:56 --> Database Driver Class Initialized
DEBUG - 2025-05-10 05:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 05:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 05:57:56 --> Controller Class Initialized
INFO - 2025-05-10 05:57:56 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 05:57:56 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 05:57:56 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 05:57:56 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 05:57:56 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 05:57:56 --> Final output sent to browser
DEBUG - 2025-05-10 05:57:56 --> Total execution time: 0.0322
INFO - 2025-05-10 05:59:22 --> Config Class Initialized
INFO - 2025-05-10 05:59:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 05:59:22 --> UTF-8 Support Enabled
INFO - 2025-05-10 05:59:22 --> Utf8 Class Initialized
INFO - 2025-05-10 05:59:22 --> URI Class Initialized
INFO - 2025-05-10 05:59:22 --> Router Class Initialized
INFO - 2025-05-10 05:59:22 --> Output Class Initialized
INFO - 2025-05-10 05:59:22 --> Security Class Initialized
DEBUG - 2025-05-10 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 05:59:22 --> Input Class Initialized
INFO - 2025-05-10 05:59:22 --> Language Class Initialized
INFO - 2025-05-10 05:59:22 --> Loader Class Initialized
INFO - 2025-05-10 05:59:22 --> Helper loaded: url_helper
INFO - 2025-05-10 05:59:22 --> Helper loaded: string_helper
INFO - 2025-05-10 05:59:22 --> Helper loaded: form_helper
INFO - 2025-05-10 05:59:22 --> Helper loaded: file_helper
INFO - 2025-05-10 05:59:22 --> Helper loaded: html_helper
INFO - 2025-05-10 05:59:22 --> Database Driver Class Initialized
DEBUG - 2025-05-10 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 05:59:22 --> Controller Class Initialized
INFO - 2025-05-10 05:59:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 05:59:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 05:59:22 --> File loaded: /home/storagep/public_html/application/views/pages/terms_and_conditions.php
INFO - 2025-05-10 05:59:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 05:59:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 05:59:22 --> Final output sent to browser
DEBUG - 2025-05-10 05:59:22 --> Total execution time: 0.0297
INFO - 2025-05-10 06:00:41 --> Config Class Initialized
INFO - 2025-05-10 06:00:41 --> Hooks Class Initialized
DEBUG - 2025-05-10 06:00:41 --> UTF-8 Support Enabled
INFO - 2025-05-10 06:00:41 --> Utf8 Class Initialized
INFO - 2025-05-10 06:00:41 --> URI Class Initialized
INFO - 2025-05-10 06:00:41 --> Router Class Initialized
INFO - 2025-05-10 06:00:41 --> Output Class Initialized
INFO - 2025-05-10 06:00:41 --> Security Class Initialized
DEBUG - 2025-05-10 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 06:00:41 --> Input Class Initialized
INFO - 2025-05-10 06:00:41 --> Language Class Initialized
INFO - 2025-05-10 06:00:41 --> Loader Class Initialized
INFO - 2025-05-10 06:00:41 --> Helper loaded: url_helper
INFO - 2025-05-10 06:00:41 --> Helper loaded: string_helper
INFO - 2025-05-10 06:00:41 --> Helper loaded: form_helper
INFO - 2025-05-10 06:00:41 --> Helper loaded: file_helper
INFO - 2025-05-10 06:00:41 --> Helper loaded: html_helper
INFO - 2025-05-10 06:00:41 --> Database Driver Class Initialized
DEBUG - 2025-05-10 06:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 06:00:41 --> Controller Class Initialized
INFO - 2025-05-10 06:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 06:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 06:00:41 --> File loaded: /home/storagep/public_html/application/views/pages/contact_us.php
INFO - 2025-05-10 06:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 06:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 06:00:41 --> Final output sent to browser
DEBUG - 2025-05-10 06:00:41 --> Total execution time: 0.0303
INFO - 2025-05-10 06:29:30 --> Config Class Initialized
INFO - 2025-05-10 06:29:30 --> Hooks Class Initialized
DEBUG - 2025-05-10 06:29:30 --> UTF-8 Support Enabled
INFO - 2025-05-10 06:29:30 --> Utf8 Class Initialized
INFO - 2025-05-10 06:29:30 --> URI Class Initialized
INFO - 2025-05-10 06:29:30 --> Router Class Initialized
INFO - 2025-05-10 06:29:30 --> Output Class Initialized
INFO - 2025-05-10 06:29:30 --> Security Class Initialized
DEBUG - 2025-05-10 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 06:29:30 --> Input Class Initialized
INFO - 2025-05-10 06:29:30 --> Language Class Initialized
INFO - 2025-05-10 06:29:30 --> Loader Class Initialized
INFO - 2025-05-10 06:29:30 --> Helper loaded: url_helper
INFO - 2025-05-10 06:29:30 --> Helper loaded: string_helper
INFO - 2025-05-10 06:29:30 --> Helper loaded: form_helper
INFO - 2025-05-10 06:29:30 --> Helper loaded: file_helper
INFO - 2025-05-10 06:29:30 --> Helper loaded: html_helper
INFO - 2025-05-10 06:29:30 --> Database Driver Class Initialized
DEBUG - 2025-05-10 06:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 06:29:30 --> Controller Class Initialized
INFO - 2025-05-10 06:29:30 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 06:29:30 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 06:29:30 --> File loaded: /home/storagep/public_html/application/views/pages/about_us.php
INFO - 2025-05-10 06:29:30 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 06:29:30 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 06:29:30 --> Final output sent to browser
DEBUG - 2025-05-10 06:29:30 --> Total execution time: 0.0301
INFO - 2025-05-10 06:34:09 --> Config Class Initialized
INFO - 2025-05-10 06:34:09 --> Hooks Class Initialized
DEBUG - 2025-05-10 06:34:09 --> UTF-8 Support Enabled
INFO - 2025-05-10 06:34:09 --> Utf8 Class Initialized
INFO - 2025-05-10 06:34:09 --> URI Class Initialized
DEBUG - 2025-05-10 06:34:09 --> No URI present. Default controller set.
INFO - 2025-05-10 06:34:09 --> Router Class Initialized
INFO - 2025-05-10 06:34:09 --> Output Class Initialized
INFO - 2025-05-10 06:34:09 --> Security Class Initialized
DEBUG - 2025-05-10 06:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 06:34:09 --> Input Class Initialized
INFO - 2025-05-10 06:34:09 --> Language Class Initialized
INFO - 2025-05-10 06:34:09 --> Loader Class Initialized
INFO - 2025-05-10 06:34:09 --> Helper loaded: url_helper
INFO - 2025-05-10 06:34:09 --> Helper loaded: string_helper
INFO - 2025-05-10 06:34:09 --> Helper loaded: form_helper
INFO - 2025-05-10 06:34:09 --> Helper loaded: file_helper
INFO - 2025-05-10 06:34:09 --> Helper loaded: html_helper
INFO - 2025-05-10 06:34:09 --> Database Driver Class Initialized
DEBUG - 2025-05-10 06:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 06:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 06:34:09 --> Controller Class Initialized
INFO - 2025-05-10 06:34:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 06:34:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 06:34:09 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 06:34:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 06:34:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 06:34:09 --> Final output sent to browser
DEBUG - 2025-05-10 06:34:09 --> Total execution time: 0.0290
INFO - 2025-05-10 08:18:01 --> Config Class Initialized
INFO - 2025-05-10 08:18:01 --> Hooks Class Initialized
DEBUG - 2025-05-10 08:18:01 --> UTF-8 Support Enabled
INFO - 2025-05-10 08:18:01 --> Utf8 Class Initialized
INFO - 2025-05-10 08:18:01 --> URI Class Initialized
DEBUG - 2025-05-10 08:18:01 --> No URI present. Default controller set.
INFO - 2025-05-10 08:18:01 --> Router Class Initialized
INFO - 2025-05-10 08:18:01 --> Output Class Initialized
INFO - 2025-05-10 08:18:01 --> Security Class Initialized
DEBUG - 2025-05-10 08:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 08:18:01 --> Input Class Initialized
INFO - 2025-05-10 08:18:01 --> Language Class Initialized
INFO - 2025-05-10 08:18:01 --> Loader Class Initialized
INFO - 2025-05-10 08:18:01 --> Helper loaded: url_helper
INFO - 2025-05-10 08:18:01 --> Helper loaded: string_helper
INFO - 2025-05-10 08:18:01 --> Helper loaded: form_helper
INFO - 2025-05-10 08:18:01 --> Helper loaded: file_helper
INFO - 2025-05-10 08:18:01 --> Helper loaded: html_helper
INFO - 2025-05-10 08:18:01 --> Database Driver Class Initialized
DEBUG - 2025-05-10 08:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 08:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 08:18:01 --> Controller Class Initialized
INFO - 2025-05-10 08:18:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 08:18:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 08:18:01 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 08:18:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 08:18:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 08:18:01 --> Final output sent to browser
DEBUG - 2025-05-10 08:18:01 --> Total execution time: 0.0578
INFO - 2025-05-10 08:18:31 --> Config Class Initialized
INFO - 2025-05-10 08:18:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 08:18:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 08:18:31 --> Utf8 Class Initialized
INFO - 2025-05-10 08:18:31 --> URI Class Initialized
DEBUG - 2025-05-10 08:18:31 --> No URI present. Default controller set.
INFO - 2025-05-10 08:18:31 --> Router Class Initialized
INFO - 2025-05-10 08:18:31 --> Output Class Initialized
INFO - 2025-05-10 08:18:31 --> Security Class Initialized
DEBUG - 2025-05-10 08:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 08:18:31 --> Input Class Initialized
INFO - 2025-05-10 08:18:31 --> Language Class Initialized
INFO - 2025-05-10 08:18:31 --> Loader Class Initialized
INFO - 2025-05-10 08:18:31 --> Helper loaded: url_helper
INFO - 2025-05-10 08:18:31 --> Helper loaded: string_helper
INFO - 2025-05-10 08:18:31 --> Helper loaded: form_helper
INFO - 2025-05-10 08:18:31 --> Helper loaded: file_helper
INFO - 2025-05-10 08:18:31 --> Helper loaded: html_helper
INFO - 2025-05-10 08:18:31 --> Database Driver Class Initialized
DEBUG - 2025-05-10 08:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 08:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 08:18:31 --> Controller Class Initialized
INFO - 2025-05-10 08:18:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 08:18:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 08:18:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 08:18:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 08:18:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 08:18:31 --> Final output sent to browser
DEBUG - 2025-05-10 08:18:31 --> Total execution time: 0.0058
INFO - 2025-05-10 08:18:33 --> Config Class Initialized
INFO - 2025-05-10 08:18:33 --> Hooks Class Initialized
DEBUG - 2025-05-10 08:18:33 --> UTF-8 Support Enabled
INFO - 2025-05-10 08:18:33 --> Utf8 Class Initialized
INFO - 2025-05-10 08:18:33 --> URI Class Initialized
DEBUG - 2025-05-10 08:18:33 --> No URI present. Default controller set.
INFO - 2025-05-10 08:18:33 --> Router Class Initialized
INFO - 2025-05-10 08:18:33 --> Output Class Initialized
INFO - 2025-05-10 08:18:33 --> Security Class Initialized
DEBUG - 2025-05-10 08:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 08:18:33 --> Input Class Initialized
INFO - 2025-05-10 08:18:33 --> Language Class Initialized
INFO - 2025-05-10 08:18:33 --> Loader Class Initialized
INFO - 2025-05-10 08:18:33 --> Helper loaded: url_helper
INFO - 2025-05-10 08:18:33 --> Helper loaded: string_helper
INFO - 2025-05-10 08:18:33 --> Helper loaded: form_helper
INFO - 2025-05-10 08:18:33 --> Helper loaded: file_helper
INFO - 2025-05-10 08:18:33 --> Helper loaded: html_helper
INFO - 2025-05-10 08:18:33 --> Database Driver Class Initialized
DEBUG - 2025-05-10 08:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 08:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 08:18:33 --> Controller Class Initialized
INFO - 2025-05-10 08:18:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 08:18:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 08:18:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 08:18:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 08:18:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 08:18:33 --> Final output sent to browser
DEBUG - 2025-05-10 08:18:33 --> Total execution time: 0.0051
INFO - 2025-05-10 08:20:32 --> Config Class Initialized
INFO - 2025-05-10 08:20:32 --> Hooks Class Initialized
DEBUG - 2025-05-10 08:20:32 --> UTF-8 Support Enabled
INFO - 2025-05-10 08:20:32 --> Utf8 Class Initialized
INFO - 2025-05-10 08:20:32 --> URI Class Initialized
DEBUG - 2025-05-10 08:20:32 --> No URI present. Default controller set.
INFO - 2025-05-10 08:20:32 --> Router Class Initialized
INFO - 2025-05-10 08:20:32 --> Output Class Initialized
INFO - 2025-05-10 08:20:32 --> Security Class Initialized
DEBUG - 2025-05-10 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 08:20:32 --> Input Class Initialized
INFO - 2025-05-10 08:20:32 --> Language Class Initialized
INFO - 2025-05-10 08:20:32 --> Loader Class Initialized
INFO - 2025-05-10 08:20:32 --> Helper loaded: url_helper
INFO - 2025-05-10 08:20:32 --> Helper loaded: string_helper
INFO - 2025-05-10 08:20:32 --> Helper loaded: form_helper
INFO - 2025-05-10 08:20:32 --> Helper loaded: file_helper
INFO - 2025-05-10 08:20:32 --> Helper loaded: html_helper
INFO - 2025-05-10 08:20:32 --> Database Driver Class Initialized
DEBUG - 2025-05-10 08:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 08:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 08:20:32 --> Controller Class Initialized
INFO - 2025-05-10 08:20:32 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 08:20:32 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 08:20:32 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 08:20:32 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 08:20:32 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 08:20:32 --> Final output sent to browser
DEBUG - 2025-05-10 08:20:32 --> Total execution time: 0.0289
INFO - 2025-05-10 08:57:51 --> Config Class Initialized
INFO - 2025-05-10 08:57:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 08:57:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 08:57:51 --> Utf8 Class Initialized
INFO - 2025-05-10 08:57:51 --> URI Class Initialized
DEBUG - 2025-05-10 08:57:51 --> No URI present. Default controller set.
INFO - 2025-05-10 08:57:51 --> Router Class Initialized
INFO - 2025-05-10 08:57:51 --> Output Class Initialized
INFO - 2025-05-10 08:57:51 --> Security Class Initialized
DEBUG - 2025-05-10 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 08:57:51 --> Input Class Initialized
INFO - 2025-05-10 08:57:51 --> Language Class Initialized
INFO - 2025-05-10 08:57:51 --> Loader Class Initialized
INFO - 2025-05-10 08:57:51 --> Helper loaded: url_helper
INFO - 2025-05-10 08:57:51 --> Helper loaded: string_helper
INFO - 2025-05-10 08:57:51 --> Helper loaded: form_helper
INFO - 2025-05-10 08:57:51 --> Helper loaded: file_helper
INFO - 2025-05-10 08:57:51 --> Helper loaded: html_helper
INFO - 2025-05-10 08:57:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 08:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 08:57:51 --> Controller Class Initialized
INFO - 2025-05-10 08:57:51 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 08:57:51 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 08:57:51 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 08:57:51 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 08:57:51 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 08:57:51 --> Final output sent to browser
DEBUG - 2025-05-10 08:57:51 --> Total execution time: 0.0549
INFO - 2025-05-10 09:03:10 --> Config Class Initialized
INFO - 2025-05-10 09:03:10 --> Hooks Class Initialized
DEBUG - 2025-05-10 09:03:10 --> UTF-8 Support Enabled
INFO - 2025-05-10 09:03:10 --> Utf8 Class Initialized
INFO - 2025-05-10 09:03:10 --> URI Class Initialized
DEBUG - 2025-05-10 09:03:10 --> No URI present. Default controller set.
INFO - 2025-05-10 09:03:10 --> Router Class Initialized
INFO - 2025-05-10 09:03:10 --> Output Class Initialized
INFO - 2025-05-10 09:03:10 --> Security Class Initialized
DEBUG - 2025-05-10 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 09:03:10 --> Input Class Initialized
INFO - 2025-05-10 09:03:10 --> Language Class Initialized
INFO - 2025-05-10 09:03:10 --> Loader Class Initialized
INFO - 2025-05-10 09:03:10 --> Helper loaded: url_helper
INFO - 2025-05-10 09:03:10 --> Helper loaded: string_helper
INFO - 2025-05-10 09:03:10 --> Helper loaded: form_helper
INFO - 2025-05-10 09:03:10 --> Helper loaded: file_helper
INFO - 2025-05-10 09:03:10 --> Helper loaded: html_helper
INFO - 2025-05-10 09:03:10 --> Database Driver Class Initialized
DEBUG - 2025-05-10 09:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 09:03:10 --> Controller Class Initialized
INFO - 2025-05-10 09:03:10 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 09:03:10 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 09:03:10 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 09:03:10 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 09:03:10 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 09:03:10 --> Final output sent to browser
DEBUG - 2025-05-10 09:03:10 --> Total execution time: 0.0298
INFO - 2025-05-10 10:23:47 --> Config Class Initialized
INFO - 2025-05-10 10:23:47 --> Hooks Class Initialized
DEBUG - 2025-05-10 10:23:47 --> UTF-8 Support Enabled
INFO - 2025-05-10 10:23:47 --> Utf8 Class Initialized
INFO - 2025-05-10 10:23:47 --> URI Class Initialized
DEBUG - 2025-05-10 10:23:47 --> No URI present. Default controller set.
INFO - 2025-05-10 10:23:47 --> Router Class Initialized
INFO - 2025-05-10 10:23:47 --> Output Class Initialized
INFO - 2025-05-10 10:23:47 --> Security Class Initialized
DEBUG - 2025-05-10 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 10:23:47 --> Input Class Initialized
INFO - 2025-05-10 10:23:47 --> Language Class Initialized
INFO - 2025-05-10 10:23:47 --> Loader Class Initialized
INFO - 2025-05-10 10:23:47 --> Helper loaded: url_helper
INFO - 2025-05-10 10:23:47 --> Helper loaded: string_helper
INFO - 2025-05-10 10:23:47 --> Helper loaded: form_helper
INFO - 2025-05-10 10:23:47 --> Helper loaded: file_helper
INFO - 2025-05-10 10:23:47 --> Helper loaded: html_helper
INFO - 2025-05-10 10:23:47 --> Database Driver Class Initialized
DEBUG - 2025-05-10 10:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 10:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 10:23:47 --> Controller Class Initialized
INFO - 2025-05-10 10:23:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 10:23:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 10:23:47 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 10:23:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 10:23:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 10:23:47 --> Final output sent to browser
DEBUG - 2025-05-10 10:23:47 --> Total execution time: 0.0595
INFO - 2025-05-10 10:23:48 --> Config Class Initialized
INFO - 2025-05-10 10:23:48 --> Hooks Class Initialized
DEBUG - 2025-05-10 10:23:48 --> UTF-8 Support Enabled
INFO - 2025-05-10 10:23:48 --> Utf8 Class Initialized
INFO - 2025-05-10 10:23:48 --> URI Class Initialized
INFO - 2025-05-10 10:23:48 --> Router Class Initialized
INFO - 2025-05-10 10:23:48 --> Output Class Initialized
INFO - 2025-05-10 10:23:48 --> Security Class Initialized
DEBUG - 2025-05-10 10:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 10:23:48 --> Input Class Initialized
INFO - 2025-05-10 10:23:48 --> Language Class Initialized
ERROR - 2025-05-10 10:23:48 --> 404 Page Not Found: Faviconpng/index
INFO - 2025-05-10 11:00:41 --> Config Class Initialized
INFO - 2025-05-10 11:00:41 --> Hooks Class Initialized
DEBUG - 2025-05-10 11:00:41 --> UTF-8 Support Enabled
INFO - 2025-05-10 11:00:41 --> Utf8 Class Initialized
INFO - 2025-05-10 11:00:41 --> URI Class Initialized
DEBUG - 2025-05-10 11:00:41 --> No URI present. Default controller set.
INFO - 2025-05-10 11:00:41 --> Router Class Initialized
INFO - 2025-05-10 11:00:41 --> Output Class Initialized
INFO - 2025-05-10 11:00:41 --> Security Class Initialized
DEBUG - 2025-05-10 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 11:00:41 --> Input Class Initialized
INFO - 2025-05-10 11:00:41 --> Language Class Initialized
INFO - 2025-05-10 11:00:41 --> Loader Class Initialized
INFO - 2025-05-10 11:00:41 --> Helper loaded: url_helper
INFO - 2025-05-10 11:00:41 --> Helper loaded: string_helper
INFO - 2025-05-10 11:00:41 --> Helper loaded: form_helper
INFO - 2025-05-10 11:00:41 --> Helper loaded: file_helper
INFO - 2025-05-10 11:00:41 --> Helper loaded: html_helper
INFO - 2025-05-10 11:00:41 --> Database Driver Class Initialized
DEBUG - 2025-05-10 11:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 11:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 11:00:41 --> Controller Class Initialized
INFO - 2025-05-10 11:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 11:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 11:00:41 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 11:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 11:00:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 11:00:41 --> Final output sent to browser
DEBUG - 2025-05-10 11:00:41 --> Total execution time: 0.0315
INFO - 2025-05-10 11:00:45 --> Config Class Initialized
INFO - 2025-05-10 11:00:45 --> Hooks Class Initialized
DEBUG - 2025-05-10 11:00:45 --> UTF-8 Support Enabled
INFO - 2025-05-10 11:00:45 --> Utf8 Class Initialized
INFO - 2025-05-10 11:00:45 --> URI Class Initialized
INFO - 2025-05-10 11:00:45 --> Router Class Initialized
INFO - 2025-05-10 11:00:45 --> Output Class Initialized
INFO - 2025-05-10 11:00:45 --> Security Class Initialized
DEBUG - 2025-05-10 11:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 11:00:45 --> Input Class Initialized
INFO - 2025-05-10 11:00:45 --> Language Class Initialized
ERROR - 2025-05-10 11:00:45 --> 404 Page Not Found: Js/index
INFO - 2025-05-10 12:17:06 --> Config Class Initialized
INFO - 2025-05-10 12:17:06 --> Hooks Class Initialized
DEBUG - 2025-05-10 12:17:06 --> UTF-8 Support Enabled
INFO - 2025-05-10 12:17:06 --> Utf8 Class Initialized
INFO - 2025-05-10 12:17:06 --> URI Class Initialized
DEBUG - 2025-05-10 12:17:06 --> No URI present. Default controller set.
INFO - 2025-05-10 12:17:06 --> Router Class Initialized
INFO - 2025-05-10 12:17:06 --> Output Class Initialized
INFO - 2025-05-10 12:17:06 --> Security Class Initialized
DEBUG - 2025-05-10 12:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 12:17:06 --> Input Class Initialized
INFO - 2025-05-10 12:17:06 --> Language Class Initialized
INFO - 2025-05-10 12:17:06 --> Loader Class Initialized
INFO - 2025-05-10 12:17:06 --> Helper loaded: url_helper
INFO - 2025-05-10 12:17:06 --> Helper loaded: string_helper
INFO - 2025-05-10 12:17:06 --> Helper loaded: form_helper
INFO - 2025-05-10 12:17:06 --> Helper loaded: file_helper
INFO - 2025-05-10 12:17:06 --> Helper loaded: html_helper
INFO - 2025-05-10 12:17:06 --> Database Driver Class Initialized
DEBUG - 2025-05-10 12:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 12:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 12:17:06 --> Controller Class Initialized
INFO - 2025-05-10 12:17:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 12:17:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 12:17:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 12:17:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 12:17:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 12:17:06 --> Final output sent to browser
DEBUG - 2025-05-10 12:17:06 --> Total execution time: 0.0565
INFO - 2025-05-10 12:45:39 --> Config Class Initialized
INFO - 2025-05-10 12:45:39 --> Hooks Class Initialized
DEBUG - 2025-05-10 12:45:39 --> UTF-8 Support Enabled
INFO - 2025-05-10 12:45:39 --> Utf8 Class Initialized
INFO - 2025-05-10 12:45:39 --> URI Class Initialized
INFO - 2025-05-10 12:45:39 --> Router Class Initialized
INFO - 2025-05-10 12:45:39 --> Output Class Initialized
INFO - 2025-05-10 12:45:39 --> Security Class Initialized
DEBUG - 2025-05-10 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 12:45:39 --> Input Class Initialized
INFO - 2025-05-10 12:45:39 --> Language Class Initialized
ERROR - 2025-05-10 12:45:39 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 12:45:40 --> Config Class Initialized
INFO - 2025-05-10 12:45:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 12:45:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 12:45:40 --> Utf8 Class Initialized
INFO - 2025-05-10 12:45:40 --> URI Class Initialized
DEBUG - 2025-05-10 12:45:40 --> No URI present. Default controller set.
INFO - 2025-05-10 12:45:40 --> Router Class Initialized
INFO - 2025-05-10 12:45:40 --> Output Class Initialized
INFO - 2025-05-10 12:45:40 --> Security Class Initialized
DEBUG - 2025-05-10 12:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 12:45:40 --> Input Class Initialized
INFO - 2025-05-10 12:45:40 --> Language Class Initialized
INFO - 2025-05-10 12:45:40 --> Loader Class Initialized
INFO - 2025-05-10 12:45:40 --> Helper loaded: url_helper
INFO - 2025-05-10 12:45:40 --> Helper loaded: string_helper
INFO - 2025-05-10 12:45:40 --> Helper loaded: form_helper
INFO - 2025-05-10 12:45:40 --> Helper loaded: file_helper
INFO - 2025-05-10 12:45:40 --> Helper loaded: html_helper
INFO - 2025-05-10 12:45:40 --> Database Driver Class Initialized
DEBUG - 2025-05-10 12:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 12:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 12:45:40 --> Controller Class Initialized
INFO - 2025-05-10 12:45:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 12:45:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 12:45:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 12:45:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 12:45:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 12:45:40 --> Final output sent to browser
DEBUG - 2025-05-10 12:45:40 --> Total execution time: 0.0335
INFO - 2025-05-10 12:51:17 --> Config Class Initialized
INFO - 2025-05-10 12:51:17 --> Hooks Class Initialized
DEBUG - 2025-05-10 12:51:17 --> UTF-8 Support Enabled
INFO - 2025-05-10 12:51:17 --> Utf8 Class Initialized
INFO - 2025-05-10 12:51:17 --> URI Class Initialized
DEBUG - 2025-05-10 12:51:17 --> No URI present. Default controller set.
INFO - 2025-05-10 12:51:17 --> Router Class Initialized
INFO - 2025-05-10 12:51:17 --> Output Class Initialized
INFO - 2025-05-10 12:51:17 --> Security Class Initialized
DEBUG - 2025-05-10 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 12:51:17 --> Input Class Initialized
INFO - 2025-05-10 12:51:17 --> Language Class Initialized
INFO - 2025-05-10 12:51:17 --> Loader Class Initialized
INFO - 2025-05-10 12:51:17 --> Helper loaded: url_helper
INFO - 2025-05-10 12:51:17 --> Helper loaded: string_helper
INFO - 2025-05-10 12:51:17 --> Helper loaded: form_helper
INFO - 2025-05-10 12:51:17 --> Helper loaded: file_helper
INFO - 2025-05-10 12:51:17 --> Helper loaded: html_helper
INFO - 2025-05-10 12:51:17 --> Database Driver Class Initialized
DEBUG - 2025-05-10 12:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 12:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 12:51:17 --> Controller Class Initialized
INFO - 2025-05-10 12:51:17 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 12:51:17 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 12:51:17 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 12:51:17 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 12:51:17 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 12:51:17 --> Final output sent to browser
DEBUG - 2025-05-10 12:51:17 --> Total execution time: 0.0285
INFO - 2025-05-10 13:19:53 --> Config Class Initialized
INFO - 2025-05-10 13:19:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 13:19:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 13:19:53 --> Utf8 Class Initialized
INFO - 2025-05-10 13:19:53 --> URI Class Initialized
DEBUG - 2025-05-10 13:19:53 --> No URI present. Default controller set.
INFO - 2025-05-10 13:19:53 --> Router Class Initialized
INFO - 2025-05-10 13:19:53 --> Output Class Initialized
INFO - 2025-05-10 13:19:53 --> Security Class Initialized
DEBUG - 2025-05-10 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 13:19:53 --> Input Class Initialized
INFO - 2025-05-10 13:19:53 --> Language Class Initialized
INFO - 2025-05-10 13:19:53 --> Loader Class Initialized
INFO - 2025-05-10 13:19:53 --> Helper loaded: url_helper
INFO - 2025-05-10 13:19:53 --> Helper loaded: string_helper
INFO - 2025-05-10 13:19:53 --> Helper loaded: form_helper
INFO - 2025-05-10 13:19:53 --> Helper loaded: file_helper
INFO - 2025-05-10 13:19:53 --> Helper loaded: html_helper
INFO - 2025-05-10 13:19:53 --> Database Driver Class Initialized
DEBUG - 2025-05-10 13:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 13:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 13:19:53 --> Controller Class Initialized
INFO - 2025-05-10 13:19:53 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 13:19:53 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 13:19:53 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 13:19:53 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 13:19:53 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 13:19:53 --> Final output sent to browser
DEBUG - 2025-05-10 13:19:53 --> Total execution time: 0.0558
INFO - 2025-05-10 14:29:05 --> Config Class Initialized
INFO - 2025-05-10 14:29:05 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:29:05 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:29:05 --> Utf8 Class Initialized
INFO - 2025-05-10 14:29:05 --> URI Class Initialized
DEBUG - 2025-05-10 14:29:05 --> No URI present. Default controller set.
INFO - 2025-05-10 14:29:05 --> Router Class Initialized
INFO - 2025-05-10 14:29:05 --> Output Class Initialized
INFO - 2025-05-10 14:29:05 --> Security Class Initialized
DEBUG - 2025-05-10 14:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:29:05 --> Input Class Initialized
INFO - 2025-05-10 14:29:05 --> Language Class Initialized
INFO - 2025-05-10 14:29:05 --> Loader Class Initialized
INFO - 2025-05-10 14:29:05 --> Helper loaded: url_helper
INFO - 2025-05-10 14:29:05 --> Helper loaded: string_helper
INFO - 2025-05-10 14:29:05 --> Helper loaded: form_helper
INFO - 2025-05-10 14:29:05 --> Helper loaded: file_helper
INFO - 2025-05-10 14:29:05 --> Helper loaded: html_helper
INFO - 2025-05-10 14:29:05 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:29:05 --> Controller Class Initialized
INFO - 2025-05-10 14:29:05 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 14:29:05 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 14:29:05 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 14:29:05 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 14:29:05 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 14:29:05 --> Final output sent to browser
DEBUG - 2025-05-10 14:29:05 --> Total execution time: 0.0575
INFO - 2025-05-10 14:35:32 --> Config Class Initialized
INFO - 2025-05-10 14:35:32 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:35:32 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:35:32 --> Utf8 Class Initialized
INFO - 2025-05-10 14:35:32 --> URI Class Initialized
INFO - 2025-05-10 14:35:32 --> Router Class Initialized
INFO - 2025-05-10 14:35:32 --> Output Class Initialized
INFO - 2025-05-10 14:35:32 --> Security Class Initialized
DEBUG - 2025-05-10 14:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:35:32 --> Input Class Initialized
INFO - 2025-05-10 14:35:32 --> Language Class Initialized
ERROR - 2025-05-10 14:35:32 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-10 14:35:33 --> Config Class Initialized
INFO - 2025-05-10 14:35:33 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:35:33 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:35:33 --> Utf8 Class Initialized
INFO - 2025-05-10 14:35:33 --> URI Class Initialized
DEBUG - 2025-05-10 14:35:33 --> No URI present. Default controller set.
INFO - 2025-05-10 14:35:33 --> Router Class Initialized
INFO - 2025-05-10 14:35:33 --> Output Class Initialized
INFO - 2025-05-10 14:35:33 --> Security Class Initialized
DEBUG - 2025-05-10 14:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:35:33 --> Input Class Initialized
INFO - 2025-05-10 14:35:33 --> Language Class Initialized
INFO - 2025-05-10 14:35:33 --> Loader Class Initialized
INFO - 2025-05-10 14:35:33 --> Helper loaded: url_helper
INFO - 2025-05-10 14:35:33 --> Helper loaded: string_helper
INFO - 2025-05-10 14:35:33 --> Helper loaded: form_helper
INFO - 2025-05-10 14:35:33 --> Helper loaded: file_helper
INFO - 2025-05-10 14:35:33 --> Helper loaded: html_helper
INFO - 2025-05-10 14:35:33 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:35:33 --> Controller Class Initialized
INFO - 2025-05-10 14:35:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 14:35:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 14:35:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 14:35:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 14:35:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 14:35:33 --> Final output sent to browser
DEBUG - 2025-05-10 14:35:33 --> Total execution time: 0.0267
INFO - 2025-05-10 15:08:08 --> Config Class Initialized
INFO - 2025-05-10 15:08:08 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:08:08 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:08:08 --> Utf8 Class Initialized
INFO - 2025-05-10 15:08:08 --> URI Class Initialized
DEBUG - 2025-05-10 15:08:08 --> No URI present. Default controller set.
INFO - 2025-05-10 15:08:08 --> Router Class Initialized
INFO - 2025-05-10 15:08:08 --> Output Class Initialized
INFO - 2025-05-10 15:08:08 --> Security Class Initialized
DEBUG - 2025-05-10 15:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:08:08 --> Input Class Initialized
INFO - 2025-05-10 15:08:08 --> Language Class Initialized
INFO - 2025-05-10 15:08:08 --> Loader Class Initialized
INFO - 2025-05-10 15:08:08 --> Helper loaded: url_helper
INFO - 2025-05-10 15:08:08 --> Helper loaded: string_helper
INFO - 2025-05-10 15:08:08 --> Helper loaded: form_helper
INFO - 2025-05-10 15:08:08 --> Helper loaded: file_helper
INFO - 2025-05-10 15:08:08 --> Helper loaded: html_helper
INFO - 2025-05-10 15:08:08 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:08:08 --> Controller Class Initialized
INFO - 2025-05-10 15:08:08 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 15:08:08 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 15:08:08 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 15:08:08 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 15:08:08 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 15:08:08 --> Final output sent to browser
DEBUG - 2025-05-10 15:08:08 --> Total execution time: 0.0580
INFO - 2025-05-10 15:08:09 --> Config Class Initialized
INFO - 2025-05-10 15:08:09 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:08:09 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:08:09 --> Utf8 Class Initialized
INFO - 2025-05-10 15:08:09 --> URI Class Initialized
DEBUG - 2025-05-10 15:08:09 --> No URI present. Default controller set.
INFO - 2025-05-10 15:08:09 --> Router Class Initialized
INFO - 2025-05-10 15:08:09 --> Output Class Initialized
INFO - 2025-05-10 15:08:09 --> Security Class Initialized
DEBUG - 2025-05-10 15:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:08:09 --> Input Class Initialized
INFO - 2025-05-10 15:08:09 --> Language Class Initialized
INFO - 2025-05-10 15:08:09 --> Loader Class Initialized
INFO - 2025-05-10 15:08:09 --> Helper loaded: url_helper
INFO - 2025-05-10 15:08:09 --> Helper loaded: string_helper
INFO - 2025-05-10 15:08:09 --> Helper loaded: form_helper
INFO - 2025-05-10 15:08:09 --> Helper loaded: file_helper
INFO - 2025-05-10 15:08:09 --> Helper loaded: html_helper
INFO - 2025-05-10 15:08:09 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:08:09 --> Controller Class Initialized
INFO - 2025-05-10 15:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 15:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 15:08:09 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 15:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 15:08:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 15:08:09 --> Final output sent to browser
DEBUG - 2025-05-10 15:08:09 --> Total execution time: 0.0038
INFO - 2025-05-10 15:24:50 --> Config Class Initialized
INFO - 2025-05-10 15:24:50 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:24:50 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:24:50 --> Utf8 Class Initialized
INFO - 2025-05-10 15:24:50 --> URI Class Initialized
DEBUG - 2025-05-10 15:24:50 --> No URI present. Default controller set.
INFO - 2025-05-10 15:24:50 --> Router Class Initialized
INFO - 2025-05-10 15:24:50 --> Output Class Initialized
INFO - 2025-05-10 15:24:50 --> Security Class Initialized
DEBUG - 2025-05-10 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:24:50 --> Input Class Initialized
INFO - 2025-05-10 15:24:50 --> Language Class Initialized
INFO - 2025-05-10 15:24:50 --> Loader Class Initialized
INFO - 2025-05-10 15:24:50 --> Helper loaded: url_helper
INFO - 2025-05-10 15:24:50 --> Helper loaded: string_helper
INFO - 2025-05-10 15:24:50 --> Helper loaded: form_helper
INFO - 2025-05-10 15:24:50 --> Helper loaded: file_helper
INFO - 2025-05-10 15:24:50 --> Helper loaded: html_helper
INFO - 2025-05-10 15:24:50 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:24:50 --> Controller Class Initialized
INFO - 2025-05-10 15:24:50 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 15:24:50 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 15:24:50 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 15:24:50 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 15:24:50 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 15:24:50 --> Final output sent to browser
DEBUG - 2025-05-10 15:24:50 --> Total execution time: 0.0289
INFO - 2025-05-10 15:44:21 --> Config Class Initialized
INFO - 2025-05-10 15:44:21 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:44:21 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:44:21 --> Utf8 Class Initialized
INFO - 2025-05-10 15:44:21 --> URI Class Initialized
DEBUG - 2025-05-10 15:44:22 --> No URI present. Default controller set.
INFO - 2025-05-10 15:44:22 --> Router Class Initialized
INFO - 2025-05-10 15:44:22 --> Output Class Initialized
INFO - 2025-05-10 15:44:22 --> Security Class Initialized
DEBUG - 2025-05-10 15:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:44:22 --> Input Class Initialized
INFO - 2025-05-10 15:44:22 --> Language Class Initialized
INFO - 2025-05-10 15:44:22 --> Loader Class Initialized
INFO - 2025-05-10 15:44:22 --> Helper loaded: url_helper
INFO - 2025-05-10 15:44:22 --> Helper loaded: string_helper
INFO - 2025-05-10 15:44:22 --> Helper loaded: form_helper
INFO - 2025-05-10 15:44:22 --> Helper loaded: file_helper
INFO - 2025-05-10 15:44:22 --> Helper loaded: html_helper
INFO - 2025-05-10 15:44:22 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:44:22 --> Controller Class Initialized
INFO - 2025-05-10 15:44:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-10 15:44:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-10 15:44:22 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-10 15:44:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-10 15:44:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-10 15:44:22 --> Final output sent to browser
DEBUG - 2025-05-10 15:44:22 --> Total execution time: 0.1063
