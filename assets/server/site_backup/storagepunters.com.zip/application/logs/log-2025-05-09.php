<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-09 00:04:40 --> Config Class Initialized
INFO - 2025-05-09 00:04:40 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:04:40 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:04:40 --> Utf8 Class Initialized
INFO - 2025-05-09 00:04:40 --> URI Class Initialized
DEBUG - 2025-05-09 00:04:40 --> No URI present. Default controller set.
INFO - 2025-05-09 00:04:40 --> Router Class Initialized
INFO - 2025-05-09 00:04:40 --> Output Class Initialized
INFO - 2025-05-09 00:04:40 --> Security Class Initialized
DEBUG - 2025-05-09 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:04:40 --> Input Class Initialized
INFO - 2025-05-09 00:04:40 --> Language Class Initialized
INFO - 2025-05-09 00:04:40 --> Loader Class Initialized
INFO - 2025-05-09 00:04:40 --> Helper loaded: url_helper
INFO - 2025-05-09 00:04:40 --> Helper loaded: string_helper
INFO - 2025-05-09 00:04:40 --> Helper loaded: form_helper
INFO - 2025-05-09 00:04:40 --> Helper loaded: file_helper
INFO - 2025-05-09 00:04:40 --> Helper loaded: html_helper
INFO - 2025-05-09 00:04:40 --> Database Driver Class Initialized
DEBUG - 2025-05-09 00:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 00:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 00:04:40 --> Controller Class Initialized
INFO - 2025-05-09 00:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 00:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 00:04:40 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 00:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 00:04:40 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 00:04:40 --> Final output sent to browser
DEBUG - 2025-05-09 00:04:40 --> Total execution time: 0.0490
INFO - 2025-05-09 00:42:09 --> Config Class Initialized
INFO - 2025-05-09 00:42:09 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:42:09 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:42:09 --> Utf8 Class Initialized
INFO - 2025-05-09 00:42:09 --> URI Class Initialized
DEBUG - 2025-05-09 00:42:09 --> No URI present. Default controller set.
INFO - 2025-05-09 00:42:09 --> Router Class Initialized
INFO - 2025-05-09 00:42:09 --> Output Class Initialized
INFO - 2025-05-09 00:42:09 --> Security Class Initialized
DEBUG - 2025-05-09 00:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:42:09 --> Input Class Initialized
INFO - 2025-05-09 00:42:09 --> Language Class Initialized
INFO - 2025-05-09 00:42:09 --> Loader Class Initialized
INFO - 2025-05-09 00:42:09 --> Helper loaded: url_helper
INFO - 2025-05-09 00:42:09 --> Helper loaded: string_helper
INFO - 2025-05-09 00:42:09 --> Helper loaded: form_helper
INFO - 2025-05-09 00:42:09 --> Helper loaded: file_helper
INFO - 2025-05-09 00:42:09 --> Helper loaded: html_helper
INFO - 2025-05-09 00:42:09 --> Database Driver Class Initialized
DEBUG - 2025-05-09 00:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 00:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 00:42:09 --> Controller Class Initialized
INFO - 2025-05-09 00:42:09 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 00:42:09 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 00:42:09 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 00:42:09 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 00:42:09 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 00:42:09 --> Final output sent to browser
DEBUG - 2025-05-09 00:42:09 --> Total execution time: 0.0304
INFO - 2025-05-09 00:56:47 --> Config Class Initialized
INFO - 2025-05-09 00:56:47 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:56:47 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:56:47 --> Utf8 Class Initialized
INFO - 2025-05-09 00:56:47 --> URI Class Initialized
DEBUG - 2025-05-09 00:56:47 --> No URI present. Default controller set.
INFO - 2025-05-09 00:56:47 --> Router Class Initialized
INFO - 2025-05-09 00:56:47 --> Output Class Initialized
INFO - 2025-05-09 00:56:47 --> Security Class Initialized
DEBUG - 2025-05-09 00:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:56:47 --> Input Class Initialized
INFO - 2025-05-09 00:56:47 --> Language Class Initialized
INFO - 2025-05-09 00:56:47 --> Loader Class Initialized
INFO - 2025-05-09 00:56:47 --> Helper loaded: url_helper
INFO - 2025-05-09 00:56:47 --> Helper loaded: string_helper
INFO - 2025-05-09 00:56:47 --> Helper loaded: form_helper
INFO - 2025-05-09 00:56:47 --> Helper loaded: file_helper
INFO - 2025-05-09 00:56:47 --> Helper loaded: html_helper
INFO - 2025-05-09 00:56:47 --> Database Driver Class Initialized
DEBUG - 2025-05-09 00:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 00:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 00:56:47 --> Controller Class Initialized
INFO - 2025-05-09 00:56:47 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 00:56:47 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 00:56:47 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 00:56:47 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 00:56:47 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 00:56:47 --> Final output sent to browser
DEBUG - 2025-05-09 00:56:47 --> Total execution time: 0.0291
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Cdndatatablesnet/1.13.6
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Codejquerycom/jquery-3.6.0.min.js
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Build/global
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Dist/js
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Swiper-bundleminjs/index
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:35 --> Config Class Initialized
INFO - 2025-05-09 00:57:35 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:35 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:35 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:35 --> URI Class Initialized
INFO - 2025-05-09 00:57:35 --> Router Class Initialized
INFO - 2025-05-09 00:57:35 --> Output Class Initialized
INFO - 2025-05-09 00:57:35 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:35 --> Input Class Initialized
INFO - 2025-05-09 00:57:35 --> Language Class Initialized
ERROR - 2025-05-09 00:57:35 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 00:57:36 --> Config Class Initialized
INFO - 2025-05-09 00:57:36 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:36 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:36 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:36 --> URI Class Initialized
INFO - 2025-05-09 00:57:36 --> Router Class Initialized
INFO - 2025-05-09 00:57:36 --> Output Class Initialized
INFO - 2025-05-09 00:57:36 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:36 --> Input Class Initialized
INFO - 2025-05-09 00:57:36 --> Language Class Initialized
ERROR - 2025-05-09 00:57:36 --> 404 Page Not Found: Ui/dist
INFO - 2025-05-09 00:57:39 --> Config Class Initialized
INFO - 2025-05-09 00:57:39 --> Hooks Class Initialized
DEBUG - 2025-05-09 00:57:39 --> UTF-8 Support Enabled
INFO - 2025-05-09 00:57:39 --> Utf8 Class Initialized
INFO - 2025-05-09 00:57:39 --> URI Class Initialized
INFO - 2025-05-09 00:57:39 --> Router Class Initialized
INFO - 2025-05-09 00:57:39 --> Output Class Initialized
INFO - 2025-05-09 00:57:39 --> Security Class Initialized
DEBUG - 2025-05-09 00:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 00:57:39 --> Input Class Initialized
INFO - 2025-05-09 00:57:39 --> Language Class Initialized
ERROR - 2025-05-09 00:57:39 --> 404 Page Not Found: Cdnjs/index
INFO - 2025-05-09 02:12:22 --> Config Class Initialized
INFO - 2025-05-09 02:12:22 --> Hooks Class Initialized
DEBUG - 2025-05-09 02:12:22 --> UTF-8 Support Enabled
INFO - 2025-05-09 02:12:22 --> Utf8 Class Initialized
INFO - 2025-05-09 02:12:22 --> URI Class Initialized
DEBUG - 2025-05-09 02:12:22 --> No URI present. Default controller set.
INFO - 2025-05-09 02:12:22 --> Router Class Initialized
INFO - 2025-05-09 02:12:22 --> Output Class Initialized
INFO - 2025-05-09 02:12:22 --> Security Class Initialized
DEBUG - 2025-05-09 02:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 02:12:22 --> Input Class Initialized
INFO - 2025-05-09 02:12:22 --> Language Class Initialized
INFO - 2025-05-09 02:12:22 --> Loader Class Initialized
INFO - 2025-05-09 02:12:22 --> Helper loaded: url_helper
INFO - 2025-05-09 02:12:22 --> Helper loaded: string_helper
INFO - 2025-05-09 02:12:22 --> Helper loaded: form_helper
INFO - 2025-05-09 02:12:22 --> Helper loaded: file_helper
INFO - 2025-05-09 02:12:22 --> Helper loaded: html_helper
INFO - 2025-05-09 02:12:22 --> Database Driver Class Initialized
DEBUG - 2025-05-09 02:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 02:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 02:12:22 --> Controller Class Initialized
INFO - 2025-05-09 02:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 02:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 02:12:22 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 02:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 02:12:22 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 02:12:22 --> Final output sent to browser
DEBUG - 2025-05-09 02:12:22 --> Total execution time: 0.0520
INFO - 2025-05-09 02:50:01 --> Config Class Initialized
INFO - 2025-05-09 02:50:01 --> Hooks Class Initialized
DEBUG - 2025-05-09 02:50:01 --> UTF-8 Support Enabled
INFO - 2025-05-09 02:50:01 --> Utf8 Class Initialized
INFO - 2025-05-09 02:50:01 --> URI Class Initialized
DEBUG - 2025-05-09 02:50:01 --> No URI present. Default controller set.
INFO - 2025-05-09 02:50:01 --> Router Class Initialized
INFO - 2025-05-09 02:50:01 --> Output Class Initialized
INFO - 2025-05-09 02:50:01 --> Security Class Initialized
DEBUG - 2025-05-09 02:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 02:50:01 --> Input Class Initialized
INFO - 2025-05-09 02:50:01 --> Language Class Initialized
INFO - 2025-05-09 02:50:01 --> Loader Class Initialized
INFO - 2025-05-09 02:50:01 --> Helper loaded: url_helper
INFO - 2025-05-09 02:50:01 --> Helper loaded: string_helper
INFO - 2025-05-09 02:50:01 --> Helper loaded: form_helper
INFO - 2025-05-09 02:50:01 --> Helper loaded: file_helper
INFO - 2025-05-09 02:50:01 --> Helper loaded: html_helper
INFO - 2025-05-09 02:50:01 --> Database Driver Class Initialized
DEBUG - 2025-05-09 02:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 02:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 02:50:01 --> Controller Class Initialized
INFO - 2025-05-09 02:50:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 02:50:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 02:50:01 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 02:50:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 02:50:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 02:50:01 --> Final output sent to browser
DEBUG - 2025-05-09 02:50:01 --> Total execution time: 0.0386
INFO - 2025-05-09 03:09:32 --> Config Class Initialized
INFO - 2025-05-09 03:09:32 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:32 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:32 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:32 --> URI Class Initialized
DEBUG - 2025-05-09 03:09:32 --> No URI present. Default controller set.
INFO - 2025-05-09 03:09:32 --> Router Class Initialized
INFO - 2025-05-09 03:09:32 --> Output Class Initialized
INFO - 2025-05-09 03:09:32 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:32 --> Input Class Initialized
INFO - 2025-05-09 03:09:32 --> Language Class Initialized
INFO - 2025-05-09 03:09:32 --> Loader Class Initialized
INFO - 2025-05-09 03:09:32 --> Helper loaded: url_helper
INFO - 2025-05-09 03:09:32 --> Helper loaded: string_helper
INFO - 2025-05-09 03:09:32 --> Helper loaded: form_helper
INFO - 2025-05-09 03:09:32 --> Helper loaded: file_helper
INFO - 2025-05-09 03:09:32 --> Helper loaded: html_helper
INFO - 2025-05-09 03:09:32 --> Database Driver Class Initialized
DEBUG - 2025-05-09 03:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 03:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 03:09:32 --> Controller Class Initialized
INFO - 2025-05-09 03:09:32 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 03:09:32 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 03:09:32 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 03:09:32 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 03:09:32 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 03:09:32 --> Final output sent to browser
DEBUG - 2025-05-09 03:09:32 --> Total execution time: 0.0285
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Build/global
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Cdndatatablesnet/1.13.6
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Ui/dist
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Swiper-bundleminjs/index
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Dist/js
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 03:09:58 --> Config Class Initialized
INFO - 2025-05-09 03:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:58 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:58 --> URI Class Initialized
INFO - 2025-05-09 03:09:58 --> Router Class Initialized
INFO - 2025-05-09 03:09:58 --> Output Class Initialized
INFO - 2025-05-09 03:09:58 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:58 --> Input Class Initialized
INFO - 2025-05-09 03:09:58 --> Language Class Initialized
ERROR - 2025-05-09 03:09:58 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
INFO - 2025-05-09 03:09:59 --> Config Class Initialized
INFO - 2025-05-09 03:09:59 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:09:59 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:09:59 --> Utf8 Class Initialized
INFO - 2025-05-09 03:09:59 --> URI Class Initialized
INFO - 2025-05-09 03:09:59 --> Router Class Initialized
INFO - 2025-05-09 03:09:59 --> Output Class Initialized
INFO - 2025-05-09 03:09:59 --> Security Class Initialized
DEBUG - 2025-05-09 03:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:09:59 --> Input Class Initialized
INFO - 2025-05-09 03:09:59 --> Language Class Initialized
ERROR - 2025-05-09 03:09:59 --> 404 Page Not Found: Codejquerycom/jquery-3.6.0.min.js
INFO - 2025-05-09 03:10:00 --> Config Class Initialized
INFO - 2025-05-09 03:10:00 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:10:00 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:10:00 --> Utf8 Class Initialized
INFO - 2025-05-09 03:10:00 --> URI Class Initialized
INFO - 2025-05-09 03:10:00 --> Router Class Initialized
INFO - 2025-05-09 03:10:00 --> Output Class Initialized
INFO - 2025-05-09 03:10:00 --> Security Class Initialized
DEBUG - 2025-05-09 03:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:10:00 --> Input Class Initialized
INFO - 2025-05-09 03:10:00 --> Language Class Initialized
ERROR - 2025-05-09 03:10:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
INFO - 2025-05-09 03:10:00 --> Config Class Initialized
INFO - 2025-05-09 03:10:00 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:10:00 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:10:00 --> Utf8 Class Initialized
INFO - 2025-05-09 03:10:00 --> URI Class Initialized
INFO - 2025-05-09 03:10:00 --> Router Class Initialized
INFO - 2025-05-09 03:10:00 --> Output Class Initialized
INFO - 2025-05-09 03:10:00 --> Security Class Initialized
DEBUG - 2025-05-09 03:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:10:00 --> Input Class Initialized
INFO - 2025-05-09 03:10:00 --> Language Class Initialized
ERROR - 2025-05-09 03:10:00 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 03:10:01 --> Config Class Initialized
INFO - 2025-05-09 03:10:01 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:10:01 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:10:01 --> Utf8 Class Initialized
INFO - 2025-05-09 03:10:01 --> URI Class Initialized
INFO - 2025-05-09 03:10:01 --> Router Class Initialized
INFO - 2025-05-09 03:10:01 --> Output Class Initialized
INFO - 2025-05-09 03:10:01 --> Security Class Initialized
DEBUG - 2025-05-09 03:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:10:01 --> Input Class Initialized
INFO - 2025-05-09 03:10:01 --> Language Class Initialized
ERROR - 2025-05-09 03:10:01 --> 404 Page Not Found: Cdnjs/index
INFO - 2025-05-09 03:10:02 --> Config Class Initialized
INFO - 2025-05-09 03:10:02 --> Hooks Class Initialized
DEBUG - 2025-05-09 03:10:02 --> UTF-8 Support Enabled
INFO - 2025-05-09 03:10:02 --> Utf8 Class Initialized
INFO - 2025-05-09 03:10:02 --> URI Class Initialized
INFO - 2025-05-09 03:10:02 --> Router Class Initialized
INFO - 2025-05-09 03:10:02 --> Output Class Initialized
INFO - 2025-05-09 03:10:02 --> Security Class Initialized
DEBUG - 2025-05-09 03:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 03:10:02 --> Input Class Initialized
INFO - 2025-05-09 03:10:02 --> Language Class Initialized
ERROR - 2025-05-09 03:10:02 --> 404 Page Not Found: Storagepunterscom/assets
INFO - 2025-05-09 04:01:27 --> Config Class Initialized
INFO - 2025-05-09 04:01:27 --> Hooks Class Initialized
DEBUG - 2025-05-09 04:01:27 --> UTF-8 Support Enabled
INFO - 2025-05-09 04:01:27 --> Utf8 Class Initialized
INFO - 2025-05-09 04:01:27 --> URI Class Initialized
DEBUG - 2025-05-09 04:01:27 --> No URI present. Default controller set.
INFO - 2025-05-09 04:01:27 --> Router Class Initialized
INFO - 2025-05-09 04:01:27 --> Output Class Initialized
INFO - 2025-05-09 04:01:27 --> Security Class Initialized
DEBUG - 2025-05-09 04:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 04:01:27 --> Input Class Initialized
INFO - 2025-05-09 04:01:27 --> Language Class Initialized
INFO - 2025-05-09 04:01:27 --> Loader Class Initialized
INFO - 2025-05-09 04:01:27 --> Helper loaded: url_helper
INFO - 2025-05-09 04:01:27 --> Helper loaded: string_helper
INFO - 2025-05-09 04:01:27 --> Helper loaded: form_helper
INFO - 2025-05-09 04:01:27 --> Helper loaded: file_helper
INFO - 2025-05-09 04:01:27 --> Helper loaded: html_helper
INFO - 2025-05-09 04:01:27 --> Database Driver Class Initialized
DEBUG - 2025-05-09 04:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 04:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 04:01:27 --> Controller Class Initialized
INFO - 2025-05-09 04:01:27 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 04:01:27 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 04:01:27 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 04:01:27 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 04:01:27 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 04:01:27 --> Final output sent to browser
DEBUG - 2025-05-09 04:01:27 --> Total execution time: 0.0470
INFO - 2025-05-09 05:15:50 --> Config Class Initialized
INFO - 2025-05-09 05:15:50 --> Hooks Class Initialized
DEBUG - 2025-05-09 05:15:50 --> UTF-8 Support Enabled
INFO - 2025-05-09 05:15:50 --> Utf8 Class Initialized
INFO - 2025-05-09 05:15:50 --> URI Class Initialized
DEBUG - 2025-05-09 05:15:50 --> No URI present. Default controller set.
INFO - 2025-05-09 05:15:50 --> Router Class Initialized
INFO - 2025-05-09 05:15:50 --> Output Class Initialized
INFO - 2025-05-09 05:15:50 --> Security Class Initialized
DEBUG - 2025-05-09 05:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 05:15:50 --> Input Class Initialized
INFO - 2025-05-09 05:15:50 --> Language Class Initialized
INFO - 2025-05-09 05:15:50 --> Loader Class Initialized
INFO - 2025-05-09 05:15:50 --> Helper loaded: url_helper
INFO - 2025-05-09 05:15:50 --> Helper loaded: string_helper
INFO - 2025-05-09 05:15:50 --> Helper loaded: form_helper
INFO - 2025-05-09 05:15:50 --> Helper loaded: file_helper
INFO - 2025-05-09 05:15:50 --> Helper loaded: html_helper
INFO - 2025-05-09 05:15:50 --> Database Driver Class Initialized
DEBUG - 2025-05-09 05:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 05:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 05:15:50 --> Controller Class Initialized
INFO - 2025-05-09 05:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 05:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 05:15:50 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 05:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 05:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 05:15:50 --> Final output sent to browser
DEBUG - 2025-05-09 05:15:50 --> Total execution time: 0.0437
INFO - 2025-05-09 05:40:14 --> Config Class Initialized
INFO - 2025-05-09 05:40:14 --> Hooks Class Initialized
DEBUG - 2025-05-09 05:40:14 --> UTF-8 Support Enabled
INFO - 2025-05-09 05:40:14 --> Utf8 Class Initialized
INFO - 2025-05-09 05:40:14 --> URI Class Initialized
DEBUG - 2025-05-09 05:40:14 --> No URI present. Default controller set.
INFO - 2025-05-09 05:40:14 --> Router Class Initialized
INFO - 2025-05-09 05:40:14 --> Output Class Initialized
INFO - 2025-05-09 05:40:14 --> Security Class Initialized
DEBUG - 2025-05-09 05:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 05:40:14 --> Input Class Initialized
INFO - 2025-05-09 05:40:14 --> Language Class Initialized
INFO - 2025-05-09 05:40:14 --> Loader Class Initialized
INFO - 2025-05-09 05:40:14 --> Helper loaded: url_helper
INFO - 2025-05-09 05:40:14 --> Helper loaded: string_helper
INFO - 2025-05-09 05:40:14 --> Helper loaded: form_helper
INFO - 2025-05-09 05:40:14 --> Helper loaded: file_helper
INFO - 2025-05-09 05:40:14 --> Helper loaded: html_helper
INFO - 2025-05-09 05:40:14 --> Database Driver Class Initialized
DEBUG - 2025-05-09 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 05:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 05:40:14 --> Controller Class Initialized
INFO - 2025-05-09 05:40:14 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 05:40:14 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 05:40:14 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 05:40:14 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 05:40:14 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 05:40:14 --> Final output sent to browser
DEBUG - 2025-05-09 05:40:14 --> Total execution time: 0.0435
INFO - 2025-05-09 07:02:57 --> Config Class Initialized
INFO - 2025-05-09 07:02:57 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:02:57 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:02:57 --> Utf8 Class Initialized
INFO - 2025-05-09 07:02:57 --> URI Class Initialized
DEBUG - 2025-05-09 07:02:57 --> No URI present. Default controller set.
INFO - 2025-05-09 07:02:57 --> Router Class Initialized
INFO - 2025-05-09 07:02:57 --> Output Class Initialized
INFO - 2025-05-09 07:02:57 --> Security Class Initialized
DEBUG - 2025-05-09 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:02:57 --> Input Class Initialized
INFO - 2025-05-09 07:02:57 --> Language Class Initialized
INFO - 2025-05-09 07:02:57 --> Loader Class Initialized
INFO - 2025-05-09 07:02:57 --> Helper loaded: url_helper
INFO - 2025-05-09 07:02:57 --> Helper loaded: string_helper
INFO - 2025-05-09 07:02:57 --> Helper loaded: form_helper
INFO - 2025-05-09 07:02:57 --> Helper loaded: file_helper
INFO - 2025-05-09 07:02:57 --> Helper loaded: html_helper
INFO - 2025-05-09 07:02:57 --> Database Driver Class Initialized
DEBUG - 2025-05-09 07:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 07:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 07:02:57 --> Controller Class Initialized
INFO - 2025-05-09 07:02:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 07:02:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 07:02:57 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 07:02:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 07:02:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 07:02:57 --> Final output sent to browser
DEBUG - 2025-05-09 07:02:57 --> Total execution time: 0.0459
INFO - 2025-05-09 07:02:57 --> Config Class Initialized
INFO - 2025-05-09 07:02:57 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:02:57 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:02:57 --> Utf8 Class Initialized
INFO - 2025-05-09 07:02:57 --> URI Class Initialized
INFO - 2025-05-09 07:02:57 --> Router Class Initialized
INFO - 2025-05-09 07:02:57 --> Output Class Initialized
INFO - 2025-05-09 07:02:57 --> Security Class Initialized
DEBUG - 2025-05-09 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:02:57 --> Input Class Initialized
INFO - 2025-05-09 07:02:57 --> Language Class Initialized
ERROR - 2025-05-09 07:02:57 --> 404 Page Not Found: Wordpress/index
INFO - 2025-05-09 07:09:13 --> Config Class Initialized
INFO - 2025-05-09 07:09:13 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:09:13 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:09:13 --> Utf8 Class Initialized
INFO - 2025-05-09 07:09:13 --> URI Class Initialized
DEBUG - 2025-05-09 07:09:13 --> No URI present. Default controller set.
INFO - 2025-05-09 07:09:13 --> Router Class Initialized
INFO - 2025-05-09 07:09:13 --> Output Class Initialized
INFO - 2025-05-09 07:09:13 --> Security Class Initialized
DEBUG - 2025-05-09 07:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:09:13 --> Input Class Initialized
INFO - 2025-05-09 07:09:13 --> Language Class Initialized
INFO - 2025-05-09 07:09:13 --> Loader Class Initialized
INFO - 2025-05-09 07:09:13 --> Helper loaded: url_helper
INFO - 2025-05-09 07:09:13 --> Helper loaded: string_helper
INFO - 2025-05-09 07:09:13 --> Helper loaded: form_helper
INFO - 2025-05-09 07:09:13 --> Helper loaded: file_helper
INFO - 2025-05-09 07:09:13 --> Helper loaded: html_helper
INFO - 2025-05-09 07:09:13 --> Database Driver Class Initialized
DEBUG - 2025-05-09 07:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 07:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 07:09:13 --> Controller Class Initialized
INFO - 2025-05-09 07:09:13 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 07:09:13 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 07:09:13 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 07:09:13 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 07:09:13 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 07:09:13 --> Final output sent to browser
DEBUG - 2025-05-09 07:09:13 --> Total execution time: 0.0324
INFO - 2025-05-09 07:15:26 --> Config Class Initialized
INFO - 2025-05-09 07:15:26 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:15:26 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:15:26 --> Utf8 Class Initialized
INFO - 2025-05-09 07:15:26 --> URI Class Initialized
DEBUG - 2025-05-09 07:15:26 --> No URI present. Default controller set.
INFO - 2025-05-09 07:15:26 --> Router Class Initialized
INFO - 2025-05-09 07:15:26 --> Output Class Initialized
INFO - 2025-05-09 07:15:26 --> Security Class Initialized
DEBUG - 2025-05-09 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:15:26 --> Input Class Initialized
INFO - 2025-05-09 07:15:26 --> Language Class Initialized
INFO - 2025-05-09 07:15:26 --> Loader Class Initialized
INFO - 2025-05-09 07:15:26 --> Helper loaded: url_helper
INFO - 2025-05-09 07:15:26 --> Helper loaded: string_helper
INFO - 2025-05-09 07:15:26 --> Helper loaded: form_helper
INFO - 2025-05-09 07:15:26 --> Helper loaded: file_helper
INFO - 2025-05-09 07:15:26 --> Helper loaded: html_helper
INFO - 2025-05-09 07:15:26 --> Database Driver Class Initialized
DEBUG - 2025-05-09 07:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 07:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 07:15:26 --> Controller Class Initialized
INFO - 2025-05-09 07:15:26 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 07:15:26 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 07:15:26 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 07:15:26 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 07:15:26 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 07:15:26 --> Final output sent to browser
DEBUG - 2025-05-09 07:15:26 --> Total execution time: 0.0296
INFO - 2025-05-09 07:45:33 --> Config Class Initialized
INFO - 2025-05-09 07:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:45:33 --> Utf8 Class Initialized
INFO - 2025-05-09 07:45:33 --> URI Class Initialized
DEBUG - 2025-05-09 07:45:33 --> No URI present. Default controller set.
INFO - 2025-05-09 07:45:33 --> Router Class Initialized
INFO - 2025-05-09 07:45:33 --> Output Class Initialized
INFO - 2025-05-09 07:45:33 --> Security Class Initialized
DEBUG - 2025-05-09 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:45:33 --> Input Class Initialized
INFO - 2025-05-09 07:45:33 --> Language Class Initialized
INFO - 2025-05-09 07:45:33 --> Loader Class Initialized
INFO - 2025-05-09 07:45:33 --> Helper loaded: url_helper
INFO - 2025-05-09 07:45:33 --> Helper loaded: string_helper
INFO - 2025-05-09 07:45:33 --> Helper loaded: form_helper
INFO - 2025-05-09 07:45:33 --> Helper loaded: file_helper
INFO - 2025-05-09 07:45:33 --> Helper loaded: html_helper
INFO - 2025-05-09 07:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-09 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 07:45:33 --> Controller Class Initialized
INFO - 2025-05-09 07:45:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 07:45:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 07:45:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 07:45:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 07:45:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 07:45:33 --> Final output sent to browser
DEBUG - 2025-05-09 07:45:33 --> Total execution time: 0.0539
INFO - 2025-05-09 07:50:33 --> Config Class Initialized
INFO - 2025-05-09 07:50:33 --> Hooks Class Initialized
DEBUG - 2025-05-09 07:50:33 --> UTF-8 Support Enabled
INFO - 2025-05-09 07:50:33 --> Utf8 Class Initialized
INFO - 2025-05-09 07:50:33 --> URI Class Initialized
INFO - 2025-05-09 07:50:33 --> Router Class Initialized
INFO - 2025-05-09 07:50:33 --> Output Class Initialized
INFO - 2025-05-09 07:50:33 --> Security Class Initialized
DEBUG - 2025-05-09 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 07:50:33 --> Input Class Initialized
INFO - 2025-05-09 07:50:33 --> Language Class Initialized
ERROR - 2025-05-09 07:50:33 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2025-05-09 09:20:33 --> Config Class Initialized
INFO - 2025-05-09 09:20:33 --> Hooks Class Initialized
DEBUG - 2025-05-09 09:20:33 --> UTF-8 Support Enabled
INFO - 2025-05-09 09:20:33 --> Utf8 Class Initialized
INFO - 2025-05-09 09:20:33 --> URI Class Initialized
DEBUG - 2025-05-09 09:20:33 --> No URI present. Default controller set.
INFO - 2025-05-09 09:20:33 --> Router Class Initialized
INFO - 2025-05-09 09:20:33 --> Output Class Initialized
INFO - 2025-05-09 09:20:33 --> Security Class Initialized
DEBUG - 2025-05-09 09:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 09:20:33 --> Input Class Initialized
INFO - 2025-05-09 09:20:33 --> Language Class Initialized
INFO - 2025-05-09 09:20:33 --> Loader Class Initialized
INFO - 2025-05-09 09:20:33 --> Helper loaded: url_helper
INFO - 2025-05-09 09:20:33 --> Helper loaded: string_helper
INFO - 2025-05-09 09:20:33 --> Helper loaded: form_helper
INFO - 2025-05-09 09:20:33 --> Helper loaded: file_helper
INFO - 2025-05-09 09:20:33 --> Helper loaded: html_helper
INFO - 2025-05-09 09:20:33 --> Database Driver Class Initialized
DEBUG - 2025-05-09 09:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 09:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 09:20:33 --> Controller Class Initialized
INFO - 2025-05-09 09:20:33 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 09:20:33 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 09:20:33 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 09:20:33 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 09:20:33 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 09:20:33 --> Final output sent to browser
DEBUG - 2025-05-09 09:20:33 --> Total execution time: 0.0547
INFO - 2025-05-09 09:59:57 --> Config Class Initialized
INFO - 2025-05-09 09:59:57 --> Hooks Class Initialized
DEBUG - 2025-05-09 09:59:57 --> UTF-8 Support Enabled
INFO - 2025-05-09 09:59:57 --> Utf8 Class Initialized
INFO - 2025-05-09 09:59:57 --> URI Class Initialized
DEBUG - 2025-05-09 09:59:57 --> No URI present. Default controller set.
INFO - 2025-05-09 09:59:57 --> Router Class Initialized
INFO - 2025-05-09 09:59:57 --> Output Class Initialized
INFO - 2025-05-09 09:59:57 --> Security Class Initialized
DEBUG - 2025-05-09 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 09:59:57 --> Input Class Initialized
INFO - 2025-05-09 09:59:57 --> Language Class Initialized
INFO - 2025-05-09 09:59:57 --> Loader Class Initialized
INFO - 2025-05-09 09:59:57 --> Helper loaded: url_helper
INFO - 2025-05-09 09:59:57 --> Helper loaded: string_helper
INFO - 2025-05-09 09:59:57 --> Helper loaded: form_helper
INFO - 2025-05-09 09:59:57 --> Helper loaded: file_helper
INFO - 2025-05-09 09:59:57 --> Helper loaded: html_helper
INFO - 2025-05-09 09:59:57 --> Database Driver Class Initialized
DEBUG - 2025-05-09 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 09:59:57 --> Controller Class Initialized
INFO - 2025-05-09 09:59:57 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 09:59:57 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 09:59:57 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 09:59:57 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 09:59:57 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 09:59:57 --> Final output sent to browser
DEBUG - 2025-05-09 09:59:57 --> Total execution time: 0.0525
INFO - 2025-05-09 10:20:23 --> Config Class Initialized
INFO - 2025-05-09 10:20:23 --> Hooks Class Initialized
DEBUG - 2025-05-09 10:20:23 --> UTF-8 Support Enabled
INFO - 2025-05-09 10:20:23 --> Utf8 Class Initialized
INFO - 2025-05-09 10:20:23 --> URI Class Initialized
DEBUG - 2025-05-09 10:20:23 --> No URI present. Default controller set.
INFO - 2025-05-09 10:20:23 --> Router Class Initialized
INFO - 2025-05-09 10:20:23 --> Output Class Initialized
INFO - 2025-05-09 10:20:23 --> Security Class Initialized
DEBUG - 2025-05-09 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 10:20:23 --> Input Class Initialized
INFO - 2025-05-09 10:20:23 --> Language Class Initialized
INFO - 2025-05-09 10:20:23 --> Loader Class Initialized
INFO - 2025-05-09 10:20:23 --> Helper loaded: url_helper
INFO - 2025-05-09 10:20:23 --> Helper loaded: string_helper
INFO - 2025-05-09 10:20:23 --> Helper loaded: form_helper
INFO - 2025-05-09 10:20:23 --> Helper loaded: file_helper
INFO - 2025-05-09 10:20:23 --> Helper loaded: html_helper
INFO - 2025-05-09 10:20:23 --> Database Driver Class Initialized
DEBUG - 2025-05-09 10:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 10:20:23 --> Controller Class Initialized
INFO - 2025-05-09 10:20:23 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 10:20:23 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 10:20:23 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 10:20:23 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 10:20:23 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 10:20:23 --> Final output sent to browser
DEBUG - 2025-05-09 10:20:23 --> Total execution time: 0.0306
INFO - 2025-05-09 10:27:30 --> Config Class Initialized
INFO - 2025-05-09 10:27:30 --> Hooks Class Initialized
DEBUG - 2025-05-09 10:27:30 --> UTF-8 Support Enabled
INFO - 2025-05-09 10:27:30 --> Utf8 Class Initialized
INFO - 2025-05-09 10:27:30 --> URI Class Initialized
INFO - 2025-05-09 10:27:30 --> Router Class Initialized
INFO - 2025-05-09 10:27:30 --> Output Class Initialized
INFO - 2025-05-09 10:27:30 --> Security Class Initialized
DEBUG - 2025-05-09 10:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 10:27:30 --> Input Class Initialized
INFO - 2025-05-09 10:27:30 --> Language Class Initialized
ERROR - 2025-05-09 10:27:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-09 13:15:50 --> Config Class Initialized
INFO - 2025-05-09 13:15:50 --> Hooks Class Initialized
DEBUG - 2025-05-09 13:15:50 --> UTF-8 Support Enabled
INFO - 2025-05-09 13:15:50 --> Utf8 Class Initialized
INFO - 2025-05-09 13:15:50 --> URI Class Initialized
DEBUG - 2025-05-09 13:15:50 --> No URI present. Default controller set.
INFO - 2025-05-09 13:15:50 --> Router Class Initialized
INFO - 2025-05-09 13:15:50 --> Output Class Initialized
INFO - 2025-05-09 13:15:50 --> Security Class Initialized
DEBUG - 2025-05-09 13:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 13:15:50 --> Input Class Initialized
INFO - 2025-05-09 13:15:50 --> Language Class Initialized
INFO - 2025-05-09 13:15:50 --> Loader Class Initialized
INFO - 2025-05-09 13:15:50 --> Helper loaded: url_helper
INFO - 2025-05-09 13:15:50 --> Helper loaded: string_helper
INFO - 2025-05-09 13:15:50 --> Helper loaded: form_helper
INFO - 2025-05-09 13:15:50 --> Helper loaded: file_helper
INFO - 2025-05-09 13:15:50 --> Helper loaded: html_helper
INFO - 2025-05-09 13:15:50 --> Database Driver Class Initialized
DEBUG - 2025-05-09 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 13:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 13:15:50 --> Controller Class Initialized
INFO - 2025-05-09 13:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 13:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 13:15:50 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 13:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 13:15:50 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 13:15:50 --> Final output sent to browser
DEBUG - 2025-05-09 13:15:50 --> Total execution time: 0.0762
INFO - 2025-05-09 13:34:07 --> Config Class Initialized
INFO - 2025-05-09 13:34:07 --> Hooks Class Initialized
DEBUG - 2025-05-09 13:34:07 --> UTF-8 Support Enabled
INFO - 2025-05-09 13:34:07 --> Utf8 Class Initialized
INFO - 2025-05-09 13:34:07 --> URI Class Initialized
DEBUG - 2025-05-09 13:34:07 --> No URI present. Default controller set.
INFO - 2025-05-09 13:34:07 --> Router Class Initialized
INFO - 2025-05-09 13:34:07 --> Output Class Initialized
INFO - 2025-05-09 13:34:07 --> Security Class Initialized
DEBUG - 2025-05-09 13:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 13:34:07 --> Input Class Initialized
INFO - 2025-05-09 13:34:07 --> Language Class Initialized
INFO - 2025-05-09 13:34:07 --> Loader Class Initialized
INFO - 2025-05-09 13:34:07 --> Helper loaded: url_helper
INFO - 2025-05-09 13:34:07 --> Helper loaded: string_helper
INFO - 2025-05-09 13:34:07 --> Helper loaded: form_helper
INFO - 2025-05-09 13:34:07 --> Helper loaded: file_helper
INFO - 2025-05-09 13:34:07 --> Helper loaded: html_helper
INFO - 2025-05-09 13:34:07 --> Database Driver Class Initialized
DEBUG - 2025-05-09 13:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 13:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 13:34:07 --> Controller Class Initialized
INFO - 2025-05-09 13:34:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 13:34:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 13:34:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 13:34:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 13:34:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 13:34:07 --> Final output sent to browser
DEBUG - 2025-05-09 13:34:07 --> Total execution time: 0.0289
INFO - 2025-05-09 16:33:53 --> Config Class Initialized
INFO - 2025-05-09 16:33:53 --> Hooks Class Initialized
DEBUG - 2025-05-09 16:33:53 --> UTF-8 Support Enabled
INFO - 2025-05-09 16:33:53 --> Utf8 Class Initialized
INFO - 2025-05-09 16:33:53 --> URI Class Initialized
DEBUG - 2025-05-09 16:33:53 --> No URI present. Default controller set.
INFO - 2025-05-09 16:33:53 --> Router Class Initialized
INFO - 2025-05-09 16:33:53 --> Output Class Initialized
INFO - 2025-05-09 16:33:53 --> Security Class Initialized
DEBUG - 2025-05-09 16:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 16:33:53 --> Input Class Initialized
INFO - 2025-05-09 16:33:53 --> Language Class Initialized
INFO - 2025-05-09 16:33:53 --> Loader Class Initialized
INFO - 2025-05-09 16:33:53 --> Helper loaded: url_helper
INFO - 2025-05-09 16:33:53 --> Helper loaded: string_helper
INFO - 2025-05-09 16:33:53 --> Helper loaded: form_helper
INFO - 2025-05-09 16:33:53 --> Helper loaded: file_helper
INFO - 2025-05-09 16:33:53 --> Helper loaded: html_helper
INFO - 2025-05-09 16:33:53 --> Database Driver Class Initialized
DEBUG - 2025-05-09 16:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 16:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 16:33:53 --> Controller Class Initialized
INFO - 2025-05-09 16:33:53 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 16:33:53 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 16:33:53 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 16:33:53 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 16:33:53 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 16:33:53 --> Final output sent to browser
DEBUG - 2025-05-09 16:33:53 --> Total execution time: 0.0519
INFO - 2025-05-09 16:48:41 --> Config Class Initialized
INFO - 2025-05-09 16:48:41 --> Hooks Class Initialized
DEBUG - 2025-05-09 16:48:41 --> UTF-8 Support Enabled
INFO - 2025-05-09 16:48:41 --> Utf8 Class Initialized
INFO - 2025-05-09 16:48:41 --> URI Class Initialized
DEBUG - 2025-05-09 16:48:41 --> No URI present. Default controller set.
INFO - 2025-05-09 16:48:41 --> Router Class Initialized
INFO - 2025-05-09 16:48:41 --> Output Class Initialized
INFO - 2025-05-09 16:48:41 --> Security Class Initialized
DEBUG - 2025-05-09 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 16:48:41 --> Input Class Initialized
INFO - 2025-05-09 16:48:41 --> Language Class Initialized
INFO - 2025-05-09 16:48:41 --> Loader Class Initialized
INFO - 2025-05-09 16:48:41 --> Helper loaded: url_helper
INFO - 2025-05-09 16:48:41 --> Helper loaded: string_helper
INFO - 2025-05-09 16:48:41 --> Helper loaded: form_helper
INFO - 2025-05-09 16:48:41 --> Helper loaded: file_helper
INFO - 2025-05-09 16:48:41 --> Helper loaded: html_helper
INFO - 2025-05-09 16:48:41 --> Database Driver Class Initialized
DEBUG - 2025-05-09 16:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 16:48:41 --> Controller Class Initialized
INFO - 2025-05-09 16:48:41 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 16:48:41 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 16:48:41 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 16:48:41 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 16:48:41 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 16:48:41 --> Final output sent to browser
DEBUG - 2025-05-09 16:48:41 --> Total execution time: 0.0288
INFO - 2025-05-09 16:52:29 --> Config Class Initialized
INFO - 2025-05-09 16:52:29 --> Hooks Class Initialized
DEBUG - 2025-05-09 16:52:29 --> UTF-8 Support Enabled
INFO - 2025-05-09 16:52:29 --> Utf8 Class Initialized
INFO - 2025-05-09 16:52:29 --> URI Class Initialized
DEBUG - 2025-05-09 16:52:29 --> No URI present. Default controller set.
INFO - 2025-05-09 16:52:29 --> Router Class Initialized
INFO - 2025-05-09 16:52:29 --> Output Class Initialized
INFO - 2025-05-09 16:52:29 --> Security Class Initialized
DEBUG - 2025-05-09 16:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 16:52:29 --> Input Class Initialized
INFO - 2025-05-09 16:52:29 --> Language Class Initialized
INFO - 2025-05-09 16:52:29 --> Loader Class Initialized
INFO - 2025-05-09 16:52:29 --> Helper loaded: url_helper
INFO - 2025-05-09 16:52:29 --> Helper loaded: string_helper
INFO - 2025-05-09 16:52:29 --> Helper loaded: form_helper
INFO - 2025-05-09 16:52:29 --> Helper loaded: file_helper
INFO - 2025-05-09 16:52:29 --> Helper loaded: html_helper
INFO - 2025-05-09 16:52:29 --> Database Driver Class Initialized
DEBUG - 2025-05-09 16:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 16:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 16:52:29 --> Controller Class Initialized
INFO - 2025-05-09 16:52:29 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 16:52:29 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 16:52:29 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 16:52:29 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 16:52:29 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 16:52:29 --> Final output sent to browser
DEBUG - 2025-05-09 16:52:29 --> Total execution time: 0.0301
INFO - 2025-05-09 17:11:23 --> Config Class Initialized
INFO - 2025-05-09 17:11:23 --> Hooks Class Initialized
DEBUG - 2025-05-09 17:11:23 --> UTF-8 Support Enabled
INFO - 2025-05-09 17:11:23 --> Utf8 Class Initialized
INFO - 2025-05-09 17:11:23 --> URI Class Initialized
DEBUG - 2025-05-09 17:11:23 --> No URI present. Default controller set.
INFO - 2025-05-09 17:11:23 --> Router Class Initialized
INFO - 2025-05-09 17:11:23 --> Output Class Initialized
INFO - 2025-05-09 17:11:23 --> Security Class Initialized
DEBUG - 2025-05-09 17:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 17:11:23 --> Input Class Initialized
INFO - 2025-05-09 17:11:23 --> Language Class Initialized
INFO - 2025-05-09 17:11:23 --> Loader Class Initialized
INFO - 2025-05-09 17:11:23 --> Helper loaded: url_helper
INFO - 2025-05-09 17:11:23 --> Helper loaded: string_helper
INFO - 2025-05-09 17:11:23 --> Helper loaded: form_helper
INFO - 2025-05-09 17:11:23 --> Helper loaded: file_helper
INFO - 2025-05-09 17:11:23 --> Helper loaded: html_helper
INFO - 2025-05-09 17:11:23 --> Database Driver Class Initialized
DEBUG - 2025-05-09 17:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 17:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 17:11:23 --> Controller Class Initialized
INFO - 2025-05-09 17:11:23 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 17:11:23 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 17:11:23 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 17:11:23 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 17:11:23 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 17:11:23 --> Final output sent to browser
DEBUG - 2025-05-09 17:11:23 --> Total execution time: 0.0620
INFO - 2025-05-09 17:11:25 --> Config Class Initialized
INFO - 2025-05-09 17:11:25 --> Hooks Class Initialized
DEBUG - 2025-05-09 17:11:25 --> UTF-8 Support Enabled
INFO - 2025-05-09 17:11:25 --> Utf8 Class Initialized
INFO - 2025-05-09 17:11:25 --> URI Class Initialized
INFO - 2025-05-09 17:11:25 --> Router Class Initialized
INFO - 2025-05-09 17:11:25 --> Output Class Initialized
INFO - 2025-05-09 17:11:25 --> Security Class Initialized
DEBUG - 2025-05-09 17:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 17:11:25 --> Input Class Initialized
INFO - 2025-05-09 17:11:25 --> Language Class Initialized
ERROR - 2025-05-09 17:11:25 --> 404 Page Not Found: Js/index
INFO - 2025-05-09 17:19:31 --> Config Class Initialized
INFO - 2025-05-09 17:19:31 --> Hooks Class Initialized
DEBUG - 2025-05-09 17:19:31 --> UTF-8 Support Enabled
INFO - 2025-05-09 17:19:31 --> Utf8 Class Initialized
INFO - 2025-05-09 17:19:31 --> URI Class Initialized
DEBUG - 2025-05-09 17:19:31 --> No URI present. Default controller set.
INFO - 2025-05-09 17:19:31 --> Router Class Initialized
INFO - 2025-05-09 17:19:31 --> Output Class Initialized
INFO - 2025-05-09 17:19:31 --> Security Class Initialized
DEBUG - 2025-05-09 17:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 17:19:31 --> Input Class Initialized
INFO - 2025-05-09 17:19:31 --> Language Class Initialized
INFO - 2025-05-09 17:19:31 --> Loader Class Initialized
INFO - 2025-05-09 17:19:31 --> Helper loaded: url_helper
INFO - 2025-05-09 17:19:31 --> Helper loaded: string_helper
INFO - 2025-05-09 17:19:31 --> Helper loaded: form_helper
INFO - 2025-05-09 17:19:31 --> Helper loaded: file_helper
INFO - 2025-05-09 17:19:31 --> Helper loaded: html_helper
INFO - 2025-05-09 17:19:31 --> Database Driver Class Initialized
DEBUG - 2025-05-09 17:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 17:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 17:19:31 --> Controller Class Initialized
INFO - 2025-05-09 17:19:31 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 17:19:31 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 17:19:31 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 17:19:31 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 17:19:31 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 17:19:31 --> Final output sent to browser
DEBUG - 2025-05-09 17:19:31 --> Total execution time: 0.0291
INFO - 2025-05-09 18:46:01 --> Config Class Initialized
INFO - 2025-05-09 18:46:01 --> Hooks Class Initialized
DEBUG - 2025-05-09 18:46:01 --> UTF-8 Support Enabled
INFO - 2025-05-09 18:46:01 --> Utf8 Class Initialized
INFO - 2025-05-09 18:46:01 --> URI Class Initialized
DEBUG - 2025-05-09 18:46:01 --> No URI present. Default controller set.
INFO - 2025-05-09 18:46:01 --> Router Class Initialized
INFO - 2025-05-09 18:46:01 --> Output Class Initialized
INFO - 2025-05-09 18:46:01 --> Security Class Initialized
DEBUG - 2025-05-09 18:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 18:46:01 --> Input Class Initialized
INFO - 2025-05-09 18:46:01 --> Language Class Initialized
INFO - 2025-05-09 18:46:01 --> Loader Class Initialized
INFO - 2025-05-09 18:46:01 --> Helper loaded: url_helper
INFO - 2025-05-09 18:46:01 --> Helper loaded: string_helper
INFO - 2025-05-09 18:46:01 --> Helper loaded: form_helper
INFO - 2025-05-09 18:46:01 --> Helper loaded: file_helper
INFO - 2025-05-09 18:46:01 --> Helper loaded: html_helper
INFO - 2025-05-09 18:46:01 --> Database Driver Class Initialized
DEBUG - 2025-05-09 18:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 18:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 18:46:01 --> Controller Class Initialized
INFO - 2025-05-09 18:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 18:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 18:46:01 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 18:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 18:46:01 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 18:46:01 --> Final output sent to browser
DEBUG - 2025-05-09 18:46:01 --> Total execution time: 0.0514
INFO - 2025-05-09 18:46:03 --> Config Class Initialized
INFO - 2025-05-09 18:46:03 --> Hooks Class Initialized
DEBUG - 2025-05-09 18:46:03 --> UTF-8 Support Enabled
INFO - 2025-05-09 18:46:03 --> Utf8 Class Initialized
INFO - 2025-05-09 18:46:03 --> URI Class Initialized
DEBUG - 2025-05-09 18:46:03 --> No URI present. Default controller set.
INFO - 2025-05-09 18:46:03 --> Router Class Initialized
INFO - 2025-05-09 18:46:03 --> Output Class Initialized
INFO - 2025-05-09 18:46:03 --> Security Class Initialized
DEBUG - 2025-05-09 18:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 18:46:03 --> Input Class Initialized
INFO - 2025-05-09 18:46:03 --> Language Class Initialized
INFO - 2025-05-09 18:46:03 --> Loader Class Initialized
INFO - 2025-05-09 18:46:03 --> Helper loaded: url_helper
INFO - 2025-05-09 18:46:03 --> Helper loaded: string_helper
INFO - 2025-05-09 18:46:03 --> Helper loaded: form_helper
INFO - 2025-05-09 18:46:03 --> Helper loaded: file_helper
INFO - 2025-05-09 18:46:03 --> Helper loaded: html_helper
INFO - 2025-05-09 18:46:03 --> Database Driver Class Initialized
DEBUG - 2025-05-09 18:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 18:46:03 --> Controller Class Initialized
INFO - 2025-05-09 18:46:03 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 18:46:03 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 18:46:03 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 18:46:03 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 18:46:03 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 18:46:03 --> Final output sent to browser
DEBUG - 2025-05-09 18:46:03 --> Total execution time: 0.0025
INFO - 2025-05-09 19:59:16 --> Config Class Initialized
INFO - 2025-05-09 19:59:16 --> Hooks Class Initialized
DEBUG - 2025-05-09 19:59:16 --> UTF-8 Support Enabled
INFO - 2025-05-09 19:59:16 --> Utf8 Class Initialized
INFO - 2025-05-09 19:59:16 --> URI Class Initialized
DEBUG - 2025-05-09 19:59:16 --> No URI present. Default controller set.
INFO - 2025-05-09 19:59:16 --> Router Class Initialized
INFO - 2025-05-09 19:59:16 --> Output Class Initialized
INFO - 2025-05-09 19:59:16 --> Security Class Initialized
DEBUG - 2025-05-09 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 19:59:16 --> Input Class Initialized
INFO - 2025-05-09 19:59:16 --> Language Class Initialized
INFO - 2025-05-09 19:59:16 --> Loader Class Initialized
INFO - 2025-05-09 19:59:16 --> Helper loaded: url_helper
INFO - 2025-05-09 19:59:16 --> Helper loaded: string_helper
INFO - 2025-05-09 19:59:16 --> Helper loaded: form_helper
INFO - 2025-05-09 19:59:16 --> Helper loaded: file_helper
INFO - 2025-05-09 19:59:16 --> Helper loaded: html_helper
INFO - 2025-05-09 19:59:16 --> Database Driver Class Initialized
DEBUG - 2025-05-09 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 19:59:16 --> Controller Class Initialized
INFO - 2025-05-09 19:59:16 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 19:59:16 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 19:59:16 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 19:59:16 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 19:59:16 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 19:59:16 --> Final output sent to browser
DEBUG - 2025-05-09 19:59:16 --> Total execution time: 0.0680
INFO - 2025-05-09 23:06:45 --> Config Class Initialized
INFO - 2025-05-09 23:06:45 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:06:45 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:06:45 --> Utf8 Class Initialized
INFO - 2025-05-09 23:06:45 --> URI Class Initialized
DEBUG - 2025-05-09 23:06:45 --> No URI present. Default controller set.
INFO - 2025-05-09 23:06:45 --> Router Class Initialized
INFO - 2025-05-09 23:06:45 --> Output Class Initialized
INFO - 2025-05-09 23:06:45 --> Security Class Initialized
DEBUG - 2025-05-09 23:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:06:45 --> Input Class Initialized
INFO - 2025-05-09 23:06:45 --> Language Class Initialized
INFO - 2025-05-09 23:06:45 --> Loader Class Initialized
INFO - 2025-05-09 23:06:45 --> Helper loaded: url_helper
INFO - 2025-05-09 23:06:45 --> Helper loaded: string_helper
INFO - 2025-05-09 23:06:45 --> Helper loaded: form_helper
INFO - 2025-05-09 23:06:45 --> Helper loaded: file_helper
INFO - 2025-05-09 23:06:45 --> Helper loaded: html_helper
INFO - 2025-05-09 23:06:45 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:06:45 --> Controller Class Initialized
INFO - 2025-05-09 23:06:45 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:06:45 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:06:45 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:06:45 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:06:45 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:06:45 --> Final output sent to browser
DEBUG - 2025-05-09 23:06:45 --> Total execution time: 0.0576
INFO - 2025-05-09 23:15:27 --> Config Class Initialized
INFO - 2025-05-09 23:15:27 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:15:27 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:15:27 --> Utf8 Class Initialized
INFO - 2025-05-09 23:15:27 --> URI Class Initialized
INFO - 2025-05-09 23:15:27 --> Router Class Initialized
INFO - 2025-05-09 23:15:27 --> Output Class Initialized
INFO - 2025-05-09 23:15:27 --> Security Class Initialized
DEBUG - 2025-05-09 23:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:15:27 --> Input Class Initialized
INFO - 2025-05-09 23:15:27 --> Language Class Initialized
ERROR - 2025-05-09 23:15:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-09 23:15:28 --> Config Class Initialized
INFO - 2025-05-09 23:15:28 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:15:28 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:15:28 --> Utf8 Class Initialized
INFO - 2025-05-09 23:15:28 --> URI Class Initialized
DEBUG - 2025-05-09 23:15:28 --> No URI present. Default controller set.
INFO - 2025-05-09 23:15:28 --> Router Class Initialized
INFO - 2025-05-09 23:15:28 --> Output Class Initialized
INFO - 2025-05-09 23:15:28 --> Security Class Initialized
DEBUG - 2025-05-09 23:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:15:28 --> Input Class Initialized
INFO - 2025-05-09 23:15:28 --> Language Class Initialized
INFO - 2025-05-09 23:15:28 --> Loader Class Initialized
INFO - 2025-05-09 23:15:28 --> Helper loaded: url_helper
INFO - 2025-05-09 23:15:28 --> Helper loaded: string_helper
INFO - 2025-05-09 23:15:28 --> Helper loaded: form_helper
INFO - 2025-05-09 23:15:28 --> Helper loaded: file_helper
INFO - 2025-05-09 23:15:28 --> Helper loaded: html_helper
INFO - 2025-05-09 23:15:28 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:15:28 --> Controller Class Initialized
INFO - 2025-05-09 23:15:28 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:15:28 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:15:28 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:15:28 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:15:28 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:15:28 --> Final output sent to browser
DEBUG - 2025-05-09 23:15:28 --> Total execution time: 0.0204
INFO - 2025-05-09 23:15:29 --> Config Class Initialized
INFO - 2025-05-09 23:15:29 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:15:29 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:15:29 --> Utf8 Class Initialized
INFO - 2025-05-09 23:15:29 --> URI Class Initialized
INFO - 2025-05-09 23:15:29 --> Router Class Initialized
INFO - 2025-05-09 23:15:29 --> Output Class Initialized
INFO - 2025-05-09 23:15:29 --> Security Class Initialized
DEBUG - 2025-05-09 23:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:15:29 --> Input Class Initialized
INFO - 2025-05-09 23:15:29 --> Language Class Initialized
ERROR - 2025-05-09 23:15:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-09 23:15:30 --> Config Class Initialized
INFO - 2025-05-09 23:15:30 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:15:30 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:15:30 --> Utf8 Class Initialized
INFO - 2025-05-09 23:15:30 --> URI Class Initialized
INFO - 2025-05-09 23:15:30 --> Router Class Initialized
INFO - 2025-05-09 23:15:30 --> Output Class Initialized
INFO - 2025-05-09 23:15:30 --> Security Class Initialized
DEBUG - 2025-05-09 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:15:30 --> Input Class Initialized
INFO - 2025-05-09 23:15:30 --> Language Class Initialized
INFO - 2025-05-09 23:15:30 --> Loader Class Initialized
INFO - 2025-05-09 23:15:30 --> Helper loaded: url_helper
INFO - 2025-05-09 23:15:30 --> Helper loaded: string_helper
INFO - 2025-05-09 23:15:30 --> Helper loaded: form_helper
INFO - 2025-05-09 23:15:30 --> Helper loaded: file_helper
INFO - 2025-05-09 23:15:30 --> Helper loaded: html_helper
INFO - 2025-05-09 23:15:30 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:15:30 --> Controller Class Initialized
INFO - 2025-05-09 23:15:30 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:15:30 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:15:30 --> File loaded: /home/storagep/public_html/application/views/pages/contact_us.php
INFO - 2025-05-09 23:15:30 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:15:30 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:15:30 --> Final output sent to browser
DEBUG - 2025-05-09 23:15:30 --> Total execution time: 0.0056
INFO - 2025-05-09 23:15:32 --> Config Class Initialized
INFO - 2025-05-09 23:15:32 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:15:32 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:15:32 --> Utf8 Class Initialized
INFO - 2025-05-09 23:15:32 --> URI Class Initialized
INFO - 2025-05-09 23:15:32 --> Router Class Initialized
INFO - 2025-05-09 23:15:32 --> Output Class Initialized
INFO - 2025-05-09 23:15:32 --> Security Class Initialized
DEBUG - 2025-05-09 23:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:15:32 --> Input Class Initialized
INFO - 2025-05-09 23:15:32 --> Language Class Initialized
INFO - 2025-05-09 23:15:32 --> Loader Class Initialized
INFO - 2025-05-09 23:15:32 --> Helper loaded: url_helper
INFO - 2025-05-09 23:15:32 --> Helper loaded: string_helper
INFO - 2025-05-09 23:15:32 --> Helper loaded: form_helper
INFO - 2025-05-09 23:15:32 --> Helper loaded: file_helper
INFO - 2025-05-09 23:15:32 --> Helper loaded: html_helper
INFO - 2025-05-09 23:15:32 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:15:32 --> Controller Class Initialized
INFO - 2025-05-09 23:15:32 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:15:32 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:15:32 --> File loaded: /home/storagep/public_html/application/views/pages/about_us.php
INFO - 2025-05-09 23:15:32 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:15:32 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:15:32 --> Final output sent to browser
DEBUG - 2025-05-09 23:15:32 --> Total execution time: 0.0034
INFO - 2025-05-09 23:21:06 --> Config Class Initialized
INFO - 2025-05-09 23:21:06 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:21:06 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:21:06 --> Utf8 Class Initialized
INFO - 2025-05-09 23:21:06 --> URI Class Initialized
DEBUG - 2025-05-09 23:21:06 --> No URI present. Default controller set.
INFO - 2025-05-09 23:21:06 --> Router Class Initialized
INFO - 2025-05-09 23:21:06 --> Output Class Initialized
INFO - 2025-05-09 23:21:06 --> Security Class Initialized
DEBUG - 2025-05-09 23:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:21:06 --> Input Class Initialized
INFO - 2025-05-09 23:21:06 --> Language Class Initialized
INFO - 2025-05-09 23:21:06 --> Loader Class Initialized
INFO - 2025-05-09 23:21:06 --> Helper loaded: url_helper
INFO - 2025-05-09 23:21:06 --> Helper loaded: string_helper
INFO - 2025-05-09 23:21:06 --> Helper loaded: form_helper
INFO - 2025-05-09 23:21:06 --> Helper loaded: file_helper
INFO - 2025-05-09 23:21:06 --> Helper loaded: html_helper
INFO - 2025-05-09 23:21:06 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:21:06 --> Controller Class Initialized
INFO - 2025-05-09 23:21:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:21:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:21:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:21:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:21:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:21:06 --> Final output sent to browser
DEBUG - 2025-05-09 23:21:06 --> Total execution time: 0.0300
INFO - 2025-05-09 23:30:06 --> Config Class Initialized
INFO - 2025-05-09 23:30:06 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:30:06 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:30:06 --> Utf8 Class Initialized
INFO - 2025-05-09 23:30:06 --> URI Class Initialized
DEBUG - 2025-05-09 23:30:06 --> No URI present. Default controller set.
INFO - 2025-05-09 23:30:06 --> Router Class Initialized
INFO - 2025-05-09 23:30:06 --> Output Class Initialized
INFO - 2025-05-09 23:30:06 --> Security Class Initialized
DEBUG - 2025-05-09 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:30:06 --> Input Class Initialized
INFO - 2025-05-09 23:30:06 --> Language Class Initialized
INFO - 2025-05-09 23:30:06 --> Loader Class Initialized
INFO - 2025-05-09 23:30:06 --> Helper loaded: url_helper
INFO - 2025-05-09 23:30:06 --> Helper loaded: string_helper
INFO - 2025-05-09 23:30:06 --> Helper loaded: form_helper
INFO - 2025-05-09 23:30:06 --> Helper loaded: file_helper
INFO - 2025-05-09 23:30:06 --> Helper loaded: html_helper
INFO - 2025-05-09 23:30:06 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:30:06 --> Controller Class Initialized
INFO - 2025-05-09 23:30:06 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:30:06 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:30:06 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:30:06 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:30:06 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:30:06 --> Final output sent to browser
DEBUG - 2025-05-09 23:30:06 --> Total execution time: 0.0296
INFO - 2025-05-09 23:30:07 --> Config Class Initialized
INFO - 2025-05-09 23:30:07 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:30:07 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:30:07 --> Utf8 Class Initialized
INFO - 2025-05-09 23:30:07 --> URI Class Initialized
DEBUG - 2025-05-09 23:30:07 --> No URI present. Default controller set.
INFO - 2025-05-09 23:30:07 --> Router Class Initialized
INFO - 2025-05-09 23:30:07 --> Output Class Initialized
INFO - 2025-05-09 23:30:07 --> Security Class Initialized
DEBUG - 2025-05-09 23:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:30:07 --> Input Class Initialized
INFO - 2025-05-09 23:30:07 --> Language Class Initialized
INFO - 2025-05-09 23:30:07 --> Loader Class Initialized
INFO - 2025-05-09 23:30:07 --> Helper loaded: url_helper
INFO - 2025-05-09 23:30:07 --> Helper loaded: string_helper
INFO - 2025-05-09 23:30:07 --> Helper loaded: form_helper
INFO - 2025-05-09 23:30:07 --> Helper loaded: file_helper
INFO - 2025-05-09 23:30:07 --> Helper loaded: html_helper
INFO - 2025-05-09 23:30:07 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:30:07 --> Controller Class Initialized
INFO - 2025-05-09 23:30:07 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:30:07 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:30:07 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:30:07 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:30:07 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:30:07 --> Final output sent to browser
DEBUG - 2025-05-09 23:30:07 --> Total execution time: 0.0026
INFO - 2025-05-09 23:45:11 --> Config Class Initialized
INFO - 2025-05-09 23:45:11 --> Hooks Class Initialized
DEBUG - 2025-05-09 23:45:11 --> UTF-8 Support Enabled
INFO - 2025-05-09 23:45:11 --> Utf8 Class Initialized
INFO - 2025-05-09 23:45:11 --> URI Class Initialized
DEBUG - 2025-05-09 23:45:11 --> No URI present. Default controller set.
INFO - 2025-05-09 23:45:11 --> Router Class Initialized
INFO - 2025-05-09 23:45:11 --> Output Class Initialized
INFO - 2025-05-09 23:45:11 --> Security Class Initialized
DEBUG - 2025-05-09 23:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-09 23:45:11 --> Input Class Initialized
INFO - 2025-05-09 23:45:11 --> Language Class Initialized
INFO - 2025-05-09 23:45:11 --> Loader Class Initialized
INFO - 2025-05-09 23:45:11 --> Helper loaded: url_helper
INFO - 2025-05-09 23:45:11 --> Helper loaded: string_helper
INFO - 2025-05-09 23:45:11 --> Helper loaded: form_helper
INFO - 2025-05-09 23:45:11 --> Helper loaded: file_helper
INFO - 2025-05-09 23:45:11 --> Helper loaded: html_helper
INFO - 2025-05-09 23:45:11 --> Database Driver Class Initialized
DEBUG - 2025-05-09 23:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-09 23:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-09 23:45:11 --> Controller Class Initialized
INFO - 2025-05-09 23:45:11 --> File loaded: /home/storagep/public_html/application/views/layout/head.php
INFO - 2025-05-09 23:45:11 --> File loaded: /home/storagep/public_html/application/views/layout/header.php
INFO - 2025-05-09 23:45:11 --> File loaded: /home/storagep/public_html/application/views/home/index.php
INFO - 2025-05-09 23:45:11 --> File loaded: /home/storagep/public_html/application/views/layout/footer.php
INFO - 2025-05-09 23:45:11 --> File loaded: /home/storagep/public_html/application/views/layout/scripts.php
INFO - 2025-05-09 23:45:11 --> Final output sent to browser
DEBUG - 2025-05-09 23:45:11 --> Total execution time: 0.0318
