<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-06 05:32:12 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:32:23 --> Model "UserModel" initialized
INFO - 2025-05-06 05:32:25 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:32:48 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:32:48 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-06 05:32:48 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:32:48 --> Final output sent to browser
DEBUG - 2025-05-06 05:32:48 --> Total execution time: 0.6295
INFO - 2025-05-06 05:32:48 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:32:48 --> Final output sent to browser
DEBUG - 2025-05-06 05:32:48 --> Total execution time: 0.6501
INFO - 2025-05-06 05:32:50 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:32:50 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:32:51 --> Final output sent to browser
DEBUG - 2025-05-06 05:32:51 --> Total execution time: 0.4214
INFO - 2025-05-06 05:46:47 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:46:47 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:46:47 --> Final output sent to browser
DEBUG - 2025-05-06 05:46:47 --> Total execution time: 0.2039
INFO - 2025-05-06 05:50:32 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:50:32 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:50:32 --> Final output sent to browser
DEBUG - 2025-05-06 05:50:32 --> Total execution time: 0.1271
INFO - 2025-05-06 05:50:59 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:50:59 --> Model "UserModel" initialized
INFO - 2025-05-06 05:51:01 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:51:01 --> Model "UserModel" initialized
INFO - 2025-05-06 05:51:04 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:51:04 --> Model "UserModel" initialized
INFO - 2025-05-06 05:51:56 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:51:56 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:51:56 --> Final output sent to browser
DEBUG - 2025-05-06 05:51:56 --> Total execution time: 0.2337
INFO - 2025-05-06 05:52:03 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:52:03 --> Model "UserModel" initialized
INFO - 2025-05-06 05:52:05 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:52:05 --> Model "UserModel" initialized
INFO - 2025-05-06 05:52:14 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:52:14 --> Model "UserModel" initialized
INFO - 2025-05-06 05:52:40 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:52:40 --> Model "UserModel" initialized
INFO - 2025-05-06 05:52:40 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:54:10 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:54:10 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:54:10 --> Final output sent to browser
DEBUG - 2025-05-06 05:54:10 --> Total execution time: 0.3695
INFO - 2025-05-06 05:55:41 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:55:41 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:55:41 --> Final output sent to browser
DEBUG - 2025-05-06 05:55:41 --> Total execution time: 0.2075
INFO - 2025-05-06 05:55:50 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:55:50 --> Model "UserModel" initialized
INFO - 2025-05-06 05:55:50 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:57:44 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:57:44 --> Model "UserModel" initialized
INFO - 2025-05-06 05:57:48 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:57:48 --> Model "UserModel" initialized
INFO - 2025-05-06 05:57:52 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:57:52 --> Model "UserModel" initialized
INFO - 2025-05-06 05:57:52 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:58:36 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:58:36 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:58:37 --> Final output sent to browser
DEBUG - 2025-05-06 05:58:37 --> Total execution time: 0.1550
INFO - 2025-05-06 05:58:52 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:58:52 --> Model "UserModel" initialized
INFO - 2025-05-06 05:58:52 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:59:49 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:59:49 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:59:49 --> Final output sent to browser
DEBUG - 2025-05-06 05:59:49 --> Total execution time: 0.2743
INFO - 2025-05-06 05:59:57 --> Model "CompanyModel" initialized
INFO - 2025-05-06 05:59:57 --> Model "UserModel" initialized
INFO - 2025-05-06 05:59:57 --> Model "StaffModel" initialized
INFO - 2025-05-06 05:59:58 --> Model "UserModel" initialized
DEBUG - 2025-05-06 05:59:58 --> PHPMailer class is loaded.
INFO - 2025-05-06 06:00:36 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:00:36 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:00:36 --> Final output sent to browser
DEBUG - 2025-05-06 06:00:36 --> Total execution time: 0.2508
INFO - 2025-05-06 06:00:43 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:00:43 --> Model "UserModel" initialized
INFO - 2025-05-06 06:00:43 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:00:43 --> Model "UserModel" initialized
DEBUG - 2025-05-06 06:00:43 --> PHPMailer class is loaded.
INFO - 2025-05-06 06:00:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 06:00:48 --> Final output sent to browser
DEBUG - 2025-05-06 06:00:48 --> Total execution time: 4.5174
INFO - 2025-05-06 06:01:57 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:01:57 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:01:57 --> Final output sent to browser
DEBUG - 2025-05-06 06:01:57 --> Total execution time: 0.1337
INFO - 2025-05-06 06:09:19 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:09:19 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:09:19 --> Final output sent to browser
DEBUG - 2025-05-06 06:09:19 --> Total execution time: 0.1435
INFO - 2025-05-06 06:09:35 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:09:35 --> Model "UserModel" initialized
INFO - 2025-05-06 06:09:35 --> Model "StaffModel" initialized
ERROR - 2025-05-06 06:09:35 --> Severity: Warning --> Undefined property: Email::$CompanyModel C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 703
ERROR - 2025-05-06 06:09:35 --> Severity: error --> Exception: Call to a member function getCompanyById() on null C:\xampp\htdocs\storage_auctions\application\controllers\Email.php 703
INFO - 2025-05-06 06:10:08 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:08 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:10:08 --> Final output sent to browser
DEBUG - 2025-05-06 06:10:08 --> Total execution time: 0.1749
INFO - 2025-05-06 06:10:29 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:29 --> Model "UserModel" initialized
INFO - 2025-05-06 06:10:38 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:38 --> Model "UserModel" initialized
INFO - 2025-05-06 06:10:38 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:10:38 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:38 --> Model "UserModel" initialized
DEBUG - 2025-05-06 06:10:38 --> PHPMailer class is loaded.
INFO - 2025-05-06 06:10:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 06:10:43 --> Final output sent to browser
DEBUG - 2025-05-06 06:10:43 --> Total execution time: 4.7663
INFO - 2025-05-06 06:10:43 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:43 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:10:43 --> Final output sent to browser
DEBUG - 2025-05-06 06:10:43 --> Total execution time: 0.1933
INFO - 2025-05-06 06:10:49 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:10:49 --> Model "UserModel" initialized
INFO - 2025-05-06 06:14:02 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:14:02 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:14:02 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:02 --> Total execution time: 0.1226
INFO - 2025-05-06 06:14:28 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:14:28 --> Model "UserModel" initialized
INFO - 2025-05-06 06:14:28 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:14:28 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:14:28 --> Model "UserModel" initialized
DEBUG - 2025-05-06 06:14:28 --> PHPMailer class is loaded.
INFO - 2025-05-06 06:14:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 06:14:33 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:33 --> Total execution time: 4.8393
INFO - 2025-05-06 06:14:33 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:14:33 --> Model "StaffModel" initialized
INFO - 2025-05-06 06:14:33 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:33 --> Total execution time: 0.1740
INFO - 2025-05-06 06:14:50 --> Model "UserModel" initialized
INFO - 2025-05-06 06:14:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:14:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:16:31 --> Model "UserModel" initialized
INFO - 2025-05-06 06:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:16:31 --> Final output sent to browser
DEBUG - 2025-05-06 06:16:31 --> Total execution time: 0.2733
INFO - 2025-05-06 06:16:36 --> Model "UserModel" initialized
INFO - 2025-05-06 06:16:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:16:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:16:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:16:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:16:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:16:36 --> Final output sent to browser
DEBUG - 2025-05-06 06:16:36 --> Total execution time: 0.2429
INFO - 2025-05-06 06:17:00 --> Model "UserModel" initialized
INFO - 2025-05-06 06:17:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:17:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:17:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:17:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:17:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:17:01 --> Final output sent to browser
DEBUG - 2025-05-06 06:17:01 --> Total execution time: 0.2207
INFO - 2025-05-06 06:17:05 --> Model "UserModel" initialized
INFO - 2025-05-06 06:17:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:17:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:17:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:17:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:17:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:17:05 --> Final output sent to browser
DEBUG - 2025-05-06 06:17:05 --> Total execution time: 0.1275
INFO - 2025-05-06 06:18:15 --> Model "UserModel" initialized
INFO - 2025-05-06 06:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:18:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:18:15 --> Final output sent to browser
DEBUG - 2025-05-06 06:18:15 --> Total execution time: 0.1123
INFO - 2025-05-06 06:51:25 --> Model "UserModel" initialized
INFO - 2025-05-06 06:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:51:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:51:25 --> Final output sent to browser
DEBUG - 2025-05-06 06:51:25 --> Total execution time: 0.1259
INFO - 2025-05-06 06:51:41 --> Model "UserModel" initialized
INFO - 2025-05-06 06:51:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:51:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:51:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:51:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:51:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:51:41 --> Final output sent to browser
DEBUG - 2025-05-06 06:51:41 --> Total execution time: 0.0955
INFO - 2025-05-06 06:53:01 --> Model "UserModel" initialized
INFO - 2025-05-06 06:53:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:53:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:53:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:53:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:53:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:53:01 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:01 --> Total execution time: 0.1320
INFO - 2025-05-06 06:53:04 --> Model "UserModel" initialized
INFO - 2025-05-06 06:53:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:53:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:53:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:53:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:53:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:53:04 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:04 --> Total execution time: 0.1437
INFO - 2025-05-06 06:53:40 --> Model "UserModel" initialized
INFO - 2025-05-06 06:53:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:53:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:53:45 --> Model "UserModel" initialized
INFO - 2025-05-06 06:53:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:53:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:53:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:53:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:53:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:53:45 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:45 --> Total execution time: 0.3073
INFO - 2025-05-06 06:54:02 --> Model "UserModel" initialized
INFO - 2025-05-06 06:54:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:54:02 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:02 --> Total execution time: 0.2264
INFO - 2025-05-06 06:54:22 --> Model "UserModel" initialized
INFO - 2025-05-06 06:54:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:54:22 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:22 --> Total execution time: 0.2252
INFO - 2025-05-06 06:54:36 --> Model "UserModel" initialized
INFO - 2025-05-06 06:54:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:54:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:54:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:54:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:54:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:54:36 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:36 --> Total execution time: 0.2751
INFO - 2025-05-06 06:54:46 --> Model "UserModel" initialized
INFO - 2025-05-06 06:54:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:54:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:54:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:54:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:54:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:54:46 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:46 --> Total execution time: 0.1273
INFO - 2025-05-06 06:55:02 --> Model "UserModel" initialized
INFO - 2025-05-06 06:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:55:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:55:02 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:02 --> Total execution time: 0.1472
INFO - 2025-05-06 06:55:04 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:55:04 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:04 --> Total execution time: 0.1454
INFO - 2025-05-06 06:55:23 --> Model "UserModel" initialized
INFO - 2025-05-06 06:55:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:55:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:55:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:55:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:55:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:55:23 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:23 --> Total execution time: 0.1356
INFO - 2025-05-06 06:55:24 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:55:24 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:24 --> Total execution time: 0.1532
INFO - 2025-05-06 06:55:37 --> Model "UserModel" initialized
INFO - 2025-05-06 06:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:55:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:55:37 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:37 --> Total execution time: 0.1626
INFO - 2025-05-06 06:55:39 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:55:39 --> Final output sent to browser
DEBUG - 2025-05-06 06:55:39 --> Total execution time: 0.1307
INFO - 2025-05-06 06:56:32 --> Model "UserModel" initialized
INFO - 2025-05-06 06:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:56:32 --> Final output sent to browser
DEBUG - 2025-05-06 06:56:32 --> Total execution time: 0.1366
INFO - 2025-05-06 06:56:33 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:56:33 --> Final output sent to browser
DEBUG - 2025-05-06 06:56:34 --> Total execution time: 0.1304
INFO - 2025-05-06 06:56:43 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:56:44 --> Model "UserModel" initialized
INFO - 2025-05-06 06:56:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:56:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:56:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 06:56:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:56:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:56:44 --> Final output sent to browser
DEBUG - 2025-05-06 06:56:44 --> Total execution time: 0.2459
INFO - 2025-05-06 06:56:46 --> Model "CompanyModel" initialized
INFO - 2025-05-06 06:56:46 --> Final output sent to browser
DEBUG - 2025-05-06 06:56:46 --> Total execution time: 0.2838
INFO - 2025-05-06 07:04:28 --> Model "UserModel" initialized
INFO - 2025-05-06 07:04:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:04:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:04:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:04:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:04:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:04:28 --> Final output sent to browser
DEBUG - 2025-05-06 07:04:28 --> Total execution time: 0.5036
INFO - 2025-05-06 07:04:30 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:04:30 --> Final output sent to browser
DEBUG - 2025-05-06 07:04:30 --> Total execution time: 0.2597
INFO - 2025-05-06 07:04:32 --> Model "UserModel" initialized
INFO - 2025-05-06 07:04:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:04:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:04:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:04:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:04:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:04:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:04:32 --> Total execution time: 0.1187
INFO - 2025-05-06 07:04:33 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:04:33 --> Final output sent to browser
DEBUG - 2025-05-06 07:04:33 --> Total execution time: 0.1372
INFO - 2025-05-06 07:06:27 --> Model "UserModel" initialized
INFO - 2025-05-06 07:06:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:06:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:06:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:06:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:06:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:06:27 --> Final output sent to browser
DEBUG - 2025-05-06 07:06:27 --> Total execution time: 0.1168
INFO - 2025-05-06 07:06:29 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:06:29 --> Final output sent to browser
DEBUG - 2025-05-06 07:06:29 --> Total execution time: 0.2181
INFO - 2025-05-06 07:07:13 --> Model "UserModel" initialized
INFO - 2025-05-06 07:07:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:07:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:07:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:07:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:07:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:07:13 --> Final output sent to browser
DEBUG - 2025-05-06 07:07:13 --> Total execution time: 0.1263
INFO - 2025-05-06 07:07:15 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:07:15 --> Final output sent to browser
DEBUG - 2025-05-06 07:07:15 --> Total execution time: 0.1418
INFO - 2025-05-06 07:07:41 --> Model "UserModel" initialized
INFO - 2025-05-06 07:07:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:07:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:07:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:07:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:07:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:07:41 --> Final output sent to browser
DEBUG - 2025-05-06 07:07:41 --> Total execution time: 0.1371
INFO - 2025-05-06 07:07:43 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:07:43 --> Final output sent to browser
DEBUG - 2025-05-06 07:07:43 --> Total execution time: 0.1579
INFO - 2025-05-06 07:08:09 --> Model "UserModel" initialized
INFO - 2025-05-06 07:08:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:08:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:08:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:08:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:08:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:08:09 --> Final output sent to browser
DEBUG - 2025-05-06 07:08:09 --> Total execution time: 0.1045
INFO - 2025-05-06 07:08:11 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:08:11 --> Final output sent to browser
DEBUG - 2025-05-06 07:08:11 --> Total execution time: 0.1167
INFO - 2025-05-06 07:09:03 --> Model "UserModel" initialized
INFO - 2025-05-06 07:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:09:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:09:03 --> Final output sent to browser
DEBUG - 2025-05-06 07:09:03 --> Total execution time: 0.1530
INFO - 2025-05-06 07:09:04 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:09:04 --> Final output sent to browser
DEBUG - 2025-05-06 07:09:04 --> Total execution time: 0.1544
INFO - 2025-05-06 07:09:05 --> Model "StaffModel" initialized
ERROR - 2025-05-06 07:09:06 --> Severity: Warning --> Undefined property: Users::$UserModel C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1852
ERROR - 2025-05-06 07:09:06 --> Severity: error --> Exception: Call to a member function deleteActivationToken() on null C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1852
INFO - 2025-05-06 07:10:15 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:10:15 --> Model "UserModel" initialized
ERROR - 2025-05-06 07:10:15 --> Severity: Warning --> Undefined variable $token C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1856
INFO - 2025-05-06 07:10:32 --> Model "UserModel" initialized
INFO - 2025-05-06 07:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:10:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:10:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:10:32 --> Total execution time: 0.1214
INFO - 2025-05-06 07:10:33 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:10:33 --> Final output sent to browser
DEBUG - 2025-05-06 07:10:33 --> Total execution time: 0.1700
INFO - 2025-05-06 07:11:01 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:11:02 --> Model "UserModel" initialized
ERROR - 2025-05-06 07:11:02 --> Severity: Warning --> Undefined variable $token C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1856
ERROR - 2025-05-06 07:11:30 --> Severity: Warning --> Undefined property: Users::$UserModel C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1825
ERROR - 2025-05-06 07:11:30 --> Severity: error --> Exception: Call to a member function getActivationByToken() on null C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1825
ERROR - 2025-05-06 07:11:42 --> Severity: Warning --> Undefined property: Users::$UserModel C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1825
ERROR - 2025-05-06 07:11:42 --> Severity: error --> Exception: Call to a member function getActivationByToken() on null C:\xampp\htdocs\storage_auctions\application\controllers\Users.php 1825
INFO - 2025-05-06 07:12:17 --> Model "UserModel" initialized
INFO - 2025-05-06 07:12:17 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:12:20 --> Model "UserModel" initialized
INFO - 2025-05-06 07:13:28 --> Model "UserModel" initialized
INFO - 2025-05-06 07:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-06 07:13:28 --> Final output sent to browser
DEBUG - 2025-05-06 07:13:28 --> Total execution time: 0.1515
INFO - 2025-05-06 07:14:21 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:14:21 --> Model "UserModel" initialized
INFO - 2025-05-06 07:14:21 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:14:22 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:14:22 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:14:22 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:14:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:14:26 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:26 --> Total execution time: 4.5874
INFO - 2025-05-06 07:14:27 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:14:27 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:14:27 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:27 --> Total execution time: 0.1895
INFO - 2025-05-06 07:14:35 --> Model "UserModel" initialized
INFO - 2025-05-06 07:14:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-06 07:14:35 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:35 --> Total execution time: 0.1377
INFO - 2025-05-06 07:14:45 --> Model "UserModel" initialized
INFO - 2025-05-06 07:14:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:14:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:14:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:14:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:14:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:14:45 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:45 --> Total execution time: 0.1380
INFO - 2025-05-06 07:14:47 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:14:47 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:47 --> Total execution time: 0.1535
INFO - 2025-05-06 07:14:48 --> Model "UserModel" initialized
INFO - 2025-05-06 07:14:48 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:14:52 --> Model "AuctionModel" initialized
INFO - 2025-05-06 07:14:57 --> Model "UserModel" initialized
INFO - 2025-05-06 07:14:57 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\user/activation/invalid.php
INFO - 2025-05-06 07:14:57 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:57 --> Total execution time: 0.1393
INFO - 2025-05-06 07:15:29 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:15:29 --> Model "UserModel" initialized
INFO - 2025-05-06 07:15:29 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:15:29 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:15:29 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:15:29 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:15:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:15:37 --> Final output sent to browser
DEBUG - 2025-05-06 07:15:37 --> Total execution time: 7.8793
INFO - 2025-05-06 07:15:37 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:15:37 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:15:38 --> Final output sent to browser
DEBUG - 2025-05-06 07:15:38 --> Total execution time: 0.3136
INFO - 2025-05-06 07:15:49 --> Model "UserModel" initialized
INFO - 2025-05-06 07:15:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:15:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:15:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:15:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:15:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:15:49 --> Final output sent to browser
DEBUG - 2025-05-06 07:15:49 --> Total execution time: 0.1367
INFO - 2025-05-06 07:15:51 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:15:51 --> Final output sent to browser
DEBUG - 2025-05-06 07:15:51 --> Total execution time: 0.2205
INFO - 2025-05-06 07:16:00 --> Model "UserModel" initialized
INFO - 2025-05-06 07:16:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:16:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:16:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:16:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:16:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:16:00 --> Final output sent to browser
DEBUG - 2025-05-06 07:16:00 --> Total execution time: 0.1228
INFO - 2025-05-06 07:16:01 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:16:01 --> Final output sent to browser
DEBUG - 2025-05-06 07:16:01 --> Total execution time: 0.1611
INFO - 2025-05-06 07:16:09 --> Model "UserModel" initialized
INFO - 2025-05-06 07:16:09 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:16:16 --> Model "AuctionModel" initialized
INFO - 2025-05-06 07:16:17 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:16:17 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:16:17 --> Final output sent to browser
DEBUG - 2025-05-06 07:16:17 --> Total execution time: 0.1967
INFO - 2025-05-06 07:32:57 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:32:57 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:32:57 --> Final output sent to browser
DEBUG - 2025-05-06 07:32:57 --> Total execution time: 0.2955
INFO - 2025-05-06 07:32:59 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:32:59 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:32:59 --> Final output sent to browser
DEBUG - 2025-05-06 07:32:59 --> Total execution time: 0.1771
INFO - 2025-05-06 07:33:11 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:33:11 --> Model "UserModel" initialized
INFO - 2025-05-06 07:33:11 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:33:11 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:33:11 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:33:11 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:33:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:33:23 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:23 --> Total execution time: 11.5588
INFO - 2025-05-06 07:33:23 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:33:23 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:33:23 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:23 --> Total execution time: 0.2071
INFO - 2025-05-06 07:33:48 --> Model "UserModel" initialized
INFO - 2025-05-06 07:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:33:48 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:48 --> Total execution time: 0.0826
INFO - 2025-05-06 07:33:49 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:33:49 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:49 --> Total execution time: 0.3088
INFO - 2025-05-06 07:33:51 --> Model "UserModel" initialized
INFO - 2025-05-06 07:33:51 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:33:54 --> Model "AuctionModel" initialized
INFO - 2025-05-06 07:33:58 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:33:58 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:33:58 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:58 --> Total execution time: 0.2152
INFO - 2025-05-06 07:35:18 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:35:18 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:35:18 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:35:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:35:26 --> Final output sent to browser
DEBUG - 2025-05-06 07:35:26 --> Total execution time: 7.6608
INFO - 2025-05-06 07:35:26 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:35:26 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:35:26 --> Final output sent to browser
DEBUG - 2025-05-06 07:35:26 --> Total execution time: 0.1472
INFO - 2025-05-06 07:36:09 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:36:09 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:36:09 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:36:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:36:17 --> Final output sent to browser
DEBUG - 2025-05-06 07:36:17 --> Total execution time: 8.2408
INFO - 2025-05-06 07:36:17 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:36:17 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:36:17 --> Final output sent to browser
DEBUG - 2025-05-06 07:36:17 --> Total execution time: 0.2333
INFO - 2025-05-06 07:36:29 --> Model "UserModel" initialized
INFO - 2025-05-06 07:36:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:36:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:36:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:36:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:36:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:36:29 --> Final output sent to browser
DEBUG - 2025-05-06 07:36:29 --> Total execution time: 0.1319
INFO - 2025-05-06 07:36:30 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:36:30 --> Final output sent to browser
DEBUG - 2025-05-06 07:36:30 --> Total execution time: 0.0884
INFO - 2025-05-06 07:37:31 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:37:31 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:37:31 --> Final output sent to browser
DEBUG - 2025-05-06 07:37:31 --> Total execution time: 0.1645
INFO - 2025-05-06 07:38:25 --> Model "UserModel" initialized
INFO - 2025-05-06 07:38:25 --> Final output sent to browser
DEBUG - 2025-05-06 07:38:25 --> Total execution time: 0.1260
INFO - 2025-05-06 07:38:46 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:38:46 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:38:46 --> Final output sent to browser
DEBUG - 2025-05-06 07:38:46 --> Total execution time: 0.1819
INFO - 2025-05-06 07:38:52 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:38:52 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:38:52 --> Final output sent to browser
DEBUG - 2025-05-06 07:38:52 --> Total execution time: 0.2015
INFO - 2025-05-06 07:39:25 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:39:25 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:39:25 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:25 --> Total execution time: 0.1646
INFO - 2025-05-06 07:39:48 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:39:48 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:39:48 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:48 --> Total execution time: 0.1890
INFO - 2025-05-06 07:46:45 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:46:45 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:46:45 --> Final output sent to browser
DEBUG - 2025-05-06 07:46:45 --> Total execution time: 0.1925
INFO - 2025-05-06 07:46:47 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:46:47 --> Model "UserModel" initialized
DEBUG - 2025-05-06 07:46:47 --> PHPMailer class is loaded.
INFO - 2025-05-06 07:46:47 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 07:46:55 --> Final output sent to browser
DEBUG - 2025-05-06 07:46:55 --> Total execution time: 7.6398
INFO - 2025-05-06 07:47:09 --> Model "UserModel" initialized
INFO - 2025-05-06 07:47:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:47:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:47:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:47:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:47:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:47:09 --> Final output sent to browser
DEBUG - 2025-05-06 07:47:09 --> Total execution time: 0.1254
INFO - 2025-05-06 07:47:10 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:47:10 --> Final output sent to browser
DEBUG - 2025-05-06 07:47:10 --> Total execution time: 0.1453
INFO - 2025-05-06 07:47:31 --> Model "UserModel" initialized
INFO - 2025-05-06 07:47:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:47:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:47:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/accept_invitation.php
INFO - 2025-05-06 07:47:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:47:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:47:31 --> Final output sent to browser
DEBUG - 2025-05-06 07:47:31 --> Total execution time: 0.2243
INFO - 2025-05-06 07:47:32 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:47:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:47:32 --> Total execution time: 0.1158
INFO - 2025-05-06 07:48:52 --> Model "CompanyModel" initialized
INFO - 2025-05-06 07:48:52 --> Model "StaffModel" initialized
INFO - 2025-05-06 07:48:52 --> Final output sent to browser
DEBUG - 2025-05-06 07:48:52 --> Total execution time: 0.2177
INFO - 2025-05-06 07:49:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:49:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:49:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 07:49:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:49:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:49:53 --> Final output sent to browser
DEBUG - 2025-05-06 07:49:53 --> Total execution time: 0.1090
INFO - 2025-05-06 07:50:17 --> Model "AuctionModel" initialized
INFO - 2025-05-06 07:50:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 07:50:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 07:50:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 07:50:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 07:50:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 07:50:55 --> Final output sent to browser
DEBUG - 2025-05-06 07:50:55 --> Total execution time: 0.0924
INFO - 2025-05-06 05:28:28 --> Config Class Initialized
INFO - 2025-05-06 05:28:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:28:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:28:28 --> Utf8 Class Initialized
INFO - 2025-05-06 05:28:28 --> URI Class Initialized
DEBUG - 2025-05-06 05:28:28 --> No URI present. Default controller set.
INFO - 2025-05-06 05:28:28 --> Router Class Initialized
INFO - 2025-05-06 05:28:28 --> Output Class Initialized
INFO - 2025-05-06 05:28:28 --> Security Class Initialized
DEBUG - 2025-05-06 05:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:28:28 --> Input Class Initialized
INFO - 2025-05-06 05:28:28 --> Language Class Initialized
INFO - 2025-05-06 05:28:28 --> Loader Class Initialized
INFO - 2025-05-06 05:28:28 --> Helper loaded: url_helper
INFO - 2025-05-06 05:28:28 --> Helper loaded: string_helper
INFO - 2025-05-06 05:28:28 --> Helper loaded: form_helper
INFO - 2025-05-06 05:28:28 --> Helper loaded: file_helper
INFO - 2025-05-06 05:28:28 --> Helper loaded: html_helper
INFO - 2025-05-06 05:28:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:28:28 --> Controller Class Initialized
INFO - 2025-05-06 05:28:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 05:28:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 05:28:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 05:28:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 05:28:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 05:28:28 --> Final output sent to browser
DEBUG - 2025-05-06 05:28:29 --> Total execution time: 0.2882
INFO - 2025-05-06 05:28:31 --> Config Class Initialized
INFO - 2025-05-06 05:28:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:28:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:28:31 --> Utf8 Class Initialized
INFO - 2025-05-06 05:28:31 --> URI Class Initialized
INFO - 2025-05-06 05:28:31 --> Router Class Initialized
INFO - 2025-05-06 05:28:31 --> Output Class Initialized
INFO - 2025-05-06 05:28:31 --> Security Class Initialized
DEBUG - 2025-05-06 05:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:28:31 --> Input Class Initialized
INFO - 2025-05-06 05:28:31 --> Language Class Initialized
INFO - 2025-05-06 05:28:31 --> Loader Class Initialized
INFO - 2025-05-06 05:28:31 --> Helper loaded: url_helper
INFO - 2025-05-06 05:28:31 --> Helper loaded: string_helper
INFO - 2025-05-06 05:28:31 --> Helper loaded: form_helper
INFO - 2025-05-06 05:28:31 --> Helper loaded: file_helper
INFO - 2025-05-06 05:28:31 --> Helper loaded: html_helper
INFO - 2025-05-06 05:28:31 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:28:31 --> Controller Class Initialized
INFO - 2025-05-06 13:28:31 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:30:03 --> Config Class Initialized
INFO - 2025-05-06 05:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:30:03 --> Utf8 Class Initialized
INFO - 2025-05-06 05:30:03 --> URI Class Initialized
INFO - 2025-05-06 05:30:03 --> Router Class Initialized
INFO - 2025-05-06 05:30:03 --> Output Class Initialized
INFO - 2025-05-06 05:30:03 --> Security Class Initialized
DEBUG - 2025-05-06 05:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:30:03 --> Input Class Initialized
INFO - 2025-05-06 05:30:03 --> Language Class Initialized
INFO - 2025-05-06 05:30:03 --> Loader Class Initialized
INFO - 2025-05-06 05:30:03 --> Helper loaded: url_helper
INFO - 2025-05-06 05:30:03 --> Helper loaded: string_helper
INFO - 2025-05-06 05:30:03 --> Helper loaded: form_helper
INFO - 2025-05-06 05:30:03 --> Helper loaded: file_helper
INFO - 2025-05-06 05:30:03 --> Helper loaded: html_helper
INFO - 2025-05-06 05:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:30:03 --> Controller Class Initialized
INFO - 2025-05-06 13:30:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:30:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:30:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:30:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:30:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:30:03 --> Final output sent to browser
DEBUG - 2025-05-06 13:30:03 --> Total execution time: 0.2305
INFO - 2025-05-06 05:42:53 --> Config Class Initialized
INFO - 2025-05-06 05:42:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:42:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:42:53 --> Utf8 Class Initialized
INFO - 2025-05-06 05:42:53 --> URI Class Initialized
DEBUG - 2025-05-06 05:42:53 --> No URI present. Default controller set.
INFO - 2025-05-06 05:42:53 --> Router Class Initialized
INFO - 2025-05-06 05:42:53 --> Output Class Initialized
INFO - 2025-05-06 05:42:53 --> Security Class Initialized
DEBUG - 2025-05-06 05:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:42:53 --> Input Class Initialized
INFO - 2025-05-06 05:42:53 --> Language Class Initialized
INFO - 2025-05-06 05:42:53 --> Loader Class Initialized
INFO - 2025-05-06 05:42:53 --> Helper loaded: url_helper
INFO - 2025-05-06 05:42:53 --> Helper loaded: string_helper
INFO - 2025-05-06 05:42:53 --> Helper loaded: form_helper
INFO - 2025-05-06 05:42:53 --> Helper loaded: file_helper
INFO - 2025-05-06 05:42:53 --> Helper loaded: html_helper
INFO - 2025-05-06 05:42:53 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:42:53 --> Controller Class Initialized
INFO - 2025-05-06 05:42:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 05:42:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 05:42:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 05:42:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 05:42:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 05:42:53 --> Final output sent to browser
DEBUG - 2025-05-06 05:42:53 --> Total execution time: 0.1552
INFO - 2025-05-06 05:42:54 --> Config Class Initialized
INFO - 2025-05-06 05:42:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:42:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:42:54 --> Utf8 Class Initialized
INFO - 2025-05-06 05:42:54 --> URI Class Initialized
INFO - 2025-05-06 05:42:54 --> Router Class Initialized
INFO - 2025-05-06 05:42:54 --> Output Class Initialized
INFO - 2025-05-06 05:42:54 --> Security Class Initialized
DEBUG - 2025-05-06 05:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:42:54 --> Input Class Initialized
INFO - 2025-05-06 05:42:55 --> Language Class Initialized
INFO - 2025-05-06 05:42:55 --> Loader Class Initialized
INFO - 2025-05-06 05:42:55 --> Helper loaded: url_helper
INFO - 2025-05-06 05:42:55 --> Helper loaded: string_helper
INFO - 2025-05-06 05:42:55 --> Helper loaded: form_helper
INFO - 2025-05-06 05:42:55 --> Helper loaded: file_helper
INFO - 2025-05-06 05:42:55 --> Helper loaded: html_helper
INFO - 2025-05-06 05:42:55 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:42:55 --> Controller Class Initialized
INFO - 2025-05-06 13:42:55 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:43:06 --> Config Class Initialized
INFO - 2025-05-06 05:43:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:43:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:43:06 --> Utf8 Class Initialized
INFO - 2025-05-06 05:43:06 --> URI Class Initialized
DEBUG - 2025-05-06 05:43:06 --> No URI present. Default controller set.
INFO - 2025-05-06 05:43:06 --> Router Class Initialized
INFO - 2025-05-06 05:43:06 --> Output Class Initialized
INFO - 2025-05-06 05:43:06 --> Security Class Initialized
DEBUG - 2025-05-06 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:43:06 --> Input Class Initialized
INFO - 2025-05-06 05:43:06 --> Language Class Initialized
INFO - 2025-05-06 05:43:06 --> Loader Class Initialized
INFO - 2025-05-06 05:43:06 --> Helper loaded: url_helper
INFO - 2025-05-06 05:43:06 --> Helper loaded: string_helper
INFO - 2025-05-06 05:43:06 --> Helper loaded: form_helper
INFO - 2025-05-06 05:43:06 --> Helper loaded: file_helper
INFO - 2025-05-06 05:43:06 --> Helper loaded: html_helper
INFO - 2025-05-06 05:43:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:43:06 --> Controller Class Initialized
INFO - 2025-05-06 05:43:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 05:43:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 05:43:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 05:43:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 05:43:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 05:43:06 --> Final output sent to browser
DEBUG - 2025-05-06 05:43:06 --> Total execution time: 0.1316
INFO - 2025-05-06 05:44:04 --> Config Class Initialized
INFO - 2025-05-06 05:44:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:44:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:44:04 --> Utf8 Class Initialized
INFO - 2025-05-06 05:44:04 --> URI Class Initialized
DEBUG - 2025-05-06 05:44:04 --> No URI present. Default controller set.
INFO - 2025-05-06 05:44:04 --> Router Class Initialized
INFO - 2025-05-06 05:44:04 --> Output Class Initialized
INFO - 2025-05-06 05:44:04 --> Security Class Initialized
DEBUG - 2025-05-06 05:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:44:04 --> Input Class Initialized
INFO - 2025-05-06 05:44:04 --> Language Class Initialized
INFO - 2025-05-06 05:44:04 --> Loader Class Initialized
INFO - 2025-05-06 05:44:04 --> Helper loaded: url_helper
INFO - 2025-05-06 05:44:04 --> Helper loaded: string_helper
INFO - 2025-05-06 05:44:04 --> Helper loaded: form_helper
INFO - 2025-05-06 05:44:04 --> Helper loaded: file_helper
INFO - 2025-05-06 05:44:04 --> Helper loaded: html_helper
INFO - 2025-05-06 05:44:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:44:04 --> Controller Class Initialized
INFO - 2025-05-06 05:44:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 05:44:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 05:44:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 05:44:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 05:44:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 05:44:04 --> Final output sent to browser
DEBUG - 2025-05-06 05:44:04 --> Total execution time: 0.1038
INFO - 2025-05-06 05:44:06 --> Config Class Initialized
INFO - 2025-05-06 05:44:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:44:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:44:06 --> Utf8 Class Initialized
INFO - 2025-05-06 05:44:06 --> URI Class Initialized
INFO - 2025-05-06 05:44:06 --> Router Class Initialized
INFO - 2025-05-06 05:44:06 --> Output Class Initialized
INFO - 2025-05-06 05:44:06 --> Security Class Initialized
DEBUG - 2025-05-06 05:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:44:06 --> Input Class Initialized
INFO - 2025-05-06 05:44:06 --> Language Class Initialized
INFO - 2025-05-06 05:44:06 --> Loader Class Initialized
INFO - 2025-05-06 05:44:06 --> Helper loaded: url_helper
INFO - 2025-05-06 05:44:06 --> Helper loaded: string_helper
INFO - 2025-05-06 05:44:06 --> Helper loaded: form_helper
INFO - 2025-05-06 05:44:06 --> Helper loaded: file_helper
INFO - 2025-05-06 05:44:06 --> Helper loaded: html_helper
INFO - 2025-05-06 05:44:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:44:06 --> Controller Class Initialized
INFO - 2025-05-06 13:44:06 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:45:33 --> Config Class Initialized
INFO - 2025-05-06 05:45:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:45:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:45:33 --> Utf8 Class Initialized
INFO - 2025-05-06 05:45:33 --> URI Class Initialized
INFO - 2025-05-06 05:45:33 --> Router Class Initialized
INFO - 2025-05-06 05:45:33 --> Output Class Initialized
INFO - 2025-05-06 05:45:33 --> Security Class Initialized
DEBUG - 2025-05-06 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:45:33 --> Input Class Initialized
INFO - 2025-05-06 05:45:33 --> Language Class Initialized
INFO - 2025-05-06 05:45:33 --> Loader Class Initialized
INFO - 2025-05-06 05:45:33 --> Helper loaded: url_helper
INFO - 2025-05-06 05:45:33 --> Helper loaded: string_helper
INFO - 2025-05-06 05:45:33 --> Helper loaded: form_helper
INFO - 2025-05-06 05:45:33 --> Helper loaded: file_helper
INFO - 2025-05-06 05:45:33 --> Helper loaded: html_helper
INFO - 2025-05-06 05:45:33 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:45:33 --> Controller Class Initialized
INFO - 2025-05-06 13:45:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:45:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:45:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:45:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:45:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:45:33 --> Final output sent to browser
DEBUG - 2025-05-06 13:45:33 --> Total execution time: 0.0904
INFO - 2025-05-06 05:47:28 --> Config Class Initialized
INFO - 2025-05-06 05:47:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:47:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:47:28 --> Utf8 Class Initialized
INFO - 2025-05-06 05:47:28 --> URI Class Initialized
INFO - 2025-05-06 05:47:28 --> Router Class Initialized
INFO - 2025-05-06 05:47:28 --> Output Class Initialized
INFO - 2025-05-06 05:47:28 --> Security Class Initialized
DEBUG - 2025-05-06 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:47:28 --> Input Class Initialized
INFO - 2025-05-06 05:47:28 --> Language Class Initialized
INFO - 2025-05-06 05:47:28 --> Loader Class Initialized
INFO - 2025-05-06 05:47:28 --> Helper loaded: url_helper
INFO - 2025-05-06 05:47:28 --> Helper loaded: string_helper
INFO - 2025-05-06 05:47:28 --> Helper loaded: form_helper
INFO - 2025-05-06 05:47:28 --> Helper loaded: file_helper
INFO - 2025-05-06 05:47:28 --> Helper loaded: html_helper
INFO - 2025-05-06 05:47:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:47:28 --> Controller Class Initialized
INFO - 2025-05-06 13:47:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:47:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:47:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:47:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:47:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:47:28 --> Final output sent to browser
DEBUG - 2025-05-06 13:47:28 --> Total execution time: 0.3934
INFO - 2025-05-06 05:48:58 --> Config Class Initialized
INFO - 2025-05-06 05:48:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:48:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:48:58 --> Utf8 Class Initialized
INFO - 2025-05-06 05:48:58 --> URI Class Initialized
INFO - 2025-05-06 05:48:58 --> Router Class Initialized
INFO - 2025-05-06 05:48:58 --> Output Class Initialized
INFO - 2025-05-06 05:48:58 --> Security Class Initialized
DEBUG - 2025-05-06 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:48:58 --> Input Class Initialized
INFO - 2025-05-06 05:48:58 --> Language Class Initialized
INFO - 2025-05-06 05:48:58 --> Loader Class Initialized
INFO - 2025-05-06 05:48:58 --> Helper loaded: url_helper
INFO - 2025-05-06 05:48:58 --> Helper loaded: string_helper
INFO - 2025-05-06 05:48:58 --> Helper loaded: form_helper
INFO - 2025-05-06 05:48:58 --> Helper loaded: file_helper
INFO - 2025-05-06 05:48:58 --> Helper loaded: html_helper
INFO - 2025-05-06 05:48:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:48:58 --> Controller Class Initialized
INFO - 2025-05-06 13:48:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:48:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:48:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:48:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:48:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:48:58 --> Final output sent to browser
DEBUG - 2025-05-06 13:48:58 --> Total execution time: 0.1505
INFO - 2025-05-06 05:54:13 --> Config Class Initialized
INFO - 2025-05-06 05:54:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:54:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:54:13 --> Utf8 Class Initialized
INFO - 2025-05-06 05:54:13 --> URI Class Initialized
INFO - 2025-05-06 05:54:13 --> Router Class Initialized
INFO - 2025-05-06 05:54:13 --> Output Class Initialized
INFO - 2025-05-06 05:54:13 --> Security Class Initialized
DEBUG - 2025-05-06 05:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:54:13 --> Input Class Initialized
INFO - 2025-05-06 05:54:13 --> Language Class Initialized
INFO - 2025-05-06 05:54:14 --> Loader Class Initialized
INFO - 2025-05-06 05:54:14 --> Helper loaded: url_helper
INFO - 2025-05-06 05:54:14 --> Helper loaded: string_helper
INFO - 2025-05-06 05:54:14 --> Helper loaded: form_helper
INFO - 2025-05-06 05:54:14 --> Helper loaded: file_helper
INFO - 2025-05-06 05:54:14 --> Helper loaded: html_helper
INFO - 2025-05-06 05:54:14 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:54:14 --> Controller Class Initialized
INFO - 2025-05-06 13:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:54:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:54:14 --> Final output sent to browser
DEBUG - 2025-05-06 13:54:14 --> Total execution time: 0.1030
INFO - 2025-05-06 05:54:18 --> Config Class Initialized
INFO - 2025-05-06 05:54:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:54:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:54:19 --> Utf8 Class Initialized
INFO - 2025-05-06 05:54:19 --> URI Class Initialized
INFO - 2025-05-06 05:54:19 --> Router Class Initialized
INFO - 2025-05-06 05:54:19 --> Output Class Initialized
INFO - 2025-05-06 05:54:19 --> Security Class Initialized
DEBUG - 2025-05-06 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:54:19 --> Input Class Initialized
INFO - 2025-05-06 05:54:19 --> Language Class Initialized
INFO - 2025-05-06 05:54:19 --> Loader Class Initialized
INFO - 2025-05-06 05:54:19 --> Helper loaded: url_helper
INFO - 2025-05-06 05:54:19 --> Helper loaded: string_helper
INFO - 2025-05-06 05:54:19 --> Helper loaded: form_helper
INFO - 2025-05-06 05:54:19 --> Helper loaded: file_helper
INFO - 2025-05-06 05:54:19 --> Helper loaded: html_helper
INFO - 2025-05-06 05:54:19 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:54:19 --> Controller Class Initialized
INFO - 2025-05-06 13:54:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:54:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:54:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:54:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:54:19 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:54:19 --> Final output sent to browser
DEBUG - 2025-05-06 13:54:19 --> Total execution time: 0.1362
INFO - 2025-05-06 05:54:56 --> Config Class Initialized
INFO - 2025-05-06 05:54:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:54:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:54:56 --> Utf8 Class Initialized
INFO - 2025-05-06 05:54:56 --> URI Class Initialized
INFO - 2025-05-06 05:54:56 --> Router Class Initialized
INFO - 2025-05-06 05:54:56 --> Output Class Initialized
INFO - 2025-05-06 05:54:56 --> Security Class Initialized
DEBUG - 2025-05-06 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:54:56 --> Input Class Initialized
INFO - 2025-05-06 05:54:56 --> Language Class Initialized
INFO - 2025-05-06 05:54:56 --> Loader Class Initialized
INFO - 2025-05-06 05:54:56 --> Helper loaded: url_helper
INFO - 2025-05-06 05:54:56 --> Helper loaded: string_helper
INFO - 2025-05-06 05:54:56 --> Helper loaded: form_helper
INFO - 2025-05-06 05:54:56 --> Helper loaded: file_helper
INFO - 2025-05-06 05:54:56 --> Helper loaded: html_helper
INFO - 2025-05-06 05:54:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:54:56 --> Controller Class Initialized
INFO - 2025-05-06 13:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:54:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:54:56 --> Final output sent to browser
DEBUG - 2025-05-06 13:54:56 --> Total execution time: 0.0898
INFO - 2025-05-06 05:55:29 --> Config Class Initialized
INFO - 2025-05-06 05:55:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:55:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:55:29 --> Utf8 Class Initialized
INFO - 2025-05-06 05:55:29 --> URI Class Initialized
DEBUG - 2025-05-06 05:55:29 --> No URI present. Default controller set.
INFO - 2025-05-06 05:55:29 --> Router Class Initialized
INFO - 2025-05-06 05:55:29 --> Output Class Initialized
INFO - 2025-05-06 05:55:29 --> Security Class Initialized
DEBUG - 2025-05-06 05:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:55:29 --> Input Class Initialized
INFO - 2025-05-06 05:55:29 --> Language Class Initialized
INFO - 2025-05-06 05:55:29 --> Loader Class Initialized
INFO - 2025-05-06 05:55:29 --> Helper loaded: url_helper
INFO - 2025-05-06 05:55:29 --> Helper loaded: string_helper
INFO - 2025-05-06 05:55:29 --> Helper loaded: form_helper
INFO - 2025-05-06 05:55:29 --> Helper loaded: file_helper
INFO - 2025-05-06 05:55:29 --> Helper loaded: html_helper
INFO - 2025-05-06 05:55:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:55:29 --> Controller Class Initialized
INFO - 2025-05-06 05:55:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 05:55:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 05:55:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 05:55:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 05:55:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 05:55:29 --> Final output sent to browser
DEBUG - 2025-05-06 05:55:29 --> Total execution time: 0.1140
INFO - 2025-05-06 05:56:32 --> Config Class Initialized
INFO - 2025-05-06 05:56:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:56:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:56:32 --> Utf8 Class Initialized
INFO - 2025-05-06 05:56:32 --> URI Class Initialized
INFO - 2025-05-06 05:56:32 --> Router Class Initialized
INFO - 2025-05-06 05:56:32 --> Output Class Initialized
INFO - 2025-05-06 05:56:32 --> Security Class Initialized
DEBUG - 2025-05-06 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:56:32 --> Input Class Initialized
INFO - 2025-05-06 05:56:32 --> Language Class Initialized
INFO - 2025-05-06 05:56:32 --> Loader Class Initialized
INFO - 2025-05-06 05:56:32 --> Helper loaded: url_helper
INFO - 2025-05-06 05:56:32 --> Helper loaded: string_helper
INFO - 2025-05-06 05:56:32 --> Helper loaded: form_helper
INFO - 2025-05-06 05:56:32 --> Helper loaded: file_helper
INFO - 2025-05-06 05:56:32 --> Helper loaded: html_helper
INFO - 2025-05-06 05:56:32 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:56:32 --> Controller Class Initialized
INFO - 2025-05-06 13:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:56:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:56:32 --> Final output sent to browser
DEBUG - 2025-05-06 13:56:32 --> Total execution time: 0.1301
INFO - 2025-05-06 05:56:50 --> Config Class Initialized
INFO - 2025-05-06 05:56:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:56:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:56:51 --> Utf8 Class Initialized
INFO - 2025-05-06 05:56:51 --> URI Class Initialized
INFO - 2025-05-06 05:56:51 --> Router Class Initialized
INFO - 2025-05-06 05:56:51 --> Output Class Initialized
INFO - 2025-05-06 05:56:51 --> Security Class Initialized
DEBUG - 2025-05-06 05:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:56:51 --> Input Class Initialized
INFO - 2025-05-06 05:56:51 --> Language Class Initialized
INFO - 2025-05-06 05:56:51 --> Loader Class Initialized
INFO - 2025-05-06 05:56:51 --> Helper loaded: url_helper
INFO - 2025-05-06 05:56:51 --> Helper loaded: string_helper
INFO - 2025-05-06 05:56:51 --> Helper loaded: form_helper
INFO - 2025-05-06 05:56:51 --> Helper loaded: file_helper
INFO - 2025-05-06 05:56:51 --> Helper loaded: html_helper
INFO - 2025-05-06 05:56:51 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:56:51 --> Controller Class Initialized
INFO - 2025-05-06 13:56:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:56:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:56:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:56:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:56:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:56:51 --> Final output sent to browser
DEBUG - 2025-05-06 13:56:51 --> Total execution time: 0.1409
INFO - 2025-05-06 05:57:42 --> Config Class Initialized
INFO - 2025-05-06 05:57:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:57:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:57:42 --> Utf8 Class Initialized
INFO - 2025-05-06 05:57:42 --> URI Class Initialized
INFO - 2025-05-06 05:57:42 --> Router Class Initialized
INFO - 2025-05-06 05:57:42 --> Output Class Initialized
INFO - 2025-05-06 05:57:42 --> Security Class Initialized
DEBUG - 2025-05-06 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:57:42 --> Input Class Initialized
INFO - 2025-05-06 05:57:42 --> Language Class Initialized
INFO - 2025-05-06 05:57:42 --> Loader Class Initialized
INFO - 2025-05-06 05:57:42 --> Helper loaded: url_helper
INFO - 2025-05-06 05:57:42 --> Helper loaded: string_helper
INFO - 2025-05-06 05:57:42 --> Helper loaded: form_helper
INFO - 2025-05-06 05:57:42 --> Helper loaded: file_helper
INFO - 2025-05-06 05:57:42 --> Helper loaded: html_helper
INFO - 2025-05-06 05:57:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:57:42 --> Controller Class Initialized
INFO - 2025-05-06 13:57:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:57:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:57:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:57:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:57:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:57:42 --> Final output sent to browser
DEBUG - 2025-05-06 13:57:42 --> Total execution time: 0.0986
INFO - 2025-05-06 05:57:47 --> Config Class Initialized
INFO - 2025-05-06 05:57:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:57:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:57:47 --> Utf8 Class Initialized
INFO - 2025-05-06 05:57:47 --> URI Class Initialized
INFO - 2025-05-06 05:57:47 --> Router Class Initialized
INFO - 2025-05-06 05:57:47 --> Output Class Initialized
INFO - 2025-05-06 05:57:47 --> Security Class Initialized
DEBUG - 2025-05-06 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:57:47 --> Input Class Initialized
INFO - 2025-05-06 05:57:47 --> Language Class Initialized
INFO - 2025-05-06 05:57:47 --> Loader Class Initialized
INFO - 2025-05-06 05:57:47 --> Helper loaded: url_helper
INFO - 2025-05-06 05:57:47 --> Helper loaded: string_helper
INFO - 2025-05-06 05:57:47 --> Helper loaded: form_helper
INFO - 2025-05-06 05:57:47 --> Helper loaded: file_helper
INFO - 2025-05-06 05:57:47 --> Helper loaded: html_helper
INFO - 2025-05-06 05:57:47 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:57:47 --> Controller Class Initialized
INFO - 2025-05-06 13:57:47 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:58:03 --> Config Class Initialized
INFO - 2025-05-06 05:58:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:58:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:58:03 --> Utf8 Class Initialized
INFO - 2025-05-06 05:58:03 --> URI Class Initialized
INFO - 2025-05-06 05:58:03 --> Router Class Initialized
INFO - 2025-05-06 05:58:03 --> Output Class Initialized
INFO - 2025-05-06 05:58:03 --> Security Class Initialized
DEBUG - 2025-05-06 05:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:58:03 --> Input Class Initialized
INFO - 2025-05-06 05:58:03 --> Language Class Initialized
INFO - 2025-05-06 05:58:03 --> Loader Class Initialized
INFO - 2025-05-06 05:58:03 --> Helper loaded: url_helper
INFO - 2025-05-06 05:58:03 --> Helper loaded: string_helper
INFO - 2025-05-06 05:58:03 --> Helper loaded: form_helper
INFO - 2025-05-06 05:58:03 --> Helper loaded: file_helper
INFO - 2025-05-06 05:58:03 --> Helper loaded: html_helper
INFO - 2025-05-06 05:58:03 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:58:03 --> Controller Class Initialized
INFO - 2025-05-06 13:58:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:58:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:58:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:58:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:58:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:58:03 --> Final output sent to browser
DEBUG - 2025-05-06 13:58:03 --> Total execution time: 0.1431
INFO - 2025-05-06 05:58:10 --> Config Class Initialized
INFO - 2025-05-06 05:58:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:58:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:58:10 --> Utf8 Class Initialized
INFO - 2025-05-06 05:58:10 --> URI Class Initialized
INFO - 2025-05-06 05:58:10 --> Router Class Initialized
INFO - 2025-05-06 05:58:10 --> Output Class Initialized
INFO - 2025-05-06 05:58:10 --> Security Class Initialized
DEBUG - 2025-05-06 05:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:58:10 --> Input Class Initialized
INFO - 2025-05-06 05:58:10 --> Language Class Initialized
INFO - 2025-05-06 05:58:10 --> Loader Class Initialized
INFO - 2025-05-06 05:58:10 --> Helper loaded: url_helper
INFO - 2025-05-06 05:58:10 --> Helper loaded: string_helper
INFO - 2025-05-06 05:58:10 --> Helper loaded: form_helper
INFO - 2025-05-06 05:58:10 --> Helper loaded: file_helper
INFO - 2025-05-06 05:58:10 --> Helper loaded: html_helper
INFO - 2025-05-06 05:58:10 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:58:10 --> Controller Class Initialized
INFO - 2025-05-06 13:58:10 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:59:26 --> Config Class Initialized
INFO - 2025-05-06 05:59:26 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:59:26 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:59:26 --> Utf8 Class Initialized
INFO - 2025-05-06 05:59:26 --> URI Class Initialized
INFO - 2025-05-06 05:59:26 --> Router Class Initialized
INFO - 2025-05-06 05:59:26 --> Output Class Initialized
INFO - 2025-05-06 05:59:26 --> Security Class Initialized
DEBUG - 2025-05-06 05:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:59:26 --> Input Class Initialized
INFO - 2025-05-06 05:59:26 --> Language Class Initialized
INFO - 2025-05-06 05:59:26 --> Loader Class Initialized
INFO - 2025-05-06 05:59:26 --> Helper loaded: url_helper
INFO - 2025-05-06 05:59:26 --> Helper loaded: string_helper
INFO - 2025-05-06 05:59:26 --> Helper loaded: form_helper
INFO - 2025-05-06 05:59:26 --> Helper loaded: file_helper
INFO - 2025-05-06 05:59:26 --> Helper loaded: html_helper
INFO - 2025-05-06 05:59:26 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:59:26 --> Controller Class Initialized
INFO - 2025-05-06 13:59:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:59:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:59:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:59:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:59:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:59:26 --> Final output sent to browser
DEBUG - 2025-05-06 13:59:26 --> Total execution time: 0.0839
INFO - 2025-05-06 05:59:27 --> Config Class Initialized
INFO - 2025-05-06 05:59:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:59:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:59:27 --> Utf8 Class Initialized
INFO - 2025-05-06 05:59:27 --> URI Class Initialized
INFO - 2025-05-06 05:59:27 --> Router Class Initialized
INFO - 2025-05-06 05:59:27 --> Output Class Initialized
INFO - 2025-05-06 05:59:27 --> Security Class Initialized
DEBUG - 2025-05-06 05:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:59:27 --> Input Class Initialized
INFO - 2025-05-06 05:59:27 --> Language Class Initialized
INFO - 2025-05-06 05:59:27 --> Loader Class Initialized
INFO - 2025-05-06 05:59:27 --> Helper loaded: url_helper
INFO - 2025-05-06 05:59:27 --> Helper loaded: string_helper
INFO - 2025-05-06 05:59:27 --> Helper loaded: form_helper
INFO - 2025-05-06 05:59:27 --> Helper loaded: file_helper
INFO - 2025-05-06 05:59:27 --> Helper loaded: html_helper
INFO - 2025-05-06 05:59:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:59:27 --> Controller Class Initialized
INFO - 2025-05-06 13:59:27 --> Model "AuctionModel" initialized
INFO - 2025-05-06 05:59:58 --> Config Class Initialized
INFO - 2025-05-06 05:59:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:59:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:59:58 --> Utf8 Class Initialized
INFO - 2025-05-06 05:59:58 --> URI Class Initialized
INFO - 2025-05-06 05:59:58 --> Router Class Initialized
INFO - 2025-05-06 05:59:58 --> Output Class Initialized
INFO - 2025-05-06 05:59:58 --> Security Class Initialized
DEBUG - 2025-05-06 05:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:59:58 --> Input Class Initialized
INFO - 2025-05-06 05:59:58 --> Language Class Initialized
INFO - 2025-05-06 05:59:58 --> Loader Class Initialized
INFO - 2025-05-06 05:59:58 --> Helper loaded: url_helper
INFO - 2025-05-06 05:59:58 --> Helper loaded: string_helper
INFO - 2025-05-06 05:59:58 --> Helper loaded: form_helper
INFO - 2025-05-06 05:59:58 --> Helper loaded: file_helper
INFO - 2025-05-06 05:59:58 --> Helper loaded: html_helper
INFO - 2025-05-06 05:59:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 05:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 05:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 05:59:58 --> Controller Class Initialized
INFO - 2025-05-06 13:59:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:59:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:59:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 13:59:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:59:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:59:58 --> Final output sent to browser
DEBUG - 2025-05-06 13:59:58 --> Total execution time: 0.1278
INFO - 2025-05-06 06:00:00 --> Config Class Initialized
INFO - 2025-05-06 06:00:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:00:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:00:00 --> Utf8 Class Initialized
INFO - 2025-05-06 06:00:00 --> URI Class Initialized
INFO - 2025-05-06 06:00:00 --> Router Class Initialized
INFO - 2025-05-06 06:00:00 --> Output Class Initialized
INFO - 2025-05-06 06:00:00 --> Security Class Initialized
DEBUG - 2025-05-06 06:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:00:00 --> Input Class Initialized
INFO - 2025-05-06 06:00:00 --> Language Class Initialized
INFO - 2025-05-06 06:00:00 --> Loader Class Initialized
INFO - 2025-05-06 06:00:00 --> Helper loaded: url_helper
INFO - 2025-05-06 06:00:00 --> Helper loaded: string_helper
INFO - 2025-05-06 06:00:00 --> Helper loaded: form_helper
INFO - 2025-05-06 06:00:00 --> Helper loaded: file_helper
INFO - 2025-05-06 06:00:00 --> Helper loaded: html_helper
INFO - 2025-05-06 06:00:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:00:00 --> Controller Class Initialized
INFO - 2025-05-06 14:00:00 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:00:26 --> Config Class Initialized
INFO - 2025-05-06 06:00:26 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:00:26 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:00:26 --> Utf8 Class Initialized
INFO - 2025-05-06 06:00:26 --> URI Class Initialized
INFO - 2025-05-06 06:00:26 --> Router Class Initialized
INFO - 2025-05-06 06:00:26 --> Output Class Initialized
INFO - 2025-05-06 06:00:26 --> Security Class Initialized
DEBUG - 2025-05-06 06:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:00:26 --> Input Class Initialized
INFO - 2025-05-06 06:00:26 --> Language Class Initialized
INFO - 2025-05-06 06:00:26 --> Loader Class Initialized
INFO - 2025-05-06 06:00:26 --> Helper loaded: url_helper
INFO - 2025-05-06 06:00:26 --> Helper loaded: string_helper
INFO - 2025-05-06 06:00:26 --> Helper loaded: form_helper
INFO - 2025-05-06 06:00:26 --> Helper loaded: file_helper
INFO - 2025-05-06 06:00:26 --> Helper loaded: html_helper
INFO - 2025-05-06 06:00:26 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:00:26 --> Controller Class Initialized
INFO - 2025-05-06 14:00:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:00:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:00:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:00:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:00:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:00:26 --> Final output sent to browser
DEBUG - 2025-05-06 14:00:26 --> Total execution time: 0.0698
INFO - 2025-05-06 06:00:27 --> Config Class Initialized
INFO - 2025-05-06 06:00:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:00:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:00:27 --> Utf8 Class Initialized
INFO - 2025-05-06 06:00:27 --> URI Class Initialized
INFO - 2025-05-06 06:00:28 --> Router Class Initialized
INFO - 2025-05-06 06:00:28 --> Output Class Initialized
INFO - 2025-05-06 06:00:28 --> Security Class Initialized
DEBUG - 2025-05-06 06:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:00:28 --> Input Class Initialized
INFO - 2025-05-06 06:00:28 --> Language Class Initialized
INFO - 2025-05-06 06:00:28 --> Loader Class Initialized
INFO - 2025-05-06 06:00:28 --> Helper loaded: url_helper
INFO - 2025-05-06 06:00:28 --> Helper loaded: string_helper
INFO - 2025-05-06 06:00:28 --> Helper loaded: form_helper
INFO - 2025-05-06 06:00:28 --> Helper loaded: file_helper
INFO - 2025-05-06 06:00:28 --> Helper loaded: html_helper
INFO - 2025-05-06 06:00:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:00:28 --> Controller Class Initialized
INFO - 2025-05-06 14:00:28 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:02:56 --> Config Class Initialized
INFO - 2025-05-06 06:02:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:02:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:02:56 --> Utf8 Class Initialized
INFO - 2025-05-06 06:02:56 --> URI Class Initialized
INFO - 2025-05-06 06:02:56 --> Router Class Initialized
INFO - 2025-05-06 06:02:56 --> Output Class Initialized
INFO - 2025-05-06 06:02:56 --> Security Class Initialized
DEBUG - 2025-05-06 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:02:56 --> Input Class Initialized
INFO - 2025-05-06 06:02:56 --> Language Class Initialized
INFO - 2025-05-06 06:02:56 --> Loader Class Initialized
INFO - 2025-05-06 06:02:56 --> Helper loaded: url_helper
INFO - 2025-05-06 06:02:56 --> Helper loaded: string_helper
INFO - 2025-05-06 06:02:56 --> Helper loaded: form_helper
INFO - 2025-05-06 06:02:56 --> Helper loaded: file_helper
INFO - 2025-05-06 06:02:56 --> Helper loaded: html_helper
INFO - 2025-05-06 06:02:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:02:56 --> Controller Class Initialized
INFO - 2025-05-06 14:02:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:02:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:02:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:02:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:02:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:02:56 --> Final output sent to browser
DEBUG - 2025-05-06 14:02:56 --> Total execution time: 0.1121
INFO - 2025-05-06 06:02:58 --> Config Class Initialized
INFO - 2025-05-06 06:02:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:02:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:02:58 --> Utf8 Class Initialized
INFO - 2025-05-06 06:02:58 --> URI Class Initialized
INFO - 2025-05-06 06:02:58 --> Router Class Initialized
INFO - 2025-05-06 06:02:58 --> Output Class Initialized
INFO - 2025-05-06 06:02:58 --> Security Class Initialized
DEBUG - 2025-05-06 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:02:58 --> Input Class Initialized
INFO - 2025-05-06 06:02:58 --> Language Class Initialized
INFO - 2025-05-06 06:02:58 --> Loader Class Initialized
INFO - 2025-05-06 06:02:58 --> Helper loaded: url_helper
INFO - 2025-05-06 06:02:58 --> Helper loaded: string_helper
INFO - 2025-05-06 06:02:58 --> Helper loaded: form_helper
INFO - 2025-05-06 06:02:58 --> Helper loaded: file_helper
INFO - 2025-05-06 06:02:58 --> Helper loaded: html_helper
INFO - 2025-05-06 06:02:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:02:58 --> Controller Class Initialized
INFO - 2025-05-06 14:02:58 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:03:54 --> Config Class Initialized
INFO - 2025-05-06 06:03:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:03:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:03:54 --> Utf8 Class Initialized
INFO - 2025-05-06 06:03:54 --> URI Class Initialized
INFO - 2025-05-06 06:03:54 --> Router Class Initialized
INFO - 2025-05-06 06:03:54 --> Output Class Initialized
INFO - 2025-05-06 06:03:54 --> Security Class Initialized
DEBUG - 2025-05-06 06:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:03:54 --> Input Class Initialized
INFO - 2025-05-06 06:03:54 --> Language Class Initialized
INFO - 2025-05-06 06:03:54 --> Loader Class Initialized
INFO - 2025-05-06 06:03:54 --> Helper loaded: url_helper
INFO - 2025-05-06 06:03:54 --> Helper loaded: string_helper
INFO - 2025-05-06 06:03:54 --> Helper loaded: form_helper
INFO - 2025-05-06 06:03:54 --> Helper loaded: file_helper
INFO - 2025-05-06 06:03:54 --> Helper loaded: html_helper
INFO - 2025-05-06 06:03:54 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:03:54 --> Controller Class Initialized
INFO - 2025-05-06 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:03:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:03:54 --> Final output sent to browser
DEBUG - 2025-05-06 14:03:54 --> Total execution time: 0.1269
INFO - 2025-05-06 06:03:56 --> Config Class Initialized
INFO - 2025-05-06 06:03:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:03:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:03:56 --> Utf8 Class Initialized
INFO - 2025-05-06 06:03:56 --> URI Class Initialized
INFO - 2025-05-06 06:03:56 --> Router Class Initialized
INFO - 2025-05-06 06:03:56 --> Output Class Initialized
INFO - 2025-05-06 06:03:56 --> Security Class Initialized
DEBUG - 2025-05-06 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:03:56 --> Input Class Initialized
INFO - 2025-05-06 06:03:56 --> Language Class Initialized
INFO - 2025-05-06 06:03:56 --> Loader Class Initialized
INFO - 2025-05-06 06:03:56 --> Helper loaded: url_helper
INFO - 2025-05-06 06:03:56 --> Helper loaded: string_helper
INFO - 2025-05-06 06:03:56 --> Helper loaded: form_helper
INFO - 2025-05-06 06:03:56 --> Helper loaded: file_helper
INFO - 2025-05-06 06:03:56 --> Helper loaded: html_helper
INFO - 2025-05-06 06:03:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:03:56 --> Controller Class Initialized
INFO - 2025-05-06 14:03:56 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:07:44 --> Config Class Initialized
INFO - 2025-05-06 06:07:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:07:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:07:44 --> Utf8 Class Initialized
INFO - 2025-05-06 06:07:44 --> URI Class Initialized
INFO - 2025-05-06 06:07:44 --> Router Class Initialized
INFO - 2025-05-06 06:07:44 --> Output Class Initialized
INFO - 2025-05-06 06:07:44 --> Security Class Initialized
DEBUG - 2025-05-06 06:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:07:44 --> Input Class Initialized
INFO - 2025-05-06 06:07:44 --> Language Class Initialized
INFO - 2025-05-06 06:07:44 --> Loader Class Initialized
INFO - 2025-05-06 06:07:44 --> Helper loaded: url_helper
INFO - 2025-05-06 06:07:44 --> Helper loaded: string_helper
INFO - 2025-05-06 06:07:44 --> Helper loaded: form_helper
INFO - 2025-05-06 06:07:44 --> Helper loaded: file_helper
INFO - 2025-05-06 06:07:44 --> Helper loaded: html_helper
INFO - 2025-05-06 06:07:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:07:44 --> Controller Class Initialized
INFO - 2025-05-06 14:07:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:07:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:07:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:07:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:07:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:07:44 --> Final output sent to browser
DEBUG - 2025-05-06 14:07:44 --> Total execution time: 0.1185
INFO - 2025-05-06 06:07:45 --> Config Class Initialized
INFO - 2025-05-06 06:07:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:07:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:07:45 --> Utf8 Class Initialized
INFO - 2025-05-06 06:07:45 --> URI Class Initialized
INFO - 2025-05-06 06:07:45 --> Router Class Initialized
INFO - 2025-05-06 06:07:45 --> Output Class Initialized
INFO - 2025-05-06 06:07:45 --> Security Class Initialized
DEBUG - 2025-05-06 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:07:45 --> Input Class Initialized
INFO - 2025-05-06 06:07:45 --> Language Class Initialized
INFO - 2025-05-06 06:07:45 --> Loader Class Initialized
INFO - 2025-05-06 06:07:45 --> Helper loaded: url_helper
INFO - 2025-05-06 06:07:45 --> Helper loaded: string_helper
INFO - 2025-05-06 06:07:45 --> Helper loaded: form_helper
INFO - 2025-05-06 06:07:45 --> Helper loaded: file_helper
INFO - 2025-05-06 06:07:45 --> Helper loaded: html_helper
INFO - 2025-05-06 06:07:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:07:45 --> Controller Class Initialized
INFO - 2025-05-06 14:07:45 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:08:35 --> Config Class Initialized
INFO - 2025-05-06 06:08:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:08:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:08:35 --> Utf8 Class Initialized
INFO - 2025-05-06 06:08:35 --> URI Class Initialized
INFO - 2025-05-06 06:08:35 --> Router Class Initialized
INFO - 2025-05-06 06:08:35 --> Output Class Initialized
INFO - 2025-05-06 06:08:35 --> Security Class Initialized
DEBUG - 2025-05-06 06:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:08:35 --> Input Class Initialized
INFO - 2025-05-06 06:08:35 --> Language Class Initialized
INFO - 2025-05-06 06:08:35 --> Loader Class Initialized
INFO - 2025-05-06 06:08:35 --> Helper loaded: url_helper
INFO - 2025-05-06 06:08:35 --> Helper loaded: string_helper
INFO - 2025-05-06 06:08:35 --> Helper loaded: form_helper
INFO - 2025-05-06 06:08:35 --> Helper loaded: file_helper
INFO - 2025-05-06 06:08:35 --> Helper loaded: html_helper
INFO - 2025-05-06 06:08:35 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:08:35 --> Controller Class Initialized
INFO - 2025-05-06 14:08:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:08:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:08:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:08:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:08:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:08:35 --> Final output sent to browser
DEBUG - 2025-05-06 14:08:35 --> Total execution time: 0.1903
INFO - 2025-05-06 06:08:36 --> Config Class Initialized
INFO - 2025-05-06 06:08:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:08:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:08:36 --> Utf8 Class Initialized
INFO - 2025-05-06 06:08:36 --> URI Class Initialized
INFO - 2025-05-06 06:08:36 --> Router Class Initialized
INFO - 2025-05-06 06:08:36 --> Output Class Initialized
INFO - 2025-05-06 06:08:36 --> Security Class Initialized
DEBUG - 2025-05-06 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:08:36 --> Input Class Initialized
INFO - 2025-05-06 06:08:36 --> Language Class Initialized
INFO - 2025-05-06 06:08:36 --> Loader Class Initialized
INFO - 2025-05-06 06:08:36 --> Helper loaded: url_helper
INFO - 2025-05-06 06:08:36 --> Helper loaded: string_helper
INFO - 2025-05-06 06:08:36 --> Helper loaded: form_helper
INFO - 2025-05-06 06:08:36 --> Helper loaded: file_helper
INFO - 2025-05-06 06:08:36 --> Helper loaded: html_helper
INFO - 2025-05-06 06:08:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:08:36 --> Controller Class Initialized
INFO - 2025-05-06 14:08:36 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:09:15 --> Config Class Initialized
INFO - 2025-05-06 06:09:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:09:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:09:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:09:15 --> URI Class Initialized
INFO - 2025-05-06 06:09:15 --> Router Class Initialized
INFO - 2025-05-06 06:09:15 --> Output Class Initialized
INFO - 2025-05-06 06:09:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:09:15 --> Input Class Initialized
INFO - 2025-05-06 06:09:15 --> Language Class Initialized
INFO - 2025-05-06 06:09:15 --> Loader Class Initialized
INFO - 2025-05-06 06:09:15 --> Helper loaded: url_helper
INFO - 2025-05-06 06:09:15 --> Helper loaded: string_helper
INFO - 2025-05-06 06:09:15 --> Helper loaded: form_helper
INFO - 2025-05-06 06:09:15 --> Helper loaded: file_helper
INFO - 2025-05-06 06:09:15 --> Helper loaded: html_helper
INFO - 2025-05-06 06:09:15 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:09:15 --> Controller Class Initialized
INFO - 2025-05-06 14:09:15 --> Model "AuctionModel" initialized
INFO - 2025-05-06 14:09:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:09:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:09:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 14:09:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:09:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:09:15 --> Final output sent to browser
DEBUG - 2025-05-06 14:09:15 --> Total execution time: 0.1862
INFO - 2025-05-06 06:09:16 --> Config Class Initialized
INFO - 2025-05-06 06:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:09:16 --> Utf8 Class Initialized
INFO - 2025-05-06 06:09:16 --> URI Class Initialized
INFO - 2025-05-06 06:09:16 --> Router Class Initialized
INFO - 2025-05-06 06:09:16 --> Output Class Initialized
INFO - 2025-05-06 06:09:16 --> Security Class Initialized
DEBUG - 2025-05-06 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:09:16 --> Input Class Initialized
INFO - 2025-05-06 06:09:16 --> Language Class Initialized
INFO - 2025-05-06 06:09:16 --> Loader Class Initialized
INFO - 2025-05-06 06:09:16 --> Helper loaded: url_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: string_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: form_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: file_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: html_helper
INFO - 2025-05-06 06:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:09:16 --> Controller Class Initialized
INFO - 2025-05-06 06:09:16 --> Config Class Initialized
INFO - 2025-05-06 06:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:09:16 --> Utf8 Class Initialized
INFO - 2025-05-06 06:09:16 --> URI Class Initialized
INFO - 2025-05-06 06:09:16 --> Router Class Initialized
INFO - 2025-05-06 06:09:16 --> Output Class Initialized
INFO - 2025-05-06 06:09:16 --> Security Class Initialized
DEBUG - 2025-05-06 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:09:16 --> Input Class Initialized
INFO - 2025-05-06 06:09:16 --> Language Class Initialized
INFO - 2025-05-06 06:09:16 --> Loader Class Initialized
INFO - 2025-05-06 06:09:16 --> Helper loaded: url_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: string_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: form_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: file_helper
INFO - 2025-05-06 06:09:16 --> Helper loaded: html_helper
INFO - 2025-05-06 06:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:09:16 --> Controller Class Initialized
INFO - 2025-05-06 14:09:16 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:10:34 --> Config Class Initialized
INFO - 2025-05-06 06:10:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:35 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:35 --> URI Class Initialized
DEBUG - 2025-05-06 06:10:35 --> No URI present. Default controller set.
INFO - 2025-05-06 06:10:35 --> Router Class Initialized
INFO - 2025-05-06 06:10:35 --> Output Class Initialized
INFO - 2025-05-06 06:10:35 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:35 --> Input Class Initialized
INFO - 2025-05-06 06:10:35 --> Language Class Initialized
INFO - 2025-05-06 06:10:35 --> Loader Class Initialized
INFO - 2025-05-06 06:10:35 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:35 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:35 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:35 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:35 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:35 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:35 --> Controller Class Initialized
INFO - 2025-05-06 06:10:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:10:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:10:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 06:10:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:10:35 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:10:35 --> Final output sent to browser
DEBUG - 2025-05-06 06:10:35 --> Total execution time: 0.1078
INFO - 2025-05-06 06:10:37 --> Config Class Initialized
INFO - 2025-05-06 06:10:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:37 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:37 --> URI Class Initialized
INFO - 2025-05-06 06:10:37 --> Router Class Initialized
INFO - 2025-05-06 06:10:37 --> Output Class Initialized
INFO - 2025-05-06 06:10:37 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:37 --> Input Class Initialized
INFO - 2025-05-06 06:10:37 --> Language Class Initialized
INFO - 2025-05-06 06:10:37 --> Loader Class Initialized
INFO - 2025-05-06 06:10:37 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:37 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:37 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:37 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:37 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:37 --> Controller Class Initialized
INFO - 2025-05-06 14:10:37 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:10:41 --> Config Class Initialized
INFO - 2025-05-06 06:10:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:41 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:41 --> URI Class Initialized
INFO - 2025-05-06 06:10:41 --> Router Class Initialized
INFO - 2025-05-06 06:10:41 --> Output Class Initialized
INFO - 2025-05-06 06:10:41 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:41 --> Input Class Initialized
INFO - 2025-05-06 06:10:41 --> Language Class Initialized
INFO - 2025-05-06 06:10:41 --> Loader Class Initialized
INFO - 2025-05-06 06:10:41 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:41 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:41 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:41 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:41 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:41 --> Controller Class Initialized
INFO - 2025-05-06 14:10:41 --> Model "AuctionModel" initialized
INFO - 2025-05-06 14:10:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:10:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:10:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 14:10:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:10:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:10:41 --> Final output sent to browser
DEBUG - 2025-05-06 14:10:41 --> Total execution time: 0.1154
INFO - 2025-05-06 06:10:42 --> Config Class Initialized
INFO - 2025-05-06 06:10:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:42 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:42 --> URI Class Initialized
INFO - 2025-05-06 06:10:42 --> Router Class Initialized
INFO - 2025-05-06 06:10:42 --> Output Class Initialized
INFO - 2025-05-06 06:10:42 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:42 --> Input Class Initialized
INFO - 2025-05-06 06:10:42 --> Language Class Initialized
INFO - 2025-05-06 06:10:42 --> Loader Class Initialized
INFO - 2025-05-06 06:10:42 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:42 --> Controller Class Initialized
INFO - 2025-05-06 06:10:42 --> Config Class Initialized
INFO - 2025-05-06 06:10:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:42 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:42 --> URI Class Initialized
INFO - 2025-05-06 06:10:42 --> Router Class Initialized
INFO - 2025-05-06 06:10:42 --> Output Class Initialized
INFO - 2025-05-06 06:10:42 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:42 --> Input Class Initialized
INFO - 2025-05-06 06:10:42 --> Language Class Initialized
INFO - 2025-05-06 06:10:42 --> Loader Class Initialized
INFO - 2025-05-06 06:10:42 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:42 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:42 --> Controller Class Initialized
INFO - 2025-05-06 14:10:42 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:10:47 --> Config Class Initialized
INFO - 2025-05-06 06:10:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:47 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:47 --> URI Class Initialized
INFO - 2025-05-06 06:10:47 --> Router Class Initialized
INFO - 2025-05-06 06:10:47 --> Output Class Initialized
INFO - 2025-05-06 06:10:47 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:47 --> Input Class Initialized
INFO - 2025-05-06 06:10:47 --> Language Class Initialized
INFO - 2025-05-06 06:10:47 --> Loader Class Initialized
INFO - 2025-05-06 06:10:47 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:47 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:47 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:47 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:47 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:47 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:48 --> Controller Class Initialized
INFO - 2025-05-06 14:10:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:10:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:10:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:10:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:10:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:10:48 --> Final output sent to browser
DEBUG - 2025-05-06 14:10:48 --> Total execution time: 0.1428
INFO - 2025-05-06 06:10:49 --> Config Class Initialized
INFO - 2025-05-06 06:10:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:10:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:10:49 --> Utf8 Class Initialized
INFO - 2025-05-06 06:10:49 --> URI Class Initialized
INFO - 2025-05-06 06:10:49 --> Router Class Initialized
INFO - 2025-05-06 06:10:49 --> Output Class Initialized
INFO - 2025-05-06 06:10:49 --> Security Class Initialized
DEBUG - 2025-05-06 06:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:10:49 --> Input Class Initialized
INFO - 2025-05-06 06:10:49 --> Language Class Initialized
INFO - 2025-05-06 06:10:49 --> Loader Class Initialized
INFO - 2025-05-06 06:10:49 --> Helper loaded: url_helper
INFO - 2025-05-06 06:10:49 --> Helper loaded: string_helper
INFO - 2025-05-06 06:10:49 --> Helper loaded: form_helper
INFO - 2025-05-06 06:10:49 --> Helper loaded: file_helper
INFO - 2025-05-06 06:10:49 --> Helper loaded: html_helper
INFO - 2025-05-06 06:10:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:10:49 --> Controller Class Initialized
INFO - 2025-05-06 14:10:49 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:11:00 --> Config Class Initialized
INFO - 2025-05-06 06:11:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:11:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:11:00 --> Utf8 Class Initialized
INFO - 2025-05-06 06:11:00 --> URI Class Initialized
INFO - 2025-05-06 06:11:00 --> Router Class Initialized
INFO - 2025-05-06 06:11:00 --> Output Class Initialized
INFO - 2025-05-06 06:11:00 --> Security Class Initialized
DEBUG - 2025-05-06 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:11:00 --> Input Class Initialized
INFO - 2025-05-06 06:11:00 --> Language Class Initialized
INFO - 2025-05-06 06:11:00 --> Loader Class Initialized
INFO - 2025-05-06 06:11:00 --> Helper loaded: url_helper
INFO - 2025-05-06 06:11:00 --> Helper loaded: string_helper
INFO - 2025-05-06 06:11:00 --> Helper loaded: form_helper
INFO - 2025-05-06 06:11:00 --> Helper loaded: file_helper
INFO - 2025-05-06 06:11:00 --> Helper loaded: html_helper
INFO - 2025-05-06 06:11:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:11:00 --> Controller Class Initialized
INFO - 2025-05-06 14:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:11:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:11:00 --> Final output sent to browser
DEBUG - 2025-05-06 14:11:00 --> Total execution time: 0.1231
INFO - 2025-05-06 06:11:02 --> Config Class Initialized
INFO - 2025-05-06 06:11:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:11:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:11:02 --> Utf8 Class Initialized
INFO - 2025-05-06 06:11:02 --> URI Class Initialized
INFO - 2025-05-06 06:11:02 --> Router Class Initialized
INFO - 2025-05-06 06:11:02 --> Output Class Initialized
INFO - 2025-05-06 06:11:02 --> Security Class Initialized
DEBUG - 2025-05-06 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:11:02 --> Input Class Initialized
INFO - 2025-05-06 06:11:02 --> Language Class Initialized
INFO - 2025-05-06 06:11:02 --> Loader Class Initialized
INFO - 2025-05-06 06:11:02 --> Helper loaded: url_helper
INFO - 2025-05-06 06:11:02 --> Helper loaded: string_helper
INFO - 2025-05-06 06:11:02 --> Helper loaded: form_helper
INFO - 2025-05-06 06:11:02 --> Helper loaded: file_helper
INFO - 2025-05-06 06:11:02 --> Helper loaded: html_helper
INFO - 2025-05-06 06:11:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:11:02 --> Controller Class Initialized
INFO - 2025-05-06 14:11:02 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:11:30 --> Config Class Initialized
INFO - 2025-05-06 06:11:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:11:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:11:30 --> Utf8 Class Initialized
INFO - 2025-05-06 06:11:30 --> URI Class Initialized
INFO - 2025-05-06 06:11:30 --> Router Class Initialized
INFO - 2025-05-06 06:11:30 --> Output Class Initialized
INFO - 2025-05-06 06:11:30 --> Security Class Initialized
DEBUG - 2025-05-06 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:11:30 --> Input Class Initialized
INFO - 2025-05-06 06:11:30 --> Language Class Initialized
INFO - 2025-05-06 06:11:31 --> Loader Class Initialized
INFO - 2025-05-06 06:11:31 --> Helper loaded: url_helper
INFO - 2025-05-06 06:11:31 --> Helper loaded: string_helper
INFO - 2025-05-06 06:11:31 --> Helper loaded: form_helper
INFO - 2025-05-06 06:11:31 --> Helper loaded: file_helper
INFO - 2025-05-06 06:11:31 --> Helper loaded: html_helper
INFO - 2025-05-06 06:11:31 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:11:31 --> Controller Class Initialized
INFO - 2025-05-06 14:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:11:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:11:31 --> Final output sent to browser
DEBUG - 2025-05-06 14:11:31 --> Total execution time: 0.1434
INFO - 2025-05-06 06:11:32 --> Config Class Initialized
INFO - 2025-05-06 06:11:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:11:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:11:32 --> Utf8 Class Initialized
INFO - 2025-05-06 06:11:32 --> URI Class Initialized
INFO - 2025-05-06 06:11:32 --> Router Class Initialized
INFO - 2025-05-06 06:11:32 --> Output Class Initialized
INFO - 2025-05-06 06:11:32 --> Security Class Initialized
DEBUG - 2025-05-06 06:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:11:32 --> Input Class Initialized
INFO - 2025-05-06 06:11:32 --> Language Class Initialized
INFO - 2025-05-06 06:11:32 --> Loader Class Initialized
INFO - 2025-05-06 06:11:32 --> Helper loaded: url_helper
INFO - 2025-05-06 06:11:32 --> Helper loaded: string_helper
INFO - 2025-05-06 06:11:32 --> Helper loaded: form_helper
INFO - 2025-05-06 06:11:32 --> Helper loaded: file_helper
INFO - 2025-05-06 06:11:32 --> Helper loaded: html_helper
INFO - 2025-05-06 06:11:32 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:11:32 --> Controller Class Initialized
INFO - 2025-05-06 14:11:32 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:27:05 --> Config Class Initialized
INFO - 2025-05-06 06:27:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:27:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:27:05 --> Utf8 Class Initialized
INFO - 2025-05-06 06:27:05 --> URI Class Initialized
INFO - 2025-05-06 06:27:05 --> Router Class Initialized
INFO - 2025-05-06 06:27:05 --> Output Class Initialized
INFO - 2025-05-06 06:27:05 --> Security Class Initialized
DEBUG - 2025-05-06 06:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:27:05 --> Input Class Initialized
INFO - 2025-05-06 06:27:05 --> Language Class Initialized
INFO - 2025-05-06 06:27:05 --> Loader Class Initialized
INFO - 2025-05-06 06:27:05 --> Helper loaded: url_helper
INFO - 2025-05-06 06:27:05 --> Helper loaded: string_helper
INFO - 2025-05-06 06:27:05 --> Helper loaded: form_helper
INFO - 2025-05-06 06:27:05 --> Helper loaded: file_helper
INFO - 2025-05-06 06:27:05 --> Helper loaded: html_helper
INFO - 2025-05-06 06:27:05 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:27:05 --> Controller Class Initialized
INFO - 2025-05-06 14:27:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:27:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:27:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:27:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:27:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:27:05 --> Final output sent to browser
DEBUG - 2025-05-06 14:27:05 --> Total execution time: 0.2533
INFO - 2025-05-06 06:27:07 --> Config Class Initialized
INFO - 2025-05-06 06:27:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:27:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:27:07 --> Utf8 Class Initialized
INFO - 2025-05-06 06:27:07 --> URI Class Initialized
INFO - 2025-05-06 06:27:07 --> Router Class Initialized
INFO - 2025-05-06 06:27:07 --> Output Class Initialized
INFO - 2025-05-06 06:27:07 --> Security Class Initialized
DEBUG - 2025-05-06 06:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:27:07 --> Input Class Initialized
INFO - 2025-05-06 06:27:07 --> Language Class Initialized
INFO - 2025-05-06 06:27:07 --> Loader Class Initialized
INFO - 2025-05-06 06:27:07 --> Helper loaded: url_helper
INFO - 2025-05-06 06:27:07 --> Helper loaded: string_helper
INFO - 2025-05-06 06:27:07 --> Helper loaded: form_helper
INFO - 2025-05-06 06:27:07 --> Helper loaded: file_helper
INFO - 2025-05-06 06:27:07 --> Helper loaded: html_helper
INFO - 2025-05-06 06:27:07 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:27:07 --> Controller Class Initialized
INFO - 2025-05-06 14:27:07 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:27:29 --> Config Class Initialized
INFO - 2025-05-06 06:27:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:27:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:27:29 --> Utf8 Class Initialized
INFO - 2025-05-06 06:27:29 --> URI Class Initialized
INFO - 2025-05-06 06:27:29 --> Router Class Initialized
INFO - 2025-05-06 06:27:29 --> Output Class Initialized
INFO - 2025-05-06 06:27:29 --> Security Class Initialized
DEBUG - 2025-05-06 06:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:27:29 --> Input Class Initialized
INFO - 2025-05-06 06:27:29 --> Language Class Initialized
INFO - 2025-05-06 06:27:29 --> Loader Class Initialized
INFO - 2025-05-06 06:27:29 --> Helper loaded: url_helper
INFO - 2025-05-06 06:27:29 --> Helper loaded: string_helper
INFO - 2025-05-06 06:27:29 --> Helper loaded: form_helper
INFO - 2025-05-06 06:27:29 --> Helper loaded: file_helper
INFO - 2025-05-06 06:27:29 --> Helper loaded: html_helper
INFO - 2025-05-06 06:27:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:27:29 --> Controller Class Initialized
INFO - 2025-05-06 14:27:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:27:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:27:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:27:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:27:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:27:29 --> Final output sent to browser
DEBUG - 2025-05-06 14:27:29 --> Total execution time: 0.2578
INFO - 2025-05-06 06:27:32 --> Config Class Initialized
INFO - 2025-05-06 06:27:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:27:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:27:32 --> Utf8 Class Initialized
INFO - 2025-05-06 06:27:32 --> URI Class Initialized
INFO - 2025-05-06 06:27:32 --> Router Class Initialized
INFO - 2025-05-06 06:27:32 --> Output Class Initialized
INFO - 2025-05-06 06:27:32 --> Security Class Initialized
DEBUG - 2025-05-06 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:27:32 --> Input Class Initialized
INFO - 2025-05-06 06:27:32 --> Language Class Initialized
INFO - 2025-05-06 06:27:32 --> Loader Class Initialized
INFO - 2025-05-06 06:27:32 --> Helper loaded: url_helper
INFO - 2025-05-06 06:27:32 --> Helper loaded: string_helper
INFO - 2025-05-06 06:27:32 --> Helper loaded: form_helper
INFO - 2025-05-06 06:27:32 --> Helper loaded: file_helper
INFO - 2025-05-06 06:27:32 --> Helper loaded: html_helper
INFO - 2025-05-06 06:27:32 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:27:32 --> Controller Class Initialized
INFO - 2025-05-06 14:27:32 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:28:20 --> Config Class Initialized
INFO - 2025-05-06 06:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:28:20 --> Utf8 Class Initialized
INFO - 2025-05-06 06:28:20 --> URI Class Initialized
INFO - 2025-05-06 06:28:20 --> Router Class Initialized
INFO - 2025-05-06 06:28:20 --> Output Class Initialized
INFO - 2025-05-06 06:28:20 --> Security Class Initialized
DEBUG - 2025-05-06 06:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:28:20 --> Input Class Initialized
INFO - 2025-05-06 06:28:20 --> Language Class Initialized
INFO - 2025-05-06 06:28:20 --> Loader Class Initialized
INFO - 2025-05-06 06:28:20 --> Helper loaded: url_helper
INFO - 2025-05-06 06:28:20 --> Helper loaded: string_helper
INFO - 2025-05-06 06:28:20 --> Helper loaded: form_helper
INFO - 2025-05-06 06:28:21 --> Helper loaded: file_helper
INFO - 2025-05-06 06:28:21 --> Helper loaded: html_helper
INFO - 2025-05-06 06:28:21 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:28:21 --> Controller Class Initialized
INFO - 2025-05-06 14:28:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:28:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:28:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:28:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:28:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:28:21 --> Final output sent to browser
DEBUG - 2025-05-06 14:28:21 --> Total execution time: 0.1539
INFO - 2025-05-06 06:28:22 --> Config Class Initialized
INFO - 2025-05-06 06:28:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:28:22 --> Utf8 Class Initialized
INFO - 2025-05-06 06:28:22 --> URI Class Initialized
INFO - 2025-05-06 06:28:22 --> Router Class Initialized
INFO - 2025-05-06 06:28:22 --> Output Class Initialized
INFO - 2025-05-06 06:28:22 --> Security Class Initialized
DEBUG - 2025-05-06 06:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:28:22 --> Input Class Initialized
INFO - 2025-05-06 06:28:22 --> Language Class Initialized
INFO - 2025-05-06 06:28:22 --> Loader Class Initialized
INFO - 2025-05-06 06:28:22 --> Helper loaded: url_helper
INFO - 2025-05-06 06:28:22 --> Helper loaded: string_helper
INFO - 2025-05-06 06:28:22 --> Helper loaded: form_helper
INFO - 2025-05-06 06:28:22 --> Helper loaded: file_helper
INFO - 2025-05-06 06:28:22 --> Helper loaded: html_helper
INFO - 2025-05-06 06:28:22 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:28:22 --> Controller Class Initialized
INFO - 2025-05-06 14:28:22 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:28:27 --> Config Class Initialized
INFO - 2025-05-06 06:28:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:28:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:28:27 --> Utf8 Class Initialized
INFO - 2025-05-06 06:28:27 --> URI Class Initialized
INFO - 2025-05-06 06:28:27 --> Router Class Initialized
INFO - 2025-05-06 06:28:27 --> Output Class Initialized
INFO - 2025-05-06 06:28:27 --> Security Class Initialized
DEBUG - 2025-05-06 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:28:27 --> Input Class Initialized
INFO - 2025-05-06 06:28:27 --> Language Class Initialized
INFO - 2025-05-06 06:28:27 --> Loader Class Initialized
INFO - 2025-05-06 06:28:27 --> Helper loaded: url_helper
INFO - 2025-05-06 06:28:27 --> Helper loaded: string_helper
INFO - 2025-05-06 06:28:27 --> Helper loaded: form_helper
INFO - 2025-05-06 06:28:27 --> Helper loaded: file_helper
INFO - 2025-05-06 06:28:27 --> Helper loaded: html_helper
INFO - 2025-05-06 06:28:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:28:27 --> Controller Class Initialized
INFO - 2025-05-06 14:28:27 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:28:40 --> Config Class Initialized
INFO - 2025-05-06 06:28:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:28:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:28:40 --> Utf8 Class Initialized
INFO - 2025-05-06 06:28:40 --> URI Class Initialized
INFO - 2025-05-06 06:28:40 --> Router Class Initialized
INFO - 2025-05-06 06:28:40 --> Output Class Initialized
INFO - 2025-05-06 06:28:40 --> Security Class Initialized
DEBUG - 2025-05-06 06:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:28:40 --> Input Class Initialized
INFO - 2025-05-06 06:28:40 --> Language Class Initialized
INFO - 2025-05-06 06:28:40 --> Loader Class Initialized
INFO - 2025-05-06 06:28:40 --> Helper loaded: url_helper
INFO - 2025-05-06 06:28:40 --> Helper loaded: string_helper
INFO - 2025-05-06 06:28:40 --> Helper loaded: form_helper
INFO - 2025-05-06 06:28:40 --> Helper loaded: file_helper
INFO - 2025-05-06 06:28:40 --> Helper loaded: html_helper
INFO - 2025-05-06 06:28:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:28:40 --> Controller Class Initialized
INFO - 2025-05-06 14:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:28:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:28:40 --> Final output sent to browser
DEBUG - 2025-05-06 14:28:40 --> Total execution time: 0.1350
INFO - 2025-05-06 06:28:41 --> Config Class Initialized
INFO - 2025-05-06 06:28:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:28:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:28:41 --> Utf8 Class Initialized
INFO - 2025-05-06 06:28:41 --> URI Class Initialized
INFO - 2025-05-06 06:28:41 --> Router Class Initialized
INFO - 2025-05-06 06:28:41 --> Output Class Initialized
INFO - 2025-05-06 06:28:41 --> Security Class Initialized
DEBUG - 2025-05-06 06:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:28:41 --> Input Class Initialized
INFO - 2025-05-06 06:28:41 --> Language Class Initialized
INFO - 2025-05-06 06:28:41 --> Loader Class Initialized
INFO - 2025-05-06 06:28:41 --> Helper loaded: url_helper
INFO - 2025-05-06 06:28:41 --> Helper loaded: string_helper
INFO - 2025-05-06 06:28:41 --> Helper loaded: form_helper
INFO - 2025-05-06 06:28:41 --> Helper loaded: file_helper
INFO - 2025-05-06 06:28:41 --> Helper loaded: html_helper
INFO - 2025-05-06 06:28:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:28:41 --> Controller Class Initialized
INFO - 2025-05-06 14:28:41 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:29:15 --> Config Class Initialized
INFO - 2025-05-06 06:29:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:29:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:29:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:29:15 --> URI Class Initialized
INFO - 2025-05-06 06:29:15 --> Router Class Initialized
INFO - 2025-05-06 06:29:15 --> Output Class Initialized
INFO - 2025-05-06 06:29:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:29:15 --> Input Class Initialized
INFO - 2025-05-06 06:29:15 --> Language Class Initialized
INFO - 2025-05-06 06:29:15 --> Loader Class Initialized
INFO - 2025-05-06 06:29:15 --> Helper loaded: url_helper
INFO - 2025-05-06 06:29:15 --> Helper loaded: string_helper
INFO - 2025-05-06 06:29:15 --> Helper loaded: form_helper
INFO - 2025-05-06 06:29:15 --> Helper loaded: file_helper
INFO - 2025-05-06 06:29:15 --> Helper loaded: html_helper
INFO - 2025-05-06 06:29:15 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:29:16 --> Controller Class Initialized
INFO - 2025-05-06 14:29:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:29:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:29:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:29:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:29:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:29:16 --> Final output sent to browser
DEBUG - 2025-05-06 14:29:16 --> Total execution time: 0.1557
INFO - 2025-05-06 06:29:17 --> Config Class Initialized
INFO - 2025-05-06 06:29:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:29:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:29:17 --> Utf8 Class Initialized
INFO - 2025-05-06 06:29:17 --> URI Class Initialized
INFO - 2025-05-06 06:29:17 --> Router Class Initialized
INFO - 2025-05-06 06:29:17 --> Output Class Initialized
INFO - 2025-05-06 06:29:17 --> Security Class Initialized
DEBUG - 2025-05-06 06:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:29:17 --> Input Class Initialized
INFO - 2025-05-06 06:29:17 --> Language Class Initialized
INFO - 2025-05-06 06:29:17 --> Loader Class Initialized
INFO - 2025-05-06 06:29:17 --> Helper loaded: url_helper
INFO - 2025-05-06 06:29:17 --> Helper loaded: string_helper
INFO - 2025-05-06 06:29:17 --> Helper loaded: form_helper
INFO - 2025-05-06 06:29:17 --> Helper loaded: file_helper
INFO - 2025-05-06 06:29:17 --> Helper loaded: html_helper
INFO - 2025-05-06 06:29:17 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:29:17 --> Controller Class Initialized
INFO - 2025-05-06 14:29:17 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:33:58 --> Config Class Initialized
INFO - 2025-05-06 06:33:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:33:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:33:58 --> Utf8 Class Initialized
INFO - 2025-05-06 06:33:58 --> URI Class Initialized
INFO - 2025-05-06 06:33:58 --> Router Class Initialized
INFO - 2025-05-06 06:33:58 --> Output Class Initialized
INFO - 2025-05-06 06:33:58 --> Security Class Initialized
DEBUG - 2025-05-06 06:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:33:58 --> Input Class Initialized
INFO - 2025-05-06 06:33:58 --> Language Class Initialized
INFO - 2025-05-06 06:33:58 --> Loader Class Initialized
INFO - 2025-05-06 06:33:58 --> Helper loaded: url_helper
INFO - 2025-05-06 06:33:58 --> Helper loaded: string_helper
INFO - 2025-05-06 06:33:58 --> Helper loaded: form_helper
INFO - 2025-05-06 06:33:58 --> Helper loaded: file_helper
INFO - 2025-05-06 06:33:58 --> Helper loaded: html_helper
INFO - 2025-05-06 06:33:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:33:58 --> Controller Class Initialized
INFO - 2025-05-06 14:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:33:58 --> Final output sent to browser
DEBUG - 2025-05-06 14:33:58 --> Total execution time: 0.2814
INFO - 2025-05-06 06:34:00 --> Config Class Initialized
INFO - 2025-05-06 06:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:34:00 --> Utf8 Class Initialized
INFO - 2025-05-06 06:34:00 --> URI Class Initialized
INFO - 2025-05-06 06:34:00 --> Router Class Initialized
INFO - 2025-05-06 06:34:00 --> Output Class Initialized
INFO - 2025-05-06 06:34:00 --> Security Class Initialized
DEBUG - 2025-05-06 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:34:00 --> Input Class Initialized
INFO - 2025-05-06 06:34:00 --> Language Class Initialized
INFO - 2025-05-06 06:34:00 --> Loader Class Initialized
INFO - 2025-05-06 06:34:00 --> Helper loaded: url_helper
INFO - 2025-05-06 06:34:00 --> Helper loaded: string_helper
INFO - 2025-05-06 06:34:00 --> Helper loaded: form_helper
INFO - 2025-05-06 06:34:00 --> Helper loaded: file_helper
INFO - 2025-05-06 06:34:00 --> Helper loaded: html_helper
INFO - 2025-05-06 06:34:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:34:00 --> Controller Class Initialized
INFO - 2025-05-06 14:34:00 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:35:09 --> Config Class Initialized
INFO - 2025-05-06 06:35:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:35:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:35:09 --> Utf8 Class Initialized
INFO - 2025-05-06 06:35:09 --> URI Class Initialized
INFO - 2025-05-06 06:35:09 --> Router Class Initialized
INFO - 2025-05-06 06:35:09 --> Output Class Initialized
INFO - 2025-05-06 06:35:09 --> Security Class Initialized
DEBUG - 2025-05-06 06:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:35:09 --> Input Class Initialized
INFO - 2025-05-06 06:35:09 --> Language Class Initialized
INFO - 2025-05-06 06:35:09 --> Loader Class Initialized
INFO - 2025-05-06 06:35:09 --> Helper loaded: url_helper
INFO - 2025-05-06 06:35:09 --> Helper loaded: string_helper
INFO - 2025-05-06 06:35:09 --> Helper loaded: form_helper
INFO - 2025-05-06 06:35:09 --> Helper loaded: file_helper
INFO - 2025-05-06 06:35:09 --> Helper loaded: html_helper
INFO - 2025-05-06 06:35:09 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:35:09 --> Controller Class Initialized
INFO - 2025-05-06 14:35:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:35:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:35:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:35:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:35:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:35:09 --> Final output sent to browser
DEBUG - 2025-05-06 14:35:09 --> Total execution time: 0.3540
INFO - 2025-05-06 06:35:10 --> Config Class Initialized
INFO - 2025-05-06 06:35:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:35:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:35:10 --> Utf8 Class Initialized
INFO - 2025-05-06 06:35:10 --> URI Class Initialized
INFO - 2025-05-06 06:35:10 --> Router Class Initialized
INFO - 2025-05-06 06:35:10 --> Output Class Initialized
INFO - 2025-05-06 06:35:10 --> Security Class Initialized
DEBUG - 2025-05-06 06:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:35:10 --> Input Class Initialized
INFO - 2025-05-06 06:35:10 --> Language Class Initialized
INFO - 2025-05-06 06:35:10 --> Loader Class Initialized
INFO - 2025-05-06 06:35:10 --> Helper loaded: url_helper
INFO - 2025-05-06 06:35:10 --> Helper loaded: string_helper
INFO - 2025-05-06 06:35:10 --> Helper loaded: form_helper
INFO - 2025-05-06 06:35:10 --> Helper loaded: file_helper
INFO - 2025-05-06 06:35:10 --> Helper loaded: html_helper
INFO - 2025-05-06 06:35:10 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:35:10 --> Controller Class Initialized
INFO - 2025-05-06 14:35:10 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:36:12 --> Config Class Initialized
INFO - 2025-05-06 06:36:12 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:12 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:12 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:12 --> URI Class Initialized
INFO - 2025-05-06 06:36:12 --> Router Class Initialized
INFO - 2025-05-06 06:36:12 --> Output Class Initialized
INFO - 2025-05-06 06:36:12 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:12 --> Input Class Initialized
INFO - 2025-05-06 06:36:12 --> Language Class Initialized
INFO - 2025-05-06 06:36:12 --> Loader Class Initialized
INFO - 2025-05-06 06:36:12 --> Helper loaded: url_helper
INFO - 2025-05-06 06:36:12 --> Helper loaded: string_helper
INFO - 2025-05-06 06:36:12 --> Helper loaded: form_helper
INFO - 2025-05-06 06:36:12 --> Helper loaded: file_helper
INFO - 2025-05-06 06:36:12 --> Helper loaded: html_helper
INFO - 2025-05-06 06:36:12 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:12 --> Controller Class Initialized
INFO - 2025-05-06 14:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:36:12 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:36:12 --> Final output sent to browser
DEBUG - 2025-05-06 14:36:12 --> Total execution time: 0.1321
INFO - 2025-05-06 06:36:15 --> Config Class Initialized
INFO - 2025-05-06 06:36:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:15 --> URI Class Initialized
INFO - 2025-05-06 06:36:15 --> Router Class Initialized
INFO - 2025-05-06 06:36:15 --> Output Class Initialized
INFO - 2025-05-06 06:36:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:15 --> Input Class Initialized
INFO - 2025-05-06 06:36:15 --> Language Class Initialized
DEBUG - 2025-05-06 06:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:15 --> Controller Class Initialized
INFO - 2025-05-06 14:36:15 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:36:23 --> Config Class Initialized
INFO - 2025-05-06 06:36:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:24 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:24 --> URI Class Initialized
INFO - 2025-05-06 06:36:24 --> Router Class Initialized
INFO - 2025-05-06 06:36:24 --> Output Class Initialized
INFO - 2025-05-06 06:36:24 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:24 --> Input Class Initialized
INFO - 2025-05-06 06:36:24 --> Language Class Initialized
INFO - 2025-05-06 06:36:24 --> Loader Class Initialized
INFO - 2025-05-06 06:36:24 --> Helper loaded: url_helper
INFO - 2025-05-06 06:36:24 --> Helper loaded: string_helper
INFO - 2025-05-06 06:36:24 --> Helper loaded: form_helper
INFO - 2025-05-06 06:36:24 --> Helper loaded: file_helper
INFO - 2025-05-06 06:36:24 --> Helper loaded: html_helper
INFO - 2025-05-06 06:36:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:24 --> Controller Class Initialized
INFO - 2025-05-06 14:36:24 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:36:33 --> Config Class Initialized
INFO - 2025-05-06 06:36:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:33 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:33 --> URI Class Initialized
INFO - 2025-05-06 06:36:33 --> Router Class Initialized
INFO - 2025-05-06 06:36:33 --> Output Class Initialized
INFO - 2025-05-06 06:36:33 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:33 --> Input Class Initialized
INFO - 2025-05-06 06:36:33 --> Language Class Initialized
INFO - 2025-05-06 06:36:33 --> Loader Class Initialized
INFO - 2025-05-06 06:36:33 --> Helper loaded: url_helper
INFO - 2025-05-06 06:36:33 --> Helper loaded: string_helper
INFO - 2025-05-06 06:36:33 --> Helper loaded: form_helper
INFO - 2025-05-06 06:36:33 --> Helper loaded: file_helper
INFO - 2025-05-06 06:36:33 --> Helper loaded: html_helper
INFO - 2025-05-06 06:36:33 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:33 --> Controller Class Initialized
INFO - 2025-05-06 14:36:33 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:36:44 --> Config Class Initialized
INFO - 2025-05-06 06:36:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:44 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:44 --> URI Class Initialized
INFO - 2025-05-06 06:36:44 --> Router Class Initialized
INFO - 2025-05-06 06:36:44 --> Output Class Initialized
INFO - 2025-05-06 06:36:44 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:44 --> Input Class Initialized
INFO - 2025-05-06 06:36:44 --> Language Class Initialized
INFO - 2025-05-06 06:36:44 --> Loader Class Initialized
INFO - 2025-05-06 06:36:44 --> Helper loaded: url_helper
INFO - 2025-05-06 06:36:44 --> Helper loaded: string_helper
INFO - 2025-05-06 06:36:44 --> Helper loaded: form_helper
INFO - 2025-05-06 06:36:44 --> Helper loaded: file_helper
INFO - 2025-05-06 06:36:44 --> Helper loaded: html_helper
INFO - 2025-05-06 06:36:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:44 --> Controller Class Initialized
INFO - 2025-05-06 14:36:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:36:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:36:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:36:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:36:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:36:44 --> Final output sent to browser
DEBUG - 2025-05-06 14:36:44 --> Total execution time: 0.1333
INFO - 2025-05-06 06:36:45 --> Config Class Initialized
INFO - 2025-05-06 06:36:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:36:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:36:45 --> Utf8 Class Initialized
INFO - 2025-05-06 06:36:45 --> URI Class Initialized
INFO - 2025-05-06 06:36:45 --> Router Class Initialized
INFO - 2025-05-06 06:36:45 --> Output Class Initialized
INFO - 2025-05-06 06:36:45 --> Security Class Initialized
DEBUG - 2025-05-06 06:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:36:45 --> Input Class Initialized
INFO - 2025-05-06 06:36:45 --> Language Class Initialized
INFO - 2025-05-06 06:36:45 --> Loader Class Initialized
INFO - 2025-05-06 06:36:45 --> Helper loaded: url_helper
INFO - 2025-05-06 06:36:45 --> Helper loaded: string_helper
INFO - 2025-05-06 06:36:45 --> Helper loaded: form_helper
INFO - 2025-05-06 06:36:45 --> Helper loaded: file_helper
INFO - 2025-05-06 06:36:45 --> Helper loaded: html_helper
INFO - 2025-05-06 06:36:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:36:45 --> Controller Class Initialized
INFO - 2025-05-06 14:36:45 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:37:50 --> Config Class Initialized
INFO - 2025-05-06 06:37:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:37:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:37:50 --> Utf8 Class Initialized
INFO - 2025-05-06 06:37:50 --> URI Class Initialized
INFO - 2025-05-06 06:37:50 --> Router Class Initialized
INFO - 2025-05-06 06:37:50 --> Output Class Initialized
INFO - 2025-05-06 06:37:50 --> Security Class Initialized
DEBUG - 2025-05-06 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:37:50 --> Input Class Initialized
INFO - 2025-05-06 06:37:50 --> Language Class Initialized
INFO - 2025-05-06 06:37:50 --> Loader Class Initialized
INFO - 2025-05-06 06:37:50 --> Helper loaded: url_helper
INFO - 2025-05-06 06:37:50 --> Helper loaded: string_helper
INFO - 2025-05-06 06:37:50 --> Helper loaded: form_helper
INFO - 2025-05-06 06:37:50 --> Helper loaded: file_helper
INFO - 2025-05-06 06:37:50 --> Helper loaded: html_helper
INFO - 2025-05-06 06:37:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:37:50 --> Controller Class Initialized
INFO - 2025-05-06 14:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:37:50 --> Final output sent to browser
DEBUG - 2025-05-06 14:37:50 --> Total execution time: 0.1784
INFO - 2025-05-06 06:37:51 --> Config Class Initialized
INFO - 2025-05-06 06:37:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:37:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:37:51 --> Utf8 Class Initialized
INFO - 2025-05-06 06:37:51 --> URI Class Initialized
INFO - 2025-05-06 06:37:51 --> Router Class Initialized
INFO - 2025-05-06 06:37:51 --> Output Class Initialized
INFO - 2025-05-06 06:37:51 --> Security Class Initialized
DEBUG - 2025-05-06 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:37:51 --> Input Class Initialized
INFO - 2025-05-06 06:37:51 --> Language Class Initialized
INFO - 2025-05-06 06:37:51 --> Loader Class Initialized
INFO - 2025-05-06 06:37:51 --> Helper loaded: url_helper
INFO - 2025-05-06 06:37:51 --> Helper loaded: string_helper
INFO - 2025-05-06 06:37:51 --> Helper loaded: form_helper
INFO - 2025-05-06 06:37:51 --> Helper loaded: file_helper
INFO - 2025-05-06 06:37:51 --> Helper loaded: html_helper
INFO - 2025-05-06 06:37:51 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:37:51 --> Controller Class Initialized
INFO - 2025-05-06 14:37:51 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:40:36 --> Config Class Initialized
INFO - 2025-05-06 06:40:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:40:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:40:36 --> Utf8 Class Initialized
INFO - 2025-05-06 06:40:36 --> URI Class Initialized
INFO - 2025-05-06 06:40:36 --> Router Class Initialized
INFO - 2025-05-06 06:40:36 --> Output Class Initialized
INFO - 2025-05-06 06:40:36 --> Security Class Initialized
DEBUG - 2025-05-06 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:40:36 --> Input Class Initialized
INFO - 2025-05-06 06:40:36 --> Language Class Initialized
INFO - 2025-05-06 06:40:36 --> Loader Class Initialized
INFO - 2025-05-06 06:40:36 --> Helper loaded: url_helper
INFO - 2025-05-06 06:40:36 --> Helper loaded: string_helper
INFO - 2025-05-06 06:40:36 --> Helper loaded: form_helper
INFO - 2025-05-06 06:40:36 --> Helper loaded: file_helper
INFO - 2025-05-06 06:40:36 --> Helper loaded: html_helper
INFO - 2025-05-06 06:40:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:40:36 --> Controller Class Initialized
INFO - 2025-05-06 14:40:36 --> Model "AuctionModel" initialized
INFO - 2025-05-06 14:40:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:40:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:40:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 14:40:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:40:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:40:36 --> Final output sent to browser
DEBUG - 2025-05-06 14:40:36 --> Total execution time: 0.1969
INFO - 2025-05-06 06:40:37 --> Config Class Initialized
INFO - 2025-05-06 06:40:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:40:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:40:37 --> Utf8 Class Initialized
INFO - 2025-05-06 06:40:37 --> URI Class Initialized
INFO - 2025-05-06 06:40:37 --> Router Class Initialized
INFO - 2025-05-06 06:40:37 --> Output Class Initialized
INFO - 2025-05-06 06:40:37 --> Security Class Initialized
DEBUG - 2025-05-06 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:40:37 --> Input Class Initialized
INFO - 2025-05-06 06:40:37 --> Language Class Initialized
INFO - 2025-05-06 06:40:37 --> Loader Class Initialized
INFO - 2025-05-06 06:40:37 --> Helper loaded: url_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: string_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: form_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: file_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: html_helper
INFO - 2025-05-06 06:40:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:40:37 --> Controller Class Initialized
INFO - 2025-05-06 06:40:37 --> Config Class Initialized
INFO - 2025-05-06 06:40:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:40:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:40:37 --> Utf8 Class Initialized
INFO - 2025-05-06 06:40:37 --> URI Class Initialized
INFO - 2025-05-06 06:40:37 --> Router Class Initialized
INFO - 2025-05-06 06:40:37 --> Output Class Initialized
INFO - 2025-05-06 06:40:37 --> Security Class Initialized
DEBUG - 2025-05-06 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:40:37 --> Input Class Initialized
INFO - 2025-05-06 06:40:37 --> Language Class Initialized
INFO - 2025-05-06 06:40:37 --> Loader Class Initialized
INFO - 2025-05-06 06:40:37 --> Helper loaded: url_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: string_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: form_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: file_helper
INFO - 2025-05-06 06:40:37 --> Helper loaded: html_helper
INFO - 2025-05-06 06:40:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:40:37 --> Controller Class Initialized
INFO - 2025-05-06 14:40:37 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:41:26 --> Config Class Initialized
INFO - 2025-05-06 06:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:41:26 --> Utf8 Class Initialized
INFO - 2025-05-06 06:41:26 --> URI Class Initialized
INFO - 2025-05-06 06:41:26 --> Router Class Initialized
INFO - 2025-05-06 06:41:26 --> Output Class Initialized
INFO - 2025-05-06 06:41:26 --> Security Class Initialized
DEBUG - 2025-05-06 06:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:41:26 --> Input Class Initialized
INFO - 2025-05-06 06:41:26 --> Language Class Initialized
INFO - 2025-05-06 06:41:26 --> Loader Class Initialized
INFO - 2025-05-06 06:41:26 --> Helper loaded: url_helper
INFO - 2025-05-06 06:41:26 --> Helper loaded: string_helper
INFO - 2025-05-06 06:41:26 --> Helper loaded: form_helper
INFO - 2025-05-06 06:41:26 --> Helper loaded: file_helper
INFO - 2025-05-06 06:41:26 --> Helper loaded: html_helper
INFO - 2025-05-06 06:41:26 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:41:26 --> Controller Class Initialized
INFO - 2025-05-06 14:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:41:26 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:41:26 --> Final output sent to browser
DEBUG - 2025-05-06 14:41:26 --> Total execution time: 0.1789
INFO - 2025-05-06 06:41:27 --> Config Class Initialized
INFO - 2025-05-06 06:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:41:27 --> Utf8 Class Initialized
INFO - 2025-05-06 06:41:27 --> URI Class Initialized
INFO - 2025-05-06 06:41:27 --> Router Class Initialized
INFO - 2025-05-06 06:41:27 --> Output Class Initialized
INFO - 2025-05-06 06:41:27 --> Security Class Initialized
DEBUG - 2025-05-06 06:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:41:27 --> Input Class Initialized
INFO - 2025-05-06 06:41:27 --> Language Class Initialized
INFO - 2025-05-06 06:41:27 --> Loader Class Initialized
INFO - 2025-05-06 06:41:27 --> Helper loaded: url_helper
INFO - 2025-05-06 06:41:27 --> Helper loaded: string_helper
INFO - 2025-05-06 06:41:27 --> Helper loaded: form_helper
INFO - 2025-05-06 06:41:27 --> Helper loaded: file_helper
INFO - 2025-05-06 06:41:27 --> Helper loaded: html_helper
INFO - 2025-05-06 06:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:41:27 --> Controller Class Initialized
INFO - 2025-05-06 14:41:27 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:42:07 --> Config Class Initialized
INFO - 2025-05-06 06:42:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:42:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:42:07 --> Utf8 Class Initialized
INFO - 2025-05-06 06:42:07 --> URI Class Initialized
INFO - 2025-05-06 06:42:07 --> Router Class Initialized
INFO - 2025-05-06 06:42:07 --> Output Class Initialized
INFO - 2025-05-06 06:42:07 --> Security Class Initialized
DEBUG - 2025-05-06 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:42:07 --> Input Class Initialized
INFO - 2025-05-06 06:42:07 --> Language Class Initialized
INFO - 2025-05-06 06:42:07 --> Loader Class Initialized
INFO - 2025-05-06 06:42:07 --> Helper loaded: url_helper
INFO - 2025-05-06 06:42:07 --> Helper loaded: string_helper
INFO - 2025-05-06 06:42:07 --> Helper loaded: form_helper
INFO - 2025-05-06 06:42:07 --> Helper loaded: file_helper
INFO - 2025-05-06 06:42:07 --> Helper loaded: html_helper
INFO - 2025-05-06 06:42:07 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:42:07 --> Controller Class Initialized
INFO - 2025-05-06 14:42:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 14:42:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 14:42:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 14:42:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 14:42:07 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 14:42:07 --> Final output sent to browser
DEBUG - 2025-05-06 14:42:07 --> Total execution time: 0.1635
INFO - 2025-05-06 06:42:08 --> Config Class Initialized
INFO - 2025-05-06 06:42:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:42:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:42:08 --> Utf8 Class Initialized
INFO - 2025-05-06 06:42:08 --> URI Class Initialized
INFO - 2025-05-06 06:42:08 --> Router Class Initialized
INFO - 2025-05-06 06:42:08 --> Output Class Initialized
INFO - 2025-05-06 06:42:08 --> Security Class Initialized
DEBUG - 2025-05-06 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:42:08 --> Input Class Initialized
INFO - 2025-05-06 06:42:08 --> Language Class Initialized
INFO - 2025-05-06 06:42:08 --> Loader Class Initialized
INFO - 2025-05-06 06:42:08 --> Helper loaded: url_helper
INFO - 2025-05-06 06:42:08 --> Helper loaded: string_helper
INFO - 2025-05-06 06:42:08 --> Helper loaded: form_helper
INFO - 2025-05-06 06:42:08 --> Helper loaded: file_helper
INFO - 2025-05-06 06:42:08 --> Helper loaded: html_helper
INFO - 2025-05-06 06:42:08 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:42:08 --> Controller Class Initialized
INFO - 2025-05-06 14:42:08 --> Model "AuctionModel" initialized
INFO - 2025-05-06 06:42:46 --> Config Class Initialized
INFO - 2025-05-06 06:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:42:46 --> Utf8 Class Initialized
INFO - 2025-05-06 06:42:46 --> URI Class Initialized
INFO - 2025-05-06 06:42:46 --> Router Class Initialized
INFO - 2025-05-06 06:42:46 --> Output Class Initialized
INFO - 2025-05-06 06:42:46 --> Security Class Initialized
DEBUG - 2025-05-06 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:42:46 --> Input Class Initialized
INFO - 2025-05-06 06:42:46 --> Language Class Initialized
INFO - 2025-05-06 06:42:46 --> Loader Class Initialized
INFO - 2025-05-06 06:42:46 --> Helper loaded: url_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: string_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: form_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: file_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: html_helper
INFO - 2025-05-06 06:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:42:46 --> Controller Class Initialized
INFO - 2025-05-06 06:42:46 --> Config Class Initialized
INFO - 2025-05-06 06:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:42:46 --> Utf8 Class Initialized
INFO - 2025-05-06 06:42:46 --> URI Class Initialized
DEBUG - 2025-05-06 06:42:46 --> No URI present. Default controller set.
INFO - 2025-05-06 06:42:46 --> Router Class Initialized
INFO - 2025-05-06 06:42:46 --> Output Class Initialized
INFO - 2025-05-06 06:42:46 --> Security Class Initialized
DEBUG - 2025-05-06 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:42:46 --> Input Class Initialized
INFO - 2025-05-06 06:42:46 --> Language Class Initialized
INFO - 2025-05-06 06:42:46 --> Loader Class Initialized
INFO - 2025-05-06 06:42:46 --> Helper loaded: url_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: string_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: form_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: file_helper
INFO - 2025-05-06 06:42:46 --> Helper loaded: html_helper
INFO - 2025-05-06 06:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:42:46 --> Controller Class Initialized
INFO - 2025-05-06 06:42:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 06:42:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 06:42:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 06:42:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 06:42:46 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 06:42:46 --> Final output sent to browser
DEBUG - 2025-05-06 06:42:46 --> Total execution time: 0.1046
INFO - 2025-05-06 06:42:48 --> Config Class Initialized
INFO - 2025-05-06 06:42:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:42:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:42:48 --> Utf8 Class Initialized
INFO - 2025-05-06 06:42:48 --> URI Class Initialized
INFO - 2025-05-06 06:42:48 --> Router Class Initialized
INFO - 2025-05-06 06:42:48 --> Output Class Initialized
INFO - 2025-05-06 06:42:48 --> Security Class Initialized
DEBUG - 2025-05-06 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:42:48 --> Input Class Initialized
INFO - 2025-05-06 06:42:48 --> Language Class Initialized
INFO - 2025-05-06 06:42:48 --> Loader Class Initialized
INFO - 2025-05-06 06:42:48 --> Helper loaded: url_helper
INFO - 2025-05-06 06:42:48 --> Helper loaded: string_helper
INFO - 2025-05-06 06:42:48 --> Helper loaded: form_helper
INFO - 2025-05-06 06:42:48 --> Helper loaded: file_helper
INFO - 2025-05-06 06:42:48 --> Helper loaded: html_helper
INFO - 2025-05-06 06:42:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 06:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:42:48 --> Controller Class Initialized
INFO - 2025-05-06 14:42:48 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:03 --> Config Class Initialized
INFO - 2025-05-06 10:59:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:03 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:03 --> URI Class Initialized
INFO - 2025-05-06 10:59:03 --> Router Class Initialized
INFO - 2025-05-06 10:59:03 --> Output Class Initialized
INFO - 2025-05-06 10:59:03 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:03 --> Input Class Initialized
INFO - 2025-05-06 10:59:03 --> Language Class Initialized
INFO - 2025-05-06 10:59:04 --> Loader Class Initialized
INFO - 2025-05-06 10:59:04 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:04 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:04 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:04 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:04 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:05 --> Controller Class Initialized
INFO - 2025-05-06 18:59:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 18:59:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 18:59:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 18:59:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 18:59:05 --> Final output sent to browser
DEBUG - 2025-05-06 18:59:05 --> Total execution time: 2.9064
INFO - 2025-05-06 10:59:06 --> Config Class Initialized
INFO - 2025-05-06 10:59:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:06 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:06 --> URI Class Initialized
INFO - 2025-05-06 10:59:06 --> Router Class Initialized
INFO - 2025-05-06 10:59:06 --> Output Class Initialized
INFO - 2025-05-06 10:59:06 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:06 --> Input Class Initialized
INFO - 2025-05-06 10:59:06 --> Language Class Initialized
INFO - 2025-05-06 10:59:06 --> Loader Class Initialized
INFO - 2025-05-06 10:59:06 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:06 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:06 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:06 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:06 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:06 --> Controller Class Initialized
INFO - 2025-05-06 18:59:06 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:27 --> Config Class Initialized
INFO - 2025-05-06 10:59:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:27 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:27 --> URI Class Initialized
INFO - 2025-05-06 10:59:27 --> Router Class Initialized
INFO - 2025-05-06 10:59:27 --> Output Class Initialized
INFO - 2025-05-06 10:59:27 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:27 --> Input Class Initialized
INFO - 2025-05-06 10:59:27 --> Language Class Initialized
INFO - 2025-05-06 10:59:27 --> Loader Class Initialized
INFO - 2025-05-06 10:59:27 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:27 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:27 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:27 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:27 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:27 --> Controller Class Initialized
INFO - 2025-05-06 18:59:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 18:59:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 18:59:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 18:59:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 18:59:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 18:59:27 --> Final output sent to browser
DEBUG - 2025-05-06 18:59:27 --> Total execution time: 0.1154
INFO - 2025-05-06 10:59:29 --> Config Class Initialized
INFO - 2025-05-06 10:59:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:29 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:29 --> URI Class Initialized
INFO - 2025-05-06 10:59:29 --> Router Class Initialized
INFO - 2025-05-06 10:59:29 --> Output Class Initialized
INFO - 2025-05-06 10:59:29 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:29 --> Input Class Initialized
INFO - 2025-05-06 10:59:29 --> Language Class Initialized
INFO - 2025-05-06 10:59:29 --> Loader Class Initialized
INFO - 2025-05-06 10:59:29 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:29 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:29 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:29 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:29 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:29 --> Controller Class Initialized
INFO - 2025-05-06 18:59:29 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:42 --> Config Class Initialized
INFO - 2025-05-06 10:59:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:42 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:42 --> URI Class Initialized
INFO - 2025-05-06 10:59:42 --> Router Class Initialized
INFO - 2025-05-06 10:59:42 --> Output Class Initialized
INFO - 2025-05-06 10:59:42 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:43 --> Input Class Initialized
INFO - 2025-05-06 10:59:43 --> Language Class Initialized
INFO - 2025-05-06 10:59:43 --> Loader Class Initialized
INFO - 2025-05-06 10:59:43 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:43 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:43 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:43 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:43 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:43 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:43 --> Controller Class Initialized
INFO - 2025-05-06 18:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 18:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 18:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 18:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 18:59:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 18:59:43 --> Final output sent to browser
DEBUG - 2025-05-06 18:59:43 --> Total execution time: 0.1443
INFO - 2025-05-06 10:59:44 --> Config Class Initialized
INFO - 2025-05-06 10:59:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:44 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:44 --> URI Class Initialized
INFO - 2025-05-06 10:59:44 --> Router Class Initialized
INFO - 2025-05-06 10:59:44 --> Output Class Initialized
INFO - 2025-05-06 10:59:44 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:44 --> Input Class Initialized
INFO - 2025-05-06 10:59:44 --> Language Class Initialized
INFO - 2025-05-06 10:59:44 --> Loader Class Initialized
INFO - 2025-05-06 10:59:44 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:44 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:44 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:44 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:44 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:44 --> Controller Class Initialized
INFO - 2025-05-06 18:59:44 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:49 --> Config Class Initialized
INFO - 2025-05-06 10:59:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:49 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:49 --> URI Class Initialized
INFO - 2025-05-06 10:59:49 --> Router Class Initialized
INFO - 2025-05-06 10:59:49 --> Output Class Initialized
INFO - 2025-05-06 10:59:49 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:49 --> Input Class Initialized
INFO - 2025-05-06 10:59:49 --> Language Class Initialized
INFO - 2025-05-06 10:59:49 --> Loader Class Initialized
INFO - 2025-05-06 10:59:49 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:49 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:49 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:49 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:49 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:49 --> Controller Class Initialized
INFO - 2025-05-06 18:59:49 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:53 --> Config Class Initialized
INFO - 2025-05-06 10:59:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:53 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:53 --> URI Class Initialized
INFO - 2025-05-06 10:59:53 --> Router Class Initialized
INFO - 2025-05-06 10:59:53 --> Output Class Initialized
INFO - 2025-05-06 10:59:53 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:53 --> Input Class Initialized
INFO - 2025-05-06 10:59:53 --> Language Class Initialized
INFO - 2025-05-06 10:59:53 --> Loader Class Initialized
INFO - 2025-05-06 10:59:53 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:53 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:53 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:53 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:53 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:53 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:53 --> Controller Class Initialized
INFO - 2025-05-06 18:59:53 --> Model "AuctionModel" initialized
INFO - 2025-05-06 10:59:56 --> Config Class Initialized
INFO - 2025-05-06 10:59:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:59:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:59:56 --> Utf8 Class Initialized
INFO - 2025-05-06 10:59:56 --> URI Class Initialized
INFO - 2025-05-06 10:59:56 --> Router Class Initialized
INFO - 2025-05-06 10:59:56 --> Output Class Initialized
INFO - 2025-05-06 10:59:56 --> Security Class Initialized
DEBUG - 2025-05-06 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:59:56 --> Input Class Initialized
INFO - 2025-05-06 10:59:56 --> Language Class Initialized
INFO - 2025-05-06 10:59:56 --> Loader Class Initialized
INFO - 2025-05-06 10:59:56 --> Helper loaded: url_helper
INFO - 2025-05-06 10:59:56 --> Helper loaded: string_helper
INFO - 2025-05-06 10:59:56 --> Helper loaded: form_helper
INFO - 2025-05-06 10:59:56 --> Helper loaded: file_helper
INFO - 2025-05-06 10:59:56 --> Helper loaded: html_helper
INFO - 2025-05-06 10:59:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 10:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:59:56 --> Controller Class Initialized
INFO - 2025-05-06 18:59:56 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:00:00 --> Config Class Initialized
INFO - 2025-05-06 11:00:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:00:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:00:00 --> Utf8 Class Initialized
INFO - 2025-05-06 11:00:00 --> URI Class Initialized
INFO - 2025-05-06 11:00:00 --> Router Class Initialized
INFO - 2025-05-06 11:00:00 --> Output Class Initialized
INFO - 2025-05-06 11:00:00 --> Security Class Initialized
DEBUG - 2025-05-06 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:00:00 --> Input Class Initialized
INFO - 2025-05-06 11:00:00 --> Language Class Initialized
INFO - 2025-05-06 11:00:00 --> Loader Class Initialized
INFO - 2025-05-06 11:00:00 --> Helper loaded: url_helper
INFO - 2025-05-06 11:00:00 --> Helper loaded: string_helper
INFO - 2025-05-06 11:00:00 --> Helper loaded: form_helper
INFO - 2025-05-06 11:00:00 --> Helper loaded: file_helper
INFO - 2025-05-06 11:00:00 --> Helper loaded: html_helper
INFO - 2025-05-06 11:00:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:00:00 --> Controller Class Initialized
INFO - 2025-05-06 19:00:00 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:00:03 --> Config Class Initialized
INFO - 2025-05-06 11:00:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:00:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:00:03 --> Utf8 Class Initialized
INFO - 2025-05-06 11:00:03 --> URI Class Initialized
INFO - 2025-05-06 11:00:03 --> Router Class Initialized
INFO - 2025-05-06 11:00:03 --> Output Class Initialized
INFO - 2025-05-06 11:00:03 --> Security Class Initialized
DEBUG - 2025-05-06 11:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:00:03 --> Input Class Initialized
INFO - 2025-05-06 11:00:03 --> Language Class Initialized
INFO - 2025-05-06 11:00:03 --> Loader Class Initialized
INFO - 2025-05-06 11:00:03 --> Helper loaded: url_helper
INFO - 2025-05-06 11:00:03 --> Helper loaded: string_helper
INFO - 2025-05-06 11:00:03 --> Helper loaded: form_helper
INFO - 2025-05-06 11:00:03 --> Helper loaded: file_helper
INFO - 2025-05-06 11:00:03 --> Helper loaded: html_helper
INFO - 2025-05-06 11:00:03 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:00:03 --> Controller Class Initialized
INFO - 2025-05-06 19:00:03 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:00:15 --> Config Class Initialized
INFO - 2025-05-06 11:00:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:00:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:00:15 --> Utf8 Class Initialized
INFO - 2025-05-06 11:00:15 --> URI Class Initialized
INFO - 2025-05-06 11:00:15 --> Router Class Initialized
INFO - 2025-05-06 11:00:15 --> Output Class Initialized
INFO - 2025-05-06 11:00:15 --> Security Class Initialized
DEBUG - 2025-05-06 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:00:15 --> Input Class Initialized
INFO - 2025-05-06 11:00:15 --> Language Class Initialized
INFO - 2025-05-06 11:00:15 --> Loader Class Initialized
INFO - 2025-05-06 11:00:15 --> Helper loaded: url_helper
INFO - 2025-05-06 11:00:15 --> Helper loaded: string_helper
INFO - 2025-05-06 11:00:15 --> Helper loaded: form_helper
INFO - 2025-05-06 11:00:15 --> Helper loaded: file_helper
INFO - 2025-05-06 11:00:15 --> Helper loaded: html_helper
INFO - 2025-05-06 11:00:15 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:00:15 --> Controller Class Initialized
INFO - 2025-05-06 19:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:00:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:00:15 --> Final output sent to browser
DEBUG - 2025-05-06 19:00:15 --> Total execution time: 0.1285
INFO - 2025-05-06 11:00:18 --> Config Class Initialized
INFO - 2025-05-06 11:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:00:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:00:18 --> URI Class Initialized
INFO - 2025-05-06 11:00:18 --> Router Class Initialized
INFO - 2025-05-06 11:00:18 --> Output Class Initialized
INFO - 2025-05-06 11:00:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:00:18 --> Input Class Initialized
INFO - 2025-05-06 11:00:18 --> Language Class Initialized
INFO - 2025-05-06 11:00:18 --> Loader Class Initialized
INFO - 2025-05-06 11:00:18 --> Helper loaded: url_helper
INFO - 2025-05-06 11:00:18 --> Helper loaded: string_helper
INFO - 2025-05-06 11:00:18 --> Helper loaded: form_helper
INFO - 2025-05-06 11:00:18 --> Helper loaded: file_helper
INFO - 2025-05-06 11:00:18 --> Helper loaded: html_helper
INFO - 2025-05-06 11:00:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:00:18 --> Controller Class Initialized
INFO - 2025-05-06 19:00:18 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:02:01 --> Config Class Initialized
INFO - 2025-05-06 11:02:01 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:02:01 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:02:01 --> Utf8 Class Initialized
INFO - 2025-05-06 11:02:01 --> URI Class Initialized
INFO - 2025-05-06 11:02:01 --> Router Class Initialized
INFO - 2025-05-06 11:02:01 --> Output Class Initialized
INFO - 2025-05-06 11:02:01 --> Security Class Initialized
DEBUG - 2025-05-06 11:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:02:01 --> Input Class Initialized
INFO - 2025-05-06 11:02:01 --> Language Class Initialized
INFO - 2025-05-06 11:02:02 --> Loader Class Initialized
INFO - 2025-05-06 11:02:02 --> Helper loaded: url_helper
INFO - 2025-05-06 11:02:02 --> Helper loaded: string_helper
INFO - 2025-05-06 11:02:02 --> Helper loaded: form_helper
INFO - 2025-05-06 11:02:02 --> Helper loaded: file_helper
INFO - 2025-05-06 11:02:02 --> Helper loaded: html_helper
INFO - 2025-05-06 11:02:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:02:02 --> Controller Class Initialized
INFO - 2025-05-06 19:02:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:02:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:02:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:02:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:02:03 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:02:03 --> Final output sent to browser
DEBUG - 2025-05-06 19:02:03 --> Total execution time: 2.3629
INFO - 2025-05-06 11:02:03 --> Config Class Initialized
INFO - 2025-05-06 11:02:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:02:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:02:04 --> Utf8 Class Initialized
INFO - 2025-05-06 11:02:04 --> URI Class Initialized
INFO - 2025-05-06 11:02:04 --> Router Class Initialized
INFO - 2025-05-06 11:02:04 --> Output Class Initialized
INFO - 2025-05-06 11:02:04 --> Security Class Initialized
DEBUG - 2025-05-06 11:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:02:04 --> Input Class Initialized
INFO - 2025-05-06 11:02:04 --> Language Class Initialized
INFO - 2025-05-06 11:02:04 --> Loader Class Initialized
INFO - 2025-05-06 11:02:04 --> Helper loaded: url_helper
INFO - 2025-05-06 11:02:04 --> Helper loaded: string_helper
INFO - 2025-05-06 11:02:04 --> Helper loaded: form_helper
INFO - 2025-05-06 11:02:04 --> Helper loaded: file_helper
INFO - 2025-05-06 11:02:04 --> Helper loaded: html_helper
INFO - 2025-05-06 11:02:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:02:04 --> Controller Class Initialized
INFO - 2025-05-06 19:02:04 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:02:21 --> Config Class Initialized
INFO - 2025-05-06 11:02:21 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:02:21 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:02:21 --> Utf8 Class Initialized
INFO - 2025-05-06 11:02:21 --> URI Class Initialized
INFO - 2025-05-06 11:02:21 --> Router Class Initialized
INFO - 2025-05-06 11:02:21 --> Output Class Initialized
INFO - 2025-05-06 11:02:21 --> Security Class Initialized
DEBUG - 2025-05-06 11:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:02:21 --> Input Class Initialized
INFO - 2025-05-06 11:02:21 --> Language Class Initialized
INFO - 2025-05-06 11:02:21 --> Loader Class Initialized
INFO - 2025-05-06 11:02:21 --> Helper loaded: url_helper
INFO - 2025-05-06 11:02:21 --> Helper loaded: string_helper
INFO - 2025-05-06 11:02:21 --> Helper loaded: form_helper
INFO - 2025-05-06 11:02:21 --> Helper loaded: file_helper
INFO - 2025-05-06 11:02:21 --> Helper loaded: html_helper
INFO - 2025-05-06 11:02:21 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:02:21 --> Controller Class Initialized
INFO - 2025-05-06 19:02:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:02:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:02:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:02:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:02:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:02:21 --> Final output sent to browser
DEBUG - 2025-05-06 19:02:21 --> Total execution time: 0.1526
INFO - 2025-05-06 11:02:55 --> Config Class Initialized
INFO - 2025-05-06 11:02:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:02:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:02:55 --> Utf8 Class Initialized
INFO - 2025-05-06 11:02:55 --> URI Class Initialized
INFO - 2025-05-06 11:02:55 --> Router Class Initialized
INFO - 2025-05-06 11:02:55 --> Output Class Initialized
INFO - 2025-05-06 11:02:55 --> Security Class Initialized
DEBUG - 2025-05-06 11:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:02:55 --> Input Class Initialized
INFO - 2025-05-06 11:02:55 --> Language Class Initialized
INFO - 2025-05-06 11:02:55 --> Loader Class Initialized
INFO - 2025-05-06 11:02:55 --> Helper loaded: url_helper
INFO - 2025-05-06 11:02:55 --> Helper loaded: string_helper
INFO - 2025-05-06 11:02:55 --> Helper loaded: form_helper
INFO - 2025-05-06 11:02:55 --> Helper loaded: file_helper
INFO - 2025-05-06 11:02:55 --> Helper loaded: html_helper
INFO - 2025-05-06 11:02:55 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:02:55 --> Controller Class Initialized
INFO - 2025-05-06 19:02:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:02:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:02:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:02:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:02:55 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:02:55 --> Final output sent to browser
DEBUG - 2025-05-06 19:02:55 --> Total execution time: 0.1682
INFO - 2025-05-06 11:02:57 --> Config Class Initialized
INFO - 2025-05-06 11:02:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:02:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:02:57 --> Utf8 Class Initialized
INFO - 2025-05-06 11:02:57 --> URI Class Initialized
INFO - 2025-05-06 11:02:57 --> Router Class Initialized
INFO - 2025-05-06 11:02:57 --> Output Class Initialized
INFO - 2025-05-06 11:02:57 --> Security Class Initialized
DEBUG - 2025-05-06 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:02:57 --> Input Class Initialized
INFO - 2025-05-06 11:02:57 --> Language Class Initialized
INFO - 2025-05-06 11:02:57 --> Loader Class Initialized
INFO - 2025-05-06 11:02:57 --> Helper loaded: url_helper
INFO - 2025-05-06 11:02:57 --> Helper loaded: string_helper
INFO - 2025-05-06 11:02:57 --> Helper loaded: form_helper
INFO - 2025-05-06 11:02:57 --> Helper loaded: file_helper
INFO - 2025-05-06 11:02:57 --> Helper loaded: html_helper
INFO - 2025-05-06 11:02:57 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:02:57 --> Controller Class Initialized
INFO - 2025-05-06 19:02:57 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:03:49 --> Config Class Initialized
INFO - 2025-05-06 11:03:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:03:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:03:49 --> Utf8 Class Initialized
INFO - 2025-05-06 11:03:49 --> URI Class Initialized
INFO - 2025-05-06 11:03:49 --> Router Class Initialized
INFO - 2025-05-06 11:03:49 --> Output Class Initialized
INFO - 2025-05-06 11:03:49 --> Security Class Initialized
DEBUG - 2025-05-06 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:03:49 --> Input Class Initialized
INFO - 2025-05-06 11:03:49 --> Language Class Initialized
INFO - 2025-05-06 11:03:49 --> Loader Class Initialized
INFO - 2025-05-06 11:03:49 --> Helper loaded: url_helper
INFO - 2025-05-06 11:03:49 --> Helper loaded: string_helper
INFO - 2025-05-06 11:03:49 --> Helper loaded: form_helper
INFO - 2025-05-06 11:03:49 --> Helper loaded: file_helper
INFO - 2025-05-06 11:03:49 --> Helper loaded: html_helper
INFO - 2025-05-06 11:03:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:03:49 --> Controller Class Initialized
INFO - 2025-05-06 19:03:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:03:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:03:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:03:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:03:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:03:49 --> Final output sent to browser
DEBUG - 2025-05-06 19:03:49 --> Total execution time: 0.1136
INFO - 2025-05-06 11:03:51 --> Config Class Initialized
INFO - 2025-05-06 11:03:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:03:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:03:51 --> Utf8 Class Initialized
INFO - 2025-05-06 11:03:51 --> URI Class Initialized
INFO - 2025-05-06 11:03:51 --> Router Class Initialized
INFO - 2025-05-06 11:03:51 --> Output Class Initialized
INFO - 2025-05-06 11:03:51 --> Security Class Initialized
DEBUG - 2025-05-06 11:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:03:51 --> Input Class Initialized
INFO - 2025-05-06 11:03:51 --> Language Class Initialized
INFO - 2025-05-06 11:03:51 --> Loader Class Initialized
INFO - 2025-05-06 11:03:51 --> Helper loaded: url_helper
INFO - 2025-05-06 11:03:51 --> Helper loaded: string_helper
INFO - 2025-05-06 11:03:51 --> Helper loaded: form_helper
INFO - 2025-05-06 11:03:51 --> Helper loaded: file_helper
INFO - 2025-05-06 11:03:51 --> Helper loaded: html_helper
INFO - 2025-05-06 11:03:51 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:03:51 --> Controller Class Initialized
INFO - 2025-05-06 19:03:51 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:04:02 --> Config Class Initialized
INFO - 2025-05-06 11:04:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:04:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:04:02 --> Utf8 Class Initialized
INFO - 2025-05-06 11:04:02 --> URI Class Initialized
INFO - 2025-05-06 11:04:02 --> Router Class Initialized
INFO - 2025-05-06 11:04:02 --> Output Class Initialized
INFO - 2025-05-06 11:04:02 --> Security Class Initialized
DEBUG - 2025-05-06 11:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:04:02 --> Input Class Initialized
INFO - 2025-05-06 11:04:02 --> Language Class Initialized
INFO - 2025-05-06 11:04:02 --> Loader Class Initialized
INFO - 2025-05-06 11:04:02 --> Helper loaded: url_helper
INFO - 2025-05-06 11:04:02 --> Helper loaded: string_helper
INFO - 2025-05-06 11:04:02 --> Helper loaded: form_helper
INFO - 2025-05-06 11:04:02 --> Helper loaded: file_helper
INFO - 2025-05-06 11:04:02 --> Helper loaded: html_helper
INFO - 2025-05-06 11:04:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:04:02 --> Controller Class Initialized
INFO - 2025-05-06 19:04:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:04:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:04:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:04:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:04:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:04:02 --> Final output sent to browser
DEBUG - 2025-05-06 19:04:02 --> Total execution time: 0.2106
INFO - 2025-05-06 11:04:03 --> Config Class Initialized
INFO - 2025-05-06 11:04:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:04:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:04:03 --> Utf8 Class Initialized
INFO - 2025-05-06 11:04:03 --> URI Class Initialized
INFO - 2025-05-06 11:04:03 --> Router Class Initialized
INFO - 2025-05-06 11:04:03 --> Output Class Initialized
INFO - 2025-05-06 11:04:03 --> Security Class Initialized
DEBUG - 2025-05-06 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:04:03 --> Input Class Initialized
INFO - 2025-05-06 11:04:03 --> Language Class Initialized
INFO - 2025-05-06 11:04:03 --> Loader Class Initialized
INFO - 2025-05-06 11:04:03 --> Helper loaded: url_helper
INFO - 2025-05-06 11:04:03 --> Helper loaded: string_helper
INFO - 2025-05-06 11:04:03 --> Helper loaded: form_helper
INFO - 2025-05-06 11:04:03 --> Helper loaded: file_helper
INFO - 2025-05-06 11:04:03 --> Helper loaded: html_helper
INFO - 2025-05-06 11:04:03 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:04:03 --> Controller Class Initialized
INFO - 2025-05-06 19:04:03 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:04:25 --> Config Class Initialized
INFO - 2025-05-06 11:04:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:04:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:04:25 --> Utf8 Class Initialized
INFO - 2025-05-06 11:04:25 --> URI Class Initialized
INFO - 2025-05-06 11:04:25 --> Router Class Initialized
INFO - 2025-05-06 11:04:25 --> Output Class Initialized
INFO - 2025-05-06 11:04:25 --> Security Class Initialized
DEBUG - 2025-05-06 11:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:04:25 --> Input Class Initialized
INFO - 2025-05-06 11:04:25 --> Language Class Initialized
INFO - 2025-05-06 11:04:25 --> Loader Class Initialized
INFO - 2025-05-06 11:04:25 --> Helper loaded: url_helper
INFO - 2025-05-06 11:04:25 --> Helper loaded: string_helper
INFO - 2025-05-06 11:04:25 --> Helper loaded: form_helper
INFO - 2025-05-06 11:04:25 --> Helper loaded: file_helper
INFO - 2025-05-06 11:04:25 --> Helper loaded: html_helper
INFO - 2025-05-06 11:04:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:04:25 --> Controller Class Initialized
INFO - 2025-05-06 19:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:04:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:04:25 --> Final output sent to browser
DEBUG - 2025-05-06 19:04:25 --> Total execution time: 0.0959
INFO - 2025-05-06 11:05:04 --> Config Class Initialized
INFO - 2025-05-06 11:05:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:05:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:05:04 --> Utf8 Class Initialized
INFO - 2025-05-06 11:05:04 --> URI Class Initialized
INFO - 2025-05-06 11:05:04 --> Router Class Initialized
INFO - 2025-05-06 11:05:04 --> Output Class Initialized
INFO - 2025-05-06 11:05:04 --> Security Class Initialized
DEBUG - 2025-05-06 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:05:04 --> Input Class Initialized
INFO - 2025-05-06 11:05:04 --> Language Class Initialized
INFO - 2025-05-06 11:05:04 --> Loader Class Initialized
INFO - 2025-05-06 11:05:04 --> Helper loaded: url_helper
INFO - 2025-05-06 11:05:04 --> Helper loaded: string_helper
INFO - 2025-05-06 11:05:04 --> Helper loaded: form_helper
INFO - 2025-05-06 11:05:04 --> Helper loaded: file_helper
INFO - 2025-05-06 11:05:04 --> Helper loaded: html_helper
INFO - 2025-05-06 11:05:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:05:04 --> Controller Class Initialized
INFO - 2025-05-06 19:05:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:05:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:05:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:05:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:05:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:05:04 --> Final output sent to browser
DEBUG - 2025-05-06 19:05:04 --> Total execution time: 0.0955
INFO - 2025-05-06 11:05:05 --> Config Class Initialized
INFO - 2025-05-06 11:05:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:05:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:05:05 --> Utf8 Class Initialized
INFO - 2025-05-06 11:05:05 --> URI Class Initialized
INFO - 2025-05-06 11:05:05 --> Router Class Initialized
INFO - 2025-05-06 11:05:05 --> Output Class Initialized
INFO - 2025-05-06 11:05:05 --> Security Class Initialized
DEBUG - 2025-05-06 11:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:05:05 --> Input Class Initialized
INFO - 2025-05-06 11:05:05 --> Language Class Initialized
INFO - 2025-05-06 11:05:05 --> Loader Class Initialized
INFO - 2025-05-06 11:05:05 --> Helper loaded: url_helper
INFO - 2025-05-06 11:05:05 --> Helper loaded: string_helper
INFO - 2025-05-06 11:05:05 --> Helper loaded: form_helper
INFO - 2025-05-06 11:05:05 --> Helper loaded: file_helper
INFO - 2025-05-06 11:05:05 --> Helper loaded: html_helper
INFO - 2025-05-06 11:05:05 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:05:05 --> Controller Class Initialized
INFO - 2025-05-06 19:05:05 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:05:17 --> Config Class Initialized
INFO - 2025-05-06 11:05:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:05:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:05:17 --> Utf8 Class Initialized
INFO - 2025-05-06 11:05:17 --> URI Class Initialized
INFO - 2025-05-06 11:05:17 --> Router Class Initialized
INFO - 2025-05-06 11:05:17 --> Output Class Initialized
INFO - 2025-05-06 11:05:17 --> Security Class Initialized
DEBUG - 2025-05-06 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:05:17 --> Input Class Initialized
INFO - 2025-05-06 11:05:17 --> Language Class Initialized
INFO - 2025-05-06 11:05:17 --> Loader Class Initialized
INFO - 2025-05-06 11:05:17 --> Helper loaded: url_helper
INFO - 2025-05-06 11:05:17 --> Helper loaded: string_helper
INFO - 2025-05-06 11:05:17 --> Helper loaded: form_helper
INFO - 2025-05-06 11:05:17 --> Helper loaded: file_helper
INFO - 2025-05-06 11:05:17 --> Helper loaded: html_helper
INFO - 2025-05-06 11:05:17 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:05:17 --> Controller Class Initialized
INFO - 2025-05-06 19:05:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:05:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:05:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:05:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:05:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:05:17 --> Final output sent to browser
DEBUG - 2025-05-06 19:05:17 --> Total execution time: 0.2747
INFO - 2025-05-06 11:05:18 --> Config Class Initialized
INFO - 2025-05-06 11:05:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:05:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:05:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:05:18 --> URI Class Initialized
INFO - 2025-05-06 11:05:18 --> Router Class Initialized
INFO - 2025-05-06 11:05:18 --> Output Class Initialized
INFO - 2025-05-06 11:05:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:05:18 --> Input Class Initialized
INFO - 2025-05-06 11:05:18 --> Language Class Initialized
INFO - 2025-05-06 11:05:19 --> Loader Class Initialized
INFO - 2025-05-06 11:05:19 --> Helper loaded: url_helper
INFO - 2025-05-06 11:05:19 --> Helper loaded: string_helper
INFO - 2025-05-06 11:05:19 --> Helper loaded: form_helper
INFO - 2025-05-06 11:05:19 --> Helper loaded: file_helper
INFO - 2025-05-06 11:05:19 --> Helper loaded: html_helper
INFO - 2025-05-06 11:05:19 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:05:19 --> Controller Class Initialized
INFO - 2025-05-06 19:05:19 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:06:28 --> Config Class Initialized
INFO - 2025-05-06 11:06:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:06:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:06:28 --> Utf8 Class Initialized
INFO - 2025-05-06 11:06:28 --> URI Class Initialized
INFO - 2025-05-06 11:06:28 --> Router Class Initialized
INFO - 2025-05-06 11:06:28 --> Output Class Initialized
INFO - 2025-05-06 11:06:28 --> Security Class Initialized
DEBUG - 2025-05-06 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:06:28 --> Input Class Initialized
INFO - 2025-05-06 11:06:28 --> Language Class Initialized
INFO - 2025-05-06 11:06:28 --> Loader Class Initialized
INFO - 2025-05-06 11:06:28 --> Helper loaded: url_helper
INFO - 2025-05-06 11:06:28 --> Helper loaded: string_helper
INFO - 2025-05-06 11:06:28 --> Helper loaded: form_helper
INFO - 2025-05-06 11:06:28 --> Helper loaded: file_helper
INFO - 2025-05-06 11:06:28 --> Helper loaded: html_helper
INFO - 2025-05-06 11:06:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:06:29 --> Controller Class Initialized
INFO - 2025-05-06 19:06:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:06:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:06:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:06:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:06:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:06:29 --> Final output sent to browser
DEBUG - 2025-05-06 19:06:29 --> Total execution time: 0.1994
INFO - 2025-05-06 11:06:30 --> Config Class Initialized
INFO - 2025-05-06 11:06:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:06:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:06:30 --> Utf8 Class Initialized
INFO - 2025-05-06 11:06:30 --> URI Class Initialized
INFO - 2025-05-06 11:06:30 --> Router Class Initialized
INFO - 2025-05-06 11:06:30 --> Output Class Initialized
INFO - 2025-05-06 11:06:30 --> Security Class Initialized
DEBUG - 2025-05-06 11:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:06:30 --> Input Class Initialized
INFO - 2025-05-06 11:06:30 --> Language Class Initialized
INFO - 2025-05-06 11:06:30 --> Loader Class Initialized
INFO - 2025-05-06 11:06:30 --> Helper loaded: url_helper
INFO - 2025-05-06 11:06:30 --> Helper loaded: string_helper
INFO - 2025-05-06 11:06:30 --> Helper loaded: form_helper
INFO - 2025-05-06 11:06:30 --> Helper loaded: file_helper
INFO - 2025-05-06 11:06:30 --> Helper loaded: html_helper
INFO - 2025-05-06 11:06:30 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:06:30 --> Controller Class Initialized
INFO - 2025-05-06 19:06:30 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:08:45 --> Config Class Initialized
INFO - 2025-05-06 11:08:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:08:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:08:45 --> Utf8 Class Initialized
INFO - 2025-05-06 11:08:45 --> URI Class Initialized
INFO - 2025-05-06 11:08:45 --> Router Class Initialized
INFO - 2025-05-06 11:08:45 --> Output Class Initialized
INFO - 2025-05-06 11:08:45 --> Security Class Initialized
DEBUG - 2025-05-06 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:08:45 --> Input Class Initialized
INFO - 2025-05-06 11:08:45 --> Language Class Initialized
INFO - 2025-05-06 11:08:45 --> Loader Class Initialized
INFO - 2025-05-06 11:08:45 --> Helper loaded: url_helper
INFO - 2025-05-06 11:08:45 --> Helper loaded: string_helper
INFO - 2025-05-06 11:08:45 --> Helper loaded: form_helper
INFO - 2025-05-06 11:08:45 --> Helper loaded: file_helper
INFO - 2025-05-06 11:08:45 --> Helper loaded: html_helper
INFO - 2025-05-06 11:08:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:08:45 --> Controller Class Initialized
INFO - 2025-05-06 19:08:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:08:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:08:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:08:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:08:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:08:45 --> Final output sent to browser
DEBUG - 2025-05-06 19:08:45 --> Total execution time: 0.2219
INFO - 2025-05-06 11:08:46 --> Config Class Initialized
INFO - 2025-05-06 11:08:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:08:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:08:46 --> Utf8 Class Initialized
INFO - 2025-05-06 11:08:46 --> URI Class Initialized
INFO - 2025-05-06 11:08:46 --> Router Class Initialized
INFO - 2025-05-06 11:08:46 --> Output Class Initialized
INFO - 2025-05-06 11:08:46 --> Security Class Initialized
DEBUG - 2025-05-06 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:08:46 --> Input Class Initialized
INFO - 2025-05-06 11:08:46 --> Language Class Initialized
INFO - 2025-05-06 11:08:46 --> Loader Class Initialized
INFO - 2025-05-06 11:08:46 --> Helper loaded: url_helper
INFO - 2025-05-06 11:08:46 --> Helper loaded: string_helper
INFO - 2025-05-06 11:08:46 --> Helper loaded: form_helper
INFO - 2025-05-06 11:08:46 --> Helper loaded: file_helper
INFO - 2025-05-06 11:08:46 --> Helper loaded: html_helper
INFO - 2025-05-06 11:08:46 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:08:46 --> Controller Class Initialized
INFO - 2025-05-06 19:08:46 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:08:56 --> Config Class Initialized
INFO - 2025-05-06 11:08:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:08:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:08:56 --> Utf8 Class Initialized
INFO - 2025-05-06 11:08:56 --> URI Class Initialized
INFO - 2025-05-06 11:08:56 --> Router Class Initialized
INFO - 2025-05-06 11:08:56 --> Output Class Initialized
INFO - 2025-05-06 11:08:56 --> Security Class Initialized
DEBUG - 2025-05-06 11:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:08:56 --> Input Class Initialized
INFO - 2025-05-06 11:08:56 --> Language Class Initialized
INFO - 2025-05-06 11:08:56 --> Loader Class Initialized
INFO - 2025-05-06 11:08:56 --> Helper loaded: url_helper
INFO - 2025-05-06 11:08:56 --> Helper loaded: string_helper
INFO - 2025-05-06 11:08:56 --> Helper loaded: form_helper
INFO - 2025-05-06 11:08:56 --> Helper loaded: file_helper
INFO - 2025-05-06 11:08:56 --> Helper loaded: html_helper
INFO - 2025-05-06 11:08:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:08:56 --> Controller Class Initialized
INFO - 2025-05-06 19:08:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:08:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:08:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:08:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:08:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:08:56 --> Final output sent to browser
DEBUG - 2025-05-06 19:08:56 --> Total execution time: 0.2080
INFO - 2025-05-06 11:08:57 --> Config Class Initialized
INFO - 2025-05-06 11:08:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:08:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:08:57 --> Utf8 Class Initialized
INFO - 2025-05-06 11:08:57 --> URI Class Initialized
INFO - 2025-05-06 11:08:57 --> Router Class Initialized
INFO - 2025-05-06 11:08:57 --> Output Class Initialized
INFO - 2025-05-06 11:08:57 --> Security Class Initialized
DEBUG - 2025-05-06 11:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:08:57 --> Input Class Initialized
INFO - 2025-05-06 11:08:57 --> Language Class Initialized
INFO - 2025-05-06 11:08:57 --> Loader Class Initialized
INFO - 2025-05-06 11:08:57 --> Helper loaded: url_helper
INFO - 2025-05-06 11:08:57 --> Helper loaded: string_helper
INFO - 2025-05-06 11:08:57 --> Helper loaded: form_helper
INFO - 2025-05-06 11:08:57 --> Helper loaded: file_helper
INFO - 2025-05-06 11:08:57 --> Helper loaded: html_helper
INFO - 2025-05-06 11:08:57 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:08:57 --> Controller Class Initialized
INFO - 2025-05-06 19:08:57 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:09:27 --> Config Class Initialized
INFO - 2025-05-06 11:09:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:09:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:09:27 --> Utf8 Class Initialized
INFO - 2025-05-06 11:09:27 --> URI Class Initialized
INFO - 2025-05-06 11:09:27 --> Router Class Initialized
INFO - 2025-05-06 11:09:27 --> Output Class Initialized
INFO - 2025-05-06 11:09:27 --> Security Class Initialized
DEBUG - 2025-05-06 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:09:27 --> Input Class Initialized
INFO - 2025-05-06 11:09:27 --> Language Class Initialized
INFO - 2025-05-06 11:09:27 --> Loader Class Initialized
INFO - 2025-05-06 11:09:27 --> Helper loaded: url_helper
INFO - 2025-05-06 11:09:27 --> Helper loaded: string_helper
INFO - 2025-05-06 11:09:27 --> Helper loaded: form_helper
INFO - 2025-05-06 11:09:27 --> Helper loaded: file_helper
INFO - 2025-05-06 11:09:27 --> Helper loaded: html_helper
INFO - 2025-05-06 11:09:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:09:27 --> Controller Class Initialized
INFO - 2025-05-06 19:09:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:09:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:09:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:09:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:09:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:09:28 --> Final output sent to browser
DEBUG - 2025-05-06 19:09:28 --> Total execution time: 0.1968
INFO - 2025-05-06 11:09:28 --> Config Class Initialized
INFO - 2025-05-06 11:09:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:09:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:09:28 --> Utf8 Class Initialized
INFO - 2025-05-06 11:09:28 --> URI Class Initialized
INFO - 2025-05-06 11:09:28 --> Router Class Initialized
INFO - 2025-05-06 11:09:28 --> Output Class Initialized
INFO - 2025-05-06 11:09:28 --> Security Class Initialized
DEBUG - 2025-05-06 11:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:09:28 --> Input Class Initialized
INFO - 2025-05-06 11:09:28 --> Language Class Initialized
INFO - 2025-05-06 11:09:29 --> Loader Class Initialized
INFO - 2025-05-06 11:09:29 --> Helper loaded: url_helper
INFO - 2025-05-06 11:09:29 --> Helper loaded: string_helper
INFO - 2025-05-06 11:09:29 --> Helper loaded: form_helper
INFO - 2025-05-06 11:09:29 --> Helper loaded: file_helper
INFO - 2025-05-06 11:09:29 --> Helper loaded: html_helper
INFO - 2025-05-06 11:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:09:29 --> Controller Class Initialized
INFO - 2025-05-06 19:09:29 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:10:01 --> Config Class Initialized
INFO - 2025-05-06 11:10:01 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:10:01 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:10:01 --> Utf8 Class Initialized
INFO - 2025-05-06 11:10:01 --> URI Class Initialized
INFO - 2025-05-06 11:10:01 --> Router Class Initialized
INFO - 2025-05-06 11:10:01 --> Output Class Initialized
INFO - 2025-05-06 11:10:01 --> Security Class Initialized
DEBUG - 2025-05-06 11:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:10:01 --> Input Class Initialized
INFO - 2025-05-06 11:10:01 --> Language Class Initialized
INFO - 2025-05-06 11:10:01 --> Loader Class Initialized
INFO - 2025-05-06 11:10:01 --> Helper loaded: url_helper
INFO - 2025-05-06 11:10:01 --> Helper loaded: string_helper
INFO - 2025-05-06 11:10:01 --> Helper loaded: form_helper
INFO - 2025-05-06 11:10:01 --> Helper loaded: file_helper
INFO - 2025-05-06 11:10:01 --> Helper loaded: html_helper
INFO - 2025-05-06 11:10:01 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:10:01 --> Controller Class Initialized
INFO - 2025-05-06 19:10:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:10:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:10:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:10:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:10:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:10:01 --> Final output sent to browser
DEBUG - 2025-05-06 19:10:01 --> Total execution time: 0.1613
INFO - 2025-05-06 11:10:02 --> Config Class Initialized
INFO - 2025-05-06 11:10:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:10:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:10:02 --> Utf8 Class Initialized
INFO - 2025-05-06 11:10:02 --> URI Class Initialized
INFO - 2025-05-06 11:10:02 --> Router Class Initialized
INFO - 2025-05-06 11:10:02 --> Output Class Initialized
INFO - 2025-05-06 11:10:02 --> Security Class Initialized
DEBUG - 2025-05-06 11:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:10:02 --> Input Class Initialized
INFO - 2025-05-06 11:10:02 --> Language Class Initialized
INFO - 2025-05-06 11:10:02 --> Loader Class Initialized
INFO - 2025-05-06 11:10:02 --> Helper loaded: url_helper
INFO - 2025-05-06 11:10:02 --> Helper loaded: string_helper
INFO - 2025-05-06 11:10:02 --> Helper loaded: form_helper
INFO - 2025-05-06 11:10:02 --> Helper loaded: file_helper
INFO - 2025-05-06 11:10:02 --> Helper loaded: html_helper
INFO - 2025-05-06 11:10:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:10:02 --> Controller Class Initialized
INFO - 2025-05-06 19:10:02 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:10:09 --> Config Class Initialized
INFO - 2025-05-06 11:10:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:10:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:10:09 --> Utf8 Class Initialized
INFO - 2025-05-06 11:10:09 --> URI Class Initialized
INFO - 2025-05-06 11:10:09 --> Router Class Initialized
INFO - 2025-05-06 11:10:09 --> Output Class Initialized
INFO - 2025-05-06 11:10:09 --> Security Class Initialized
DEBUG - 2025-05-06 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:10:09 --> Input Class Initialized
INFO - 2025-05-06 11:10:09 --> Language Class Initialized
INFO - 2025-05-06 11:10:09 --> Loader Class Initialized
INFO - 2025-05-06 11:10:09 --> Helper loaded: url_helper
INFO - 2025-05-06 11:10:09 --> Helper loaded: string_helper
INFO - 2025-05-06 11:10:09 --> Helper loaded: form_helper
INFO - 2025-05-06 11:10:09 --> Helper loaded: file_helper
INFO - 2025-05-06 11:10:09 --> Helper loaded: html_helper
INFO - 2025-05-06 11:10:09 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:10:09 --> Controller Class Initialized
INFO - 2025-05-06 19:10:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:10:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:10:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:10:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:10:09 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:10:09 --> Final output sent to browser
DEBUG - 2025-05-06 19:10:09 --> Total execution time: 0.1039
INFO - 2025-05-06 11:10:27 --> Config Class Initialized
INFO - 2025-05-06 11:10:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:10:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:10:27 --> Utf8 Class Initialized
INFO - 2025-05-06 11:10:27 --> URI Class Initialized
INFO - 2025-05-06 11:10:27 --> Router Class Initialized
INFO - 2025-05-06 11:10:27 --> Output Class Initialized
INFO - 2025-05-06 11:10:27 --> Security Class Initialized
DEBUG - 2025-05-06 11:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:10:27 --> Input Class Initialized
INFO - 2025-05-06 11:10:27 --> Language Class Initialized
INFO - 2025-05-06 11:10:27 --> Loader Class Initialized
INFO - 2025-05-06 11:10:27 --> Helper loaded: url_helper
INFO - 2025-05-06 11:10:27 --> Helper loaded: string_helper
INFO - 2025-05-06 11:10:27 --> Helper loaded: form_helper
INFO - 2025-05-06 11:10:27 --> Helper loaded: file_helper
INFO - 2025-05-06 11:10:27 --> Helper loaded: html_helper
INFO - 2025-05-06 11:10:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:10:27 --> Controller Class Initialized
INFO - 2025-05-06 19:10:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:10:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:10:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:10:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:10:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:10:27 --> Final output sent to browser
DEBUG - 2025-05-06 19:10:27 --> Total execution time: 0.1362
INFO - 2025-05-06 11:10:29 --> Config Class Initialized
INFO - 2025-05-06 11:10:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:10:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:10:29 --> Utf8 Class Initialized
INFO - 2025-05-06 11:10:29 --> URI Class Initialized
INFO - 2025-05-06 11:10:29 --> Router Class Initialized
INFO - 2025-05-06 11:10:29 --> Output Class Initialized
INFO - 2025-05-06 11:10:29 --> Security Class Initialized
DEBUG - 2025-05-06 11:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:10:29 --> Input Class Initialized
INFO - 2025-05-06 11:10:29 --> Language Class Initialized
INFO - 2025-05-06 11:10:29 --> Loader Class Initialized
INFO - 2025-05-06 11:10:29 --> Helper loaded: url_helper
INFO - 2025-05-06 11:10:29 --> Helper loaded: string_helper
INFO - 2025-05-06 11:10:29 --> Helper loaded: form_helper
INFO - 2025-05-06 11:10:29 --> Helper loaded: file_helper
INFO - 2025-05-06 11:10:29 --> Helper loaded: html_helper
INFO - 2025-05-06 11:10:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:10:30 --> Controller Class Initialized
INFO - 2025-05-06 19:10:30 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:11:37 --> Config Class Initialized
INFO - 2025-05-06 11:11:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:11:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:11:37 --> Utf8 Class Initialized
INFO - 2025-05-06 11:11:37 --> URI Class Initialized
INFO - 2025-05-06 11:11:37 --> Router Class Initialized
INFO - 2025-05-06 11:11:37 --> Output Class Initialized
INFO - 2025-05-06 11:11:37 --> Security Class Initialized
DEBUG - 2025-05-06 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:11:37 --> Input Class Initialized
INFO - 2025-05-06 11:11:37 --> Language Class Initialized
INFO - 2025-05-06 11:11:37 --> Loader Class Initialized
INFO - 2025-05-06 11:11:37 --> Helper loaded: url_helper
INFO - 2025-05-06 11:11:37 --> Helper loaded: string_helper
INFO - 2025-05-06 11:11:37 --> Helper loaded: form_helper
INFO - 2025-05-06 11:11:37 --> Helper loaded: file_helper
INFO - 2025-05-06 11:11:37 --> Helper loaded: html_helper
INFO - 2025-05-06 11:11:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:11:37 --> Controller Class Initialized
INFO - 2025-05-06 19:11:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:11:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:11:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:11:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:11:37 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:11:37 --> Final output sent to browser
DEBUG - 2025-05-06 19:11:37 --> Total execution time: 0.1103
INFO - 2025-05-06 11:11:38 --> Config Class Initialized
INFO - 2025-05-06 11:11:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:11:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:11:38 --> Utf8 Class Initialized
INFO - 2025-05-06 11:11:38 --> URI Class Initialized
INFO - 2025-05-06 11:11:38 --> Router Class Initialized
INFO - 2025-05-06 11:11:38 --> Output Class Initialized
INFO - 2025-05-06 11:11:38 --> Security Class Initialized
DEBUG - 2025-05-06 11:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:11:38 --> Input Class Initialized
INFO - 2025-05-06 11:11:38 --> Language Class Initialized
INFO - 2025-05-06 11:11:38 --> Loader Class Initialized
INFO - 2025-05-06 11:11:38 --> Helper loaded: url_helper
INFO - 2025-05-06 11:11:38 --> Helper loaded: string_helper
INFO - 2025-05-06 11:11:38 --> Helper loaded: form_helper
INFO - 2025-05-06 11:11:38 --> Helper loaded: file_helper
INFO - 2025-05-06 11:11:38 --> Helper loaded: html_helper
INFO - 2025-05-06 11:11:38 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:11:38 --> Controller Class Initialized
INFO - 2025-05-06 19:11:38 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:11:49 --> Config Class Initialized
INFO - 2025-05-06 11:11:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:11:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:11:49 --> Utf8 Class Initialized
INFO - 2025-05-06 11:11:49 --> URI Class Initialized
INFO - 2025-05-06 11:11:49 --> Router Class Initialized
INFO - 2025-05-06 11:11:49 --> Output Class Initialized
INFO - 2025-05-06 11:11:49 --> Security Class Initialized
DEBUG - 2025-05-06 11:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:11:49 --> Input Class Initialized
INFO - 2025-05-06 11:11:49 --> Language Class Initialized
INFO - 2025-05-06 11:11:49 --> Loader Class Initialized
INFO - 2025-05-06 11:11:49 --> Helper loaded: url_helper
INFO - 2025-05-06 11:11:49 --> Helper loaded: string_helper
INFO - 2025-05-06 11:11:49 --> Helper loaded: form_helper
INFO - 2025-05-06 11:11:49 --> Helper loaded: file_helper
INFO - 2025-05-06 11:11:49 --> Helper loaded: html_helper
INFO - 2025-05-06 11:11:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:11:49 --> Controller Class Initialized
INFO - 2025-05-06 19:11:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:11:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:11:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:11:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:11:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:11:49 --> Final output sent to browser
DEBUG - 2025-05-06 19:11:49 --> Total execution time: 0.1245
INFO - 2025-05-06 11:11:50 --> Config Class Initialized
INFO - 2025-05-06 11:11:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:11:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:11:50 --> Utf8 Class Initialized
INFO - 2025-05-06 11:11:50 --> URI Class Initialized
INFO - 2025-05-06 11:11:50 --> Router Class Initialized
INFO - 2025-05-06 11:11:50 --> Output Class Initialized
INFO - 2025-05-06 11:11:50 --> Security Class Initialized
DEBUG - 2025-05-06 11:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:11:50 --> Input Class Initialized
INFO - 2025-05-06 11:11:50 --> Language Class Initialized
INFO - 2025-05-06 11:11:50 --> Loader Class Initialized
INFO - 2025-05-06 11:11:50 --> Helper loaded: url_helper
INFO - 2025-05-06 11:11:50 --> Helper loaded: string_helper
INFO - 2025-05-06 11:11:50 --> Helper loaded: form_helper
INFO - 2025-05-06 11:11:50 --> Helper loaded: file_helper
INFO - 2025-05-06 11:11:50 --> Helper loaded: html_helper
INFO - 2025-05-06 11:11:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:11:50 --> Controller Class Initialized
INFO - 2025-05-06 19:11:50 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:12:11 --> Config Class Initialized
INFO - 2025-05-06 11:12:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:12:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:12:11 --> Utf8 Class Initialized
INFO - 2025-05-06 11:12:11 --> URI Class Initialized
INFO - 2025-05-06 11:12:11 --> Router Class Initialized
INFO - 2025-05-06 11:12:11 --> Output Class Initialized
INFO - 2025-05-06 11:12:11 --> Security Class Initialized
DEBUG - 2025-05-06 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:12:11 --> Input Class Initialized
INFO - 2025-05-06 11:12:11 --> Language Class Initialized
INFO - 2025-05-06 11:12:11 --> Loader Class Initialized
INFO - 2025-05-06 11:12:11 --> Helper loaded: url_helper
INFO - 2025-05-06 11:12:11 --> Helper loaded: string_helper
INFO - 2025-05-06 11:12:11 --> Helper loaded: form_helper
INFO - 2025-05-06 11:12:11 --> Helper loaded: file_helper
INFO - 2025-05-06 11:12:11 --> Helper loaded: html_helper
INFO - 2025-05-06 11:12:11 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:12:11 --> Controller Class Initialized
INFO - 2025-05-06 19:12:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:12:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:12:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:12:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:12:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:12:11 --> Final output sent to browser
DEBUG - 2025-05-06 19:12:11 --> Total execution time: 0.1055
INFO - 2025-05-06 11:12:14 --> Config Class Initialized
INFO - 2025-05-06 11:12:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:12:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:12:14 --> Utf8 Class Initialized
INFO - 2025-05-06 11:12:14 --> URI Class Initialized
INFO - 2025-05-06 11:12:14 --> Router Class Initialized
INFO - 2025-05-06 11:12:14 --> Output Class Initialized
INFO - 2025-05-06 11:12:14 --> Security Class Initialized
DEBUG - 2025-05-06 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:12:14 --> Input Class Initialized
INFO - 2025-05-06 11:12:14 --> Language Class Initialized
INFO - 2025-05-06 11:12:14 --> Loader Class Initialized
INFO - 2025-05-06 11:12:14 --> Helper loaded: url_helper
INFO - 2025-05-06 11:12:14 --> Helper loaded: string_helper
INFO - 2025-05-06 11:12:14 --> Helper loaded: form_helper
INFO - 2025-05-06 11:12:14 --> Helper loaded: file_helper
INFO - 2025-05-06 11:12:14 --> Helper loaded: html_helper
INFO - 2025-05-06 11:12:14 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:12:14 --> Controller Class Initialized
INFO - 2025-05-06 19:12:14 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:12:16 --> Config Class Initialized
INFO - 2025-05-06 11:12:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:12:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:12:16 --> Utf8 Class Initialized
INFO - 2025-05-06 11:12:16 --> URI Class Initialized
INFO - 2025-05-06 11:12:16 --> Router Class Initialized
INFO - 2025-05-06 11:12:16 --> Output Class Initialized
INFO - 2025-05-06 11:12:16 --> Security Class Initialized
DEBUG - 2025-05-06 11:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:12:16 --> Input Class Initialized
INFO - 2025-05-06 11:12:16 --> Language Class Initialized
INFO - 2025-05-06 11:12:16 --> Loader Class Initialized
INFO - 2025-05-06 11:12:16 --> Helper loaded: url_helper
INFO - 2025-05-06 11:12:16 --> Helper loaded: string_helper
INFO - 2025-05-06 11:12:16 --> Helper loaded: form_helper
INFO - 2025-05-06 11:12:16 --> Helper loaded: file_helper
INFO - 2025-05-06 11:12:16 --> Helper loaded: html_helper
INFO - 2025-05-06 11:12:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:12:16 --> Controller Class Initialized
INFO - 2025-05-06 19:12:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:12:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:12:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:12:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:12:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:12:16 --> Final output sent to browser
DEBUG - 2025-05-06 19:12:16 --> Total execution time: 0.1125
INFO - 2025-05-06 11:12:18 --> Config Class Initialized
INFO - 2025-05-06 11:12:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:12:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:12:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:12:18 --> URI Class Initialized
INFO - 2025-05-06 11:12:18 --> Router Class Initialized
INFO - 2025-05-06 11:12:18 --> Output Class Initialized
INFO - 2025-05-06 11:12:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:12:18 --> Input Class Initialized
INFO - 2025-05-06 11:12:18 --> Language Class Initialized
INFO - 2025-05-06 11:12:18 --> Loader Class Initialized
INFO - 2025-05-06 11:12:18 --> Helper loaded: url_helper
INFO - 2025-05-06 11:12:18 --> Helper loaded: string_helper
INFO - 2025-05-06 11:12:18 --> Helper loaded: form_helper
INFO - 2025-05-06 11:12:18 --> Helper loaded: file_helper
INFO - 2025-05-06 11:12:18 --> Helper loaded: html_helper
INFO - 2025-05-06 11:12:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:12:18 --> Controller Class Initialized
INFO - 2025-05-06 19:12:18 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:14:13 --> Config Class Initialized
INFO - 2025-05-06 11:14:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:14:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:14:13 --> Utf8 Class Initialized
INFO - 2025-05-06 11:14:13 --> URI Class Initialized
INFO - 2025-05-06 11:14:13 --> Router Class Initialized
INFO - 2025-05-06 11:14:13 --> Output Class Initialized
INFO - 2025-05-06 11:14:13 --> Security Class Initialized
DEBUG - 2025-05-06 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:14:13 --> Input Class Initialized
INFO - 2025-05-06 11:14:13 --> Language Class Initialized
INFO - 2025-05-06 11:14:13 --> Loader Class Initialized
INFO - 2025-05-06 11:14:13 --> Helper loaded: url_helper
INFO - 2025-05-06 11:14:13 --> Helper loaded: string_helper
INFO - 2025-05-06 11:14:13 --> Helper loaded: form_helper
INFO - 2025-05-06 11:14:13 --> Helper loaded: file_helper
INFO - 2025-05-06 11:14:13 --> Helper loaded: html_helper
INFO - 2025-05-06 11:14:13 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:14:13 --> Controller Class Initialized
INFO - 2025-05-06 19:14:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:14:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:14:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:14:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:14:13 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:14:13 --> Final output sent to browser
DEBUG - 2025-05-06 19:14:13 --> Total execution time: 0.1356
INFO - 2025-05-06 11:14:16 --> Config Class Initialized
INFO - 2025-05-06 11:14:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:14:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:14:16 --> Utf8 Class Initialized
INFO - 2025-05-06 11:14:16 --> URI Class Initialized
INFO - 2025-05-06 11:14:16 --> Router Class Initialized
INFO - 2025-05-06 11:14:16 --> Output Class Initialized
INFO - 2025-05-06 11:14:16 --> Security Class Initialized
DEBUG - 2025-05-06 11:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:14:16 --> Input Class Initialized
INFO - 2025-05-06 11:14:16 --> Language Class Initialized
INFO - 2025-05-06 11:14:16 --> Loader Class Initialized
INFO - 2025-05-06 11:14:16 --> Helper loaded: url_helper
INFO - 2025-05-06 11:14:16 --> Helper loaded: string_helper
INFO - 2025-05-06 11:14:16 --> Helper loaded: form_helper
INFO - 2025-05-06 11:14:16 --> Helper loaded: file_helper
INFO - 2025-05-06 11:14:16 --> Helper loaded: html_helper
INFO - 2025-05-06 11:14:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:14:16 --> Controller Class Initialized
INFO - 2025-05-06 19:14:16 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:20:41 --> Config Class Initialized
INFO - 2025-05-06 11:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:20:41 --> Utf8 Class Initialized
INFO - 2025-05-06 11:20:41 --> URI Class Initialized
INFO - 2025-05-06 11:20:41 --> Router Class Initialized
INFO - 2025-05-06 11:20:41 --> Output Class Initialized
INFO - 2025-05-06 11:20:41 --> Security Class Initialized
DEBUG - 2025-05-06 11:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:20:41 --> Input Class Initialized
INFO - 2025-05-06 11:20:41 --> Language Class Initialized
INFO - 2025-05-06 11:20:41 --> Loader Class Initialized
INFO - 2025-05-06 11:20:41 --> Helper loaded: url_helper
INFO - 2025-05-06 11:20:41 --> Helper loaded: string_helper
INFO - 2025-05-06 11:20:41 --> Helper loaded: form_helper
INFO - 2025-05-06 11:20:41 --> Helper loaded: file_helper
INFO - 2025-05-06 11:20:41 --> Helper loaded: html_helper
INFO - 2025-05-06 11:20:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:20:41 --> Controller Class Initialized
INFO - 2025-05-06 19:20:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:20:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:20:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:20:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:20:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:20:41 --> Final output sent to browser
DEBUG - 2025-05-06 19:20:41 --> Total execution time: 0.1243
INFO - 2025-05-06 11:20:43 --> Config Class Initialized
INFO - 2025-05-06 11:20:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:20:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:20:43 --> Utf8 Class Initialized
INFO - 2025-05-06 11:20:43 --> URI Class Initialized
INFO - 2025-05-06 11:20:43 --> Router Class Initialized
INFO - 2025-05-06 11:20:43 --> Output Class Initialized
INFO - 2025-05-06 11:20:43 --> Security Class Initialized
DEBUG - 2025-05-06 11:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:20:43 --> Input Class Initialized
INFO - 2025-05-06 11:20:43 --> Language Class Initialized
INFO - 2025-05-06 11:20:43 --> Loader Class Initialized
INFO - 2025-05-06 11:20:43 --> Helper loaded: url_helper
INFO - 2025-05-06 11:20:43 --> Helper loaded: string_helper
INFO - 2025-05-06 11:20:43 --> Helper loaded: form_helper
INFO - 2025-05-06 11:20:43 --> Helper loaded: file_helper
INFO - 2025-05-06 11:20:43 --> Helper loaded: html_helper
INFO - 2025-05-06 11:20:43 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:20:43 --> Controller Class Initialized
INFO - 2025-05-06 19:20:43 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:25:04 --> Config Class Initialized
INFO - 2025-05-06 11:25:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:25:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:25:04 --> Utf8 Class Initialized
INFO - 2025-05-06 11:25:04 --> URI Class Initialized
INFO - 2025-05-06 11:25:04 --> Router Class Initialized
INFO - 2025-05-06 11:25:04 --> Output Class Initialized
INFO - 2025-05-06 11:25:04 --> Security Class Initialized
DEBUG - 2025-05-06 11:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:25:04 --> Input Class Initialized
INFO - 2025-05-06 11:25:04 --> Language Class Initialized
INFO - 2025-05-06 11:25:04 --> Loader Class Initialized
INFO - 2025-05-06 11:25:04 --> Helper loaded: url_helper
INFO - 2025-05-06 11:25:04 --> Helper loaded: string_helper
INFO - 2025-05-06 11:25:04 --> Helper loaded: form_helper
INFO - 2025-05-06 11:25:04 --> Helper loaded: file_helper
INFO - 2025-05-06 11:25:04 --> Helper loaded: html_helper
INFO - 2025-05-06 11:25:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:25:04 --> Controller Class Initialized
INFO - 2025-05-06 19:25:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:25:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:25:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:25:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:25:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:25:04 --> Final output sent to browser
DEBUG - 2025-05-06 19:25:04 --> Total execution time: 0.2996
INFO - 2025-05-06 11:25:06 --> Config Class Initialized
INFO - 2025-05-06 11:25:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:25:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:25:06 --> Utf8 Class Initialized
INFO - 2025-05-06 11:25:06 --> URI Class Initialized
INFO - 2025-05-06 11:25:06 --> Router Class Initialized
INFO - 2025-05-06 11:25:06 --> Output Class Initialized
INFO - 2025-05-06 11:25:06 --> Security Class Initialized
DEBUG - 2025-05-06 11:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:25:06 --> Input Class Initialized
INFO - 2025-05-06 11:25:06 --> Language Class Initialized
INFO - 2025-05-06 11:25:06 --> Loader Class Initialized
INFO - 2025-05-06 11:25:06 --> Helper loaded: url_helper
INFO - 2025-05-06 11:25:06 --> Helper loaded: string_helper
INFO - 2025-05-06 11:25:06 --> Helper loaded: form_helper
INFO - 2025-05-06 11:25:06 --> Helper loaded: file_helper
INFO - 2025-05-06 11:25:06 --> Helper loaded: html_helper
INFO - 2025-05-06 11:25:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:25:06 --> Controller Class Initialized
INFO - 2025-05-06 19:25:06 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:27:38 --> Config Class Initialized
INFO - 2025-05-06 11:27:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:27:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:27:38 --> Utf8 Class Initialized
INFO - 2025-05-06 11:27:38 --> URI Class Initialized
INFO - 2025-05-06 11:27:38 --> Router Class Initialized
INFO - 2025-05-06 11:27:38 --> Output Class Initialized
INFO - 2025-05-06 11:27:38 --> Security Class Initialized
DEBUG - 2025-05-06 11:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:27:38 --> Input Class Initialized
INFO - 2025-05-06 11:27:38 --> Language Class Initialized
INFO - 2025-05-06 11:27:38 --> Loader Class Initialized
INFO - 2025-05-06 11:27:38 --> Helper loaded: url_helper
INFO - 2025-05-06 11:27:38 --> Helper loaded: string_helper
INFO - 2025-05-06 11:27:38 --> Helper loaded: form_helper
INFO - 2025-05-06 11:27:38 --> Helper loaded: file_helper
INFO - 2025-05-06 11:27:38 --> Helper loaded: html_helper
INFO - 2025-05-06 11:27:38 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:27:38 --> Controller Class Initialized
INFO - 2025-05-06 19:27:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:27:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:27:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:27:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:27:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:27:38 --> Final output sent to browser
DEBUG - 2025-05-06 19:27:38 --> Total execution time: 0.1588
INFO - 2025-05-06 11:27:40 --> Config Class Initialized
INFO - 2025-05-06 11:27:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:27:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:27:40 --> Utf8 Class Initialized
INFO - 2025-05-06 11:27:40 --> URI Class Initialized
INFO - 2025-05-06 11:27:40 --> Router Class Initialized
INFO - 2025-05-06 11:27:40 --> Output Class Initialized
INFO - 2025-05-06 11:27:40 --> Security Class Initialized
DEBUG - 2025-05-06 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:27:40 --> Input Class Initialized
INFO - 2025-05-06 11:27:40 --> Language Class Initialized
INFO - 2025-05-06 11:27:40 --> Loader Class Initialized
INFO - 2025-05-06 11:27:40 --> Helper loaded: url_helper
INFO - 2025-05-06 11:27:40 --> Helper loaded: string_helper
INFO - 2025-05-06 11:27:40 --> Helper loaded: form_helper
INFO - 2025-05-06 11:27:40 --> Helper loaded: file_helper
INFO - 2025-05-06 11:27:40 --> Helper loaded: html_helper
INFO - 2025-05-06 11:27:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:27:40 --> Controller Class Initialized
INFO - 2025-05-06 19:27:40 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:30:15 --> Config Class Initialized
INFO - 2025-05-06 11:30:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:30:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:30:15 --> Utf8 Class Initialized
INFO - 2025-05-06 11:30:15 --> URI Class Initialized
INFO - 2025-05-06 11:30:15 --> Router Class Initialized
INFO - 2025-05-06 11:30:15 --> Output Class Initialized
INFO - 2025-05-06 11:30:15 --> Security Class Initialized
DEBUG - 2025-05-06 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:30:15 --> Input Class Initialized
INFO - 2025-05-06 11:30:15 --> Language Class Initialized
INFO - 2025-05-06 11:30:15 --> Loader Class Initialized
INFO - 2025-05-06 11:30:15 --> Helper loaded: url_helper
INFO - 2025-05-06 11:30:15 --> Helper loaded: string_helper
INFO - 2025-05-06 11:30:15 --> Helper loaded: form_helper
INFO - 2025-05-06 11:30:15 --> Helper loaded: file_helper
INFO - 2025-05-06 11:30:15 --> Helper loaded: html_helper
INFO - 2025-05-06 11:30:15 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:30:15 --> Controller Class Initialized
INFO - 2025-05-06 19:30:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:30:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:30:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:30:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:30:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:30:15 --> Final output sent to browser
DEBUG - 2025-05-06 19:30:15 --> Total execution time: 0.1161
INFO - 2025-05-06 11:30:18 --> Config Class Initialized
INFO - 2025-05-06 11:30:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:30:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:30:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:30:18 --> URI Class Initialized
INFO - 2025-05-06 11:30:18 --> Router Class Initialized
INFO - 2025-05-06 11:30:18 --> Output Class Initialized
INFO - 2025-05-06 11:30:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:30:18 --> Input Class Initialized
INFO - 2025-05-06 11:30:18 --> Language Class Initialized
INFO - 2025-05-06 11:30:18 --> Loader Class Initialized
INFO - 2025-05-06 11:30:18 --> Helper loaded: url_helper
INFO - 2025-05-06 11:30:18 --> Helper loaded: string_helper
INFO - 2025-05-06 11:30:18 --> Helper loaded: form_helper
INFO - 2025-05-06 11:30:18 --> Helper loaded: file_helper
INFO - 2025-05-06 11:30:18 --> Helper loaded: html_helper
INFO - 2025-05-06 11:30:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:30:18 --> Controller Class Initialized
INFO - 2025-05-06 19:30:18 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:31:14 --> Config Class Initialized
INFO - 2025-05-06 11:31:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:31:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:31:14 --> Utf8 Class Initialized
INFO - 2025-05-06 11:31:14 --> URI Class Initialized
INFO - 2025-05-06 11:31:14 --> Router Class Initialized
INFO - 2025-05-06 11:31:14 --> Output Class Initialized
INFO - 2025-05-06 11:31:14 --> Security Class Initialized
DEBUG - 2025-05-06 11:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:31:14 --> Input Class Initialized
INFO - 2025-05-06 11:31:14 --> Language Class Initialized
INFO - 2025-05-06 11:31:14 --> Loader Class Initialized
INFO - 2025-05-06 11:31:14 --> Helper loaded: url_helper
INFO - 2025-05-06 11:31:14 --> Helper loaded: string_helper
INFO - 2025-05-06 11:31:14 --> Helper loaded: form_helper
INFO - 2025-05-06 11:31:14 --> Helper loaded: file_helper
INFO - 2025-05-06 11:31:14 --> Helper loaded: html_helper
INFO - 2025-05-06 11:31:14 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:31:14 --> Controller Class Initialized
INFO - 2025-05-06 19:31:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:31:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:31:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:31:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:31:14 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:31:14 --> Final output sent to browser
DEBUG - 2025-05-06 19:31:14 --> Total execution time: 0.0881
INFO - 2025-05-06 11:31:16 --> Config Class Initialized
INFO - 2025-05-06 11:31:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:31:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:31:16 --> Utf8 Class Initialized
INFO - 2025-05-06 11:31:16 --> URI Class Initialized
INFO - 2025-05-06 11:31:16 --> Router Class Initialized
INFO - 2025-05-06 11:31:16 --> Output Class Initialized
INFO - 2025-05-06 11:31:16 --> Security Class Initialized
DEBUG - 2025-05-06 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:31:16 --> Input Class Initialized
INFO - 2025-05-06 11:31:16 --> Language Class Initialized
INFO - 2025-05-06 11:31:16 --> Loader Class Initialized
INFO - 2025-05-06 11:31:16 --> Helper loaded: url_helper
INFO - 2025-05-06 11:31:16 --> Helper loaded: string_helper
INFO - 2025-05-06 11:31:16 --> Helper loaded: form_helper
INFO - 2025-05-06 11:31:16 --> Helper loaded: file_helper
INFO - 2025-05-06 11:31:16 --> Helper loaded: html_helper
INFO - 2025-05-06 11:31:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:31:16 --> Controller Class Initialized
INFO - 2025-05-06 19:31:16 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:33:22 --> Config Class Initialized
INFO - 2025-05-06 11:33:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:22 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:22 --> URI Class Initialized
INFO - 2025-05-06 11:33:22 --> Router Class Initialized
INFO - 2025-05-06 11:33:22 --> Output Class Initialized
INFO - 2025-05-06 11:33:22 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:22 --> Input Class Initialized
INFO - 2025-05-06 11:33:22 --> Language Class Initialized
INFO - 2025-05-06 11:33:22 --> Loader Class Initialized
INFO - 2025-05-06 11:33:22 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:22 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:22 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:22 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:22 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:22 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:22 --> Controller Class Initialized
INFO - 2025-05-06 19:33:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:33:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:33:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:33:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:33:22 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:33:22 --> Final output sent to browser
DEBUG - 2025-05-06 19:33:22 --> Total execution time: 0.0955
INFO - 2025-05-06 11:33:24 --> Config Class Initialized
INFO - 2025-05-06 11:33:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:24 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:24 --> URI Class Initialized
INFO - 2025-05-06 11:33:24 --> Router Class Initialized
INFO - 2025-05-06 11:33:24 --> Output Class Initialized
INFO - 2025-05-06 11:33:24 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:24 --> Input Class Initialized
INFO - 2025-05-06 11:33:24 --> Language Class Initialized
INFO - 2025-05-06 11:33:24 --> Loader Class Initialized
INFO - 2025-05-06 11:33:24 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:24 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:24 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:24 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:24 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:24 --> Controller Class Initialized
INFO - 2025-05-06 19:33:24 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:33:40 --> Config Class Initialized
INFO - 2025-05-06 11:33:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:40 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:40 --> URI Class Initialized
INFO - 2025-05-06 11:33:40 --> Router Class Initialized
INFO - 2025-05-06 11:33:40 --> Output Class Initialized
INFO - 2025-05-06 11:33:40 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:40 --> Input Class Initialized
INFO - 2025-05-06 11:33:40 --> Language Class Initialized
INFO - 2025-05-06 11:33:40 --> Loader Class Initialized
INFO - 2025-05-06 11:33:40 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:40 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:40 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:40 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:40 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:40 --> Controller Class Initialized
INFO - 2025-05-06 19:33:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:33:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:33:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:33:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:33:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:33:41 --> Final output sent to browser
DEBUG - 2025-05-06 19:33:41 --> Total execution time: 0.1013
INFO - 2025-05-06 11:33:42 --> Config Class Initialized
INFO - 2025-05-06 11:33:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:42 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:42 --> URI Class Initialized
INFO - 2025-05-06 11:33:42 --> Router Class Initialized
INFO - 2025-05-06 11:33:42 --> Output Class Initialized
INFO - 2025-05-06 11:33:42 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:42 --> Input Class Initialized
INFO - 2025-05-06 11:33:42 --> Language Class Initialized
INFO - 2025-05-06 11:33:42 --> Loader Class Initialized
INFO - 2025-05-06 11:33:42 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:42 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:42 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:42 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:42 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:42 --> Controller Class Initialized
INFO - 2025-05-06 19:33:42 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:33:43 --> Config Class Initialized
INFO - 2025-05-06 11:33:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:43 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:43 --> URI Class Initialized
INFO - 2025-05-06 11:33:43 --> Router Class Initialized
INFO - 2025-05-06 11:33:43 --> Output Class Initialized
INFO - 2025-05-06 11:33:43 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:43 --> Input Class Initialized
INFO - 2025-05-06 11:33:43 --> Language Class Initialized
INFO - 2025-05-06 11:33:43 --> Loader Class Initialized
INFO - 2025-05-06 11:33:43 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:43 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:43 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:43 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:43 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:43 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:43 --> Controller Class Initialized
INFO - 2025-05-06 19:33:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:33:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:33:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:33:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:33:43 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:33:43 --> Final output sent to browser
DEBUG - 2025-05-06 19:33:43 --> Total execution time: 0.1079
INFO - 2025-05-06 11:33:45 --> Config Class Initialized
INFO - 2025-05-06 11:33:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:33:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:33:45 --> Utf8 Class Initialized
INFO - 2025-05-06 11:33:45 --> URI Class Initialized
INFO - 2025-05-06 11:33:45 --> Router Class Initialized
INFO - 2025-05-06 11:33:45 --> Output Class Initialized
INFO - 2025-05-06 11:33:45 --> Security Class Initialized
DEBUG - 2025-05-06 11:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:33:45 --> Input Class Initialized
INFO - 2025-05-06 11:33:45 --> Language Class Initialized
INFO - 2025-05-06 11:33:45 --> Loader Class Initialized
INFO - 2025-05-06 11:33:45 --> Helper loaded: url_helper
INFO - 2025-05-06 11:33:45 --> Helper loaded: string_helper
INFO - 2025-05-06 11:33:45 --> Helper loaded: form_helper
INFO - 2025-05-06 11:33:45 --> Helper loaded: file_helper
INFO - 2025-05-06 11:33:45 --> Helper loaded: html_helper
INFO - 2025-05-06 11:33:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:33:45 --> Controller Class Initialized
INFO - 2025-05-06 19:33:45 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:36:16 --> Config Class Initialized
INFO - 2025-05-06 11:36:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:36:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:36:16 --> Utf8 Class Initialized
INFO - 2025-05-06 11:36:16 --> URI Class Initialized
INFO - 2025-05-06 11:36:16 --> Router Class Initialized
INFO - 2025-05-06 11:36:16 --> Output Class Initialized
INFO - 2025-05-06 11:36:16 --> Security Class Initialized
DEBUG - 2025-05-06 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:36:16 --> Input Class Initialized
INFO - 2025-05-06 11:36:16 --> Language Class Initialized
INFO - 2025-05-06 11:36:16 --> Loader Class Initialized
INFO - 2025-05-06 11:36:16 --> Helper loaded: url_helper
INFO - 2025-05-06 11:36:16 --> Helper loaded: string_helper
INFO - 2025-05-06 11:36:16 --> Helper loaded: form_helper
INFO - 2025-05-06 11:36:16 --> Helper loaded: file_helper
INFO - 2025-05-06 11:36:16 --> Helper loaded: html_helper
INFO - 2025-05-06 11:36:16 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:36:16 --> Controller Class Initialized
INFO - 2025-05-06 19:36:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:36:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:36:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:36:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:36:16 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:36:16 --> Final output sent to browser
DEBUG - 2025-05-06 19:36:16 --> Total execution time: 0.1187
INFO - 2025-05-06 11:36:18 --> Config Class Initialized
INFO - 2025-05-06 11:36:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:36:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:36:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:36:18 --> URI Class Initialized
INFO - 2025-05-06 11:36:18 --> Router Class Initialized
INFO - 2025-05-06 11:36:18 --> Output Class Initialized
INFO - 2025-05-06 11:36:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:36:18 --> Input Class Initialized
INFO - 2025-05-06 11:36:18 --> Language Class Initialized
INFO - 2025-05-06 11:36:18 --> Loader Class Initialized
INFO - 2025-05-06 11:36:18 --> Helper loaded: url_helper
INFO - 2025-05-06 11:36:18 --> Helper loaded: string_helper
INFO - 2025-05-06 11:36:18 --> Helper loaded: form_helper
INFO - 2025-05-06 11:36:18 --> Helper loaded: file_helper
INFO - 2025-05-06 11:36:18 --> Helper loaded: html_helper
INFO - 2025-05-06 11:36:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:36:18 --> Controller Class Initialized
INFO - 2025-05-06 19:36:18 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:38:17 --> Config Class Initialized
INFO - 2025-05-06 11:38:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:38:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:38:17 --> Utf8 Class Initialized
INFO - 2025-05-06 11:38:17 --> URI Class Initialized
INFO - 2025-05-06 11:38:17 --> Router Class Initialized
INFO - 2025-05-06 11:38:17 --> Output Class Initialized
INFO - 2025-05-06 11:38:17 --> Security Class Initialized
DEBUG - 2025-05-06 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:38:17 --> Input Class Initialized
INFO - 2025-05-06 11:38:17 --> Language Class Initialized
INFO - 2025-05-06 11:38:17 --> Loader Class Initialized
INFO - 2025-05-06 11:38:17 --> Helper loaded: url_helper
INFO - 2025-05-06 11:38:17 --> Helper loaded: string_helper
INFO - 2025-05-06 11:38:17 --> Helper loaded: form_helper
INFO - 2025-05-06 11:38:17 --> Helper loaded: file_helper
INFO - 2025-05-06 11:38:17 --> Helper loaded: html_helper
INFO - 2025-05-06 11:38:17 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:38:17 --> Controller Class Initialized
INFO - 2025-05-06 19:38:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:38:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:38:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:38:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:38:17 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:38:17 --> Final output sent to browser
DEBUG - 2025-05-06 19:38:17 --> Total execution time: 0.1392
INFO - 2025-05-06 11:38:19 --> Config Class Initialized
INFO - 2025-05-06 11:38:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:38:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:38:19 --> Utf8 Class Initialized
INFO - 2025-05-06 11:38:19 --> URI Class Initialized
INFO - 2025-05-06 11:38:19 --> Router Class Initialized
INFO - 2025-05-06 11:38:19 --> Output Class Initialized
INFO - 2025-05-06 11:38:19 --> Security Class Initialized
DEBUG - 2025-05-06 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:38:19 --> Input Class Initialized
INFO - 2025-05-06 11:38:19 --> Language Class Initialized
INFO - 2025-05-06 11:38:19 --> Loader Class Initialized
INFO - 2025-05-06 11:38:19 --> Helper loaded: url_helper
INFO - 2025-05-06 11:38:19 --> Helper loaded: string_helper
INFO - 2025-05-06 11:38:19 --> Helper loaded: form_helper
INFO - 2025-05-06 11:38:19 --> Helper loaded: file_helper
INFO - 2025-05-06 11:38:19 --> Helper loaded: html_helper
INFO - 2025-05-06 11:38:19 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:38:19 --> Controller Class Initialized
INFO - 2025-05-06 19:38:19 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:41:05 --> Config Class Initialized
INFO - 2025-05-06 11:41:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:41:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:41:05 --> Utf8 Class Initialized
INFO - 2025-05-06 11:41:05 --> URI Class Initialized
INFO - 2025-05-06 11:41:05 --> Router Class Initialized
INFO - 2025-05-06 11:41:05 --> Output Class Initialized
INFO - 2025-05-06 11:41:05 --> Security Class Initialized
DEBUG - 2025-05-06 11:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:41:05 --> Input Class Initialized
INFO - 2025-05-06 11:41:05 --> Language Class Initialized
INFO - 2025-05-06 11:41:05 --> Loader Class Initialized
INFO - 2025-05-06 11:41:05 --> Helper loaded: url_helper
INFO - 2025-05-06 11:41:05 --> Helper loaded: string_helper
INFO - 2025-05-06 11:41:05 --> Helper loaded: form_helper
INFO - 2025-05-06 11:41:05 --> Helper loaded: file_helper
INFO - 2025-05-06 11:41:05 --> Helper loaded: html_helper
INFO - 2025-05-06 11:41:05 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:41:05 --> Controller Class Initialized
INFO - 2025-05-06 19:41:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:41:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:41:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:41:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:41:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:41:05 --> Final output sent to browser
DEBUG - 2025-05-06 19:41:05 --> Total execution time: 0.1695
INFO - 2025-05-06 11:41:07 --> Config Class Initialized
INFO - 2025-05-06 11:41:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:41:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:41:07 --> Utf8 Class Initialized
INFO - 2025-05-06 11:41:07 --> URI Class Initialized
INFO - 2025-05-06 11:41:07 --> Router Class Initialized
INFO - 2025-05-06 11:41:07 --> Output Class Initialized
INFO - 2025-05-06 11:41:07 --> Security Class Initialized
DEBUG - 2025-05-06 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:41:07 --> Input Class Initialized
INFO - 2025-05-06 11:41:07 --> Language Class Initialized
INFO - 2025-05-06 11:41:07 --> Loader Class Initialized
INFO - 2025-05-06 11:41:07 --> Helper loaded: url_helper
INFO - 2025-05-06 11:41:07 --> Helper loaded: string_helper
INFO - 2025-05-06 11:41:07 --> Helper loaded: form_helper
INFO - 2025-05-06 11:41:07 --> Helper loaded: file_helper
INFO - 2025-05-06 11:41:07 --> Helper loaded: html_helper
INFO - 2025-05-06 11:41:08 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:41:08 --> Controller Class Initialized
INFO - 2025-05-06 19:41:08 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:41:32 --> Config Class Initialized
INFO - 2025-05-06 11:41:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:41:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:41:32 --> Utf8 Class Initialized
INFO - 2025-05-06 11:41:32 --> URI Class Initialized
INFO - 2025-05-06 11:41:32 --> Router Class Initialized
INFO - 2025-05-06 11:41:32 --> Output Class Initialized
INFO - 2025-05-06 11:41:32 --> Security Class Initialized
DEBUG - 2025-05-06 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:41:32 --> Input Class Initialized
INFO - 2025-05-06 11:41:32 --> Language Class Initialized
INFO - 2025-05-06 11:41:32 --> Loader Class Initialized
INFO - 2025-05-06 11:41:32 --> Helper loaded: url_helper
INFO - 2025-05-06 11:41:32 --> Helper loaded: string_helper
INFO - 2025-05-06 11:41:32 --> Helper loaded: form_helper
INFO - 2025-05-06 11:41:32 --> Helper loaded: file_helper
INFO - 2025-05-06 11:41:32 --> Helper loaded: html_helper
INFO - 2025-05-06 11:41:32 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:41:32 --> Controller Class Initialized
INFO - 2025-05-06 19:41:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:41:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:41:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:41:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:41:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:41:32 --> Final output sent to browser
DEBUG - 2025-05-06 19:41:32 --> Total execution time: 0.0986
INFO - 2025-05-06 11:41:34 --> Config Class Initialized
INFO - 2025-05-06 11:41:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:41:34 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:41:34 --> Utf8 Class Initialized
INFO - 2025-05-06 11:41:34 --> URI Class Initialized
INFO - 2025-05-06 11:41:34 --> Router Class Initialized
INFO - 2025-05-06 11:41:34 --> Output Class Initialized
INFO - 2025-05-06 11:41:34 --> Security Class Initialized
DEBUG - 2025-05-06 11:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:41:34 --> Input Class Initialized
INFO - 2025-05-06 11:41:34 --> Language Class Initialized
INFO - 2025-05-06 11:41:34 --> Loader Class Initialized
INFO - 2025-05-06 11:41:34 --> Helper loaded: url_helper
INFO - 2025-05-06 11:41:34 --> Helper loaded: string_helper
INFO - 2025-05-06 11:41:34 --> Helper loaded: form_helper
INFO - 2025-05-06 11:41:34 --> Helper loaded: file_helper
INFO - 2025-05-06 11:41:34 --> Helper loaded: html_helper
INFO - 2025-05-06 11:41:34 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:41:34 --> Controller Class Initialized
INFO - 2025-05-06 19:41:34 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:43:23 --> Config Class Initialized
INFO - 2025-05-06 11:43:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:43:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:43:23 --> Utf8 Class Initialized
INFO - 2025-05-06 11:43:23 --> URI Class Initialized
INFO - 2025-05-06 11:43:23 --> Router Class Initialized
INFO - 2025-05-06 11:43:23 --> Output Class Initialized
INFO - 2025-05-06 11:43:23 --> Security Class Initialized
DEBUG - 2025-05-06 11:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:43:23 --> Input Class Initialized
INFO - 2025-05-06 11:43:23 --> Language Class Initialized
INFO - 2025-05-06 11:43:23 --> Loader Class Initialized
INFO - 2025-05-06 11:43:23 --> Helper loaded: url_helper
INFO - 2025-05-06 11:43:23 --> Helper loaded: string_helper
INFO - 2025-05-06 11:43:23 --> Helper loaded: form_helper
INFO - 2025-05-06 11:43:23 --> Helper loaded: file_helper
INFO - 2025-05-06 11:43:23 --> Helper loaded: html_helper
INFO - 2025-05-06 11:43:23 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:43:23 --> Controller Class Initialized
INFO - 2025-05-06 19:43:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:43:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:43:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:43:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:43:23 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:43:23 --> Final output sent to browser
DEBUG - 2025-05-06 19:43:23 --> Total execution time: 0.1993
INFO - 2025-05-06 11:43:25 --> Config Class Initialized
INFO - 2025-05-06 11:43:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:43:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:43:25 --> Utf8 Class Initialized
INFO - 2025-05-06 11:43:25 --> URI Class Initialized
INFO - 2025-05-06 11:43:25 --> Router Class Initialized
INFO - 2025-05-06 11:43:25 --> Output Class Initialized
INFO - 2025-05-06 11:43:25 --> Security Class Initialized
DEBUG - 2025-05-06 11:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:43:25 --> Input Class Initialized
INFO - 2025-05-06 11:43:25 --> Language Class Initialized
INFO - 2025-05-06 11:43:25 --> Loader Class Initialized
INFO - 2025-05-06 11:43:25 --> Helper loaded: url_helper
INFO - 2025-05-06 11:43:25 --> Helper loaded: string_helper
INFO - 2025-05-06 11:43:25 --> Helper loaded: form_helper
INFO - 2025-05-06 11:43:25 --> Helper loaded: file_helper
INFO - 2025-05-06 11:43:25 --> Helper loaded: html_helper
INFO - 2025-05-06 11:43:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:43:25 --> Controller Class Initialized
INFO - 2025-05-06 19:43:25 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:44:44 --> Config Class Initialized
INFO - 2025-05-06 11:44:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:44:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:44:44 --> Utf8 Class Initialized
INFO - 2025-05-06 11:44:44 --> URI Class Initialized
INFO - 2025-05-06 11:44:44 --> Router Class Initialized
INFO - 2025-05-06 11:44:44 --> Output Class Initialized
INFO - 2025-05-06 11:44:44 --> Security Class Initialized
DEBUG - 2025-05-06 11:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:44:44 --> Input Class Initialized
INFO - 2025-05-06 11:44:44 --> Language Class Initialized
INFO - 2025-05-06 11:44:44 --> Loader Class Initialized
INFO - 2025-05-06 11:44:44 --> Helper loaded: url_helper
INFO - 2025-05-06 11:44:44 --> Helper loaded: string_helper
INFO - 2025-05-06 11:44:44 --> Helper loaded: form_helper
INFO - 2025-05-06 11:44:44 --> Helper loaded: file_helper
INFO - 2025-05-06 11:44:44 --> Helper loaded: html_helper
INFO - 2025-05-06 11:44:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:44:44 --> Controller Class Initialized
INFO - 2025-05-06 19:44:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:44:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:44:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:44:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:44:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:44:44 --> Final output sent to browser
DEBUG - 2025-05-06 19:44:44 --> Total execution time: 0.1041
INFO - 2025-05-06 11:44:48 --> Config Class Initialized
INFO - 2025-05-06 11:44:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:44:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:44:48 --> Utf8 Class Initialized
INFO - 2025-05-06 11:44:48 --> URI Class Initialized
INFO - 2025-05-06 11:44:48 --> Router Class Initialized
INFO - 2025-05-06 11:44:48 --> Output Class Initialized
INFO - 2025-05-06 11:44:48 --> Security Class Initialized
DEBUG - 2025-05-06 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:44:48 --> Input Class Initialized
INFO - 2025-05-06 11:44:48 --> Language Class Initialized
INFO - 2025-05-06 11:44:48 --> Loader Class Initialized
INFO - 2025-05-06 11:44:48 --> Helper loaded: url_helper
INFO - 2025-05-06 11:44:48 --> Helper loaded: string_helper
INFO - 2025-05-06 11:44:48 --> Helper loaded: form_helper
INFO - 2025-05-06 11:44:48 --> Helper loaded: file_helper
INFO - 2025-05-06 11:44:48 --> Helper loaded: html_helper
INFO - 2025-05-06 11:44:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:44:48 --> Controller Class Initialized
INFO - 2025-05-06 19:44:48 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:50:18 --> Config Class Initialized
INFO - 2025-05-06 11:50:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:50:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:50:18 --> Utf8 Class Initialized
INFO - 2025-05-06 11:50:18 --> URI Class Initialized
INFO - 2025-05-06 11:50:18 --> Router Class Initialized
INFO - 2025-05-06 11:50:18 --> Output Class Initialized
INFO - 2025-05-06 11:50:18 --> Security Class Initialized
DEBUG - 2025-05-06 11:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:50:18 --> Input Class Initialized
INFO - 2025-05-06 11:50:18 --> Language Class Initialized
INFO - 2025-05-06 11:50:18 --> Loader Class Initialized
INFO - 2025-05-06 11:50:18 --> Helper loaded: url_helper
INFO - 2025-05-06 11:50:18 --> Helper loaded: string_helper
INFO - 2025-05-06 11:50:18 --> Helper loaded: form_helper
INFO - 2025-05-06 11:50:18 --> Helper loaded: file_helper
INFO - 2025-05-06 11:50:18 --> Helper loaded: html_helper
INFO - 2025-05-06 11:50:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:50:18 --> Controller Class Initialized
INFO - 2025-05-06 19:50:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:50:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:50:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:50:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:50:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:50:18 --> Final output sent to browser
DEBUG - 2025-05-06 19:50:18 --> Total execution time: 0.1149
INFO - 2025-05-06 11:50:19 --> Config Class Initialized
INFO - 2025-05-06 11:50:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:50:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:50:19 --> Utf8 Class Initialized
INFO - 2025-05-06 11:50:19 --> URI Class Initialized
INFO - 2025-05-06 11:50:19 --> Router Class Initialized
INFO - 2025-05-06 11:50:19 --> Output Class Initialized
INFO - 2025-05-06 11:50:19 --> Security Class Initialized
DEBUG - 2025-05-06 11:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:50:19 --> Input Class Initialized
INFO - 2025-05-06 11:50:19 --> Language Class Initialized
INFO - 2025-05-06 11:50:19 --> Loader Class Initialized
INFO - 2025-05-06 11:50:19 --> Helper loaded: url_helper
INFO - 2025-05-06 11:50:19 --> Helper loaded: string_helper
INFO - 2025-05-06 11:50:19 --> Helper loaded: form_helper
INFO - 2025-05-06 11:50:19 --> Helper loaded: file_helper
INFO - 2025-05-06 11:50:19 --> Helper loaded: html_helper
INFO - 2025-05-06 11:50:19 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:50:19 --> Controller Class Initialized
INFO - 2025-05-06 19:50:19 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:52:55 --> Config Class Initialized
INFO - 2025-05-06 11:52:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:52:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:52:55 --> Utf8 Class Initialized
INFO - 2025-05-06 11:52:55 --> URI Class Initialized
INFO - 2025-05-06 11:52:55 --> Router Class Initialized
INFO - 2025-05-06 11:52:55 --> Output Class Initialized
INFO - 2025-05-06 11:52:55 --> Security Class Initialized
DEBUG - 2025-05-06 11:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:52:55 --> Input Class Initialized
INFO - 2025-05-06 11:52:55 --> Language Class Initialized
INFO - 2025-05-06 11:52:55 --> Loader Class Initialized
INFO - 2025-05-06 11:52:55 --> Helper loaded: url_helper
INFO - 2025-05-06 11:52:55 --> Helper loaded: string_helper
INFO - 2025-05-06 11:52:55 --> Helper loaded: form_helper
INFO - 2025-05-06 11:52:55 --> Helper loaded: file_helper
INFO - 2025-05-06 11:52:55 --> Helper loaded: html_helper
INFO - 2025-05-06 11:52:56 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:52:56 --> Controller Class Initialized
INFO - 2025-05-06 19:52:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:52:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:52:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:52:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:52:56 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:52:56 --> Final output sent to browser
DEBUG - 2025-05-06 19:52:56 --> Total execution time: 0.1461
INFO - 2025-05-06 11:52:57 --> Config Class Initialized
INFO - 2025-05-06 11:52:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:52:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:52:57 --> Utf8 Class Initialized
INFO - 2025-05-06 11:52:57 --> URI Class Initialized
INFO - 2025-05-06 11:52:57 --> Router Class Initialized
INFO - 2025-05-06 11:52:57 --> Output Class Initialized
INFO - 2025-05-06 11:52:57 --> Security Class Initialized
DEBUG - 2025-05-06 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:52:57 --> Input Class Initialized
INFO - 2025-05-06 11:52:58 --> Language Class Initialized
INFO - 2025-05-06 11:52:58 --> Loader Class Initialized
INFO - 2025-05-06 11:52:58 --> Helper loaded: url_helper
INFO - 2025-05-06 11:52:58 --> Helper loaded: string_helper
INFO - 2025-05-06 11:52:58 --> Helper loaded: form_helper
INFO - 2025-05-06 11:52:58 --> Helper loaded: file_helper
INFO - 2025-05-06 11:52:58 --> Helper loaded: html_helper
INFO - 2025-05-06 11:52:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:52:58 --> Controller Class Initialized
INFO - 2025-05-06 19:52:58 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:53:28 --> Config Class Initialized
INFO - 2025-05-06 11:53:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:53:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:53:29 --> Utf8 Class Initialized
INFO - 2025-05-06 11:53:29 --> URI Class Initialized
INFO - 2025-05-06 11:53:29 --> Router Class Initialized
INFO - 2025-05-06 11:53:29 --> Output Class Initialized
INFO - 2025-05-06 11:53:29 --> Security Class Initialized
DEBUG - 2025-05-06 11:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:53:29 --> Input Class Initialized
INFO - 2025-05-06 11:53:29 --> Language Class Initialized
INFO - 2025-05-06 11:53:29 --> Loader Class Initialized
INFO - 2025-05-06 11:53:29 --> Helper loaded: url_helper
INFO - 2025-05-06 11:53:29 --> Helper loaded: string_helper
INFO - 2025-05-06 11:53:29 --> Helper loaded: form_helper
INFO - 2025-05-06 11:53:29 --> Helper loaded: file_helper
INFO - 2025-05-06 11:53:29 --> Helper loaded: html_helper
INFO - 2025-05-06 11:53:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:53:29 --> Controller Class Initialized
INFO - 2025-05-06 19:53:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:53:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:53:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:53:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:53:29 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:53:29 --> Final output sent to browser
DEBUG - 2025-05-06 19:53:29 --> Total execution time: 0.2488
INFO - 2025-05-06 11:53:30 --> Config Class Initialized
INFO - 2025-05-06 11:53:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:53:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:53:30 --> Utf8 Class Initialized
INFO - 2025-05-06 11:53:30 --> URI Class Initialized
INFO - 2025-05-06 11:53:30 --> Router Class Initialized
INFO - 2025-05-06 11:53:30 --> Output Class Initialized
INFO - 2025-05-06 11:53:30 --> Security Class Initialized
DEBUG - 2025-05-06 11:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:53:30 --> Input Class Initialized
INFO - 2025-05-06 11:53:30 --> Language Class Initialized
INFO - 2025-05-06 11:53:30 --> Loader Class Initialized
INFO - 2025-05-06 11:53:30 --> Helper loaded: url_helper
INFO - 2025-05-06 11:53:30 --> Helper loaded: string_helper
INFO - 2025-05-06 11:53:30 --> Helper loaded: form_helper
INFO - 2025-05-06 11:53:30 --> Helper loaded: file_helper
INFO - 2025-05-06 11:53:30 --> Helper loaded: html_helper
INFO - 2025-05-06 11:53:30 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:53:30 --> Controller Class Initialized
INFO - 2025-05-06 19:53:30 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:54:33 --> Config Class Initialized
INFO - 2025-05-06 11:54:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:54:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:54:33 --> Utf8 Class Initialized
INFO - 2025-05-06 11:54:33 --> URI Class Initialized
INFO - 2025-05-06 11:54:33 --> Router Class Initialized
INFO - 2025-05-06 11:54:33 --> Output Class Initialized
INFO - 2025-05-06 11:54:33 --> Security Class Initialized
DEBUG - 2025-05-06 11:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:54:33 --> Input Class Initialized
INFO - 2025-05-06 11:54:33 --> Language Class Initialized
INFO - 2025-05-06 11:54:33 --> Loader Class Initialized
INFO - 2025-05-06 11:54:33 --> Helper loaded: url_helper
INFO - 2025-05-06 11:54:33 --> Helper loaded: string_helper
INFO - 2025-05-06 11:54:33 --> Helper loaded: form_helper
INFO - 2025-05-06 11:54:33 --> Helper loaded: file_helper
INFO - 2025-05-06 11:54:33 --> Helper loaded: html_helper
INFO - 2025-05-06 11:54:33 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:54:33 --> Controller Class Initialized
INFO - 2025-05-06 19:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:54:33 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:54:33 --> Final output sent to browser
DEBUG - 2025-05-06 19:54:33 --> Total execution time: 0.1381
INFO - 2025-05-06 11:54:34 --> Config Class Initialized
INFO - 2025-05-06 11:54:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:54:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:54:35 --> Utf8 Class Initialized
INFO - 2025-05-06 11:54:35 --> URI Class Initialized
INFO - 2025-05-06 11:54:35 --> Router Class Initialized
INFO - 2025-05-06 11:54:35 --> Output Class Initialized
INFO - 2025-05-06 11:54:35 --> Security Class Initialized
DEBUG - 2025-05-06 11:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:54:35 --> Input Class Initialized
INFO - 2025-05-06 11:54:35 --> Language Class Initialized
INFO - 2025-05-06 11:54:35 --> Loader Class Initialized
INFO - 2025-05-06 11:54:35 --> Helper loaded: url_helper
INFO - 2025-05-06 11:54:35 --> Helper loaded: string_helper
INFO - 2025-05-06 11:54:35 --> Helper loaded: form_helper
INFO - 2025-05-06 11:54:35 --> Helper loaded: file_helper
INFO - 2025-05-06 11:54:35 --> Helper loaded: html_helper
INFO - 2025-05-06 11:54:35 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:54:35 --> Controller Class Initialized
INFO - 2025-05-06 19:54:35 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:55:36 --> Config Class Initialized
INFO - 2025-05-06 11:55:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:55:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:55:36 --> Utf8 Class Initialized
INFO - 2025-05-06 11:55:36 --> URI Class Initialized
INFO - 2025-05-06 11:55:36 --> Router Class Initialized
INFO - 2025-05-06 11:55:36 --> Output Class Initialized
INFO - 2025-05-06 11:55:36 --> Security Class Initialized
DEBUG - 2025-05-06 11:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:55:36 --> Input Class Initialized
INFO - 2025-05-06 11:55:36 --> Language Class Initialized
INFO - 2025-05-06 11:55:36 --> Loader Class Initialized
INFO - 2025-05-06 11:55:36 --> Helper loaded: url_helper
INFO - 2025-05-06 11:55:36 --> Helper loaded: string_helper
INFO - 2025-05-06 11:55:36 --> Helper loaded: form_helper
INFO - 2025-05-06 11:55:36 --> Helper loaded: file_helper
INFO - 2025-05-06 11:55:36 --> Helper loaded: html_helper
INFO - 2025-05-06 11:55:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:55:36 --> Controller Class Initialized
INFO - 2025-05-06 19:55:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:55:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:55:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:55:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:55:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:55:36 --> Final output sent to browser
DEBUG - 2025-05-06 19:55:36 --> Total execution time: 0.0970
INFO - 2025-05-06 11:55:37 --> Config Class Initialized
INFO - 2025-05-06 11:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:55:37 --> Utf8 Class Initialized
INFO - 2025-05-06 11:55:37 --> URI Class Initialized
INFO - 2025-05-06 11:55:37 --> Router Class Initialized
INFO - 2025-05-06 11:55:37 --> Output Class Initialized
INFO - 2025-05-06 11:55:37 --> Security Class Initialized
DEBUG - 2025-05-06 11:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:55:37 --> Input Class Initialized
INFO - 2025-05-06 11:55:37 --> Language Class Initialized
INFO - 2025-05-06 11:55:37 --> Loader Class Initialized
INFO - 2025-05-06 11:55:37 --> Helper loaded: url_helper
INFO - 2025-05-06 11:55:37 --> Helper loaded: string_helper
INFO - 2025-05-06 11:55:37 --> Helper loaded: form_helper
INFO - 2025-05-06 11:55:37 --> Helper loaded: file_helper
INFO - 2025-05-06 11:55:37 --> Helper loaded: html_helper
INFO - 2025-05-06 11:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:55:37 --> Controller Class Initialized
INFO - 2025-05-06 19:55:37 --> Model "AuctionModel" initialized
INFO - 2025-05-06 11:57:00 --> Config Class Initialized
INFO - 2025-05-06 11:57:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:57:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:57:00 --> Utf8 Class Initialized
INFO - 2025-05-06 11:57:00 --> URI Class Initialized
INFO - 2025-05-06 11:57:00 --> Router Class Initialized
INFO - 2025-05-06 11:57:00 --> Output Class Initialized
INFO - 2025-05-06 11:57:00 --> Security Class Initialized
DEBUG - 2025-05-06 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:57:00 --> Input Class Initialized
INFO - 2025-05-06 11:57:00 --> Language Class Initialized
INFO - 2025-05-06 11:57:00 --> Loader Class Initialized
INFO - 2025-05-06 11:57:00 --> Helper loaded: url_helper
INFO - 2025-05-06 11:57:00 --> Helper loaded: string_helper
INFO - 2025-05-06 11:57:00 --> Helper loaded: form_helper
INFO - 2025-05-06 11:57:00 --> Helper loaded: file_helper
INFO - 2025-05-06 11:57:00 --> Helper loaded: html_helper
INFO - 2025-05-06 11:57:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:57:00 --> Controller Class Initialized
INFO - 2025-05-06 19:57:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:57:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:57:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:57:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:57:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:57:00 --> Final output sent to browser
DEBUG - 2025-05-06 19:57:00 --> Total execution time: 0.1411
INFO - 2025-05-06 11:57:02 --> Config Class Initialized
INFO - 2025-05-06 11:57:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:57:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:57:02 --> Utf8 Class Initialized
INFO - 2025-05-06 11:57:02 --> URI Class Initialized
INFO - 2025-05-06 11:57:02 --> Router Class Initialized
INFO - 2025-05-06 11:57:02 --> Output Class Initialized
INFO - 2025-05-06 11:57:02 --> Security Class Initialized
DEBUG - 2025-05-06 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:57:02 --> Input Class Initialized
INFO - 2025-05-06 11:57:02 --> Language Class Initialized
INFO - 2025-05-06 11:59:48 --> Config Class Initialized
INFO - 2025-05-06 11:59:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 11:59:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 11:59:48 --> Utf8 Class Initialized
INFO - 2025-05-06 11:59:48 --> URI Class Initialized
INFO - 2025-05-06 11:59:48 --> Router Class Initialized
INFO - 2025-05-06 11:59:48 --> Output Class Initialized
INFO - 2025-05-06 11:59:48 --> Security Class Initialized
DEBUG - 2025-05-06 11:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 11:59:48 --> Input Class Initialized
INFO - 2025-05-06 11:59:48 --> Language Class Initialized
INFO - 2025-05-06 11:59:48 --> Loader Class Initialized
INFO - 2025-05-06 11:59:48 --> Helper loaded: url_helper
INFO - 2025-05-06 11:59:48 --> Helper loaded: string_helper
INFO - 2025-05-06 11:59:48 --> Helper loaded: form_helper
INFO - 2025-05-06 11:59:48 --> Helper loaded: file_helper
INFO - 2025-05-06 11:59:48 --> Helper loaded: html_helper
INFO - 2025-05-06 11:59:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 11:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 11:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 11:59:48 --> Controller Class Initialized
INFO - 2025-05-06 19:59:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 19:59:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 19:59:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 19:59:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 19:59:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 19:59:48 --> Final output sent to browser
DEBUG - 2025-05-06 19:59:48 --> Total execution time: 0.1617
INFO - 2025-05-06 11:59:50 --> Config Class Initialized
INFO - 2025-05-06 11:59:50 --> Hooks Class Initialized
INFO - 2025-05-06 12:03:24 --> Config Class Initialized
INFO - 2025-05-06 12:03:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:03:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:03:24 --> Utf8 Class Initialized
INFO - 2025-05-06 12:03:24 --> URI Class Initialized
INFO - 2025-05-06 12:03:24 --> Router Class Initialized
INFO - 2025-05-06 12:03:24 --> Output Class Initialized
INFO - 2025-05-06 12:03:24 --> Security Class Initialized
DEBUG - 2025-05-06 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:03:24 --> Input Class Initialized
INFO - 2025-05-06 12:03:24 --> Language Class Initialized
INFO - 2025-05-06 12:03:24 --> Loader Class Initialized
INFO - 2025-05-06 12:03:24 --> Helper loaded: url_helper
INFO - 2025-05-06 12:03:24 --> Helper loaded: string_helper
INFO - 2025-05-06 12:03:24 --> Helper loaded: form_helper
INFO - 2025-05-06 12:03:24 --> Helper loaded: file_helper
INFO - 2025-05-06 12:03:24 --> Helper loaded: html_helper
INFO - 2025-05-06 12:03:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:03:24 --> Controller Class Initialized
INFO - 2025-05-06 20:03:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:03:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:03:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:03:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:03:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:03:24 --> Final output sent to browser
DEBUG - 2025-05-06 20:03:24 --> Total execution time: 0.1247
INFO - 2025-05-06 12:03:25 --> Config Class Initialized
INFO - 2025-05-06 12:03:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:03:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:03:25 --> Utf8 Class Initialized
INFO - 2025-05-06 12:03:25 --> URI Class Initialized
INFO - 2025-05-06 12:03:25 --> Router Class Initialized
INFO - 2025-05-06 12:03:25 --> Output Class Initialized
INFO - 2025-05-06 12:03:25 --> Security Class Initialized
DEBUG - 2025-05-06 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:03:25 --> Input Class Initialized
INFO - 2025-05-06 12:03:25 --> Language Class Initialized
INFO - 2025-05-06 12:03:25 --> Loader Class Initialized
INFO - 2025-05-06 12:03:25 --> Helper loaded: url_helper
INFO - 2025-05-06 12:03:25 --> Helper loaded: string_helper
INFO - 2025-05-06 12:03:25 --> Helper loaded: form_helper
INFO - 2025-05-06 12:03:25 --> Helper loaded: file_helper
INFO - 2025-05-06 12:03:25 --> Helper loaded: html_helper
INFO - 2025-05-06 12:03:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:03:25 --> Controller Class Initialized
INFO - 2025-05-06 20:03:25 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:05:05 --> Config Class Initialized
INFO - 2025-05-06 12:05:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:05:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:05:05 --> Utf8 Class Initialized
INFO - 2025-05-06 12:05:05 --> URI Class Initialized
INFO - 2025-05-06 12:05:05 --> Router Class Initialized
INFO - 2025-05-06 12:05:05 --> Output Class Initialized
INFO - 2025-05-06 12:05:05 --> Security Class Initialized
DEBUG - 2025-05-06 12:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:05:05 --> Input Class Initialized
INFO - 2025-05-06 12:05:05 --> Language Class Initialized
INFO - 2025-05-06 12:05:05 --> Loader Class Initialized
INFO - 2025-05-06 12:05:05 --> Helper loaded: url_helper
INFO - 2025-05-06 12:05:05 --> Helper loaded: string_helper
INFO - 2025-05-06 12:05:05 --> Helper loaded: form_helper
INFO - 2025-05-06 12:05:05 --> Helper loaded: file_helper
INFO - 2025-05-06 12:05:05 --> Helper loaded: html_helper
INFO - 2025-05-06 12:05:05 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:05:05 --> Controller Class Initialized
INFO - 2025-05-06 20:05:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:05:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:05:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:05:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:05:05 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:05:05 --> Final output sent to browser
DEBUG - 2025-05-06 20:05:05 --> Total execution time: 0.0900
INFO - 2025-05-06 12:05:06 --> Config Class Initialized
INFO - 2025-05-06 12:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:05:06 --> Utf8 Class Initialized
INFO - 2025-05-06 12:05:06 --> URI Class Initialized
INFO - 2025-05-06 12:05:06 --> Router Class Initialized
INFO - 2025-05-06 12:05:06 --> Output Class Initialized
INFO - 2025-05-06 12:05:06 --> Security Class Initialized
DEBUG - 2025-05-06 12:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:05:06 --> Input Class Initialized
INFO - 2025-05-06 12:05:06 --> Language Class Initialized
INFO - 2025-05-06 12:05:06 --> Loader Class Initialized
INFO - 2025-05-06 12:05:06 --> Helper loaded: url_helper
INFO - 2025-05-06 12:05:06 --> Helper loaded: string_helper
INFO - 2025-05-06 12:05:06 --> Helper loaded: form_helper
INFO - 2025-05-06 12:05:06 --> Helper loaded: file_helper
INFO - 2025-05-06 12:05:06 --> Helper loaded: html_helper
INFO - 2025-05-06 12:05:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:05:06 --> Controller Class Initialized
INFO - 2025-05-06 20:05:06 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:07:48 --> Config Class Initialized
INFO - 2025-05-06 12:07:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:07:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:07:48 --> Utf8 Class Initialized
INFO - 2025-05-06 12:07:48 --> URI Class Initialized
INFO - 2025-05-06 12:07:48 --> Router Class Initialized
INFO - 2025-05-06 12:07:48 --> Output Class Initialized
INFO - 2025-05-06 12:07:48 --> Security Class Initialized
DEBUG - 2025-05-06 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:07:48 --> Input Class Initialized
INFO - 2025-05-06 12:07:48 --> Language Class Initialized
INFO - 2025-05-06 12:07:48 --> Loader Class Initialized
INFO - 2025-05-06 12:07:48 --> Helper loaded: url_helper
INFO - 2025-05-06 12:07:48 --> Helper loaded: string_helper
INFO - 2025-05-06 12:07:48 --> Helper loaded: form_helper
INFO - 2025-05-06 12:07:48 --> Helper loaded: file_helper
INFO - 2025-05-06 12:07:48 --> Helper loaded: html_helper
INFO - 2025-05-06 12:07:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:07:48 --> Controller Class Initialized
INFO - 2025-05-06 20:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:07:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:07:48 --> Final output sent to browser
DEBUG - 2025-05-06 20:07:48 --> Total execution time: 0.1435
INFO - 2025-05-06 12:07:50 --> Config Class Initialized
INFO - 2025-05-06 12:07:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:07:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:07:50 --> Utf8 Class Initialized
INFO - 2025-05-06 12:07:50 --> URI Class Initialized
INFO - 2025-05-06 12:07:50 --> Router Class Initialized
INFO - 2025-05-06 12:07:50 --> Output Class Initialized
INFO - 2025-05-06 12:07:50 --> Security Class Initialized
DEBUG - 2025-05-06 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:07:50 --> Input Class Initialized
INFO - 2025-05-06 12:07:50 --> Language Class Initialized
INFO - 2025-05-06 12:07:50 --> Loader Class Initialized
INFO - 2025-05-06 12:07:50 --> Helper loaded: url_helper
INFO - 2025-05-06 12:07:50 --> Helper loaded: string_helper
INFO - 2025-05-06 12:07:50 --> Helper loaded: form_helper
INFO - 2025-05-06 12:07:50 --> Helper loaded: file_helper
INFO - 2025-05-06 12:07:50 --> Helper loaded: html_helper
INFO - 2025-05-06 12:07:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:07:50 --> Controller Class Initialized
INFO - 2025-05-06 20:07:50 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:11:24 --> Config Class Initialized
INFO - 2025-05-06 12:11:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:11:24 --> Utf8 Class Initialized
INFO - 2025-05-06 12:11:24 --> URI Class Initialized
INFO - 2025-05-06 12:11:24 --> Router Class Initialized
INFO - 2025-05-06 12:11:24 --> Output Class Initialized
INFO - 2025-05-06 12:11:24 --> Security Class Initialized
DEBUG - 2025-05-06 12:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:11:24 --> Input Class Initialized
INFO - 2025-05-06 12:11:24 --> Language Class Initialized
INFO - 2025-05-06 12:11:24 --> Loader Class Initialized
INFO - 2025-05-06 12:11:24 --> Helper loaded: url_helper
INFO - 2025-05-06 12:11:24 --> Helper loaded: string_helper
INFO - 2025-05-06 12:11:24 --> Helper loaded: form_helper
INFO - 2025-05-06 12:11:24 --> Helper loaded: file_helper
INFO - 2025-05-06 12:11:24 --> Helper loaded: html_helper
INFO - 2025-05-06 12:11:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:11:24 --> Controller Class Initialized
INFO - 2025-05-06 20:11:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:11:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:11:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:11:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:11:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:11:24 --> Final output sent to browser
DEBUG - 2025-05-06 20:11:24 --> Total execution time: 0.1346
INFO - 2025-05-06 12:11:29 --> Config Class Initialized
INFO - 2025-05-06 12:11:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:11:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:11:29 --> Utf8 Class Initialized
INFO - 2025-05-06 12:11:29 --> URI Class Initialized
INFO - 2025-05-06 12:11:29 --> Router Class Initialized
INFO - 2025-05-06 12:11:29 --> Output Class Initialized
INFO - 2025-05-06 12:11:29 --> Security Class Initialized
DEBUG - 2025-05-06 12:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:11:29 --> Input Class Initialized
INFO - 2025-05-06 12:11:29 --> Language Class Initialized
INFO - 2025-05-06 12:11:29 --> Loader Class Initialized
INFO - 2025-05-06 12:11:29 --> Helper loaded: url_helper
INFO - 2025-05-06 12:11:29 --> Helper loaded: string_helper
INFO - 2025-05-06 12:11:29 --> Helper loaded: form_helper
INFO - 2025-05-06 12:11:29 --> Helper loaded: file_helper
INFO - 2025-05-06 12:11:29 --> Helper loaded: html_helper
INFO - 2025-05-06 12:11:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:11:29 --> Controller Class Initialized
INFO - 2025-05-06 20:11:29 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:12:06 --> Config Class Initialized
INFO - 2025-05-06 12:12:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:12:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:12:06 --> Utf8 Class Initialized
INFO - 2025-05-06 12:12:06 --> URI Class Initialized
INFO - 2025-05-06 12:12:06 --> Router Class Initialized
INFO - 2025-05-06 12:12:06 --> Output Class Initialized
INFO - 2025-05-06 12:12:06 --> Security Class Initialized
DEBUG - 2025-05-06 12:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:12:06 --> Input Class Initialized
INFO - 2025-05-06 12:12:06 --> Language Class Initialized
INFO - 2025-05-06 12:12:06 --> Loader Class Initialized
INFO - 2025-05-06 12:12:06 --> Helper loaded: url_helper
INFO - 2025-05-06 12:12:06 --> Helper loaded: string_helper
INFO - 2025-05-06 12:12:06 --> Helper loaded: form_helper
INFO - 2025-05-06 12:12:06 --> Helper loaded: file_helper
INFO - 2025-05-06 12:12:06 --> Helper loaded: html_helper
INFO - 2025-05-06 12:12:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:12:06 --> Controller Class Initialized
INFO - 2025-05-06 20:12:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:12:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:12:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:12:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:12:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:12:06 --> Final output sent to browser
DEBUG - 2025-05-06 20:12:06 --> Total execution time: 0.1278
INFO - 2025-05-06 12:12:07 --> Config Class Initialized
INFO - 2025-05-06 12:12:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:12:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:12:07 --> Utf8 Class Initialized
INFO - 2025-05-06 12:12:07 --> URI Class Initialized
INFO - 2025-05-06 12:12:07 --> Router Class Initialized
INFO - 2025-05-06 12:12:07 --> Output Class Initialized
INFO - 2025-05-06 12:12:07 --> Security Class Initialized
DEBUG - 2025-05-06 12:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:12:07 --> Input Class Initialized
INFO - 2025-05-06 12:12:07 --> Language Class Initialized
INFO - 2025-05-06 12:12:07 --> Loader Class Initialized
INFO - 2025-05-06 12:12:07 --> Helper loaded: url_helper
INFO - 2025-05-06 12:12:07 --> Helper loaded: string_helper
INFO - 2025-05-06 12:12:07 --> Helper loaded: form_helper
INFO - 2025-05-06 12:12:07 --> Helper loaded: file_helper
INFO - 2025-05-06 12:12:07 --> Helper loaded: html_helper
INFO - 2025-05-06 12:12:07 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:12:07 --> Controller Class Initialized
INFO - 2025-05-06 20:12:07 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:13:28 --> Config Class Initialized
INFO - 2025-05-06 12:13:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:28 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:28 --> URI Class Initialized
INFO - 2025-05-06 12:13:28 --> Router Class Initialized
INFO - 2025-05-06 12:13:28 --> Output Class Initialized
INFO - 2025-05-06 12:13:28 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:28 --> Input Class Initialized
INFO - 2025-05-06 12:13:28 --> Language Class Initialized
INFO - 2025-05-06 12:13:28 --> Loader Class Initialized
INFO - 2025-05-06 12:13:28 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:28 --> Helper loaded: string_helper
INFO - 2025-05-06 12:13:28 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:28 --> Helper loaded: file_helper
INFO - 2025-05-06 12:13:28 --> Helper loaded: html_helper
INFO - 2025-05-06 12:13:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:28 --> Controller Class Initialized
INFO - 2025-05-06 20:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:13:28 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:13:28 --> Final output sent to browser
DEBUG - 2025-05-06 20:13:28 --> Total execution time: 0.1109
INFO - 2025-05-06 12:13:29 --> Config Class Initialized
INFO - 2025-05-06 12:13:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:29 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:29 --> URI Class Initialized
INFO - 2025-05-06 12:13:29 --> Router Class Initialized
INFO - 2025-05-06 12:13:29 --> Output Class Initialized
INFO - 2025-05-06 12:13:29 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:29 --> Input Class Initialized
INFO - 2025-05-06 12:13:29 --> Language Class Initialized
INFO - 2025-05-06 12:13:29 --> Loader Class Initialized
INFO - 2025-05-06 12:13:29 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:29 --> Helper loaded: string_helper
INFO - 2025-05-06 12:13:29 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:29 --> Helper loaded: file_helper
INFO - 2025-05-06 12:13:29 --> Helper loaded: html_helper
INFO - 2025-05-06 12:13:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:29 --> Controller Class Initialized
INFO - 2025-05-06 20:13:29 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:14:44 --> Config Class Initialized
INFO - 2025-05-06 12:14:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:14:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:14:44 --> Utf8 Class Initialized
INFO - 2025-05-06 12:14:44 --> URI Class Initialized
INFO - 2025-05-06 12:14:44 --> Router Class Initialized
INFO - 2025-05-06 12:14:44 --> Output Class Initialized
INFO - 2025-05-06 12:14:44 --> Security Class Initialized
DEBUG - 2025-05-06 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:14:44 --> Input Class Initialized
INFO - 2025-05-06 12:14:44 --> Language Class Initialized
INFO - 2025-05-06 12:14:44 --> Loader Class Initialized
INFO - 2025-05-06 12:14:44 --> Helper loaded: url_helper
INFO - 2025-05-06 12:14:44 --> Helper loaded: string_helper
INFO - 2025-05-06 12:14:44 --> Helper loaded: form_helper
INFO - 2025-05-06 12:14:44 --> Helper loaded: file_helper
INFO - 2025-05-06 12:14:44 --> Helper loaded: html_helper
INFO - 2025-05-06 12:14:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:14:44 --> Controller Class Initialized
INFO - 2025-05-06 20:14:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:14:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:14:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:14:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:14:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:14:44 --> Final output sent to browser
DEBUG - 2025-05-06 20:14:44 --> Total execution time: 0.1623
INFO - 2025-05-06 12:14:45 --> Config Class Initialized
INFO - 2025-05-06 12:14:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:14:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:14:45 --> Utf8 Class Initialized
INFO - 2025-05-06 12:14:45 --> URI Class Initialized
INFO - 2025-05-06 12:14:45 --> Router Class Initialized
INFO - 2025-05-06 12:14:45 --> Output Class Initialized
INFO - 2025-05-06 12:14:45 --> Security Class Initialized
DEBUG - 2025-05-06 12:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:14:45 --> Input Class Initialized
INFO - 2025-05-06 12:14:45 --> Language Class Initialized
INFO - 2025-05-06 12:14:45 --> Loader Class Initialized
INFO - 2025-05-06 12:14:45 --> Helper loaded: url_helper
INFO - 2025-05-06 12:14:45 --> Helper loaded: string_helper
INFO - 2025-05-06 12:14:45 --> Helper loaded: form_helper
INFO - 2025-05-06 12:14:45 --> Helper loaded: file_helper
INFO - 2025-05-06 12:14:45 --> Helper loaded: html_helper
INFO - 2025-05-06 12:14:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:14:45 --> Controller Class Initialized
INFO - 2025-05-06 20:14:45 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:01 --> Config Class Initialized
INFO - 2025-05-06 12:15:01 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:01 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:01 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:01 --> URI Class Initialized
INFO - 2025-05-06 12:15:01 --> Router Class Initialized
INFO - 2025-05-06 12:15:01 --> Output Class Initialized
INFO - 2025-05-06 12:15:01 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:01 --> Input Class Initialized
INFO - 2025-05-06 12:15:01 --> Language Class Initialized
INFO - 2025-05-06 12:15:01 --> Loader Class Initialized
INFO - 2025-05-06 12:15:01 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:01 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:01 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:01 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:01 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:01 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:01 --> Controller Class Initialized
INFO - 2025-05-06 20:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:15:01 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:15:01 --> Final output sent to browser
DEBUG - 2025-05-06 20:15:01 --> Total execution time: 0.1832
INFO - 2025-05-06 12:15:02 --> Config Class Initialized
INFO - 2025-05-06 12:15:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:02 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:02 --> URI Class Initialized
INFO - 2025-05-06 12:15:02 --> Router Class Initialized
INFO - 2025-05-06 12:15:02 --> Output Class Initialized
INFO - 2025-05-06 12:15:02 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:02 --> Input Class Initialized
INFO - 2025-05-06 12:15:02 --> Language Class Initialized
INFO - 2025-05-06 12:15:02 --> Loader Class Initialized
INFO - 2025-05-06 12:15:02 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:02 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:02 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:02 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:03 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:03 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:03 --> Controller Class Initialized
INFO - 2025-05-06 20:15:03 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:07 --> Config Class Initialized
INFO - 2025-05-06 12:15:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:07 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:07 --> URI Class Initialized
INFO - 2025-05-06 12:15:07 --> Router Class Initialized
INFO - 2025-05-06 12:15:07 --> Output Class Initialized
INFO - 2025-05-06 12:15:07 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:07 --> Input Class Initialized
INFO - 2025-05-06 12:15:07 --> Language Class Initialized
INFO - 2025-05-06 12:15:07 --> Loader Class Initialized
INFO - 2025-05-06 12:15:07 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:07 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:07 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:07 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:07 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:07 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:07 --> Controller Class Initialized
INFO - 2025-05-06 20:15:07 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:14 --> Config Class Initialized
INFO - 2025-05-06 12:15:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:14 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:14 --> URI Class Initialized
INFO - 2025-05-06 12:15:14 --> Router Class Initialized
INFO - 2025-05-06 12:15:14 --> Output Class Initialized
INFO - 2025-05-06 12:15:14 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:14 --> Input Class Initialized
INFO - 2025-05-06 12:15:14 --> Language Class Initialized
INFO - 2025-05-06 12:15:14 --> Loader Class Initialized
INFO - 2025-05-06 12:15:14 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:14 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:14 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:14 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:14 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:14 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:14 --> Controller Class Initialized
INFO - 2025-05-06 20:15:14 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:18 --> Config Class Initialized
INFO - 2025-05-06 12:15:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:18 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:18 --> URI Class Initialized
INFO - 2025-05-06 12:15:18 --> Router Class Initialized
INFO - 2025-05-06 12:15:18 --> Output Class Initialized
INFO - 2025-05-06 12:15:18 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:18 --> Input Class Initialized
INFO - 2025-05-06 12:15:18 --> Language Class Initialized
INFO - 2025-05-06 12:15:18 --> Loader Class Initialized
INFO - 2025-05-06 12:15:18 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:18 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:18 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:18 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:18 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:19 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:19 --> Controller Class Initialized
INFO - 2025-05-06 20:15:19 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:21 --> Config Class Initialized
INFO - 2025-05-06 12:15:21 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:21 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:21 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:21 --> URI Class Initialized
INFO - 2025-05-06 12:15:21 --> Router Class Initialized
INFO - 2025-05-06 12:15:21 --> Output Class Initialized
INFO - 2025-05-06 12:15:21 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:21 --> Input Class Initialized
INFO - 2025-05-06 12:15:21 --> Language Class Initialized
INFO - 2025-05-06 12:15:21 --> Loader Class Initialized
INFO - 2025-05-06 12:15:21 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:21 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:21 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:21 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:21 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:21 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:21 --> Controller Class Initialized
INFO - 2025-05-06 20:15:21 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:24 --> Config Class Initialized
INFO - 2025-05-06 12:15:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:24 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:24 --> URI Class Initialized
INFO - 2025-05-06 12:15:24 --> Router Class Initialized
INFO - 2025-05-06 12:15:24 --> Output Class Initialized
INFO - 2025-05-06 12:15:24 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:24 --> Input Class Initialized
INFO - 2025-05-06 12:15:24 --> Language Class Initialized
INFO - 2025-05-06 12:15:24 --> Loader Class Initialized
INFO - 2025-05-06 12:15:24 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:24 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:24 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:24 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:24 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:24 --> Controller Class Initialized
INFO - 2025-05-06 20:15:24 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:34 --> Config Class Initialized
INFO - 2025-05-06 12:15:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:34 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:34 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:34 --> URI Class Initialized
INFO - 2025-05-06 12:15:34 --> Router Class Initialized
INFO - 2025-05-06 12:15:34 --> Output Class Initialized
INFO - 2025-05-06 12:15:34 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:34 --> Input Class Initialized
INFO - 2025-05-06 12:15:34 --> Language Class Initialized
INFO - 2025-05-06 12:15:34 --> Loader Class Initialized
INFO - 2025-05-06 12:15:34 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:34 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:34 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:34 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:34 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:34 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:34 --> Controller Class Initialized
INFO - 2025-05-06 20:15:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:15:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:15:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:15:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:15:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:15:34 --> Final output sent to browser
DEBUG - 2025-05-06 20:15:34 --> Total execution time: 0.2214
INFO - 2025-05-06 12:15:40 --> Config Class Initialized
INFO - 2025-05-06 12:15:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:40 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:40 --> URI Class Initialized
INFO - 2025-05-06 12:15:40 --> Router Class Initialized
INFO - 2025-05-06 12:15:40 --> Output Class Initialized
INFO - 2025-05-06 12:15:40 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:40 --> Input Class Initialized
INFO - 2025-05-06 12:15:40 --> Language Class Initialized
INFO - 2025-05-06 12:15:40 --> Loader Class Initialized
INFO - 2025-05-06 12:15:40 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:40 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:40 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:40 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:40 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:40 --> Controller Class Initialized
INFO - 2025-05-06 20:15:40 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:15:54 --> Config Class Initialized
INFO - 2025-05-06 12:15:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:54 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:54 --> URI Class Initialized
INFO - 2025-05-06 12:15:54 --> Router Class Initialized
INFO - 2025-05-06 12:15:54 --> Output Class Initialized
INFO - 2025-05-06 12:15:54 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:54 --> Input Class Initialized
INFO - 2025-05-06 12:15:54 --> Language Class Initialized
INFO - 2025-05-06 12:15:54 --> Loader Class Initialized
INFO - 2025-05-06 12:15:54 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:54 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:54 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:54 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:54 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:54 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:54 --> Controller Class Initialized
INFO - 2025-05-06 20:15:54 --> Model "AuctionModel" initialized
INFO - 2025-05-06 20:15:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:15:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:15:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 20:15:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:15:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:15:54 --> Final output sent to browser
DEBUG - 2025-05-06 20:15:54 --> Total execution time: 0.2335
INFO - 2025-05-06 12:15:54 --> Config Class Initialized
INFO - 2025-05-06 12:15:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:55 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:55 --> URI Class Initialized
INFO - 2025-05-06 12:15:55 --> Router Class Initialized
INFO - 2025-05-06 12:15:55 --> Output Class Initialized
INFO - 2025-05-06 12:15:55 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:55 --> Input Class Initialized
INFO - 2025-05-06 12:15:55 --> Language Class Initialized
INFO - 2025-05-06 12:15:55 --> Loader Class Initialized
INFO - 2025-05-06 12:15:55 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:55 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:55 --> Controller Class Initialized
INFO - 2025-05-06 12:15:55 --> Config Class Initialized
INFO - 2025-05-06 12:15:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:15:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:15:55 --> Utf8 Class Initialized
INFO - 2025-05-06 12:15:55 --> URI Class Initialized
INFO - 2025-05-06 12:15:55 --> Router Class Initialized
INFO - 2025-05-06 12:15:55 --> Output Class Initialized
INFO - 2025-05-06 12:15:55 --> Security Class Initialized
DEBUG - 2025-05-06 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:15:55 --> Input Class Initialized
INFO - 2025-05-06 12:15:55 --> Language Class Initialized
INFO - 2025-05-06 12:15:55 --> Loader Class Initialized
INFO - 2025-05-06 12:15:55 --> Helper loaded: url_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: string_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: form_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: file_helper
INFO - 2025-05-06 12:15:55 --> Helper loaded: html_helper
INFO - 2025-05-06 12:15:55 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:15:55 --> Controller Class Initialized
INFO - 2025-05-06 20:15:55 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:16:08 --> Config Class Initialized
INFO - 2025-05-06 12:16:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:08 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:08 --> URI Class Initialized
INFO - 2025-05-06 12:16:08 --> Router Class Initialized
INFO - 2025-05-06 12:16:08 --> Output Class Initialized
INFO - 2025-05-06 12:16:08 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:08 --> Input Class Initialized
INFO - 2025-05-06 12:16:08 --> Language Class Initialized
INFO - 2025-05-06 12:16:08 --> Loader Class Initialized
INFO - 2025-05-06 12:16:08 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:08 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:08 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:08 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:08 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:08 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:08 --> Controller Class Initialized
INFO - 2025-05-06 20:16:08 --> Model "AuctionModel" initialized
INFO - 2025-05-06 20:16:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:16:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:16:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 20:16:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:16:08 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:16:08 --> Final output sent to browser
DEBUG - 2025-05-06 20:16:08 --> Total execution time: 0.1339
INFO - 2025-05-06 12:16:09 --> Config Class Initialized
INFO - 2025-05-06 12:16:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:09 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:09 --> URI Class Initialized
INFO - 2025-05-06 12:16:09 --> Router Class Initialized
INFO - 2025-05-06 12:16:09 --> Output Class Initialized
INFO - 2025-05-06 12:16:09 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:09 --> Input Class Initialized
INFO - 2025-05-06 12:16:09 --> Language Class Initialized
INFO - 2025-05-06 12:16:09 --> Loader Class Initialized
INFO - 2025-05-06 12:16:09 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:09 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:09 --> Controller Class Initialized
INFO - 2025-05-06 12:16:09 --> Config Class Initialized
INFO - 2025-05-06 12:16:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:09 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:09 --> URI Class Initialized
INFO - 2025-05-06 12:16:09 --> Router Class Initialized
INFO - 2025-05-06 12:16:09 --> Output Class Initialized
INFO - 2025-05-06 12:16:09 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:09 --> Input Class Initialized
INFO - 2025-05-06 12:16:09 --> Language Class Initialized
INFO - 2025-05-06 12:16:09 --> Loader Class Initialized
INFO - 2025-05-06 12:16:09 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:09 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:09 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:09 --> Controller Class Initialized
INFO - 2025-05-06 20:16:09 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:16:11 --> Config Class Initialized
INFO - 2025-05-06 12:16:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:11 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:11 --> URI Class Initialized
INFO - 2025-05-06 12:16:11 --> Router Class Initialized
INFO - 2025-05-06 12:16:11 --> Output Class Initialized
INFO - 2025-05-06 12:16:11 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:11 --> Input Class Initialized
INFO - 2025-05-06 12:16:11 --> Language Class Initialized
INFO - 2025-05-06 12:16:11 --> Loader Class Initialized
INFO - 2025-05-06 12:16:11 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:11 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:11 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:11 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:11 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:11 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:11 --> Controller Class Initialized
INFO - 2025-05-06 20:16:11 --> Model "AuctionModel" initialized
INFO - 2025-05-06 20:16:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:16:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:16:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 20:16:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:16:11 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:16:11 --> Final output sent to browser
DEBUG - 2025-05-06 20:16:11 --> Total execution time: 0.1226
INFO - 2025-05-06 12:16:12 --> Config Class Initialized
INFO - 2025-05-06 12:16:12 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:12 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:12 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:12 --> URI Class Initialized
INFO - 2025-05-06 12:16:12 --> Router Class Initialized
INFO - 2025-05-06 12:16:12 --> Output Class Initialized
INFO - 2025-05-06 12:16:12 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:12 --> Input Class Initialized
INFO - 2025-05-06 12:16:12 --> Language Class Initialized
INFO - 2025-05-06 12:16:12 --> Loader Class Initialized
INFO - 2025-05-06 12:16:12 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:12 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:12 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:12 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:12 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:13 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:13 --> Controller Class Initialized
INFO - 2025-05-06 12:16:13 --> Config Class Initialized
INFO - 2025-05-06 12:16:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:13 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:13 --> URI Class Initialized
INFO - 2025-05-06 12:16:13 --> Router Class Initialized
INFO - 2025-05-06 12:16:13 --> Output Class Initialized
INFO - 2025-05-06 12:16:13 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:13 --> Input Class Initialized
INFO - 2025-05-06 12:16:13 --> Language Class Initialized
INFO - 2025-05-06 12:16:13 --> Loader Class Initialized
INFO - 2025-05-06 12:16:13 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:13 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:13 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:13 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:13 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:13 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:13 --> Controller Class Initialized
INFO - 2025-05-06 20:16:13 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:16:31 --> Config Class Initialized
INFO - 2025-05-06 12:16:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:31 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:31 --> URI Class Initialized
INFO - 2025-05-06 12:16:31 --> Router Class Initialized
INFO - 2025-05-06 12:16:31 --> Output Class Initialized
INFO - 2025-05-06 12:16:31 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:31 --> Input Class Initialized
INFO - 2025-05-06 12:16:31 --> Language Class Initialized
INFO - 2025-05-06 12:16:31 --> Loader Class Initialized
INFO - 2025-05-06 12:16:31 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:31 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:31 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:31 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:31 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:31 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:31 --> Controller Class Initialized
INFO - 2025-05-06 20:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 20:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:16:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:16:31 --> Final output sent to browser
DEBUG - 2025-05-06 20:16:31 --> Total execution time: 0.1673
INFO - 2025-05-06 12:16:33 --> Config Class Initialized
INFO - 2025-05-06 12:16:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:16:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:16:33 --> Utf8 Class Initialized
INFO - 2025-05-06 12:16:33 --> URI Class Initialized
INFO - 2025-05-06 12:16:33 --> Router Class Initialized
INFO - 2025-05-06 12:16:33 --> Output Class Initialized
INFO - 2025-05-06 12:16:33 --> Security Class Initialized
DEBUG - 2025-05-06 12:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:16:33 --> Input Class Initialized
INFO - 2025-05-06 12:16:33 --> Language Class Initialized
INFO - 2025-05-06 12:16:33 --> Loader Class Initialized
INFO - 2025-05-06 12:16:33 --> Helper loaded: url_helper
INFO - 2025-05-06 12:16:33 --> Helper loaded: string_helper
INFO - 2025-05-06 12:16:33 --> Helper loaded: form_helper
INFO - 2025-05-06 12:16:33 --> Helper loaded: file_helper
INFO - 2025-05-06 12:16:33 --> Helper loaded: html_helper
INFO - 2025-05-06 12:16:33 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:16:33 --> Controller Class Initialized
INFO - 2025-05-06 20:16:33 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:17:35 --> Config Class Initialized
INFO - 2025-05-06 12:17:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:35 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:35 --> URI Class Initialized
DEBUG - 2025-05-06 12:17:35 --> No URI present. Default controller set.
INFO - 2025-05-06 12:17:35 --> Router Class Initialized
INFO - 2025-05-06 12:17:35 --> Output Class Initialized
INFO - 2025-05-06 12:17:35 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:35 --> Input Class Initialized
INFO - 2025-05-06 12:17:35 --> Language Class Initialized
INFO - 2025-05-06 12:17:36 --> Loader Class Initialized
INFO - 2025-05-06 12:17:36 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:36 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:36 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:36 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:36 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:36 --> Controller Class Initialized
INFO - 2025-05-06 12:17:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 12:17:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 12:17:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 12:17:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 12:17:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 12:17:36 --> Final output sent to browser
DEBUG - 2025-05-06 12:17:36 --> Total execution time: 0.1812
INFO - 2025-05-06 12:17:37 --> Config Class Initialized
INFO - 2025-05-06 12:17:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:37 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:37 --> URI Class Initialized
INFO - 2025-05-06 12:17:37 --> Router Class Initialized
INFO - 2025-05-06 12:17:37 --> Output Class Initialized
INFO - 2025-05-06 12:17:37 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:37 --> Input Class Initialized
INFO - 2025-05-06 12:17:37 --> Language Class Initialized
INFO - 2025-05-06 12:17:37 --> Loader Class Initialized
INFO - 2025-05-06 12:17:37 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:37 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:37 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:37 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:37 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:37 --> Controller Class Initialized
INFO - 2025-05-06 20:17:37 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:17:47 --> Config Class Initialized
INFO - 2025-05-06 12:17:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:47 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:47 --> URI Class Initialized
INFO - 2025-05-06 12:17:47 --> Router Class Initialized
INFO - 2025-05-06 12:17:47 --> Output Class Initialized
INFO - 2025-05-06 12:17:47 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:47 --> Input Class Initialized
INFO - 2025-05-06 12:17:47 --> Language Class Initialized
INFO - 2025-05-06 12:17:47 --> Loader Class Initialized
INFO - 2025-05-06 12:17:47 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:47 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:47 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:47 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:47 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:47 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:47 --> Controller Class Initialized
INFO - 2025-05-06 20:17:47 --> Model "UserModel" initialized
INFO - 2025-05-06 12:17:48 --> Config Class Initialized
INFO - 2025-05-06 12:17:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:48 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:48 --> URI Class Initialized
DEBUG - 2025-05-06 12:17:48 --> No URI present. Default controller set.
INFO - 2025-05-06 12:17:48 --> Router Class Initialized
INFO - 2025-05-06 12:17:48 --> Output Class Initialized
INFO - 2025-05-06 12:17:48 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:48 --> Input Class Initialized
INFO - 2025-05-06 12:17:48 --> Language Class Initialized
INFO - 2025-05-06 12:17:48 --> Loader Class Initialized
INFO - 2025-05-06 12:17:48 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:48 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:48 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:48 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:48 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:48 --> Controller Class Initialized
INFO - 2025-05-06 12:17:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 12:17:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 12:17:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 12:17:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 12:17:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 12:17:48 --> Final output sent to browser
DEBUG - 2025-05-06 12:17:48 --> Total execution time: 0.1202
INFO - 2025-05-06 12:17:49 --> Config Class Initialized
INFO - 2025-05-06 12:17:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:49 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:49 --> URI Class Initialized
INFO - 2025-05-06 12:17:49 --> Router Class Initialized
INFO - 2025-05-06 12:17:49 --> Output Class Initialized
INFO - 2025-05-06 12:17:49 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:49 --> Input Class Initialized
INFO - 2025-05-06 12:17:49 --> Language Class Initialized
INFO - 2025-05-06 12:17:49 --> Loader Class Initialized
INFO - 2025-05-06 12:17:49 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:49 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:49 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:49 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:49 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:49 --> Controller Class Initialized
INFO - 2025-05-06 20:17:49 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:17:51 --> Config Class Initialized
INFO - 2025-05-06 12:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:51 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:51 --> URI Class Initialized
INFO - 2025-05-06 12:17:51 --> Router Class Initialized
INFO - 2025-05-06 12:17:51 --> Output Class Initialized
INFO - 2025-05-06 12:17:51 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:51 --> Input Class Initialized
INFO - 2025-05-06 12:17:51 --> Language Class Initialized
INFO - 2025-05-06 12:17:51 --> Loader Class Initialized
INFO - 2025-05-06 12:17:51 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:51 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:51 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:51 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:51 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:51 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:51 --> Controller Class Initialized
INFO - 2025-05-06 12:17:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 12:17:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 12:17:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/index.php
INFO - 2025-05-06 12:17:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 12:17:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 12:17:51 --> Final output sent to browser
DEBUG - 2025-05-06 12:17:51 --> Total execution time: 0.3180
INFO - 2025-05-06 12:17:52 --> Config Class Initialized
INFO - 2025-05-06 12:17:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:52 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:52 --> URI Class Initialized
INFO - 2025-05-06 12:17:52 --> Config Class Initialized
INFO - 2025-05-06 12:17:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:52 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:52 --> URI Class Initialized
INFO - 2025-05-06 12:17:52 --> Router Class Initialized
INFO - 2025-05-06 12:17:52 --> Router Class Initialized
INFO - 2025-05-06 12:17:52 --> Output Class Initialized
INFO - 2025-05-06 12:17:52 --> Output Class Initialized
INFO - 2025-05-06 12:17:52 --> Security Class Initialized
INFO - 2025-05-06 12:17:52 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:52 --> Input Class Initialized
DEBUG - 2025-05-06 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:52 --> Language Class Initialized
INFO - 2025-05-06 12:17:52 --> Input Class Initialized
INFO - 2025-05-06 12:17:52 --> Language Class Initialized
INFO - 2025-05-06 12:17:52 --> Loader Class Initialized
INFO - 2025-05-06 12:17:52 --> Loader Class Initialized
INFO - 2025-05-06 12:17:52 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:52 --> Database Driver Class Initialized
INFO - 2025-05-06 12:17:52 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-05-06 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:52 --> Controller Class Initialized
INFO - 2025-05-06 20:17:52 --> Model "CompanyModel" initialized
INFO - 2025-05-06 20:17:52 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-06 20:17:52 --> Model "AuctionModel" initialized
INFO - 2025-05-06 20:17:52 --> Final output sent to browser
DEBUG - 2025-05-06 20:17:52 --> Total execution time: 0.3710
INFO - 2025-05-06 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:52 --> Controller Class Initialized
INFO - 2025-05-06 20:17:52 --> Model "AuctionModel" initialized
INFO - 2025-05-06 20:17:52 --> Final output sent to browser
DEBUG - 2025-05-06 20:17:52 --> Total execution time: 0.3710
INFO - 2025-05-06 12:17:52 --> Config Class Initialized
INFO - 2025-05-06 12:17:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:52 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:52 --> URI Class Initialized
INFO - 2025-05-06 12:17:52 --> Router Class Initialized
INFO - 2025-05-06 12:17:52 --> Output Class Initialized
INFO - 2025-05-06 12:17:52 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:52 --> Input Class Initialized
INFO - 2025-05-06 12:17:52 --> Language Class Initialized
INFO - 2025-05-06 12:17:52 --> Loader Class Initialized
INFO - 2025-05-06 12:17:52 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:52 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:52 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:52 --> Controller Class Initialized
INFO - 2025-05-06 12:17:52 --> Model "UserModel" initialized
INFO - 2025-05-06 12:17:52 --> Final output sent to browser
DEBUG - 2025-05-06 12:17:52 --> Total execution time: 0.1563
INFO - 2025-05-06 12:17:53 --> Config Class Initialized
INFO - 2025-05-06 12:17:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:53 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:53 --> URI Class Initialized
INFO - 2025-05-06 12:17:53 --> Router Class Initialized
INFO - 2025-05-06 12:17:53 --> Output Class Initialized
INFO - 2025-05-06 12:17:53 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:53 --> Input Class Initialized
INFO - 2025-05-06 12:17:53 --> Language Class Initialized
INFO - 2025-05-06 12:17:53 --> Loader Class Initialized
INFO - 2025-05-06 12:17:53 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:53 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:53 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:53 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:53 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:54 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:54 --> Controller Class Initialized
INFO - 2025-05-06 20:17:54 --> Model "BankModel" initialized
INFO - 2025-05-06 12:17:54 --> Config Class Initialized
INFO - 2025-05-06 12:17:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:17:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:17:54 --> Utf8 Class Initialized
INFO - 2025-05-06 12:17:54 --> URI Class Initialized
INFO - 2025-05-06 12:17:54 --> Router Class Initialized
INFO - 2025-05-06 12:17:54 --> Output Class Initialized
INFO - 2025-05-06 12:17:54 --> Security Class Initialized
DEBUG - 2025-05-06 12:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:17:54 --> Input Class Initialized
INFO - 2025-05-06 12:17:54 --> Language Class Initialized
INFO - 2025-05-06 12:17:54 --> Loader Class Initialized
INFO - 2025-05-06 12:17:54 --> Helper loaded: url_helper
INFO - 2025-05-06 12:17:54 --> Helper loaded: string_helper
INFO - 2025-05-06 12:17:54 --> Helper loaded: form_helper
INFO - 2025-05-06 12:17:54 --> Helper loaded: file_helper
INFO - 2025-05-06 12:17:54 --> Helper loaded: html_helper
INFO - 2025-05-06 12:17:54 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:17:54 --> Controller Class Initialized
INFO - 2025-05-06 20:17:54 --> Model "BankModel" initialized
INFO - 2025-05-06 20:17:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:17:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:17:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:17:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:17:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:17:54 --> Final output sent to browser
DEBUG - 2025-05-06 20:17:54 --> Total execution time: 0.1546
INFO - 2025-05-06 12:18:20 --> Config Class Initialized
INFO - 2025-05-06 12:18:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:18:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:18:20 --> Utf8 Class Initialized
INFO - 2025-05-06 12:18:20 --> URI Class Initialized
DEBUG - 2025-05-06 12:18:20 --> No URI present. Default controller set.
INFO - 2025-05-06 12:18:20 --> Router Class Initialized
INFO - 2025-05-06 12:18:20 --> Output Class Initialized
INFO - 2025-05-06 12:18:20 --> Security Class Initialized
DEBUG - 2025-05-06 12:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:18:20 --> Input Class Initialized
INFO - 2025-05-06 12:18:20 --> Language Class Initialized
INFO - 2025-05-06 12:18:21 --> Loader Class Initialized
INFO - 2025-05-06 12:18:21 --> Helper loaded: url_helper
INFO - 2025-05-06 12:18:21 --> Helper loaded: string_helper
INFO - 2025-05-06 12:18:21 --> Helper loaded: form_helper
INFO - 2025-05-06 12:18:21 --> Helper loaded: file_helper
INFO - 2025-05-06 12:18:21 --> Helper loaded: html_helper
INFO - 2025-05-06 12:18:21 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:18:21 --> Controller Class Initialized
INFO - 2025-05-06 12:18:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 12:18:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 12:18:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 12:18:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 12:18:21 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 12:18:21 --> Final output sent to browser
DEBUG - 2025-05-06 12:18:21 --> Total execution time: 0.0925
INFO - 2025-05-06 12:18:33 --> Config Class Initialized
INFO - 2025-05-06 12:18:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:18:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:18:33 --> Utf8 Class Initialized
INFO - 2025-05-06 12:18:33 --> URI Class Initialized
INFO - 2025-05-06 12:18:34 --> Router Class Initialized
INFO - 2025-05-06 12:18:34 --> Output Class Initialized
INFO - 2025-05-06 12:18:34 --> Security Class Initialized
DEBUG - 2025-05-06 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:18:34 --> Input Class Initialized
INFO - 2025-05-06 12:18:34 --> Language Class Initialized
INFO - 2025-05-06 12:18:34 --> Loader Class Initialized
INFO - 2025-05-06 12:18:34 --> Helper loaded: url_helper
INFO - 2025-05-06 12:18:34 --> Helper loaded: string_helper
INFO - 2025-05-06 12:18:34 --> Helper loaded: form_helper
INFO - 2025-05-06 12:18:34 --> Helper loaded: file_helper
INFO - 2025-05-06 12:18:34 --> Helper loaded: html_helper
INFO - 2025-05-06 12:18:34 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:18:34 --> Controller Class Initialized
INFO - 2025-05-06 20:18:34 --> Model "AuctionModel" initialized
INFO - 2025-05-06 12:42:44 --> Config Class Initialized
INFO - 2025-05-06 12:42:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:42:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:42:44 --> Utf8 Class Initialized
INFO - 2025-05-06 12:42:44 --> URI Class Initialized
INFO - 2025-05-06 12:42:44 --> Router Class Initialized
INFO - 2025-05-06 12:42:44 --> Output Class Initialized
INFO - 2025-05-06 12:42:44 --> Security Class Initialized
DEBUG - 2025-05-06 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:42:44 --> Input Class Initialized
INFO - 2025-05-06 12:42:44 --> Language Class Initialized
INFO - 2025-05-06 12:42:44 --> Loader Class Initialized
INFO - 2025-05-06 12:42:44 --> Helper loaded: url_helper
INFO - 2025-05-06 12:42:44 --> Helper loaded: string_helper
INFO - 2025-05-06 12:42:44 --> Helper loaded: form_helper
INFO - 2025-05-06 12:42:44 --> Helper loaded: file_helper
INFO - 2025-05-06 12:42:44 --> Helper loaded: html_helper
INFO - 2025-05-06 12:42:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:42:44 --> Controller Class Initialized
INFO - 2025-05-06 20:42:44 --> Model "BankModel" initialized
INFO - 2025-05-06 20:42:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:42:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:42:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:42:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:42:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:42:44 --> Final output sent to browser
DEBUG - 2025-05-06 20:42:44 --> Total execution time: 0.2299
INFO - 2025-05-06 12:42:48 --> Config Class Initialized
INFO - 2025-05-06 12:42:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:42:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:42:48 --> Utf8 Class Initialized
INFO - 2025-05-06 12:42:48 --> URI Class Initialized
INFO - 2025-05-06 12:42:48 --> Router Class Initialized
INFO - 2025-05-06 12:42:48 --> Output Class Initialized
INFO - 2025-05-06 12:42:48 --> Security Class Initialized
DEBUG - 2025-05-06 12:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:42:48 --> Input Class Initialized
INFO - 2025-05-06 12:42:48 --> Language Class Initialized
INFO - 2025-05-06 12:42:48 --> Loader Class Initialized
INFO - 2025-05-06 12:42:48 --> Helper loaded: url_helper
INFO - 2025-05-06 12:42:49 --> Helper loaded: string_helper
INFO - 2025-05-06 12:42:49 --> Helper loaded: form_helper
INFO - 2025-05-06 12:42:49 --> Helper loaded: file_helper
INFO - 2025-05-06 12:42:49 --> Helper loaded: html_helper
INFO - 2025-05-06 12:42:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:42:49 --> Controller Class Initialized
INFO - 2025-05-06 20:42:49 --> Model "BankModel" initialized
INFO - 2025-05-06 20:42:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:42:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:42:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:42:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:42:49 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:42:49 --> Final output sent to browser
DEBUG - 2025-05-06 20:42:49 --> Total execution time: 0.0839
INFO - 2025-05-06 12:45:39 --> Config Class Initialized
INFO - 2025-05-06 12:45:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:45:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:45:39 --> Utf8 Class Initialized
INFO - 2025-05-06 12:45:39 --> URI Class Initialized
INFO - 2025-05-06 12:45:39 --> Router Class Initialized
INFO - 2025-05-06 12:45:39 --> Output Class Initialized
INFO - 2025-05-06 12:45:39 --> Security Class Initialized
DEBUG - 2025-05-06 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:45:39 --> Input Class Initialized
INFO - 2025-05-06 12:45:39 --> Language Class Initialized
INFO - 2025-05-06 12:45:39 --> Loader Class Initialized
INFO - 2025-05-06 12:45:39 --> Helper loaded: url_helper
INFO - 2025-05-06 12:45:39 --> Helper loaded: string_helper
INFO - 2025-05-06 12:45:39 --> Helper loaded: form_helper
INFO - 2025-05-06 12:45:39 --> Helper loaded: file_helper
INFO - 2025-05-06 12:45:39 --> Helper loaded: html_helper
INFO - 2025-05-06 12:45:39 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:45:39 --> Controller Class Initialized
INFO - 2025-05-06 20:45:39 --> Model "BankModel" initialized
INFO - 2025-05-06 20:45:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:45:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:45:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:45:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:45:39 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:45:39 --> Final output sent to browser
DEBUG - 2025-05-06 20:45:39 --> Total execution time: 0.1728
INFO - 2025-05-06 12:46:36 --> Config Class Initialized
INFO - 2025-05-06 12:46:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:46:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:46:36 --> Utf8 Class Initialized
INFO - 2025-05-06 12:46:36 --> URI Class Initialized
INFO - 2025-05-06 12:46:36 --> Router Class Initialized
INFO - 2025-05-06 12:46:36 --> Output Class Initialized
INFO - 2025-05-06 12:46:36 --> Security Class Initialized
DEBUG - 2025-05-06 12:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:46:36 --> Input Class Initialized
INFO - 2025-05-06 12:46:36 --> Language Class Initialized
INFO - 2025-05-06 12:46:36 --> Loader Class Initialized
INFO - 2025-05-06 12:46:36 --> Helper loaded: url_helper
INFO - 2025-05-06 12:46:36 --> Helper loaded: string_helper
INFO - 2025-05-06 12:46:36 --> Helper loaded: form_helper
INFO - 2025-05-06 12:46:36 --> Helper loaded: file_helper
INFO - 2025-05-06 12:46:36 --> Helper loaded: html_helper
INFO - 2025-05-06 12:46:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:46:36 --> Controller Class Initialized
INFO - 2025-05-06 20:46:36 --> Model "BankModel" initialized
INFO - 2025-05-06 20:46:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:46:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:46:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:46:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:46:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:46:36 --> Final output sent to browser
DEBUG - 2025-05-06 20:46:36 --> Total execution time: 0.1989
INFO - 2025-05-06 12:47:52 --> Config Class Initialized
INFO - 2025-05-06 12:47:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:47:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:47:52 --> Utf8 Class Initialized
INFO - 2025-05-06 12:47:52 --> URI Class Initialized
INFO - 2025-05-06 12:47:52 --> Router Class Initialized
INFO - 2025-05-06 12:47:52 --> Output Class Initialized
INFO - 2025-05-06 12:47:52 --> Security Class Initialized
DEBUG - 2025-05-06 12:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:47:52 --> Input Class Initialized
INFO - 2025-05-06 12:47:52 --> Language Class Initialized
INFO - 2025-05-06 12:47:52 --> Loader Class Initialized
INFO - 2025-05-06 12:47:52 --> Helper loaded: url_helper
INFO - 2025-05-06 12:47:52 --> Helper loaded: string_helper
INFO - 2025-05-06 12:47:52 --> Helper loaded: form_helper
INFO - 2025-05-06 12:47:52 --> Helper loaded: file_helper
INFO - 2025-05-06 12:47:52 --> Helper loaded: html_helper
INFO - 2025-05-06 12:47:52 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:47:52 --> Controller Class Initialized
INFO - 2025-05-06 20:47:52 --> Model "BankModel" initialized
INFO - 2025-05-06 20:47:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:47:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:47:52 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:47:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:47:53 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:47:53 --> Final output sent to browser
DEBUG - 2025-05-06 20:47:53 --> Total execution time: 0.1708
INFO - 2025-05-06 12:48:40 --> Config Class Initialized
INFO - 2025-05-06 12:48:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:48:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:48:40 --> Utf8 Class Initialized
INFO - 2025-05-06 12:48:40 --> URI Class Initialized
INFO - 2025-05-06 12:48:40 --> Router Class Initialized
INFO - 2025-05-06 12:48:40 --> Output Class Initialized
INFO - 2025-05-06 12:48:40 --> Security Class Initialized
DEBUG - 2025-05-06 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:48:40 --> Input Class Initialized
INFO - 2025-05-06 12:48:40 --> Language Class Initialized
INFO - 2025-05-06 12:48:40 --> Loader Class Initialized
INFO - 2025-05-06 12:48:41 --> Helper loaded: url_helper
INFO - 2025-05-06 12:48:41 --> Helper loaded: string_helper
INFO - 2025-05-06 12:48:41 --> Helper loaded: form_helper
INFO - 2025-05-06 12:48:41 --> Helper loaded: file_helper
INFO - 2025-05-06 12:48:41 --> Helper loaded: html_helper
INFO - 2025-05-06 12:48:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:48:41 --> Controller Class Initialized
INFO - 2025-05-06 20:48:41 --> Model "BankModel" initialized
INFO - 2025-05-06 20:48:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:48:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:48:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:48:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:48:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:48:41 --> Final output sent to browser
DEBUG - 2025-05-06 20:48:41 --> Total execution time: 0.1997
INFO - 2025-05-06 12:51:29 --> Config Class Initialized
INFO - 2025-05-06 12:51:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:51:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:51:29 --> Utf8 Class Initialized
INFO - 2025-05-06 12:51:29 --> URI Class Initialized
INFO - 2025-05-06 12:51:29 --> Router Class Initialized
INFO - 2025-05-06 12:51:30 --> Output Class Initialized
INFO - 2025-05-06 12:51:30 --> Security Class Initialized
DEBUG - 2025-05-06 12:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:51:30 --> Input Class Initialized
INFO - 2025-05-06 12:51:30 --> Language Class Initialized
INFO - 2025-05-06 12:51:30 --> Loader Class Initialized
INFO - 2025-05-06 12:51:30 --> Helper loaded: url_helper
INFO - 2025-05-06 12:51:30 --> Helper loaded: string_helper
INFO - 2025-05-06 12:51:30 --> Helper loaded: form_helper
INFO - 2025-05-06 12:51:30 --> Helper loaded: file_helper
INFO - 2025-05-06 12:51:30 --> Helper loaded: html_helper
INFO - 2025-05-06 12:51:30 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:51:30 --> Controller Class Initialized
INFO - 2025-05-06 20:51:30 --> Model "BankModel" initialized
INFO - 2025-05-06 20:51:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:51:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:51:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:51:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:51:30 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:51:30 --> Final output sent to browser
DEBUG - 2025-05-06 20:51:30 --> Total execution time: 0.2108
INFO - 2025-05-06 12:51:54 --> Config Class Initialized
INFO - 2025-05-06 12:51:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:51:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:51:54 --> Utf8 Class Initialized
INFO - 2025-05-06 12:51:54 --> URI Class Initialized
INFO - 2025-05-06 12:51:54 --> Router Class Initialized
INFO - 2025-05-06 12:51:54 --> Output Class Initialized
INFO - 2025-05-06 12:51:54 --> Security Class Initialized
DEBUG - 2025-05-06 12:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:51:54 --> Input Class Initialized
INFO - 2025-05-06 12:51:54 --> Language Class Initialized
INFO - 2025-05-06 12:51:54 --> Loader Class Initialized
INFO - 2025-05-06 12:51:54 --> Helper loaded: url_helper
INFO - 2025-05-06 12:51:54 --> Helper loaded: string_helper
INFO - 2025-05-06 12:51:54 --> Helper loaded: form_helper
INFO - 2025-05-06 12:51:54 --> Helper loaded: file_helper
INFO - 2025-05-06 12:51:54 --> Helper loaded: html_helper
INFO - 2025-05-06 12:51:54 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:51:54 --> Controller Class Initialized
INFO - 2025-05-06 20:51:54 --> Model "BankModel" initialized
INFO - 2025-05-06 20:51:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:51:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:51:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:51:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:51:54 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:51:54 --> Final output sent to browser
DEBUG - 2025-05-06 20:51:55 --> Total execution time: 0.2339
INFO - 2025-05-06 12:52:42 --> Config Class Initialized
INFO - 2025-05-06 12:52:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:52:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:52:42 --> Utf8 Class Initialized
INFO - 2025-05-06 12:52:42 --> URI Class Initialized
INFO - 2025-05-06 12:52:42 --> Router Class Initialized
INFO - 2025-05-06 12:52:42 --> Output Class Initialized
INFO - 2025-05-06 12:52:42 --> Security Class Initialized
DEBUG - 2025-05-06 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:52:42 --> Input Class Initialized
INFO - 2025-05-06 12:52:42 --> Language Class Initialized
INFO - 2025-05-06 12:52:42 --> Loader Class Initialized
INFO - 2025-05-06 12:52:42 --> Helper loaded: url_helper
INFO - 2025-05-06 12:52:42 --> Helper loaded: string_helper
INFO - 2025-05-06 12:52:42 --> Helper loaded: form_helper
INFO - 2025-05-06 12:52:42 --> Helper loaded: file_helper
INFO - 2025-05-06 12:52:42 --> Helper loaded: html_helper
INFO - 2025-05-06 12:52:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:52:42 --> Controller Class Initialized
INFO - 2025-05-06 20:52:42 --> Model "BankModel" initialized
INFO - 2025-05-06 20:52:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:52:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:52:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:52:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:52:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:52:42 --> Final output sent to browser
DEBUG - 2025-05-06 20:52:42 --> Total execution time: 0.1675
INFO - 2025-05-06 12:53:15 --> Config Class Initialized
INFO - 2025-05-06 12:53:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:53:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:53:15 --> Utf8 Class Initialized
INFO - 2025-05-06 12:53:15 --> URI Class Initialized
INFO - 2025-05-06 12:53:15 --> Router Class Initialized
INFO - 2025-05-06 12:53:15 --> Output Class Initialized
INFO - 2025-05-06 12:53:15 --> Security Class Initialized
DEBUG - 2025-05-06 12:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:53:15 --> Input Class Initialized
INFO - 2025-05-06 12:53:15 --> Language Class Initialized
INFO - 2025-05-06 12:53:15 --> Loader Class Initialized
INFO - 2025-05-06 12:53:15 --> Helper loaded: url_helper
INFO - 2025-05-06 12:53:15 --> Helper loaded: string_helper
INFO - 2025-05-06 12:53:15 --> Helper loaded: form_helper
INFO - 2025-05-06 12:53:15 --> Helper loaded: file_helper
INFO - 2025-05-06 12:53:15 --> Helper loaded: html_helper
INFO - 2025-05-06 12:53:15 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:53:15 --> Controller Class Initialized
INFO - 2025-05-06 20:53:15 --> Model "BankModel" initialized
INFO - 2025-05-06 20:53:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:53:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:53:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:53:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:53:15 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:53:15 --> Final output sent to browser
DEBUG - 2025-05-06 20:53:15 --> Total execution time: 0.1519
INFO - 2025-05-06 12:53:25 --> Config Class Initialized
INFO - 2025-05-06 12:53:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:53:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:53:25 --> Utf8 Class Initialized
INFO - 2025-05-06 12:53:25 --> URI Class Initialized
INFO - 2025-05-06 12:53:25 --> Router Class Initialized
INFO - 2025-05-06 12:53:25 --> Output Class Initialized
INFO - 2025-05-06 12:53:25 --> Security Class Initialized
DEBUG - 2025-05-06 12:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:53:25 --> Input Class Initialized
INFO - 2025-05-06 12:53:25 --> Language Class Initialized
INFO - 2025-05-06 12:53:25 --> Loader Class Initialized
INFO - 2025-05-06 12:53:25 --> Helper loaded: url_helper
INFO - 2025-05-06 12:53:25 --> Helper loaded: string_helper
INFO - 2025-05-06 12:53:25 --> Helper loaded: form_helper
INFO - 2025-05-06 12:53:25 --> Helper loaded: file_helper
INFO - 2025-05-06 12:53:25 --> Helper loaded: html_helper
INFO - 2025-05-06 12:53:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:53:25 --> Controller Class Initialized
INFO - 2025-05-06 20:53:25 --> Model "BankModel" initialized
INFO - 2025-05-06 20:53:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:53:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:53:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:53:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:53:25 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:53:25 --> Final output sent to browser
DEBUG - 2025-05-06 20:53:25 --> Total execution time: 0.2395
INFO - 2025-05-06 12:55:40 --> Config Class Initialized
INFO - 2025-05-06 12:55:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:55:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:55:40 --> Utf8 Class Initialized
INFO - 2025-05-06 12:55:40 --> URI Class Initialized
INFO - 2025-05-06 12:55:40 --> Router Class Initialized
INFO - 2025-05-06 12:55:40 --> Output Class Initialized
INFO - 2025-05-06 12:55:40 --> Security Class Initialized
DEBUG - 2025-05-06 12:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:55:40 --> Input Class Initialized
INFO - 2025-05-06 12:55:40 --> Language Class Initialized
INFO - 2025-05-06 12:55:40 --> Loader Class Initialized
INFO - 2025-05-06 12:55:40 --> Helper loaded: url_helper
INFO - 2025-05-06 12:55:40 --> Helper loaded: string_helper
INFO - 2025-05-06 12:55:40 --> Helper loaded: form_helper
INFO - 2025-05-06 12:55:40 --> Helper loaded: file_helper
INFO - 2025-05-06 12:55:40 --> Helper loaded: html_helper
INFO - 2025-05-06 12:55:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:55:40 --> Controller Class Initialized
INFO - 2025-05-06 20:55:40 --> Model "BankModel" initialized
INFO - 2025-05-06 20:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:55:40 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:55:40 --> Final output sent to browser
DEBUG - 2025-05-06 20:55:40 --> Total execution time: 0.0807
INFO - 2025-05-06 12:56:02 --> Config Class Initialized
INFO - 2025-05-06 12:56:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:56:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:56:02 --> Utf8 Class Initialized
INFO - 2025-05-06 12:56:02 --> URI Class Initialized
INFO - 2025-05-06 12:56:02 --> Router Class Initialized
INFO - 2025-05-06 12:56:02 --> Output Class Initialized
INFO - 2025-05-06 12:56:02 --> Security Class Initialized
DEBUG - 2025-05-06 12:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:56:02 --> Input Class Initialized
INFO - 2025-05-06 12:56:02 --> Language Class Initialized
INFO - 2025-05-06 12:56:02 --> Loader Class Initialized
INFO - 2025-05-06 12:56:02 --> Helper loaded: url_helper
INFO - 2025-05-06 12:56:02 --> Helper loaded: string_helper
INFO - 2025-05-06 12:56:02 --> Helper loaded: form_helper
INFO - 2025-05-06 12:56:02 --> Helper loaded: file_helper
INFO - 2025-05-06 12:56:02 --> Helper loaded: html_helper
INFO - 2025-05-06 12:56:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:56:02 --> Controller Class Initialized
INFO - 2025-05-06 20:56:02 --> Model "BankModel" initialized
INFO - 2025-05-06 20:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:56:02 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:56:02 --> Final output sent to browser
DEBUG - 2025-05-06 20:56:02 --> Total execution time: 0.2821
INFO - 2025-05-06 12:58:06 --> Config Class Initialized
INFO - 2025-05-06 12:58:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:58:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:58:06 --> Utf8 Class Initialized
INFO - 2025-05-06 12:58:06 --> URI Class Initialized
INFO - 2025-05-06 12:58:06 --> Router Class Initialized
INFO - 2025-05-06 12:58:06 --> Output Class Initialized
INFO - 2025-05-06 12:58:06 --> Security Class Initialized
DEBUG - 2025-05-06 12:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:58:06 --> Input Class Initialized
INFO - 2025-05-06 12:58:06 --> Language Class Initialized
INFO - 2025-05-06 12:58:06 --> Loader Class Initialized
INFO - 2025-05-06 12:58:06 --> Helper loaded: url_helper
INFO - 2025-05-06 12:58:06 --> Helper loaded: string_helper
INFO - 2025-05-06 12:58:06 --> Helper loaded: form_helper
INFO - 2025-05-06 12:58:06 --> Helper loaded: file_helper
INFO - 2025-05-06 12:58:06 --> Helper loaded: html_helper
INFO - 2025-05-06 12:58:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:58:06 --> Controller Class Initialized
INFO - 2025-05-06 20:58:06 --> Model "BankModel" initialized
INFO - 2025-05-06 20:58:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 20:58:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 20:58:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 20:58:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 20:58:06 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 20:58:06 --> Final output sent to browser
DEBUG - 2025-05-06 20:58:06 --> Total execution time: 0.1043
INFO - 2025-05-06 12:58:22 --> Config Class Initialized
INFO - 2025-05-06 12:58:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:58:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:58:22 --> Utf8 Class Initialized
INFO - 2025-05-06 12:58:22 --> URI Class Initialized
INFO - 2025-05-06 12:58:22 --> Router Class Initialized
INFO - 2025-05-06 12:58:22 --> Output Class Initialized
INFO - 2025-05-06 12:58:22 --> Security Class Initialized
DEBUG - 2025-05-06 12:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:58:22 --> Input Class Initialized
INFO - 2025-05-06 12:58:22 --> Language Class Initialized
INFO - 2025-05-06 12:58:22 --> Loader Class Initialized
INFO - 2025-05-06 12:58:22 --> Helper loaded: url_helper
INFO - 2025-05-06 12:58:22 --> Helper loaded: string_helper
INFO - 2025-05-06 12:58:22 --> Helper loaded: form_helper
INFO - 2025-05-06 12:58:22 --> Helper loaded: file_helper
INFO - 2025-05-06 12:58:22 --> Helper loaded: html_helper
INFO - 2025-05-06 12:58:22 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:58:22 --> Controller Class Initialized
INFO - 2025-05-06 12:58:23 --> Config Class Initialized
INFO - 2025-05-06 12:58:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:58:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:58:23 --> Utf8 Class Initialized
INFO - 2025-05-06 12:58:23 --> URI Class Initialized
INFO - 2025-05-06 12:58:23 --> Router Class Initialized
INFO - 2025-05-06 12:58:23 --> Output Class Initialized
INFO - 2025-05-06 12:58:23 --> Security Class Initialized
DEBUG - 2025-05-06 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:58:23 --> Input Class Initialized
INFO - 2025-05-06 12:58:23 --> Language Class Initialized
INFO - 2025-05-06 12:58:23 --> Loader Class Initialized
INFO - 2025-05-06 12:58:23 --> Helper loaded: url_helper
INFO - 2025-05-06 12:58:23 --> Helper loaded: string_helper
INFO - 2025-05-06 12:58:23 --> Helper loaded: form_helper
INFO - 2025-05-06 12:58:23 --> Helper loaded: file_helper
INFO - 2025-05-06 12:58:23 --> Helper loaded: html_helper
INFO - 2025-05-06 12:58:23 --> Database Driver Class Initialized
DEBUG - 2025-05-06 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:58:23 --> Controller Class Initialized
INFO - 2025-05-06 13:16:18 --> Config Class Initialized
INFO - 2025-05-06 13:16:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:16:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:16:18 --> Utf8 Class Initialized
INFO - 2025-05-06 13:16:18 --> URI Class Initialized
INFO - 2025-05-06 13:16:18 --> Router Class Initialized
INFO - 2025-05-06 13:16:18 --> Output Class Initialized
INFO - 2025-05-06 13:16:18 --> Security Class Initialized
DEBUG - 2025-05-06 13:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:16:18 --> Input Class Initialized
INFO - 2025-05-06 13:16:18 --> Language Class Initialized
INFO - 2025-05-06 13:16:18 --> Loader Class Initialized
INFO - 2025-05-06 13:16:18 --> Helper loaded: url_helper
INFO - 2025-05-06 13:16:18 --> Helper loaded: string_helper
INFO - 2025-05-06 13:16:18 --> Helper loaded: form_helper
INFO - 2025-05-06 13:16:18 --> Helper loaded: file_helper
INFO - 2025-05-06 13:16:18 --> Helper loaded: html_helper
INFO - 2025-05-06 13:16:18 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:16:18 --> Controller Class Initialized
INFO - 2025-05-06 21:16:18 --> Model "BankModel" initialized
INFO - 2025-05-06 21:16:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:16:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:16:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 21:16:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:16:18 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:16:18 --> Final output sent to browser
DEBUG - 2025-05-06 21:16:18 --> Total execution time: 0.2934
INFO - 2025-05-06 13:16:39 --> Config Class Initialized
INFO - 2025-05-06 13:16:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:16:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:16:39 --> Utf8 Class Initialized
INFO - 2025-05-06 13:16:39 --> URI Class Initialized
INFO - 2025-05-06 13:16:39 --> Router Class Initialized
INFO - 2025-05-06 13:16:39 --> Output Class Initialized
INFO - 2025-05-06 13:16:39 --> Security Class Initialized
DEBUG - 2025-05-06 13:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:16:39 --> Input Class Initialized
INFO - 2025-05-06 13:16:39 --> Language Class Initialized
INFO - 2025-05-06 13:16:39 --> Loader Class Initialized
INFO - 2025-05-06 13:16:39 --> Helper loaded: url_helper
INFO - 2025-05-06 13:16:39 --> Helper loaded: string_helper
INFO - 2025-05-06 13:16:39 --> Helper loaded: form_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: file_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: html_helper
INFO - 2025-05-06 13:16:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:16:40 --> Controller Class Initialized
INFO - 2025-05-06 13:16:40 --> Config Class Initialized
INFO - 2025-05-06 13:16:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:16:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:16:40 --> Utf8 Class Initialized
INFO - 2025-05-06 13:16:40 --> URI Class Initialized
INFO - 2025-05-06 13:16:40 --> Router Class Initialized
INFO - 2025-05-06 13:16:40 --> Output Class Initialized
INFO - 2025-05-06 13:16:40 --> Security Class Initialized
DEBUG - 2025-05-06 13:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:16:40 --> Input Class Initialized
INFO - 2025-05-06 13:16:40 --> Language Class Initialized
INFO - 2025-05-06 13:16:40 --> Loader Class Initialized
INFO - 2025-05-06 13:16:40 --> Helper loaded: url_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: string_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: form_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: file_helper
INFO - 2025-05-06 13:16:40 --> Helper loaded: html_helper
INFO - 2025-05-06 13:16:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:16:40 --> Controller Class Initialized
INFO - 2025-05-06 13:20:52 --> Config Class Initialized
INFO - 2025-05-06 13:20:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:20:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:20:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:20:52 --> URI Class Initialized
INFO - 2025-05-06 13:20:52 --> Router Class Initialized
INFO - 2025-05-06 13:20:52 --> Output Class Initialized
INFO - 2025-05-06 13:20:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:20:52 --> Input Class Initialized
INFO - 2025-05-06 13:20:52 --> Language Class Initialized
INFO - 2025-05-06 13:20:52 --> Loader Class Initialized
INFO - 2025-05-06 13:20:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:20:52 --> Helper loaded: string_helper
INFO - 2025-05-06 13:20:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:20:52 --> Helper loaded: file_helper
INFO - 2025-05-06 13:20:52 --> Helper loaded: html_helper
INFO - 2025-05-06 13:20:52 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:20:52 --> Controller Class Initialized
INFO - 2025-05-06 21:21:00 --> Final output sent to browser
DEBUG - 2025-05-06 21:21:00 --> Total execution time: 8.2793
INFO - 2025-05-06 13:21:00 --> Config Class Initialized
INFO - 2025-05-06 13:21:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:21:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:21:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:21:00 --> URI Class Initialized
INFO - 2025-05-06 13:21:00 --> Router Class Initialized
INFO - 2025-05-06 13:21:00 --> Output Class Initialized
INFO - 2025-05-06 13:21:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:21:00 --> Input Class Initialized
INFO - 2025-05-06 13:21:00 --> Language Class Initialized
INFO - 2025-05-06 13:21:00 --> Loader Class Initialized
INFO - 2025-05-06 13:21:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:21:00 --> Helper loaded: string_helper
INFO - 2025-05-06 13:21:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:21:00 --> Helper loaded: file_helper
INFO - 2025-05-06 13:21:00 --> Helper loaded: html_helper
INFO - 2025-05-06 13:21:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:21:00 --> Controller Class Initialized
INFO - 2025-05-06 21:21:01 --> Final output sent to browser
DEBUG - 2025-05-06 21:21:01 --> Total execution time: 1.3415
INFO - 2025-05-06 13:21:01 --> Config Class Initialized
INFO - 2025-05-06 13:21:01 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:21:01 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:21:01 --> Utf8 Class Initialized
INFO - 2025-05-06 13:21:01 --> URI Class Initialized
INFO - 2025-05-06 13:21:02 --> Router Class Initialized
INFO - 2025-05-06 13:21:02 --> Output Class Initialized
INFO - 2025-05-06 13:21:02 --> Security Class Initialized
DEBUG - 2025-05-06 13:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:21:02 --> Input Class Initialized
INFO - 2025-05-06 13:21:02 --> Language Class Initialized
INFO - 2025-05-06 13:21:02 --> Loader Class Initialized
INFO - 2025-05-06 13:21:02 --> Helper loaded: url_helper
INFO - 2025-05-06 13:21:02 --> Helper loaded: string_helper
INFO - 2025-05-06 13:21:02 --> Helper loaded: form_helper
INFO - 2025-05-06 13:21:02 --> Helper loaded: file_helper
INFO - 2025-05-06 13:21:02 --> Helper loaded: html_helper
INFO - 2025-05-06 13:21:02 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:21:02 --> Controller Class Initialized
INFO - 2025-05-06 21:21:03 --> Final output sent to browser
DEBUG - 2025-05-06 21:21:03 --> Total execution time: 1.0649
INFO - 2025-05-06 13:30:22 --> Config Class Initialized
INFO - 2025-05-06 13:30:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:30:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:30:22 --> Utf8 Class Initialized
INFO - 2025-05-06 13:30:22 --> URI Class Initialized
INFO - 2025-05-06 13:30:22 --> Router Class Initialized
INFO - 2025-05-06 13:30:22 --> Output Class Initialized
INFO - 2025-05-06 13:30:22 --> Security Class Initialized
DEBUG - 2025-05-06 13:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:30:22 --> Input Class Initialized
INFO - 2025-05-06 13:30:22 --> Language Class Initialized
INFO - 2025-05-06 13:30:22 --> Loader Class Initialized
INFO - 2025-05-06 13:30:22 --> Helper loaded: url_helper
INFO - 2025-05-06 13:30:22 --> Helper loaded: string_helper
INFO - 2025-05-06 13:30:22 --> Helper loaded: form_helper
INFO - 2025-05-06 13:30:22 --> Helper loaded: file_helper
INFO - 2025-05-06 13:30:22 --> Helper loaded: html_helper
INFO - 2025-05-06 13:30:22 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:30:22 --> Controller Class Initialized
INFO - 2025-05-06 21:30:23 --> Final output sent to browser
DEBUG - 2025-05-06 21:30:23 --> Total execution time: 0.8091
INFO - 2025-05-06 13:30:23 --> Config Class Initialized
INFO - 2025-05-06 13:30:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:30:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:30:23 --> Utf8 Class Initialized
INFO - 2025-05-06 13:30:23 --> URI Class Initialized
INFO - 2025-05-06 13:30:23 --> Router Class Initialized
INFO - 2025-05-06 13:30:23 --> Output Class Initialized
INFO - 2025-05-06 13:30:23 --> Security Class Initialized
DEBUG - 2025-05-06 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:30:23 --> Input Class Initialized
INFO - 2025-05-06 13:30:23 --> Language Class Initialized
INFO - 2025-05-06 13:30:23 --> Loader Class Initialized
INFO - 2025-05-06 13:30:23 --> Helper loaded: url_helper
INFO - 2025-05-06 13:30:23 --> Helper loaded: string_helper
INFO - 2025-05-06 13:30:23 --> Helper loaded: form_helper
INFO - 2025-05-06 13:30:23 --> Helper loaded: file_helper
INFO - 2025-05-06 13:30:23 --> Helper loaded: html_helper
INFO - 2025-05-06 13:30:23 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:30:23 --> Controller Class Initialized
INFO - 2025-05-06 21:30:24 --> Final output sent to browser
DEBUG - 2025-05-06 21:30:24 --> Total execution time: 0.6678
INFO - 2025-05-06 13:31:50 --> Config Class Initialized
INFO - 2025-05-06 13:31:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:31:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:31:50 --> Utf8 Class Initialized
INFO - 2025-05-06 13:31:50 --> URI Class Initialized
INFO - 2025-05-06 13:31:50 --> Router Class Initialized
INFO - 2025-05-06 13:31:51 --> Output Class Initialized
INFO - 2025-05-06 13:31:51 --> Security Class Initialized
DEBUG - 2025-05-06 13:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:31:51 --> Input Class Initialized
INFO - 2025-05-06 13:31:51 --> Language Class Initialized
INFO - 2025-05-06 13:31:51 --> Loader Class Initialized
INFO - 2025-05-06 13:31:51 --> Helper loaded: url_helper
INFO - 2025-05-06 13:31:51 --> Helper loaded: string_helper
INFO - 2025-05-06 13:31:51 --> Helper loaded: form_helper
INFO - 2025-05-06 13:31:51 --> Helper loaded: file_helper
INFO - 2025-05-06 13:31:51 --> Helper loaded: html_helper
INFO - 2025-05-06 13:31:51 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:31:51 --> Controller Class Initialized
INFO - 2025-05-06 21:31:51 --> Model "BankModel" initialized
INFO - 2025-05-06 21:31:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:31:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:31:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 21:31:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:31:51 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:31:51 --> Final output sent to browser
DEBUG - 2025-05-06 21:31:51 --> Total execution time: 0.1807
INFO - 2025-05-06 13:31:59 --> Config Class Initialized
INFO - 2025-05-06 13:31:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:31:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:31:59 --> Utf8 Class Initialized
INFO - 2025-05-06 13:31:59 --> URI Class Initialized
INFO - 2025-05-06 13:31:59 --> Router Class Initialized
INFO - 2025-05-06 13:31:59 --> Output Class Initialized
INFO - 2025-05-06 13:32:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:32:00 --> Input Class Initialized
INFO - 2025-05-06 13:32:00 --> Language Class Initialized
INFO - 2025-05-06 13:32:00 --> Loader Class Initialized
INFO - 2025-05-06 13:32:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:32:00 --> Helper loaded: string_helper
INFO - 2025-05-06 13:32:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:32:00 --> Helper loaded: file_helper
INFO - 2025-05-06 13:32:00 --> Helper loaded: html_helper
INFO - 2025-05-06 13:32:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:32:00 --> Controller Class Initialized
INFO - 2025-05-06 21:32:00 --> Model "BankModel" initialized
INFO - 2025-05-06 21:32:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:32:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:32:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 21:32:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:32:00 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:32:00 --> Final output sent to browser
DEBUG - 2025-05-06 21:32:00 --> Total execution time: 0.1361
INFO - 2025-05-06 13:32:04 --> Config Class Initialized
INFO - 2025-05-06 13:32:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:32:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:32:04 --> Utf8 Class Initialized
INFO - 2025-05-06 13:32:04 --> URI Class Initialized
INFO - 2025-05-06 13:32:04 --> Router Class Initialized
INFO - 2025-05-06 13:32:04 --> Output Class Initialized
INFO - 2025-05-06 13:32:04 --> Security Class Initialized
DEBUG - 2025-05-06 13:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:32:04 --> Input Class Initialized
INFO - 2025-05-06 13:32:04 --> Language Class Initialized
INFO - 2025-05-06 13:32:04 --> Loader Class Initialized
INFO - 2025-05-06 13:32:04 --> Helper loaded: url_helper
INFO - 2025-05-06 13:32:04 --> Helper loaded: string_helper
INFO - 2025-05-06 13:32:04 --> Helper loaded: form_helper
INFO - 2025-05-06 13:32:04 --> Helper loaded: file_helper
INFO - 2025-05-06 13:32:04 --> Helper loaded: html_helper
INFO - 2025-05-06 13:32:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:32:04 --> Controller Class Initialized
INFO - 2025-05-06 21:32:04 --> Model "BankModel" initialized
INFO - 2025-05-06 21:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/bank/add_bank.php
INFO - 2025-05-06 21:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:32:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:32:04 --> Final output sent to browser
DEBUG - 2025-05-06 21:32:04 --> Total execution time: 0.0957
INFO - 2025-05-06 13:33:48 --> Config Class Initialized
INFO - 2025-05-06 13:33:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:33:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:33:48 --> Utf8 Class Initialized
INFO - 2025-05-06 13:33:48 --> URI Class Initialized
INFO - 2025-05-06 13:33:48 --> Router Class Initialized
INFO - 2025-05-06 13:33:48 --> Output Class Initialized
INFO - 2025-05-06 13:33:48 --> Security Class Initialized
DEBUG - 2025-05-06 13:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:33:48 --> Input Class Initialized
INFO - 2025-05-06 13:33:48 --> Language Class Initialized
INFO - 2025-05-06 13:33:48 --> Loader Class Initialized
INFO - 2025-05-06 13:33:48 --> Helper loaded: url_helper
INFO - 2025-05-06 13:33:48 --> Helper loaded: string_helper
INFO - 2025-05-06 13:33:48 --> Helper loaded: form_helper
INFO - 2025-05-06 13:33:48 --> Helper loaded: file_helper
INFO - 2025-05-06 13:33:48 --> Helper loaded: html_helper
INFO - 2025-05-06 13:33:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:33:48 --> Controller Class Initialized
INFO - 2025-05-06 21:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:33:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:33:48 --> Final output sent to browser
DEBUG - 2025-05-06 21:33:48 --> Total execution time: 0.1028
INFO - 2025-05-06 13:33:49 --> Config Class Initialized
INFO - 2025-05-06 13:33:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:33:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:33:49 --> Utf8 Class Initialized
INFO - 2025-05-06 13:33:49 --> URI Class Initialized
INFO - 2025-05-06 13:33:49 --> Router Class Initialized
INFO - 2025-05-06 13:33:49 --> Output Class Initialized
INFO - 2025-05-06 13:33:49 --> Security Class Initialized
DEBUG - 2025-05-06 13:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:33:49 --> Input Class Initialized
INFO - 2025-05-06 13:33:49 --> Language Class Initialized
INFO - 2025-05-06 13:33:49 --> Loader Class Initialized
INFO - 2025-05-06 13:33:49 --> Helper loaded: url_helper
INFO - 2025-05-06 13:33:49 --> Helper loaded: string_helper
INFO - 2025-05-06 13:33:49 --> Helper loaded: form_helper
INFO - 2025-05-06 13:33:49 --> Helper loaded: file_helper
INFO - 2025-05-06 13:33:49 --> Helper loaded: html_helper
INFO - 2025-05-06 13:33:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:33:49 --> Controller Class Initialized
INFO - 2025-05-06 21:33:49 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:33:58 --> Config Class Initialized
INFO - 2025-05-06 13:33:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:33:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:33:58 --> Utf8 Class Initialized
INFO - 2025-05-06 13:33:58 --> URI Class Initialized
INFO - 2025-05-06 13:33:58 --> Router Class Initialized
INFO - 2025-05-06 13:33:58 --> Output Class Initialized
INFO - 2025-05-06 13:33:58 --> Security Class Initialized
DEBUG - 2025-05-06 13:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:33:58 --> Input Class Initialized
INFO - 2025-05-06 13:33:58 --> Language Class Initialized
INFO - 2025-05-06 13:33:58 --> Loader Class Initialized
INFO - 2025-05-06 13:33:58 --> Helper loaded: url_helper
INFO - 2025-05-06 13:33:58 --> Helper loaded: string_helper
INFO - 2025-05-06 13:33:58 --> Helper loaded: form_helper
INFO - 2025-05-06 13:33:58 --> Helper loaded: file_helper
INFO - 2025-05-06 13:33:58 --> Helper loaded: html_helper
INFO - 2025-05-06 13:33:58 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:33:58 --> Controller Class Initialized
INFO - 2025-05-06 21:33:58 --> Model "AuctionModel" initialized
INFO - 2025-05-06 21:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 21:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:33:58 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:33:58 --> Final output sent to browser
DEBUG - 2025-05-06 21:33:58 --> Total execution time: 0.1269
INFO - 2025-05-06 13:33:59 --> Config Class Initialized
INFO - 2025-05-06 13:33:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:00 --> URI Class Initialized
INFO - 2025-05-06 13:34:00 --> Router Class Initialized
INFO - 2025-05-06 13:34:00 --> Output Class Initialized
INFO - 2025-05-06 13:34:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:00 --> Input Class Initialized
INFO - 2025-05-06 13:34:00 --> Language Class Initialized
INFO - 2025-05-06 13:34:00 --> Loader Class Initialized
INFO - 2025-05-06 13:34:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:00 --> Controller Class Initialized
INFO - 2025-05-06 13:34:00 --> Config Class Initialized
INFO - 2025-05-06 13:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:00 --> URI Class Initialized
INFO - 2025-05-06 13:34:00 --> Router Class Initialized
INFO - 2025-05-06 13:34:00 --> Output Class Initialized
INFO - 2025-05-06 13:34:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:00 --> Input Class Initialized
INFO - 2025-05-06 13:34:00 --> Language Class Initialized
INFO - 2025-05-06 13:34:00 --> Loader Class Initialized
INFO - 2025-05-06 13:34:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:00 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:00 --> Controller Class Initialized
INFO - 2025-05-06 21:34:00 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:34:27 --> Config Class Initialized
INFO - 2025-05-06 13:34:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:27 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:27 --> URI Class Initialized
DEBUG - 2025-05-06 13:34:27 --> No URI present. Default controller set.
INFO - 2025-05-06 13:34:27 --> Router Class Initialized
INFO - 2025-05-06 13:34:27 --> Output Class Initialized
INFO - 2025-05-06 13:34:27 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:27 --> Input Class Initialized
INFO - 2025-05-06 13:34:27 --> Language Class Initialized
INFO - 2025-05-06 13:34:27 --> Loader Class Initialized
INFO - 2025-05-06 13:34:27 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:27 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:27 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:27 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:27 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:27 --> Controller Class Initialized
INFO - 2025-05-06 13:34:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:34:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:34:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\home/index.php
INFO - 2025-05-06 13:34:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:34:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:34:27 --> Final output sent to browser
DEBUG - 2025-05-06 13:34:27 --> Total execution time: 0.1156
INFO - 2025-05-06 13:34:28 --> Config Class Initialized
INFO - 2025-05-06 13:34:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:28 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:28 --> URI Class Initialized
INFO - 2025-05-06 13:34:28 --> Router Class Initialized
INFO - 2025-05-06 13:34:28 --> Output Class Initialized
INFO - 2025-05-06 13:34:28 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:28 --> Input Class Initialized
INFO - 2025-05-06 13:34:28 --> Language Class Initialized
INFO - 2025-05-06 13:34:28 --> Loader Class Initialized
INFO - 2025-05-06 13:34:28 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:28 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:28 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:28 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:28 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:28 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:28 --> Controller Class Initialized
INFO - 2025-05-06 21:34:28 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:34:32 --> Config Class Initialized
INFO - 2025-05-06 13:34:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:32 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:32 --> URI Class Initialized
INFO - 2025-05-06 13:34:32 --> Router Class Initialized
DEBUG - 2025-05-06 13:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:32 --> Controller Class Initialized
INFO - 2025-05-06 21:34:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:34:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:34:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:34:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:34:32 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:34:32 --> Final output sent to browser
DEBUG - 2025-05-06 21:34:32 --> Total execution time: 0.1039
INFO - 2025-05-06 13:34:36 --> Config Class Initialized
INFO - 2025-05-06 13:34:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:36 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:36 --> URI Class Initialized
INFO - 2025-05-06 13:34:36 --> Router Class Initialized
INFO - 2025-05-06 13:34:36 --> Output Class Initialized
INFO - 2025-05-06 13:34:36 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:36 --> Input Class Initialized
INFO - 2025-05-06 13:34:36 --> Language Class Initialized
INFO - 2025-05-06 13:34:36 --> Loader Class Initialized
INFO - 2025-05-06 13:34:36 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:36 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:36 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:36 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:36 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:36 --> Controller Class Initialized
INFO - 2025-05-06 21:34:36 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:34:44 --> Config Class Initialized
INFO - 2025-05-06 13:34:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:34:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:34:44 --> Utf8 Class Initialized
INFO - 2025-05-06 13:34:44 --> URI Class Initialized
INFO - 2025-05-06 13:34:44 --> Router Class Initialized
INFO - 2025-05-06 13:34:44 --> Output Class Initialized
INFO - 2025-05-06 13:34:44 --> Security Class Initialized
DEBUG - 2025-05-06 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:34:44 --> Input Class Initialized
INFO - 2025-05-06 13:34:44 --> Language Class Initialized
INFO - 2025-05-06 13:34:44 --> Loader Class Initialized
INFO - 2025-05-06 13:34:44 --> Helper loaded: url_helper
INFO - 2025-05-06 13:34:44 --> Helper loaded: string_helper
INFO - 2025-05-06 13:34:44 --> Helper loaded: form_helper
INFO - 2025-05-06 13:34:44 --> Helper loaded: file_helper
INFO - 2025-05-06 13:34:44 --> Helper loaded: html_helper
INFO - 2025-05-06 13:34:44 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:34:44 --> Controller Class Initialized
INFO - 2025-05-06 21:34:44 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:34:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:34:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:34:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:34:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:34:45 --> Final output sent to browser
DEBUG - 2025-05-06 21:34:45 --> Total execution time: 0.1332
INFO - 2025-05-06 13:35:04 --> Config Class Initialized
INFO - 2025-05-06 13:35:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:04 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:04 --> URI Class Initialized
INFO - 2025-05-06 13:35:04 --> Router Class Initialized
INFO - 2025-05-06 13:35:04 --> Output Class Initialized
INFO - 2025-05-06 13:35:04 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:04 --> Input Class Initialized
INFO - 2025-05-06 13:35:04 --> Language Class Initialized
INFO - 2025-05-06 13:35:04 --> Loader Class Initialized
INFO - 2025-05-06 13:35:04 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:04 --> Helper loaded: string_helper
INFO - 2025-05-06 13:35:04 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:04 --> Helper loaded: file_helper
INFO - 2025-05-06 13:35:04 --> Helper loaded: html_helper
INFO - 2025-05-06 13:35:04 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:04 --> Controller Class Initialized
INFO - 2025-05-06 21:35:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:35:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:35:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:35:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:35:04 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:35:04 --> Final output sent to browser
DEBUG - 2025-05-06 21:35:04 --> Total execution time: 0.0713
INFO - 2025-05-06 13:35:06 --> Config Class Initialized
INFO - 2025-05-06 13:35:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:06 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:06 --> URI Class Initialized
INFO - 2025-05-06 13:35:06 --> Router Class Initialized
INFO - 2025-05-06 13:35:06 --> Output Class Initialized
INFO - 2025-05-06 13:35:06 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:06 --> Input Class Initialized
INFO - 2025-05-06 13:35:06 --> Language Class Initialized
INFO - 2025-05-06 13:35:06 --> Loader Class Initialized
INFO - 2025-05-06 13:35:06 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:06 --> Helper loaded: string_helper
INFO - 2025-05-06 13:35:06 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:06 --> Helper loaded: file_helper
INFO - 2025-05-06 13:35:06 --> Helper loaded: html_helper
INFO - 2025-05-06 13:35:06 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:06 --> Controller Class Initialized
INFO - 2025-05-06 21:35:06 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:35:20 --> Config Class Initialized
INFO - 2025-05-06 13:35:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:20 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:20 --> URI Class Initialized
INFO - 2025-05-06 13:35:20 --> Router Class Initialized
INFO - 2025-05-06 13:35:20 --> Output Class Initialized
INFO - 2025-05-06 13:35:20 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:20 --> Input Class Initialized
INFO - 2025-05-06 13:35:20 --> Language Class Initialized
INFO - 2025-05-06 13:35:20 --> Loader Class Initialized
INFO - 2025-05-06 13:35:20 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:20 --> Helper loaded: string_helper
INFO - 2025-05-06 13:35:20 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:20 --> Helper loaded: file_helper
INFO - 2025-05-06 13:35:20 --> Helper loaded: html_helper
INFO - 2025-05-06 13:35:20 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:20 --> Controller Class Initialized
INFO - 2025-05-06 21:35:20 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:36:27 --> Config Class Initialized
INFO - 2025-05-06 13:36:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:27 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:27 --> URI Class Initialized
INFO - 2025-05-06 13:36:27 --> Router Class Initialized
INFO - 2025-05-06 13:36:27 --> Output Class Initialized
INFO - 2025-05-06 13:36:27 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:27 --> Input Class Initialized
INFO - 2025-05-06 13:36:27 --> Language Class Initialized
INFO - 2025-05-06 13:36:27 --> Loader Class Initialized
INFO - 2025-05-06 13:36:27 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:27 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:27 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:27 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:27 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:27 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:27 --> Controller Class Initialized
INFO - 2025-05-06 21:36:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:36:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:36:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:36:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:36:27 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:36:27 --> Final output sent to browser
DEBUG - 2025-05-06 21:36:27 --> Total execution time: 0.1515
INFO - 2025-05-06 13:36:29 --> Config Class Initialized
INFO - 2025-05-06 13:36:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:29 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:29 --> URI Class Initialized
INFO - 2025-05-06 13:36:29 --> Router Class Initialized
INFO - 2025-05-06 13:36:29 --> Output Class Initialized
INFO - 2025-05-06 13:36:29 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:29 --> Input Class Initialized
INFO - 2025-05-06 13:36:29 --> Language Class Initialized
INFO - 2025-05-06 13:36:29 --> Loader Class Initialized
INFO - 2025-05-06 13:36:29 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:29 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:29 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:29 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:29 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:29 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:29 --> Controller Class Initialized
INFO - 2025-05-06 21:36:29 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:36:38 --> Config Class Initialized
INFO - 2025-05-06 13:36:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:38 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:38 --> URI Class Initialized
INFO - 2025-05-06 13:36:38 --> Router Class Initialized
INFO - 2025-05-06 13:36:38 --> Output Class Initialized
INFO - 2025-05-06 13:36:38 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:38 --> Input Class Initialized
INFO - 2025-05-06 13:36:38 --> Language Class Initialized
INFO - 2025-05-06 13:36:38 --> Loader Class Initialized
INFO - 2025-05-06 13:36:38 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:38 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:38 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:38 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:38 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:38 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:38 --> Controller Class Initialized
INFO - 2025-05-06 21:36:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:36:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:36:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:36:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:36:38 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:36:38 --> Final output sent to browser
DEBUG - 2025-05-06 21:36:38 --> Total execution time: 0.1338
INFO - 2025-05-06 13:36:40 --> Config Class Initialized
INFO - 2025-05-06 13:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:40 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:40 --> URI Class Initialized
INFO - 2025-05-06 13:36:40 --> Router Class Initialized
INFO - 2025-05-06 13:36:40 --> Output Class Initialized
INFO - 2025-05-06 13:36:40 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:40 --> Input Class Initialized
INFO - 2025-05-06 13:36:40 --> Language Class Initialized
INFO - 2025-05-06 13:36:40 --> Loader Class Initialized
INFO - 2025-05-06 13:36:40 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:40 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:40 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:40 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:40 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:40 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:40 --> Controller Class Initialized
INFO - 2025-05-06 21:36:40 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:36:50 --> Config Class Initialized
INFO - 2025-05-06 13:36:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:50 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:50 --> URI Class Initialized
INFO - 2025-05-06 13:36:50 --> Router Class Initialized
INFO - 2025-05-06 13:36:50 --> Output Class Initialized
INFO - 2025-05-06 13:36:50 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:50 --> Input Class Initialized
INFO - 2025-05-06 13:36:50 --> Language Class Initialized
INFO - 2025-05-06 13:36:50 --> Loader Class Initialized
INFO - 2025-05-06 13:36:50 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:50 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:50 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:50 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:50 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:50 --> Controller Class Initialized
INFO - 2025-05-06 21:36:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:36:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:36:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:36:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:36:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:36:50 --> Final output sent to browser
DEBUG - 2025-05-06 21:36:50 --> Total execution time: 0.1171
INFO - 2025-05-06 13:36:52 --> Config Class Initialized
INFO - 2025-05-06 13:36:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:52 --> URI Class Initialized
INFO - 2025-05-06 13:36:52 --> Router Class Initialized
INFO - 2025-05-06 13:36:52 --> Output Class Initialized
INFO - 2025-05-06 13:36:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:52 --> Input Class Initialized
INFO - 2025-05-06 13:36:52 --> Language Class Initialized
INFO - 2025-05-06 13:36:52 --> Loader Class Initialized
INFO - 2025-05-06 13:36:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:52 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:52 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:52 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:52 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:52 --> Controller Class Initialized
INFO - 2025-05-06 21:36:52 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:36:59 --> Config Class Initialized
INFO - 2025-05-06 13:36:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:59 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:59 --> URI Class Initialized
INFO - 2025-05-06 13:36:59 --> Router Class Initialized
INFO - 2025-05-06 13:36:59 --> Output Class Initialized
INFO - 2025-05-06 13:36:59 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:59 --> Input Class Initialized
INFO - 2025-05-06 13:36:59 --> Language Class Initialized
INFO - 2025-05-06 13:36:59 --> Loader Class Initialized
INFO - 2025-05-06 13:36:59 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:59 --> Helper loaded: string_helper
INFO - 2025-05-06 13:36:59 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:59 --> Helper loaded: file_helper
INFO - 2025-05-06 13:36:59 --> Helper loaded: html_helper
INFO - 2025-05-06 13:36:59 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:59 --> Controller Class Initialized
INFO - 2025-05-06 21:36:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:36:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:36:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/index.php
INFO - 2025-05-06 21:36:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:36:59 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:36:59 --> Final output sent to browser
DEBUG - 2025-05-06 21:36:59 --> Total execution time: 0.1586
INFO - 2025-05-06 13:37:00 --> Config Class Initialized
INFO - 2025-05-06 13:37:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:00 --> URI Class Initialized
INFO - 2025-05-06 13:37:00 --> Router Class Initialized
INFO - 2025-05-06 13:37:00 --> Output Class Initialized
INFO - 2025-05-06 13:37:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:00 --> Input Class Initialized
INFO - 2025-05-06 13:37:00 --> Language Class Initialized
INFO - 2025-05-06 13:37:00 --> Loader Class Initialized
INFO - 2025-05-06 13:37:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:00 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:00 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:00 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:00 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:00 --> Controller Class Initialized
INFO - 2025-05-06 21:37:00 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:37:24 --> Config Class Initialized
INFO - 2025-05-06 13:37:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:24 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:24 --> URI Class Initialized
INFO - 2025-05-06 13:37:24 --> Router Class Initialized
INFO - 2025-05-06 13:37:24 --> Output Class Initialized
INFO - 2025-05-06 13:37:24 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:24 --> Input Class Initialized
INFO - 2025-05-06 13:37:24 --> Language Class Initialized
INFO - 2025-05-06 13:37:24 --> Loader Class Initialized
INFO - 2025-05-06 13:37:24 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:24 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:24 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:24 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:24 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:24 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:24 --> Controller Class Initialized
INFO - 2025-05-06 21:37:24 --> Model "AuctionModel" initialized
INFO - 2025-05-06 21:37:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:37:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:37:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 21:37:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:37:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:37:24 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:24 --> Total execution time: 0.1172
INFO - 2025-05-06 13:37:25 --> Config Class Initialized
INFO - 2025-05-06 13:37:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:25 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:25 --> URI Class Initialized
INFO - 2025-05-06 13:37:25 --> Router Class Initialized
INFO - 2025-05-06 13:37:25 --> Output Class Initialized
INFO - 2025-05-06 13:37:25 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:25 --> Input Class Initialized
INFO - 2025-05-06 13:37:25 --> Language Class Initialized
INFO - 2025-05-06 13:37:25 --> Loader Class Initialized
INFO - 2025-05-06 13:37:25 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:25 --> Controller Class Initialized
INFO - 2025-05-06 13:37:25 --> Config Class Initialized
INFO - 2025-05-06 13:37:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:25 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:25 --> URI Class Initialized
INFO - 2025-05-06 13:37:25 --> Router Class Initialized
INFO - 2025-05-06 13:37:25 --> Output Class Initialized
INFO - 2025-05-06 13:37:25 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:25 --> Input Class Initialized
INFO - 2025-05-06 13:37:25 --> Language Class Initialized
INFO - 2025-05-06 13:37:25 --> Loader Class Initialized
INFO - 2025-05-06 13:37:25 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:25 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:25 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:25 --> Controller Class Initialized
INFO - 2025-05-06 21:37:25 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:37:36 --> Config Class Initialized
INFO - 2025-05-06 13:37:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:36 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:36 --> URI Class Initialized
INFO - 2025-05-06 13:37:36 --> Router Class Initialized
INFO - 2025-05-06 13:37:36 --> Output Class Initialized
INFO - 2025-05-06 13:37:36 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:36 --> Input Class Initialized
INFO - 2025-05-06 13:37:36 --> Language Class Initialized
INFO - 2025-05-06 13:37:36 --> Loader Class Initialized
INFO - 2025-05-06 13:37:36 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:36 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:36 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:36 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:36 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:36 --> Controller Class Initialized
INFO - 2025-05-06 21:37:36 --> Model "AuctionModel" initialized
INFO - 2025-05-06 21:37:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:37:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:37:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auctions/details.php
INFO - 2025-05-06 21:37:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:37:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:37:36 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:36 --> Total execution time: 0.1174
INFO - 2025-05-06 13:37:37 --> Config Class Initialized
INFO - 2025-05-06 13:37:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:37 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:37 --> URI Class Initialized
INFO - 2025-05-06 13:37:37 --> Router Class Initialized
INFO - 2025-05-06 13:37:37 --> Output Class Initialized
INFO - 2025-05-06 13:37:37 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:37 --> Input Class Initialized
INFO - 2025-05-06 13:37:37 --> Language Class Initialized
INFO - 2025-05-06 13:37:37 --> Loader Class Initialized
INFO - 2025-05-06 13:37:37 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:37 --> Controller Class Initialized
INFO - 2025-05-06 13:37:37 --> Config Class Initialized
INFO - 2025-05-06 13:37:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:37 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:37 --> URI Class Initialized
INFO - 2025-05-06 13:37:37 --> Router Class Initialized
INFO - 2025-05-06 13:37:37 --> Output Class Initialized
INFO - 2025-05-06 13:37:37 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:37 --> Input Class Initialized
INFO - 2025-05-06 13:37:37 --> Language Class Initialized
INFO - 2025-05-06 13:37:37 --> Loader Class Initialized
INFO - 2025-05-06 13:37:37 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:37 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:37 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:37 --> Controller Class Initialized
INFO - 2025-05-06 21:37:37 --> Model "AuctionModel" initialized
INFO - 2025-05-06 13:37:41 --> Config Class Initialized
INFO - 2025-05-06 13:37:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:41 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:41 --> URI Class Initialized
INFO - 2025-05-06 13:37:41 --> Router Class Initialized
INFO - 2025-05-06 13:37:41 --> Output Class Initialized
INFO - 2025-05-06 13:37:41 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:41 --> Input Class Initialized
INFO - 2025-05-06 13:37:41 --> Language Class Initialized
INFO - 2025-05-06 13:37:41 --> Loader Class Initialized
INFO - 2025-05-06 13:37:41 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:41 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:41 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:41 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:41 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:41 --> Controller Class Initialized
INFO - 2025-05-06 13:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/account.php
INFO - 2025-05-06 13:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:37:41 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:37:41 --> Final output sent to browser
DEBUG - 2025-05-06 13:37:41 --> Total execution time: 0.2243
INFO - 2025-05-06 13:37:42 --> Config Class Initialized
INFO - 2025-05-06 13:37:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:42 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:42 --> URI Class Initialized
INFO - 2025-05-06 13:37:42 --> Router Class Initialized
INFO - 2025-05-06 13:37:42 --> Output Class Initialized
INFO - 2025-05-06 13:37:42 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:42 --> Input Class Initialized
INFO - 2025-05-06 13:37:42 --> Language Class Initialized
INFO - 2025-05-06 13:37:42 --> Loader Class Initialized
INFO - 2025-05-06 13:37:42 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:42 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:42 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:42 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:42 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:42 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:42 --> Controller Class Initialized
INFO - 2025-05-06 21:37:42 --> Model "UserModel" initialized
INFO - 2025-05-06 21:37:42 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:42 --> Total execution time: 0.1551
INFO - 2025-05-06 13:37:45 --> Config Class Initialized
INFO - 2025-05-06 13:37:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:45 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:45 --> URI Class Initialized
INFO - 2025-05-06 13:37:45 --> Router Class Initialized
INFO - 2025-05-06 13:37:45 --> Output Class Initialized
INFO - 2025-05-06 13:37:45 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:45 --> Input Class Initialized
INFO - 2025-05-06 13:37:45 --> Language Class Initialized
INFO - 2025-05-06 13:37:45 --> Loader Class Initialized
INFO - 2025-05-06 13:37:45 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:45 --> Controller Class Initialized
INFO - 2025-05-06 21:37:45 --> Model "CompanyModel" initialized
INFO - 2025-05-06 13:37:45 --> Config Class Initialized
INFO - 2025-05-06 13:37:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:45 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:45 --> URI Class Initialized
INFO - 2025-05-06 13:37:45 --> Router Class Initialized
INFO - 2025-05-06 13:37:45 --> Output Class Initialized
INFO - 2025-05-06 13:37:45 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:45 --> Input Class Initialized
INFO - 2025-05-06 13:37:45 --> Language Class Initialized
INFO - 2025-05-06 13:37:45 --> Loader Class Initialized
INFO - 2025-05-06 13:37:45 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:45 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:45 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:45 --> Controller Class Initialized
INFO - 2025-05-06 21:37:45 --> Model "CompanyModel" initialized
INFO - 2025-05-06 21:37:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 21:37:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 21:37:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/company/details.php
INFO - 2025-05-06 21:37:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 21:37:45 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 21:37:45 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:45 --> Total execution time: 0.1321
INFO - 2025-05-06 13:37:46 --> Config Class Initialized
INFO - 2025-05-06 13:37:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:46 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:46 --> URI Class Initialized
INFO - 2025-05-06 13:37:46 --> Router Class Initialized
INFO - 2025-05-06 13:37:46 --> Output Class Initialized
INFO - 2025-05-06 13:37:46 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:46 --> Input Class Initialized
INFO - 2025-05-06 13:37:46 --> Language Class Initialized
INFO - 2025-05-06 13:37:46 --> Loader Class Initialized
INFO - 2025-05-06 13:37:46 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:46 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:46 --> Controller Class Initialized
INFO - 2025-05-06 13:37:46 --> Config Class Initialized
INFO - 2025-05-06 13:37:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:46 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:46 --> URI Class Initialized
INFO - 2025-05-06 13:37:46 --> Router Class Initialized
INFO - 2025-05-06 13:37:46 --> Output Class Initialized
INFO - 2025-05-06 13:37:46 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:46 --> Input Class Initialized
INFO - 2025-05-06 13:37:46 --> Language Class Initialized
INFO - 2025-05-06 13:37:46 --> Loader Class Initialized
INFO - 2025-05-06 13:37:46 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:46 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:46 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:46 --> Controller Class Initialized
INFO - 2025-05-06 21:37:46 --> Model "CompanyModel" initialized
INFO - 2025-05-06 21:37:46 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:46 --> Total execution time: 0.1221
INFO - 2025-05-06 13:37:48 --> Config Class Initialized
INFO - 2025-05-06 13:37:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:48 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:48 --> URI Class Initialized
INFO - 2025-05-06 13:37:48 --> Router Class Initialized
INFO - 2025-05-06 13:37:48 --> Output Class Initialized
INFO - 2025-05-06 13:37:48 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:48 --> Input Class Initialized
INFO - 2025-05-06 13:37:48 --> Language Class Initialized
INFO - 2025-05-06 13:37:48 --> Loader Class Initialized
INFO - 2025-05-06 13:37:48 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:48 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:48 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:48 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:48 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:48 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:48 --> Controller Class Initialized
INFO - 2025-05-06 13:37:48 --> Model "CompanyModel" initialized
INFO - 2025-05-06 13:37:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:37:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:37:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/storage_facility_location/manage.php
INFO - 2025-05-06 13:37:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:37:48 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:37:48 --> Final output sent to browser
DEBUG - 2025-05-06 13:37:48 --> Total execution time: 0.1774
INFO - 2025-05-06 13:37:49 --> Config Class Initialized
INFO - 2025-05-06 13:37:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:49 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:49 --> URI Class Initialized
INFO - 2025-05-06 13:37:49 --> Router Class Initialized
INFO - 2025-05-06 13:37:49 --> Output Class Initialized
INFO - 2025-05-06 13:37:49 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:49 --> Input Class Initialized
INFO - 2025-05-06 13:37:49 --> Language Class Initialized
INFO - 2025-05-06 13:37:49 --> Loader Class Initialized
INFO - 2025-05-06 13:37:49 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:49 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:49 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:49 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:49 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:49 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:49 --> Controller Class Initialized
INFO - 2025-05-06 13:37:49 --> Model "StorageFacilityModel" initialized
INFO - 2025-05-06 13:37:49 --> Final output sent to browser
DEBUG - 2025-05-06 13:37:49 --> Total execution time: 0.2966
INFO - 2025-05-06 13:37:50 --> Config Class Initialized
INFO - 2025-05-06 13:37:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:50 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:50 --> URI Class Initialized
INFO - 2025-05-06 13:37:50 --> Router Class Initialized
INFO - 2025-05-06 13:37:50 --> Output Class Initialized
INFO - 2025-05-06 13:37:50 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:50 --> Input Class Initialized
INFO - 2025-05-06 13:37:50 --> Language Class Initialized
INFO - 2025-05-06 13:37:50 --> Loader Class Initialized
INFO - 2025-05-06 13:37:50 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:50 --> Controller Class Initialized
INFO - 2025-05-06 13:37:50 --> Model "CompanyModel" initialized
INFO - 2025-05-06 13:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-06 13:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:37:50 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:37:50 --> Final output sent to browser
DEBUG - 2025-05-06 13:37:50 --> Total execution time: 0.1010
INFO - 2025-05-06 13:37:50 --> Config Class Initialized
INFO - 2025-05-06 13:37:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:37:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:37:50 --> Utf8 Class Initialized
INFO - 2025-05-06 13:37:50 --> URI Class Initialized
INFO - 2025-05-06 13:37:50 --> Router Class Initialized
INFO - 2025-05-06 13:37:50 --> Output Class Initialized
INFO - 2025-05-06 13:37:50 --> Security Class Initialized
DEBUG - 2025-05-06 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:37:50 --> Input Class Initialized
INFO - 2025-05-06 13:37:50 --> Language Class Initialized
INFO - 2025-05-06 13:37:50 --> Loader Class Initialized
INFO - 2025-05-06 13:37:50 --> Helper loaded: url_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: string_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: form_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: file_helper
INFO - 2025-05-06 13:37:50 --> Helper loaded: html_helper
INFO - 2025-05-06 13:37:50 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:37:50 --> Controller Class Initialized
INFO - 2025-05-06 21:37:50 --> Model "CompanyModel" initialized
INFO - 2025-05-06 21:37:50 --> Model "StaffModel" initialized
INFO - 2025-05-06 21:37:50 --> Final output sent to browser
DEBUG - 2025-05-06 21:37:50 --> Total execution time: 0.2449
INFO - 2025-05-06 13:42:36 --> Config Class Initialized
INFO - 2025-05-06 13:42:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:42:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:42:36 --> Utf8 Class Initialized
INFO - 2025-05-06 13:42:36 --> URI Class Initialized
INFO - 2025-05-06 13:42:36 --> Router Class Initialized
INFO - 2025-05-06 13:42:36 --> Output Class Initialized
INFO - 2025-05-06 13:42:36 --> Security Class Initialized
DEBUG - 2025-05-06 13:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:42:36 --> Input Class Initialized
INFO - 2025-05-06 13:42:36 --> Language Class Initialized
INFO - 2025-05-06 13:42:36 --> Loader Class Initialized
INFO - 2025-05-06 13:42:36 --> Helper loaded: url_helper
INFO - 2025-05-06 13:42:36 --> Helper loaded: string_helper
INFO - 2025-05-06 13:42:36 --> Helper loaded: form_helper
INFO - 2025-05-06 13:42:36 --> Helper loaded: file_helper
INFO - 2025-05-06 13:42:36 --> Helper loaded: html_helper
INFO - 2025-05-06 13:42:36 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:42:36 --> Controller Class Initialized
INFO - 2025-05-06 13:42:36 --> Model "CompanyModel" initialized
INFO - 2025-05-06 13:42:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-06 13:42:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-06 13:42:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\dashboard/storage_facility/staff/manage.php
INFO - 2025-05-06 13:42:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-06 13:42:36 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-06 13:42:36 --> Final output sent to browser
DEBUG - 2025-05-06 13:42:36 --> Total execution time: 0.1810
INFO - 2025-05-06 13:42:38 --> Config Class Initialized
INFO - 2025-05-06 13:42:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:42:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:42:38 --> Utf8 Class Initialized
INFO - 2025-05-06 13:42:38 --> URI Class Initialized
INFO - 2025-05-06 13:42:38 --> Router Class Initialized
INFO - 2025-05-06 13:42:38 --> Output Class Initialized
INFO - 2025-05-06 13:42:38 --> Security Class Initialized
DEBUG - 2025-05-06 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:42:38 --> Input Class Initialized
INFO - 2025-05-06 13:42:38 --> Language Class Initialized
INFO - 2025-05-06 13:42:38 --> Loader Class Initialized
INFO - 2025-05-06 13:42:38 --> Helper loaded: url_helper
INFO - 2025-05-06 13:42:38 --> Helper loaded: string_helper
INFO - 2025-05-06 13:42:38 --> Helper loaded: form_helper
INFO - 2025-05-06 13:42:38 --> Helper loaded: file_helper
INFO - 2025-05-06 13:42:38 --> Helper loaded: html_helper
INFO - 2025-05-06 13:42:38 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:42:38 --> Controller Class Initialized
INFO - 2025-05-06 21:42:38 --> Model "CompanyModel" initialized
INFO - 2025-05-06 21:42:38 --> Model "StaffModel" initialized
INFO - 2025-05-06 21:42:38 --> Final output sent to browser
DEBUG - 2025-05-06 21:42:38 --> Total execution time: 0.1401
INFO - 2025-05-06 13:42:41 --> Config Class Initialized
INFO - 2025-05-06 13:42:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:42:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:42:41 --> Utf8 Class Initialized
INFO - 2025-05-06 13:42:41 --> URI Class Initialized
INFO - 2025-05-06 13:42:41 --> Router Class Initialized
INFO - 2025-05-06 13:42:41 --> Output Class Initialized
INFO - 2025-05-06 13:42:41 --> Security Class Initialized
DEBUG - 2025-05-06 13:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:42:41 --> Input Class Initialized
INFO - 2025-05-06 13:42:41 --> Language Class Initialized
INFO - 2025-05-06 13:42:41 --> Loader Class Initialized
INFO - 2025-05-06 13:42:41 --> Helper loaded: url_helper
INFO - 2025-05-06 13:42:41 --> Helper loaded: string_helper
INFO - 2025-05-06 13:42:41 --> Helper loaded: form_helper
INFO - 2025-05-06 13:42:41 --> Helper loaded: file_helper
INFO - 2025-05-06 13:42:41 --> Helper loaded: html_helper
INFO - 2025-05-06 13:42:41 --> Database Driver Class Initialized
DEBUG - 2025-05-06 13:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-06 13:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:42:41 --> Controller Class Initialized
INFO - 2025-05-06 21:42:41 --> Model "CompanyModel" initialized
INFO - 2025-05-06 21:42:41 --> Model "UserModel" initialized
DEBUG - 2025-05-06 21:42:41 --> PHPMailer class is loaded.
INFO - 2025-05-06 21:42:42 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\email_templates/staff_invitation_email.php
INFO - 2025-05-06 21:42:48 --> Final output sent to browser
DEBUG - 2025-05-06 21:42:48 --> Total execution time: 7.7308
