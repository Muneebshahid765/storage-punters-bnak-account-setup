<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-02 05:51:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-02 05:51:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-02 05:51:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-02 05:51:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-02 05:51:24 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-02 05:51:24 --> Final output sent to browser
DEBUG - 2025-05-02 05:51:24 --> Total execution time: 0.1645
INFO - 2025-05-02 05:51:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-02 05:51:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-02 05:51:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-02 05:51:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-02 05:51:31 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-02 05:51:31 --> Final output sent to browser
DEBUG - 2025-05-02 05:51:31 --> Total execution time: 0.1704
INFO - 2025-05-02 05:51:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/head.php
INFO - 2025-05-02 05:51:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/header.php
INFO - 2025-05-02 05:51:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\auth/register_bidder.php
INFO - 2025-05-02 05:51:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/footer.php
INFO - 2025-05-02 05:51:34 --> File loaded: C:\xampp\htdocs\storage_auctions\application\views\layout/scripts.php
INFO - 2025-05-02 05:51:34 --> Final output sent to browser
DEBUG - 2025-05-02 05:51:34 --> Total execution time: 0.2450
