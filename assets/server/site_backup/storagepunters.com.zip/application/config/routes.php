<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


$route['login'] = 'Auth/signIn';
$route['api/user/checkUserLogin'] = 'Auth/checkUserLogin';
$route['auth/login'] = 'Auth/process_login';
$route['auth/logout'] = 'Auth/process_logout';

$route['register/standard-bidder'] = 'Auth/registerBidder';
$route['register/standard-seller'] = 'Auth/registerStorageFacility';

// Auctions Controller //
$route['auctions'] = 'Auctions/index';
$route['auctions/(:any)'] = 'Auctions/actionDetails/$1';
$route['api/auctions/getTopThreeAuctions'] = 'Auctions/getTopThreeAuctions';
$route['api/auctions/getAllAuctions'] = 'Auctions/getAllAuctions';
$route['api/auctions/getAuctionById'] = 'Auctions/getAuctionById';
$route['api/auctions/add_bid_to_auction'] = 'Auctions/addBidToAuction';
$route['api/auctions/add_auction_to_watchlist'] = 'Auctions/addAuctionToWatchlist';
$route['api/auction/fetch_current_active_auctions_by_user'] = 'Auctions/getCurrentActiveAuctionsByBidderUser';
$route['api/auction/fetch_all_auctions_by_user'] = 'Auctions/getAllAuctionsByBidderUser';
$route['api/auction/fetch_watched_auctions_by_user'] = 'Auctions/getWatchedAuctionsByBidderUser';
$route['api/auction/fetch_won_auctions_by_user'] = 'Auctions/getWonAuctionsByBidderUser';
$route['api/invoice/fetch_invoices_auctions_by_user'] = 'Invoices/getInvoicesAuctionsByBidderUser';
$route['api/auction/fetch_won_auctions_by_storage_facility'] = 'Auctions/getWonAuctionsByStorageFacilityUser';

// Pages Controller //
$route['about-us'] = 'Pages/aboutUs';
$route['contact-us'] = 'Pages/contactUs';
$route['faqs'] = 'Pages/faqs';
$route['terms-and-conditions'] = 'Pages/termsAndConditions';


// BidderDashboard Controller //
$route['show-dashboard/dashboard'] = 'BidderDashboard/bidderDashboard';
$route['show-dashboard/edit-account'] = 'BidderDashboard/bidderAccount';
$route['show-dashboard/payment-method'] = 'BidderDashboard/bidderPaymentMethod';
$route['show-dashboard/notifications'] = 'BidderDashboard/bidderNotification';


// Users Controller //
$route['api/users/standard-bidder/registration'] = 'Users/registerNewBidder';
$route['api/users/standard-seller/registration'] = 'Users/registerNewStoragePunter';

$route['api/users/bidder/profile/get'] = 'Users/getBidderProfileById';
$route['api/users/bidder/profile/update'] = 'Users/updateBidderProfileById';

$route['api/users/storage-facility/profile/get'] = 'Users/getStorageFacilityProfileById';
$route['api/users/storage-facility/profile/update'] = 'Users/updateStorageFacilityProfileById';

$route['api/users/bidder/payment-method/add'] = 'Users/addBidderPaymentMethodById';
$route['api/users/bidder/payment-method/update'] = 'Users/updateBidderPaymentMethodById';
$route['api/users/bidder/payment-method/update-status'] = 'StripeController/attachDetachBidderPaymentMethodCardStatusFromStripeById';
$route['api/users/bidder/payment-method/update-card-status'] = 'StripeController/updateBidderPaymentMethodCardStatusFromStripeById';
$route['api/users/bidder/payment-method/get'] = 'StripeController/getBidderPaymentMethodFromStripeById';
$route['api/users/invitation/accept'] = 'Users/acceptInvitationByStaff';
$route['api/users/invitation/cancel'] = 'Users/cancelInvitationByStaff';

$route['api/users/bidder/notifications/get'] = 'Notifications/getBidderNotificationById';
$route['api/users/bidder/notifications/update'] = 'Notifications/updateBidderNotificationStatusById';


// StorageFacilityDashboard Controller //
$route['storage-facility/dashboard'] = 'StorageFacilityDashboard/storageFacilityDashboard';
$route['storage-facility/edit-account'] = 'StorageFacilityDashboard/storageFacilityAccount';
$route['storage-facility/manage'] = 'StorageFacilityDashboard/storageFacilityManage';
$route['storage-facility/add'] = 'StorageFacilityDashboard/storageFacilityAdd';
$route['storage-facility/edit/(:any)'] = 'StorageFacilityDashboard/storageFacilityDetailsEditByStorageFacilityUser/$1';
$route['storage-facility/staff/manage'] = 'StorageFacilityDashboard/storageFacilityStaffManage';


// Auction APIs
$route['api/auction/statuses'] = 'Auctions/getAllStatuses';
$route['api/auction/types'] = 'Auctions/getAllTypes';
$route['api/auction/categories'] = 'Auctions/getAllCategories';
// Storage Facility APIs
$route['api/user/fetch_storage_facilities_by_user'] = 'StorageFacility/getAllFacilitiesByUser';



// Companies Controller //
$route['api/companies/storage-facility/add'] = 'Companies/addCompanyByStorageFacilityUser';
$route['api/companies/storage-facility/update'] = 'Companies/updateCompanyByStorageFacilityUser';
$route['api/companies/storage-facility/get_by_company_id'] = 'Companies/getCompanyInformationById';
$route['api/user/fetch_companies_by_user'] = 'Companies/getAllCompaniesByUser';

// Storage Controller //
$route['api/storage/storage-facility/add'] = 'StorageFacility/addStorageFacilityByStorageFacilityUser';
$route['api/storage/storage-facility/update'] = 'StorageFacility/updateStorageFacilityByStorageFacilityUser';
$route['api/storage/storage-facility/update-status'] = 'StorageFacility/updateStorageFacilityStatusByIdByStorageFacilityUser';
$route['api/storage/storage-facility/get'] = 'StorageFacility/getAllStorageFacility';
$route['api/storage/storage-facility/get_by_storage_id'] = 'StorageFacility/getAllStorageFacilityById';

// Staff Controller //
$route['api/staff/storage-facility/add'] = 'Staff/addStaffMemberByStorageFacilityUser';
$route['api/staff/storage-facility/update'] = 'Staff/updateStaffMemberByStorageFacilityUser';
$route['api/staff/storage-facility/update-status'] = 'Staff/updateStaffMemberStatusByIdByStorageFacilityUser';
$route['api/staff/storage-facility/get'] = 'Staff/getAllStaffMember';
$route['api/staff/storage-facility/get_by_staff_id'] = 'Staff/getStaffMemberById';

// Auctions Controller //
$route['api/auction/confirm_auction'] = 'Auctions/addAuctionToConfirm';
$route['api/auction/fetch_all_auctions_by_storage_facility'] = 'Auctions/getAllAuctionsByStorageFacilityUser';
$route['api/auction/storage-facility/add'] = 'Auctions/addAuctionByStorageFacilityUser';
$route['api/auction/storage-facility/update'] = 'Auctions/updateAuctionByAuctionIdForStorageFacilityUser';
$route['api/auction/storage-facility/update-status'] = 'Auctions/updateAuctionStatusByAuctionIdForStorageFacilityUser';
$route['api/auction/storage-facility/get'] = 'Auctions/getAuctionsStatusByStorageFacilityUser';
$route['auctions/edit/(:any)'] = 'Auctions/auctionDetailsEditByStorageFacilityUser/$1';
$route['auctions/create/new'] = 'Auctions/auctionDetailsAddByStorageFacilityUser';
$route['api/auction/remove_views'] = 'Auctions/auctionRemoveViewDataByBidderUser';



// Company Controller //
$route['company/edit/(:any)'] = 'Companies/companyDetailsViewByStorageFacilityUser/$1';
$route['company/setup/new'] = 'Companies/companyDetailsSetupAddByStorageFacilityUser';
$route['company'] = 'Companies';
$route['companies/get_by_company_id'] = 'Companies/getCompanyDetailsById';

// Bank Controller //
$route['bank/edit/(:any)'] = 'Bank/bankDetailsViewByStorageFacilityUser/$1';
$route['bank/setup/new'] = 'Bank/bankDetailsSetupAddByStorageFacilityUser';
$route['bank'] = 'Bank';



$route['api/email/test'] = 'Email/test_email';


$route['api/stripe/test'] = 'StripeController/test_stripe';

$route['api/stripe/customer/search_by_email'] = 'StripeController/searchStripeCustomer';
$route['api/stripe/customer/add'] = 'StripeController/addStripeCustomer';
$route['api/stripe/setup-intent'] = 'StripeController/createStripeSetupIntent';
$route['api/stripe/invoice/payment'] = 'StripeController/invoicePaymentBidderFromStripeById';

$route['api/stripe/payment-method/attach'] = 'StripeController/attachStripePaymentMethod';
$route['api/stripe/customer/payment-method/update'] = 'StripeController/addStripePaymentMethod';

$route['api/stripe/bank-account/attach'] = 'StripeController/addBankByStorageFacilityUserFromStripeById';

$route['webhook/stripe/invoice/payment-status'] = 'webhook/stripeInvoicePaymentStatus';

$route['api/logs/invoice/payment-history'] = 'Logs/invoicePaymentHistoryBidderFromStripeById';
$route['api/logs/auction/confirm-logs'] = 'Logs/auctionConfirmWinnerLogsById';


$route['cron/send-auction-to-queue'] = 'Queue/sendAuctionToQueue';

$route['email/process-auction-win'] = 'Email/process_auction_win_email';
$route['email/process-auction-outbid'] = 'Email/process_auction_outbid_email';
$route['email/process-auction-outbid-by-id/(:num)'] = 'Email/process_auction_outbid_email_by_id/$1';
$route['email/process-queue-1h'] = 'Email/process_queue_reminder_1hr';
$route['email/process-queue-3h'] = 'Email/process_queue_reminder_3hr';
$route['email/process-auction-invoice'] = 'Email/process_auction_invoice_email';
$route['email/process-forgot-password'] = 'Email/forgot_password_email';
$route['email/process-password-reset-success'] = 'Email/user_account_password_reset_success_email';
$route['email/process-staff-invitation'] = 'Email/staff_invitation_email';
$route['email/process-resend-staff-invitation'] = 'Email/resend_staff_invitation_email';

$route['test/process-auction-expiration-auto'] = 'Auctions/testAuctionToBackgroundSchedule';

$route['api/users/send-welcome-email'] = 'Email/register_email';
$route['api/users/send-otp'] = 'Email/send_otp';
$route['api/users/verify-otp'] = 'Email/verify_otp';


$route['activate-account'] = 'Users/activate_account';
$route['forgot-password-account'] = 'Users/forgot_password_account';
$route['accept-invitation'] = 'Users/staff_invitation_account';

$route['api/users/account/process-reset-password'] = 'Users/reset_user_account_password';


$route['registration-success'] = 'Users/registrationSuccessPage';
$route['api/uploads/bulk-upload-images'] = 'Uploads/bulkUploadImages';
$route['media/uploads/auctions/(:any)'] = 'Uploads/getUploadImage/$1';
