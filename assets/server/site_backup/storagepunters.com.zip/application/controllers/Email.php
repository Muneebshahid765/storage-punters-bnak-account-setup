<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require APPPATH . 'third_party/phpmailer/src/Exception.php';
require APPPATH . 'third_party/phpmailer/src/PHPMailer.php';
require APPPATH . 'third_party/phpmailer/src/SMTP.php';

class Email extends CI_Controller
{
    protected $smtpData;

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Australia/Brisbane');


        $this->smtpData = [
            'smtpHost'       => 'ventraip.email',
            'smtpUsername'   => 'bid@storagepunters.com',
            'smtpPassword'   => 'MCTc2023!',
            'smtpPort'       => 465,
            'smtpFromEmail'  => 'bid@storagepunters.com',
            'smtpFromName'   => 'Storage Punters',
        ];
    }

    // ✅ Reusable required fields validator
    private function validate_required_fields($data, $required_fields)
    {
        foreach ($required_fields as $field) {
            if (empty($data->$field)) {
                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['error' => "$field is required"]))
                    ->set_status_header(400);
                return false;
            }
        }
        return true;
    }


    public function process_queue_reminder_3hr()
    {
        $this->load->model('EmailQueueModel');

        $nowTime = date('Y-m-d H:i:s');

        $emails = $this->EmailQueueModel->get_reminder_3hr_pending_due($nowTime, 100);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {


                $this->send(
                    $email->to_email,
                    $email->subject,
                    $email->template,
                    [
                        'name'         => $email->name,
                        'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        'auction_url'  => $email->auction_url
                    ],
                    false,
                    ""
                );

                $this->EmailQueueModel->mark_sent($email->id, $nowTime);
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }

    public function process_queue_reminder_1hr()
    {
        $this->load->model('EmailQueueModel');

        $nowTime = date('Y-m-d H:i:s');

        $emails = $this->EmailQueueModel->get_reminder_1hr_pending_due($nowTime, 100);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {


                $this->send(
                    $email->to_email,
                    $email->subject,
                    $email->template,
                    [
                        'name'         => $email->name,
                        'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        'auction_url'  => $email->auction_url
                    ],
                    false,
                    ""
                );

                $this->EmailQueueModel->mark_sent($email->id, $nowTime);
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }

    // ✅ Email sender using PHPMailer and view
    private function send($toEmail, $subject, $bodyView, $viewData = [], $attachment = false, $invoiceContent = null)
    {
        // Load PHPMailer library
        $this->load->library('phpmailer_lib');

        // PHPMailer object
        $mail = $this->phpmailer_lib->load();

        try {
            $mail->isSMTP();
            $mail->Host       = $this->smtpData['smtpHost'];
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->smtpData['smtpUsername'];
            $mail->Password   = $this->smtpData['smtpPassword'];
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = $this->smtpData['smtpPort'];

            $mail->setFrom($this->smtpData['smtpFromEmail'], $this->smtpData['smtpFromName']);
            $mail->addAddress($toEmail);

            $mail->isHTML(true);
            $mail->Subject = $subject;

            $mail->Body = $this->load->view("email_templates/{$bodyView}", $viewData, true);

            if ($attachment == true) {
                $mail->addStringAttachment($invoiceContent, 'invoice.pdf');
            }


            /*if ($mail->send()) {
                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => true]))
                    ->set_status_header(200);
            } else {
                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => false, 'error' => 'Failed to send email']))
                    ->set_status_header(500);
            }*/

            if ($mail->send()) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => 'Failed to send email.'];
            }
        } catch (Exception $e) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'error' => $mail->ErrorInfo]))
                ->set_status_header(500);
        }
    }

    private function generate_invoice_pdf($bodyView, $viewData = [])
    {
        $this->load->library('Pdf');

        // Create TCPDF instance
        $tcpdf = new Pdf(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Document info
        $tcpdf->SetCreator(PDF_CREATOR);
        $tcpdf->SetAuthor('Storage Punters');
        $tcpdf->SetTitle('Storage Punters Invoice');
        $tcpdf->SetSubject('Auction Invoice');
        $tcpdf->SetKeywords('Invoice, Auction, Storage, PDF');

        $tcpdf->SetFont('helvetica', '', 10);
        $tcpdf->AddPage();

        // Load and render view as HTML
        $html = $this->load->view("email_templates/{$bodyView}", $viewData, true);
        $tcpdf->writeHTML($html, true, false, true, false, '');

        // Return PDF as string (no saving to disk)
        return $tcpdf->Output('', 'S'); // 'S' = return as string
    }


    public function test_email()
    {
        $test = 8;
        $toEmail = "specialemailid2050@gmail.com";
        $toName = "Ali";

        if ($test == 1) {
            // Welcome to Storage Punters!
            $this->send(
                $toEmail,
                'Welcome to Storage Punters!',
                'register_welcome_email_for_bidder',
                ['name' => $toName],
                false,
                ""
            );
        } else if ($test == 2) {
            $this->send(
                $toEmail,
                'Reset Your Password',
                'forgot_password_email',
                [
                    'name' => $toName,
                    'reset_link' => "http://localhost/storage_auctions/auth/verify_email/{token}"
                ],
                false,
                ""
            );
        } else if ($test == 3) {
            $this->send(
                $toEmail,
                'Verify Your Email Address',
                'email_verification',
                [
                    'name' => $toName,
                    'verify_link' => "http://localhost/storage_auctions/auth/reset_password/{token}"
                ],
                false,
                ""
            );
        } else if ($test == 4) {
            $this->send(
                $toEmail,
                'Your Bid Has Been Placed Successfully!',
                'auction_bid_email',
                [
                    'name'         => $toName,
                    'auction_item' => "Forest Glen Self Storage Auction #13 - San Jose2, California",
                    'auction_url'  => base_url('auctions/' . 13)
                ],
                false,
                ""
            );
        } else if ($test == 5) {
            $this->send(
                $toEmail,
                'Reminder: Auction Ending Soon!',
                'auction_reminder_3hr_email',
                [
                    'name'         => $toName,
                    'auction_item' => "Forest Glen Self Storage Auction #13 - San Jose2, California",
                    'auction_url'  => base_url('auctions/' . 13)
                ],
                false,
                ""
            );
        } else if ($test == 6) {
            $this->send(
                $toEmail,
                'You have Been Outbid!',
                'auction_outbid_email',
                [
                    'name'         => $toName,
                    'auction_item' => "Forest Glen Self Storage Auction #13 - San Jose2, California",
                    'auction_url'  => base_url('auctions/' . 13)
                ],
                false,
                ""
            );
        } else if ($test == 7) {
            $this->send(
                $toEmail,
                'Congratulations, You Won the Auction!',
                'auction_winner_email',
                [
                    'name'         => $toName,
                    'auction_item' => "Forest Glen Self Storage Auction #13 - San Jose2, California",
                    'auction_url'  => base_url('auctions/' . 13)
                ],
                false,
                ""
            );
        } else if ($test == 8) {

            $viewData = [
                'name'         => $toName,
                'auction_item' => 'Forest Glen Self Storage Auction #13 - San Jose2, California'
            ];

            // 🔽 Get PDF as string
            $invoicePdf = $this->generate_invoice_pdf('pdf_invoice_template', $viewData);

            $this->send(
                $toEmail,
                'Your Invoice from Storage Punters',
                'invoice_email',
                [
                    'name'         => $toName,
                    'auction_item' => "Forest Glen Self Storage Auction #13 - San Jose2, California"
                ],
                true,
                $invoicePdf
            );
        }
    }

    // Register email
    public function register_email()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if (!$existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "No user found with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        // ✅ If user exists, extract user_id
        $userId = $existingUser['user_id'] ?? null;

        if (!$userId) {
            echo json_encode([
                "status" => "error",
                "message" => "User record is missing an ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(500);
            exit;
        }

        // Generate activation token and expiry
        $token = bin2hex(random_bytes(32)); // 64-char secure token
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 day')); // 24-hour expiry

        // Store token & expiry in DB (you must have a table like `user_verifications`)
        $this->UserModel->insertActivationTokenData([
            'email' => $email,
            'token' => $token,
            'expires_at' => $expiresAt,
            'token_activation_type_id' => 1,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Create the activation link
        $activationUrl = base_url("activate-account?token={$token}");

        $response =  $this->send(
            $email,
            'Welcome to Storage Punters!',
            'register_welcome_email',
            ['name' => $data['toName'], 'activation_link' => $activationUrl],
            false,
            ""
        );

        if (!isset($response['success'])) {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send your welcome email. Please check your email address or try again shortly.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }

        if ($response['success']) {

            $response = [
                'success' => true,
                'status' => 'success',
                'message' => 'Welcome email sent successfully. Please check your inbox for next steps.'
            ];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        } else {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send your welcome email. Please check your email address or try again shortly.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }
    }


    public function forgot_password_email()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if (!$existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "No user found with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        // ✅ If user exists, extract user_id
        $userId = $existingUser['user_id'] ?? null;

        if (!$userId) {
            echo json_encode([
                "status" => "error",
                "message" => "User record is missing an ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(500);
            exit;
        }


        $userData = $this->UserModel->get_user_by_id($userId);

        if (!$userData) {
            echo json_encode([
                "status" => "error",
                "message" => "No user data with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        $name = $userData['first_name'] . " " . $userData['last_name'];

        // Generate activation token and expiry
        $token = bin2hex(random_bytes(32)); // 64-char secure token
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 day')); // 24-hour expiry

        // Store token & expiry in DB (you must have a table like `user_verifications`)
        $this->UserModel->insertActivationTokenData([
            'email' => $email,
            'token' => $token,
            'expires_at' => $expiresAt,
            'token_activation_type_id' => 2,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Create the activation link
        $resetLink = base_url("forgot-password-account?token={$token}");

        $response =  $this->send(
            $email,
            'Reset Your Storage Punters Password',
            'forgot_password_email',
            ['name' => $name, 'reset_link' => $resetLink],
            false,
            ""
        );

        if (!isset($response['success'])) {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the password reset email. Please try again later.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }

        if ($response['success']) {

            $response = [
                'success' => true,
                'status' => 'success',
                'message' => 'A password reset link has been sent to your email address. Please check your inbox.'
            ];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        } else {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the password reset email. Please try again later.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }
    }

    public function staff_invitation_email()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }


        $this->load->model('CompanyModel');

        // Fetch bidder profile details from the database
        $companyData = $this->CompanyModel->getCompanyByUserId($userId);

        // If user profile not found, return error response
        if (!$companyData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No company data found. Please set up your company profile first."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $companyId = $companyData['id'];

        $this->load->model('CompanyModel');
        // Fetch bidder profile details from the database
        $companyData = $this->CompanyModel->getCompanyById($companyId);

        // If user profile not found, return error response
        if (!$companyData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No company data found. Please set up your company profile first."
            ], JSON_PRETTY_PRINT);
            exit;
        }


        $company_name = $companyData['name'];

        $email = isset($json_input['email']) ? strtolower(trim($json_input['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if (!$existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "No user found with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        $userId = $existingUser['user_id'] ?? null;

        if (!$userId) {
            echo json_encode([
                "status" => "error",
                "message" => "User record is missing an ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(500);
            exit;
        }

        $userData = $this->UserModel->get_user_by_id($userId);

        if (!$userData) {
            echo json_encode([
                "status" => "error",
                "message" => "No user data found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        $name = $userData['first_name'] . " " . $userData['last_name'];

        // Generate secure invitation token
        $token = bin2hex(random_bytes(32)); // 64-char secure token
        $expiresAt = date('Y-m-d H:i:s', strtotime('+2 days')); // 48-hour expiry

        // Store the token
        $this->UserModel->insertActivationTokenData([
            'email' => $email,
            'token' => $token,
            'expires_at' => $expiresAt,
            'token_activation_type_id' => 3, // You can define this as invitation in DB
            'user_id' => $userId,
            'company_id' => $companyId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Build the invitation link
        $inviteLink = base_url("accept-invitation?token={$token}");

        // Send the invitation email
        $response = $this->send(
            "specialemailid2050@gmail.com",
            "You're Invited to Join " . $company_name,
            'staff_invitation_email',
            ['name' => $name, 'company_name' => $company_name,  'accept_link' => $inviteLink],
            false,
            ""
        );

        if (!isset($response['success'])) {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the invitation email. Please try again later.'
            ];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
            return;
        }

        if ($response['success']) {
            $response = [
                'success' => true,
                'status' => 'success',
                'message' => 'An invitation email has been sent to the staff member.'
            ];
        } else {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the invitation email. Please try again later.'
            ];
        }

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response))
            ->set_status_header(200);
    }


    public function user_account_password_reset_success_email()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if (!$existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "No user found with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        // ✅ If user exists, extract user_id
        $userId = $existingUser['user_id'] ?? null;

        if (!$userId) {
            echo json_encode([
                "status" => "error",
                "message" => "User record is missing an ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(500);
            exit;
        }


        $userData = $this->UserModel->get_user_by_id($userId);

        if (!$userData) {
            echo json_encode([
                "status" => "error",
                "message" => "No user data with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        $name = $userData['first_name'] . " " . $userData['last_name'];

        $emailResponse = $this->send(
            $email,
            'Your Password Has Been Successfully Reset',
            'reset_password_success_email',
            ['name' => $name],
            false,
            ""
        );

        if (isset($emailResponse['success']) && $emailResponse['success']) {
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'status' => 'success',
                'message' => 'A confirmation email has been sent to your inbox.'
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'status' => 'error',
                'message' => 'Password was reset, but we could not send the confirmation email.'
            ], JSON_PRETTY_PRINT);
        }
    }


    public function reset_user_account_password_email()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if (!$existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "No user found with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        // ✅ If user exists, extract user_id
        $userId = $existingUser['user_id'] ?? null;

        if (!$userId) {
            echo json_encode([
                "status" => "error",
                "message" => "User record is missing an ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(500);
            exit;
        }


        $userData = $this->UserModel->get_user_by_id($userId);

        if (!$userData) {
            echo json_encode([
                "status" => "error",
                "message" => "No user data with this email address."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }

        $name = $userData['first_name'] . " " . $userData['last_name'];

        // Generate activation token and expiry
        $token = bin2hex(random_bytes(32)); // 64-char secure token
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 day')); // 24-hour expiry

        // Store token & expiry in DB (you must have a table like `user_verifications`)
        $this->UserModel->insertActivationTokenData([
            'email' => $email,
            'token' => $token,
            'expires_at' => $expiresAt,
            'token_activation_type_id' => 2,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Create the activation link
        $resetLink = base_url("forgot-password-account?token={$token}");

        $response =  $this->send(
            $email,
            'Reset Your Storage Punters Password',
            'forgot_password_email',
            ['name' => $name, 'reset_link' => $resetLink],
            false,
            ""
        );

        if (!isset($response['success'])) {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the password reset email. Please try again later.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }

        if ($response['success']) {

            $response = [
                'success' => true,
                'status' => 'success',
                'message' => 'A password reset link has been sent to your email address. Please check your inbox.'
            ];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        } else {
            $response = [
                'success' => false,
                'status' => 'danger',
                'message' => 'We couldn’t send the password reset email. Please try again later.'
            ];


            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }
    }

    public function process_auction_outbid_email()
    {
        $this->load->model('EmailQueueModel');

        $nowTime = date('Y-m-d H:i:s');

        $emails = $this->EmailQueueModel->get_outbid_pending_due(100);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {



                $this->send(
                    $email->to_email,
                    $email->subject,
                    $email->template,
                    [
                        'name'         => $email->name,
                        'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        'auction_url'  => $email->auction_url
                    ],
                    false,
                    ""
                );



                $this->EmailQueueModel->mark_sent($email->id, $nowTime);
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }

    // Auction Outbid Email
    public function process_auction_win_email_by_id($auctionId = null)
    {
        $nowTime = date('Y-m-d H:i:s');

        if (!$auctionId || !is_numeric($auctionId)) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => false,
                    'message' => 'Missing or invalid auction ID.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(400);
        }

        $this->load->model('EmailQueueModel');
        $this->load->model('AuctionModel');
        $this->load->model('InvoiceModel');



        $emails = $this->EmailQueueModel->get_winner_pending_due_by_auction($auctionId);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {


                $this->send(
                    $email->to_email,
                    $email->subject,
                    $email->template,
                    [
                        'name'         => $email->name,
                        'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        'auction_url'  => $email->auction_url
                    ],
                    false,
                    ""
                );

                $scheduleTime = date('Y-m-d H:i:s');

                $this->EmailQueueModel->add([
                    'to_email'     => $email->to_email,
                    'subject'      => "Your Invoice from Storage Punters",
                    'template'     => "auction_invoice_email",
                    'name'         => $email->name,
                    'auction_id'  => $email->auction_id,
                    'auction_item' => $email->auction_item,
                    'auction_amount' => $email->auction_amount,
                    'auction_total' => $email->auction_total,
                    'auction_url'  => $email->auction_url,
                    'scheduled_at' => $scheduleTime,
                    'status'       => 'pending'
                ]);

                $this->generateAuctionInvoiceToBackgroundSchedule($email->auction_id);


                $this->EmailQueueModel->mark_sent($email->id, $nowTime);
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }

    public function generateAuctionInvoiceToBackgroundSchedule($auctionId)
    {

        // Step 1: Get current time + 5 minutes in Brisbane
        $endDateTime = new DateTime('now', new DateTimeZone('Australia/Brisbane'));
        $endDateTime->modify('+3 minutes');
        $endTimestamp = $endDateTime->getTimestamp();

        // Step 2: Determine proper PHP path
        $phpPath = PHP_BINARY;

        // On Windows Apache, PHP_BINARY may point to httpd.exe — fallback
        if (str_contains(strtolower($phpPath), 'httpd.exe')) {
            $phpPath = 'C:\xampp\php\php.exe'; // XAMPP fallback path
        }

        // Step 3: Paths & redirection
        $indexPhpPath = FCPATH . "index.php";
        $isWindows = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
        $redirect = $isWindows ? '> NUL 2>&1' : '> /dev/null 2>&1';

        // Step 4: Build and run command
        $cliCommand = "\"{$phpPath}\" \"{$indexPhpPath}\" Email process_auction_invoice_email_by_id {$auctionId} {$endTimestamp} {$redirect}";
        exec($cliCommand);

        // Step 5: Log message
        log_message('info', "Invoice for Auction ID {$auctionId} will be generated in 3 minutes (Brisbane time: {$endDateTime->format('Y-m-d H:i:s')}, timestamp: {$endTimestamp}).");
        log_message('debug', "CLI command executed: {$cliCommand}");
    }

    public function process_auction_invoice_email_by_id($auctionId = null)
    {

        $nowTime = date('Y-m-d H:i:s');

        if (!$auctionId || !is_numeric($auctionId)) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => false,
                    'message' => 'Missing or invalid auction ID.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(400);
        }


        $this->load->model('EmailQueueModel');
        $this->load->model('AuctionModel');
        $this->load->model('InvoiceModel');



        $emails = $this->EmailQueueModel->get_invoice_pending_due_by_auction($auctionId);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {


                $currentHighestBid = $this->AuctionModel->getCurrentHighestBidWithUser($email->auction_id);

                if ($currentHighestBid['user_id'] !== null) {

                    $user_id = $currentHighestBid['user_id'];
                    $max_bid = $currentHighestBid['current_highest_bid'];

                    // Extract only required fields from JSON input
                    $invoiceData = [
                        'invoice_number' => uniqid('INV-'), // or your own logic
                        'amount'         => number_format($max_bid, 2),
                        'tax_amount'     => number_format($max_bid * 0.10, 2), // 10% tax
                        'total_amount'   => number_format($max_bid, 2),
                        'currency'       => 'AUD',
                        'invoice_date'   => date('Y-m-d H:i:s'),
                        'due_date'       => date('Y-m-d H:i:s', strtotime('+3 days')),
                        'paid_date'      => date('Y-m-d H:i:s', strtotime('+3 days')), // same for now
                        'created_at'     => date('Y-m-d H:i:s'),
                        'updated_at'     => date('Y-m-d H:i:s')
                    ];

                    $invoiceDataInserted = $this->InvoiceModel->insert_invoice($invoiceData);

                    // Get company ID from JSON input
                    $invoiceId = $invoiceDataInserted['invoice_id'];

                    // Validate company ID
                    if ($invoiceId <= 0) {
                        echo json_encode([
                            "status" => "error",
                            "message" => "Invalid or missing company ID."
                        ], JSON_PRETTY_PRINT);
                        http_response_code(400); // Bad Request
                        exit;
                    }

                    // Extract only required fields from JSON input
                    $invoiceAuctionRelationshipData = [
                        'invoice_id' => $invoiceId,
                        'invoice_type_id' => 2,
                        'invoice_payment_method_type_id' => 2,
                        'invoice_payment_status_type_id' => 1,
                        'auction_id' => $email->auction_id,
                        'user_id' =>  $user_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];

                    $this->InvoiceModel->insert_invoice_auction_relationship($invoiceAuctionRelationshipData);

                    // Extract only required fields from JSON input
                    $auctionWonData = [
                        'auction_id' => $email->auction_id,
                        'user_id' =>  $user_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];

                    $this->AuctionModel->addToWonAuction($auctionWonData);

                    $auctionStatusTypeData = [
                        'auction_type_id' => 9,
                        'updated_at' => date('Y-m-d H:i:s')
                    ];

                    $this->AuctionModel->updateAuctionStatusTypeData($email->auction_id, $auctionStatusTypeData);

                    $viewData = [
                        'name' => $email->name,
                        'auction_item' => $email->auction_item,
                        'invoice_number' => $invoiceId,
                        'auction_amount' => $email->auction_amount,
                        'auction_total' => $email->auction_total
                    ];

                    // 🔽 Get PDF as string
                    $invoicePdf = $this->generate_invoice_pdf('pdf_invoice_template', $viewData);

                    $this->send(
                        $email->to_email,
                        $email->subject,
                        $email->template,
                        [
                            'name'         => $email->name,
                            'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        ],
                        true,
                        $invoicePdf
                    );


                    $this->EmailQueueModel->mark_sent($email->id, $nowTime);
                }
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }

    public function process_auction_outbid_email_by_id($auctionId = null)
    {

        $this->load->model('EmailQueueModel');

        $nowTime = date('Y-m-d H:i:s');

        if (!$auctionId || !is_numeric($auctionId)) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => false,
                    'message' => 'Missing or invalid auction ID.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(400);
        }

        $emails = $this->EmailQueueModel->get_outbid_pending_due_by_auction($auctionId);

        if (empty($emails)) {

            // Return JSON response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => 'No pending emails found in the queue.',
                    'timestamp' => $nowTime
                ]))
                ->set_status_header(200);

            return;
        }

        foreach ($emails as $email) {


            $this->EmailQueueModel->mark_processing($email->id, $nowTime);

            try {



                $this->send(
                    $email->to_email,
                    $email->subject,
                    $email->template,
                    [
                        'name'         => $email->name,
                        'auction_item' => $email->auction_item, /*"Forest Glen Self Storage Auction #13 - San Jose2, California",*/
                        'auction_url'  => $email->auction_url
                    ],
                    false,
                    ""
                );



                $this->EmailQueueModel->mark_sent($email->id, $nowTime);
            } catch (Exception $e) {
                $this->EmailQueueModel->mark_failed($email->id, $nowTime, $e->getMessage());
            }
        }

        // Optional success message
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'success' => true,
                'message' => 'Email queue processed successfully.',
                'processed' => count($emails),
                'timestamp' => $nowTime
            ]))
            ->set_status_header(200);
    }




    public function send_otp()
    {
        // Check if the request is an AJAX request
        if (!$this->input->is_ajax_request()) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'status' => 'danger', 'message' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Get data from JSON request body
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;

        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    "status" => "error",
                    "message" => "A valid email address is required."
                ]))
                ->set_status_header(400);
            return;
        }

        $toName = $data['toName'];
        // Load the model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);

        if ($existingUser) {
            // Email address already exists, return an error response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'status' => 'danger', 'message' => 'This email is already in use. Please use a different one.']))
                ->set_status_header(200);
            return;
        }

        // Generate a 6-digit OTP
        $otp = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);


        $response = $this->send(
            $email,
            '[Storage Punters] Your OTP Code for Access Verification',
            'new_registration_otp_email',
            ['name' => $toName, 'otp_code' => $otp],
            false,
            ""
        );

        if (!isset($response['success'])) {
            $response = ['success' => false, 'status' => 'danger', 'message' => 'An error occurred while sending the OTP. Please try again later.'];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }

        if ($response['success']) {

            $result =  [
                'status' => 'success',
                'message' => 'OTP sent successfully',
                'data' => [
                    '_otp' => $otp,
                    '_otp_email' => $email,
                    '_timestamp' => time() // Store current timestamp
                ]
            ];
            $this->session->unset_userdata('storage_punters_customer_registration_otp_session_data');

            $this->session->set_userdata('storage_punters_customer_registration_otp_session_data', $result);

            $response = ['success' => true, 'status' => 'success', 'message' => 'OTP sent successfully. Please check your email.'];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        } else {
            $response = ['success' => false, 'status' => 'danger', 'message' => 'An error occurred while sending the OTP. Please try again later.'];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }
    }

    public function verify_otp()
    {

        // Check if the request is an AJAX request
        if (!$this->input->is_ajax_request()) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'status' => 'danger', 'message' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Get data from JSON request body
        $data = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }



        $email = isset($data['email']) ? strtolower(trim($data['email'])) : null;

        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    "status" => "error",
                    "message" => "A valid email address is required."
                ]))
                ->set_status_header(400);
            return;
        }


        // Load the model
        $this->load->model('UserModel');

        $existingUser = $this->UserModel->get_user_by_email_address($email);

        if ($existingUser) {
            // Email address already exists, return an error response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'status' => 'danger', 'message' => 'This email is already in use. Please use a different one.']))
                ->set_status_header(200);
            return;
        }


        // Check if 'to' (email address) and 'otp' are provided
        if (!isset($data['otp'])) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    "status" => "error",
                    "message" => "OTP is required."
                ]))
                ->set_status_header(400);
            return;
        }


        $otp = $data['otp'];

        // Retrieve OTP, email, and timestamp from session
        $sessionData = $this->session->userdata('storage_punters_customer_registration_otp_session_data');

        // Check if session data exists
        if ($sessionData) {
            // Check if OTP has expired (1 minute expiration time)
            $currentTimestamp = time();
            $otpTimestamp = $sessionData['data']['_timestamp'];
            if (($currentTimestamp - $otpTimestamp) > 60) {
                // OTP has expired
                $response = ['success' => false, 'status' => 'danger', 'message' => 'OTP has expired. Please request a new OTP.'];
                $this->session->unset_userdata('storage_punters_customer_registration_otp_session_data');

                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode($response))
                    ->set_status_header(200);
            } else {
                // Validate OTP and email
                if ($email === $sessionData['data']['_otp_email'] && $otp === $sessionData['data']['_otp']) {
                    // OTP is valid
                    $response = ['success' => true, 'status' => 'success', 'message' => 'OTP verified successfully.'];
                    // Optionally, clear OTP from session after successful verification
                    $this->session->unset_userdata('storage_punters_customer_registration_otp_session_data');

                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode($response))
                        ->set_status_header(200);
                } else {
                    // OTP is invalid
                    $response = ['success' => false, 'status' => 'danger', 'message' => 'Invalid OTP. Please try again.'];

                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode($response))
                        ->set_status_header(200);
                }
            }
        } else {
            // No OTP data found in session
            $response = ['success' => false, 'status' => 'danger', 'message' => 'No OTP data found. Please request a new OTP.'];

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response))
                ->set_status_header(200);
        }
    }
}
