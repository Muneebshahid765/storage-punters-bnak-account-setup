<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Invoices extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Australia/Brisbane');
    }

    public function getInvoicesAuctionsByBidderUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405); // Method Not Allowed
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            http_response_code(403); // Forbidden
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access payment methods."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 2, 3])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }



        if (in_array($userRoleId, [1, 3])) {


            $this->load->model('CompanyModel');


            // Fetch bidder profile details from the database
            $companyData = $this->CompanyModel->getAllCompaniesByUser($userId);

            // If user profile not found, return error response
            if (!$companyData) {

                // Prepare the response data
                $data = [
                    "draw" => (int) $this->input->post('draw'),
                    "recordsTotal" => "0",
                    "recordsFiltered" => "0",
                    "data" => [],
                ];

                http_response_code(200); // Not Found
                echo json_encode([
                    "status" => "error",
                    "message" => "No company data is found.",
                    "result" => $data
                ], JSON_PRETTY_PRINT);
                exit;
            }



            // Extract just the company IDs
            $companyIds = array_column($companyData, 'company_id');

            $this->load->model('StorageFacilityModel');

            $storageFacilityIds = $this->StorageFacilityModel->getStorageFacilityIdsByCompanyId($companyIds);

            if (empty($storageFacilityIds)) {

                // Prepare the response data
                $data = [
                    "draw" => (int) $this->input->post('draw'),
                    "recordsTotal" => "0",
                    "recordsFiltered" => "0",
                    "data" => [],
                ];

                http_response_code(200);


                echo json_encode([
                    "status" => "error",
                    "message" => "No storage facilities found for the user's companies.",
                    "result" => $data
                ], JSON_PRETTY_PRINT);
                exit;
            }


            $this->load->model('AuctionModel');

            $auctionIds = $this->AuctionModel->getAuctionIdsByStorageFacilityIds($storageFacilityIds);

            if (empty($auctionIds)) {

                // Prepare the response data
                $data = [
                    "draw" => (int) $this->input->post('draw'),
                    "recordsTotal" => "0",
                    "recordsFiltered" => "0",
                    "data" => [],
                ];


                http_response_code(200);
                echo json_encode([
                    "status" => "error",
                    "message" => "No auctions are found for the user's storage facilities.",
                    "result" => $data
                ], JSON_PRETTY_PRINT);
                exit;
            }
        } else {

            $this->load->model('AuctionModel');

            $auctionIds = $this->AuctionModel->getAuctionIdsByUserId($userId);


            if (empty($auctionIds)) {

                // Prepare the response data
                $data = [
                    "draw" => (int) $this->input->post('draw'),
                    "recordsTotal" => "0",
                    "recordsFiltered" => "0",
                    "data" => [],
                ];


                http_response_code(200);
                echo json_encode([
                    "status" => "error",
                    "message" => "No auctions are found for the user.",
                    "result" => $data
                ], JSON_PRETTY_PRINT);
                exit;
            }
        }
        // Sanitize input data
        $draw = (int)$this->input->post('draw');
        $start = (int)$this->input->post('start');
        $length = (int)$this->input->post('length');
        $search = $this->input->post('search')['value'];
        $orderColumn = $this->input->post('order')[0]['column'];
        $orderDir = $this->input->post('order')[0]['dir'];

        // Validate input data to prevent SQL injection
        if (!is_int($draw) || !is_int($start) || !is_int($length)) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid input']))
                ->set_status_header(400);
            return;
        }

        // Load User Model
        $this->load->model('InvoiceModel');

        $totalRecords = $this->InvoiceModel->countAllAuctionInvoicesByBidderUser($userId, $userRoleId, $auctionIds);
        $filteredRecords = $this->InvoiceModel->countFilteredAuctionInvoicesByBidderUser($search, $userId, $userRoleId, $auctionIds);
        $result = $this->InvoiceModel->getFilteredAuctionInvoicesByBidderUser($start, $length, $search, $orderColumn, $orderDir, $userId, $userRoleId, $auctionIds);

        // Prepare the response data
        $data = [
            'draw' => $draw,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data' => $result,
        ];

        // Return success response with payment method data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Invoices are retrieved successfully.",
            "result" => $data
        ], JSON_PRETTY_PRINT);
    }
}
