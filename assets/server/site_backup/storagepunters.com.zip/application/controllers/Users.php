<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Users extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Australia/Brisbane');
    }
    public function getBidderProfileById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Load Auction Model
        $this->load->model('UserModel');

        // Fetch bidder profile details from the database
        $userProfileData = $this->UserModel->getBidderProfileById($userId);

        // If user profile not found, return error response
        if (!$userProfileData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No profile is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Your profile retrieved successfully.",
            "data" => $userProfileData
        ], JSON_PRETTY_PRINT);
    }


    public function getStorageFacilityProfileById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Load Auction Model
        $this->load->model('UserModel');

        // Fetch bidder profile details from the database
        $userProfileData = $this->UserModel->getBidderProfileById($userId);

        // If user profile not found, return error response
        if (!$userProfileData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No profile is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Your profile retrieved successfully.",
            "data" => $userProfileData
        ], JSON_PRETTY_PRINT);
    }


    public function getBidderPaymentMethodById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405); // Method Not Allowed
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            http_response_code(403); // Forbidden
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access payment methods."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Sanitize input data
        $draw = (int)$this->input->post('draw');
        $start = (int)$this->input->post('start');
        $length = (int)$this->input->post('length');
        $search = $this->input->post('search')['value'];
        $orderColumn = $this->input->post('order')[0]['column'];
        $orderDir = $this->input->post('order')[0]['dir'];

        // Validate input data to prevent SQL injection
        if (!is_int($draw) || !is_int($start) || !is_int($length)) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid input']))
                ->set_status_header(400);
            return;
        }

        // Load User Model
        $this->load->model('UserModel');

        $totalRecords = $this->UserModel->countAllPaymentMethod();
        $filteredRecords = $this->UserModel->countFilteredPaymentMethod($search, $userId);
        $result = $this->UserModel->getFilteredBidderPaymentMethodById($start, $length, $search, $orderColumn, $orderDir, $userId);

        // Prepare the response data
        $data = [
            'draw' => $draw,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data' => $result,
        ];

        // Return success response with payment method data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Payment method retrieved successfully.",
            "result" => $data
        ], JSON_PRETTY_PRINT);
    }


    public function registerNewBidder()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $email = isset($json_input['email']) ? strtolower(trim($json_input['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if ($existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "This email is already in use. Please use a different one."
            ], JSON_PRETTY_PRINT);
            http_response_code(200);
            exit;
        }


        $password = isset($json_input['current_password']) ? trim($json_input['current_password']) : '';
        $passwordConfirmation = isset($json_input['password_confirmation']) ? trim($json_input['password_confirmation']) : '';

        // 🔒 Validate password length
        if (strlen($password) < 6) {
            echo json_encode([
                "status" => "error",
                "message" => "Password must be at least 6 characters long."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // 🔒 Validate password match
        if ($password !== $passwordConfirmation) {
            echo json_encode([
                "status" => "error",
                "message" => "Password and confirmation do not match."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // ✅ Begin DB transaction
        $this->db->trans_begin();

        // Identity data
        $bidderIdentityData = [
            'first_name' => isset($json_input['first_name']) ? ucwords(strtolower(trim($json_input['first_name']))) : null,
            'last_name'  => isset($json_input['last_name']) ? ucwords(strtolower(trim($json_input['last_name']))) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $bidderIdentityDataInserted = $this->UserModel->insertBidderIdentityData($bidderIdentityData);
        $userId = $bidderIdentityDataInserted['user_id'] ?? 0;

        if ($userId <= 0) {
            $this->db->trans_rollback();
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing user ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Credentials
        $bidderCredentialsData = [
            'email' => $email,
            'password' => $password,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderCredentialsData($bidderCredentialsData);

        // Role
        $bidderRoleData = [
            'role_id' => 2,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderRoleData($bidderRoleData);

        // Status
        $bidderStatusData = [
            'status_type_id' => 2,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderStatusData($bidderStatusData);

        // Profile
        $bidderProfileData = [
            'date_of_birth' => isset($json_input['dob']) ? trim($json_input['dob']) : null,
            'time_zone' => isset($json_input['timezone']) ? trim($json_input['timezone']) : null,
            'hear_us' => isset($json_input['hear_us']) ? trim($json_input['hear_us']) : null,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderProfileData($bidderProfileData);

        // Alerts
        $alertTypes = [
            [1, 4],
            [2, 4],
            [1, 5],
            [2, 5],
            [1, 3],
            [2, 3]
        ];
        $alertSettings = [];
        foreach ($alertTypes as [$prefId, $notifId]) {
            $alertSettings[] = [
                'preference_type_id' => $prefId,
                'notification_type_id' => $notifId,
                'status_type_id' => 1,
                'user_id' => $userId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
        }
        $this->UserModel->insertBidderAlertSettingsData($alertSettings);

        // Location
        $bidderLocationData = [
            'street_address' => isset($json_input['address']) ? ucwords(strtolower(trim($json_input['address']))) : null,
            'apt_suite'      => isset($json_input['apt_suite']) ? ucwords(strtolower(trim($json_input['apt_suite']))) : null,
            'city'           => isset($json_input['city']) ? ucwords(strtolower(trim($json_input['city']))) : null,
            'postal_code'    => isset($json_input['zip']) ? strtoupper(trim($json_input['zip'])) : null,
            'state'          => isset($json_input['state']) ? ucwords(strtolower(trim($json_input['state']))) : null,
            'country'        => isset($json_input['country']) ? ucwords(strtolower(trim($json_input['country']))) : null,
            'phone'     => isset($json_input['cell_phone']) ? trim($json_input['cell_phone']) : null,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s')
        ];
        $locationInsertResult = $this->UserModel->insertBidderLocationData($bidderLocationData);
        $locationId = $locationInsertResult['location_id'] ?? 0;

        if ($locationId <= 0) {
            $this->db->trans_rollback();
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Location relationship
        $bidderLocationRelationshipData = [
            'user_id' => $userId,
            'location_id' => $locationId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderLocationRelationshipData($bidderLocationRelationshipData);

        // ✅ Check and commit/rollback
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Registration failed due to a database error. No data was saved."
            ], JSON_PRETTY_PRINT);
        } else {
            $this->db->trans_commit();
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Your registration was completed successfully."
            ], JSON_PRETTY_PRINT);
        }

        exit;
    }


    public function registerNewStoragePunter()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Load model
        $this->load->model('UserModel');

        $email = isset($json_input['email']) ? strtolower(trim($json_input['email'])) : null;
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "A valid email address is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $existingUser = $this->UserModel->get_user_by_email_address($email);
        if ($existingUser) {
            echo json_encode([
                "status" => "error",
                "message" => "This email is already in use. Please use a different one."
            ], JSON_PRETTY_PRINT);
            http_response_code(200);
            exit;
        }


        $password = isset($json_input['current_password']) ? trim($json_input['current_password']) : '';
        $passwordConfirmation = isset($json_input['password_confirmation']) ? trim($json_input['password_confirmation']) : '';

        // 🔒 Validate password length
        if (strlen($password) < 6) {
            echo json_encode([
                "status" => "error",
                "message" => "Password must be at least 6 characters long."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // 🔒 Validate password match
        if ($password !== $passwordConfirmation) {
            echo json_encode([
                "status" => "error",
                "message" => "Password and confirmation do not match."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // ✅ Begin DB transaction
        $this->db->trans_begin();

        // Identity data
        $bidderIdentityData = [
            'first_name' => isset($json_input['first_name']) ? ucwords(strtolower(trim($json_input['first_name']))) : null,
            'last_name'  => isset($json_input['last_name']) ? ucwords(strtolower(trim($json_input['last_name']))) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $bidderIdentityDataInserted = $this->UserModel->insertBidderIdentityData($bidderIdentityData);
        $userId = $bidderIdentityDataInserted['user_id'] ?? 0;

        if ($userId <= 0) {
            $this->db->trans_rollback();
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing user ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Credentials
        $bidderCredentialsData = [
            'email' => $email,
            'password' => $password,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderCredentialsData($bidderCredentialsData);

        // Role
        $bidderRoleData = [
            'role_id' => 1,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderRoleData($bidderRoleData);

        // Status
        $bidderStatusData = [
            'status_type_id' => 2,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderStatusData($bidderStatusData);

        // Profile
        $bidderProfileData = [
            'date_of_birth' => isset($json_input['dob']) ? trim($json_input['dob']) : null,
            'time_zone' => isset($json_input['timezone']) ? trim($json_input['timezone']) : null,
            'hear_us' => isset($json_input['hear_us']) ? trim($json_input['hear_us']) : null,
            'user_id' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderProfileData($bidderProfileData);

        // Location
        $bidderLocationData = [
            'street_address' => isset($json_input['address']) ? ucwords(strtolower(trim($json_input['address']))) : null,
            'apt_suite'      => isset($json_input['apt_suite']) ? ucwords(strtolower(trim($json_input['apt_suite']))) : null,
            'city'           => isset($json_input['city']) ? ucwords(strtolower(trim($json_input['city']))) : null,
            'postal_code'    => isset($json_input['zip']) ? strtoupper(trim($json_input['zip'])) : null,
            'state'          => isset($json_input['state']) ? ucwords(strtolower(trim($json_input['state']))) : null,
            'country'        => isset($json_input['country']) ? ucwords(strtolower(trim($json_input['country']))) : null,
            'phone'     => isset($json_input['cell_phone']) ? trim($json_input['cell_phone']) : null,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s')
        ];
        $locationInsertResult = $this->UserModel->insertBidderLocationData($bidderLocationData);
        $locationId = $locationInsertResult['location_id'] ?? 0;

        if ($locationId <= 0) {
            $this->db->trans_rollback();
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Location relationship
        $bidderLocationRelationshipData = [
            'user_id' => $userId,
            'location_id' => $locationId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->UserModel->insertBidderLocationRelationshipData($bidderLocationRelationshipData);

        // ✅ Check and commit/rollback
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Registration failed due to a database error. No data was saved."
            ], JSON_PRETTY_PRINT);
        } else {
            $this->db->trans_commit();
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Your registration was completed successfully."
            ], JSON_PRETTY_PRINT);
        }

        exit;
    }



    public function updateBidderProfileById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Extract only required fields from JSON input
        $bidderProfileData = [
            'date_of_birth' => isset($json_input['dob']) ? trim($json_input['dob']) : null,
            'time_zone' => isset($json_input['timezone']) ? trim($json_input['timezone']) : null,
            'hear_us' => isset($json_input['hear_us']) ? trim($json_input['hear_us']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $bidderLocationData = [
            'street_address' => isset($json_input['address']) ? trim($json_input['address']) : null,
            'apt_suite' => isset($json_input['apt_suite']) ? trim($json_input['apt_suite']) : null,
            'city' => isset($json_input['city']) ? trim($json_input['city']) : null,
            'postal_code' => isset($json_input['zip']) ? trim($json_input['zip']) : null,
            'state' => isset($json_input['state']) ? trim($json_input['state']) : null,
            'country' => isset($json_input['country']) ? trim($json_input['country']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $bidderPasswordData = [
            'password' => isset($json_input['current_password']) ? trim($json_input['current_password']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Load Auction Model
        $this->load->model('UserModel');

        // Update profile, location, and password separately
        $profileUpdated = $this->UserModel->updateBidderProfile($userId, $bidderProfileData);
        $locationUpdated = $this->UserModel->updateBidderLocation($userId, $bidderLocationData);
        $passwordUpdated = $this->UserModel->updateBidderPassword($userId, $bidderPasswordData);


        // Check if at least one update was successful
        if ($profileUpdated || $locationUpdated || $passwordUpdated) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Profile has been updated successfully."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update profile."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }


    public function updateStorageFacilityProfileById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Extract only required fields from JSON input
        $bidderProfileData = [
            'date_of_birth' => isset($json_input['dob']) ? trim($json_input['dob']) : null,
            'time_zone' => isset($json_input['timezone']) ? trim($json_input['timezone']) : null,
            'hear_us' => isset($json_input['hear_us']) ? trim($json_input['hear_us']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $bidderLocationData = [
            'street_address' => isset($json_input['address']) ? trim($json_input['address']) : null,
            'apt_suite' => isset($json_input['apt_suite']) ? trim($json_input['apt_suite']) : null,
            'city' => isset($json_input['city']) ? trim($json_input['city']) : null,
            'postal_code' => isset($json_input['zip']) ? trim($json_input['zip']) : null,
            'state' => isset($json_input['state']) ? trim($json_input['state']) : null,
            'country' => isset($json_input['country']) ? trim($json_input['country']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $bidderPasswordData = [
            'password' => isset($json_input['current_password']) ? trim($json_input['current_password']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Load Auction Model
        $this->load->model('UserModel');

        // Update profile, location, and password separately
        $profileUpdated = $this->UserModel->updateBidderProfile($userId, $bidderProfileData);
        $locationUpdated = $this->UserModel->updateBidderLocation($userId, $bidderLocationData);
        $passwordUpdated = $this->UserModel->updateBidderPassword($userId, $bidderPasswordData);


        // Check if at least one update was successful
        if ($profileUpdated || $locationUpdated || $passwordUpdated) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Profile has been updated successfully."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update profile."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }

    public function addBidderPaymentMethodById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Required fields list
        $required_fields = ["firstname", "lastname", "email", "phone", "address", "zip", "card_type", "card_number", "card_security_code", "card_expiration_month", "card_expiration_year"];
        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || empty(trim($json_input[$field]))) {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Additional validation
        if (!filter_var($json_input["email"], FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid email format."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{5,6}$/', $json_input["zip"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid ZIP code. Only digits allowed (3-10 digits)."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{20}$/', $json_input["card_number"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid card number. It must be exactly 20 digits."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{3}$/', $json_input["card_security_code"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid CVV. Enter a valid 3 or 4 digit CVV."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // ✅ Validate Expiration Date (Must be in the future)
        $currentYear = date("Y");
        $currentMonth = date("m");

        $expMonth = (int) $json_input["card_expiration_month"];
        $expYear = (int) $json_input["card_expiration_year"];

        if ($expYear < $currentYear || ($expYear === $currentYear && $expMonth < $currentMonth)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid expiration date. The card must expire in the future."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }
        // Load Auction Model
        $this->load->model('UserModel');


        // ✅ Prepare data to insert into database
        $paymentMethodData = [
            "card_holder_first_name"   => $json_input["firstname"],
            "card_holder_last_name"    => $json_input["lastname"],
            "card_holder_email"        => $json_input["email"],
            "card_holder_phone"        => $json_input["phone"],
            "card_billing_address"     => $json_input["address"],
            "card_billing_zip"         => $json_input["zip"],
            "card_type"                => $json_input["card_type"],
            "card_holder_card_number"  => $json_input["card_number"],
            "card_cvv"                 => $json_input["card_security_code"],
            "card_expiration_month"    => $json_input["card_expiration_month"],
            "card_expiration_year"     => $json_input["card_expiration_year"],
            "user_id"     => $userId,
            "status_type_id "     => 1,
            "created_at"               => date("Y-m-d H:i:s"),
            "updated_at"               => date("Y-m-d H:i:s")
        ];
        // Fetch auction details from the database
        $paymentMethodResult = $this->UserModel->insert_bidder_payment_method_data($paymentMethodData);

        // Return the response
        if ($paymentMethodResult) {
            echo json_encode([
                "status" => "success",
                "message" => "Your payment method has been successfully added and secured.",
                "data" => [
                    "payment_method_id" => $paymentMethodResult['payment_method_id']
                ]
            ], JSON_PRETTY_PRINT);
            http_response_code(200);
            exit;
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Something went wrong. We couldn't add your payment method. Please try again later."
            ], JSON_PRETTY_PRINT);
            http_response_code(500); // Internal Server Error
            exit;
        }
        exit;
    }

    public function updateBidderPaymentMethodById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_id` is passed (for update scenarios)
        $payment_method_id = isset($json_input['payment_method_id']) ? (int)$json_input['payment_method_id'] : null;

        // ✅ Handle case when `payment_method_id` is NOT passed
        if ($payment_method_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Required fields list
        $required_fields = ["firstname", "lastname", "email", "phone", "address", "zip", "card_type", "card_number", "card_security_code", "card_expiration_month", "card_expiration_year"];
        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || empty(trim($json_input[$field]))) {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Additional validation
        if (!filter_var($json_input["email"], FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid email format."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{5,6}$/', $json_input["zip"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid ZIP code. Only digits allowed (3-10 digits)."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{20}$/', $json_input["card_number"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid card number. It must be exactly 20 digits."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        if (!preg_match('/^[0-9]{3}$/', $json_input["card_security_code"])) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid CVV. Enter a valid 3 or 4 digit CVV."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // ✅ Validate Expiration Date (Must be in the future)
        $currentYear = date("Y");
        $currentMonth = date("m");

        $expMonth = (int) $json_input["card_expiration_month"];
        $expYear = (int) $json_input["card_expiration_year"];

        if ($expYear < $currentYear || ($expYear === $currentYear && $expMonth < $currentMonth)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid expiration date. The card must expire in the future."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }
        // Load Auction Model
        $this->load->model('UserModel');


        // ✅ Prepare data to insert into database
        $paymentMethodData = [
            "card_holder_first_name"   => $json_input["firstname"],
            "card_holder_last_name"    => $json_input["lastname"],
            "card_holder_email"        => $json_input["email"],
            "card_holder_phone"        => $json_input["phone"],
            "card_billing_address"     => $json_input["address"],
            "card_billing_zip"         => $json_input["zip"],
            "card_type"                => $json_input["card_type"],
            "card_holder_card_number"  => $json_input["card_number"],
            "card_cvv"                 => $json_input["card_security_code"],
            "card_expiration_month"    => $json_input["card_expiration_month"],
            "card_expiration_year"     => $json_input["card_expiration_year"],
            "updated_at"               => date("Y-m-d H:i:s")
        ];
        // Fetch auction details from the database
        $paymentMethodResult = $this->UserModel->update_bidder_payment_method_data($payment_method_id, $paymentMethodData);

        // Return the response
        if ($paymentMethodResult) {
            echo json_encode([
                "status" => "success",
                "message" => "Your payment method has been updated successfully.",
            ], JSON_PRETTY_PRINT);
            http_response_code(200);
            exit;
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Something went wrong. We couldn't update your payment method. Please try again later."
            ], JSON_PRETTY_PRINT);
            http_response_code(500); // Internal Server Error
            exit;
        }
        exit;
    }


    public function updateBidderPaymentMethodStatusById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_id` is passed (for update scenarios)
        $payment_method_id = isset($json_input['payment_method_id']) ? (int)$json_input['payment_method_id'] : null;

        // ✅ Handle case when `payment_method_id` is NOT passed
        if ($payment_method_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_status_name` is passed (for update scenarios)
        $payment_method_status_name = isset($json_input['payment_method_status_name']) ? (string)$json_input['payment_method_status_name'] : null;


        // ✅ Handle case when `payment_method_status_name` is NOT passed
        if ($payment_method_status_name === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_status_name is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        if ($payment_method_status_name == "Active") {
            $payment_method_status_id = 1;
        } else if ($payment_method_status_name == "Inactive") {
            $payment_method_status_id = 2;
        } else {
            $payment_method_status_id = 0;
        }

        // ✅ Handle case when `payment_method_status_id` is NOT passed
        if ($payment_method_status_id == 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_status_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('UserModel');


        // ✅ Prepare data to insert into database
        $paymentMethodStatusData = [
            "status_type_id" => $payment_method_status_id,
            "updated_at" => date("Y-m-d H:i:s")
        ];
        // Fetch auction details from the database
        $paymentMethodResult = $this->UserModel->update_bidder_payment_method_status_data($payment_method_id, $paymentMethodStatusData);

        // Return the response
        if ($paymentMethodResult) {
            echo json_encode([
                "status" => "success",
                "message" => "Your payment method status has been updated successfully.",
            ], JSON_PRETTY_PRINT);
            http_response_code(200);
            exit;
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Something went wrong. We couldn't update your payment method status. Please try again later."
            ], JSON_PRETTY_PRINT);
            http_response_code(500); // Internal Server Error
            exit;
        }
        exit;
    }

    public function activate_account()
    {


        $token = $this->input->get('token');

        if (!$token) {
            show_error("Invalid or missing activation token.", 400);
            return;
        }

        $this->load->model('UserModel');

        $record = $this->UserModel->getActivationByToken($token, 1); // 1 for Email Actication Token

        if (!$record) {
            $this->load->view('user/activation/invalid');
            return;
        }

        // Check expiry
        if (strtotime($record['expires_at']) < time()) {
            $this->load->view('user/activation/expired');
            return;
        }

        // Activate the account
        $this->UserModel->update_user_status($record['user_id'], 1);  // 1 for Email Actication Token
        $this->UserModel->deleteActivationToken($token, 1);

        $this->load->view('user/activation/success');
    }

    public function forgot_password_account()
    {


        $token = $this->input->get('token');

        if (!$token) {
            show_error("Invalid or missing activation token.", 400);
            return;
        }

        $this->load->model('UserModel');

        $record = $this->UserModel->getActivationByToken($token, 2); // 2 for Email Forgot Password Token

        if (!$record) {
            $this->load->view('user/activation/invalid');
            return;
        }

        // Check expiry
        if (strtotime($record['expires_at']) < time()) {
            $this->load->view('user/activation/expired');
            return;
        }


        $data['scripts'] = [
            base_url('assets/js/ajax/authentication/password_reset.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('auth/forgot_password');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function staff_invitation_account()
    {


        $token = $this->input->get('token');

        if (!$token) {
            show_error("Invalid or missing activation token.", 400);
            return;
        }

        $this->load->model('UserModel');

        $record = $this->UserModel->getActivationByToken($token, 3); // 3 for Invitation Staff Token

        if (!$record) {
            $this->load->view('user/activation/invalid');
            return;
        }

        // Check expiry
        if (strtotime($record['expires_at']) < time()) {
            $this->load->view('user/activation/expired');
            return;
        }

        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/staff/accept_invitation.js'),
        ];

        $companyInfo = [

            'user_id' => $record['user_id'],
            'company_id' => $record['company_id'],

        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/staff/accept_invitation', $companyInfo);
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function registrationSuccessPage()
    {
        // Securely get the email from query string
        $email = $this->input->get('email', true); // 'true' = XSS filtering

        // Fallback if no email is passed
        if (!$email) {
            redirect('login'); // Or show a custom error page
            return;
        }

        $data['user_email'] = strtolower($email);

        // Load views
        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('user/registration/success', $data); // pass email to view
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts');
    }


    public function reset_user_account_password()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Get and validate required inputs
        $token = isset($json_input['token']) ? trim($json_input['token']) : '';
        $newPassword = trim($json_input['new_password'] ?? '');
        $passwordConfirmation = trim($json_input['confirm_password'] ?? '');

        if (empty($token)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Missing or invalid password reset token."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // 🔒 Validate password length
        if (strlen($newPassword) < 8) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Password must be at least 8 characters long."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // 🔒 Validate password match
        if ($newPassword !== $passwordConfirmation) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Password and confirmation do not match."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }


        // Load model
        $this->load->model('UserModel');

        $userToken  = $this->UserModel->getActivationByToken($token, 2); // 2 for Email Forgot Password Token
        if (!$userToken) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid or expired token. Please request a new password reset."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        // ✅ If user exists, extract user_id
        $userId = $userToken['user_id'] ?? null;

        if (!$userId) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid token. No associated user."
            ], JSON_PRETTY_PRINT);
            exit;
        }



        $userData = $this->UserModel->get_user_by_id($userId);


        if (!$userData) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "User account not found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        // Update password
        $updateData = [
            'password' => $newPassword,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $passwordUpdated = $this->UserModel->updateBidderPassword($userId, $updateData);

        if (!$passwordUpdated) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Failed to update the password. Please try again."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Delete token (1 = general token type for cleanup)
        $this->UserModel->deleteActivationToken($token, 2);


        // Send confirmation email
        $name = $userData['first_name'] . ' ' . $userData['last_name'];
        $email = $userToken['email'];

        // ✅ Final success response
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'status' => 'success',
            "message" => "Your password has been successfully reset.",
            "data" => ["name" => $name, "email" => $email]
        ], JSON_PRETTY_PRINT);
    }

    public function acceptInvitationByStaff()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Get and validate required inputs
        $token = isset($json_input['token']) ? trim($json_input['token']) : '';

        if (empty($token)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Missing or invalid password reset token."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $this->load->model('UserModel');

        $userToken  = $this->UserModel->getActivationByToken($token, 3); // 3 for Invitation Token
        if (!$userToken) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid or expired token. Please request a new password reset."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        // Get company ID and bid amount from JSON input
        $companyId = isset($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate company ID and bid amount
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Get user ID and bid amount from JSON input
        $staffMemberId = isset($json_input['userId']) ? (int)$json_input['userId'] : 0;

        // Validate user ID and bid amount
        if ($staffMemberId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing staff ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $this->load->model('StaffModel');

        $staffMemberStatusData = [
            "status_type_id"   => 1,
            "updated_at"   => date("Y-m-d H:i:s")
        ];


        $staffMemberStatusDataUpdated = $this->StaffModel->updateStaffMemberStatusData($staffMemberId, $companyId, $staffMemberStatusData);

        // Check if at least one update was successful
        if ($staffMemberStatusDataUpdated) {

            // Delete token (1 = general token type for cleanup)
            $this->UserModel->deleteActivationToken($token, 3);

            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "You’ve successfully accepted the invitation. Welcome aboard!"
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update invitation status."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }


    public function cancelInvitationByStaff()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            $this->output->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid request']))
                ->set_status_header(400);
            return;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        // Get and validate required inputs
        $token = isset($json_input['token']) ? trim($json_input['token']) : '';

        if (empty($token)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Missing or invalid password reset token."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $this->load->model('UserModel');

        $userToken  = $this->UserModel->getActivationByToken($token, 3); // 3 for Invitation Token
        if (!$userToken) {
            echo json_encode([
                'success' => false,
                "status" => "error",
                "message" => "Invalid or expired token. Please request a new password reset."
            ], JSON_PRETTY_PRINT);
            http_response_code(404);
            exit;
        }

        // Get company ID and bid amount from JSON input
        $companyId = isset($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate company ID and bid amount
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Get user ID and bid amount from JSON input
        $staffMemberId = isset($json_input['userId']) ? (int)$json_input['userId'] : 0;

        // Validate user ID and bid amount
        if ($staffMemberId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing staff ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $this->load->model('StaffModel');

        $staffMemberStatusData = [
            "status_type_id"   => 2,
            "updated_at"   => date("Y-m-d H:i:s")
        ];


        $staffMemberStatusDataUpdated = $this->StaffModel->updateStaffMemberStatusData($staffMemberId, $companyId, $staffMemberStatusData);

        // Check if at least one update was successful
        if ($staffMemberStatusDataUpdated) {



            // Delete token (1 = general token type for cleanup)
            $this->UserModel->deleteActivationToken($token, 3);

            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "You’ve cancelled the invitation. No changes have been made."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update invitation status."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }
}
