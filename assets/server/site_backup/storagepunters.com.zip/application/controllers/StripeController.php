<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Stripe\Stripe;
use Stripe\Customer;
use Stripe\PaymentMethod;
use Stripe\Charge;
use Stripe\Subscription;
use Stripe\Exception\CardException;
use Stripe\Exception\RateLimitException;
use Stripe\Exception\InvalidRequestException;
use Stripe\Exception\AuthenticationException;
use Stripe\Exception\ApiConnectionException;
use Stripe\Exception\ApiErrorException;
use Stripe\Identity\VerificationSession;

class StripeController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        /* TEST KEY*/
        Stripe::setApiKey("sk_test_51R6fiK08JMAyNQJTX1m1tmy0kDvgkoswTi699EFf0zI180ZzLWvQ0byw4y24JaNrft1t7BVBXCBl9R2eguNYIgog00g1nWmPoM");

        /* PRODUCTION KEY*/
        // Stripe::setApiKey("");

        date_default_timezone_set('Australia/Brisbane');
    }

    private function jsonResponse($data, $code = 200)
    {
        http_response_code($code);
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }

    private function getInput(array $requiredKeys = [])
    {
        $input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->jsonResponse([
                'status' => 'error',
                'message' => 'Invalid JSON: ' . json_last_error_msg()
            ], 400);
        }

        foreach ($requiredKeys as $key) {
            if (!isset($input[$key])) {
                $this->jsonResponse([
                    'status' => 'error',
                    'message' => "Missing required field: $key"
                ], 400);
            }
        }

        return $input;
    }

    public function test_stripe()
    {

        $test = 3;

        $email = strtolower("specialemailid2050@gmail.com");
        $name = "Ali";

        try {
            if ($test == 1) {


                $customers = Customer::all([
                    'email' => $email,
                    'limit' => 1
                ]);

                if (!empty($customers->data)) {
                    $customer = $customers->data[0];


                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode(['success' => true, 'message' => "Customer found", 'customer' => [
                            'id'    => $customer->id,
                            'email' => $customer->email,
                            'name'  => $customer->name,
                        ]]))
                        ->set_status_header(200);
                } else {

                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode(['success' => false, 'message' => "Customer not found"]))
                        ->set_status_header(200);
                }
            } else if ($test == 2) {

                // cus_S9Rp4QnqmWqP2b
                // Create the customer in Stripe
                $customer = \Stripe\Customer::create([
                    'email' => $email,
                    'name'  => $name
                ]);

                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => true, 'message' => "Customer found", 'customer' => $customer]))
                    ->set_status_header(200);
            } else {

                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => false, 'message' => "Test mode is off"]))
                    ->set_status_header(200);
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }


    public function addStripeCustomer()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $name = $userSessionData['first_name'] . " " . $userSessionData['last_name'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 2])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        try {

            // ✅ Create Stripe Customer
            $customer = \Stripe\Customer::create([
                'email' => $email,
                'name'  => $name,
                'metadata' => [
                    'app_user_id' => $userId
                ]
            ]);


            // ✅ Respond with success
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => true,
                    'message' => "Customer created successfully",
                    'customer' => [
                        'id'    => $customer->id,
                        'email' => $customer->email,
                        'name'  => $customer->name,
                    ]
                ]))
                ->set_status_header(200);
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }

    public function searchStripeCustomer()
    {


        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 2])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        try {
            $customers = Customer::all([
                'email' => $email,
                'limit' => 1
            ]);

            if (!empty($customers->data)) {
                $customer = $customers->data[0];


                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => true, 'message' => "Customer found", 'customer' => [
                        'id'    => $customer->id,
                        'email' => $customer->email,
                        'name'  => $customer->name,
                    ]]))
                    ->set_status_header(200);
            } else {

                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(['success' => false, 'message' => "Customer not found"]))
                    ->set_status_header(200);
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }

    public function createStripeSetupIntent()
    {

        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 2])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $customer_id = isset($json_input['customer_id']) ? trim($json_input['customer_id']) : null;

        if (empty($customer_id)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing customer ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }



        try {

            $setupIntent = \Stripe\SetupIntent::create([
                'customer' => $customer_id
            ]);

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => true, 'client_secret' => $setupIntent->client_secret]))
                ->set_status_header(200);
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }

    public function attachStripePaymentMethod()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "Access Denied: Your account does not have permission."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $customer_id = isset($json_input['customer_id']) ? trim($json_input['customer_id']) : null;

        if (empty($customer_id)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing customer ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $payment_method_id = isset($json_input['payment_method_id']) ? trim($json_input['payment_method_id']) : null;

        if (empty($customer_id) || empty($payment_method_id)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing payment method ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        try {

            $paymentMethod =  \Stripe\PaymentMethod::retrieve($payment_method_id)->attach([
                'customer' => $customer_id
            ]);

            // ✅ Prepare data to insert into database
            $paymentMethodData = [
                "user_id"     => $userId,
                "stripe_customer_id"   => $customer_id,
                "stripe_payment_method_id"    => $payment_method_id,
                "is_default"        => "false",
                "status_type_id "     => 1,
                "created_at"               => date("Y-m-d H:i:s"),
                "updated_at"               => date("Y-m-d H:i:s")
            ];

            // Load Auction Model
            $this->load->model('UserModel');

            // Fetch auction details from the database
            $paymentMethodResult = $this->UserModel->insert_bidder_payment_method_data($paymentMethodData);

            // Return the response
            if ($paymentMethodResult) {
                echo json_encode([
                    "status" => "success",
                    "message" => "Your payment method has been successfully added and secured.",
                    "data" => [
                        "payment_method_id" => $paymentMethodResult['payment_method_id']
                    ]
                ], JSON_PRETTY_PRINT);
                http_response_code(200);
                exit;
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Something went wrong. We couldn't add your payment method. Please try again later."
                ], JSON_PRETTY_PRINT);
                http_response_code(500); // Internal Server Error
                exit;
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }


    public function getBidderPaymentMethodFromStripeById()
    {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        if (!$this->input->is_ajax_request()) {
            http_response_code(403);
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401);
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access payment methods."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        if ($userRoleId != 2) {
            http_response_code(401);
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $draw = (int)$this->input->post('draw');
        $start = (int)$this->input->post('start');
        $length = (int)$this->input->post('length');
        $search = $this->input->post('search')['value'];
        $orderColumnIndex = (int)$this->input->post('order')[0]['column'];
        $orderDir = $this->input->post('order')[0]['dir'];

        $columns = [
            'card_holder_first_name',
            'card_holder_email',
            'card_holder_phone',
            'card_billing_address',
            'card_billing_zip',
            'card_type',
            'card_holder_card_number',
            'card_expiration_month',
            'card_expiration_year',
            'card_status_type_name',
            'card_status_type_id',
            'card_updated_at'
        ];

        $orderByColumn = isset($columns[$orderColumnIndex]) ? $columns[$orderColumnIndex] : 'card_updated_at';
        $orderDir = in_array(strtolower($orderDir), ['asc', 'desc']) ? $orderDir : 'desc';

        try {
            $this->load->model('UserModel');
            $paymentMethodRecords = $this->UserModel->getBidderPaymentMethodById($userId);

            $result = [];
            foreach ($paymentMethodRecords as $record) {
                $pm = \Stripe\PaymentMethod::retrieve($record['stripe_payment_method_id']);
                $card = $pm->card;
                $meta = $pm->billing_details;

                $result[] = [
                    "payment_method_id" => $record['payment_method_id'],
                    "card_holder_first_name" => $meta->name ?? '',
                    "card_holder_email" => $meta->email ?? '',
                    "card_holder_phone" => $meta->phone ?? '',
                    "card_billing_address" => $meta->address->line1 ?? '',
                    "card_billing_zip" => $meta->address->postal_code ?? '',
                    "card_type" => ucfirst($card->brand),
                    "card_holder_card_number" => "**** **** **** " . $card->last4,
                    "card_expiration_month" => str_pad($card->exp_month, 2, "0", STR_PAD_LEFT),
                    "card_expiration_year" => $card->exp_year,
                    "card_is_default" => $record['card_is_default'],
                    "card_status_type_name" => $record['card_status_type_name'],
                    "card_status_type_id" => $record['card_status_type_id'],
                    "card_updated_at" => $record['card_updated_at'],
                ];
            }

            // Filter
            if (!empty($search)) {
                $result = array_filter($result, function ($item) use ($search) {
                    return stripos(json_encode($item), $search) !== false;
                });
            }

            // Sort
            usort($result, function ($a, $b) use ($orderByColumn, $orderDir) {
                return $orderDir === 'asc'
                    ? strcmp($a[$orderByColumn], $b[$orderByColumn])
                    : strcmp($b[$orderByColumn], $a[$orderByColumn]);
            });

            // Paginate
            $total = count($result);
            $paginated = array_slice($result, $start, $length);

            echo json_encode([
                "status" => "success",
                "message" => "Payment method retrieved successfully.",
                "result" => [
                    "draw" => $draw,
                    "recordsTotal" => $total,
                    "recordsFiltered" => $total,
                    "data" => array_values($paginated)
                ]
            ], JSON_PRETTY_PRINT);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Stripe API error: " . $e->getMessage()
            ], JSON_PRETTY_PRINT);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Error: " . $e->getMessage()
            ], JSON_PRETTY_PRINT);
        }
    }


    public function updateBidderPaymentMethodCardStatusFromStripeById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "Access Denied: Your account does not have permission."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_id` is passed (for update scenarios)
        $payment_method_id = isset($json_input['payment_method_id']) ? (int)$json_input['payment_method_id'] : null;

        // ✅ Handle case when `payment_method_id` is NOT passed
        if ($payment_method_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_status_name` is passed (for update scenarios)
        $payment_method_status_name = isset($json_input['payment_method_status_name']) ? (string)$json_input['payment_method_status_name'] : null;


        // ✅ Handle case when `payment_method_status_name` is NOT passed
        if ($payment_method_status_name === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_status_name is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        if ($payment_method_status_name == "Yes") {
            $is_default = "true";
        } else if ($payment_method_status_name == "No") {
            $is_default = "false";
        } else {
            $is_default = 0;
        }

        // ✅ Handle case when `is_default` is NOT passed
        if ($is_default == 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: is_default is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('UserModel');


        // Fetch auction details from the database
        $paymentMethodData = $this->UserModel->getPaymentMethodById($payment_method_id);

        // If auction not found, return error response
        if (!$paymentMethodData) {
            echo json_encode([
                "status" => "error",
                "message" => "Payment method not found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }


        try {

            $stripePaymentMethodId = $paymentMethodData['stripe_payment_method_id'];
            $stripeCustomerId = $paymentMethodData['stripe_customer_id'];
            $cardStatusId = $paymentMethodData['status_type_id'];


            if ($cardStatusId == 2) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Something went wrong. We couldn't update your payment method status. Please try again later."
                ], JSON_PRETTY_PRINT);
                http_response_code(500); // Internal Server Error
                exit;
            }

            if ($is_default) {
                // Set as default card for the customer
                \Stripe\Customer::update(
                    $stripeCustomerId,
                    ['invoice_settings' => ['default_payment_method' => $stripePaymentMethodId]]
                );
            } else {
                // Set as default card for the customer
                \Stripe\Customer::update(
                    $stripeCustomerId,
                    ['invoice_settings' => ['default_payment_method' => null]]
                );
            }

            // ✅ Prepare data to insert into database
            $paymentMethodCardStatusData = [
                "is_default" => $is_default,
                "updated_at" => date("Y-m-d H:i:s")
            ];

            // ✅ Prepare data to insert into database
            $paymentMethodOtherCardStatusData = [
                "is_default" => "false",
                "updated_at" => date("Y-m-d H:i:s")
            ];

            // Fetch auction details from the database
            $paymentMethodResult = $this->UserModel->update_bidder_payment_method_card_status_data($userId, $payment_method_id, $paymentMethodCardStatusData, $paymentMethodOtherCardStatusData);

            // Return the response
            if ($paymentMethodResult) {
                echo json_encode([
                    "status" => "success",
                    "message" => "Your payment method status has been updated successfully.",
                ], JSON_PRETTY_PRINT);
                http_response_code(200);
                exit;
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Something went wrong. We couldn't update your payment method status. Please try again later."
                ], JSON_PRETTY_PRINT);
                http_response_code(500); // Internal Server Error
                exit;
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }
    public function attachDetachBidderPaymentMethodCardStatusFromStripeById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "Access Denied: Your account does not have permission."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_id` is passed (for update scenarios)
        $payment_method_id = isset($json_input['payment_method_id']) ? (int)$json_input['payment_method_id'] : null;

        // ✅ Handle case when `payment_method_id` is NOT passed
        if ($payment_method_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `payment_method_status_name` is passed (for update scenarios)
        $payment_method_status_name = isset($json_input['payment_method_status_name']) ? (string)$json_input['payment_method_status_name'] : null;


        // ✅ Handle case when `payment_method_status_name` is NOT passed
        if ($payment_method_status_name === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_status_name is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        if ($payment_method_status_name == "Active") {
            $payment_method_status_id = 1;
        } else if ($payment_method_status_name == "Inactive") {
            $payment_method_status_id = 2;
        } else {
            $payment_method_status_id = 0;
        }

        // ✅ Handle case when `payment_method_status_id` is NOT passed
        if ($payment_method_status_id == 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: payment_method_status_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('UserModel');


        // Fetch auction details from the database
        $paymentMethodData = $this->UserModel->getPaymentMethodById($payment_method_id);

        // If auction not found, return error response
        if (!$paymentMethodData) {
            echo json_encode([
                "status" => "error",
                "message" => "Payment method not found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }


        try {

            $stripePaymentMethodId = $paymentMethodData['stripe_payment_method_id'];
            $stripeCustomerId = $paymentMethodData['stripe_customer_id'];

            $stripePaymentMethod = \Stripe\PaymentMethod::retrieve($stripePaymentMethodId);

            if ($payment_method_status_id == 1) {
                echo json_encode([
                    "status" => "error",
                    "message" => "This card was previously removed for security reasons and cannot be reused. Please add your card details again to continue."
                ], JSON_PRETTY_PRINT);
                http_response_code(500);
                exit;
            } else if ($payment_method_status_id == 2) {
                $stripePaymentMethod->detach();

                // ✅ Prepare data to insert into database
                $paymentMethodDefaultStatusInfo = [
                    "is_default" => "false",
                    "updated_at" => date("Y-m-d H:i:s")
                ];

                // ✅ Prepare data to insert into database
                $paymentMethodAttachDetachStatusData = [
                    "status_type_id" => $payment_method_status_id,
                    "updated_at" => date("Y-m-d H:i:s")
                ];

                // Fetch auction details from the database
                $paymentMethodResult = $this->UserModel->update_bidder_payment_method_status_data($payment_method_id, $paymentMethodDefaultStatusInfo, $paymentMethodAttachDetachStatusData);


                // Return the response
                if ($paymentMethodResult) {

                    echo json_encode([
                        "status" => "success",
                        "message" => "Your payment method has been detached successfully.",
                    ], JSON_PRETTY_PRINT);
                    http_response_code(200);

                    exit;
                } else {
                    echo json_encode([
                        "status" => "error",
                        "message" => "Something went wrong. We couldn't update your payment method status. Please try again later."
                    ], JSON_PRETTY_PRINT);
                    http_response_code(500); // Internal Server Error
                    exit;
                }
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }



    public function invoicePaymentBidderFromStripeById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "Access Denied: Your account does not have permission."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Check if `invoice_id` is passed (for update scenarios)
        $invoice_id = isset($json_input['invoice_id']) ? (int)$json_input['invoice_id'] : null;

        // ✅ Handle case when `invoice_id` is NOT passed
        if ($invoice_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: invoice_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('UserModel');

        // Fetch auction details from the database
        $userStripeData = $this->UserModel->getUserStripeIdById($userId);

        // If auction not found, return error response
        if (!$userStripeData) {
            echo json_encode([
                "status" => "error",
                "message" => "Customer not found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }


        // Load Auction Model
        $this->load->model('InvoiceModel');


        // Fetch auction details from the database
        $invoiceData = $this->InvoiceModel->getInvoiceById($invoice_id);

        // If auction not found, return error response
        if (!$invoiceData) {
            echo json_encode([
                "status" => "error",
                "message" => "Invoice not found."
            ], JSON_PRETTY_PRINT);
            http_response_code(404); // Not Found
            exit;
        }


        try {

            $stripeCustomerId = $userStripeData['stripe_customer_id'];

            $customer = \Stripe\Customer::retrieve($stripeCustomerId);
            if (empty($customer->invoice_settings->default_payment_method)) {
                throw new Exception("Customer has no default payment method.");
            }

            $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method;

            $invoiceNumber = $invoiceData['id'];
            $invoiceAmount = $invoiceData['total_amount'] * 100; // Convert to cents;
            $invoiceCurrency = strtolower($invoiceData['currency']); // Always lowercase like 'usd'



            // 1️⃣ Create PaymentIntent with default payment method
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => $invoiceAmount,
                'currency' => $invoiceCurrency,
                'customer' => $stripeCustomerId,
                'payment_method' => $defaultPaymentMethodId, // You must specify this if customer has no default
                'confirm' => true,
                'off_session' => true,
                'metadata' => [
                    'invoice_id' => $invoiceNumber,
                    'user_id' => $userId
                ]
            ]);
            if ($paymentIntent->status !== 'succeeded') {
                throw new Exception("Payment failed. Status: " . $paymentIntent->status);
            }

            // ✅ Prepare data to insert into database
            $invoicePaymentByStripeData = [
                "invoice_id" =>  $invoiceNumber,
                "stripe_invoice_id" =>  $paymentIntent->id,
                "created_at" => date("Y-m-d H:i:s"),
                "updated_at" => date("Y-m-d H:i:s")
            ];
            // Fetch auction details from the database
            $invoicePaymentResult = $this->InvoiceModel->insert_invoice_with_stripe($invoicePaymentByStripeData);

            // Return the response
            if ($invoicePaymentResult) {

                echo json_encode([
                    "status" => "success",
                    "message" => "Invoice has been paid successfully.",
                    "data" => [
                        "payment_intent_id" => $paymentIntent->id,
                        "payment_method_id" => $paymentIntent->payment_method,
                        "amount" => $paymentIntent->amount / 100, // convert back to dollars
                        "currency" => strtoupper($paymentIntent->currency),
                        "charge_id" => $paymentIntent->latest_charge,
                        "status" => $paymentIntent->status
                    ]
                ], JSON_PRETTY_PRINT);
                http_response_code(200);

                exit;
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Something went wrong. We couldn't process the invoice payment. Please try again later."
                ], JSON_PRETTY_PRINT);
                http_response_code(500); // Internal Server Error
                exit;
            }
        } catch (CardException $e) {
            // Card-specific errors (e.g., declined, expired)
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'success' => false,
                    'message' => 'Card was declined: ' . $e->getError()->message // ✅ More descriptive
                ]))
                ->set_status_header(200); // Payment Required
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }

    public function addStripeBankAccount()
    {
        $input = $this->getInput(['stripe_customer_id', 'bank_token']);
        try {
            $bankAccount = Customer::createSource($input['stripe_customer_id'], [
                'source' => $input['bank_token']
            ]);
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Bank account added successfully.',
                'result' => $bankAccount
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function updateStripeBankAccount()
    {
        $input = $this->getInput(['stripe_customer_id', 'bank_account_id']);
        try {
            $updated = Customer::updateSource($input['stripe_customer_id'], $input['bank_account_id'], [
                'metadata' => ['updated_by' => $this->session->userdata('auction_user_session_data')['user_id']]
            ]);
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Bank account updated successfully.',
                'result' => $updated
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function deactivateStripeBankAccount()
    {
        $input = $this->getInput(['stripe_customer_id', 'bank_account_id']);
        try {
            $deleted = Customer::deleteSource($input['stripe_customer_id'], $input['bank_account_id']);
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Bank account removed successfully.',
                'result' => $deleted
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function getBankAccountByCustomer()
    {
        $input = $this->getInput(['stripe_customer_id']);
        try {
            $customer = Customer::retrieve($input['stripe_customer_id']);
            $bankAccounts = array_filter($customer->sources->data, function ($source) {
                return $source->object === 'bank_account';
            });
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Bank accounts retrieved successfully.',
                'result' => array_values($bankAccounts)
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function defaultPaymentMethod()
    {
        $input = $this->getInput(['stripe_customer_id', 'payment_method_id']);
        try {
            $customer = Customer::update($input['stripe_customer_id'], [
                'invoice_settings' => [
                    'default_payment_method' => $input['payment_method_id']
                ]
            ]);
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Default payment method set successfully.',
                'result' => $customer
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function defaultBankAccount()
    {
        $input = $this->getInput(['stripe_customer_id', 'bank_account_id']);
        try {
            $bankAccount = Customer::updateSource($input['stripe_customer_id'], $input['bank_account_id'], [
                'default_for_currency' => true
            ]);
            $this->jsonResponse([
                'status' => 'success',
                'message' => 'Default bank account set successfully.',
                'result' => $bankAccount
            ]);
        } catch (ApiErrorException $e) {
            $this->jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }

    public function addBankByStorageFacilityUserFromStripeById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in."
            ], JSON_PRETTY_PRINT);
            http_response_code(401); // Unauthorized
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $email = $userSessionData['email'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 2])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $customer_id = isset($json_input['customer_id']) ? trim($json_input['customer_id']) : null;

        if (empty($customer_id)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing customer ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        $token = isset($json_input['token']) ? trim($json_input['token']) : null;

        if (empty($customer_id) || empty($token)) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing bank token."
            ], JSON_PRETTY_PRINT);
            http_response_code(400);
            exit;
        }

        try {


            // Attach bank account to customer
            $bankAccount = \Stripe\Customer::createSource($customer_id, [
                'source' => $token
            ]);

            // ✅ Prepare data to insert into database
            $bankAccountData = [
                "user_id"     => $userId,
                "stripe_customer_id"   => $customer_id,
                "stripe_bank_account_id"    => $bankAccount->id,
                "is_default"        => "false",
                "status_type_id "     => 1,
                "created_at"               => date("Y-m-d H:i:s"),
                "updated_at"               => date("Y-m-d H:i:s")
            ];

            // Load Auction Model
            $this->load->model('BankModel');

            // Fetch auction details from the database
            $bankAccountResult = $this->BankModel->insertStorageFacilityBankData($bankAccountData);

            // Return the response
            if ($bankAccountResult) {

                $bankAccountId = $bankAccountResult['bank_account_id'];
                // ✅ Prepare data to insert into database
                $bankAccountUserRelationshipData = [
                    "user_id"     => $userId,
                    "bank_id"   => $bankAccountId,
                    "status_type_id "     => 1,
                    "created_at"               => date("Y-m-d H:i:s"),
                    "updated_at"               => date("Y-m-d H:i:s")
                ];

                $bankUserRelationshipDataInserted = $this->BankModel->insertStorageFacilityBankUserRelationshipData($bankAccountUserRelationshipData);

                echo json_encode([
                    "status" => "success",
                    "message" => "Your bank account has been successfully added and secured.",
                    "data" => [
                        "bank_account_id" => $bankAccountResult['bank_account_id']
                    ]
                ], JSON_PRETTY_PRINT);
                http_response_code(200);
                exit;
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Something went wrong. We couldn't add your payment method. Please try again later."
                ], JSON_PRETTY_PRINT);
                http_response_code(500); // Internal Server Error
                exit;
            }
        } catch (ApiErrorException $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'Stripe API error: ' . $e->getMessage()]))
                ->set_status_header(200);
        } catch (Exception $e) {

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['success' => false, 'message' => 'General error: ' . $e->getMessage()]))
                ->set_status_header(200);
        }
    }
}
