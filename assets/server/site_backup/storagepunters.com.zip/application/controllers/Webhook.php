<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Stripe\Stripe;
use Stripe\Customer;
use Stripe\PaymentMethod;
use Stripe\Charge;
use Stripe\Subscription;
use Stripe\Exception\CardException;
use Stripe\Exception\RateLimitException;
use Stripe\Exception\InvalidRequestException;
use Stripe\Exception\AuthenticationException;
use Stripe\Exception\ApiConnectionException;
use Stripe\Exception\ApiErrorException;
use Stripe\Identity\VerificationSession;

class Webhook extends CI_Controller
{
    private $stripe_secret = 'whsec_oBmqBS0xae5KesAz25rdlhGiGtb4ZmoT'; // Your Stripe webhook secret

    public function __construct()
    {
        parent::__construct();
        Stripe::setApiKey("sk_test_51R6fiK08JMAyNQJTX1m1tmy0kDvgkoswTi699EFf0zI180ZzLWvQ0byw4y24JaNrft1t7BVBXCBl9R2eguNYIgog00g1nWmPoM");
        date_default_timezone_set('Australia/Brisbane');
    }

    public function stripeInvoicePaymentStatus()
    {
        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? null;

        // In development mode: skip signature verification
        if (ENVIRONMENT === 'development') {
            $event = json_decode($payload);
        } else {
            if (!$sig_header) {
                return $this->respond(false, 'Missing Stripe signature', [], 400);
            }

            try {
                $event = \Stripe\Webhook::constructEvent(
                    $payload,
                    $sig_header,
                    $this->stripe_secret
                );
            } catch (\UnexpectedValueException $e) {
                return $this->respond(false, 'Invalid payload', [], 400);
            } catch (\Stripe\Exception\SignatureVerificationException $e) {
                return $this->respond(false, 'Invalid signature', [], 400);
            }
        }

        // Load Auction Model
        $this->load->model('LogsModel');

        // ✅ Prepare data to insert into database
        $logsData = [
            "stripe_event_id" => $event->id,
            "stripe_payment_intent_id" => $event->data->object->id,
            "stripe_customer_id" =>  $event->data->object->customer,
            "stripe_charge_id" => $event->data->object->latest_charge,
            "amount_received" => $event->data->object->amount_received,
            "currency" => $event->data->object->currency,
            "payment_status" =>  $event->data->object->status,
            "event_type" =>  $event->type,
            "payment_at" => date('Y-m-d H:i:s', $event->created),
            "invoice_id" => $event->data->object->metadata->invoice_id,
            "created_at" => date("Y-m-d H:i:s"),
            "updated_at" => date("Y-m-d H:i:s")
        ];

        $this->LogsModel->insert_stripe_invoice_payment_logs_data($logsData);


        if ($event->type == 'payment_intent.succeeded') {
            return $this->invoice_payment_success($event->data->object);
        } elseif ($event->type == 'payment_intent.payment_failed') {
            return $this->invoice_payment_failed($event->data->object);
        } else {

            return $this->respond(true, 'Event ignored', [], 200);
        }
    }

    private function invoice_payment_success($paymentIntent)
    {
        // Load the Invoice Model
        $this->load->model('InvoiceModel');

        // Extract PaymentIntent ID from Stripe webhook payload
        $payment_intent_id = $paymentIntent->id ?? null;

        if (!$payment_intent_id) {
            return $this->respond(false, 'Missing payment_intent ID', [], 400);
        }

        // Find the invoice by PaymentIntent ID
        $invoice = $this->InvoiceModel->getByPaymentIntentId($payment_intent_id);

        if (!$invoice) {
            return $this->respond(false, 'Invoice not found', [], 404);
        }

        // Prepare data to update invoice
        $updateData = [
            'invoice_payment_status_type_id ' => 2, // or whatever you want to set
            'updated_at' => date('Y-m-d H:i:s') // optional: update the timestamp
        ];

        // Update the invoice
        $updated = $this->InvoiceModel->updateStatusByPaymentIntentId($invoice['invoice_id'], $updateData);

        if ($updated) {

            return $this->respond(true, 'Invoice updated successfully', [
                'payment_intent_id' => $payment_intent_id,
                'invoice_id' => $invoice['invoice_id']
            ], 200);
        } else {

            return $this->respond(false, 'Failed to update invoice', [], 500);
        }
    }

    private function invoice_payment_failed($paymentIntent)
    {
        // Load the Invoice Model
        $this->load->model('InvoiceModel');

        // Extract PaymentIntent ID from Stripe webhook payload
        $payment_intent_id = $paymentIntent->id ?? null;

        if (!$payment_intent_id) {
            return $this->respond(false, 'Missing payment_intent ID', [], 400);
        }

        // Find the invoice by PaymentIntent ID
        $invoice = $this->InvoiceModel->getByPaymentIntentId($payment_intent_id);

        if (!$invoice) {
            return $this->respond(false, 'Invoice not found', [], 404);
        }

        // Prepare data to update invoice
        $updateData = [
            'invoice_payment_status_type_id' => 4,
            'updated_at' => date('Y-m-d H:i:s')
        ];


        // Update the invoice
        $updated = $this->InvoiceModel->updateStatusByPaymentIntentId($invoice['invoice_id'], $updateData);

        if ($updated) {
            return $this->respond(true, 'Invoice marked as failed', [
                'payment_intent_id' => $payment_intent_id,
                'invoice_id' => $invoice['invoice_id']
            ], 200);
        } else {
            return $this->respond(false, 'Failed to update invoice status', [], 500);
        }
    }




    private function respond($success, $message, $customer = [], $statusCode = 200)
    {
        $response = [
            'success' => $success,
            'message' => $message,
            'customer' => $customer
        ];

        return $this->output
            ->set_content_type('application/json')
            ->set_status_header($statusCode)
            ->set_output(json_encode($response));
    }
}
