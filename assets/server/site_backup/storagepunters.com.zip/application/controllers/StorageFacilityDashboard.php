<?php
defined('BASEPATH') or exit('No direct script access allowed');

class StorageFacilityDashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Check if the user session exists
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 3])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }
    }


    public function storageFacilityDashboard()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            // base_url('assets/js/ajax/dashboard/storage_facility/get_all_auction_status.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/get_all_auction_types.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/get_all_auction_storage_facilities.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/auction.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/dashboard.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/index');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function storageFacilityAccount()
    {

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }


        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/account.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/account');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function storageFacilityStaffManage()
    {

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }

        // Load the Company model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyData = $this->CompanyModel->getCompanyByUserId($userId); // you must implement this method

        if ($companyData == null) {
            // If company does not exist, redirect to setup page
            redirect('company/setup/new');
        }

        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/staff/manage.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/staff/manage');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function storageFacilityManage()
    {

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }

        // Load the Company model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyData = $this->CompanyModel->getCompanyByUserId($userId); // you must implement this method

        if ($companyData == null) {
            // If company does not exist, redirect to setup page
            redirect('company/setup/new');
        }

        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/storage_facility_location/view_storage_facility_all.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/storage_facility_location/manage');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function storageFacilityAdd()
    {

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }

        // Load the Company model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyData = $this->CompanyModel->getCompanyByUserId($userId); // you must implement this method

        if ($companyData == null) {
            // If company does not exist, redirect to setup page
            redirect('company/setup/new');
        }

        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/get_all_companies.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/storage_facility_location/add_storage_facility.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/storage_facility_location/add_storage_facility');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function storageFacilityDetailsEditByStorageFacilityUser($storageFacilityId = null)
    {

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1])) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }


        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];


        // Validate auction ID
        if (!$storageFacilityId || !is_numeric($storageFacilityId)) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Load the Auction model
        $this->load->model('StorageFacilityModel');

        // Fetch auction details from database
        $storageFacilityData = $this->StorageFacilityModel->getStorageFacilityById($storageFacilityId);

        if (!$storageFacilityData) {
            redirect(base_url()); // Redirect if auction is not found
            return;
        }


        // Fetch auction details from database
        $companyDataByStorageFacilityData = $this->StorageFacilityModel->getCompanyIdByStorageFacilityById($storageFacilityId);

        if (!$companyDataByStorageFacilityData) {
            redirect(base_url()); // Redirect if auction is not found
            return;
        }

        $companyId =  $companyDataByStorageFacilityData['company_id'];

        // Load the Company model
        $this->load->model('CompanyModel');


        // Fetch company details from database
        $CompanyByIdWithUserId = $this->CompanyModel->getCompanyByIdWithUserId($companyId, $userId);

        if (!$CompanyByIdWithUserId) {
            redirect(base_url()); // Redirect if company is not found
            return;
        }


        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/get_all_companies.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/storage_facility_location/view_storage_facility_by_id.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/storage_facility_location/details');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }
}
