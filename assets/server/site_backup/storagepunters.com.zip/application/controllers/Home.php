<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/auctions/get_auctions.js'),
            base_url('assets/js/ajax/auctions/get_top_3_auctions.js')
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('home/index');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }
}
