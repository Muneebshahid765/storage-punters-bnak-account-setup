<?php
defined('BASEPATH') or exit('No direct script access allowed');

class BidderDashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Check if the user session exists
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }

        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 2) {
            redirect(base_url()); // Redirect to the default controller
            return;
        }
    }

    public function bidderDashboard()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/bidder/auction.js'),
            base_url('assets/js/ajax/dashboard/bidder/dashboard.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/bidder/index');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function bidderAccount()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/bidder/account.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/bidder/account');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function bidderPaymentMethod()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/bidder/card_validation.js'),
            base_url('assets/js/ajax/dashboard/bidder/stripe.js'),
            base_url('assets/js/ajax/dashboard/bidder/payment.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/bidder/payment');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function bidderNotification()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/bidder/notifications.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/bidder/notifications');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }



    public function storageFacilityDashboard()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/auction.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/dashboard.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/index');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function storageFacilityAccount()
    {
        $data['scripts'] = [
            base_url('assets/js/script.js'),
            base_url('assets/js/ajax/dashboard/storage_facility/account.js'),
        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/account');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

}
