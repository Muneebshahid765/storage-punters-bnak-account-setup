<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bank extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Australia/Brisbane');
    }
    public function index()
    {

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url());
            return;
        }

        // Get logged-in user ID and role
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        if ($userRoleId != 1) {
            redirect(base_url());
            return;
        }

        // Load the bank model
        $this->load->model('BankModel');

        // Check if bank exists for this user
        $bankData = $this->BankModel->getBankByUserId($userId); // you must implement this method

        if ($bankData) {
            // If bank exists, redirect to view page
            redirect('bank/edit/' . $bankData['bank_id']);
        } else {
            // If bank does not exist, redirect to setup page
            redirect('bank/setup/new');
        }
    }


    public function bankDetailsViewByStorageFacilityUser($bankId)
    {

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Validate bank ID
        if (!$bankId || !is_numeric($bankId)) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Load the bank model
        $this->load->model('BankModel');

        // Fetch bank details from database
        $bankData = $this->BankModel->getBankById($bankId);

        if (!$bankData) {
            redirect(base_url()); // Redirect if bank is not found
            return;
        }

        // Fetch bank details from database
        $bankByIdWithUserId = $this->BankModel->getBankByIdWithUserId($bankId, $userId);

        if (!$bankByIdWithUserId) {
            redirect(base_url()); // Redirect if bank is not found
            return;
        }


        $data['scripts'] = [
            base_url('assets/js/ajax/dashboard/storage_facility/bank/view_bank_details_by_id.js'),

        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/bank/details');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }


    public function bankDetailsSetupAddByStorageFacilityUser()
    {
        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }
        // Load the bank model
        $this->load->model('BankModel');

        // Check if bank exists for this user
        $bankData = $this->BankModel->getBankByUserId($userId); // you must implement this method

        if ($bankData) {
            // If bank exists, redirect to view page
            redirect('bank/edit/' . $bankData['id']);
        }

        $data['scripts'] = [
            /*base_url('assets/js/ajax/dashboard/storage_facility/stripe.js'),*/
            base_url('assets/js/ajax/dashboard/storage_facility/bank/add_bank_details.js'),

        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/bank/add_bank');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

}
