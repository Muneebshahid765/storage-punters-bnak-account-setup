<?php
defined('BASEPATH') or exit('No direct script access allowed');

class StorageFacility extends CI_Controller
{

    public function getAllFacilitiesByUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if (!in_array($userRoleId, [1, 3])) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Load Auction Model
        $this->load->model('UserModel');

        // Fetch bidder profile details from the database
        $facilityData = $this->UserModel->getAllFacilitiesByUser($userId);

        // If user profile not found, return error response
        if (!$facilityData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No facility data is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Facility data has been retrieved successfully.",
            "data" => $facilityData
        ], JSON_PRETTY_PRINT);
    }

    public function addStorageFacilityByStorageFacilityUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Get  storage company ID from JSON input
        $companyId = !empty($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate company ID
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Required fields list
        $required_fields = [
            'storage_facility_name',
            'storage_facility_abn',
            'storage_facility_website',
            'storage_facility_description',
            'storage_facility_timezone',
            'storage_facility_contact_email',
            'storage_facility_office_hours',
            'storage_facility_payout_details'
        ];

        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || trim((string)$json_input[$field]) === '') {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Extract only required fields from JSON input
        $storageFacilityData = [
            'name' => isset($json_input['storage_facility_name']) ? trim($json_input['storage_facility_name']) : null,
            'abn' => isset($json_input['storage_facility_abn']) ? trim($json_input['storage_facility_abn']) : null,
            'website' => isset($json_input['storage_facility_website']) ? trim($json_input['storage_facility_website']) : null,
            'description' => isset($json_input['storage_facility_description']) ? trim($json_input['storage_facility_description']) : null,
            'timezone' => isset($json_input['storage_facility_timezone']) ? trim($json_input['storage_facility_timezone']) : null,
            'contact_email' => isset($json_input['storage_facility_contact_email']) ? trim($json_input['storage_facility_contact_email']) : null,
            'additional_email' => isset($json_input['storage_facility_additional_email']) ? trim($json_input['storage_facility_additional_email']) : null,
            'office_hours' => isset($json_input['storage_facility_office_hours']) ? trim($json_input['storage_facility_office_hours']) : null,
            'payout_details' => isset($json_input['storage_facility_payout_details']) ? trim($json_input['storage_facility_payout_details']) : null,
            'youtube_video_url' => isset($json_input['storage_facility_youtube_video_url']) ? trim($json_input['storage_facility_youtube_video_url']) : null,
            'branding_logo' => isset($json_input['storage_facility_branding_logo']) ? trim($json_input['storage_facility_branding_logo']) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        // Load storage facility Model
        $this->load->model('StorageFacilityModel');


        $storageFacilityDataInserted = $this->StorageFacilityModel->insertStorageFacilityData($storageFacilityData);

        // Get storage facility ID from JSON input
        $storageFacilityId = $storageFacilityDataInserted['storage_facility_id'];

        // Validate storage facility ID
        if ($storageFacilityId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing storage facility ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $storageFacilityLocationData = [
            'street_address' => isset($json_input['storage_facility_street_address']) ? trim($json_input['storage_facility_street_address']) : null,
            'apt_suite' => isset($json_input['storage_facility_apt_suite']) ? trim($json_input['storage_facility_apt_suite']) : null,
            'city' => isset($json_input['storage_facility_city']) ? trim($json_input['storage_facility_city']) : null,
            'postal_code' => isset($json_input['storage_facility_zip']) ? trim($json_input['storage_facility_zip']) : null,
            'state' => isset($json_input['storage_facility_state']) ? trim($json_input['storage_facility_state']) : null,
            'country' => isset($json_input['storage_facility_country']) ? trim($json_input['storage_facility_country']) : null,
            'phone' => isset($json_input['storage_facility_cell_phone']) ? trim($json_input['storage_facility_cell_phone']) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        $storageFacilityLocationDataInserted = $this->StorageFacilityModel->insertStorageFacilityLocationData($storageFacilityLocationData);

        // Get storage facility location ID from JSON input
        $storageFacilityLocationId = $storageFacilityLocationDataInserted['storage_facility_location_id'];

        // Validate company ID
        if ($storageFacilityLocationId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing storage facility location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $storageFacilityLocationRelationshipData = [
            'storage_facility_id' => $storageFacilityId,
            'location_id' => $storageFacilityLocationId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $storageFacilityStatusData = [
            'storage_facility_id' => $storageFacilityId,
            'status_type_id' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $storageFacilityCompanyRelationshipData = [
            'storage_facility_id' => $storageFacilityId,
            'company_id' => $companyId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        $storageFacilityLocationRelationshipDataInserted = $this->StorageFacilityModel->insertStorageFacilityLocationRelationshipData($storageFacilityLocationRelationshipData);
        $storageFacilityStatusDataInserted = $this->StorageFacilityModel->insertStorageFacilityStatusData($storageFacilityStatusData);
        $storageFacilityCompanyRelationshipDataInserted = $this->StorageFacilityModel->insertStorageFacilityCompanyRelationshipData($storageFacilityCompanyRelationshipData);


        // Check if at least one update was successful
        if ($storageFacilityDataInserted || $storageFacilityLocationDataInserted || $storageFacilityLocationRelationshipDataInserted || $storageFacilityStatusDataInserted || $storageFacilityCompanyRelationshipDataInserted) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Storage facility informations has been added successfully.",
                "data" => [
                    "storage_facility_id" => $storageFacilityId
                ]
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add storage facility details."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }



    public function updateStorageFacilityByStorageFacilityUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Get  storage facility ID from JSON input
        $storageFacilityId = isset($json_input['storageFacilityId']) ? (int)$json_input['storageFacilityId'] : 0;

        // Validate  storage facility ID
        if ($storageFacilityId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing  storage facility ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Load Company Model
        $this->load->model('StorageFacilityModel');

        // Check if company exists for this user
        $storageFacilityLocationData = $this->StorageFacilityModel->getStorageFacilityLocationIdByStorageFacilityId($storageFacilityId); // you must implement this method


        // Get storage facility location ID from JSON input
        $storageFacilityLocationId = $storageFacilityLocationData['location_id'];

        // Validate company ID
        if ($storageFacilityLocationId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing storage facility location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Required fields list
        $required_fields = [
            'storage_facility_name',
            'storage_facility_abn',
            'storage_facility_website',
            'storage_facility_description',
            'storage_facility_timezone',
            'storage_facility_contact_email',
            'storage_facility_office_hours',
            'storage_facility_payout_details'
        ];

        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || trim((string)$json_input[$field]) === '') {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Extract only required fields from JSON input
        $storageFacilityData = [
            'name' => isset($json_input['storage_facility_name']) ? trim($json_input['storage_facility_name']) : null,
            'abn' => isset($json_input['storage_facility_abn']) ? trim($json_input['storage_facility_abn']) : null,
            'website' => isset($json_input['storage_facility_website']) ? trim($json_input['storage_facility_website']) : null,
            'description' => isset($json_input['storage_facility_description']) ? trim($json_input['storage_facility_description']) : null,
            'timezone' => isset($json_input['storage_facility_timezone']) ? trim($json_input['storage_facility_timezone']) : null,
            'contact_email' => isset($json_input['storage_facility_contact_email']) ? trim($json_input['storage_facility_contact_email']) : null,
            'additional_email' => isset($json_input['storage_facility_additional_email']) ? trim($json_input['storage_facility_additional_email']) : null,
            'office_hours' => isset($json_input['storage_facility_office_hours']) ? trim($json_input['storage_facility_office_hours']) : null,
            'payout_details' => isset($json_input['storage_facility_payout_details']) ? trim($json_input['storage_facility_payout_details']) : null,
            'youtube_video_url' => isset($json_input['storage_facility_youtube_video_url']) ? trim($json_input['storage_facility_youtube_video_url']) : null,
            'branding_logo' => isset($json_input['storage_facility_branding_logo']) ? trim($json_input['storage_facility_branding_logo']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];


        $storageFacilityLocationData = [
            'street_address' => isset($json_input['storage_facility_street_address']) ? trim($json_input['storage_facility_street_address']) : null,
            'apt_suite' => isset($json_input['storage_facility_apt_suite']) ? trim($json_input['storage_facility_apt_suite']) : null,
            'city' => isset($json_input['storage_facility_city']) ? trim($json_input['storage_facility_city']) : null,
            'postal_code' => isset($json_input['storage_facility_zip']) ? trim($json_input['storage_facility_zip']) : null,
            'state' => isset($json_input['storage_facility_state']) ? trim($json_input['storage_facility_state']) : null,
            'country' => isset($json_input['storage_facility_country']) ? trim($json_input['storage_facility_country']) : null,
            'phone' => isset($json_input['storage_facility_cell_phone']) ? trim($json_input['storage_facility_cell_phone']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $storageFacilityDataUpdated = $this->StorageFacilityModel->updateStorageFacilityData($storageFacilityId, $storageFacilityData);
        $storageFacilityLocationDataUpdated = $this->StorageFacilityModel->updateStorageFacilityLocationData($storageFacilityLocationId, $storageFacilityLocationData);

        // Check if at least one update was successful
        if ($storageFacilityDataUpdated || $storageFacilityLocationDataUpdated) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Storage facility informations has been updated successfully."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update storage facility details."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }




    public function updateStorageFacilityStatusByIdByStorageFacilityUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Get storage facility ID from JSON input
        $storageFacilityId = isset($json_input['storage_facility_id']) ? (int)$json_input['storage_facility_id'] : 0;

        // Validate  storage facility ID
        if ($storageFacilityId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing storage facility ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // ✅ Check if `storage_facility_status_name` is passed (for update scenarios)
        $storage_facility_status_name = isset($json_input['storage_facility_status_name']) ? (string)$json_input['storage_facility_status_name'] : null;


        // ✅ Handle case when `storage_facility_status_name` is NOT passed
        if ($storage_facility_status_name === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: storage_facility_status_name is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        if ($storage_facility_status_name == "Active") {
            $storage_facility_status_id = 1;
        } else if ($storage_facility_status_name == "Inactive") {
            $storage_facility_status_id = 2;
        } else {
            $storage_facility_status_id = 0;
        }

        // ✅ Handle case when `storage_facility_status_id` is NOT passed
        if ($storage_facility_status_id == 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing input parameters: storage_facility_status_id is required."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Load User Model
        $this->load->model('StorageFacilityModel');

        $storageFacilityStatusData = [
            'status_type_id' => $storage_facility_status_id,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $storageFacilityStatusDataUpdated = $this->StorageFacilityModel->updateStorageFacilityStatusData($storageFacilityId, $storageFacilityStatusData);

        // Check if at least one update was successful
        if ($storageFacilityStatusDataUpdated) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Storage facility status has been updated successfully."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update storage facility status."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }


    public function getAllStorageFacility()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405); // Method Not Allowed
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            http_response_code(403); // Forbidden
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access payment methods."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Sanitize input data
        $draw = (int)$this->input->post('draw');
        $start = (int)$this->input->post('start');
        $length = (int)$this->input->post('length');
        $search = $this->input->post('search')['value'];
        $orderColumn = $this->input->post('order')[0]['column'];
        $orderDir = $this->input->post('order')[0]['dir'];

        // Validate input data to prevent SQL injection
        if (!is_int($draw) || !is_int($start) || !is_int($length)) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['error' => 'Invalid input']))
                ->set_status_header(400);
            return;
        }

        // Load User Model
        $this->load->model('StorageFacilityModel');

        $totalRecords = $this->StorageFacilityModel->countAllStorageFacility();
        $filteredRecords = $this->StorageFacilityModel->countFilteredStorageFacility($search, $userId);
        $result = $this->StorageFacilityModel->getFilteredStorageFacilityById($start, $length, $search, $orderColumn, $orderDir, $userId);

        // Prepare the response data
        $data = [
            'draw' => $draw,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data' => $result,
        ];

        // Return success response with storage facilities data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Storage facilities retrieved successfully.",
            "result" => $data
        ], JSON_PRETTY_PRINT);
    }


    public function getAllStorageFacilityById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Get storage facility ID from JSON input
        $storageFacilityId = isset($json_input['storageFacilityId']) ? (int)$json_input['storageFacilityId'] : 0;

        // Validate auction ID
        if ($storageFacilityId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing storage facility ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('StorageFacilityModel');

        // Fetch bidder profile details from the database
        $storageDacilityData = $this->StorageFacilityModel->getStorageFacilityInformationById($storageFacilityId);

        // If user profile not found, return error response
        if (!$storageDacilityData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No storage facility is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Your storage facility data is retrieved successfully.",
            "data" => $storageDacilityData
        ], JSON_PRETTY_PRINT);
    }
}
