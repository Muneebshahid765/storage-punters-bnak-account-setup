<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Companies extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Australia/Brisbane');
    }
    public function index()
    {

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url());
            return;
        }

        // Get logged-in user ID and role
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        if ($userRoleId != 1) {
            redirect(base_url());
            return;
        }

        // Load the Company model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyData = $this->CompanyModel->getCompanyByUserId($userId); // you must implement this method

        if ($companyData) {
            // If company exists, redirect to view page
            redirect('company/edit/' . $companyData['company_id']);
        } else {
            // If company does not exist, redirect to setup page
            redirect('company/setup/new');
        }
    }


    public function getAllCompaniesByUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Load Auction Model
        $this->load->model('CompanyModel');

        // Fetch bidder profile details from the database
        $companyData = $this->CompanyModel->getAllCompaniesByUser($userId);

        // If user profile not found, return error response
        if (!$companyData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No company data is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Company data has been retrieved successfully.",
            "data" => $companyData
        ], JSON_PRETTY_PRINT);
    }

    public function companyDetailsViewByStorageFacilityUser($companyId)
    {

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Validate company ID
        if (!$companyId || !is_numeric($companyId)) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Load the Company model
        $this->load->model('CompanyModel');

        // Fetch company details from database
        $companyData = $this->CompanyModel->getCompanyById($companyId);

        if (!$companyData) {
            redirect(base_url()); // Redirect if company is not found
            return;
        }

        // Fetch company details from database
        $CompanyByIdWithUserId = $this->CompanyModel->getCompanyByIdWithUserId($companyId, $userId);

        if (!$CompanyByIdWithUserId) {
            redirect(base_url()); // Redirect if company is not found
            return;
        }


        $data['scripts'] = [
            base_url('assets/js/ajax/dashboard/storage_facility/company/view_company_details_by_id.js'),

        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/company/details');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }
    public function companyDetailsSetupAddByStorageFacilityUser()
    {
        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            redirect(base_url()); // Redirect to the default controller route
            return;
        }
        // Load the Company model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyData = $this->CompanyModel->getCompanyByUserId($userId); // you must implement this method

        if ($companyData) {
            // If company exists, redirect to view page
            redirect('company/edit/' . $companyData['id']);
        }

        $data['scripts'] = [
            base_url('assets/js/ajax/dashboard/storage_facility/company/add_company_details.js'),

        ];

        $this->load->view('layout/head');
        $this->load->view('layout/header');
        $this->load->view('dashboard/storage_facility/company/add_company');
        $this->load->view('layout/footer');
        $this->load->view('layout/scripts', $data);
    }

    public function addCompanyByStorageFacilityUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // ✅ Required fields list
        $required_fields = [
            'company_name',
            'company_website',
            'company_email',
            'company_street_address',
            'company_apt_suite',
            'company_city',
            'company_zip',
            'company_state',
            'company_country',
            'company_cell_phone'

        ];

        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || trim((string)$json_input[$field]) === '') {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Extract only required fields from JSON input
        $companyData = [
            'name' => isset($json_input['company_name']) ? trim($json_input['company_name']) : null,
            'website' => isset($json_input['company_website']) ? trim($json_input['company_website']) : null,
            'email' => isset($json_input['company_email']) ? trim($json_input['company_email']) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        // Load Company Model
        $this->load->model('CompanyModel');


        $companyDataInserted = $this->CompanyModel->insertCompanyData($companyData);

        // Get company ID from JSON input
        $companyId = $companyDataInserted['company_id'];

        // Validate company ID
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $companyLocationData = [
            'street_address' => isset($json_input['company_street_address']) ? trim($json_input['company_street_address']) : null,
            'apt_suite' => isset($json_input['company_apt_suite']) ? trim($json_input['company_apt_suite']) : null,
            'city' => isset($json_input['company_city']) ? trim($json_input['company_city']) : null,
            'postal_code' => isset($json_input['company_zip']) ? trim($json_input['company_zip']) : null,
            'state' => isset($json_input['company_state']) ? trim($json_input['company_state']) : null,
            'country' => isset($json_input['company_country']) ? trim($json_input['company_country']) : null,
            'phone' => isset($json_input['company_cell_phone']) ? trim($json_input['company_cell_phone']) : null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        $companyLocationDataInserted = $this->CompanyModel->insertCompanyLocationData($companyLocationData);

        // Get company location ID from JSON input
        $companyLocationId = $companyLocationDataInserted['company_location_id'];

        // Validate company ID
        if ($companyLocationId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        $companyLocationRelationshipData = [
            'company_id' => $companyId,
            'location_id' => $companyLocationId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $companyStatusData = [
            'company_id' => $companyId,
            'status_type_id' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $companyUserRelationshipData = [
            'company_id' => $companyId,
            'user_id' => $userId,
            'status_type_id' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];


        $companyLocationRelationshipDataInserted = $this->CompanyModel->insertCompanyLocationRelationshipData($companyLocationRelationshipData);
        $companyStatusDataInserted = $this->CompanyModel->insertCompanyStatusData($companyStatusData);
        $companyUserRelationshipDataInserted = $this->CompanyModel->insertCompanyUserRelationshipData($companyUserRelationshipData);


        // Check if at least one update was successful
        if ($companyDataInserted || $companyLocationData || $companyLocationRelationshipDataInserted || $companyStatusDataInserted ||  $companyUserRelationshipDataInserted) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Company informations has been added successfully.",
                "data" => [
                    "company_id" => $companyId
                ]
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add company details."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }


    public function updateCompanyByStorageFacilityUser()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }
        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Get company ID from JSON input
        $companyId = isset($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate company ID
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Company Model
        $this->load->model('CompanyModel');

        // Check if company exists for this user
        $companyLocationData = $this->CompanyModel->getCompanyLocationIdByCompanyId($companyId); // you must implement this method

        // Get company location ID from JSON input
        $companyLocationId = $companyLocationData['location_id'];

        // Validate company ID
        if ($companyLocationId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company location ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // ✅ Required fields list
        $required_fields = [
            'company_name',
            'company_website',
            'company_email',
            'company_street_address',
            'company_apt_suite',
            'company_city',
            'company_zip',
            'company_state',
            'company_country',
            'company_cell_phone'

        ];
        $missing_fields = [];

        // ✅ Validate required fields
        foreach ($required_fields as $field) {
            if (!isset($json_input[$field]) || trim((string)$json_input[$field]) === '') {
                $missing_fields[] = $field;
            }
        }

        // ✅ Return error if any required field is missing
        if (!empty($missing_fields)) {
            echo json_encode([
                "status" => "error",
                "message" => "Missing required fields: " . implode(", ", $missing_fields)
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }


        // Extract only required fields from JSON input
        $companyData = [
            'name' => isset($json_input['company_name']) ? trim($json_input['company_name']) : null,
            'website' => isset($json_input['company_website']) ? trim($json_input['company_website']) : null,
            'email' => isset($json_input['company_email']) ? trim($json_input['company_email']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];





        $companyLocationData = [
            'street_address' => isset($json_input['company_street_address']) ? trim($json_input['company_street_address']) : null,
            'apt_suite' => isset($json_input['company_apt_suite']) ? trim($json_input['company_apt_suite']) : null,
            'city' => isset($json_input['company_city']) ? trim($json_input['company_city']) : null,
            'postal_code' => isset($json_input['company_zip']) ? trim($json_input['company_zip']) : null,
            'state' => isset($json_input['company_state']) ? trim($json_input['company_state']) : null,
            'country' => isset($json_input['company_country']) ? trim($json_input['company_country']) : null,
            'phone' => isset($json_input['company_cell_phone']) ? trim($json_input['company_cell_phone']) : null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $companyDataUpdated = $this->CompanyModel->updateCompanyData($companyId, $companyData);
        $companyLocationDataUpdated = $this->CompanyModel->updateCompanyLocationData($companyLocationId, $companyLocationData);


        // Check if at least one update was successful
        if ($companyDataUpdated || $companyLocationDataUpdated) {
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Company informations has been updated successfully."
            ], JSON_PRETTY_PRINT);
        } else {
            http_response_code(500);
            echo json_encode([
                "status" => "error",
                "message" => "Failed to update company details."
            ], JSON_PRETTY_PRINT);
        }
        exit;
    }

    public function getCompanyInformationById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Check if user is logged in
        if (!$this->session->userdata('auction_user_session_data')) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "User is not logged in. Please log in to access your profile."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Get logged-in user ID
        $userSessionData = $this->session->userdata('auction_user_session_data');
        $userId = $userSessionData['user_id'];
        $userRoleId = $userSessionData['role_id'];

        // Check if user is logged in
        if ($userRoleId != 1) {
            http_response_code(401); // Unauthorized
            echo json_encode([
                "status" => "error",
                "message" => "You do not have the required permissions to access this request."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Get company ID from JSON input
        $companyId = isset($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate auction ID
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('CompanyModel');

        // Fetch bidder profile details from the database
        $companyData = $this->CompanyModel->getCompanyInformationById($companyId);

        // If user profile not found, return error response
        if (!$companyData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No company is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Your company data is retrieved successfully.",
            "data" => $companyData
        ], JSON_PRETTY_PRINT);
    }


    public function getCompanyDetailsById()
    {
        header('Content-Type: application/json');

        // Ensure it's a POST request
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid request method. Only POST requests are allowed."
            ], JSON_PRETTY_PRINT);
            http_response_code(405); // Method Not Allowed
            exit;
        }

        // Ensure it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            echo json_encode([
                "status" => "error",
                "message" => "Unauthorized request. This endpoint accepts only AJAX requests."
            ], JSON_PRETTY_PRINT);
            http_response_code(403); // Forbidden
            exit;
        }

        // Read JSON input safely
        $json_input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid JSON payload: " . json_last_error_msg()
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Get company ID from JSON input
        $companyId = isset($json_input['companyId']) ? (int)$json_input['companyId'] : 0;

        // Validate auction ID
        if ($companyId <= 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Invalid or missing company ID."
            ], JSON_PRETTY_PRINT);
            http_response_code(400); // Bad Request
            exit;
        }

        // Load Auction Model
        $this->load->model('CompanyModel');

        // Fetch bidder profile details from the database
        $companyData = $this->CompanyModel->getCompanyDetailsById($companyId);

        // If user profile not found, return error response
        if (!$companyData) {
            http_response_code(404); // Not Found
            echo json_encode([
                "status" => "error",
                "message" => "No company is found."
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Return success response with user profile data
        http_response_code(200); // Success
        echo json_encode([
            "status" => "success",
            "message" => "Your company data is retrieved successfully.",
            "data" => $companyData
        ], JSON_PRETTY_PRINT);
    }
}
