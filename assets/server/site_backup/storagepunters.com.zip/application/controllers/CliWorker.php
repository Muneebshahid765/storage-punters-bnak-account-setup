<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CliWorker extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // Restrict access to CLI only
        if (!$this->input->is_cli_request()) {
            show_error('This script can only be accessed via the command line.', 403);
        }

        // Set timezone to Brisbane
        date_default_timezone_set('Australia/Brisbane');

        $this->load->model('AuctionModel');
    }

    /**
     * Monitor auction end time and update status to 'ended'.
     * Usage: php index.php CliWorker monitorAuctionEnd <auctionId> <endTimestamp>
     */
    public function monitorAuctionEnd($auctionId = null, $endTimestamp = null)
    {
        log_message('info', "CliWorker: monitorAuctionEnd STARTED for auction ID {$auctionId} at " . date('Y-m-d H:i:s'));

        // Validate inputs
        if (!$auctionId || !$endTimestamp || !is_numeric($endTimestamp)) {
            log_message('error', "CliWorker: Invalid parameters received (auctionId: {$auctionId}, endTimestamp: {$endTimestamp})");
            echo "Invalid parameters.\n";
            return;
        }

        // Fetch auction
        $auctionData = $this->AuctionModel->getAuctionById($auctionId);
        if (!$auctionData) {
            log_message('error', "CliWorker: Auction not found with ID: $auctionId");
            echo "Auction not found.\n";
            return;
        }

        $now = time();
        $wait = $endTimestamp - $now;

        if ($wait > 0) {
            log_message('info', "CliWorker: Auction ID $auctionId will sleep for {$wait} seconds (until " . date('Y-m-d H:i:s', $endTimestamp) . ").");
            sleep($wait);
        } else {
            log_message('debug', "CliWorker: Auction ID $auctionId already expired (timestamp difference = $wait). Proceeding immediately.");
        }



        // Check for highest bid
        $currentHighestBid = $this->AuctionModel->getCurrentHighestBidWithUser($auctionId);

        if ($currentHighestBid['user_id'] !== null) {
            try {
                $this->load->model('UserModel');
                $userId = $currentHighestBid['user_id'];
                $maxBid = $currentHighestBid['current_highest_bid'];
                $user = $this->UserModel->get_users_information_by_id($userId);

                if ($user) {
                    $this->load->model('EmailQueueModel');
                    $auctionDetails = $this->AuctionModel->getAuctionInformationById($auctionId);

                    if (!isset($auctionDetails[0])) {
                        log_message('error', "CliWorker: No auction details found for auction ID {$auctionId}.");
                    } else {

                        $auction = $auctionDetails[0];
                        $scheduleTime = date('Y-m-d H:i:s');

                        // Add email to queue
                        $this->EmailQueueModel->add([
                            'to_email'      => $user->email,
                            'subject'       => "Congratulations, You Won the Auction!",
                            'template'      => "auction_winner_email",
                            'name'          => $user->first_name . " " . $user->last_name,
                            'user_id'  =>  $userId,
                            'auction_id'    => $auctionId,
                            'auction_item'  => trim($auction->auction_storage_facility_name . ' #' . $auction->auction_id . ' - ' . $auction->auction_storage_facility_city . ' , ' . $auction->auction_storage_facility_state),
                            'auction_amount' => $maxBid,
                            'auction_total' => $maxBid,
                            'auction_url'   => base_url('auctions/' . $auctionId),
                            'scheduled_at'  => $scheduleTime,
                            'status'        => 'pending'
                        ]);

                        // Update auction to 'expired'
                        $updateData = [
                            'auction_type_id' => 9, // Won
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                        $this->AuctionModel->updateAuctionStatusTypeData($auctionId, $updateData);

                        log_message('info', "CliWorker: Auction ID $auctionId marked as won.");

                        log_message('info', "CliWorker: Winner email queued for user ID $userId (Auction ID $auctionId, Bid: $maxBid)");

                        $this->auctionWonEmailToBackgroundSchedule($auctionId);
                    }
                } else {
                    log_message('error', "CliWorker: User ID $userId not found. Cannot queue winner email.");
                }
            } catch (Exception $e) {
                log_message('error', "CliWorker: Exception while processing winner for auction ID $auctionId - " . $e->getMessage());
            }
        } else {

            // Update auction to 'expired'
            $updateData = [
                'auction_type_id' => 10, // Expired
                'updated_at' => date('Y-m-d H:i:s')
            ];
            $this->AuctionModel->updateAuctionStatusTypeData($auctionId, $updateData);

            log_message('info', "CliWorker: Auction ID $auctionId marked as expired.");

            log_message('info', "CliWorker: No bids placed for Auction ID $auctionId. No winner email sent.");
        }

        echo "✅ Auction ID $auctionId processed at " . date('Y-m-d H:i:s') . "\n";
    }


    public function auctionWonEmailToBackgroundSchedule($auctionId)
    {

        // Step 1: Get current time + 5 minutes in Brisbane
        $endDateTime = new DateTime('now', new DateTimeZone('Australia/Brisbane'));
        $endDateTime->modify('+3 minutes');
        $endTimestamp = $endDateTime->getTimestamp();

        // Step 2: Determine proper PHP path
        $phpPath = PHP_BINARY;

        // On Windows Apache, PHP_BINARY may point to httpd.exe — fallback
        if (str_contains(strtolower($phpPath), 'httpd.exe')) {
            $phpPath = 'C:\xampp\php\php.exe'; // XAMPP fallback path
        }

        // Step 3: Paths & redirection
        $indexPhpPath = FCPATH . "index.php";
        $isWindows = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
        $redirect = $isWindows ? '> NUL 2>&1' : '> /dev/null 2>&1';

        // Step 4: Build and run command
        $cliCommand = "\"{$phpPath}\" \"{$indexPhpPath}\" Email process_auction_win_email_by_id {$auctionId} {$endTimestamp} {$redirect}";
        exec($cliCommand);

        // Step 5: Log message
        log_message('info', "Winner Email for Auction ID {$auctionId} will be sent in 3 minutes (Brisbane time: {$endDateTime->format('Y-m-d H:i:s')}, timestamp: {$endTimestamp}).");
        log_message('debug', "CLI command executed: {$cliCommand}");
    }
}
